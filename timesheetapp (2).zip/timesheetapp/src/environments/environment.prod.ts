export const environment = {
  production: false,
  API_URL:'http://localhost:56753/',
  SECRET_KEY:'1203199320052021',
  SECRET_KEY_IV:'1203199320052021',
};
