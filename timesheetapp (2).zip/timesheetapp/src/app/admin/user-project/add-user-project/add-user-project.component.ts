import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { IUserProject, IUserProjectFormGroup } from 'src/app/core/interface/IUserProject';
import { ProjectService } from 'src/app/core/services/project/project.service';


@Component({
  selector: 'app-add-user-project',
  templateUrl: './add-user-project.component.html',
  styleUrls: ['./add-user-project.component.css']
})
export class AddUserProjectComponent implements OnInit {

  userProject: IUserProject;
  userProjectForm: IUserProjectFormGroup;
  /**
   *
   */
  constructor(private dialogRef: MatDialogRef<AddUserProjectComponent>,
    @Inject(MAT_DIALOG_DATA) public data: IUserProject,
    private fb: FormBuilder, private projectService: ProjectService) {
  }


  ngOnInit(): void {
    this.userProjectForm = this.fb.group({
      id: [""],
      userMid: ["", Validators.required],
      projectId: ["", Validators.required],
      startDate: ["", Validators.required],
      endDate: ["", Validators.required]

    }) as IUserProjectFormGroup;
  }

  submit() {

  }
  confirmAdd() {

  }
  onCancel() {

  }
}