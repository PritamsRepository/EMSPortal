import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddUserProjectComponent } from './add-user-project/add-user-project.component';
import { IUserProject } from 'src/app/core/interface/IUserProject';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Observable, map } from 'rxjs';
import { ProjectService } from 'src/app/core/services/project/project.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { IProject } from 'src/app/core/interface/IProject';

@Component({
  selector: 'app-user-project',
  templateUrl: './user-project.component.html',
  styleUrls: ['./user-project.component.css']
})
export class UserProjectComponent implements OnInit, AfterViewInit {

  userProject: IUserProject;
  data: any;
  dataSource1 = new MatTableDataSource<IUserProject>();

  $dataSource: Observable<MatTableDataSource<IUserProject>>;

  columnsToDisplay = ['id', 'projectName', 'personName', 'startDate', 'endDate', 'isActive'];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private _dialog: MatDialog, private projectService: ProjectService, private _toaster: ToasterService) {


  }

  ngOnInit(): void {
    this.$dataSource =
      this.projectService._getAllUserAssignedProject().pipe(
        map(things => {
          const datasource = this.dataSource1;
          datasource.data = things as IUserProject[]
          datasource.sort = this.sort, 
          datasource.paginator = this.paginator ;
          return datasource;
        }));

  }

  ngAfterViewInit(): void {

    // this.$dataSource.subscribe({
    //   next: x => { x.sort = this.sort, x.paginator = this.paginator }
    // });
  }

  openDialogForUserProject() {
    const dialogRef = this._dialog.open(AddUserProjectComponent, {
      data: { userProject: this.userProject }
    });
  }

  public getData = () => {
    this.projectService._getAllUserAssignedProject()
      .subscribe({
        next: res => res as IUserProject[],
        error(err) { },
        complete() { }
      });
  }
  public customSort = (event) => {
    console.log(event);
  }
}