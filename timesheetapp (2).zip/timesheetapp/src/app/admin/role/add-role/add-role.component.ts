import { Component, Inject, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Observable, tap, map } from 'rxjs'
import { FormControl, FormGroup, Validator, FormBuilder, Validators } from '@angular/forms'
import { IRole, IRoleFormGroup } from 'src/app/core/interface/IRole'
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { validateBasis } from '@angular/flex-layout';
import { RoleService } from 'src/app/core/services/role/role.service';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {

  roleData: IRole;
  roleFormGroup: IRoleFormGroup;
  constructor(public dialog: MatDialogRef<AddRoleComponent>, 
    @Inject(MAT_DIALOG_DATA) 
    public data: IRole, public fb: FormBuilder,
    public toaster: ToasterService, public roleService: RoleService) {


  }
  ngOnInit(): void {
    this.roleFormGroup = this.fb.group({
      roleId: [""],
      roleName: ["", Validators.required],
      roleCode: ["", Validators.required],
      isAdmin: [false, Validators.required],
      isActive: [true, Validators.required],

    }) as IRoleFormGroup;
  }
  submit() {

  }
  confirmAdd() {
    this.roleData = this.data;
    this.roleService.addRole(this.roleData).subscribe();
    this.toaster.showToasterMessage('success', 'Well done!', 'This is a success alert', 3000);

  }
  onNoClick() {
    this.dialog.close();
  }
}
