import { Component, OnInit, ViewChild, AfterViewInit  } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {IRole} from 'src/app/core/interface/IRole'
import { AddRoleComponent } from './add-role/add-role.component';
import { RoleService } from 'src/app/core/services/role/role.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit, AfterViewInit {

role:IRole;
public dataSource = new  MatTableDataSource<IRole>();
columnsToDisplay = ['roleId', 'roleName', 'roleCode','isAdmin','isActive'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

 constructor(public dialog:MatDialog, public roleService:RoleService) {
 }
 ngOnInit(): void {
  const componentTitle="Role Master";
  this.getAllRoles();
 }
 
 ngAfterViewInit(): void {
  this.dataSource.sort = this.sort;
  this.dataSource.paginator = this.paginator;
 }
 getAllRoles(){
  return  this.roleService.GetAllRoles().subscribe(
    res=>{
      this.dataSource.data = res as IRole[];
    }
  );

 }
  public openAddRoleMasterDialoge() {
    const dialogRef = this.dialog.open(AddRoleComponent, {
      data: { role: this.role }
    });
  }
  public customSort = (event) => {
    console.log(event);
  }

}
