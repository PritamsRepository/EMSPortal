import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoadingInterceptor } from 'src/app/core/services/loading.interceptor';
import { HttpRequestInterceptor } from 'src/app/helper/http-request.interceptor';


export const interceptorProviders =
    [
        { provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: HttpRequestInterceptor, multi: true },

    ];