import { ObserversModule } from '@angular/cdk/observers';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { AsyncPipe, DatePipe, DecimalPipe, NgFor, NgIf } from '@angular/common';
import { IProject } from 'src/app/core/interface/IProject'
import { ProjectService } from 'src/app/core/services/project/project.service';
import { Observable, tap, catchError, throwError, finalize,pipe, EMPTY, observable, map } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { AddProjectComponent } from './add-project/add-project.component';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { Router, RouterLink } from '@angular/router';
import { MaterialModule } from "src/app/material.module"
import { MatSnackBar } from '@angular/material/snack-bar';
import { ConfirmDialogComponent, ConfirmDialogModel } from 'src/app/common/confirm-dialog/confirm-dialog.component';
import { TableUtil } from 'src/app/core/Utiltz/table.util';
import { HeaderComponent } from 'src/app/layout/fragments/header/header.component';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css'],
  standalone: true,
  imports: [RouterLink, MaterialModule, DatePipe, DecimalPipe, NgFor, NgIf,AsyncPipe]

})

export class ProjectComponent implements OnInit, AfterViewInit {
  $projectsList: Observable<MatTableDataSource<IProject>>;

  projectsList1: IProject[] = [];

  // project:any=Observable<IProject>;
  project: Observable<IProject>;
  dataSource1 = new MatTableDataSource<IProject>();
  $dataSource: Observable<MatTableDataSource<IProject>>;


  //public $dataSource = new MatTableDataSource<Observable<IProject[]>>() ;
  loading = false;
  columnsToDisplay = ['id', 'projectName', 'projectCode', 'startDate', 'endDate', 'description', 'isActive', 'isDefault', 'details', 'delete'];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  formatDate: string[] = [
    'dd-MM-yyyy'

  ];
  constructor(private projectService: ProjectService, public dialog: MatDialog, public toasterService: ToasterService, public router: Router, private _snackBar: MatSnackBar) {
  }

  ngOnInit() {
    const componentTitle = "Projects";
    this.getData();
    // this.$dataSource =
    // this.projectService.GetProjectsList().pipe(
    //   map(things => {
    //     const datasource = this.dataSource1;
    //     datasource.data = things as IProject[]
    //     datasource.sort = this.sort, 
    //     datasource.paginator = this.paginator ;
    //     return datasource;
    //   }));
    //  this.projectService.GetProjectsList().subscribe(result=>{
    //     this.projectsList=result});

    //     this.projectService.GetProjectsList().pipe(
    //       tap(lessons => this.projectsList1 = lessons),
    //       catchError(err => {
    //           console.log("Error loading lessons", err);
    //           alert("Error loading lessons.");
    //           return throwError(err);

    //       }),
    //       finalize(() => this.loading = false)
    //   )
    //   .subscribe();


  }

  ngAfterViewInit(): void {
    // this.dataSource.sort = this.sort;
    // this.dataSource.paginator = this.paginator;
  }

  getData(){
    this.$dataSource =
    this.projectService.GetProjectsList().pipe(
      map(things => {
        const datasource = this.dataSource1;
        datasource.data = things as IProject[]
        datasource.sort = this.sort, 
        datasource.paginator = this.paginator ;
        return datasource;
      }));
  }
  // public getData = () => {
  //     this.projectService.GetProjectsList()
  //     .subscribe({
  //       next:res=>this.dataSource.data = res as IProject[],
  //       error(err){},
  //       complete(){}
  //     });
  //   }
    
  public customSort = (event) => {
    console.log(event);
  }

  public doFilter = (value: string) => {
    this.$dataSource.pipe(map(x=>x.filter = value.trim().toLocaleLowerCase()));
  }

  public redirectToDetails = (id: string) => {
    this.router.navigate(['/project', id]);
  }
  public redirectToUpdate = (id: string) => {

  }

  public confirmDialog = (id: number) => {
    const message = `Are you sure you want to delete this?`;
    const dialogData = new ConfirmDialogModel("Confirm Action", message);
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });
    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.projectService._deleteProject(id).subscribe(result => {
          if (result) {
           this.getData();

          }

        });
        this.showSnackbarCssStyles("Project: " + id + " Updated !", "Done", 2000);
      }
    });
  }

  // public redirectToDelete = (id: number) => {
  //   alert(id);
  //   this.projectService._deleteProject(id).subscribe(result => {
  //     if (result ) {
  //       this.getData();

  //     }

  //   });

  //   //this._sanckBar.open("Project: "+id+" Updated !","Edit Project",{duration:3000});
  //   this.showSnackbarCssStyles("Project: " + id + " Updated !", "Done", 2000);
  // }

  showSnackbarCssStyles(content, action, duration) {
    let sb = this._snackBar.open(content, action, {
      duration: duration,
      panelClass: ["custom-style"],
      verticalPosition: "top",
      horizontalPosition: "center"
    });
    sb.onAction().subscribe(() => {
      sb.dismiss();
    });
  }

  public openAddProjectDialoge() {
    const dialogRef = this.dialog.open(AddProjectComponent, {
      data: { project: this.project }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result === 1) {

        this.showSnackbarCssStyles("Project Created Succesfully", "Done", 2000);
        //this.toasterService.showToasterMessage('success', 'Well done!', 'Add Project', 3000);
        this.getData();
      }
    });
  }
  exportTable() {
    TableUtil.exportTableToExcel("tblProjectLists", "Projects");
  }


}
