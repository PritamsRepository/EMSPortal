import { Routes } from "@angular/router";
import { ProjectComponent } from "./project.component";
import { ProjectDetailComponent } from "./project-detail/project-detail.component";
import { ProjectdetailguirdGuard } from "./projectdetailguird.guard"

export const PROJECT_ROUTES: Routes = [
  { path: '', component: ProjectComponent },
  {
      path: ':id',
      canActivate: [ProjectdetailguirdGuard],
      component: ProjectDetailComponent
  }
];