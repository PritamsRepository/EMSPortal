import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Observable, tap, catchError, throwError, finalize,of, startWith, debounceTime, distinctUntilChanged, switchMap, map  } from 'rxjs';
import { IProject, IProjectFormGroup } from 'src/app/core/interface/IProject';
import { IDropDownKeyValue } from 'src/app/core/interface/IDropdownKeyValue';
import { ProjectService } from 'src/app/core/services/project/project.service';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { ISelectListItem } from 'src/app/core/interface/ISelectListItem';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']

})
export class AddProjectComponent implements OnInit {
  projectData: IProject;
  projectForm: IProjectFormGroup;
  dropdownYesNoList: IDropDownKeyValue[] = [];
  projectManager:ISelectListItem[]=[];
  filteredOptions: Observable<any[]>;
  myControl = new FormControl();
  error: string = "";


  constructor(public dialogRef: MatDialogRef<AddProjectComponent>,
    @Inject(MAT_DIALOG_DATA) public data: IProject,
    public projectService: ProjectService, private formBuilder: FormBuilder, public toaster: ToasterService) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(
        startWith(''),
        debounceTime(400),
        distinctUntilChanged(),
        switchMap(val => {
              return this.filter(val || '')
         }) 
      )

      
    }

  ngOnInit() {
    this.projectForm = this.formBuilder.group({
      id: [""],
      projectName: [""],
      projectCode: [""],
      description: [""],
      isActive: [""],
      isDefault: [""],
      startDate: [""],
      endDate: [""],
      autoAssign: [""],
      pmMid:[""],

    }) as IProjectFormGroup; // make sure to double-check this list with the interface  

    this.projectService._getDropdownYesNoList().subscribe({
      next: data => {
        this.dropdownYesNoList = data;
      },
      error: err => this.error = err.errorMessage
    });

  }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);
  getErrorMessage() {
    return this.formControl.hasError('required') ? '*' :
      this.formControl.hasError('email') ? '*Invalid Email' :
        '';
  }
  submit() {
    // empty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.projectData = this.data;
    console.log(this.projectData);
    this.projectService.addNewProject(this.projectData).subscribe();

    this.toaster.showToasterMessage('success', 'Well done!', 'This is a success alert', 3000);
  }



  getData(key:string) {
    return this.projectManager.find(x=>x.name==key) ?
      of(this.projectManager) :
      this.projectService._getProjectManagerList(key).pipe(tap(data => this.projectManager = data))
  }

  filter(val: string): Observable<any[]> {
    // call the service which makes the http-request
    return this.getData(val)
     .pipe(
       map(response => response.filter(option => { 
         return option.name.toLowerCase().indexOf(val.toLowerCase()) === 0
       }))
     )
   } 
}

