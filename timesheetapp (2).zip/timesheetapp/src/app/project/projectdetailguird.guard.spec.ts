import { TestBed } from '@angular/core/testing';

import { ProjectdetailguirdGuard } from './projectdetailguird.guard';

describe('ProjectdetailguirdGuard', () => {
  let guard: ProjectdetailguirdGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ProjectdetailguirdGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
