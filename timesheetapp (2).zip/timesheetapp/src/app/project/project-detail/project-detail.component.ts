import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { MaterialModule } from "src/app/material.module"
import { NgIf, LowerCasePipe, CurrencyPipe, JsonPipe, NgForOf, NgFor } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ProjectService } from 'src/app/core/services/project/project.service';
import { IProject, IProjectFormGroup } from 'src/app/core/interface/IProject';
import { IDropDownKeyValue } from 'src/app/core/interface/IDropdownKeyValue';
import { Observable, tap, catchError, throwError, finalize, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { FormsModule, FormBuilder, FormArray, FormGroup, ReactiveFormsModule, FormControl, Validators } from '@angular/forms'
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FactoryTarget } from '@angular/compiler';
import { ISelectListItem } from 'src/app/core/interface/ISelectListItem';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.css'],
  standalone: true,
  imports: [RouterLink, MaterialModule, FlexLayoutModule, FormsModule, NgIf, ReactiveFormsModule, NgForOf, NgFor,CommonModule]
})
export class ProjectDetailComponent implements OnInit {
  projectId: number;
  project: IProject;
  projectForm: IProjectFormGroup;
  dropdownYesNoList: IDropDownKeyValue[] = [];
  error: string = "";
  projectManager: ISelectListItem[] = [];
  filteredOptions: Observable<any[]>;
  myControl = new FormControl();
  constructor(private route: ActivatedRoute,
    private router: Router, private _projectService: ProjectService, private formBuilder: FormBuilder, public toaster: ToasterService, private _sanckBar: MatSnackBar) {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(val => {
        return this.filter(val || '')
      })
    )
  }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    // if (id) {
    // this._projectService.GetProjectById(id).subscribe(data: any[]);
    // const data= JSON.stringify(this.getData(id));
    // console.log(data);
    this.projectForm = this.formBuilder.group({

      id: [""],
      projectName: [""],
      projectCode: [""],
      description: [""],
      isActive: [""],
      isDefault: [""],
      startDate: [""],
      endDate: [""],
      autoAssign: [""],
      pmMid: [""],

    }) as IProjectFormGroup;

    this._projectService.GetProjectById(id).pipe().subscribe((res: any) => {
      this.projectId = res.id;
      this.projectForm.patchValue({
        id: res.id,
        projectName: res.projectName,
        projectCode: res.projectCode,
        description: res.description,
        isDefault: res.isDefault,
        isActive: res.isActive,
        startDate: res.startDate,
        endDate: res.endDate,
        autoAssign: res.autoAssign,
        pmMid:res.pmMid

      });

    });
    this._projectService._getDropdownYesNoList().subscribe({
      next: data => {
        this.dropdownYesNoList = data;
      },
      error: err => this.error = err.errorMessage
    });

  }

  public generateDataForFormGroup(data) {

    return this.formBuilder.group({

      id: this.formBuilder.control({ value: data.id, disabled: false }),
      projectName: this.formBuilder.control({ value: data.projectName, disabled: false }),
      projectCode: this.formBuilder.control({ value: data.projectCode, disabled: false }),
      description: this.formBuilder.control({ value: data.description, disabled: false }),
      isActive: this.formBuilder.control({ value: data.isActive, disabled: false }),
      isDefault: this.formBuilder.control({ value: data.isDefault, disabled: false }),
      startDate: this.formBuilder.control({ value: data.startDate, disabled: false }),
      endDate: this.formBuilder.control({ value: data.startDate, disabled: false }),
      autoAssign: this.formBuilder.control({ value: data.id, disabled: false }),
      pmMid: this.formBuilder.control({ value: data.pmMid, disabled: false })

    }) as IProjectFormGroup;
  }

  public getData = (id: number) => {
    this._projectService.GetProjectById(id)
      .subscribe(res => {
        this.project = res as IProject;
      });
    }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  EditProject(model: any, isValid: boolean, e: any) {
    // e.preventDefault();
    const data = model as IProject;
    const id = data.id;
    if (id) {

      this._projectService._editProject(id, model);
      this.router.navigate(['/main-shell/project']);
      //this._sanckBar.open("Project: "+id+" Updated !","Edit Project",{duration:3000});
      this.showSnackbarCssStyles("Project: " + id + " Updated !", "Done", 2000);
      //this.toaster.showToasterMessage('success', 'Well done!', 'This is a success alert',3000);

    }
  }
  showSnackbarCssStyles(content, action, duration) {
    let sb = this._sanckBar.open(content, action, {
      duration: duration,
      panelClass: ["custom-style"],
      verticalPosition: "top",
      horizontalPosition: "center"
    });
    sb.onAction().subscribe(() => {
      sb.dismiss();
    });
  }

  getErrorMessage() {
    return this.formControl.hasError('required') ? '*Required' :
      this.formControl.hasError('email') ? '*Invalid Email' :
        '';
  }

  onCancelClick(): void {
    this.router.navigate(['/main-shell/project']);
  }

  getDataForManager(key: string) {
    return this.projectManager.find(x => x.name == key) ?
      of(this.projectManager) :
      this._projectService._getProjectManagerList(key).pipe(tap(data => this.projectManager = data))
  }

  filter(val: string): Observable<any[]> {
    // call the service which makes the http-request
    return this.getDataForManager(val)
      .pipe(
        map(response => response.filter(option => {
          return option.name.toLowerCase().indexOf(val.toLowerCase()) === 0
        }))
      )
  }

}
