import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router'
import { StorageService } from 'src/app/core/services/storage.service';

const MINUTES_UNITL_AUTO_LOGOUT = 2 // in mins
const CHECK_INTERVAL = 60000 // in ms
const EXPIRY_TIME = 'expiry_Time';
@Injectable()
export class AutoLogoutService {

  public getExpiryTime(): any {
    var expiryTime = window.sessionStorage.getItem(EXPIRY_TIME);
    if (expiryTime) {
      return new Date(expiryTime);
    }
    return new Date();
  }
  public setLastAction(lastAction: number) {
    localStorage.setItem(EXPIRY_TIME, this.getExpiryTime().toString());
  }

  constructor(private router: Router, private storageService: StorageService, private _dialog:MatDialog) {
    console.log('object created');
    this.check();
    this.initListener();
    this.initInterval();
  }

  initListener() {
    document.body.addEventListener('click', () => this.reset());
    document.body.addEventListener('mouseover', () => this.reset());
    document.body.addEventListener('mouseout', () => this.reset());
    document.body.addEventListener('keydown', () => this.reset());
    document.body.addEventListener('keyup', () => this.reset());
    document.body.addEventListener('keypress', () => this.reset());
  }

  reset() {
    this.getExpiryTime();
  }

  initInterval() {
    setInterval(() => {
      this.check();
    }, CHECK_INTERVAL);
  }

  check() {
    const now = Date.now();
    const timeleft = this.getExpiryTime();
    //const timeleft = this.getExpiryTime();
 
    const diff = timeleft - now;
  
    const isTimeout = diff <= 0;

    if (isTimeout) {
      this.storageService.clean();
      this._dialog.closeAll();
      // localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
}