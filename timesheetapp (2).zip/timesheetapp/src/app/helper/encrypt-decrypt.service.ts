import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EncryptDecryptService {

  private secretKey = CryptoJS.enc.Utf8.parse(environment.SECRET_KEY);
  private secretKeyIV = CryptoJS.enc.Utf8.parse(environment.SECRET_KEY_IV);
  constructor() { }

  encryptUsingAES256(text): any {

    var encryptedValue = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(text), this.secretKey, {
      keySize: 128 / 8,
      iv: this.secretKeyIV,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return encryptedValue.toString();
  }
  decryptUsingAES256(text): any {

    var decryptedValue = CryptoJS.AES.decrypt(text, this.secretKey, {
      keySize: 128 / 8,
      iv: this.secretKeyIV,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return decryptedValue.toString();
  }
}