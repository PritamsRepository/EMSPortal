export interface ISelectListItem{
    id:string,
    name:string
}