import { AbstractControl, FormGroup } from "@angular/forms";

export interface IRole {
    roleId?: number,
    roleName: string,
    roleCode: string,
    isAdmin: boolean,
    isActive: boolean
}

// 
export interface IRoleFormGroup extends FormGroup {
    controls: {
        roleId: AbstractControl,
        roleName: AbstractControl,
        roleCode: AbstractControl,
        isAdmin: AbstractControl,
        isActive: AbstractControl,
    }
}

