import { AbstractControl, FormGroup } from "@angular/forms";
  
export interface IProject{
    id?:number,
    projectName:string,
    projectCode?:string,
    description?:string,
    isActive?:number,
    isDefault?:number,
    startDate?:Date,
    endDate?:Date,
    autoAssign?:number,
    pmMid?:string,



}

export interface IProjectFormGroup extends FormGroup {
  //  value: IProject; // the general interface we've used in the rest of our application
  
    // We need to add these manually again, same fields as IProject.
    
    controls: {
      id: AbstractControl; 
      projectName: AbstractControl; 
      projectCode: AbstractControl; 
      description: AbstractControl; 
      isActive: AbstractControl; 
      isDefault: AbstractControl;
      startDate:AbstractControl;
      endDate:AbstractControl;
      autoAssign:AbstractControl;
      pmMid:AbstractControl;
    };
  }