export interface IUser{
    
}