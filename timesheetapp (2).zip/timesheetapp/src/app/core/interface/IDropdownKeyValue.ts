export  interface IDropDownKeyValue{
    id:number,
    name:string
}