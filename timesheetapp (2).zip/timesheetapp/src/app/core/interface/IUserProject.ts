import { AbstractControl, FormGroup } from "@angular/forms";

export interface IUserProject {
    id: number,
    projectId: number,
    projectName: number,
    personName: string,
    userMid: string,
    startDate: Date,
    endDate: Date
}

export interface IUserProjectFormGroup extends FormGroup {

    // value: IUserProject,
    controls: {
        id: AbstractControl;
        projectId: AbstractControl;
        userMid: AbstractControl;
        startDate: AbstractControl;
        endDate: AbstractControl;
    };
}