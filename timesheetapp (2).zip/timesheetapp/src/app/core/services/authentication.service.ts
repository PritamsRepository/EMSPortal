import { OnInit, Injectable } from '@angular/core';
import { catchError, map, Observable, throwError, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { ILogin } from 'src/app/core/interface/ILogin';
import { HttpclientService } from 'src/app/core/services/HttpClientServices';
import { StorageService } from 'src/app/core/services/storage.service';
import { JsonPipe } from '@angular/common';
import { RESOURCE_CACHE_PROVIDER } from '@angular/platform-browser-dynamic';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  header: any;
  errorMessage: any;


  constructor(private _httpService: HttpclientService, private storageService: StorageService) {
    const headerSettings: { [auth_token: string]: string | string[]; } = {};
    this.header = new HttpHeaders(headerSettings);



  }

  ngOnInit() {
  }


  login(login: ILogin): Observable<any> {
    const body = JSON.stringify(login);
    return this._httpService.post('Authentication/Login', login).pipe(
      tap(user => {
        if (user) {

        }
        return user;
      }),
      catchError(this.handleError))
  }

  logout(): Observable<any> {

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,
    });
    
    return this._httpService.postWithHeaders('Authentication/SignOut', headers).pipe(
      tap(data => {
        return data;
      }),
      catchError(this.handleError))
  }

  private handleError(err): Observable<never> {
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occurred: ${err}`;
    } else {
      errorMessage = `Backend returned code ${err.status}: ${err.errorMessage}`;
    }
    console.error(errorMessage);
    return throwError(() => (new Error(errorMessage)));
  }
}
