import { Injectable } from '@angular/core';

const USER_KEY = 'currentUser';
const TOKEN_KEY='jwt_token';
const EXPIRYTIME='expiry_Time'

@Injectable({
  providedIn: 'root'
})


export class StorageService {
  constructor() {}

  clean(): void {
   
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.removeItem(TOKEN_KEY);  
    window.sessionStorage.removeItem(EXPIRYTIME);
    window.sessionStorage.clear();
  }

  public saveUser(user: any,token:any): void {
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.removeItem(EXPIRYTIME);
    window.sessionStorage.setItem(USER_KEY, JSON.stringify(user));
    window.sessionStorage.setItem(TOKEN_KEY, JSON.stringify(token));
    window.sessionStorage.setItem(EXPIRYTIME,user.expiryTime)

  }

  public getUser(): any {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return JSON.parse(user);
    }

    return {};
  }

  public isLoggedIn(): boolean {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return true;
    }

    return false;
  }
}