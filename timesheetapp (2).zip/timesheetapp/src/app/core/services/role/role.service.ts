import { Injectable } from '@angular/core';
import { IRole } from '../../interface/IRole';
import { Observable } from 'rxjs';
import { HttpclientService } from '../HttpClientServices';
import { ToasterService } from '../toaster/toaster.service';
import { HttpClient, HttpHeaders, HttpResponse, HttpErrorResponse, HttpParams } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RoleService {
  headers: any;
  errorMessage: any;
  roles: Observable<IRole[]>;
  dialogData: any;

  constructor(private _httpService: HttpclientService, private _toaster: ToasterService) {

    //  const headerSettings: { [auth_token: string]: string | string[]; } = {};
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,
    });

  }

  GetAllRoles(): Observable<any> {

    // const headers = new HttpHeaders({
    //   'Content-Type': 'application/json',
    //   'Accept': 'application/json',
    //   Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,
    // });

    const result = this._httpService.getList<IRole[]>('Roles/GetAllRoles', this.headers).pipe();
    return result;
  }

  GetRoleById(id: number): Observable<any> {

    const params = new HttpParams().set("id", id);
    const result = this._httpService.getById<IRole>('Roles/GetRoleById/', this.headers, params).pipe();
    return result;
  }
  addRole(role: IRole): Observable<any> {
    var result = this._httpService.postwithbody('Roles/Add', role, this.headers).pipe();
    return result;

  }
}
