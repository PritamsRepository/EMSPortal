import { Injectable, OnInit } from '@angular/core';
import { HttpclientService } from 'src/app/core/services/HttpClientServices';
import { IProject } from 'src/app/core/interface/IProject';
import { IDropDownKeyValue } from 'src/app/core/interface/IDropdownKeyValue';
import { HttpHeaders, HttpClient, HttpResponse, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { catchError, map, Observable, throwError, tap, of } from 'rxjs';
import { Interpolation, ParsedProperty } from '@angular/compiler';
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { JsonPipe } from '@angular/common';
import { ISelectListItem } from '../../interface/ISelectListItem';
import { IUserProject } from '../../interface/IUserProject';


@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  header: any;
  errorMessage: any;
  projects: Observable<IProject[]>;
  dialogData: any;



  //Constructor Declaration
  constructor(private _httpService: HttpclientService, public _toasterService: ToasterService) {
    const headerSettings: { [auth_token: string]: string | string[]; } = {};
    this.header = new HttpHeaders(headerSettings);

  }

  ngOnInIt() {

  }
  //  GetRequestorApproverList(mid: string):Observable<any>{

  //   console.log(sessionStorage.getItem('token'));

  //   const headers = new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Accept': 'application/json',
  //       Authorization: `Bearer ${sessionStorage.getItem('token')}`,
  //     });


  //   return this.httpAPIUrl.get<any>(this.APIUrl + '/Requester/GetRequestorApproverList?Mid='+mid,{headers:headers})
  //   .pipe(map((data: any) => data), 

  //         catchError(error => { return throwError('Its a Trap!')})
  //   );
  // }

  GetProjectsList(): Observable<IProject[]> {

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,
    });

    const result = this._httpService.getList<IProject>('Projects/GetProjects', headers)
      .pipe(
        tap(data => JSON.stringify(data))
      );
    return result;
  }

  GetProjectById(id: number): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,
    });

    const params = new HttpParams().set("id", id);
    const result = this._httpService.getById<IProject>('Projects/GetProjectById/', headers, params).pipe();

    return result;
  }

  // private handleError<T>(operation = 'operation', result?: T) {
  //   return (error: any): Observable<T> => {

  //     // TODO: send the error to remote logging infrastructure
  //     console.error(error); // log to console instead

  //     // TODO: better job of transforming error for user consumption
  //    // this.log(`${operation} failed: ${error.message}`);

  //     // Let the app keep running by returning an empty result.
  //     return of(result as T);
  //   };
  // }

  addNewProject(project: IProject): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });

    // this._httpService.postwithbody('Projects/Add', project, headers).subscribe({
    //   complete: () => {
    //     this.dialogData = project;
    //     this._toasterService.showToasterMessage('success', 'Well done!', 'Add Project', 3000);
    //   },
    //   error: () => {
    //     (err: HttpErrorResponse) => {
    //       this._toasterService.showToasterMessage('error', 'Error occurred. Details: ' + err.name + ' ' + err.message, 'Add Project  Error', 8000);

    //     }

    //   }
    // });

    var result = this._httpService.postwithbody('Projects/Add', project, headers).pipe();
    return result;

  }

  _editProject(id: number, project: any) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });
    console.log('service');
    console.log(id);
    console.log(project);
    const params = new HttpParams().set("id", id);
    this._httpService.postwithbodyWithId('Projects/EditProject/', project, headers, params).subscribe({
      complete: () => {
        this._toasterService.showToasterMessage("success", "Project Updated Succesfull", "Edit Project", 2000);
      },
      error: () => {
        (err: HttpErrorResponse) => {
          this._toasterService.showToasterMessage("error", "Error Occurred:" + err.name + " " + err.message, "Edit Project", 2000);
        }
      }

    });
  }
  _deleteProject(id: number): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });

    const params = new HttpParams().set("id", id);
    // var result= this._httpService.postById('Projects/DeleteProjectById', headers, params).subscribe({
    //   complete: () => {
    //     this._toasterService.showToasterMessage("success", "Project Deleted Succesfull", "Delete Project", 2000);
    //     return true;
    //   },
    //   error: () => {
    //     (err: HttpErrorResponse) => {
    //       this._toasterService.showToasterMessage("error", "Error Occurred:" + err.name + " " + err.message, "Edit Project", 2000);
    //     }
    //     return false;
    //   }

    // });
    var result = this._httpService.postById('Projects/DeleteProjectById', headers, params).pipe();

    return result;


  }

  _getDropdownYesNoList(): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });
    var result = this._httpService.getList<IDropDownKeyValue>('Projects/GetDropdownYesNo', headers).pipe();
    return result;
  }

  _getProjectManagerList(key: string): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });
    const params = new HttpParams().set("key", key);
    var result = this._httpService.getById<ISelectListItem>('Projects/GetUserListByKey', headers, params).pipe();
    return result;
  }
  _getAllUserAssignedProject():Observable<IUserProject[]>{
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      Authorization: `Bearer ${window.sessionStorage.getItem('token')}`,

    });
 
    var result=this._httpService.getList<IUserProject>('Projects/GetAllAssignedUserProjects',headers).pipe(
      tap(data=>JSON.stringify(data)));
      return result;
    
  }
}



