import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ILogin } from 'src/app/core/interface/ILogin';
import { AuthenticationService } from 'src/app/core/services/authentication.service';
import { throwError, of, catchError, map, Observable, tap } from 'rxjs';
import {StorageService} from 'src/app/core/services/storage.service';
import { EncryptDecryptService } from '../helper/encrypt-decrypt.service';
import { ToasterService } from '../core/services/toaster/toaster.service';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit, ILogin {
  loginForm: any = FormGroup;
  username: any;
  password: any;
  submitted = false;
  error: string | null;

  isLoggedIn = false;
  isLoginFailed = false;

  roles: string[] = [];

  get f() { return this.loginForm.controls; }
  /**
   *
   */
  constructor(private fb: FormBuilder, private router: Router, private authenticationService: AuthenticationService, public storage:StorageService,private security:EncryptDecryptService, private toaster:ToasterService) {

  }

  formControl = new FormControl('', [
    Validators.required,
    Validators.email
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? '*Required' :
      this.formControl.hasError('email') ? '*Invalid Email' :
        '';
  }

  ngOnInit(): void {
    if (this.storage.isLoggedIn()) {
      this.isLoggedIn = true;
      //this.roles = this.storageService.getUser().roles;
    }

    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]

    })
  }
  onSubmit(): void {
    this.submitted = true;
    if (this.loginForm.valid && this.submitted) {

      this.username = ((document.getElementById("txtUserName") as HTMLInputElement).value);
      this.password = ((document.getElementById("txtPassword") as HTMLInputElement).value);
      console.log(this.security.encryptUsingAES256(this.username));
      console.log(this.security.encryptUsingAES256(this.password));

      const login = {} as ILogin;
      // login.username = this.username;
      // login.password = this.password;
      login.username = this.security.encryptUsingAES256(this.username);
      login.password = this.security.encryptUsingAES256(this.password);

      this.authenticationService.login(login).subscribe({
        next: data => {

          this.storage.saveUser(data,data.token);
          this.isLoginFailed = false;
          this.isLoggedIn = true;

          sessionStorage.setItem('currentUser', JSON.stringify(data));
          sessionStorage.setItem('token', data.token);
          // this.isLoggedIn = true;
          // this.isLoginFailed = false;
          this.router.navigate(['/main-shell']);

        },
        error: err => {
          this.isLoggedIn = false;
          this.isLoginFailed = true;
          this.error = "Invalid UserId and Password. Login Failed ";
         // this.error = err;
          this.toaster.showToasterMessage('error', 'Authentication Error', this.error, 3000);
        }

      });

      this.submitEM.emit(this.loginForm.value);
    }
  }

  @Output() submitEM = new EventEmitter();
}