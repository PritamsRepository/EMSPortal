import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { AuthenticationService } from '../core/services/authentication.service';
import { StorageService } from '../core/services/storage.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  /**
   *
   */
  constructor(private router: Router, private _authentication: AuthenticationService, private storageService: StorageService) {

    
  }
  ngOnInit(): void {
    this._authentication.logout().subscribe({
      next: res => {
        this.storageService.clean();
        //window.location.reload();
        this.router.navigate(['login']);
      },
      error(err) { console.log(err); }
    });

  }
}