import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProjectComponent } from './project/project.component';
import { HolidayComponent } from './holiday/holiday.component';
import { TimesheetComponent } from './timesheet/timesheet.component';
import { MainShellComponent } from './layout/fragments/main-shell/main-shell.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthenticationGuard } from 'src/app/helper/authentication.guard';
import { RoleComponent } from './admin/role/role.component';
import { UserProjectComponent } from './admin/user-project/user-project.component';

const routes: Routes = [
  {
    path: '', component: LoginComponent
  },
  { path: 'login', component: LoginComponent },
  {
    path: 'main-shell', component: MainShellComponent, data: { title: "Home" },
    children: [
      {
        path: '', redirectTo:'home', pathMatch: 'full', data: { title: "Home" }
      },
      // { path: '', component: HomeComponent, data: { title: "Home" } },
      {
        path: 'home', component: HomeComponent, data: { title: "Home" }, canActivate: [AuthenticationGuard]
      },
      {
        path: 'project',
        loadChildren: () => import('./project/project.routes').then(r => r.PROJECT_ROUTES),
        data: { title: "Project" }, canActivate: [AuthenticationGuard]
      },
      { path: 'holiday', component: HolidayComponent, data: { title: "Holiday" } },
      { path: 'timesheet', component: TimesheetComponent, data: { title: "Timesheet" } },
      { path: 'role', component: RoleComponent, data: { title: "Role" } },
      { path: 'user-project', component: UserProjectComponent, data: { title: "User Project" } }

    ]
  },
  { path: 'logout', component: LogoutComponent }
  //,
  //   { path: '', component: HomeComponent },
  // { path: 'home', component: HomeComponent },
  // { path: 'project', component: ProjectComponent },
  // { path: 'holiday', component: HolidayComponent },
  // { path: 'timesheet', component: TimesheetComponent  }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
