import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core'; 
import { Observable } from 'rxjs';
import { IMenu } from 'src/app/core/interface/IMenu';
import { HttpclientService } from 'src/app/core/services/HttpClientServices'

 
@Component({
  selector: 'app-side-navbar',
  templateUrl: './side-navbar.component.html',
  styleUrls: ['./side-navbar.component.css']
})
export class SideNavbarComponent implements OnInit {
  private _jsonURL = 'assets/SampleJson.json';
   menuList: Observable<IMenu[]>;
  constructor(private httpService: HttpClient) { }
  
  ngOnInit() {
    this.menuList = this.httpService.get<IMenu[]>("/assets/menu.json")
  }
}
