import { Component, OnInit } from '@angular/core';
import{AutoLogoutComponent} from 'src/app/helper/auto-logout.component';
import {AutoLogoutService} from 'src/app/helper/auto-logout.service';

@Component({
  selector: 'app-main-shell',
  templateUrl: './main-shell.component.html',
  styleUrls: ['./main-shell.component.css'],
  providers: [AutoLogoutService]

})
export class MainShellComponent implements OnInit {

  constructor( private service:AutoLogoutService) { }

  ngOnInit() {
  }

}
