import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProjectComponent } from './project/project.component';
import { TimesheetComponent } from './timesheet/timesheet.component';
import { HolidayComponent } from './holiday/holiday.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { FragmentsModule } from './layout/fragments/fragments.module';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddProjectComponent } from './project/add-project/add-project.component';
import { ToasterComponent } from 'src/app/core/services/toaster/toaster.component';
import{ToasterContainerComponent} from 'src/app/core/services/toaster/toaster-container.component'
import { ToasterService } from 'src/app/core/services/toaster/toaster.service';
import { LoaderComponent } from './common/loader/loader.component';
import{HTTP_INTERCEPTORS} from '@angular/common/http';
import{LoadingInterceptor} from 'src/app/core/services/loading.interceptor'
import{FlexLayoutModule} from '@angular/flex-layout';
import { ProjectDetailComponent } from './project/project-detail/project-detail.component';
import { ConfirmDialogComponent } from './common/confirm-dialog/confirm-dialog.component';
import { LogoutComponent } from './logout/logout.component';
import {interceptorProviders} from './interceptorProviders';
import{AutoLogoutComponent} from './helper/auto-logout.component';
import { RoleComponent } from './admin/role/role.component';
import { UserComponent } from './admin/user/user.component';
import { AddRoleComponent } from './admin/role/add-role/add-role.component';
import { UserProjectComponent } from './admin/user-project/user-project.component';
import { AddUserProjectComponent } from './admin/user-project/add-user-project/add-user-project.component';


const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    //ProjectComponent,
    TimesheetComponent,
    HolidayComponent,
    LoginComponent,
    AddProjectComponent,
    ToasterComponent,
    ToasterContainerComponent,
    LoaderComponent,
    ConfirmDialogComponent,
    LogoutComponent,
    AutoLogoutComponent,
    RoleComponent,
    UserComponent,
    AddRoleComponent,
    UserProjectComponent,
    AddUserProjectComponent
   // ProjectDetailComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FragmentsModule,
    RouterModule.forRoot(routes),
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule

  ],
  providers: [interceptorProviders],
  // providers: [{
  //   provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true
  // }],
  bootstrap: [AppComponent]
})

export class AppModule { }
