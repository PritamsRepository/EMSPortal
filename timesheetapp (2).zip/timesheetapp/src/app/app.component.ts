import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { Subscription } from 'rxjs';
import { StorageService } from './core/services/storage.service';
import { AuthenticationService } from './core/services/authentication.service';
import { EventBusService } from './shared/event-bus.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'TimeSheetApp';
  private roles: string[] = [];
  isLoggedIn = false;
  username?: string;

  eventBusSub?: Subscription;
  constructor(private storageService: StorageService,
    private authenticationService: AuthenticationService,
    private eventBusService: EventBusService,
    private router: Router) {


  }
  ngOnInit(): void {
    this.isLoggedIn = this.storageService.isLoggedIn();
    if (this.isLoggedIn) {
      const user = this.storageService.getUser();
      this.username = user.username;
    }

    this.eventBusSub = this.eventBusService.on('logout', () => {
      this.logout();
    });
  }
  logout(): void {
    this.authenticationService.logout().subscribe({
      next: res => {
        this.storageService.clean();
        this.router.navigate(['login']);
      },
      error(err) {
        console.log(err);
      }
    });
  }
}