IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'NT Service\SqlServerExtension')
CREATE LOGIN [NT Service\SqlServerExtension] FROM WINDOWS
GO
CREATE USER [NT Service\SqlServerExtension] FOR LOGIN [NT Service\SqlServerExtension]
GO
