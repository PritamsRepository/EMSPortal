CREATE USER [mpreporting] FOR LOGIN [mpreporting]
GO
