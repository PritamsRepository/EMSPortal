IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'MYL\jrgaines')
CREATE LOGIN [MYL\jrgaines] FROM WINDOWS
GO
CREATE USER [MYL\jrgaines] FOR LOGIN [MYL\jrgaines] WITH DEFAULT_SCHEMA=[MYL\jrgaines]
GO
REVOKE CONNECT TO [MYL\jrgaines]
