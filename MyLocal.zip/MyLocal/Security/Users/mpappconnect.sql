CREATE USER [mpappconnect] FOR LOGIN [mpappconnect]
GO
