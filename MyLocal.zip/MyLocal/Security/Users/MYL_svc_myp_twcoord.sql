IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'MYL\svc_myp_twcoord')
CREATE LOGIN [MYL\svc_myp_twcoord] FROM WINDOWS
GO
CREATE USER [MYL\svc_myp_twcoord] FOR LOGIN [MYL\svc_myp_twcoord] WITH DEFAULT_SCHEMA=[MYL\svc_myp_twcoord]
GO
REVOKE CONNECT TO [MYL\svc_myp_twcoord]
