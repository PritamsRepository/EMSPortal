IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'MYL\svc_MFG_MyPortfolio')
CREATE LOGIN [MYL\svc_MFG_MyPortfolio] FROM WINDOWS
GO
CREATE USER [MYL\svc_MFG_MyPortfolio] FOR LOGIN [MYL\svc_MFG_MyPortfolio] WITH DEFAULT_SCHEMA=[MYL\svc_MFG_MyPortfolio]
GO
REVOKE CONNECT TO [MYL\svc_MFG_MyPortfolio]
