CREATE SCHEMA [MA.Reporting]
AUTHORIZATION [dbo]
GO
GRANT EXECUTE ON SCHEMA:: [MA.Reporting] TO [mp_db_execute]
GO
GRANT EXECUTE ON SCHEMA:: [MA.Reporting] TO [mpreporting]
GO
