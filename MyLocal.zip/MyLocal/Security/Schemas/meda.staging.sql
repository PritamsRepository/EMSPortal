CREATE SCHEMA [meda.staging]
AUTHORIZATION [dbo]
GO
