CREATE SCHEMA [Core.Common.Filter]
AUTHORIZATION [dbo]
GO
