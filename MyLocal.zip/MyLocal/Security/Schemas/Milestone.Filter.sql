CREATE SCHEMA [Milestone.Filter]
AUTHORIZATION [dbo]
GO
