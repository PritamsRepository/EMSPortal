CREATE SCHEMA [MYL\svc_myp_twcoord]
AUTHORIZATION [MYL\svc_myp_twcoord]
GO
