CREATE SCHEMA [MYL\svc_MFG_MyPortfolio]
AUTHORIZATION [MYL\svc_MFG_MyPortfolio]
GO
