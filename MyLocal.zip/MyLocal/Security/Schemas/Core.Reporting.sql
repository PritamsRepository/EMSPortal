CREATE SCHEMA [Core.Reporting]
AUTHORIZATION [dbo]
GO
GRANT EXECUTE ON SCHEMA:: [Core.Reporting] TO [mp_db_execute]
GO
GRANT EXECUTE ON SCHEMA:: [Core.Reporting] TO [mpreporting]
GO
