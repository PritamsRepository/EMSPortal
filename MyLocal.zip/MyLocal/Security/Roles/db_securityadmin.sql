ALTER ROLE [db_securityadmin] ADD MEMBER [MYL\m104058]
GO
