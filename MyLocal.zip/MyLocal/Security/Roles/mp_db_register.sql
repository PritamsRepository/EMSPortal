CREATE ROLE [mp_db_register]
AUTHORIZATION [dbo]
GO
ALTER ROLE [mp_db_register] ADD MEMBER [mpregister]
GO
