ALTER ROLE [db_ddladmin] ADD MEMBER [mpappconnect]
GO
ALTER ROLE [db_ddladmin] ADD MEMBER [MYL\m104058]
GO
ALTER ROLE [db_ddladmin] ADD MEMBER [MYL\M104058_SADM]
GO
ALTER ROLE [db_ddladmin] ADD MEMBER [MYL\m104232]
GO
