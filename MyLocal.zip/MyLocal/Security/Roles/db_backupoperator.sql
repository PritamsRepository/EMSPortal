ALTER ROLE [db_backupoperator] ADD MEMBER [MYL\m104058]
GO
