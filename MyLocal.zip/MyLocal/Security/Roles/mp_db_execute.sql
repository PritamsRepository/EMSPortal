CREATE ROLE [mp_db_execute]
AUTHORIZATION [dbo]
GO
ALTER ROLE [mp_db_execute] ADD MEMBER [mpappconnect]
GO
ALTER ROLE [mp_db_execute] ADD MEMBER [mpreporting]
GO
ALTER ROLE [mp_db_execute] ADD MEMBER [MYL\m104058]
GO
GRANT EXECUTE TO [mp_db_execute]
