ALTER ROLE [db_datareader] ADD MEMBER [mpappconnect]
GO
ALTER ROLE [db_datareader] ADD MEMBER [mpregister]
GO
ALTER ROLE [db_datareader] ADD MEMBER [mpreporting]
GO
ALTER ROLE [db_datareader] ADD MEMBER [MYL\m104058]
GO
ALTER ROLE [db_datareader] ADD MEMBER [MYL\M104058_SADM]
GO
ALTER ROLE [db_datareader] ADD MEMBER [MYL\m104232]
GO
ALTER ROLE [db_datareader] ADD MEMBER [MYL\M565934_SADM]
GO
