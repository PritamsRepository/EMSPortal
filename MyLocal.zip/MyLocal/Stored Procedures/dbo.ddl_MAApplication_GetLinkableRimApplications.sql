SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MAApplication_GetLinkableRimApplications]
    @FormID INT,
    @CountryGroupID INT
AS
BEGIN TRY
    SELECT DISTINCT
           maa.MAApplicationID AS ID,
           'A' + CONVERT(NVARCHAR(20), maa.MAApplicationID) + ' - ' + sr.Category + ' - ' + maa.ProcedureNumber AS Name
    FROM rim.RimApplication maa
        JOIN rim.ApplicationLinkCountry lc
            ON lc.MAApplicationID = maa.MAApplicationID
        JOIN rim.ApplicationLinkStrength ls
            ON ls.MAApplicationID = maa.MAApplicationID
        JOIN dbo.tblSubmissionRoute sr
            ON sr.NAME = maa.SubmissionRoute
    WHERE lc.CountryGroupID = @CountryGroupID
          AND ls.FormID = @FormID
    ORDER BY maa.MAApplicationID;
END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
