SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[ProjectSummary_ParameterTranslation]
    (
      @FormFiltersList NVARCHAR(MAX) = NULL ,
      @CountryGroupFiltersList NVARCHAR(MAX) = NULL ,
      @CountryFiltersList NVARCHAR(MAX) = NULL ,
      @BBOTagFiltersList NVARCHAR(MAX) = NULL ,
      @ValidProjectTypeFiltersList NVARCHAR(MAX) = NULL ,
      @SubmissionYearFiltersList NVARCHAR(MAX) = NULL ,
      @ProjectLeadID INT = NULL ,
      @ValidWorkPlanID INT = NULL ,
      --@ValidTechOpsRatingID INT = NULL,
      @ValidTechOpsRatingFiltersList NVARCHAR(MAX) = NULL ,
      @ValidOpportunityTypeFiltersList NVARCHAR(MAX) = NULL ,
      @ProjectStatusID INT = NULL ,
      @UserId INT ,
      @FormFiltersInclusionID INT = NULL ,
      @CountryGroupFiltersInclusionID INT = NULL ,
      @CountryFiltersInclusionID INT = NULL ,
      @BBOTagFiltersInclusionID INT = NULL ,
      @ValidProjectTypeFiltersInclusionID INT = NULL ,
      @SubmissionYearFiltersInclusionID INT = NULL ,
      @ProjectLeadInclusionID INT = NULL ,
      @ValidWorkPlanInclusionID INT = NULL ,
      @ValidTechOpsRatingInclusionID INT = NULL ,
      @ValidOpportunityTypeFiltersInclusionID INT = NULL ,
      @ProjectStatusInclusionID INT = NULL ,
      @SiteCompanyGroups NVARCHAR(MAX) = NULL , -- Replace | with ,
      @SiteFiltersList NVARCHAR(MAX) = NULL ,
      @SiteNameFiltersInclusionID INT = NULL ,
      @ProductGroupID INT = NULL ,
      @ProjectTeamRole NVARCHAR(MAX) = NULL ,
      @ProjectTeamRoleInclusionID INT = NULL ,
      @TeamMembers NVARCHAR(MAX) = NULL ,
      @TeamMembersInclusionID INT = NULL ,
      @AlertTypes NVARCHAR(MAX) = NULL ,
      @AlertTypesInclusionID INT = NULL
    )
AS
    BEGIN
        DECLARE @CountryGroupFilters CountryGroupType
        DECLARE @CountryFilters CountryType
        DECLARE @BBOTagFilters BBOTagType
        DECLARE @ValidProjectTypeFilters ValidProjectTypeType
        DECLARE @SubmissionYearFilters TimeframeType
        DECLARE @ValidOpportunityTypeFilters ValidOpportunityTypeType
        DECLARE @ValidTechOpsRatingFilters ValidTechOpsRatingType
        DECLARE @FormFilters FormType
        DECLARE @SiteFilters IdType
        DECLARE @AlertFilters IdType
        DECLARE @TeamMemberFilters IdType
            
        DECLARE @CountryGroups NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @Countries NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @BBOTags NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @ProjectTypes NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @SubmissionYears NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @OpportunityTypes NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @Forms NVARCHAR(MAX) = 'All' , --Null lists should return 'All'
            @ProjectLead NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @ValidWorkPlan NVARCHAR(MAX) = 'All' ,--Null  should return 'All'
            @ValidTechOpsRating NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @ProjectStatus NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @User NVARCHAR(MAX) , --Coalesce with FullName and username
            @Sites NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @SiteNames NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @ProductGroup NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @ProjectTeamRoleName NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @TeamMemberNames NVARCHAR(MAX) = 'All' , --Null should return 'All'
            @Alerts NVARCHAR(MAX) = 'All' --Null should return 'All'
			  
        IF LEN(@CountryGroupFiltersList) > 0
            BEGIN
                INSERT  @CountryGroupFilters
                        ( CountryGroupID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList)
		
                SET @CountryGroups = ( SELECT   STUFF(( SELECT DISTINCT
                                                              ', ' + Name
                                                        FROM  dbo.tblCountryGroup
                                                        WHERE CountryGroupID IN (
                                                              SELECT
                                                              CountryGroupID
                                                              FROM
                                                              @CountryGroupFilters )
                                                        ORDER BY ', ' + Name
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                     )
            END
            
        IF LEN(@CountryFiltersList) > 0
            BEGIN
                INSERT  @CountryFilters
                        ( CountryID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@CountryFiltersList)
		
                SET @Countries = ( SELECT   STUFF(( SELECT DISTINCT
                                                            ', ' + Name
                                                    FROM    dbo.tblCountry
                                                    WHERE   CountryID IN (
                                                            SELECT
                                                              CountryID
                                                            FROM
                                                              @CountryFilters )
                                                    ORDER BY ', ' + Name
                                                  FOR
                                                    XML PATH('')
                                                  ), 1, 2, '')
                                 )
            END  

        IF LEN(@BBOTagFiltersList) > 0
            BEGIN
                INSERT  @BBOTagFilters
                        ( BBOTagID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@BBOTagFiltersList)
                    
                SET @BBOTags = ( SELECT STUFF(( SELECT DISTINCT
                                                        ', ' + Tag
                                                FROM    dbo.tblValidBBOTag
                                                WHERE   ValidBBOTagID IN (
                                                        SELECT
                                                              BBOTagID
                                                        FROM  @BBOTagFilters )
                                                ORDER BY ', ' + Tag
                                              FOR
                                                XML PATH('')
                                              ), 1, 2, '')
                               )
            END

        IF LEN(@ValidProjectTypeFiltersList) > 0
            BEGIN
                INSERT  @ValidProjectTypeFilters
                        ( ValidProjectTypeID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@ValidProjectTypeFiltersList)

                SET @ProjectTypes = ( SELECT    STUFF(( SELECT DISTINCT
                                                              ', ' + Name
                                                        FROM  dbo.tblValidProjectType
                                                        WHERE ValidProjectTypeID IN (
                                                              SELECT
                                                              ValidProjectTypeID
                                                              FROM
                                                              @ValidProjectTypeFilters )
                                                        ORDER BY ', ' + Name
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                    )
            END
		
        IF LEN(@SubmissionYearFiltersList) > 0
            BEGIN
                INSERT  @SubmissionYearFilters
                        ( Timeframe
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList)
                 
                SET @SubmissionYears = ( SELECT STUFF(( SELECT DISTINCT
                                                              ', '
                                                              + CASE
                                                              WHEN Timeframe = '-12'
                                                              THEN N'12 mos.'
                                                              ELSE CONVERT(NVARCHAR(10), Timeframe)
                                                              END
                                                        FROM  @SubmissionYearFilters
                                                        ORDER BY 1
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                       )
            END

        IF LEN(@ValidOpportunityTypeFiltersList) > 0
            BEGIN
                INSERT  @ValidOpportunityTypeFilters
                        ( ValidOpportunityTypeID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@ValidOpportunityTypeFiltersList)

                SET @OpportunityTypes = ( SELECT    STUFF(( SELECT DISTINCT
                                                              ', ' + Name
                                                            FROM
                                                              dbo.tblValidProjectOppType
                                                            WHERE
                                                              ValidProjectOppTypeID IN (
                                                              SELECT
                                                              ValidOpportunityTypeID
                                                              FROM
                                                              @ValidOpportunityTypeFilters )
                                                            ORDER BY ', '
                                                              + Name
                                                          FOR
                                                            XML
                                                              PATH('')
                                                          ), 1, 2, '')
                                        )
            END
		
        IF LEN(@FormFiltersList) > 0
            BEGIN
                INSERT  @FormFilters
                        ( FormID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@FormFiltersList)
                    
                SET @Forms = ( SELECT   STUFF(( SELECT DISTINCT
                                                        ', ' + Name
                                                FROM    dbo.tblForm
                                                WHERE   FormID IN ( SELECT
                                                              FormID
                                                              FROM
                                                              @FormFilters )
                                                ORDER BY ', ' + Name
                                              FOR
                                                XML PATH('')
                                              ), 1, 2, '')
                             )
            END
		
        IF LEN(@ValidTechOpsRatingFiltersList) > 0
            BEGIN
                INSERT  @ValidTechOpsRatingFilters
                        ( ValidTechOpsRatingID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@ValidTechOpsRatingFiltersList)

                SET @ValidTechOpsRating = ( SELECT  STUFF(( SELECT DISTINCT
                                                              ', ' + Name
                                                            FROM
                                                              dbo.tblValidTechOpsRating
                                                            WHERE
                                                              ValidTechOpsRatingID IN (
                                                              SELECT
                                                              ValidTechOpsRatingID
                                                              FROM
                                                              @ValidTechOpsRatingFilters )
                                                            ORDER BY ', '
                                                              + Name
                                                          FOR
                                                            XML
                                                              PATH('')
                                                          ), 1, 2, '')
                                          )
            END
            
-- Sites

        IF LEN(@SiteCompanyGroups) > 0
            BEGIN
                SET @Sites = REPLACE(@SiteCompanyGroups, '|', ', ')
        
                INSERT  INTO @SiteFilters
                        ( id
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@SiteFiltersList)
		
                SET @SiteNames = ( SELECT   STUFF(( SELECT DISTINCT
                                                            ', ' + Name
                                                    FROM    dbo.tblCompany
                                                    WHERE   CompanyID IN (
                                                            SELECT
                                                              id
                                                            FROM
                                                              @SiteFilters )
                                                    ORDER BY ', ' + Name
                                                  FOR
                                                    XML PATH('')
                                                  ), 1, 2, '')
                                 )
            END
		
        IF LEN(@AlertTypes) > 0
            BEGIN
                INSERT  @AlertFilters
                        ( id
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@AlertTypes)

                SET @Alerts = ( SELECT  STUFF(( SELECT DISTINCT
                                                        ', ' + Name
                                                FROM    dbo.tblValidAlertType
                                                WHERE   ValidAlertTypeID IN (
                                                        SELECT
                                                              id
                                                        FROM  @AlertFilters )
                                                ORDER BY ', ' + Name
                                              FOR
                                                XML PATH('')
                                              ), 1, 2, '')
                              )
            END
         
        IF LEN(@TeamMembers) > 0
            BEGIN
                INSERT  @TeamMemberFilters
                        ( id
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@TeamMembers)

                SET @TeamMemberNames = ( SELECT STUFF(( SELECT DISTINCT
                                                              ', '
                                                              + COALESCE(FullName,
                                                              ADUserName)
                                                        FROM  dbo.admin_SecUser
                                                        WHERE UserID IN (
                                                              SELECT
                                                              id
                                                              FROM
                                                              @TeamMemberFilters )
                                                        ORDER BY ', '
                                                              + COALESCE(FullName,
                                                              ADUserName)
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                       )
            END 
            
        IF LEN(@ProjectTeamRole) > 0
            BEGIN
                SET @ProjectTeamRoleName = @ProjectTeamRole
            END 
            
        SELECT  @ProjectLead = COALESCE(FullName, ADUserName)
        FROM    dbo.admin_SecUser
        WHERE   UserID = @ProjectLeadID

        SELECT  @ValidWorkPlan = Name
        FROM    dbo.tblValidWorkPlan
        WHERE   ValidWorkPlanID = @ValidWorkPlanID
        
        SELECT  @ProjectStatus = StateName
        FROM    dbo.tblBusinessBaseStates
        WHERE   StateID = @ProjectStatusID
        
        SELECT  @User = COALESCE(FullName, ADUserName)
        FROM    dbo.admin_SecUser
        WHERE   UserID = @UserID
        
        SELECT  @ProductGroup = P.Name
        FROM    dbo.tblProduct AS P
        WHERE   P.ProductID = @ProductGroupID
        
        SELECT  dbo.udf_InclusionParameterTranslate(@CountryGroupFiltersInclusionID,
                                                    @CountryGroups, 0) AS Regions ,
                dbo.udf_InclusionParameterTranslate(@CountryFiltersInclusionID,
                                                    @Countries, 0) AS Countries ,
                dbo.udf_InclusionParameterTranslate(@BBOTagFiltersInclusionID,
                                                    @BBOTags, 0) AS Tags ,
                dbo.udf_InclusionParameterTranslate(@ValidProjectTypeFiltersInclusionID,
                                                    @ProjectTypes, 0) AS ProjectTypes ,
                dbo.udf_InclusionParameterTranslate(@SubmissionYearFiltersInclusionID,
                                                    @SubmissionYears, 0) AS SubmissionYears ,
                dbo.udf_InclusionParameterTranslate(@ValidOpportunityTypeFiltersInclusionID,
                                                    @OpportunityTypes, 0) AS OpportunityTypes ,
                dbo.udf_InclusionParameterTranslate(@FormFiltersInclusionID,
                                                    @Forms, 0) AS Forms ,
                dbo.udf_InclusionParameterTranslate(@ProjectLeadInclusionID,
                                                    @ProjectLead, 1) AS ProjectLead ,
                dbo.udf_InclusionParameterTranslate(@ValidWorkPlanInclusionID,
                                                    @ValidWorkPlan, 1) AS ValidWorkPlan ,
                dbo.udf_InclusionParameterTranslate(@ValidTechOpsRatingInclusionID,
                                                    @ValidTechOpsRating, 0) AS ValidTechOpsRating ,
                dbo.udf_InclusionParameterTranslate(@ProjectStatusInclusionID,
                                                    @ProjectStatus, 1) AS AdminStatus ,
                dbo.udf_InclusionParameterTranslate(@SiteNameFiltersInclusionID,
                                                    @Sites, 0) AS Sites ,
                dbo.udf_InclusionParameterTranslate(@SiteNameFiltersInclusionID,
                                                    @SiteNames, 0) AS SiteNames ,
                dbo.udf_InclusionParameterTranslate(@ProjectTeamRoleInclusionID,
                                                    @ProjectTeamRoleName, 1) AS ProjectTeamRole ,
                dbo.udf_InclusionParameterTranslate(@TeamMembersInclusionID,
                                                    @TeamMemberNames, 0) AS TeamMembers ,
                dbo.udf_InclusionParameterTranslate(@AlertTypesInclusionID,
                                                    @Alerts, 0) AS Alerts ,
                @ProductGroup AS ProductGroup ,
                @User AS [User]
    END
GO
