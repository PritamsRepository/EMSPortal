SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[admin_SecPriv_GetByID] @PrivID INT
AS 
    SET NOCOUNT ON 
    SET XACT_ABORT ON  

    BEGIN TRY 
	

        SELECT  [PrivID] ,
                [PrivCode] ,
                [Name] ,
                [Description] ,
                [IsAudited] ,
                [IsCountrySpecific] ,
                [IsCGSpecific] ,
                [Object] ,
                [Action] ,
                [Num] ,
                [PrivType] ,
                [RowSpecific] ,
                [VisibleOrEnable] ,
                [HasPrivParam] ,
                [ConcurrencyID] ,
                [IsTeamSpecific] ,
                [CanEditComments]
        FROM    [dbo].[admin_SecPriv]
        WHERE   ( [PrivID] = @PrivID
                  OR @PrivID IS NULL ) 
    END TRY

    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH


GO
GRANT EXECUTE ON  [dbo].[admin_SecPriv_GetByID] TO [mp_db_execute]
GO
