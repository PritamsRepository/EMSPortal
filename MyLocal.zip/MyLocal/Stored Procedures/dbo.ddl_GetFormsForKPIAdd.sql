SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


-------------------------------------------------------------------------------------------------------------------
--																DROP PROCEDURE 
-------------------------------------------------------------------------------------------------------------------


CREATE PROCEDURE [dbo].[ddl_GetFormsForKPIAdd]
(
@KPIID INT
)
AS
/*
---------------------------------------------------------------------------------------
-- Date 04/19/2010 | JRG | Modify for SDLC 449 DBR 567 | Modify sp  
---------------------------------------------------------------------------------------
-- Change Description
SDLC 449 DBR 567

Params:
@KPIID
 
Gets FormID and Name from tblForm
 
All records in tblForm that have productID in tblProductLinkKPI 
where tblProductLinkKPI.KPIID is IN (Select KPIID from tblKPI where KPIID = @KPIID)

*/


BEGIN TRY
	
	SELECT 
		f.FormID,
		f.Name
	FROM tblForm f 
		INNER JOIN tblProductLinkKPI plk ON plk.ProductID = f.ProductID
		
	where plk.KPIID IN (Select KPIID from tblKPI where KPIID = @KPIID)
	order by f.Name
	

END TRY

BEGIN CATCH
	EXEC SP_RollAndRaise
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_GetFormsForKPIAdd] TO [mp_db_execute]
GO
