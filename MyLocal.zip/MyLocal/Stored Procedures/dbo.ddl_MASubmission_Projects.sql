SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MASubmission_Projects]
    @SubmissionRouteID INT ,
    @HealthAuthorityID INT ,
    @MAApplicationID INT
AS
    BEGIN TRY 
        SELECT DISTINCT
                prj.ProjectID AS ID ,
                ( 'PRJ' + CAST(prj.ProjectID AS NVARCHAR(20)) + '-' + prcg.Name
                  + '-' + ISNULL(vpt.Name, 'Project Type Unknown') + '-'
                  + f.Name ) AS Name
        FROM    pm.Project prj
                JOIN dbo.tblCountryGroup prcg ON prcg.CountryGroupID = prj.CountryGroupID
                JOIN dbo.tblValidProjectType vpt ON vpt.ValidProjectTypeID = prj.ValidProjectTypeID
                JOIN dbo.tblForm f ON f.FormID = prj.FormID
                JOIN dbo.tblMAApplication ma ON ma.MAApplicationID = @MAApplicationID
                                                AND f.ProductID = ma.ProductGroupID
        WHERE   prj.ValidProjectTypeID != 6
                AND ( prj.CountryGroupID IN (
                      SELECT DISTINCT
                                clcg.CountryGroupID
                      FROM      dbo.tblSubmissionRouteConfig src
                                JOIN dbo.tblCountryLinkCountryGroup clcg ON src.CountryID = clcg.CountryID
                                JOIN dbo.tblCountryGroup cg ON clcg.CountryGroupID = cg.CountryGroupID
                                                           AND cg.CountryGroupType = 'KeyMkt'
                      WHERE     src.SubmissionRouteID = @SubmissionRouteID
                                AND src.HealthAuthorityID = @HealthAuthorityID )
                      OR ( @SubmissionRouteID IN ( 1, 3 )
                           AND prj.CountryGroupID IN (
                           SELECT DISTINCT
                                    cg.CountryGroupID
                           FROM     dbo.tblCountryGroup cg
                           WHERE    cg.Name = 'Europe'
                                    AND cg.CountryGroupType = 'KeyMkt' )
                         )
                    )
        ORDER BY Name;
    END TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise;
    END CATCH
GO
