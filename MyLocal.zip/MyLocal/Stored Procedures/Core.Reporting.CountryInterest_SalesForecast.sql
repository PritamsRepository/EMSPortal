SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[CountryInterest_SalesForecast]
    @FormID INT = NULL,
    @CountryID INT = NULL,
    @StatusID INT = NULL,
    @PRBSessionID INT = NULL,
    @UserID INT
AS
BEGIN
    DECLARE @Years INT = 5;
    DECLARE @StartYear INT = YEAR(GETDATE());

    DECLARE @gpe BIT = 0;
    DECLARE @RoleID INT =
            (
                SELECT TOP (1)
                       RoleID
                FROM dbo.admin_SecRole
                WHERE Name = 'Global Portfolio Editor'
                ORDER BY RoleID
            );
    DECLARE @Complete INT =
            (
                SELECT TOP (1)
                       StateID
                FROM dbo.tblBusinessBaseStates
                WHERE StateControlID = 3
                      AND StateName = 'Complete'
                ORDER BY StateID
            );
    --DECLARE @PostPRB INT = ( SELECT StateID
    --                         FROM   dbo.tblBusinessBaseStates
    --                         WHERE  StateControlID = 3
    --                                AND StateName = 'Post PRB'
    --                       )
    -- Check to see if User is Global Portfolio Editor
    IF EXISTS
    (
        SELECT 1
        FROM dbo.admin_SecUserRole
        WHERE UserID = @UserID
              AND RoleID = @RoleID
    )
    BEGIN
        SET @gpe = 1;
    END;

    SELECT ci.CountryInterestID,
           td.CountryInterestTradeDressID,
           f.Name AS Product,
           s.Name + ' - ' + COALESCE(vpt.Name + ' ', '') + COALESCE(CONVERT(NVARCHAR(255), td.PackSize) + ' ', '')
           + COALESCE(uom.Name, '') + COALESCE(' - ' + vbl.Name, '') AS [TradeDress],
           c.Code AS Country,
           vsc.Name AS [SalesChannel],
           num.Number AS [Year],
           sf.ForecastVolume,
           sf.ForecastPricePerUnit,
           COALESCE(cur.Name, 'USD') AS Currency,
           sf.MktShare
    FROM pm.CountryInterest ci
        JOIN dbo.tblForm f
            ON f.FormID = ci.FormID
        JOIN pm.CountryInterestTradeDress td
            ON td.CountryInterestID = ci.CountryInterestID
        JOIN dbo.tblStrength s
            ON s.StrengthID = td.StrengthID
        JOIN dbo.tblCountry c
            ON c.CountryID = ci.CountryID
        JOIN dbo.utility_Years num
            ON num.Number >= COALESCE(   ci.ForecastStartYear,
                             (
                                 SELECT MIN(ForecastYear)
                                 FROM pm.CountryInterestSalesForecast
                                 WHERE CountryInterestTradeDressID = td.CountryInterestTradeDressID
                             ),
                                         @StartYear
                                     )
               AND num.Number <= COALESCE(
                                 (
                                     SELECT MAX(ForecastYear)
                                     FROM pm.CountryInterestSalesForecast
                                     WHERE CountryInterestTradeDressID = td.CountryInterestTradeDressID
                                 ),
                                 ci.ForecastStartYear,
                                 @StartYear
                                         ) + @Years
        LEFT JOIN dbo.tblValidCurrency cur
            ON cur.ValidCurrencyID = ci.ValidCurrencyID
        LEFT JOIN dbo.tblValidPackType vpt
            ON vpt.ValidPackTypeID = td.ValidPackTypeID
        LEFT JOIN dbo.tblValidPackSizeUOM uom
            ON uom.ValidPackSizeUOMID = td.ValidPackSizeUOMID
        LEFT JOIN dbo.tblValidBreakline vbl
            ON vbl.ValidBreaklineID = td.ValidBreaklineID
        LEFT JOIN dbo.tblValidSalesChannel vsc
            ON vsc.ValidSalesChannelID = td.ValidSalesChannelID
        LEFT JOIN pm.CountryInterestSalesForecast sf
            ON sf.CountryInterestTradeDressID = td.CountryInterestTradeDressID
               AND sf.ForecastYear = num.Number
    WHERE (
              @gpe = 1
              OR ci.StatusID NOT IN ( @Complete ) --, @PostPRB )
          )
          AND
          (
              @FormID IS NULL
              OR @FormID = ci.FormID
          )
          AND
          (
              @StatusID IS NULL
              OR ci.StatusID = @StatusID
          )
          AND
          (
              @CountryID IS NULL
              OR @CountryID = ci.CountryID
          )
          AND
          (
              @PRBSessionID IS NULL
              OR @PRBSessionID = ci.PRBSessionID
          )
    ORDER BY ci.CountryInterestID,
             td.CountryInterestTradeDressID,
             num.Number;
END;
GO
