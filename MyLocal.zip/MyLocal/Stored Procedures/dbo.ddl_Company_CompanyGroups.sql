SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_Company_CompanyGroups]
AS

BEGIN TRY

SELECT DISTINCT
  cg.CompanyGroupID,
  cg.[Text] AS Name
FROM
  dbo.tblCompanyGroup cg
    JOIN dbo.tblCompanyLinkCompanyGroup clcg ON cg.CompanyGroupID = clcg.CompanyGroupID
ORDER BY
  cg.[Text]

END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_Company_CompanyGroups] TO [mp_db_execute]
GO
