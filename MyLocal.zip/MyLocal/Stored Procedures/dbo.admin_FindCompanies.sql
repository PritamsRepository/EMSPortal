SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC dbo.admin_MergeCompanies @OldID =2389 , -- int
--    @NewID = 9361 -- int

CREATE PROC [dbo].[admin_FindCompanies]
    @OldID INT ,
    @Debug BIT = 0
AS
    BEGIN TRY
	

/* 

	Check and display all places where the ID is used 
	this displays the table name where the company ID is used without the tbl prefix used in 
	this application

*/
		-- Testing JRG
         --DECLARE @OldID INT = 1697	
         	
         	
		/* 
			Check if we left our temp table lying around and clean up 
		   Should not be necessary but handy for testing 
		   SQL Server should clean this up on disconnect too
		*/     
		    	
        IF EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..#Temp') )
            BEGIN                    
                DROP TABLE #Temp
            END            
                    
         /* 
         
			Define a single quote so we do not have to type it so many times in Dynamic SQL
			it gets confusing to parse
			
		*/
		
        DECLARE @Quote NCHAR(1)= '''' 
        
       
		/* Check and see if we are on a wild goose chase if so just raise the error and exit */
        IF NOT EXISTS ( SELECT  name
                        FROM    tblcompany
                        WHERE   companyid = @OldID )
            BEGIN
                RAISERROR( 'Old ID does not exists',16,1) WITH nowait;
            END
 
 
 /* 
 
	Create a table to hold our search locations and then check each place once then display the findings
	I used to have this execute without a loop but there became too many strings in the nvarchar so to 
	the temp table land we go
 
 */ 
        CREATE TABLE #Temp
            (
              id INT IDENTITY(1, 1) ,
              SQLStmt NVARCHAR(2000)
            );
              
        IF OBJECT_ID('tempdb..#CompanyExistsIn') IS  NULL
            BEGIN
                CREATE TABLE #CompanyExistsIn
                    (
                      TableName SYSNAME NULL ,
                      BBOName VARCHAR(256) NULL ,
                      qty INT NULL
                    )
            END

        IF OBJECT_ID('tempdb..#CompanyExistsIn') IS NOT NULL
            BEGIN
                DELETE  FROM tempdb..#CompanyExistsIn
            END
        
              
              /* Generate some Dynamic SQL based off all the FKs found to */
        INSERT  INTO #Temp
                ( SQLStmt
                )
                SELECT  'IF Exists (select ' + COL_NAME(fc.parent_object_id,
                                                        fc.parent_column_id)
                        + ' from  ' + SCHEMA_NAME(f.SCHEMA_ID) + '.'
                        + OBJECT_NAME(f.parent_object_id) + ' where '
                        + COL_NAME(fc.parent_object_id, fc.parent_column_id)
                        + '  = ' + CAST(@OLDID AS NVARCHAR(6)) + ') DECLARE @count INT =(SELECT COUNT(*) FROM  ' + SCHEMA_NAME(f.SCHEMA_ID) + '.'
                        + OBJECT_NAME(f.parent_object_id) + ' WHERE '
                        + COL_NAME(fc.parent_object_id, fc.parent_column_id)
                        + '  = ' + CAST(@OLDID AS NVARCHAR(6)) + ')'
                        + ' DECLARE @BBOName NVARCHAR(256)= (SELECT TOP 1 BBOName from dbo.tblBusinessBaseObject WHERE BBOTable='
                        + @Quote + SCHEMA_NAME(f.SCHEMA_ID) + '.'
                        + OBJECT_NAME(f.parent_object_id) + @Quote
                        + ' OR BBOTable=' + @Quote
                        + OBJECT_NAME(f.parent_object_id) + @Quote + ')'
                        + ' insert into #CompanyExistsIn (TableName,BBOName,qty) SELECT '
                        + @Quote + SCHEMA_NAME(f.SCHEMA_ID) + '.'
                        + OBJECT_NAME(f.parent_object_id) + @Quote
                        + ' ,@BBOName AS BBOName, @count AS ' + @Quote
                        + ' Count ' + @Quote
                FROM    sys.foreign_keys AS f
                        INNER JOIN sys.foreign_key_columns AS fc ON f.OBJECT_ID = fc.constraint_object_id
                        INNER JOIN sys.objects AS o ON o.OBJECT_ID = fc.referenced_object_id
                WHERE   o.object_id = OBJECT_ID('tblcompany')                 
        
        /* 
        This is handy to see all the SQL Statements for debug*/
        
        IF @Debug = 1
            BEGIN
                SELECT  id ,
                        SQLStmt
                FROM    #Temp
            END
		
        DECLARE @RID INT = ( SELECT MIN(id)
                             FROM   #Temp
                           );
        
        DECLARE @MaxRID INT = ( SELECT  MAX(id)
                                FROM    #Temp
                              );
        
        DECLARE @SQL NVARCHAR(1000) 
        
        
        WHILE ( @RID <= @MaxRID )
            BEGIN
 
                SET @SQL = ( SELECT SQLStmt
                             FROM   #Temp
                             WHERE  id = @RID
                           )
 
				
                EXEC (@SQL)
 
                SET @RID += 1;
            END
            
                 
        SELECT  TableName ,
                COALESCE(BBOName, TableName) AS BBOName ,
                SUM(qty) AS LinkCount
        FROM    #CompanyExistsIn
        WHERE   qty IS NOT NULL
        GROUP BY TableName ,
                COALESCE(BBOName, TableName);
		
		/* Check and clean up our temp tables */
        IF EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..#Temp') )
            DROP TABLE #Temp
            
        IF EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..#CompanyExistsIn') )
            BEGIN                    
                DROP TABLE #CompanyExistsIn
            END            
    END TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[admin_FindCompanies] TO [mp_db_execute]
GO
