SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[Argus_Family]
AS
BEGIN
    DECLARE @start DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, -7)
            );
    DECLARE @end DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, 0)
            );

    -- Sheet 1 - Family
    SELECT DISTINCT
           p.ProductID AS [Product ID],
           p.NAME AS [Family Name],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + vki.Name + ISNULL(' ' + vs.Name, '')
               FROM dbo.tblProductLinkKPI lnk
                   JOIN dbo.tblKPI kpi
                       ON lnk.KPIID = kpi.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE p.ProductID = lnk.ProductID
               ORDER BY ', ' + vki.Name + ISNULL(' ' + vs.Name, '')
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Name of Active Ingredient]
    FROM dbo.tblProduct p
    WHERE p.UpdateDate >= @start
          AND p.UpdateDate < @end
    ORDER BY 1;
END;
GO
