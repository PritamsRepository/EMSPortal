SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_COUNTRYINTEREST_GetCountryInterestsByFilterExport_Report]
    @FormName NVARCHAR(256) = NULL,
    @CountryID INT = NULL,
    @ValidResponseID INT = NULL,
    @ValidCIStatusID INT = NULL,
    @ValidCIPurposeID INT = NULL,
    @UserID INT = NULL,
    @PrivCode NVARCHAR(10) = NULL
AS
    BEGIN TRY
        SET XACT_ABORT ON
        SET NOCOUNT ON

        DECLARE @USD INT
        SELECT  @USD = ValidCurrencyID
        FROM    [dbo].tblValidCurrency
        WHERE   Name = 'USD';
	
        SELECT  ci.CountryInterestID AS id ,
                ci.[ShortName] AS name ,
                ci.[ResponseDueDate] AS responseDueDate ,
                --[dbo].[udf_BBActionDateByBBOCodeStateName]('CI', 'Complete',
                --                                           ci.[CountryInterestID]) AS responseDate ,
                ci.ResponseDate AS responseDate,
				ci.[NumberLicensesProposed] AS numLicensesProposed ,
                dbo.udf_BBOSA_LastCopiedFromOn(ci.CountryInterestID) AS lastCopiedOn ,
                dbo.udf_BrandNameListByFormCountry(ci.FormID, ci.CountryID) AS brandNames ,
                f.Name AS formname ,
                c.[Name] + '(' + RTRIM(c.[Code]) + ')' AS country ,
                vr.[Name] AS validResponsename ,
                bbs.[StateName] AS businessBaseStatename ,
                --ci.MylanMarketShare ,
                ci.GxMarketShare ,
                s.Name AS Strengthname ,
                citd.TradeDressName AS TradeDressname ,
                cisf.ForecastYear AS [year] ,
                cisf.ForecastAPIUsage AS apiUsage ,
                dbo.udf_EHSAlert(f.ProductID, NULL) AS EHSAlert ,
				dbo.udf_GetMPBClassifications(f.ProductID) AS OEBClassifications,
				dbo.udf_GetDrugClassifications(f.ProductID) AS DrugClassifications,
                dbo.udf_ConvertCurrencyLatestFx(cisf.ForecastPricePerUnit,
                                                cisf.ValidCurrencyID, @USD) AS pricePerUnit ,
                dbo.udf_ConvertCurrencyLatestFx(cisf.ForecastTurnover,
                                                cisf.ValidCurrencyID, @USD) AS turnover ,
                cisf.ForecastVolume AS volumePacks ,
                ( cisf.ForecastVolume * citd.PackSize ) AS volume ,
                cisf.PacketSize AS packetSize ,
                ( SELECT    MAX(dbo.udf_ConvertCurrencyLatestFx(ForecastTurnover,
                                                              ValidCurrencyID,
                                                              @USD))
                  FROM      pm.CountryInterestSalesForecast xsf
                  WHERE     xsf.CountryInterestTradeDressID = CISF.CountryInterestTradeDressID
                ) AS peekSales
        FROM    pm.CountryInterest AS ci
                JOIN dbo.tblForm AS f ON ci.FormID = f.FormID
                JOIN dbo.tblCountry AS c ON c.CountryID = ci.CountryID
                JOIN dbo.tblValidCIPurpose vcip ON vcip.ValidCIPurposeID = ci.ValidCIPurposeID
                LEFT JOIN pm.CountryInterestTradeDress citd ON citd.CountryInterestID = ci.CountryInterestID
                LEFT JOIN [dbo].tblstrength S ON s.StrengthID = citd.StrengthID
                LEFT JOIN dbo.tblBusinessBaseStates AS bbs ON bbs.StateID = ci.StatusID
                LEFT JOIN pm.CountryInterestSalesForecast AS cisf ON cisf.CountryInterestTradeDressID = citd.CountryInterestTradeDressID
                LEFT OUTER JOIN dbo.tblValidResponse AS vr ON ci.ValidResponseID = vr.ValidResponseID
        WHERE   ( @FormName IS NULL
                  OR f.[Name] LIKE @FormName + '%'
                )
                AND ( @CountryID IS NULL
                      OR ci.CountryID = @CountryID
                    )
                AND ( @ValidResponseID IS NULL
                      OR ci.ValidResponseID = @ValidResponseID
                    )
                AND ( @ValidCIStatusID IS NULL
                      OR ci.StatusID = @ValidCIStatusID
                    )
                AND ( @ValidCIPurposeID IS NULL
                      OR ci.ValidCIPurposeID = @ValidCIPurposeID
                    )
                AND [dbo].[udf_UserHasPrivForCountry](@UserID, @PrivCode,
                                                      ci.CountryID) = 1
        ORDER BY id	
    END TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_COUNTRYINTEREST_GetCountryInterestsByFilterExport_Report] TO [mp_db_execute]
GO
