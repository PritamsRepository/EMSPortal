SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MilestoneTemplatesByBBOCode] (@BBOCode nvarchar(25))
as
/**********************************************************************************
JRG
DATE: 20101117
DropDown to get all the MilestoneTemplates for a give BBO
******
CLD
Making it less stupid.
**********************************************************************************/
	SELECT 
		MT.MilestoneTemplateID ,
	  MT.Name 
	FROM    
		dbo.tblMilestoneTemplate MT
		JOIN tblBusinessBaseObject BBO ON MT.BBOID = BBO.BBOID
	WHERE 
		bbo.BBOCode = @BBOCode
		-- Let's not include these.
		AND IsPublic = 1 AND IsActive = 1
	




GO
GRANT EXECUTE ON  [dbo].[ddl_MilestoneTemplatesByBBOCode] TO [mp_db_execute]
GO
