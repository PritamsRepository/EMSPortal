SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC [Core.Reporting].[MAApplication_Report_Site]
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Site]
(@MAApplicationID INT = NULL)
AS
BEGIN
    SELECT DISTINCT
           mals.MALicenseScopeID,
           vst.Name AS [Valid Site Type],
           c.CompanyID AS [CompanyID],
           c.Name AS [Site]
    FROM dbo.tblMALicenseScope mals
        JOIN dbo.tblMARegisteredSite mars
            ON mars.MALicenseScopeID = mals.MALicenseScopeID
        JOIN dbo.tblMASite mas
            ON mas.MASiteID = mars.MASiteID
        JOIN dbo.tblCompany c
            ON c.CompanyID = mas.CompanyID
        JOIN dbo.tblValidSiteType vst
            ON vst.ValidSiteTypeID = mas.ValidSiteTypeID;
END;
GO
