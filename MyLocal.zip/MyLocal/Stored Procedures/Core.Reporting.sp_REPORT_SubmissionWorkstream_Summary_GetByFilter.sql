SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [Core.Reporting].[sp_REPORT_SubmissionWorkstream_Summary_GetByFilter]
    @ProductName NVARCHAR(256) = NULL ,
    @ApplicationNum NVARCHAR(256) = NULL ,
    @ApplicationID INT = NULL ,
    @SubmissionTracking NVARCHAR(256) = NULL ,
    @MASubmissionWorkstreamID INT = NULL ,
    @CountryGroupID INT = NULL , --Region
    @CountryID INT = NULL ,
    @RegLeadID INT = NULL , --SubmissionLead
    @RegTeamID INT = NULL ,
    @MASubmissionWorkstreamStatusID INT = NULL ,
    @SubmissionRouteID INT = NULL ,
    @ValidMASubmissionTypeID INT = NULL , --<< New for Phase 2
    @ShowCMSSubmissions INT , --<< New for Phase 2
    @SubmissionStartDate NVARCHAR(256) = NULL ,
    @SubmissionEndDate NVARCHAR(256) = NULL ,
    @RegCloseStartDate NVARCHAR(256) = NULL ,
    @RegCloseEndDate NVARCHAR(256) = NULL ,
    @FinalApproveStartDate NVARCHAR(256) = NULL ,
    @FinalApproveEndDate NVARCHAR(256) = NULL ,
    @UserID INT ,
    @PrivCode NVARCHAR(20)
AS
    BEGIN TRY
        DECLARE @PerfectProdSearch BIT = 0
        IF CHARINDEX('"', @ProductName) > 0
            BEGIN
                SET @ProductName = REPLACE(REPLACE(@ProductName, '"', ''), '%',
                                           '')			
                SET @PerfectProdSearch = 1
            END
        
        DECLARE @BBOID INT = ( SELECT   BBOID
                               FROM     dbo.tblBusinessBaseObject
                               WHERE    BBOCode = 'SW'
                             )
        DECLARE @ProjBBOID INT = ( SELECT   BBOID
                                   FROM     dbo.tblBusinessBaseObject
                                   WHERE    BBOCode = 'PJM'
                                 )          
        DECLARE @LaunchBBOID INT = ( SELECT BBOID
                                     FROM   dbo.tblBusinessBaseObject
                                     WHERE  BBOCode = 'LNCH'
                                   )                   
                   	
/* -------------------------------------------------------------------------------------------------------------------------------------------------------- */
-- Create a temporary table to house all of the possible Submissions that will be pulled from in the query.
        IF OBJECT_ID('tempdb..#EMCS') IS NOT NULL
            DROP TABLE #EMCS

		-- Create an entrance point for applications that are already filtered.
        CREATE TABLE #EMCS
            (
              MASubmissionWorkstreamID INT NOT NULL
            )
        CREATE CLUSTERED INDEX IDX_TMP_01 ON #EMCS(MASubmissionWorkstreamID)

		-- Preload all of the possible MA license/scope names; with modifiers.
        INSERT  INTO #EMCS
                SELECT DISTINCT
                        xmasw.MASubmissionWorkstreamID
                FROM    dbo.MASubmissionWorkstream xmasw
                        JOIN dbo.udf_AccessibleMAApplications(@UserID) xma ON xma.MAApplicationID = xmasw.MAApplicationID
                        --ARD 2014-01-07: (A) LEFT JOIN dbo.tblMALicense xmal ON xmal.MASubmissionWorkstreamID = xmasw.MASubmissionWorkstreamID
                        --LEFT JOIN ( dbo.tblMALicenseScope xmls  --ARD 2014-01-07: Removed this.  Country search now points to sub route config
                        LEFT JOIN ( dbo.MASubmissionWorkstreamStrength xmas
                                    JOIN dbo.tblStrength xs ON xs.StrengthID = xmas.StrengthID
                                    JOIN dbo.tblForm xf ON xf.FormID = xs.FormID
                                  ) ON xmasw.MASubmissionWorkstreamID = xmas.MASubmissionWorkstreamID
                        
                        --LEFT JOIN dbo.tblCountryLinkCountryGroup clcg ON xmls.CountryID = clcg.CountryID --ARD 2014-01-07: Removed this.  Country Group search now points to sub route config
                        JOIN dbo.tblMAApplication maap ON maap.MAApplicationID = xmasw.MAApplicationID
                        JOIN dbo.tblProduct prd ON maap.ProductGroupID = prd.ProductID
                        JOIN dbo.tblValidMASubmissionType vmst ON vmst.ValidMASubmissionTypeID = xmasw.ValidMASubmissionTypeID
                WHERE   ( ( @PerfectProdSearch = 1
                            AND xf.Name = @ProductName
                          )
                          OR ( @ProductName IS NULL
                               OR ( xf.Name LIKE @ProductName
                               --ARD 2014-01-07:  This isn't in the grid so it was removed.  To add it back in uncomment (A) Above
                               --     OR xmal.RegisteredProductName LIKE @ProductGroupName
                                    )
                               OR ( prd.Name LIKE @ProductName )
                             )
                        )
                        AND ( @MASubmissionWorkstreamID IS NULL
                              OR xmasw.MASubmissionWorkstreamID = @MASubmissionWorkstreamID
                            )
                        AND ( @CountryGroupID IS NULL
                              OR xmasw.HealthAuthorityID IN (
                              SELECT DISTINCT
                                        ysrc.HealthAuthorityID
                              FROM      dbo.tblSubmissionRouteConfig ysrc
                                        JOIN dbo.tblCountryLinkCountryGroup clcg ON clcg.CountryID = ysrc.CountryID
                                                              AND clcg.CountryGroupID = @CountryGroupID )
                            )
                        AND ( @CountryID IS NULL
                              OR xmasw.HealthAuthorityID IN (
                              SELECT DISTINCT
                                        xsrc.HealthAuthorityID
                              FROM      dbo.tblSubmissionRouteConfig xsrc
                              WHERE     xsrc.CountryID = @CountryID )
                            )
                        AND ( @ApplicationNum IS NULL
                              OR xma.ProcedureNumber LIKE @ApplicationNum
                              --ARD 2014-01-07: Took this out. Not in the grid
                              --OR xmas.FullProcedureNumber LIKE @ProcedureNum
                              --OR xma.MAApplicationID LIKE REPLACE(@ProcedureNum,
                              --                                '%', '')
                            )
                        AND ( @RegTeamID IS NULL
                              OR xma.RegulatoryTeamID = @RegTeamID
                            )
                        AND ( @RegLeadID IS NULL
                              OR xmasw.LeadID = @RegLeadID
                            )
                        AND ( ( @SubmissionRouteID IS NULL
                                AND xmasw.SubmissionRouteID != 6
                              )
                              OR xmasw.SubmissionRouteID = @SubmissionRouteID
                            )
                        AND ( @ApplicationID IS NULL
                              OR xma.MAApplicationID = @ApplicationID
                            )
                        AND ( @MASubmissionWorkstreamID IS NULL
                              OR xmasw.MASubmissionWorkstreamID = @MASubmissionWorkstreamID
                            )
                        AND ( @ValidMASubmissionTypeID IS NULL
                              OR xmasw.ValidMASubmissionTypeID = @ValidMASubmissionTypeID
                            )
                        AND ( @MASubmissionWorkstreamStatusID IS NULL
                              OR xmasw.MASubmissionWorkstreamStatusID = @MASubmissionWorkstreamStatusID
                            )
                        AND ( @SubmissionTracking IS NULL
                              OR xmasw.SubmissionTracking LIKE @SubmissionTracking
                            )
                        AND ( @ShowCMSSubmissions = 1
                              OR ( ( @ShowCMSSubmissions = 0
                                     OR @ShowCMSSubmissions IS NULL
                                   )
                                   AND xmasw.ParentSubmissionID IS NULL
                                 )
                            )
                        AND ( ( @SubmissionStartDate IS NULL
                                AND @SubmissionEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     dbo.tblGlobalMilestone gm
                                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( dbo.tblMilestone m
                                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'Submission'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @SubmissionStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @SubmissionEndDate
                                            ) ) )
                            )
                        AND ( ( @RegCloseStartDate IS NULL
                                AND @RegCloseEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     dbo.tblGlobalMilestone gm
                                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( dbo.tblMilestone m
                                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'SW - Reg Proc Close'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @RegCloseStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @RegCloseEndDate
                                            ) ) )
                            )
                        AND ( ( @FinalApproveStartDate IS NULL
                                AND @FinalApproveEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     dbo.tblGlobalMilestone gm
                                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( dbo.tblMilestone m
                                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'SW - Final Reg Approval'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @FinalApproveStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @FinalApproveEndDate
                                            ) ) )
                            )                                              

		/* -------------------------------------------------------------------------------------------------------------------------------------------------------- */
		-- Create a temporary table to house a count of pending MA for Submissions 
        IF OBJECT_ID('tempdb..#MAPCOUNT') IS NOT NULL
            DROP TABLE #MAPCOUNT
		
        CREATE TABLE #CORRESPONDENCE
            (
              MASubmissionWorkstreamID INT NOT NULL ,
              CorrespondenceInfo NVARCHAR(MAX)
            )
        CREATE CLUSTERED INDEX IDX_TMP_Correspondence ON #CORRESPONDENCE(MASubmissionWorkstreamID)
        INSERT  INTO #CORRESPONDENCE
                ( MASubmissionWorkstreamID ,
                  CorrespondenceInfo
                )
                ( SELECT    masw.MASubmissionWorkstreamID ,
                            STUFF(( SELECT  '****' + vhasc.Name
                                            + COALESCE('**Response Date: '
                                                       + REPLACE(CONVERT(VARCHAR(11), h.ResponseDate, 106),
                                                              ' ', '-'), '')
                                            + COALESCE('**Target Response Date: '
                                                       + REPLACE(CONVERT(VARCHAR(11), h.TargetResponseDate, 106),
                                                              ' ', '-'), '')
                                            + COALESCE('**Date Received: '
                                                       + REPLACE(CONVERT(VARCHAR(11), h.ReceivedDate, 106),
                                                              ' ', '-'), '')
                                            + COALESCE('**Status: '
                                                       + vhas.Name, '')
                                    FROM    dbo.MAHAAction h
                                            LEFT JOIN dbo.tblValidMAHAActionStatus vhas ON vhas.ValidMAHAActionStatusID = h.ValidMAHAActionStatusID
                                            LEFT JOIN dbo.tblValidMAHAActionScope vhasc ON vhasc.ValidMAHAActionScopeID = h.ValidMAHAActionScopeID
                                    WHERE   h.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                                  FOR
                                    XML PATH('')
                                  ), 1, 4, '')

--List of HA Action Records for the Submission.  Format will be:

--Scope : [Topic1,Topic2,Topicn] : [ReceivedDate] : [ResponseDate OR Target Response Date] : 'Answered' if Response Date is filled in
--                    CASE WHEN LEN(HATopics.Topics) <> 0
--                         THEN SUBSTRING(HATopics.Topics, 0,
--                                        ( LEN(HATopics.Topics) ))
--                    END AS [HATopics],
                  FROM      dbo.MASubmissionWorkstream masw
                )
		
        CREATE TABLE #MAPCOUNT
            (
              MASubmissionWorkstreamID INT NOT NULL ,
              PendingMACount INT NOT NULL
            )
        CREATE CLUSTERED INDEX IDX_TMP_03 ON #MAPCOUNT(MASubmissionWorkstreamID)
        INSERT  INTO #MAPCOUNT
                SELECT  mal.MASubmissionWorkstreamID ,
                        COUNT(mal.MALicenseID) PendingMACount
                FROM    dbo.tblMALicense mal
                WHERE   mal.MASubmissionWorkstreamID IS NOT NULL
                        AND mal.ValidLicenseStatusID IN (
                        SELECT  ValidLicenseStatusID
                        FROM    dbo.ValidPendingLicenseStatus )
                GROUP BY mal.MASubmissionWorkstreamID;
        WITH    HAInfo ( MAHAActionID, MASubmissionWorkstreamID, ResponseDate, TargetResponseDate, ReceivedDate, MAHAActonStatus )
                  AS ( SELECT   b.MAHAActionID ,
                                act.MASubmissionWorkstreamID ,
                                ( CASE WHEN act.ResponseDate IS NOT NULL
                                       THEN 'Answered'
                                  END ) AS [ResponseDate] ,
                                act.TargetResponseDate ,
                                act.ReceivedDate ,
                                vhas.Name
                       FROM     dbo.MAHAActionLinkHAActionScopeTopic b
                                JOIN dbo.MAHAAction act ON b.MAHAActionID = act.MAHAActionID
                                JOIN dbo.tblValidMAHAActionStatus vhas ON vhas.ValidMAHAActionStatusID = act.ValidMAHAActionStatusID
                       GROUP BY b.MAHAActionID ,
                                act.TargetResponseDate ,
                                act.ResponseDate ,
                                act.MASubmissionWorkstreamID ,
                                act.ReceivedDate ,
                                vhas.Name
                     ),
                HATopics ( MAHAActionID, MASubmissionWorkstreamID, Topics )
                  AS ( SELECT   b.MAHAActionID ,
                                act.MASubmissionWorkstreamID ,
                                ( SELECT    CONVERT(NVARCHAR, topic.NAME)
                                            + ','
                                  FROM      dbo.MAHAActionLinkHAActionScopeTopic a
                                            JOIN dbo.tblValidMAHAActionScopeTopic topic ON a.ValidMAHAActionScopeTopicID = topic.ValidMAHAActionScopeTopicID
                                            JOIN dbo.MAHAAction act ON b.MAHAActionID = act.MAHAActionID
                                  WHERE     a.MAHAActionID = b.MAHAActionID
                                FOR
                                  XML PATH('')
                                ) Topics
                       FROM     dbo.MAHAActionLinkHAActionScopeTopic b
                                JOIN dbo.MAHAAction act ON b.MAHAActionID = act.MAHAActionID
                       GROUP BY b.MAHAActionID ,
                                act.MASubmissionWorkstreamID
                     )
            --,
                --STRPRD ( [MASubmissionWorkstreamID], [Product], [Strength] )
                --  AS ( SELECT DISTINCT
                --                ymas.[MASubmissionWorkstreamID],
                --                yf.Name,
                --                ys.NAME
                --       FROM     MASubmissionWorkstreamStrength ymas
                --                JOIN tblStrength ys ON ys.StrengthID = ymas.StrengthID
                --                JOIN tblForm yf ON ys.FormID = yf.FormID   
                        --ARD 2014-01-15  strengths need to through submission strengths now 
                       --dbo.tblMALicense ymal
                       --         JOIN tblMALIcenseScope ymals ON ymal.MALicenseID = ymals.MALicenseID
                       --         JOIN dbo.tblMAStrength ymas ON ymals.MAStrengthID = ymas.MAStrengthID
                       --         JOIN dbo.tblStrength ys ON ys.StrengthID = ymas.StrengthID
                       --         JOIN dbo.tblForm yf ON ys.FormID = yf.FormID
                       --         JOIN dbo.tblProduct yp ON yp.ProductID = yf.ProductID
                                
                    -- )
            SELECT  DISTINCT
                    masw.MASubmissionWorkstreamID [Id] ,
                
                /* HA */
                    COALESCE(hacc.Code, ha.ShortName) AS [Country] ,
                    ( CASE WHEN ha.ShortName IS NOT NULL
                           THEN ha.ShortName + ' [' + hacc.Code + ']'
                      END ) AS [AssessingHA] ,
                    ( CASE WHEN --masw.HealthAuthorityID = ma.HealthAuthorityID
                                masw.ParentSubmissionID IS NOT NULL THEN 'Yes'
                           ELSE 'No'
                      END ) AS [HA is CMS?] ,
				/* END HA */
                    --CASE WHEN f.Name IS NOT NULL
                    --     THEN f.Name + ' ['
                    --          + STUFF(( SELECT  ',' + ys.Name
                    --                    FROM    MASubmissionWorkstreamStrength ymas
                    --                            JOIN tblStrength ys ON ys.StrengthID = ymas.StrengthID
                    --                    WHERE   ymas.[MASubmissionWorkstreamID] = masw.[MASubmissionWorkstreamID]
                    --                  FOR
                    --                    XML PATH('')
                    --                  ), 1, 1, '') + ']'
                    --     ELSE 'N/A'
                    --END AS [Product Strengths] ,
                    COALESCE(( SELECT   STUFF(( SELECT DISTINCT
                                                        ', ' + yf.Name + ' ['
                                                        + STUFF(( SELECT
                                                              ', ' + ys.Name
                                                              FROM
                                                              dbo.MASubmissionWorkstreamStrength ymas
                                                              JOIN dbo.tblStrength ys ON ys.StrengthID = ymas.StrengthID
                                                              WHERE
                                                              ymas.[MASubmissionWorkstreamID] = masw.[MASubmissionWorkstreamID]
                                                              FOR
                                                              XML
                                                              PATH('')
                                                              ), 1, 2, '')
                                                        + ']'
                                                FROM    dbo.MASubmissionWorkstreamStrength masws
                                                        JOIN dbo.tblStrength ys ON ys.StrengthID = masws.StrengthID
                                                        JOIN dbo.tblForm yf ON ys.FormID = yf.FormID
                                                        JOIN dbo.tblProduct yp ON yp.ProductID = yf.ProductID
                                                WHERE   masws.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                                              FOR
                                                XML PATH('')
                                              ), 1, 2, '') --ORDER BY yf.Name
                             ), 'N/A') AS [Product Strengths] ,

                    --COALESCE(( SELECT  DISTINCT
                    --                    yf.Name + ' ['
                    --                    + STUFF(( SELECT    ', ' + ys.Name
                    --                              FROM      MASubmissionWorkstreamStrength ymas
                    --                                        JOIN tblStrength ys ON ys.StrengthID = ymas.StrengthID
                    --                              WHERE     ymas.[MASubmissionWorkstreamID] = masw.[MASubmissionWorkstreamID]
                    --                            FOR
                    --                              XML PATH('')
                    --                            ), 1, 2, '') + ']'
                    --           FROM     dbo.MASubmissionWorkstreamStrength masws
                    --                    JOIN dbo.tblStrength ys ON ys.StrengthID = masws.StrengthID
                    --                    JOIN dbo.tblForm yf ON ys.FormID = yf.FormID
                    --                    JOIN dbo.tblProduct yp ON yp.ProductID = yf.ProductID
                    --           WHERE    masws.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                    --           --ORDER BY yf.Name
                    --         ), 'N/A') AS [Product Strengths] ,
                    masw.SubmissionTracking AS [Submission Tracking] ,
                    vmast.Name AS [Submission Type] ,
                    ( SELECT    comp.Name + ' - ' + br.Name
                      FROM      dbo.tblBrand br
                                JOIN dbo.tblCompany comp ON comp.CompanyID = br.BrandCompanyID
                      WHERE     br.BrandID = proj.BrandID
                      --br.FormID = proj.FormID
                      --          AND br.CountryID IN (
                      --          SELECT DISTINCT
                      --                  xsrc.CountryID
                      --          FROM    dbo.tblSubmissionRouteConfig xsrc
                      --          WHERE   xsrc.HealthAuthorityID = masw.MASubmissionWorkstreamID )
                    ) AS [Brand Name] ,
                    cg.Name AS [Project Region] ,
                    bbs.StateName AS [Project Status] ,
                    vdr.Name AS [Development Route] ,
                    devsite.Name [Development Site] ,
                    ma.ProcedureNumber [Application #] ,
                    vpr.[NAME] AS [Submission Route] ,
                    apt.NAME AS [Application Type] ,
                    MBBS.StateName AS [Submission Status] ,
                
                /* Need to fetch list of HA Action Items and it's related topics info for a specific HASubmissionWorkstreamID */
                --HA INFO START
                    --HAInfo.MAHAActionID ,
                    --CASE WHEN LEN(HATopics.Topics) <> 0
                    --     THEN SUBSTRING(HATopics.Topics, 0,
                    --                    ( LEN(HATopics.Topics) ))
                    --END AS [HATopics] ,
                    --HAInfo.ResponseDate AS [HAActionResponseDate] ,
                    --HAInfo.TargetResponseDate AS [HAActionTargetResponseDate] ,
                    --HAInfo.ReceivedDate ,
                    --HAInfo.MAHAActonStatus ,
                    ci.CorrespondenceInfo ,
				--HA INFO END
                    ( SELECT    CASE WHEN m.ReferenceMilestoneID IS NULL
                                     THEN m.BestEstimateDate
                                     ELSE refm.BestEstimateDate
                                END
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'Submission'
                    ) AS [Submission Date] ,
                    ( SELECT    vms.Name
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                       LEFT JOIN dbo.tblMilestone AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                       JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = COALESCE(ref.StatusID,
                                                              m.StatusID)
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'Submission'
                    ) AS [Submission Date Status] ,
                    --STUFF(( SELECT DISTINCT
                    --                ', '
                    --                + CONVERT(NVARCHAR(11), MIN(pe.ExpiryDate), 106)
                    --                + CASE WHEN c.Name IS NOT NULL
                    --                       THEN '[' + c.Name + ']'
                    --                  END
                    --        FROM      dbo.MASubmissionWorkstreamStrength zmas
                    --                JOIN dbo.tblStrength st ON zmas.StrengthID = st.StrengthID
                    --                JOIN pm.PatentExpiryLinkStrength slp ON slp.StrengthID = st.StrengthID
                    --                JOIN pm.PatentExpiry pe ON pe.PatentExpiryID = slp.PatentExpiryID
                    --                JOIN pm.LegalInfo li ON li.BlockingPatentID = pe.PatentID
                    --                                          AND li.CountryID IN (
                    --                                          SELECT
                    --                                          CountryID
                    --                                          FROM
                    --                                          dbo.tblSubmissionRouteConfig zsrc
                    --                                          WHERE
                    --                                          zsrc.HealthAuthorityID = masw.HealthAuthorityID )
                    --                LEFT JOIN dbo.tblCountry c ON li.CountryID = c.CountryID
                    --        WHERE   zmas.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                    --        GROUP BY c.Name
                    --      FOR
                    --        XML PATH('')
                    --      ), 1, 1, '') AS [Patent Date] ,
                    STUFF(( SELECT DISTINCT
                                    ', '
                                    + CONVERT(NVARCHAR(11), MIN(p.ExpiryDate), 106)
                                    + CASE WHEN c.Name IS NOT NULL
                                           THEN '[' + c.Name + ']'
                                      END
                            FROM      dbo.MASubmissionWorkstreamStrength zmas
                                    JOIN dbo.tblStrength st ON zmas.StrengthID = st.StrengthID
                                    JOIN pm.PatentLinkStrength slp ON slp.StrengthID = st.StrengthID
                                    JOIN pm.Patent p ON p.PatentID = slp.PatentID
                                    JOIN pm.LegalInfo li ON li.BlockingPatentID = p.PatentID
                                                              AND li.CountryID IN (
                                                              SELECT
                                                              CountryID
                                                              FROM
                                                              dbo.tblSubmissionRouteConfig zsrc
                                                              WHERE
                                                              zsrc.HealthAuthorityID = masw.HealthAuthorityID )
                                    LEFT JOIN dbo.tblCountry c ON li.CountryID = c.CountryID
                            WHERE   zmas.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                            GROUP BY c.Name
                          FOR
                            XML PATH('')
                          ), 1, 1, '') AS [Patent Date] ,
                    ( SELECT    MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                         THEN m.BestEstimateDate
                                         ELSE refm.BestEstimateDate
                                    END)
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'SW - Reg Proc Close'
                    ) AS [HATechnical(Tentative) Approval Date] ,
                    ( SELECT    vms.Name
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                       LEFT JOIN dbo.tblMilestone AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                       JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = COALESCE(ref.StatusID,
                                                              m.StatusID)
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'SW - Reg Proc Close'
                    ) AS [HATechnical(Tentative) Approval Status] ,
                    ( SELECT    MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                         THEN m.BestEstimateDate
                                         ELSE refm.BestEstimateDate
                                    END)
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'SW - Final Reg Approval'
                    ) AS [Final Regulatory Approval Date] ,
                    ( SELECT    vms.Name
                      FROM      dbo.tblGlobalMilestone gm
                                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                JOIN ( dbo.tblMilestone m
                                       JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                       LEFT JOIN dbo.tblMilestone AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                       JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = COALESCE(ref.StatusID,
                                                              m.StatusID)
                                     ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                          AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                      WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                                AND m.BBOID = @BBOID
                                AND gm.Code = 'SW - Final Reg Approval'
                    ) AS [Final Regulatory Approval Status] ,
                    ( SELECT    MIN(m.BestEstimateDate)
                      FROM      dbo.tblMilestone m
                                JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                JOIN dbo.tblGlobalMilestone gm ON mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                JOIN dbo.tblMilestone m2 ON m2.ObjectID = m.ObjectID
                                JOIN dbo.tblMilestoneTemplateItem mti2 ON m2.MilestoneTemplateItemID = mti2.MilestoneTemplateItemID
                                JOIN dbo.tblGlobalMilestone gm2 ON mti2.GlobalMilestoneID = gm2.GlobalMileStoneID
                                JOIN dbo.tblMilestone m3 ON m2.ReferenceMilestoneID = m3.MileStoneID
                      WHERE     m3.ObjectID = masw.MASubmissionWorkstreamID
                                AND gm.Code = 'Launch'
                                AND m.BBOID = @LaunchBBOID
                                AND gm2.Code = 'Submission'
                                AND m2.BBOID = @LaunchBBOID
                                AND m3.BBOID = @BBOID
                    ) AS Launch ,
                    ( SELECT TOP(1)
                                vms.Name
                      FROM      dbo.tblMilestone m
                                JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                JOIN dbo.tblGlobalMilestone gm ON mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                JOIN dbo.tblMilestone m2 ON m2.ObjectID = m.ObjectID
                                JOIN dbo.tblMilestoneTemplateItem mti2 ON m2.MilestoneTemplateItemID = mti2.MilestoneTemplateItemID
                                JOIN dbo.tblGlobalMilestone gm2 ON mti2.GlobalMilestoneID = gm2.GlobalMileStoneID
                                JOIN dbo.tblMilestone m3 ON m2.ReferenceMilestoneID = m3.MileStoneID
                      WHERE     m3.ObjectID = masw.MASubmissionWorkstreamID
                                AND gm.Code = 'Launch'
                                AND m.BBOID = @LaunchBBOID
                                AND gm2.Code = 'Submission'
                                AND m2.BBOID = @LaunchBBOID
                                AND m3.BBOID = @BBOID
                                AND m.BestEstimateDate IS NOT NULL
                      ORDER BY  m.BestEstimateDate
                    ) AS [Launch Status] ,
                    mapcnt.PendingMACount AS [# of Market Authorizations] ,
                    DATEDIFF(DAY, GETDATE(),
                             ( SELECT   MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                                 THEN m.BestEstimateDate
                                                 ELSE refm.BestEstimateDate
                                            END)
                               FROM     dbo.tblGlobalMilestone gm
                                        JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                        JOIN ( dbo.tblMilestone m
                                               JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                             ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                                  AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                        LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                               WHERE    m.ObjectID = masw.MASubmissionWorkstreamID
                                        AND m.BBOID = @BBOID
                                        AND gm.Code = 'SW - Final Reg Approval'
                             )) AS [Days to Approval] ,
                    DATEDIFF(DAY,
                             ( SELECT   MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                                 THEN m.BestEstimateDate
                                                 ELSE refm.BestEstimateDate
                                            END)
                               FROM     dbo.tblGlobalMilestone gm
                                        JOIN ( dbo.tblMilestone m
                                               JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                             ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                                  AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                        JOIN dbo.tblMilestoneTemplate mt ON mti.MilestoneTemplateID = mt.MilestoneTemplateID
                                        JOIN dbo.tblBusinessBaseObject bbo ON mt.BBOID = bbo.BBOID
                                        LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                               WHERE    m.ObjectID = masw.MASubmissionWorkstreamID
                                        AND bbo.BBOCode = 'SW'
                                        AND gm.Code = 'Submission'  
                             ),
                             ( SELECT   MIN(mahaa.ReceivedDate)
                               FROM     dbo.MAHAAction mahaa
                                        LEFT JOIN dbo.tblValidMAHAActionScope vmahaa ON vmahaa.ValidMAHAActionScopeID = mahaa.ValidMAHAActionScopeID
                               WHERE    masw.MASubmissionWorkstreamID = mahaa.MASubmissionWorkstreamID
                             )) AS [Days Between Submission and First HA Action] ,
                    DATEDIFF(DAY,
                             ( SELECT   MIN(mahaa.ReceivedDate)
                               FROM     dbo.MAHAAction mahaa
                                        LEFT JOIN dbo.tblValidMAHAActionScope vmahaa ON vmahaa.ValidMAHAActionScopeID = mahaa.ValidMAHAActionScopeID
                               WHERE    masw.MASubmissionWorkstreamID = mahaa.MASubmissionWorkstreamID
                             ),
                             ( SELECT   MIN(mahaa.ResponseDate)
                               FROM     dbo.MAHAAction mahaa
                                        LEFT JOIN dbo.tblValidMAHAActionScope vmahaa ON vmahaa.ValidMAHAActionScopeID = mahaa.ValidMAHAActionScopeID
                               WHERE    masw.MASubmissionWorkstreamID = mahaa.MASubmissionWorkstreamID
                             )) AS [Days Between First HA and First Mylan Response] ,
                    masw.Comments AS [Comment] ,
                    proj.ExpectedMylLaunchDate ,
                    masw.WorkstreamName
            FROM    #EMCS fmsw
                    JOIN dbo.MASubmissionWorkstream masw ON masw.MASubmissionWorkstreamID = fmsw.MASubmissionWorkstreamID
                    JOIN dbo.tblMAApplication ma ON ma.MAApplicationID = masw.MAApplicationID
                    JOIN dbo.tblProduct p ON p.ProductID = ma.ProductGroupID
                    JOIN dbo.tblCompany ha ON ha.CompanyID = masw.HealthAuthorityID
                    JOIN dbo.tblSubmissionRoute vpr ON ma.SubmissionRouteID = vpr.SubmissionRouteID
                    JOIN dbo.tblBusinessBaseStates MBBS ON MBBS.StateID = masw.MASubmissionWorkstreamStatusID
                    JOIN dbo.tblValidMASubmissionType vmast ON masw.ValidMASubmissionTypeID = vmast.ValidMASubmissionTypeID
                    JOIN dbo.tblValidApplicationType apt ON ma.ValidApplicationTypeID = apt.ValidApplicationTypeID
                    LEFT JOIN pm.Project proj ON masw.ProjectID = proj.ProjectID
                    LEFT JOIN dbo.tblForm f ON proj.FormID = f.FormID
                    LEFT JOIN dbo.tblCountryGroup cg ON proj.CountryGroupID = cg.CountryGroupID
                    LEFT JOIN dbo.tblBusinessBaseStates bbs ON proj.ProjectStatusID = bbs.StateID
                    LEFT JOIN dbo.tblValidDevelopmentRoute vdr ON ma.ValidDevelopmentRouteID = vdr.ValidDevelopmentRouteID
                    LEFT JOIN #CORRESPONDENCE ci ON masw.MASubmissionWorkstreamID = ci.MASubmissionWorkstreamID
                    LEFT JOIN dbo.CompanyNameWithCountry devsite ON devsite.companyid = ma.DevelopmentSiteID  
                    LEFT JOIN dbo.tblCountry hacc ON hacc.CountryID = ha.CountryID
                    LEFT JOIN #MAPCOUNT mapcnt ON mapcnt.MASubmissionWorkstreamID = fmsw.MASubmissionWorkstreamID
                    
-- All the joins below here have to go
                    LEFT JOIN HATopics ON masw.MASubmissionWorkstreamID = HATopics.MASubmissionWorkstreamID
                    LEFT JOIN HAInfo ON masw.MASubmissionWorkstreamID = HAInfo.MASubmissionWorkstreamID
                                        AND HAInfo.MAHAActionID = HATopics.MAHAActionID
            ORDER BY --p.Name ,
                   5,
                    masw.MASubmissionWorkstreamID

        IF OBJECT_ID('tempdb..#EMCS') IS NOT NULL
            DROP TABLE #EMCS            
    
        IF OBJECT_ID('tempdb..#Correspondence') IS NOT NULL
            DROP TABLE #CORRESPONDENCE
    END TRY

    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise	
    END  CATCH
GO
