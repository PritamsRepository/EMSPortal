SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
CREATE Procedure [dbo].[ddl_Country_GetCountries] @UserID INT = NULL, @PrivCode NVARCHAR(10) = NULL, @CountryID INT = NULL 
AS
 
/*
 
CREATED BY:			JRG
CREATED DATE:		DEC 06, 2010
;
Sprint Item:		555
PURPOSE:			Returns a distinct list of Countries
 
 Unique index created on tblcountry country name too
 
*/
 
BEGIN TRY
 SELECT DISTINCT CountryID, Name AS Country FROM dbo.tblCountry
 WHERE
	((@UserID IS NULL AND @PrivCode IS NULL) OR 
	dbo.udf_UserHasPrivForCountry(@UserID, @PrivCode, CountryID) = 1)
 UNION
 SELECT CountryID, Name As Country FROM dbo.tblCountry
 WHERE CountryID = @CountryID
 ORDER BY Name
END TRY
 
 
BEGIN CATCH
	EXEC SP_ROLLANDRAISE
END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_Country_GetCountries] TO [mp_db_execute]
GO
