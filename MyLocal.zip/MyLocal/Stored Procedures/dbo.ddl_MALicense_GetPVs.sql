SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MALicense_GetPVs]
  @UserID INT = NULL

AS

BEGIN TRY 

  DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
  DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';
  				
  SELECT DISTINCT
	(CASE 
	  WHEN C.Name = @PrimarySortPriority THEN 0
	  WHEN dbo.udf_MA_FormatCompanies(MAL.PharmacovigilanceResponsibilityID) LIKE @SecondarySortPriority THEN 1
	  ELSE 2 
	  END
	) AS SortPriority,
	MAL.PharmacovigilanceResponsibilityID AS ID,	
	dbo.udf_MA_FormatCompanies(MAL.PharmacovigilanceResponsibilityID) AS Name
  FROM
	dbo.tblMALicense MAL
	  JOIN dbo.tblMAApplication MAA ON MAL.MAApplicationID = MAA.MAApplicationID
	  JOIN tblCompany C ON MAL.PharmacovigilanceResponsibilityID = C.CompanyID
  ORDER BY
	  SortPriority,
	  Name;
	
END TRY
BEGIN CATCH
	EXECUTE [dbo].[sp_RollAndRaise]
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicense_GetPVs] TO [mp_db_execute]
GO
