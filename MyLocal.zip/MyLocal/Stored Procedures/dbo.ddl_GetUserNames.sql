SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ddl_GetUserNames]
AS
/*===========================================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS CONSULTANT
CREATED ON:				DEC 15, 2009		
MODIFIED BY:				
MODIFIED ON:	
PURPOSE:					The purpose of this procedure is to get all of the names of all of the users with a security role.
-----------------------------------------------------------------------------------------------------------------------
EXAMPLE:					EXECUTE ddl_GetUserFullNames
===========================================================================================*/

BEGIN TRY

		SELECT DISTINCT 
			su.UserID,
			su.ADUserName as UserName
		FROM
			admin_SecUser su
				inner join admin_SecUserRole sur on su.UserID = sur.UserID
		WHERE 
		-- Do not show Mary Yvonne Presley.
			su.UserID <> 1
		ORDER BY
			ADUserName
END TRY

BEGIN CATCH
	EXEC sp_RollAndRaise
END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_GetUserNames] TO [mp_db_execute]
GO
