SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MASiteByCompanyGroup]
    @MAApplicationID INT ,
    @ValidSiteTypeID INT ,
    @CompanyID INT = NULL
AS 
    BEGIN TRY

DECLARE @CompanyName NVARCHAR(128)
DECLARE @Spc NCHAR(3) = ' : '
DECLARE @PreFix NCHAR(5) = 'Mylan'
DECLARE @NA NCHAR(3) = ''

	/* New drop down to only show items not already assigend to an MA App with the same company group type*/
	DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
	DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';


	SELECT DISTINCT
			(
				CASE 
				WHEN c.Name = @PrimarySortPriority THEN 0
				WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
				ELSE 2 
				END
			) AS SortPriority,
			dbo.udf_MA_FormatCompanies(c.CompanyID) AS Name ,
			c.CompanyID
		FROM tblCompany c 
		JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
		JOIN tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
		JOIN tblValidSiteType st ON cg.[Text] = st.Name
		WHERE   st.ValidSiteTypeID = @ValidSiteTypeID 
	UNION
		SELECT
			(
				CASE 
				WHEN c.Name = @PrimarySortPriority THEN 0
				WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
				ELSE 2 
				END
			) AS SortPriority,
			dbo.udf_MA_FormatCompanies(c.CompanyID) AS Name ,
			c.CompanyID
		FROM tblCompany c 
		WHERE c.CompanyID = @CompanyID 
	EXCEPT
		SELECT DISTINCT
			(
				CASE 
				WHEN c.Name = @PrimarySortPriority THEN 0
				WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
				ELSE 2 
				END
			) AS SortPriority,
			dbo.udf_MA_FormatCompanies(c.CompanyID) AS Name ,
			MAS.CompanyID
		FROM dbo.tblMASite MAS
		JOIN dbo.tblCompany c ON MAS.CompanyID = c.CompanyID
		WHERE     MAS.MAApplicationID = @MAApplicationID 
		AND MAS.ValidSiteTypeID = @ValidSiteTypeID 
	ORDER BY SortPriority, Name
		
END TRY
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MASiteByCompanyGroup] TO [mp_db_execute]
GO
