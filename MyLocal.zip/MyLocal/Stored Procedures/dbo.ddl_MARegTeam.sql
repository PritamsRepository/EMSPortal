SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MARegTeam]
  @UserID INT = NULL

AS /* 
Author:	JRG
Desc:	Drop dopwn list for Reg Team on MA Application
		only return rows that exist in the table 
Date:	2011-05-31
*/
    BEGIN TRY 
        DECLARE @CompanyName NVARCHAR(128)
        DECLARE @Spc NCHAR(3) = ' : '
        DECLARE @PreFix NCHAR(5) = 'Mylan'
        DECLARE @NA NCHAR(3) = ''

        DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
        DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';
						
        SELECT DISTINCT
                ( CASE WHEN c1.Name = @PrimarySortPriority THEN 0
                       WHEN ( SELECT    CASE WHEN c.IsThirdParty = 0 THEN @PreFix + @Spc
                                             ELSE ''
                                        END + C.name /*+ @Spc*/ + CASE WHEN co.Code IS NULL THEN @NA
                                                                       ELSE @Spc + co.Code
                                                                  END AS Company
                              FROM      dbo.tblCompany C
                                        LEFT JOIN dbo.tblCountry Co ON C.CountryID = Co.CountryID
                              WHERE     C.CompanyID = MA.RegulatoryTeamID ) LIKE @SecondarySortPriority THEN 1
                       ELSE 2
                  END ) AS SortPriority ,
                MA.RegulatoryTeamID ,
                c1.Name ,
                ( SELECT    CASE WHEN c.IsThirdParty = 0 THEN @PreFix + @Spc
                                 ELSE ''
                            END + C.name /*+ @Spc*/ + CASE WHEN co.Code IS NULL THEN @NA
                                                           ELSE @Spc + co.Code
                                                      END AS Company
                  FROM      dbo.tblCompany C
                            LEFT JOIN dbo.tblCountry Co ON C.CountryID = Co.CountryID
                  WHERE     C.CompanyID = MA.RegulatoryTeamID ) AS RegulatoryTeam
		  /*JRG search for this to find all updates 9E2C5239-C06D-4897-A30B-00F88AB9B416 
		  replace this dbo.udf_MA_FormatCompanies(MA.RegulatoryTeamID) AS RegulatoryTeam */
        FROM    dbo.tblMAApplication MA
                JOIN dbo.tblCompany C1 ON MA.RegulatoryTeamID = C1.CompanyID
        ORDER BY SortPriority ,
                RegulatoryTeam
        
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MARegTeam] TO [mp_db_execute]
GO
