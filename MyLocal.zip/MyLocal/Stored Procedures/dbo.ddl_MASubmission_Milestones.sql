SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MASubmission_Milestones] 
(							
  @MASubmissionWorkstreamID int
)
AS


BEGIN TRY
			DECLARE @BBOID int
			Select @BBOID= bboid from tblBusinessBaseObject where BBOCode = 'SW'	
		SELECT 
			m.MilestoneID,
			(gm.Code + ' - ' + gm.Name) AS Name
		FROM 
		  tblMilestone m
			 JOIN tblMilestoneTemplateItem mti ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
			JOIN tblGlobalMilestone gm on gm.GlobalMilestoneID	= mti.GlobalMilestoneID
		WHERE m.BBOID = @BBOID and m.ObjectID = @MASubmissionWorkstreamID
		
	
		ORDER BY
		  mti.DisplayOrder
			
END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MASubmission_Milestones] TO [mp_db_execute]
GO
