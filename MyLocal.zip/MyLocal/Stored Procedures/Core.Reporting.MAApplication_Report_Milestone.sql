SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Milestone]
    (
      @MAApplicationID INT = NULL ,
      @Country NVARCHAR(MAX) = NULL ,
      @Region NVARCHAR(MAX) = NULL
    )
AS
    BEGIN
        DECLARE @CountryID INT = ( SELECT   CountryID
                                   FROM     dbo.tblCountry
                                   WHERE    Code = @Country
                                 )

        DECLARE @CountryGroupID INT = ( SELECT  CountryGroupID
                                        FROM    dbo.tblCountryGroup
                                        WHERE   CountryGroupType = 'MAMkt'
                                                AND Name = @Region
                                      )
        DECLARE @swbboid INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'SW'
                               )

        SELECT  m.MileStoneID ,
                masw.MAApplicationID ,
                m.ObjectID AS [MASubmissionID] ,
                gm.Name AS [Milestone] ,
                vms.Name AS [Status] ,
                CASE WHEN m.ReferenceMilestoneID IS NULL
                     THEN REPLACE(CONVERT(VARCHAR(15), m.BestEstimateDate, 106),
                                  ' ', '-')
                     ELSE REPLACE(CONVERT(VARCHAR(15), refm.BestEstimateDate, 106),
                                  ' ', '-')
                END AS [Date]
        FROM    dbo.tblMilestone m
                JOIN dbo.tblMilestoneTemplateItem mti ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                JOIN dbo.tblGlobalMilestone gm ON gm.GlobalMileStoneID = mti.GlobalMilestoneID
                JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                JOIN dbo.MASubmissionWorkstream masw ON masw.MASubmissionWorkstreamID = m.ObjectID
				JOIN dbo.tblCompany ha ON ha.CompanyID = masw.HealthAuthorityID
                LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
        WHERE   m.BBOID = @swbboid
                AND ( @MAApplicationID IS NULL
                      OR masw.MAApplicationID = @MAApplicationID
                    )
                AND ( @CountryID IS NULL
                      OR @CountryID = ha.CountryID
                    )
                AND ( @CountryGroupID IS NULL
                      OR @CountryGroupID IN ( SELECT cg.CountryGroupID
                                             FROM   dbo.tblCountryLinkCountryGroup clcg
                                                    JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
                                             WHERE  CountryID = ha.CountryID
											 AND CountryGroupType = 'MAMkt'
                                           )
                    )
    END
GO
