SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Attachment_Update]
    @ID INT,
    @Name NVARCHAR(256),
    @ValidFileExtID INT,
    @ObjectID INT,
    @OriginalFileName NVARCHAR(256) = NULL,
    @Comment NVARCHAR(MAX) = NULL,
    @BBOID INT,
    @URL NVARCHAR(1024),
    @ConcurrencyID TIMESTAMP,
    @UpdateUserID INT
AS
BEGIN

    DECLARE @ActionType CHAR(1);
    DECLARE @RowsAffected INT;
    DECLARE @ConcurIDinDB TIMESTAMP;
    DECLARE @BBOCode NVARCHAR(50);

    BEGIN TRANSACTION;
    SELECT @ConcurIDinDB = ConcurrencyID
    FROM dbo.tblAttachment
    WHERE AttachmentID = @ID;

    SELECT @BBOCode = BBOCode
    FROM dbo.tblBusinessBaseObject
    WHERE BBOID = @BBOID;

    IF @ConcurIDinDB IS NULL
    BEGIN
        EXEC dbo.sp_RaiseCustomError 2;
    END;
    ELSE IF @ConcurIDinDB <> @ConcurrencyID
    BEGIN
        EXEC dbo.sp_RaiseCustomError 1;
    END;

    BEGIN
        UPDATE dbo.tblAttachment
        SET ValidFileExtID = @ValidFileExtID,
            BBOID = @BBOID,
            ObjectID = @ObjectID,
            Name = @Name,
            OriginalFileName = @OriginalFileName,
            Comment = @Comment,
            URL = @URL,
            UpdateUserID = @UpdateUserID,
            UpdateDate = GETDATE()
        WHERE AttachmentID = @ID
              AND ConcurrencyID = @ConcurrencyID;

        SET @RowsAffected = @@ROWCOUNT;
        IF @RowsAffected = 0
            EXEC sp_RaiseCustomError 3;

        --SET @ReturnValue = @ID
        SET @ActionType = 'U';
    END;

    SELECT --@ReturnValue AS ID,
        ConcurrencyID
    FROM dbo.tblAttachment
    WHERE AttachmentID = @ID;

    /* Audit information */
    IF (@RowsAffected = 1)
    BEGIN
        EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                                                 @UserID = @UpdateUserID,
                                                 @ObjectID = @ObjectID,
                                                 @ActionType = @ActionType;

    END;
    COMMIT TRANSACTION;
    RETURN 0;
END;
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Attachment_Update] TO [mp_db_execute]
GO
