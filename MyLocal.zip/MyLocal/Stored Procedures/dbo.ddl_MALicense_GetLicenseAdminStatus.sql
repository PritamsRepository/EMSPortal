SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicense_GetLicenseAdminStatus]
  @UserID INT = NULL

AS 
BEGIN TRY

  SELECT DISTINCT
	v.ValidMAAdminStatusID AS ID,
    v.Name
  FROM
	dbo.tblValidMAAdminStatus v
    JOIN dbo.tblMALicense l ON v.ValidMAAdminStatusID = l.ValidMAAdminStatusID
    JOIN dbo.tblMAApplication maa ON l.MAApplicationID = maa.MAApplicationID 
    
END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicense_GetLicenseAdminStatus] TO [mp_db_execute]
GO
