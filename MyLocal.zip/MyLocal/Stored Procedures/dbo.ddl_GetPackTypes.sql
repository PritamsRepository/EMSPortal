SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_GetPackTypes]
AS
BEGIN TRY 

	SELECT ValidMAPackTypeID packTypeID ,
		Name PackType
	FROM dbo.tblValidMAPackType
	ORDER BY Name

END TRY 
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_GetPackTypes] TO [mp_db_execute]
GO
