SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
create PROCEDURE [Core.Common.Filter].[GetProjectProductsByName]
	@Name nvarchar(256) = NULL
AS
	SELECT DISTINCT
		p.ProductID AS ID,
		p.Name
	FROM
		dbo.tblProduct p
			JOIN dbo.tblForm f ON p.ProductID = f.ProductID
			JOIN PM.Project pr ON pr.FormID = f.FormID
	WHERE 
		(@Name IS NULL OR p.Name LIKE @Name + '%')
	ORDER BY
		p.Name;
GO
