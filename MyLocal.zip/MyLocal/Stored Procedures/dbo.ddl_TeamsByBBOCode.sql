SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_TeamsByBBOCode](@BBOCode nvarchar(25))
as
/**********************************************************************************
ARD; DropDown to get all the Teams for a give BBO
**********************************************************************************/

BEGIN TRY 

	SELECT     
		t.TeamID as ID, 
		t.NAME

	FROM         
		tblBusinessBaseObject bbo
		INNER JOIN
        tblTeam t ON bbo.BBOID = t.BBOID
WHERE     (bbo.BBOCode = @BBOCode)
	
END TRY


BEGIN CATCH
	EXECUTE [dbo].[sp_RollAndRaise]
END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_TeamsByBBOCode] TO [mp_db_execute]
GO
