SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MASubmissionByApplicationID] @MAApplicationID INT
AS
    BEGIN TRY    
    
        DECLARE @BBOID INT = ( SELECT   BBOID
                               FROM     dbo.tblBusinessBaseObject
                               WHERE    BBOCode = 'SW'
                             );
    
        SELECT  sw.MASubmissionWorkstreamID AS ID ,
                ( sw.WorkstreamName + '-' + ISNULL(sr.Category, 'N/A') + '-'
                  + vst.Name + ISNULL(( '-' + sw.SubmissionTracking ), '')
                  + ( ' [' + bbs.StateName + ']' ) + ( ': '
                                                       + COALESCE(ha.ShortName,
                                                              ha.Name) )
                  + ISNULL(( ' [' + c.Code + ']' ), '') ) AS Name
        FROM    dbo.MASubmissionWorkstream sw
                JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = sw.MASubmissionWorkstreamStatusID
                JOIN dbo.tblSubmissionRoute sr ON sr.SubmissionRouteID = sw.SubmissionRouteID
                JOIN dbo.tblValidMASubmissionType vst ON vst.ValidMASubmissionTypeID = sw.ValidMASubmissionTypeID
                JOIN dbo.tblCompany ha ON ha.CompanyID = sw.HealthAuthorityID
                LEFT JOIN dbo.tblCountry c ON c.CountryID = ha.CountryID
        WHERE   sw.MAApplicationID = @MAApplicationID;
    
    END  TRY
    BEGIN CATCH

        EXEC dbo.sp_RollAndRaise;
    
    END CATCH
GO
