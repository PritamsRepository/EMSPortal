SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_CompanyByCompanyGroupByCountry] 
(							
  @CompanyGroup NVARCHAR(256),
  @CompanyID INT = NULL
)
AS


BEGIN TRY
				
		SELECT DISTINCT		  
		  c.CompanyID,
		  c.Name,
		 (case when co.Code is NULL THEN COALESCE(ShortName,'N/A') ELSE co.Code END  + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c 
			INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
			INNER JOIN tblCompanyGroup cg ON  clcg.CompanyGroupID = cg.CompanyGroupID
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID					
		WHERE cg.[Text] = @CompanyGroup
	
		UNION
		
		SELECT		  
		  c.CompanyID,
		  c.Name,
		 (case when co.Code is NULL THEN COALESCE(ShortName,'N/A') ELSE co.Code END  + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE 
		  CompanyID = @CompanyID
		ORDER BY
		  FullName;
			
END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_CompanyByCompanyGroupByCountry] TO [mp_db_execute]
GO
