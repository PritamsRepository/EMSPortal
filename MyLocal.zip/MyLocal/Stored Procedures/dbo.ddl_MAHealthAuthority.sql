SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAHealthAuthority]
  @UserID INT = NULL

AS 
/* 
Author:	JRG
Desc:	Drop dopwn list for HealthAuthority on MA Application
		only return rows that exist in the table 
Date:	2011-05-31
*/
    BEGIN TRY 
        SELECT  DISTINCT HealthAuthorityID AS CompanyID,
                C1.Name AS  Company,
                Cy.Name AS Country
        FROM    dbo.tblMAApplication MA
                JOIN dbo.tblCompany C1 ON MA.HealthAuthorityID = C1.CompanyID
                LEFT JOIN dbo.tblCountry Cy ON C1.CountryID = Cy.CountryID
        ORDER BY C1.Name
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAHealthAuthority] TO [mp_db_execute]
GO
