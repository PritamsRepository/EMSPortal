SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Attachment_Insert]
    @Name NVARCHAR(256),
    @ValidFileExtID INT,
    @ObjectID INT,
    @BBOID INT,
    @OriginalFileName NVARCHAR(256) = NULL,
    @Comment NVARCHAR(MAX) = NULL,
    @URL NVARCHAR(1024) = NULL,
    @UpdateUserID INT
AS 
    BEGIN
        DECLARE @ReturnValue INT,
            @ActionType CHAR(1),
            @RowsAffected INT,
            @ConcurIDinDB TIMESTAMP,
            @BBOCode NVARCHAR(50)

        SET @BBOCode = ( SELECT BBOCODE
                         FROM   dbo.tblBusinessBaseObject
                         WHERE  BBOID = @BBOID
                       )

        BEGIN TRAN AddAttachment
		
        INSERT  INTO dbo.tblAttachment
                ( ValidFileExtID,
                  BBOID,
                  ObjectID,
                  Name,
                  OriginalFileName,
                  Comment,
                  URL,
                  UpdateUserID,
                  UpdateDate
                )
        VALUES  ( @ValidFileExtID,
                  @BBOID,
                  @ObjectID,
                  @Name,
                  @OriginalFileName,
                  @Comment,
                  @URL,
                  @UpdateUserID,
                  GETDATE()
                )
					
        SET @RowsAffected = @@ROWCOUNT;
        SET @ActionType = 'I'
        SET @ReturnValue = SCOPE_IDENTITY()
        SELECT  @ReturnValue AS ID, ConcurrencyID
        FROM dbo.tblAttachment WHERE AttachmentID = @ReturnValue
                
        IF ( @RowsAffected = 0 ) 
            BEGIN
                EXEC dbo.sp_RaiseCustomError 3
            END
            
        /* Audit information */  
        IF ( @RowsAffected = 1 ) 
            BEGIN
                EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                    @UserID = @UpdateUserID, @ObjectID = @ReturnValue,
                    @ActionType = @ActionType
            END
        COMMIT;
        RETURN @ReturnValue;
    END


GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Attachment_Insert] TO [mp_db_execute]
GO
