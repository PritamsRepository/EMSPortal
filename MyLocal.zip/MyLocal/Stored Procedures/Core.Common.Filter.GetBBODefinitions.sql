SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetBBODefinitions] 
AS
    SELECT	BBOID, 
			BBOCode, 
			BBOName, 
			DisplayName, 
			TemplateName,
			IsGxP,
			IsTemplateAuditable 
    FROM dbo.tblBusinessBaseObject AS BBO 
GO
