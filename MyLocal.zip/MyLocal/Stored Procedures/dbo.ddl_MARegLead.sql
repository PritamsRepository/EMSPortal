SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MARegLead]
  @UserID INT = NULL

AS /* 
Desc:	Drop dopwn list for Reg Lead on MA Application
		Only return rows for users in the 'Regulatory Lead' Role.
*/
    BEGIN TRY 
    
       SELECT DISTINCT 
				SUR.UserID AS UserID,
                CASE WHEN SU.FullName IS NULL
						  OR SU.FullName = '' OR LEN(SU.fullname) <2 THEN SU.ADUserName
                     ELSE SU.FullName
                END AS FullName
        FROM    dbo.admin_SecUser SU
                JOIN dbo.admin_SecUserRole SUR ON SU.UserID = SUR.UserID
                JOIN dbo.admin_SecRole SR ON SUR.RoleID = SR.RoleID
        WHERE
				SR.Name = 'Regulatory Lead'
		
		UNION
				
		SELECT DISTINCT
				SUR.UserID AS UserID,
                CASE WHEN SU.FullName IS NULL
						  OR SU.FullName = '' OR LEN(SU.fullname) <2 THEN SU.ADUserName
                     ELSE SU.FullName
                END AS FullName
		FROM
		   dbo.tblMAApplication MAA
			JOIN dbo.admin_SecUser SU ON MAA.RegulatoryLeadID = SU.UserID
            JOIN dbo.admin_SecUserRole SUR ON SU.UserID = SUR.UserID
            JOIN dbo.admin_SecRole SR ON SUR.RoleID = SR.RoleID               
        ORDER BY FullName

    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MARegLead] TO [mp_db_execute]
GO
