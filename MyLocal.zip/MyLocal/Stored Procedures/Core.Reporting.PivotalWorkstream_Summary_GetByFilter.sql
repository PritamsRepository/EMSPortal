SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC [Core.Reporting].PivotalWorkstream_Summary_GetByFilter @UserId = 1426, @PrivCode = 'MA01'

CREATE PROCEDURE [Core.Reporting].[PivotalWorkstream_Summary_GetByFilter]
    @ID INT = NULL,
    @ProjectID INT = NULL,
    @ProductGroupID INT = NULL,
    @PivotalWorkstreamStatusID INT = NULL,
    @CountryGroupFiltersList NVARCHAR(MAX) = NULL,
    @BBOTagFiltersList NVARCHAR(MAX) = NULL,
    @SubmissionYearFiltersList NVARCHAR(MAX) = NULL,
    @FormFiltersList NVARCHAR(MAX) = NULL,
    @LeadID INT = NULL,
    @ParentID INT = NULL,
    @ParentType INT = NULL,
    @UserId INT,
    @PrivCode NVARCHAR(10),
    @FormFiltersInclusionID INT = 1,
    @CountryGroupFiltersInclusionID INT = 1,
    @LeadInclusionID INT = 1,
    @SubmissionYearFiltersInclusionID INT = 1,
    @PivotalWorkstreamStatusInclusionID INT = 1,
    @BBOTagFiltersInclusionID INT = 1,
    @SiteCompanyGroups NVARCHAR(MAX) = NULL,
    @SiteFiltersList NVARCHAR(MAX) = NULL,
    @SiteNameFiltersInclusionID INT = 1
AS
BEGIN
    --pivotal
    DECLARE @BBOID INT;
    SELECT @BBOID = BBOID
    FROM dbo.tblBusinessBaseObject
    WHERE BBOCode = 'PVW';

    --pilot                     
    DECLARE @PLWBBOID INT;
    SELECT @PLWBBOID = BBOID
    FROM dbo.tblBusinessBaseObject
    WHERE BBOCode = 'PLW';

    --project                       
    DECLARE @PJBBOID INT;
    SELECT @PJBBOID = BBOID
    FROM dbo.tblBusinessBaseObject
    WHERE BBOCode = 'PJM';

    --submission
    DECLARE @SWBBOID INT;
    SELECT @SWBBOID = BBOID
    FROM dbo.tblBusinessBaseObject
    WHERE BBOCode = 'SW';

    DECLARE @IsUnrestricted INT;
    SELECT @IsUnrestricted = COUNT(sur.IsUnrestricted)
    FROM dbo.admin_SecRolePriv srp
        JOIN dbo.admin_SecPriv sp
            ON srp.PrivID = sp.PrivID
        JOIN dbo.admin_SecUserRole sur
            ON sur.RoleID = srp.RoleID
    WHERE sp.PrivCode = @PrivCode
          AND sur.UserID = @UserId;

    DECLARE @IncludeScaleUpSites INT = CHARINDEX('Scale Up Site', @SiteCompanyGroups);
    DECLARE @IncludeDevelopmentSites INT = CHARINDEX('Development Site', @SiteCompanyGroups);
    DECLARE @IncludePackagingSites INT = CHARINDEX('Packaging Site', @SiteCompanyGroups);
    DECLARE @IncludeManufacturingSites INT = CHARINDEX('Manufacturing Site', @SiteCompanyGroups);

    DECLARE @CountryGroupFilters CountryGroupType;
    DECLARE @FormFilters FormType;
    DECLARE @BBOTagFilters BBOTagType;
    DECLARE @SubmissionYearFilters TimeframeType;
    DECLARE @SiteFilters IdType;

    IF LEN(@CountryGroupFiltersList) > 0
        INSERT INTO @CountryGroupFilters
        (
            CountryGroupID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList);

    IF LEN(@SiteFiltersList) > 0
        INSERT @SiteFilters
        (
            Id
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@SiteFiltersList);

    IF LEN(@BBOTagFiltersList) > 0
        INSERT @BBOTagFilters
        (
            BBOTagID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@BBOTagFiltersList);

    IF LEN(@SubmissionYearFiltersList) > 0
        INSERT @SubmissionYearFilters
        (
            Timeframe
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList);

    IF LEN(@FormFiltersList) > 0
        INSERT @FormFilters
        (
            FormID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@FormFiltersList);

    IF OBJECT_ID('tempdb..#ExpiryCountryGroups') IS NOT NULL
    BEGIN
        DROP TABLE #ExpiryCountryGroups;
    END;

    CREATE TABLE #ExpiryCountryGroups
    (
        CountryGroupID INT NOT NULL
    );

    CREATE CLUSTERED INDEX IX_temp_CountryGroupID
    ON #ExpiryCountryGroups (CountryGroupID);

    INSERT INTO #ExpiryCountryGroups
    (
        CountryGroupID
    )
    SELECT CountryGroupID
    FROM dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserId, @PrivCode)
    WHERE Privs = 1;

    --pivotal template milestones
    WITH pwms (PivotalWorkstreamID, BBOCode, MilestoneName, MilestoneStatus, EstimatedDate, DisplayOrder)
    AS (SELECT DISTINCT
               pw.PivotalWorkstreamID,
               bbo.BBOCode,
               mti.Name,
               vms.Name,
               CASE
                   WHEN m.ReferenceMilestoneID IS NULL THEN
                       m.BestEstimateDate
                   ELSE
                       refm.BestEstimateDate
               END,
               mti.DisplayOrder
        FROM pm.PivotalWorkstream pw
            JOIN dbo.tblMilestoneTemplateItem AS mti
                ON mti.MilestoneTemplateID = pw.MilestoneTemplateID
            JOIN dbo.tblMilestone AS m
                ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                   AND m.ObjectID = pw.PivotalWorkstreamID
                   AND m.BBOID = @BBOID
            JOIN dbo.tblGlobalMilestone AS gm
                ON mti.GlobalMilestoneID = gm.GlobalMileStoneID
            JOIN dbo.tblBusinessBaseObject AS bbo
                ON gm.BBOID = bbo.BBOID
            LEFT JOIN dbo.tblMilestone refm
                ON m.ReferenceMilestoneID = refm.MileStoneID
            LEFT JOIN dbo.tblValidMilestoneStatus vms
                ON COALESCE(refm.StatusID, m.StatusID) = vms.ValidMilestoneStatusID),
         --pilot template milestones for most recent pilot linked to pivotal or the project associated to a pivotal
         dwms (PivotalWorkstreamID, DevWorkstreamID, BBOCode, MilestoneName, MilestoneStatus, EstimatedDate,
               DisplayOrder
              )
    AS (SELECT MaxPilot.PivotalWorkstreamID,
               dw.DevWorkstreamID,
               bbo.BBOCode,
               mti.Name,
               vms.Name,
               CASE
                   WHEN m.ReferenceMilestoneID IS NULL THEN
                       m.BestEstimateDate
                   ELSE
                       refm.BestEstimateDate
               END,
               mti.DisplayOrder
        FROM pm.DevWorkstream dw
            JOIN
            (
                SELECT MAX(dw.DevWorkstreamID) AS DevWorkstreamID,
                       COALESCE(pwldw.PivotalWorkstreamID, dwlp.PivotalWorkstreamID) AS PivotalWorkstreamID
                FROM pm.DevWorkstream AS dw
                    JOIN dbo.tblBusinessBaseStates AS bbs
                        ON dw.DevWorkstreamStatusID = bbs.StateID
                    LEFT JOIN pm.PivotalWorkstreamLinkDevWorkstream AS pwldw
                        ON dw.DevWorkstreamID = pwldw.DevWorkstreamID
                    LEFT JOIN
                    (
                        SELECT pip.DevWorkstreamID,
                               pip.ProjectID,
                               pvp.PivotalWorkstreamID
                        FROM pm.DevWorkstreamLinkProject AS pip
                            JOIN pm.PivotalWorkstreamLinkProject AS pvp
                                ON pip.ProjectID = pvp.ProjectID
                    ) AS dwlp
                        ON dw.DevWorkstreamID = dwlp.DevWorkstreamID
                WHERE bbs.StateName IN ( 'In Progress', 'Complete' )
                      AND
                      (
                          pwldw.PivotalWorkstreamID IS NOT NULL
                          OR dwlp.PivotalWorkstreamID IS NOT NULL
                      )
                GROUP BY COALESCE(pwldw.PivotalWorkstreamID, dwlp.PivotalWorkstreamID)
            ) AS MaxPilot
                ON dw.DevWorkstreamID = MaxPilot.DevWorkstreamID
            JOIN dbo.tblMilestoneTemplateItem mti
                ON dw.MilestoneTemplateID = mti.MilestoneTemplateID
            JOIN dbo.tblMilestone m
                ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                   AND m.BBOID = @PLWBBOID
                   AND m.ObjectID = dw.DevWorkstreamID
            JOIN dbo.tblGlobalMilestone AS gm
                ON mti.GlobalMilestoneID = gm.GlobalMileStoneID
            JOIN dbo.tblBusinessBaseObject AS bbo
                ON gm.BBOID = bbo.BBOID
            LEFT JOIN dbo.tblMilestone refm
                ON m.ReferenceMilestoneID = refm.MileStoneID
            LEFT JOIN dbo.tblValidMilestoneStatus vms
                ON COALESCE(refm.StatusID, m.StatusID) = vms.ValidMilestoneStatusID),
         swExclude (ExcludedStateID)
    AS (SELECT bbs.StateID
        FROM dbo.tblBusinessBaseStateControl bbsc
            JOIN dbo.tblBusinessBaseStates bbs
                ON bbsc.StateControlID = bbs.StateControlID
        WHERE bbsc.BBOID = @SWBBOID
              AND bbs.StateName IN ( 'Rejected', 'Withdrawal in Progress', 'Withdrawn' ))
    SELECT
        --pivotal fields
           pw.PivotalWorkstreamID,
           pw.ReferenceLabel,
           pw.Comments,
           bt.Tag AS [TagName],
           pt.ValidBBOTagID AS [TagValue],
           prod.Name AS [Product],
           vrc.Name AS [PortfolioCategory],
           vrm.Name AS [ReleaseMechanism],
           LTRIM(RTRIM(   ISNULL(vrm.Name, '') + ' ' + vfo.Name + CASE
                                                                      WHEN ISNULL(f.Identifier, '') = '' THEN
                                                                          ''
                                                                      ELSE
                                                                          ' (' + f.Identifier + ')'
                                                                  END
                      )
                ) AS [PharmForm],
           STUFF(
           (
               SELECT ', ' + s.Name
               FROM dbo.tblStrength s
                   JOIN pm.PivotalWorkstreamStrength pws
                       ON s.StrengthID = pws.StrengthID
               WHERE pws.PivotalWorkstreamID = pw.PivotalWorkstreamID
                     AND s.IsUndefined = 0
               ORDER BY s.Name
               FOR XML PATH('')
           ),
           1,
           1,
           ''
                ) AS [Strengths],
           bbspw.StateName AS [PivotalStatus],
           co.Name AS [PivotalDevSite],
           COALESCE(su.FullName, su.ADUserName) AS [PivotalLead],
           COALESCE(pdsu.FullName, pdsu.ADUserName) AS [PDLead],
           COALESCE(ansu.FullName, ansu.ADUserName) AS [AnalyticalLead],
           COALESCE(pksu.FullName, pksu.ADUserName) AS [PKLead],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + ISNULL(s.Name, 'NO NAME')
               FROM pm.PivotalWorkstreamDosingStrength pwrld
                   JOIN dbo.tblStrength s
                       ON s.StrengthID = pwrld.StrengthID
               WHERE pwrld.PivotalWorkstreamID = pw.PivotalWorkstreamID
                     AND s.IsUndefined = 0
               ORDER BY ', ' + ISNULL(s.Name, 'NO NAME')
               FOR XML PATH('')
           ),
           1,
           1,
           ''
                ) AS [DosingStrengths],
           STUFF(
           (
               SELECT ', ' + s.Name + CASE
                                          WHEN pt.Name IS NOT NULL THEN
                                              '[' + pt.Name + CASE
                                                                  WHEN pwps.PackageSize IS NOT NULL THEN
                                                                      '(' + pwps.PackageSize + ')'
                                                              END + ']'
                                      END
               FROM pm.PivotalWorkstreamPackSize pwps
                   JOIN dbo.tblValidPackType pt
                       ON pt.ValidPackTypeID = pwps.ValidPackTypeID
                   JOIN dbo.tblStrength s
                       ON pwps.StrengthID = s.StrengthID
                   JOIN tblForm f
                       ON s.FormID = f.FormID
               WHERE pwps.PivotalWorkstreamID = pw.PivotalWorkstreamID
                     AND s.IsUndefined = 0
               ORDER BY s.Name
               FOR XML PATH('')
           ),
           1,
           1,
           ''
                ) AS [PackSizeOnStability],
           (
               SELECT MAX(vpc.Name)
               FROM dbo.tblValidPECCategory vpc
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vpc.ValidPECCategoryID = vki.ValidPECCategoryID
                   JOIN dbo.tblKPI kpi
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   JOIN dbo.tblProductLinkKPI plkpi
                       ON kpi.KPIID = plkpi.KPIID
               WHERE plkpi.ProductID = f.ProductID
           ) AS MPBClassification,
           p.ProjectID,
           (
               SELECT cg.Name
               FROM dbo.tblCountryGroup cg
                   JOIN pm.Project proj
                       ON cg.CountryGroupID = proj.CountryGroupID
               WHERE proj.ProjectID = p.ProjectID
           ) AS [Market],
           brnd.Name AS [BrandName],
           (
               SELECT DISTINCT
                      cmp.Name
               FROM dbo.tblBrand brnd
                   JOIN dbo.tblCountry cntry
                       ON cntry.CountryID = brnd.CountryID
                   JOIN dbo.tblCompany cmp
                       ON cmp.CompanyID = brnd.BrandCompanyID
               WHERE brnd.BrandID = p.BrandID
           ) AS [BrandCompany],
           (
               SELECT m.BestEstimateDate
               FROM dbo.tblMilestoneTemplateItem mti
                   JOIN dbo.tblMilestone m
                       ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                          AND m.BBOID = @PJBBOID
                          AND m.ObjectID = p.ProjectID
               WHERE p.MilestoneTemplateID = mti.MilestoneTemplateID
                     AND mti.Code = 'Submission'
           ) AS CEESD,
           STUFF(
           (
               SELECT CASE
                          WHEN vpsc1.Name IS NOT NULL THEN
                   (', ' + prb1.Name + ' (' + COALESCE(pc1.Name, 'None') + ' [' + COALESCE(vpsc1.Name, 'N/A') + '])')
                          ELSE
                              ', ' + prb1.Name + COALESCE(' (' + pc1.Name + ')', '')
                      END
               FROM pm.ProductProposal prop1
                   JOIN pm.ProductProposalLinkProject plp1
                       ON prop1.ProductProposalID = plp1.ProductProposalID
                   JOIN dbo.tblForm f1
                       ON prop1.FormID = f1.FormID
                   LEFT JOIN pm.Candidate c1
                       ON prop1.CandidateID = c1.CandidateID
                   LEFT JOIN pm.PRBSession prb1
                       ON prb1.PRBSessionID = c1.TargetPRBSessionID
                   LEFT JOIN dbo.tblValidProposalClass pc1
                       ON prop1.ValidProposalClassID = pc1.ValidProposalClassID
                   LEFT JOIN pm.ProductProposalLinkProjectScopeChange lsc
                       ON lsc.ProductProposalID = prop1.ProductProposalID
                   LEFT JOIN dbo.tblValidProjectScopeChange vpsc1
                       ON lsc.ValidProjectScopeChangeID = vpsc1.ValidProjectScopeChangeID
               WHERE plp1.ProjectID = p.ProjectID
               ORDER BY prb1.SessionDate
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [PRBApproval],
           COALESCE(pll.FullName, pll.ADUserName) AS [LegalLead],
           ot.Name AS [OpportunityType],
           ptp.Name AS [ProjectType],
           p.FocusNumber AS [FocusNumber],
           cor.Name AS [WorkPlan],
           p.Sales AS [IMSSales],
           p.EstFirstYearValue AS [EstFirstYearValue],
           (
               SELECT CASE
                          WHEN m.ReferenceMilestoneID IS NULL THEN
                              m.BestEstimateDate
                          ELSE
                              refm.BestEstimateDate
                      END
               FROM dbo.tblMilestone m
                   JOIN dbo.tblMilestoneTemplateItem mti
                       ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                   JOIN dbo.tblMilestoneTemplate mt
                       ON mti.MilestoneTemplateID = mt.MilestoneTemplateID
                   LEFT JOIN dbo.tblMilestone refm
                       ON m.ReferenceMilestoneID = refm.MileStoneID
               WHERE m.BBOID = @PJBBOID
                     AND m.ObjectID = pwp.ProjectID
                     AND mti.Code = 'SNC Decision'
                     AND mti.MilestoneTemplateID = p.MilestoneTemplateID
           ) AS [SNCDecision],
           (
               SELECT ms.Name
               FROM dbo.tblMilestone m
                   JOIN dbo.tblMilestoneTemplateItem mti
                       ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                   JOIN dbo.tblMilestoneTemplate mt
                       ON mti.MilestoneTemplateID = mt.MilestoneTemplateID
                   LEFT JOIN dbo.tblMilestone refm
                       ON m.ReferenceMilestoneID = refm.MileStoneID
                   LEFT JOIN dbo.tblValidMilestoneStatus ms
                       ON ms.ValidMilestoneStatusID = (CASE
                                                           WHEN m.ReferenceMilestoneID IS NULL THEN
                                                               m.StatusID
                                                           ELSE
                                                               refm.StatusID
                                                       END
                                                      )
               WHERE m.BBOID = @PJBBOID
                     AND m.ObjectID = pwp.ProjectID
                     AND mti.Code = 'SNC Decision'
                     AND mti.MilestoneTemplateID = p.MilestoneTemplateID
           ) AS [SNCDecisionStatus],
           ck.Name AS [ManufacturingSite],
           pk.Name AS [PackagingSite],
           bbsp.StateName AS [ProjectStatus],
           p.GxMarketFormationDate AS [GenericMarketFormationDate],
           p.LatestFileDate AS [LatestFilingDate],
           p.ExpectedMylLaunchDate AS [ExpectedLaunchDate],
           p.LaunchDateLogicComments AS [LaunchDateLogic],
           sus.Name AS ScaleUpSite,
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + c.Name
               FROM pm.RawMaterialSupplierSource rms
                   JOIN pm.RawMaterialSupplier rm
                       ON rms.RawMaterialSupplierID = rm.RawMaterialSupplierID
                   JOIN dbo.tblCompany c
                       ON rm.SupplierID = c.CompanyID
                   JOIN dbo.tblCompanyLinkCompanyGroup clcg
                       ON c.CompanyID = clcg.CompanyID
                   JOIN dbo.tblCompanyGroup cg
                       ON clcg.CompanyGroupID = cg.CompanyGroupID
               WHERE p.ProjectID = rms.ProjectID
                     AND
                     (
                         cg.Text = 'API Manufacturer'
                         OR cg.Text = 'API Vendor'
                     )
               ORDER BY ', ' + c.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [APIManufacturer],
           (
               SELECT TOP (1)
                      rmr.TargetUnitsOrdered
               FROM pm.RawMaterialOrder rmr
                   JOIN pm.RawMaterialSupplier srm
                       ON srm.RawMaterialSupplierID = rmr.RawMaterialSupplierID
                   JOIN pm.RawMaterialSupplierSource rms
                       ON rms.RawMaterialSupplierID = srm.RawMaterialSupplierID
               WHERE rmr.ValidRMRequestPurposeID =
               (
                   SELECT rmp.ValidRMRequestPurposeID
                   FROM dbo.tblValidRMRequestPurpose rmp
                   WHERE rmp.Name = 'R&D'
               )
                     AND rms.ProjectID IN
                         (
                             SELECT ProjectID
                             FROM pm.PivotalWorkstreamLinkProject pwlp
                             WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                         )
               ORDER BY rmr.TargetDeliveryDate
           ) AS [DevelopmentAPIOrdered],
           (
               SELECT TOP (1)
                      rmr.TargetDeliveryDate
               FROM pm.RawMaterialOrder rmr
                   JOIN pm.RawMaterialSupplier srm
                       ON srm.RawMaterialSupplierID = rmr.RawMaterialSupplierID
                   JOIN pm.RawMaterialSupplierSource rms
                       ON rms.RawMaterialSupplierID = srm.RawMaterialSupplierID
               WHERE rmr.ValidRMRequestPurposeID =
               (
                   SELECT rmp.ValidRMRequestPurposeID
                   FROM dbo.tblValidRMRequestPurpose rmp
                   WHERE rmp.Name = 'R&D'
               )
                     AND rms.ProjectID IN
                         (
                             SELECT ProjectID
                             FROM pm.PivotalWorkstreamLinkProject pwlp
                             WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                         )
               ORDER BY rmr.TargetDeliveryDate
           ) AS [DevelopmentAPIDueDate],
           (
               SELECT TOP (1)
                      rmr.TargetUnitsOrdered
               FROM pm.RawMaterialOrder rmr
                   JOIN pm.RawMaterialSupplier srm
                       ON srm.RawMaterialSupplierID = rmr.RawMaterialSupplierID
                   JOIN pm.RawMaterialSupplierSource rms
                       ON rms.RawMaterialSupplierID = srm.RawMaterialSupplierID
               WHERE rmr.ValidRMRequestPurposeID =
               (
                   SELECT rmp.ValidRMRequestPurposeID
                   FROM dbo.tblValidRMRequestPurpose rmp
                   WHERE rmp.Name = 'R&D/Scale-Up'
               )
                     AND rms.ProjectID IN
                         (
                             SELECT ProjectID
                             FROM pm.PivotalWorkstreamLinkProject pwlp
                             WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                         )
               ORDER BY rmr.TargetDeliveryDate
           ) AS [ValidationAPIOrdered],
           (
               SELECT TOP (1)
                      rmr.TargetDeliveryDate
               FROM pm.RawMaterialOrder rmr
                   JOIN pm.RawMaterialSupplier srm
                       ON srm.RawMaterialSupplierID = rmr.RawMaterialSupplierID
                   JOIN pm.RawMaterialSupplierSource rms
                       ON rms.RawMaterialSupplierID = srm.RawMaterialSupplierID
               WHERE rmr.ValidRMRequestPurposeID =
               (
                   SELECT rmp.ValidRMRequestPurposeID
                   FROM dbo.tblValidRMRequestPurpose rmp
                   WHERE rmp.Name = 'R&D/Scale-Up'
               )
                     AND rms.ProjectID IN
                         (
                             SELECT ProjectID
                             FROM pm.PivotalWorkstreamLinkProject pwlp
                             WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                         )
               ORDER BY rmr.TargetDeliveryDate
           ) AS [ValidationAPIDueDate],
           (
               SELECT TOP (1)
                      CASE
                          WHEN m2.ReferenceMilestoneID IS NULL THEN
                              m2.BestEstimateDate
                          ELSE
                              refm2.BestEstimateDate
                      END
               FROM dbo.MASubmissionWorkstream sw
                   JOIN dbo.tblMilestone m2
                       ON m2.ObjectID = sw.MASubmissionWorkstreamID
                          AND m2.BBOID = @SWBBOID
                   JOIN dbo.tblMilestoneTemplateItem mti2
                       ON sw.MilestoneTemplateID = mti2.MilestoneTemplateID
                          AND mti2.MilestoneTemplateItemID = m2.MilestoneTemplateItemID
                   JOIN dbo.tblGlobalMilestone gm2
                       ON mti2.GlobalMilestoneID = gm2.GlobalMileStoneID
                          AND gm2.Code = 'Slot Date'
                   LEFT JOIN dbo.tblMilestone refm2
                       ON m2.ReferenceMilestoneID = refm2.MileStoneID
               WHERE sw.ProjectID = p.ProjectID
                     AND sw.MASubmissionWorkstreamStatusID NOT IN
                         (
                             SELECT ExcludedStateID FROM swExclude
                         )
               ORDER BY CASE
                            WHEN m2.ReferenceMilestoneID IS NULL THEN
                                m2.BestEstimateDate
                            ELSE
                                refm2.BestEstimateDate
                        END
           ) AS SlotDate,
           (
               SELECT TOP (1)
                      m2s.Name
               FROM dbo.MASubmissionWorkstream sw
                   JOIN dbo.tblMilestone m2
                       ON m2.ObjectID = sw.MASubmissionWorkstreamID
                          AND m2.BBOID = @SWBBOID
                   JOIN dbo.tblMilestoneTemplateItem mti2
                       ON sw.MilestoneTemplateID = mti2.MilestoneTemplateID
                          AND mti2.MilestoneTemplateItemID = m2.MilestoneTemplateItemID
                   JOIN dbo.tblGlobalMilestone gm2
                       ON mti2.GlobalMilestoneID = gm2.GlobalMileStoneID
                          AND gm2.Code = 'Slot Date'
                   LEFT JOIN dbo.tblMilestone refm2
                       ON m2.ReferenceMilestoneID = refm2.MileStoneID
                   LEFT JOIN dbo.tblValidMilestoneStatus m2s
                       ON m2s.ValidMilestoneStatusID = (CASE
                                                            WHEN m2.ReferenceMilestoneID IS NULL THEN
                                                                m2.BestEstimateDate
                                                            ELSE
                                                                refm2.BestEstimateDate
                                                        END
                                                       )
               WHERE sw.ProjectID = p.ProjectID
                     AND sw.MASubmissionWorkstreamStatusID NOT IN
                         (
                             SELECT ExcludedStateID FROM swExclude
                         )
               ORDER BY CASE
                            WHEN m2.ReferenceMilestoneID IS NULL THEN
                                m2.BestEstimateDate
                            ELSE
                                refm2.BestEstimateDate
                        END
           ) AS [SlotDateStatus],
           vtor.NAME ProjRdRating,
           p.Comments ProjComments,
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + app.RegulatoryLead
               FROM rim.RimApplication app
                   JOIN rim.RimActivity act
                       ON act.MAApplicationID = app.MAApplicationID
                   JOIN pm.ProjectLinkRimActivity link
                       ON act.MAActivityID = link.MAActivityID
               WHERE link.ProjectID = p.ProjectID
               ORDER BY ', ' + app.RegulatoryLead
               FOR XML PATH('')
           ),
           1,
           1,
           ''
                ) AS [RegulatoryLeads],
           pat.Name AS [3PAgreementType],
           bcra.Name AS [3PBCRAApproval],
           bp.Name AS [3PBusinessPartner],
           p.ContractExecutionDate AS [3PContractExecution],
           (
               SELECT pt2.ValidBBOTagID
               FROM pm.ProjectTag AS pt2
                   JOIN dbo.tblValidBBOTag AS vbt
                       ON pt2.ValidBBOTagID = vbt.ValidBBOTagID
               WHERE pt2.ProjectID = p.ProjectID
                     AND vbt.Tag = 'Potent'
           ) AS [Potent],
           (
               SELECT pt2.ValidBBOTagID
               FROM pm.ProjectTag AS pt2
                   JOIN dbo.tblValidBBOTag AS vbt
                       ON pt2.ValidBBOTagID = vbt.ValidBBOTagID
               WHERE pt2.ProjectID = p.ProjectID
                     AND vbt.Tag = 'CII'
           ) AS [CII],
           (
               SELECT pt2.ValidBBOTagID
               FROM pm.ProjectTag AS pt2
                   JOIN dbo.tblValidBBOTag AS vbt
                       ON pt2.ValidBBOTagID = vbt.ValidBBOTagID
               WHERE pt2.ProjectID = p.ProjectID
                     AND vbt.Tag = 'Registry'
           ) AS [Registry],
           (
               SELECT pt2.ValidBBOTagID
               FROM pm.ProjectTag AS pt2
                   JOIN dbo.tblValidBBOTag AS vbt
                       ON pt2.ValidBBOTagID = vbt.ValidBBOTagID
               WHERE pt2.ProjectID = p.ProjectID
                     AND vbt.Tag = 'Key Product'
           ) AS [KeyProduct],
           STUFF(
           (
               SELECT ', ' + c.Code
               FROM dbo.tblCountry c
                   JOIN pm.ProjectLinkCountry plc
                       ON c.CountryID = plc.CountryID
               WHERE plc.ProjectID = p.ProjectID
               ORDER BY ', ' + c.Code
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Country Codes],
           (
               SELECT COUNT(c.CountryID)
               FROM dbo.tblCountry c
                   JOIN pm.ProjectLinkCountry plc
                       ON c.CountryID = plc.CountryID
               WHERE plc.ProjectID = p.ProjectID
           ) AS [Country Count],
           --pilot fields
           (
               SELECT MAX(DevWorkstreamID)
               FROM pm.DevWorkstreamLinkPivotalWorkstream
               WHERE PivotalWorkstreamID = pw.PivotalWorkstreamID
           ) AS [PilotID],
           (
               SELECT bbsdev.StateName
               FROM dbo.tblBusinessBaseStates bbsdev
                   JOIN pm.DevWorkstream dw
                       ON dw.DevWorkstreamStatusID = bbsdev.StateID
               WHERE dw.DevWorkstreamID =
               (
                   SELECT MAX(DevWorkstreamID)
                   FROM pm.DevWorkstreamLinkPivotalWorkstream
                   WHERE PivotalWorkstreamID = pw.PivotalWorkstreamID
               )
           ) AS [PilotStatus],
           --pivotal milestones
           pwms.BBOCode AS MilestoneBBOPivotal,
           pwms.MilestoneName AS MilestoneNamePivotal,
           pwms.MilestoneStatus AS MilestoneStatusPivotal,
           pwms.EstimatedDate AS MilestoneDatePivotal,
           pwms.DisplayOrder AS MilestoneOrderPivotal,

           --Pilot milestones
           dwms.BBOCode AS MilestoneBBOPilot,
           dwms.MilestoneName AS MilestoneNamePilot,
           dwms.MilestoneStatus AS MilestoneStatusPilot,
           dwms.EstimatedDate AS MilestoneDatePilot,
           dwms.DisplayOrder AS MilestoneOrderPilot,
           STUFF(
           (
               SELECT ', ' + tag.Tag
               FROM dbo.tblValidBBOTag tag
                   JOIN pm.ProjectTag pt
                       ON pt.ValidBBOTagID = tag.ValidBBOTagID
               WHERE pt.ProjectID = p.ProjectID
               ORDER BY tag.Tag
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Project Tag(s)]
    FROM pm.PivotalWorkstream pw
        JOIN dbo.tblForm f
            ON pw.FormID = f.FormID
        JOIN dbo.tblProduct prod
            ON prod.ProductID = f.ProductID
        JOIN dbo.tblValidForm vfo
            ON vfo.ValidFormID = f.ValidFormID
        LEFT JOIN pm.PivotalWorkstreamLinkProject pwp
            ON pwp.PivotalWorkstreamID = pw.PivotalWorkstreamID
        LEFT JOIN pm.Project p
            ON pwp.ProjectID = p.ProjectID
        LEFT JOIN dbo.tblCompany co
            ON pw.DevSiteID = co.CompanyID
        --LEFT JOIN pm.ProductProposalLinkProject plp
        --    ON p.ProjectID = plp.ProjectID
        --LEFT JOIN pm.ProductProposal prop
        --    ON plp.ProductProposalID = prop.ProductProposalID
        LEFT JOIN pm.PivotalWorkstreamTag pt
            ON pw.PivotalWorkstreamID = pt.PivotalWorkstreamID
        LEFT JOIN dbo.tblValidBBOTag bt
            ON pt.ValidBBOTagID = bt.ValidBBOTagID
        LEFT JOIN pwms
            ON pw.PivotalWorkstreamID = pwms.PivotalWorkstreamID
        LEFT JOIN dwms
            ON pw.PivotalWorkstreamID = dwms.PivotalWorkstreamID
        LEFT JOIN dbo.tblCompany ck
            ON p.ManufacturingSiteID = ck.CompanyID
        LEFT JOIN dbo.tblCompany pk
            ON p.PackagingSiteID = pk.CompanyID
        LEFT JOIN dbo.tblBusinessBaseStates bbspw
            ON pw.PivotalWorkstreamStatusID = bbspw.StateID
        LEFT JOIN dbo.tblBusinessBaseStates bbsp
            ON p.ProjectStatusID = bbsp.StateID
        LEFT JOIN dbo.admin_SecUser su
            ON su.UserID = pw.LeadID
        LEFT JOIN dbo.admin_SecUser pksu
            ON pw.PKLeadID = pksu.UserID
        LEFT JOIN dbo.admin_SecUser pdsu
            ON pw.PDLeadID = pdsu.UserID
        LEFT JOIN dbo.admin_SecUser pll
            ON p.LegalLeadID = pll.UserID
        LEFT JOIN dbo.admin_SecUser ansu
            ON pw.AnalyticalLeadID = ansu.UserID
        LEFT JOIN dbo.admin_SecUser pru
            ON pru.UserID = p.ProjectLeadID
        LEFT JOIN dbo.tblValidProjectOppType ot
            ON p.ValidOpportunityTypeID = ot.ValidProjectOppTypeID
        LEFT JOIN dbo.tblValidSterilizationType vst
            ON vst.ValidSterilizationTypeID = pw.ValidSterilizationTypeID
        LEFT JOIN dbo.tblValidStopperInfo vsi
            ON vsi.ValidStopperInfoID = pw.ValidStopperInfoID
        LEFT JOIN dbo.tblValidFilters vf
            ON vf.ValidFilterID = pw.ValidFiltersID
        LEFT JOIN dbo.tblValidReleaseCategory vrc
            ON f.ValidReleaseCategoryID = vrc.ValidReleaseCategoryID
        LEFT JOIN dbo.tblValidReleaseMechanism AS vrm
            ON f.ValidReleaseMechanismID = vrm.ValidReleaseMechanismID
        LEFT JOIN dbo.[tblValidWorkPlan] cor
            ON p.ValidWorkPlanID = cor.ValidWorkPlanID
        LEFT JOIN dbo.[tblValidProjectType] ptp
            ON p.ValidProjectTypeID = ptp.ValidProjectTypeID
        LEFT JOIN dbo.tblBrand brnd
            ON p.BrandID = brnd.BrandID
        LEFT JOIN dbo.tblValidTechOpsRating vtor
            ON p.ValidTechOpsRatingID = vtor.ValidTechOpsRatingID
        LEFT JOIN dbo.tblValidProjectAgreementType pat
            ON p.ProjectAgreementTypeID = pat.ValidProjectAgreementTypeID
        LEFT JOIN dbo.tblBCRASession bcra
            ON p.BCRASessionID = bcra.BCRASessionID
        LEFT JOIN dbo.tblCompany bp
            ON p.BusinessPartnerID = bp.CompanyID
        LEFT JOIN dbo.tblCompany sus
            ON sus.CompanyID = pw.ScaleUpSiteID
    WHERE (
              @IsUnrestricted > 0
              OR pw.PivotalWorkstreamID IN
                 (
                     SELECT pwlcg.PivotalWorkstreamID
                     FROM pm.PivotalWorkstreamLinkCountryGroup pwlcg
                         JOIN #ExpiryCountryGroups uhp
                             ON pwlcg.CountryGroupID = uhp.CountryGroupID
                 )
          )
          AND
          (
              @ID IS NULL
              OR @ID = pw.PivotalWorkstreamID
          )
          AND
          (
              @ProductGroupID IS NULL
              OR f.ProductID = @ProductGroupID
          )
          AND
          (
              @ProjectID IS NULL
              OR @ProjectID IN
                 (
                     SELECT ProjectID
                     FROM pm.PivotalWorkstreamLinkProject pwlp
                     WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                 )
          )
          AND
          (
              @ParentType IS NULL
              OR @ParentID IS NULL
              OR
              (
                  @ParentType = 0
                  AND @ParentID = 0
              )
              OR
              (
                  @ParentType = @PJBBOID
                  AND @ParentID IN
                      (
                          SELECT ProjectID
                          FROM pm.PivotalWorkstreamLinkProject pwlp
                          WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                      )
              )
          )
          AND
          (
              @PivotalWorkstreamStatusID IS NULL
              OR
              (
                  @PivotalWorkstreamStatusInclusionID = 1
                  AND @PivotalWorkstreamStatusID = pw.PivotalWorkstreamStatusID
              )
              OR
              (
                  @PivotalWorkstreamStatusInclusionID = 3
                  AND @PivotalWorkstreamStatusID <> pw.PivotalWorkstreamStatusID
              )
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @CountryGroupFilters
          )   = 0
          OR
          (
              @CountryGroupFiltersInclusionID = 1
              AND pw.PivotalWorkstreamID IN
                  (
                      SELECT PivotalWorkstreamID
                      FROM pm.PivotalWorkstreamLinkCountryGroup pwlcg
                      WHERE pwlcg.PivotalWorkstreamID = pw.PivotalWorkstreamID
                            AND pwlcg.CountryGroupID IN
                                (
                                    SELECT CountryGroupID FROM @CountryGroupFilters
                                )
                  )
          )
          OR
          (
              @CountryGroupFiltersInclusionID = 3
              AND pw.PivotalWorkstreamID NOT IN
                  (
                      SELECT PivotalWorkstreamID
                      FROM pm.PivotalWorkstreamLinkCountryGroup pwlcg
                      WHERE pwlcg.CountryGroupID IN
                            (
                                SELECT CountryGroupID FROM @CountryGroupFilters
                            )
                  )
          )
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @FormFilters
          )   = 0
          AND @FormFiltersInclusionID <> 4
          OR
          (
              @FormFiltersInclusionID = 1
              AND pw.FormID IN
                  (
                      SELECT FormID FROM @FormFilters
                  )
          )
          OR
          (
              @FormFiltersInclusionID = 2
              AND
              (
                  SELECT COUNT(DISTINCT f.FormID)
                  FROM dbo.tblForm f
                      JOIN @FormFilters ff
                          ON ff.FormID = f.FormID
                             AND f.FormID = pw.FormID
              ) =
              (
                  SELECT COUNT(DISTINCT FormID)FROM @FormFilters
              )
          )
          OR
          (
              @FormFiltersInclusionID = 3
              AND pw.FormID NOT IN
                  (
                      SELECT FormID FROM @FormFilters
                  )
          )
          OR
          (
              @FormFiltersInclusionID = 4
              AND pw.FormID IS NULL
          )
          )
          AND
          (
              (
              (
                  SELECT COUNT(*)FROM @SubmissionYearFilters
              )   = 0
              AND @SubmissionYearFiltersInclusionID <> 4
              )
              OR
              (
                  @SubmissionYearFiltersInclusionID = 1
                  AND
                  (
                      SELECT MIN(   CASE
                                        WHEN m.ReferenceMilestoneID IS NULL THEN
                                            YEAR(m.BestEstimateDate)
                                        ELSE
                                            YEAR(refm.BestEstimateDate)
                                    END
                                )
                      FROM pm.Project p
                          JOIN pm.PivotalWorkstreamLinkProject pwlp
                              ON pwlp.ProjectID = p.ProjectID
                          JOIN dbo.tblMilestone m
                              ON m.BBOID = @PJBBOID
                                 AND m.ObjectID = p.ProjectID
                          JOIN dbo.tblMilestoneTemplateItem mti
                              ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 AND mti.Code = 'Submission'
                          LEFT JOIN dbo.tblMilestone refm
                              ON refm.MileStoneID = m.MileStoneID
                      WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                  ) IN
                  (
                      SELECT Timeframe FROM @SubmissionYearFilters
                  )
              )
              OR
              (
                  @SubmissionYearFiltersInclusionID = 3
                  AND ISNULL(
                      (
                          SELECT MIN(   CASE
                                            WHEN m.ReferenceMilestoneID IS NULL THEN
                                                YEAR(m.BestEstimateDate)
                                            ELSE
                                                YEAR(refm.BestEstimateDate)
                                        END
                                    )
                          FROM pm.Project p
                              JOIN pm.PivotalWorkstreamLinkProject pwlp
                                  ON pwlp.ProjectID = p.ProjectID
                              JOIN dbo.tblMilestone m
                                  ON m.BBOID = @PJBBOID
                                     AND m.ObjectID = p.ProjectID
                              JOIN dbo.tblMilestoneTemplateItem mti
                                  ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                     AND mti.Code = 'Submission'
                              LEFT JOIN dbo.tblMilestone refm
                                  ON refm.MileStoneID = m.MileStoneID
                          WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                      ),
                      -1
                            ) NOT IN
                      (
                          SELECT Timeframe FROM @SubmissionYearFilters
                      )
              )
              OR
              (
                  @SubmissionYearFiltersInclusionID = 4
                  AND ISNULL(
                      (
                          SELECT MIN(   CASE
                                            WHEN m.ReferenceMilestoneID IS NULL THEN
                                                YEAR(m.BestEstimateDate)
                                            ELSE
                                                YEAR(refm.BestEstimateDate)
                                        END
                                    )
                          FROM pm.Project p
                              JOIN pm.PivotalWorkstreamLinkProject pwlp
                                  ON pwlp.ProjectID = p.ProjectID
                              JOIN dbo.tblMilestone m
                                  ON m.BBOID = @PJBBOID
                                     AND m.ObjectID = p.ProjectID
                              JOIN dbo.tblMilestoneTemplateItem mti
                                  ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                     AND mti.Code = 'Submission'
                              LEFT JOIN dbo.tblMilestone refm
                                  ON refm.MileStoneID = m.MileStoneID
                          WHERE pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                      ),
                      -1
                            ) IS NULL
              )
          )
          AND
          (
              @LeadID IS NULL
              OR
              (
                  @LeadInclusionID = 1
                  AND @LeadID = pw.LeadID
              )
              OR
              (
                  @LeadInclusionID = 3
                  AND @LeadID <> pw.LeadID
              )
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @BBOTagFilters
          )   = 0
          AND @BBOTagFiltersInclusionID <> 4
          OR
          (
              @BBOTagFiltersInclusionID = 1
              AND pw.PivotalWorkstreamID IN
                  (
                      SELECT PivotalWorkstreamID
                      FROM pm.PivotalWorkstreamTag
                      WHERE ValidBBOTagID IN
                            (
                                SELECT BBOTagID FROM @BBOTagFilters
                            )
                  )
          )
          OR
          (
              @BBOTagFiltersInclusionID = 2
              AND
              (
                  SELECT COUNT(DISTINCT pwt.ValidBBOTagID)
                  FROM pm.PivotalWorkstreamTag pwt
                      JOIN @BBOTagFilters tf
                          ON tf.BBOTagID = pwt.ValidBBOTagID
                             AND pwt.PivotalWorkstreamID = pw.PivotalWorkstreamID
              ) =
              (
                  SELECT COUNT(DISTINCT BBOTagID)FROM @BBOTagFilters
              )
          )
          OR
          (
              @BBOTagFiltersInclusionID = 3
              AND pw.PivotalWorkstreamID NOT IN
                  (
                      SELECT PivotalWorkstreamID
                      FROM pm.PivotalWorkstreamTag
                      WHERE ValidBBOTagID IN
                            (
                                SELECT BBOTagID FROM @BBOTagFilters
                            )
                  )
          )
          OR
          (
              @BBOTagFiltersInclusionID = 4
              AND pw.PivotalWorkstreamID IN
                  (
                      SELECT PivotalWorkstreamID
                      FROM pm.PivotalWorkstream
                      WHERE PivotalWorkstreamID NOT IN
                            (
                                SELECT PivotalWorkstreamID FROM pm.PivotalWorkstreamTag
                            )
                  )
          )
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @SiteFilters
          )   = 0
          -- Include
          OR  (
              (
                  @SiteNameFiltersInclusionID = 1
                  AND
                  (
                      (
                          @IncludeScaleUpSites > 0
                          AND pw.ScaleUpSiteID IN
                              (
                                  SELECT Id FROM @SiteFilters
                              )
                      )
                      OR
                      (
                          @IncludePackagingSites > 0
                          AND pw.PivotalWorkstreamID IN
                              (
                                  SELECT pwlp.PivotalWorkstreamID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.Project p
                                          ON p.ProjectID = pwlp.ProjectID
                                  WHERE p.PackagingSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                      OR
                      (
                          @IncludeManufacturingSites > 0
                          AND pw.PivotalWorkstreamID IN
                              (
                                  SELECT pwlp.PivotalWorkstreamID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.Project p
                                          ON p.ProjectID = pwlp.ProjectID
                                  WHERE p.ManufacturingSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                      OR
                      (
                          @IncludeDevelopmentSites > 0
                          AND pw.DevSiteID IN
                              (
                                  SELECT Id FROM @SiteFilters
                              )
                      )
                  )
              )
              )
          -- Exclude
          OR
          (
              @SiteNameFiltersInclusionID = 3
              AND
              (
                  (
                      @IncludeScaleUpSites > 0
                      AND
                      (
                          pw.ScaleUpSiteID IS NULL
                          OR pw.ScaleUpSiteID NOT IN
                             (
                                 SELECT Id FROM @SiteFilters
                             )
                      )
                  )
                  OR
                  (
                      @IncludePackagingSites > 0
                      AND pw.PivotalWorkstreamID NOT IN
                          (
                              SELECT PivotalWorkstreamID
                              FROM pm.PivotalWorkstreamLinkProject pwlp
                                  JOIN pm.Project p
                                      ON p.ProjectID = pwlp.ProjectID
                              WHERE p.PackagingSiteID IN
                                    (
                                        SELECT Id FROM @SiteFilters
                                    )
                          )
                  )
                  OR
                  (
                      @IncludeManufacturingSites > 0
                      AND pw.PivotalWorkstreamID NOT IN
                          (
                              SELECT pwlp.PivotalWorkstreamID
                              FROM pm.PivotalWorkstreamLinkProject pwlp
                                  JOIN pm.Project p
                                      ON p.ProjectID = pwlp.ProjectID
                              WHERE p.ManufacturingSiteID IN
                                    (
                                        SELECT Id FROM @SiteFilters
                                    )
                          )
                  )
                  OR
                  (
                      @IncludeDevelopmentSites > 0
                      AND pw.DevSiteID NOT IN
                          (
                              SELECT Id FROM @SiteFilters
                          )
                  )
              )
          )
          )
    ORDER BY pw.PivotalWorkstreamID;

    IF OBJECT_ID('tempdb..#ExpiryCountryGroups') IS NOT NULL
    BEGIN
        DROP TABLE #ExpiryCountryGroups;
    END;

END;
GO
