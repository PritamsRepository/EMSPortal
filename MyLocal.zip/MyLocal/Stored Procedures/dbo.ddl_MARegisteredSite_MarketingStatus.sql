SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MARegisteredSite_MarketingStatus]
  @CompanyID INT
        
AS 
BEGIN TRY

SELECT DISTINCT
  bbs.StateID AS ID,
  bbs.StateName AS Name
FROM
  dbo.tblMARegisteredSite mars
	/* Site JOINs */
	JOIN dbo.tblMASite mas ON mars.MASiteID = mas.MASiteID
	JOIN dbo.tblValidQualityStatus vqs ON mars.ValidQualityStatusID = vqs.ValidQualityStatusID
	
	/* Scope JOINs */
	JOIN dbo.tblMALicenseScope mals 
	  JOIN dbo.tblBusinessBaseStates bbs ON mals.MarketStatusID = bbs.StateID
	ON mars.MALicenseScopeID = mals.MALicenseScopeID
WHERE  
	mas.CompanyID = @CompanyID
	
END TRY
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MARegisteredSite_MarketingStatus] TO [mp_db_execute]
GO
