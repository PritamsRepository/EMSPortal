SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE PROCEDURE [Core.Common.Filter].[GetPrivileges] 
@ActiveOnly BIT = 0,
@SystemID INT = NULL,
@PrivType NCHAR(10) = NULL
AS

SELECT PrivID AS ID,
		PrivCode AS Code,
		Name AS Name
FROM dbo.admin_SecPriv AS ASP 
WHERE 
	(@SystemID IS NULL OR @SystemID = ASP.ValidSoftwareSystemID)
	AND (@PrivType IS NULL OR @PrivType = ASP.PrivType)
	AND (@ActiveOnly IS NULL OR ASP.IsActive = @ActiveOnly)

GO
