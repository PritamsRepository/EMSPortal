SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MALicense_ReviewedBy]
  @UserID INT = NULL
  
AS
  
BEGIN TRY 

  SELECT DISTINCT 
	mal.ReviewedByID AS UserID,
	(
	  CASE WHEN asu.FullName IS NULL OR asu.FullName = '' OR LEN(asu.fullname) < 2 THEN asu.ADUserName
	  ELSE asu.FullName
	  END
	) AS FullName,
	asu.FullName AS FullName
  FROM
	dbo.tblMALicense mal
	  JOIN dbo.tblMAApplication maa ON mal.MAApplicationID = maa.MAApplicationID 
	  JOIN dbo.admin_SecUser asu ON mal.ReviewedByID = asu.UserID
  ORDER BY
	asu.FullName;

END TRY
BEGIN CATCH 
  EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicense_ReviewedBy] TO [mp_db_execute]
GO
