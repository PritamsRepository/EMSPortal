SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_ProposalsForProject]
    @FormID INT ,
    @CountryGroupID INT ,
    @UserID INT ,
    @PrivCode NVARCHAR(10)
AS
    BEGIN TRY
        SELECT  DISTINCT
                prop.ProductProposalID AS ProposalID ,
                prop.ShortName AS [Name]
        FROM    pm.ProductProposal prop
                JOIN tblForm f ON f.FormID = prop.FormID
        WHERE   prop.CountryGroupID = @CountryGroupID
                AND f.FormID = @FormID
                AND [dbo].[udf_UserHasPrivForCountryGroup](@UserID, @PrivCode,
                                                           prop.[CountryGroupID]) = 'true'
        ORDER BY prop.ProductProposalID
    END TRY

    BEGIN CATCH
        EXEC sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_ProposalsForProject] TO [mp_db_execute]
GO
