SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAApplicationSubmitter]
  @CompanyID INT = NULL

AS 
    BEGIN TRY
/* 
Created By:		JRG
Date:			2011-06-24
Description:	Return a list of companyid, company name that are in the company group
				Mylan or External Partner
*/

        DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
		DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';

		SELECT DISTINCT
		  (
			CASE 
			  WHEN c.Name = @PrimarySortPriority THEN 0
			  WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
			  ELSE 2 
			  END
		  ) AS SortPriority,
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS 'Company',
		  (COALESCE(co.Code, 'N/A') + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c 
			INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
			INNER JOIN tblCompanyGroup cg ON  clcg.CompanyGroupID = cg.CompanyGroupID
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE ( CG.[Text] = 'MA Application Submitter'
              /* OR CG.[Text] = 'External Partners' changed per Reg Call*/ )
        
        UNION
        
        SELECT DISTINCT
		  (
			CASE 
			  WHEN c.Name = @PrimarySortPriority THEN 0
			  WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
			  ELSE 2 
			  END
		  ) AS SortPriority,
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS 'Company',
		  (COALESCE(co.Code, 'N/A') + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c			
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE c.CompanyID = @CompanyID		
        ORDER BY SortPriority, 'Company'
	
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplicationSubmitter] TO [mp_db_execute]
GO
