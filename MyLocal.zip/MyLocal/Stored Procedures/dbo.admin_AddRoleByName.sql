SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE PROCEDURE [dbo].[admin_AddRoleByName]
    @RoleName NVARCHAR(100) ,
    @RoleDescription NVARCHAR(256)
AS 
    BEGIN TRY
	
	/* check if role exist if so let caller know and exit*/
        IF EXISTS ( SELECT  Name
                    FROM    dbo.admin_SecRole
                    WHERE   name = @RoleName ) 
            BEGIN
                RAISERROR('Role %s already exists', 0, 42, @RoleName) WITH NoWait ;
            END
	
        ELSE 
            BEGIN
	
                IF ( @RoleName IS NOT NULL AND @RoleName <>''
                     AND @RoleDescription IS NOT NULL ) 
                    BEGIN
                        INSERT  INTO dbo.admin_SecRole
                                ( Name, Description )
                        VALUES  ( @RoleName, -- Name - nvarchar(100)
                                  @RoleDescription -- Description - nvarchar(256)
                                  )
                        RETURN 0;
                    END
				
				DECLARE @WasNullOrBlank NVARCHAR(100)
				
				SELECT @WasNullOrBlank = STUFF((SELECT ',  ' + CASE WHEN @RoleName is NULL THEN 'RoleName was NULL'
						    WHEN @RoleName ='' THEN 'RoleName was blank'
						    WHEN @RoleDescription IS NULL THEN 'Role Description was NULL'
						END
						FOR XML PATH('')), 1, 2, '') 
						
                RAISERROR(' %s  ', 0, 45, @WasNullOrBlank) WITH NoWait ;
	
            END
	
    END TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH


GO
GRANT EXECUTE ON  [dbo].[admin_AddRoleByName] TO [mp_db_execute]
GO
