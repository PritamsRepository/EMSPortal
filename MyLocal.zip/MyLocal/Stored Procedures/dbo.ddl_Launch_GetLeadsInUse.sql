SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_Launch_GetLeadsInUse]
AS
    BEGIN TRY
        SELECT  su.UserID ,
                su.ADUserName ,
                COALESCE(su.FullName, su.ADUserName) AS FullName
        FROM    dbo.admin_SecUser su
                JOIN pm.LaunchWorkstream lw ON lw.LeadID = su.UserID
        GROUP BY su.UserID ,
                su.ADUserName ,
                su.FullName
        ORDER BY su.FullName 
    END TRY

    BEGIN CATCH
        EXEC SP_ROLLANDRAISE
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_Launch_GetLeadsInUse] TO [mp_db_execute]
GO
