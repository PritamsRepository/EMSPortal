SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetPRBApprovalSessions]
	@RegionID INT = NULL,
	@ProductID INT = NULL
	
AS
BEGIN

	SELECT
		prbs.PRBSessionID AS ID,
		prbs.Name		
	FROM
		pm.PRBSession prbs
			LEFT JOIN tblBusinessBaseStates bbs ON bbs.StateID = prbs.StatusID
	WHERE 
		bbs.StateName = 'In Progress'
	ORDER BY
		prbs.SessionDate DESC;

END
GO
