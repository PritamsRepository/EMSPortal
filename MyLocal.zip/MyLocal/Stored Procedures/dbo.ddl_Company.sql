SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_Company] ( @CompanyID INT = NULL )
AS 
    BEGIN TRY
		
        SELECT DISTINCT
                c.Name ,
                c.CompanyID
        FROM    tblCompany c
                INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                INNER JOIN tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
        UNION
        SELECT  Name ,
                CompanyID
        FROM    tblCompany
        WHERE   ( CompanyID = @CompanyID
                  OR @CompanyID IS NULL
                )
        ORDER BY Name
			
    END TRY

    BEGIN CATCH
        EXECUTE dbo.sp_RollAndRaise 
    END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_Company] TO [mp_db_execute]
GO
