SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Procedure [dbo].[ddl_CountryGroup_CountryGroupTypes]
AS
BEGIN TRY

  SELECT DISTINCT
	cg.CountryGroupType AS Name
  FROM
	dbo.tblCountryGroup cg
	  JOIN dbo.tblCountryLinkCountryGroup clcg ON cg.CountryGroupID = clcg.CountryGroupID
  ORDER BY
	cg.CountryGroupType

END TRY 
BEGIN CATCH
	EXEC dbo.SP_ROLLANDRAISE
END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_CountryGroup_CountryGroupTypes] TO [mp_db_execute]
GO
