SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [Core.Reporting].[MAHAAction_Summary_GetByFilter]
    @ProductName NVARCHAR(256) = NULL ,
    @ApplicationNum NVARCHAR(256) = NULL ,
    @ApplicationID INT = NULL ,
    @SubmissionTracking NVARCHAR(256) = NULL ,
    @MASubmissionWorkstreamID INT = NULL ,
    @CountryGroupID INT = NULL , --Region
    @CountryID INT = NULL ,
    @RegLeadID INT = NULL , --SubmissionLead
    @RegTeamID INT = NULL ,
    @MASubmissionWorkstreamStatusID INT = NULL ,
    @SubmissionRouteID INT = NULL ,
    @ValidMASubmissionTypeID INT = NULL , --<< New for Phase 2
    @ShowCMSSubmissions INT , --<< New for Phase 2
    @SubmissionStartDate NVARCHAR(256) = NULL ,
    @SubmissionEndDate NVARCHAR(256) = NULL ,
    @RegCloseStartDate NVARCHAR(256) = NULL ,
    @RegCloseEndDate NVARCHAR(256) = NULL ,
    @FinalApproveStartDate NVARCHAR(256) = NULL ,
    @FinalApproveEndDate NVARCHAR(256) = NULL ,
    @UserID INT ,
    @PrivCode NVARCHAR(20)
AS
    BEGIN TRY
    
        DECLARE @PerfectProdSearch BIT = 0
        IF CHARINDEX('"', @ProductName) > 0
            BEGIN
                SET @ProductName = REPLACE(REPLACE(@ProductName, '"', ''), '%',
                                           '')			
                SET @PerfectProdSearch = 1
            END
/*	
	Priv codes MA01	MA_ViewSummary 
	License Management View By Submissions 
	using xsd MAApplicationTypes.xsd schema MASubmission
	
*/


        DECLARE @CheckPrivCode NVARCHAR(20)  = 'MA29'
        DECLARE @StateID INT
        DECLARE @StateNBMID INT
        DECLARE @StateNMID INT
		
        IF NOT EXISTS ( SELECT  p.[PrivCode]
                        FROM    [dbo].[admin_SecPriv] AS p
                                JOIN [dbo].[admin_SecRolePriv] AS rp ON p.PrivID = rp.PrivID
                                JOIN [dbo].[admin_SecRole] AS r ON r.RoleID = rp.RoleID
                                JOIN [dbo].[admin_SecUserRole] AS ur ON ur.RoleID = r.RoleID
                        WHERE   ur.[UserID] = @UserID
                                AND p.[PrivCode] = @PrivCode
                                AND @PrivCode = @CheckPrivCode )
            BEGIN
                RETURN 0;
            END

		 /* ARD : state filter log for Active */
        IF ( @StateID IS NULL )
            BEGIN
                SET @StateID = ( SELECT MBBS.StateID
                                 FROM   dbo.tblBusinessBaseStates MBBS
                                        JOIN dbo.tblBusinessBaseStateControl MBBSC ON MBBS.StateControlID = MBBSC.StateControlID
                                        JOIN dbo.tblBusinessBaseObject MBBO ON MBBSC.BBOID = MBBO.BBOID
                                                              AND MBBO.BBOID = ( SELECT
                                                              BBOID
                                                              FROM
                                                              dbo.tblBusinessBaseObject
                                                              WHERE
                                                              BBOTable = 'MASubmissionWorkstream'
                                                              )
                                 WHERE  MBBS.StateName = 'In Assessment' /* ARD #FIXME if states change for Active this will be impacted*/
                               )
            END
            
        DECLARE @SWBBOID INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'SW'
                               )
        DECLARE @BBOID INT = ( SELECT   BBOID
                               FROM     dbo.tblBusinessBaseObject
                               WHERE    BBOCode = 'SW'
                             )
/* -------------------------------------------------------------------------------------------------------------------------------------------------------- */
-- Create a temporary table to house all of the possible Submissions that will be pulled from in the query.
        IF OBJECT_ID('tempdb..#EMCS') IS NOT NULL
            DROP TABLE #EMCS

		-- Create an entrance point for applications that are already filtered.
        CREATE TABLE #EMCS
            (
              MASubmissionWorkstreamID INT NOT NULL
            )
        CREATE CLUSTERED INDEX IDX_TMP_01 ON #EMCS(MASubmissionWorkstreamID)

		-- Preload all of the possible MA license/scope names; with modifiers.
        INSERT  INTO #EMCS
                SELECT DISTINCT
                        xmasw.MASubmissionWorkstreamID
                FROM    dbo.MASubmissionWorkstream xmasw
                        JOIN dbo.udf_AccessibleMAApplications(@UserID) xma ON xma.MAApplicationID = xmasw.MAApplicationID
                        --ARD 2014-01-07: (A) LEFT JOIN dbo.tblMALicense xmal ON xmal.MASubmissionWorkstreamID = xmasw.MASubmissionWorkstreamID
                        --LEFT JOIN ( dbo.tblMALicenseScope xmls  --ARD 2014-01-07: Removed this.  Country search now points to sub route config
                        LEFT JOIN ( dbo.MASubmissionWorkstreamStrength xmas
                                    JOIN dbo.tblStrength xs ON xs.StrengthID = xmas.StrengthID
                                    JOIN dbo.tblForm xf ON xf.FormID = xs.FormID
                                  ) ON xmasw.MASubmissionWorkstreamID = xmas.MASubmissionWorkstreamID
                        
                        --LEFT JOIN dbo.tblCountryLinkCountryGroup clcg ON xmls.CountryID = clcg.CountryID --ARD 2014-01-07: Removed this.  Country Group search now points to sub route config
                        JOIN dbo.tblMAApplication maap ON maap.MAApplicationID = xmasw.MAApplicationID
                        JOIN dbo.tblProduct prd ON maap.ProductGroupID = prd.ProductID
                        JOIN dbo.tblValidMASubmissionType vmst ON vmst.ValidMASubmissionTypeID = xmasw.ValidMASubmissionTypeID
                WHERE   ( ( @PerfectProdSearch = 1
                            AND xf.Name = @ProductName
                          )
                          OR ( @ProductName IS NULL
                               OR ( xf.Name LIKE @ProductName
                               --ARD 2014-01-07:  This isn't in the grid so it was removed.  To add it back in uncomment (A) Above
                               --     OR xmal.RegisteredProductName LIKE @ProductGroupName
                                    )
                               OR ( prd.Name LIKE @ProductName )
                             )
                        )
                        AND ( @MASubmissionWorkstreamID IS NULL
                              OR xmasw.MASubmissionWorkstreamID = @MASubmissionWorkstreamID
                            )
                        AND ( @CountryGroupID IS NULL
                              OR xmasw.HealthAuthorityid IN (
                              SELECT DISTINCT
                                        ysrc.HealthAuthorityID
                              FROM      dbo.tblSubmissionRouteConfig ysrc
                                        JOIN dbo.tblCountryLinkCountryGroup clcg ON clcg.CountryID = ysrc.CountryID
                                                              AND clcg.CountryGroupID = @CountryGroupID )
                            )
                        AND ( @CountryID IS NULL
                              OR xmasw.HealthAuthorityid IN (
                              SELECT DISTINCT
                                        xsrc.HealthAuthorityID
                              FROM      dbo.tblSubmissionRouteConfig xsrc
                              WHERE     xsrc.countryid = @CountryID )
                            )
                        AND ( @ApplicationNum IS NULL
                              OR xma.ProcedureNumber LIKE @ApplicationNum
                              --ARD 2014-01-07: Took this out. Not in the grid
                              --OR xmas.FullProcedureNumber LIKE @ProcedureNum
                              --OR xma.MAApplicationID LIKE REPLACE(@ProcedureNum,
                              --                                '%', '')
                            )
                        AND ( @RegTeamID IS NULL
                              OR xma.RegulatoryTeamID = @RegTeamID
                            )
                        AND ( @RegLeadID IS NULL
                              OR xmasw.LeadID = @RegLeadID
                            )
                        AND ( ( @SubmissionRouteID IS NULL
                                AND xmasw.SubmissionRouteID != 6
                              )
                              OR xmasw.SubmissionRouteID = @SubmissionRouteID
                            )
                        AND ( @ApplicationID IS NULL
                              OR xma.MAApplicationID = @ApplicationID
                            )
                        AND ( @MASubmissionWorkstreamID IS NULL
                              OR xmasw.MASubmissionWorkstreamID = @MASubmissionWorkstreamID
                            )
                        AND ( @ValidMASubmissionTypeID IS NULL
                              OR xmasw.ValidMASubmissionTypeID = @ValidMASubmissionTypeID
                            )
                        AND ( @MASubmissionWorkstreamStatusID IS NULL
                              OR xmasw.MASubmissionWorkstreamStatusID = @MASubmissionWorkstreamStatusID
                            )
                        AND ( @SubmissionTracking IS NULL
                              OR xmasw.SubmissionTracking LIKE @SubmissionTracking
                            )
                        AND ( @ShowCMSSubmissions = 1
                              OR ( ( @ShowCMSSubmissions = 0
                                     OR @ShowCMSSubmissions IS NULL
                                   )
                                   AND xmasw.ParentSubmissionID IS NULL
                                 )
                            )
                        AND ( ( @SubmissionStartDate IS NULL
                                AND @SubmissionEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     tblGlobalMilestone gm
                                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( tblMilestone m
                                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'Submission'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @SubmissionStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @SubmissionEndDate
                                            ) ) )
                            )
                        AND ( ( @RegCloseStartDate IS NULL
                                AND @RegCloseEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     tblGlobalMilestone gm
                                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( tblMilestone m
                                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'SW - Reg Proc Close'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @RegCloseStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @RegCloseEndDate
                                            ) ) )
                            )
                        AND ( ( @FinalApproveStartDate IS NULL
                                AND @FinalApproveEndDate IS NULL
                              )
                              OR ( xmasw.MASubmissionWorkstreamID IN (
                                   SELECT   m.ObjectID
                                   FROM     tblGlobalMilestone gm
                                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                                            JOIN ( tblMilestone m
                                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                   LEFT JOIN dbo.tblMilestone
                                                   AS ref ON m.ReferenceMilestoneID = ref.MileStoneID
                                                 ) ON m.ObjectID = xmasw.MASubmissionWorkstreamID
                                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                                                      AND gm.Code = 'SW - Final Reg Approval'
                                   WHERE    ( m.ObjectID = xmasw.MASubmissionWorkstreamID
                                              AND m.BBOID = @BBOID
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) >= @FinalApproveStartDate
                                              AND COALESCE(ref.BestEstimateDate,
                                                           m.BestEstimateDate) <= @FinalApproveEndDate
                                            ) ) )
                            )

--select * from #EMCS
        SELECT  ha.MAHAActionID "id" ,
                STUFF(( SELECT  DISTINCT
                                ', ' + f.Name + ' ['
                                + STUFF(( SELECT    ', ' + s.Name
                                          FROM      dbo.tblStrength s
                                          WHERE     s.FormID = f.formID
                                                    AND s.IsUndefined = 0
                                          ORDER BY  s.Name
                                        FOR
                                          XML PATH('')
                                        ), 1, 2, '') + ']'
                        FROM    tblForm f
                                JOIN dbo.tblStrength s ON f.FormID = s.FormID
                                JOIN dbo.MASubmissionWorkstreamStrength mas ON s.StrengthID = mas.StrengthID
                        WHERE   mas.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                        --ORDER BY ', ' + f.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') "Product" ,
                COALESCE(c.shortName, c.Name) "Development Site" ,
                maa.ProcedureNumber "Application Number" ,
                COALESCE(c2.ShortName, c2.Name) "Assessing HA" ,
                sr.Name "Submission Route" ,
                vmast.Name "Submission Type" ,
                masw.SubmissionTracking "Submission Tracking" ,
                ( SELECT    CASE WHEN m.ReferenceMilestoneID IS NULL
                                 THEN m.BestEstimateDate
                                 ELSE refm.BestEstimateDate
                            END
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'Submission'
                ) "Submission Date" ,
                ( SELECT    vms.Name
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'Submission'
                ) "Submission Date Status" ,
                vhaas.Name "HA Action Scope" ,
                STUFF(( SELECT DISTINCT
                                ', ' + vst.Name
                        FROM    [dbo].tblValidMAHAActionScopeTopic vst
                                JOIN [dbo].MAHAActionLinkHAActionScopeTopic lk ON vst.ValidMAHAActionScopeTopicID = lk.ValidMAHAActionScopeTopicID
                        WHERE   lk.MAHAActionID = ha.MAHAActionID
                        ORDER BY ', ' + vst.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') "HA Action Scope Topic" ,
                STUFF(( SELECT DISTINCT
                                ', ' + vmod.Name
                        FROM    [dbo].tblValidMAHAActionModule vmod
                                JOIN [dbo].MAHAActionLinkHAActionModule lkm ON vmod.ValidMAHAActionModuleID = lkm.ValidMAHAActionModuleID
                        WHERE   lkm.MAHAActionID = ha.MAHAActionID
                        ORDER BY ', ' + vmod.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') "HA Action Module" ,
                ( SELECT    mti.Name
                  FROM      tblMilestoneTemplateItem mti
                            JOIN tblMilestone m ON mti.MilestoneTemplateItemID = m.MilestoneTemplateItemID
                  WHERE     m.MileStoneID = ha.RelatedMilestoneID
                ) "Related Milestone" ,
                ha.ReceivedDate "Action Date" ,
                CASE WHEN ha.ResponseDate IS NULL THEN 'No'
                     ELSE 'Yes'
                END "Status" ,
                ha.TargetResponseDate "Target Response Date" ,
                COALESCE(ha.ResponseDate, ha.TargetResponseDate) "Response Date" ,
                CASE WHEN ha.ResponseDate IS NULL
                     THEN CONVERT(NVARCHAR, DATEDIFF(DAY, ha.ReceivedDate,
                                                     GETDATE()))
                          + ' and counting'
                     ELSE CONVERT(NVARCHAR, DATEDIFF(DAY, ha.ReceivedDate,
                                                     ha.ResponseDate))
                END "Days To Answer" ,
                ha.Comments "Comments" ,
                ha.ResponseComments "Response Comments" ,
                'expired' "Blocking Patent" ,
                ( SELECT    MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                     THEN m.BestEstimateDate
                                     ELSE refm.BestEstimateDate
                                END)
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'SW - Reg Proc Close'
                ) "Regulatory Procedure Close Date" ,
                ( SELECT    vms.Name
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'SW - Reg Proc Close'
                ) "Regulatory Procedure Close Status" ,
                ( SELECT    MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                     THEN m.BestEstimateDate
                                     ELSE refm.BestEstimateDate
                                END)
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'SW - Final Reg Approval'
                ) "Final Regulatory Approval" ,
                ( SELECT    vms.Name
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'SW - Final Reg Approval'
                ) "Final Regulatory Approval Status" ,
                ( SELECT    MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                     THEN m.BestEstimateDate
                                     ELSE refm.BestEstimateDate
                                END)
                  FROM      tblGlobalMilestone gm
                            JOIN tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( tblMilestone m
                                   JOIN tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.Objectid = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @SWBBOID
                            AND gm.Code = 'SW - Final Reg Approval'
                ) "Days to Approval" ,
                masw.WorkstreamName "SubmissionID" ,
                masw.MASubmissionWorkstreamID
        FROM    #EMCS fmsw
                JOIN dbo.MASubmissionWorkstream masw ON fmsw.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                JOIN dbo.MAHAAction ha ON ha.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                JOIN dbo.udf_AccessibleMAApplications(@UserID) maa ON maa.MAApplicationID = masw.MAApplicationID
                JOIN dbo.tblProduct p ON p.ProductID = maa.ProductGroupID
                --LEFT JOIN ( dbo.MASubmissionWorkstreamStrength xmas
                               
                --                JOIN dbo.tblStrength xs ON xs.StrengthID = xmas.StrengthID
                --                JOIN dbo.tblForm xf ON xf.FormID = xs.FormID
                --             ) ON masw.MASubmissionWorkstreamID = xmas.MASubmissionWorkstreamID
                JOIN dbo.tblSubmissionRoute sr ON masw.SubmissionRouteID = sr.SubmissionRouteID
                JOIN dbo.tblValidMASubmissionType vmast ON masw.ValidMASubmissionTypeID = vmast.ValidMASubmissionTypeID
                JOIN dbo.tblValidMAHAActionScope vhaas ON vhaas.ValidMAHAActionScopeID = ha.ValidMAHAActionScopeID
                LEFT JOIN tblCompany c ON maa.DevelopmentSiteID = c.CompanyID
                LEFT JOIN tblCompany c2 ON masw.HealthAuthorityID = c2.CompanyID
        ORDER BY p.Name ,
                masw.MASubmissionWorkstreamID
        
        IF OBJECT_ID('tempdb..#EMCS') IS NOT NULL
            DROP TABLE #EMCS   
    END TRY

    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END  CATCH
GO
