SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


/*============================================
								create procedure
============================================*/

CREATE PROCEDURE [dbo].[ddl_GetSalesLoads]
(
@FormID INT
)
AS

BEGIN TRY
				SELECT 
					SalesLoadID, 
						Name 
				FROM 
					tblSalesLoad 
				WHERE
					tblSalesLoad.FormID = @FormID
				ORDER BY 
					UploadDate DESC
END TRY

BEGIN CATCH
	EXEC sp_RollAndRaise
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_GetSalesLoads] TO [mp_db_execute]
GO
