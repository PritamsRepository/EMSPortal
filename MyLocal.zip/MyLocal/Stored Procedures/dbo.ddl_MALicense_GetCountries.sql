SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

--EXEC [dbo].[ddl_MALicense_GetCountries] @UserID = 1426, @IsEMASelected = 1
CREATE PROCEDURE [dbo].[ddl_MALicense_GetCountries]
    @UserID INT = NULL,
    @IsEMASelected BIT = 0
AS
BEGIN TRY

    SELECT DISTINCT
           c1.CountryID,
           c1.Name,
           CASE
               WHEN c1.Code = 'US' THEN
                   1
               WHEN c1.Code = 'CA' THEN
                   2
               WHEN c1.Code = 'AU' THEN
                   3
               WHEN c1.Code = 'JP' THEN
                   4
               WHEN c1.Code = 'NZ' THEN
                   5
               WHEN c1.Code = 'IT' THEN
                   6
               WHEN c1.Code = 'ES' THEN
                   7
               ELSE
                   8
           END AS [Priority]
    FROM dbo.tblMALicenseScope MALS
        JOIN dbo.tblCountry c1
            ON c1.CountryID = MALS.CountryID
    WHERE dbo.udf_UserHasPrivForCountry(@UserID, 'MA01', c1.CountryID) = 'true'
    UNION ALL
    SELECT c.CountryID,
           c.Name,
           8 AS [Priority]
    FROM dbo.tblCountry c
    WHERE c.Code = 'EMA'
          AND @IsEMASelected = 1
    ORDER BY [Priority],
             Name
    OPTION (FORCE ORDER);

--SELECT DISTINCT
--        C1.CountryID ,
--        C1.Name ,
--        CASE WHEN C1.Code = 'US' THEN 1
--             WHEN C1.Code = 'CA' THEN 2
--             WHEN C1.Code = 'AU' THEN 3
--             WHEN C1.Code = 'JP' THEN 4
--             WHEN C1.Code = 'NZ' THEN 5
--             WHEN C1.Code = 'IT' THEN 6
--             WHEN C1.Code = 'SP' THEN 7
--             ELSE 8
--        END AS [Priority]
--FROM    dbo.tblMALicenseScope MALS ,
--        dbo.tblCountry C1 ,
--        dbo.tblMALicense MAL ,
--        ( SELECT DISTINCT
--                    MAA2.MAApplicationID
--          FROM      dbo.tblMAApplication MAA2 ,
--                    dbo.tblSubmissionRoute SR1 ,
--                    dbo.tblSubmissionRouteConfig SRC1 ,
--                    ( SELECT DISTINCT
--                                CountryID ,
--                                ISNULL(( SELECT DISTINCT
--                                                1
--                                         FROM   [dbo].[admin_SecUserRole] ur
--                                                JOIN [dbo].[admin_SecRole]
--                                                AS r ON ur.RoleID = r.RoleID
--                                                      AND ur.[UserID] = @UserID
--                                                JOIN [dbo].[admin_SecRolePriv]
--                                                AS rp ON r.RoleID = rp.RoleID
--                                                      AND rp.PrivID = ( SELECT
--                                                      PrivID
--                                                      FROM
--                                                      dbo.admin_SecPriv
--                                                      WHERE
--                                                      PrivCode = 'MA01'
--                                                      )
--                                                LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountry]
--                                                AS lc ON ur.UserRoleID = lc.UserRoleID
--                                                LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountryGroup]
--                                                AS lcg ON ur.UserRoleID = lcg.UserRoleID
--                                         WHERE  ur.isUnrestricted = 'true'
--                                                OR lc.CountryID = C2.CountryID
--                                                OR EXISTS ( SELECT
--                                                      clcg.[CountryID]
--                                                      FROM
--    [dbo].[tblCountryLinkCountryGroup]
--                                                      AS clcg
--                                                      WHERE
--                                                      clcg.[CountryGroupID] = lcg.CountryGroupID
--                                                      AND clcg.[CountryID] = C2.CountryID )
--                                       ), 0) AS Privs
--                      FROM      dbo.tblCountry C2
--                    ) P1
--          WHERE     SR1.ISHADependent = 0
--                    AND P1.Privs = 1
--                    AND MAA2.SubmissionRouteID = SR1.SubmissionRouteID
--                    AND SRC1.CountryID = P1.CountryID
--                    AND SR1.SubmissionRouteID = SRC1.SubmissionRouteID
--          UNION
--          SELECT DISTINCT
--                    MAA3.MAApplicationID
--          FROM      dbo.tblMAApplication MAA3 ,
--                    dbo.tblSubmissionRoute SR2 ,
--                    dbo.tblSubmissionRouteConfig SRC2 ,
--                    ( SELECT DISTINCT
--                                CountryID ,
--                                ISNULL(( SELECT DISTINCT
--                                                1
--                                         FROM   [dbo].[admin_SecUserRole] ur
--                                                JOIN [dbo].[admin_SecRole]
--                                                AS r ON ur.RoleID = r.RoleID
--                                                      AND ur.[UserID] = @UserID
--                                                JOIN [dbo].[admin_SecRolePriv]
--                                                AS rp ON r.RoleID = rp.RoleID
--                                                      AND rp.PrivID = ( SELECT
--                                                      PrivID
--                                                      FROM
--                                                      dbo.admin_SecPriv
--                                                      WHERE
--                                                      PrivCode = 'MA01'
--                                                      )
--                                                LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountry]
--                                                AS lc ON ur.UserRoleID = lc.UserRoleID
--                                                LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountryGroup]
--                                                AS lcg ON ur.UserRoleID = lcg.UserRoleID
--                                         WHERE  ur.isUnrestricted = 'true'
--                                                OR lc.CountryID = C3.CountryID
--                                                OR EXISTS ( SELECT
--                                                      clcg.[CountryID]
--                                                      FROM
--                                                      [dbo].[tblCountryLinkCountryGroup]
--                                                      AS clcg
--                                                      WHERE
--                                                      clcg.[CountryGroupID] = lcg.CountryGroupID
--                                                      AND clcg.[CountryID] = C3.CountryID )
--                                       ), 0) AS Privs
--                      FROM      dbo.tblCountry C3
--                    ) P2
--          WHERE     SR2.ISHADependent = 1
--                    AND P2.Privs = 1
--                    AND MAA3.SubmissionRouteID = SR2.SubmissionRouteID
--                    AND MAA3.HealthAuthorityID = SRC2.HealthAuthorityID
--                    AND SRC2.CountryID = P2.CountryID
--                    AND SR2.SubmissionRouteID = SRC2.SubmissionRouteID
--        ) MAA1
--WHERE   MAL.MAApplicationID = MAA1.MAApplicationID
--        AND MALS.MALicenseID = MAL.MALicenseID
--        AND C1.CountryID = MALS.CountryID
--ORDER BY [Priority] ,
--        C1.Name
--OPTION  ( FORCE ORDER )


END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;





GO
GRANT EXECUTE ON  [dbo].[ddl_MALicense_GetCountries] TO [mp_db_execute]
GO
