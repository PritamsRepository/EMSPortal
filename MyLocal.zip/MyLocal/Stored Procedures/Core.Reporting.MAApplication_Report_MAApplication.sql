SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_MAApplication]
(
    @MAApplicationID INT = NULL,
    @Country NVARCHAR(MAX) = NULL,
    @Region NVARCHAR(MAX) = NULL
)
AS
BEGIN
    DECLARE @CountryID INT =
            (
                SELECT CountryID FROM dbo.tblCountry WHERE Code = @Country
            );

    DECLARE @CountryGroupID INT =
            (
                SELECT CountryGroupID
                FROM dbo.tblCountryGroup
                WHERE CountryGroupType = 'MAMkt'
                      AND Name = @Region
            );
    DECLARE @swbboid INT =
            (
                SELECT BBOID FROM dbo.tblBusinessBaseObject WHERE BBOCode = 'SW'
            );

    -- Sheet 1 MAApplications
    SELECT ma.MAApplicationID,
           ma.ProcedureNumber AS [Application Number],
           p.ProductID,
           p.Name AS [Product Group],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + vf.Name
               FROM dbo.tblForm f
                   JOIN dbo.tblValidForm vf
                       ON vf.ValidFormID = f.ValidFormID
                   JOIN dbo.tblStrength s
                       ON s.FormID = f.FormID
                   JOIN dbo.tblMAStrength mas
                       ON mas.StrengthID = s.StrengthID
               WHERE ma.MAApplicationID = mas.MAApplicationID
               ORDER BY ', ' + vf.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Dosage Form],
           sr.NAME AS [Submission Route],
           vdr.Name AS [Development Route],
           dev.Name AS [Development Site],
           STUFF(
           (
               SELECT ', ' + s.Name
               FROM dbo.tblStrength s
                   JOIN dbo.tblMAStrength mas
                       ON mas.StrengthID = s.StrengthID
               WHERE mas.MAApplicationID = ma.MAApplicationID
                     AND s.IsUndefined = 0
               ORDER BY s.Name
               --FOR XML PATH('')
               FOR XML PATH(''), ROOT('mystring'), TYPE
                ).value('/mystring[1]', 'varchar(max)'),
           1,
           2,
           ''
                ) AS [Strengths],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + f.Name
               FROM dbo.tblForm f
                   JOIN dbo.tblStrength s
                       ON s.FormID = f.FormID
                   JOIN dbo.tblMAStrength mas
                       ON mas.StrengthID = s.StrengthID
               WHERE ma.MAApplicationID = mas.MAApplicationID
               ORDER BY ', ' + f.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Products],
           vat.Name AS [Application Type],
           ha.Name AS [Assessing HA],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + c.Code
               FROM dbo.tblMALicense mal
                   JOIN dbo.tblMALicenseScope mals
                       ON mal.MALicenseID = mals.MALicenseID
                   JOIN dbo.tblCountry c
                       ON mals.CountryID = c.CountryID
               WHERE ma.MAApplicationID = mal.MAApplicationID
                     AND c.Code IS NOT NULL
               ORDER BY ', ' + c.Code
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Countries],
           submitter.Name AS [Application Submitter],
           COALESCE(asu.FullName, asu.ADUserName) AS [Reviewed By],
           REPLACE(CONVERT(VARCHAR(15), ma.ReviewedOn, 106), ' ', '-') AS [Reviewed On],
           (
               SELECT TOP (1)
                      REPLACE(CONVERT(VARCHAR(15), c.EntryDate, 106), ' ', '-')
               FROM dbo.admin_ChangeTracking_Audit c
                   CROSS APPLY
               (
                   SELECT allAudit.ChangeTrackingID
                   FROM
                   (
                       SELECT acta.ChangeTrackingID
                       FROM dbo.admin_ChangeTracking_Audit acta
                           JOIN
                           (
                               SELECT ChangeTrackingID
                               FROM dbo.admin_ChangeTrackingRelationships_Audit CTR
                               WHERE ParentObjectID = ma.MAApplicationID
                                     AND CTR.ParentBBOID = 59
                           ) relAudit
                               ON acta.ChangeTrackingID = relAudit.ChangeTrackingID
                       UNION ALL
                       SELECT acta.ChangeTrackingID
                       FROM dbo.admin_ChangeTracking_Audit acta
                       WHERE acta.BusinessBasedObjectID = 59
                             AND acta.ObjectID = ma.MAApplicationID
                   ) allAudit
                   WHERE allAudit.ChangeTrackingID = c.ChangeTrackingID
                   GROUP BY allAudit.ChangeTrackingID
               ) t4
               ORDER BY c.EntryDate DESC
           ) AS [Latest Audit Trail Activity],
           STUFF(
           (
               SELECT DISTINCT ', ' + cg.Name
               FROM dbo.tblCountryGroup cg
                   JOIN dbo.tblCountryLinkCountryGroup clcg
                       ON clcg.CountryGroupID = cg.CountryGroupID
                   JOIN dbo.tblMALicenseScope mals
                       ON mals.CountryID = clcg.CountryID
                   JOIN dbo.tblMALicense mal
                       ON mal.MALicenseID = mals.MALicenseID
               WHERE mal.MAApplicationID = ma.MAApplicationID
               AND cg.CountryGroupType = 'KeyMkt'
			   ORDER BY ', ' + cg.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Region
    --COALESCE(regLead.FullName, regLead.ADUserName) AS [Regulatory Lead],
    --COALESCE(gccra.FullName, gccra.ADUserName) AS [Global CC RA Lead],
    --COALESCE(labelLead.FullName, labelLead.ADUserName) AS [Labelling Lead]
    FROM dbo.tblMAApplication ma
        JOIN dbo.tblProduct p
            ON p.ProductID = ma.ProductGroupID
        JOIN dbo.tblCompany ha
            ON ha.CompanyID = ma.HealthAuthorityID
        JOIN dbo.tblSubmissionRoute sr
            ON sr.SubmissionRouteID = ma.SubmissionRouteID
        JOIN dbo.tblValidApplicationType vat
            ON vat.ValidApplicationTypeID = ma.ValidApplicationTypeID
        LEFT JOIN dbo.tblCompany dev
            ON dev.CompanyID = ma.DevelopmentSiteID
        LEFT JOIN dbo.tblCompany submitter
            ON submitter.CompanyID = ma.ApplicationSubmitterID
        LEFT JOIN dbo.admin_SecUser asu
            ON asu.UserID = ma.ReviewedByID
        LEFT JOIN dbo.admin_SecUser regLead
            ON regLead.UserID = ma.RegulatoryLeadID
        LEFT JOIN dbo.admin_SecUser gccra
            ON gccra.UserID = ma.GlobalCCRALeadID
        LEFT JOIN dbo.admin_SecUser labelLead
            ON labelLead.UserID = ma.LabelingLeadID
        LEFT JOIN dbo.tblValidDevelopmentRoute vdr
            ON vdr.ValidDevelopmentRouteID = ma.ValidDevelopmentRouteID
    WHERE (
              @MAApplicationID IS NULL
              OR ma.MAApplicationID = @MAApplicationID
          )
          AND
          (
              @CountryID IS NULL
              OR @CountryID IN
                 (
                     SELECT mals.CountryID
                     FROM dbo.tblMALicenseScope mals
                         JOIN dbo.tblMALicense mal
                             ON mal.MALicenseID = mals.MALicenseID
                     WHERE mal.MAApplicationID = ma.MAApplicationID
                 )
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID IN
                 (
                     SELECT clcg.CountryGroupID
                     FROM dbo.tblCountryLinkCountryGroup clcg
                         JOIN dbo.tblMALicenseScope mals
                             ON mals.CountryID = clcg.CountryID
                         JOIN dbo.tblMALicense mal
                             ON mal.MALicenseID = mals.MALicenseID
                     WHERE mal.MAApplicationID = ma.MAApplicationID
                 )
          );
END;
GO
