SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_PATCERTREV_Litigations]
	@FormID int,
	@CountryID int,
	@UserID int,
	@PrivCode nvarchar(10)
AS

BEGIN TRY
		SELECT DISTINCT
			--lit.[LitigationID],
			li.[LegalInfoID],
			c.[CountryID],
			c.[Code] AS Country,
			rs.Name AS RegStay,
			li.CompetitorLitigationComments,
			li.MylanLitigationComments,
			li.RegStayComments
			--lit.[GenericParty],
			--[dbo].[udf_StrengthListByLitigationID](lit.[LitigationID]) AS Strengths,
			--lit.[ValidLitigationTypeID],
			--vlt.[Name] AS ValidLitigationType,
			--[dbo].[udf_PatentListByLitigationID](lit.[LitigationID]) AS PatentsInSuit,
			--lit.GeneralComments
		FROM
			pm.LegalInfo AS li 
			--JOIN pm.Litigation AS lit ON li.[LegalInfoID] = lit.[LegalInfoID]
			JOIN [dbo].[tblCountry] as c ON li.[CountryID] = c.[CountryID]
			LEFT JOIN dbo.tblValidRegStay rs ON rs.ValidRegStayID = li.ValidRegStayID
			--LEFT JOIN [dbo].[tblValidLitigationType] as vlt ON lit.[ValidLitigationTypeID] = vlt.[ValidLitigationTypeID]
		WHERE
			li.[FormID] = @FormID AND
			c.CountryID = @CountryID AND
			[dbo].[udf_UserHasPrivForCountry]( @UserID, @PrivCode, c.[CountryID]) = 'true'
		ORDER BY
			c.[Code]
END TRY

BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_PATCERTREV_Litigations] TO [mp_db_execute]
GO
