SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Comment_Insert]
    @BBOID INT,
    @ObjectID INT,
    @Comment NVARCHAR(MAX),
    @UpdateUserId INT,
    @Category NVARCHAR(128)
AS
BEGIN
    DECLARE @ID INT,
            @BBOCode NVARCHAR(50),
            @ActionType CHAR(1),
            @RowsAffected INT,
            @ReturnValue INT,
            @ConcurIDinDB TIMESTAMP;

    SELECT @BBOCode = BBOCode
    FROM dbo.tblBusinessBaseObject
    WHERE BBOID = @BBOID;

    BEGIN TRAN AddComment;

    INSERT INTO [dbo].[tblComment]
    (
        [BBOID],
        [ObjectID],
        [Comment],
        [UserID],
        [Category],
        [CommentDate]
    )
    VALUES
    (@BBOID, @ObjectID, @Comment, @UpdateUserId, @Category, GETDATE());

    SET @RowsAffected = @@ROWCOUNT;
    SET @ActionType = 'I';
    SET @ReturnValue = SCOPE_IDENTITY();

    SELECT @ReturnValue AS ID,
           ConcurrencyID
    FROM dbo.tblComment
    WHERE CommentID = @ReturnValue;

    IF (@RowsAffected = 0)
    BEGIN
        EXEC dbo.sp_RaiseCustomError 3;
    END;

    IF (@RowsAffected = 1)
    BEGIN
        EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                                                 @UserID = @UpdateUserId,
                                                 @ObjectID = @ObjectID,
                                                 @ActionType = @ActionType;

    END;
    COMMIT;
    RETURN 0;
END;


GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Comment_Insert] TO [mp_db_execute]
GO
