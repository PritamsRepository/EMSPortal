SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MAStrength_ByMAApplication]
    @MAApplicationID INT 
AS /* 
	Author:	ARD
	Date:	3-Aug-2011
	Description: Provide a list of MAStrengths that can be used to linked  a license to an MAApplication
	
	
	*/
    BEGIN TRY	
    
    SELECT  DISTINCT MAS.MAStrengthID ,/* need MAStrength not the Strength ID*/
                F.Name + ' ' + S.Name AS Product
                FROM    dbo.tblMAStrength MAS
                       JOIN dbo.tblStrength S ON MAS.StrengthID = S.StrengthID
                       JOIN dbo.tblForm F ON S.FormID = F.FormID 
                       WHERE MAS.MAApplicationID=@MAApplicationID

	/*EXCEPT
	SELECT  DISTINCT MAS.MAStrengthID ,
                F.Name + ' ' + S.Name AS Product
                FROM    dbo.tblMAStrength MAS
                JOIN dbo.tblStrength S ON MAS.StrengthID = S.StrengthID
                       JOIN dbo.tblForm F ON S.FormID = F.FormID 
                JOIN dbo.tblMALicenseScope MLS ON MAS.MAStrengthID = MLS.MAStrengthID
                 WHERE MAS.MAApplicationID=@MAApplicationID*/
	
    END TRY

    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 






GO
GRANT EXECUTE ON  [dbo].[ddl_MAStrength_ByMAApplication] TO [mp_db_execute]
GO
