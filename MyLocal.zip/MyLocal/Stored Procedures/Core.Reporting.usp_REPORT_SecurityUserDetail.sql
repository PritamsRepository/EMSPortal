SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_SecurityUserDetail]
    @SecurityUserID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
SELECT su.UserID,
       su.ADUserName,
       su.FullName,
       su.EmailAddress,
       'Inactive' = CASE su.Active
                        WHEN 1 THEN
                            'No'
                        ELSE
                            'Yes'
                    END,
       su.JobTitle,
       su.Department,
       su.DirectManagerID,
       su.Location,
       'LastLogin' = CASE
                         WHEN ISNULL(adt.LastLogin, '1/1/1900') = '1/1/1900' THEN
                             NULL
                         ELSE
                             adt.LastLogin
                     END,
       c.[Name] AS 'Country',
       mgr.[Name] AS 'DirectManager',
       su.Requests
FROM dbo.admin_SecUser AS su
    LEFT JOIN [dbo].[tblValidManager] AS mgr
        ON su.DirectManagerID = mgr.ValidManagerID
    LEFT JOIN dbo.tblCountry AS c
        ON su.CountryID = c.CountryID
    LEFT JOIN
    (
        SELECT UserID,
               'LastLogin' = MAX(ISNULL(LogDate, '1/1/1900'))
        FROM dbo.admin_AuditTrail
        WHERE ATEventID = 1
              AND UserID = @SecurityUserID
        GROUP BY UserID
    ) AS adt
        ON su.UserID = adt.UserID
WHERE su.UserID = @SecurityUserID
      AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1;


GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_SecurityUserDetail] TO [mp_db_execute]
GO
