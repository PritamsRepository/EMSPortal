SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Correspondence]
    (
      @MAApplicationID INT = NULL ,
      @Country NVARCHAR(MAX) = NULL ,
      @Region NVARCHAR(MAX) = NULL
    )
AS
    BEGIN
        DECLARE @CountryID INT = ( SELECT   CountryID
                                   FROM     dbo.tblCountry
                                   WHERE    Code = @Country
                                 )

        DECLARE @CountryGroupID INT = ( SELECT  CountryGroupID
                                        FROM    dbo.tblCountryGroup
                                        WHERE   CountryGroupType = 'MAMkt'
                                                AND Name = @Region
                                      )
        DECLARE @swbboid INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'SW'
                               )

        SELECT  masw.MAApplicationID ,
                masw.MASubmissionWorkstreamID ,
                maha.MAHAActionID AS CorrespondenceID ,
                REPLACE(CONVERT(VARCHAR(15), maha.ReceivedDate, 106), ' ', '-') AS [Correspondence Date] ,
                STUFF(( SELECT  ', ' + am.Name
                        FROM    dbo.MAHAActionLinkHAActionModule lam
                                JOIN dbo.tblValidMAHAActionModule am ON am.ValidMAHAActionModuleID = lam.ValidMAHAActionModuleID
                        WHERE   lam.MAHAActionID = maha.MAHAActionID
                        ORDER BY ', ' + am.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Type(s)] ,
                STUFF(( SELECT  ', ' + vhast.NAME
                        FROM    dbo.MAHAActionLinkHAActionScopeTopic mast
                                JOIN dbo.tblValidMAHAActionScopeTopic vhast ON vhast.ValidMAHAActionScopeTopicID = mast.ValidMAHAActionScopeTopicID
                        WHERE   mast.MAHAActionID = maha.MAHAActionID
                        ORDER BY ', ' + vhast.NAME
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Topic(s)] ,
                vhas.Name AS [Status] ,
                maha.Comments AS [Comment] ,
                REPLACE(CONVERT(VARCHAR(15), maha.ResponseDate, 106), ' ', '-') AS [ResponseDate]
        FROM    dbo.MASubmissionWorkstream masw
                JOIN dbo.tblCompany ha ON ha.CompanyID = masw.HealthAuthorityID
                JOIN dbo.MAHAAction maha ON maha.MASubmissionWorkstreamID = masw.MASubmissionWorkstreamID
                LEFT JOIN dbo.tblValidMAHAActionStatus vhas ON vhas.ValidMAHAActionStatusID = maha.ValidMAHAActionStatusID
                LEFT JOIN dbo.tblValidMAHAActionScope vhasc ON vhasc.ValidMAHAActionScopeID = maha.ValidMAHAActionScopeID
        WHERE   ( @MAApplicationID IS NULL
                  OR masw.MAApplicationID = @MAApplicationID
                )
                AND ( @CountryID IS NULL
                      OR @CountryID = ha.CountryID
                    )
                AND ( @CountryGroupID IS NULL
                      OR @CountryGroupID IN ( SELECT cg.CountryGroupID
                                             FROM   dbo.tblCountryLinkCountryGroup clcg
                                                    JOIN dbo.tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
                                             WHERE  clcg.CountryID = ha.CountryID
											 AND cg.CountryGroupType = 'MAMkt'
                                           )
                    )
    END
GO
