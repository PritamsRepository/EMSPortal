SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_OrangeBook_Main]
    @FormID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
DECLARE @UpdatedBy NVARCHAR(100);
DECLARE @UpdatedDate NVARCHAR(30);
DECLARE @UpdatedTime NVARCHAR(30);

DECLARE @PATBBO INT,
        @EXBBO INT;
SELECT TOP(1)
       @PATBBO = BBOID
FROM [dbo].tblBusinessBaseObject
WHERE BBOCode = 'PAT';

SELECT TOP(1)
       @EXBBO = BBOID
FROM [dbo].tblBusinessBaseObject
WHERE BBOCode = 'EX';

BEGIN TRY;

    WITH MaxUpdateDate (FullName, UpdateDate)
    AS (SELECT su.FullName,
               MAX(bblu.UpdateDate) AS UpdateDate
        FROM dbo.tblStrength s
            JOIN pm.PatentLinkStrength slp
                ON s.StrengthID = slp.StrengthID
            JOIN pm.Patent p
                ON slp.PatentID = p.PatentID
                   AND dbo.udf_PatentIsListedForForm(@FormID, p.PatentID) = 'true'
            JOIN [dbo].tblBusinessBaseLastUpdated bblu
                ON p.PatentID = bblu.ObjectID
                   AND bblu.BBOID = @PATBBO
            JOIN dbo.admin_SecUser su
                ON bblu.UserID = su.UserID
        WHERE s.[FormID] = @FormID
              AND p.[CountryID] =
              (
                  SELECT CountryID FROM [dbo].tblCountry WHERE Code = 'US'
              )
              AND s.IsUndefined <> 1
        GROUP BY FullName
        UNION
        SELECT su.FullName,
               MAX(bblu.UpdateDate) AS UpdateDate
        FROM pm.Exclusivity AS e
            JOIN [pm].ExclusivityLinkStrength AS sle
                ON e.[ExclusivityID] = sle.[ExclusivityID]
            JOIN [dbo].[tblStrength] AS s
                ON sle.[StrengthID] = s.[StrengthID]
            JOIN [dbo].tblBusinessBaseLastUpdated bblu
                ON e.ExclusivityID = bblu.ObjectID
                   AND bblu.BBOID = @EXBBO
            JOIN dbo.admin_SecUser su
                ON bblu.UserID = su.UserID
        WHERE s.IsUndefined <> 1
              AND s.[FormID] = @FormID
              AND e.[IsListed] = 'yes'
              AND e.[CountryID] =
              (
                  SELECT CountryID FROM [dbo].tblCountry WHERE Code = 'US'
              )
        GROUP BY FullName)
    SELECT @UpdatedBy = FullName,
           @UpdatedDate = REPLACE(CONVERT(NVARCHAR(11), UpdateDate, 106), ' ', '-'),
           @UpdatedTime = SUBSTRING(CONVERT(NVARCHAR(30), UpdateDate, 100), 13, 20)
    FROM MaxUpdateDate
    WHERE UpdateDate =
    (
        SELECT MAX(UpdateDate) FROM MaxUpdateDate
    );

    SELECT DISTINCT
           dbo.udf_MarketedStrengthListByBrandID(cty.CountryID, b.BrandCompanyID, @FormID) AS Strengths,
           vf.Name AS Form,
           b.Name AS InnovatorProduct,
           c.Name AS InnovatorCompany,
           p.Name AS APIGroup,
           li.MANumberComments,
           li.MANumber,
           li.FirstMANationalDate,
           @UpdatedBy AS UpdatedBy,
           @UpdatedDate AS UpdatedDate,
           @UpdatedTime AS UpdatedTime
    FROM dbo.tblForm f
        JOIN [dbo].tblValidForm vf
            ON f.ValidFormID = vf.ValidFormID
        JOIN [dbo].tblProduct p
            ON f.ProductID = p.ProductID
        JOIN [dbo].tblBrand b
            ON f.FormID = b.FormID
        LEFT JOIN [dbo].tblCompany c
            ON b.BrandCompanyID = c.CompanyID
        JOIN [dbo].tblCountry cty
            ON b.CountryID = cty.CountryID
        LEFT JOIN pm.LegalInfo li
            ON f.FormID = li.FormID
               AND b.CountryID = li.CountryID
    WHERE f.[FormID] = @FormID
          AND cty.Code = 'US';

END TRY
BEGIN CATCH
    EXEC [dbo].[sp_RollAndRaise];
END CATCH;



GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_OrangeBook_Main] TO [mp_db_execute]
GO
