SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [Core.Common.CRUD].[Admin_MessageEvent_Insert] 
    @PrivID INT = NULL,
    @MessageEventDate DATETIME = NULL,
    @MessageEventData XML,
    @CountryGroupID INT = NULL,
    @countryID INT = NULL,
    @TeamID INT = NULL
	--@UpdateUserID INT = NULL
	--@ID INT = NULL OUTPUT
AS 
BEGIN 
	DECLARE @ReturnValue int
	DECLARE @ActionType char(1)
	DECLARE @RowsAffected int
	--DECLARE @PrivID INT 
	
	--IF (@PrivCode IS NULL)
	--BEGIN
	--	RETURN 1; /* Null privcode cannot be looked up */
	--END
	
	--SELECT @PrivID = privID FROM dbo.admin_SecPriv WHERE PrivCode=@PrivCode;
	
	BEGIN TRAN AddMessageEvent
	
	IF (@MessageEventDate IS NULL)
	BEGIN
		SET @MessageEventDate=GETDATE()
	END
	
	INSERT INTO [dbo].[admin_MessageEvent] 
		   ( [PrivID], 
			 [MessageEventDate], 
			 [MessageEventData], 
			 [CountryGroupID], 
			 [countryID], 
			 [TeamID]
		   )
	VALUES ( @PrivID, 
			 @MessageEventDate, 
			 @MessageEventData, 
			 @CountryGroupID, 
			 @countryID, 
			 @TeamID
		   )
	
	SET @RowsAffected = @@ROWCOUNT
	SET @ReturnValue = SCOPE_IDENTITY()
	SET @ActionType = 'I'
		
	IF ( @RowsAffected = 0 ) 
    BEGIN
        EXEC sp_RaiseCustomError 3
    END	
        
    COMMIT;
    
    SELECT  MessageEventID,
                ConcurrencyID
        FROM    dbo.admin_MessageEvent AS AME 
        WHERE   AME.MessageEventID = @ReturnValue
END 
	




GO
