SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_GetSitesForLicenseFilter] 
 @CompanyGroup NVARCHAR(256) 
 AS
 BEGIN TRY 
SELECT
 DISTINCT
 C.companyID ID ,
 C.NAME
 FROM dbo.tblMASite MS JOIN dbo.tblMAApplication MA ON MS.MAApplicationID = MA.MAApplicationID
 JOIN dbo.tblCompany C ON MS.CompanyID=C.CompanyID
 JOIN dbo.tblCompanyLinkCompanyGroup L ON C.CompanyID = L.CompanyID
 JOIN dbo.tblCompanyGroup CG ON L.CompanyGroupID = CG.CompanyGroupID
 AND [Text]=@CompanyGroup
 
 END TRY 
 BEGIN CATCH
 	EXEC dbo.sp_RollAndRaise
 END   CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_GetSitesForLicenseFilter] TO [mp_db_execute]
GO
