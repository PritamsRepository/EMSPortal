SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetBBOStatesByCode] @BBOCode NVARCHAR(50)
AS 
    SELECT  bbs.StateID AS [ID], bbs.StateName AS [Name]
    FROM    dbo.tblBusinessBaseObject bbo
    JOIN dbo.tblBusinessBaseStateControl bbsc ON bbo.BBOID = bbsc.BBOID
    JOIN dbo.tblBusinessBaseStates bbs ON bbsc.StateControlID = bbs.StateControlID
    WHERE   bbo.BBOCode = @BBOCode
    ORDER BY bbs.[Order]
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetBBOStatesByCode] TO [mp_db_execute]
GO
