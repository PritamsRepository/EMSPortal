SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetUsersByFilter]
    @Role NVARCHAR(256) = NULL ,
    @Name NVARCHAR(256) = NULL ,
    @Roles NVARCHAR(1000) = NULL ,
	-- Add users who are assignees for milestones for a particular workstream
    @AdditionalBBOID INT = NULL ,
    @AdditionalObjectID INT = NULL ,
    @ShowInactiveUsers BIT = 0
AS -- To avoid returning NULL's, use the ADUserName when the FullName is NULL
    SELECT DISTINCT
            su.UserID ,
            COALESCE(su.FullName, su.ADUserName) AS FullName
    FROM    admin_SecUser su
            JOIN admin_SecUserRole sur ON sur.UserID = su.UserID
            JOIN admin_SecRole sr ON sr.RoleID = sur.RoleID
    WHERE   ( ( @Role IS NULL
                OR sr.[Name] = @Role
              )
              AND ( @Name IS NULL
                    OR su.[FullName] LIKE '%' + @Name + '%'
                  )
              AND ( @Roles IS NULL
                    OR sr.[Name] IN (
                    SELECT  Value
                    FROM    udf_inline_split_list_characters(@Roles, '|') )
                  )
              AND ( @ShowInactiveUsers = 1
                    OR su.Active = 1
                  )
            )
			-- This disregards whether the user is active or not
            OR ( su.UserID IN ( SELECT  assigneeID
                                FROM    tblMilestone
                                WHERE   BBOID = @AdditionalBBOID
                                        AND ObjectID = @AdditionalObjectID ) )
    ORDER BY FullName;
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetUsersByFilter] TO [mp_db_execute]
GO
