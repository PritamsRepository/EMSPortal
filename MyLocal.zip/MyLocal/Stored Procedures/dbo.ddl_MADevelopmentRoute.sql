SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MADevelopmentRoute]
  @UserID INT = NULL

AS
BEGIN TRY

  SELECT DISTINCT
	VDR.ValidDevelopmentRouteID ID, VDR.Name
  FROM
	dbo.tblValidDevelopmentRoute VDR
	  JOIN dbo.tblMAApplication MA ON VDR.ValidDevelopmentRouteID = MA.ValidDevelopmentRouteID
	  
END TRY
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MADevelopmentRoute] TO [mp_db_execute]
GO
