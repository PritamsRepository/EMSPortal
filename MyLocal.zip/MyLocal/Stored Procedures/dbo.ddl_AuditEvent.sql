SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO





------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_AuditEvent] 

AS 
    BEGIN TRY
		
        SELECT
        ate.Name,
        ate.ATEventID
        FROM dbo.admin_AuditTrailEvent  ate
			
    END TRY

    BEGIN CATCH
        EXECUTE sp_RollAndRaise 
    END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_AuditEvent] TO [mp_db_execute]
GO
