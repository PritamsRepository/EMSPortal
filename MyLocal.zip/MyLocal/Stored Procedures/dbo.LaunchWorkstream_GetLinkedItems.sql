SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[LaunchWorkstream_GetLinkedItems] ( @LaunchID INT )
AS
    BEGIN
        DECLARE @pbboid INT = ( SELECT  BBOID
                                FROM    dbo.tblBusinessBaseObject
                                WHERE   BBOCode = 'PJM'
                              )
        DECLARE @lnchbboid INT = ( SELECT   BBOID
                                   FROM     dbo.tblBusinessBaseObject
                                   WHERE    BBOCode = 'LNCH'
                                 )       
		-- Projects
        SELECT  ( SELECT    BBOCode
                  FROM      dbo.tblBusinessBaseObject
                  WHERE     BBOID = @pbboid
                ) AS [Type] ,
                p.ProjectID AS [ID] ,
                NULL AS [MAApplicationID] ,
                p.ReferenceLabel AS [Identifier] ,
                STUFF(( SELECT  ', ' + s.Name
                        FROM    dbo.tblStrength s
                                JOIN pm.ProjectStrength ps ON s.StrengthID = ps.StrengthID
                        WHERE   ps.ProjectID = p.ProjectID
                                AND s.IsUndefined = 0
                        ORDER BY s.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Strengths] ,
                COALESCE(asu.FullName, asu.ADUserName) AS [Lead] ,
                bbs.StateName AS [Status] ,
                cg.Name AS [Regions] ,
                STUFF(( SELECT  ', ' + vbbot.Tag
                        FROM    dbo.tblValidBBOTag vbbot
                                JOIN pm.ProjectTag pt ON pt.ValidBBOTagID = vbbot.ValidBBOTagID
                        WHERE   pt.ProjectID = p.ProjectID
                        ORDER BY vbbot.Tag
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Tags]
        FROM    pm.Project p
                JOIN pm.LaunchWorkstream l ON l.ProjectID = p.ProjectID
                JOIN dbo.admin_SecUser asu ON asu.UserID = p.ProjectLeadID
                JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = p.ProjectStatusID
                JOIN dbo.tblCountryGroup cg ON cg.CountryGroupID = p.CountryGroupID
        WHERE   l.LaunchWorkstreamID = @LaunchID
        UNION
		-- Launches
        SELECT  ( SELECT    BBOCode
                  FROM      dbo.tblBusinessBaseObject
                  WHERE     BBOID = @lnchbboid
                ) AS [Type] ,
                l.LaunchWorkstreamID AS [ID] ,
                NULL AS [MAApplicationID] ,
                l.ReferenceLabel AS [Identifier] ,
                STUFF(( SELECT  ', ' + s.Name
                        FROM    dbo.tblStrength s
                                JOIN pm.LaunchWorkstreamStrengthInfo ls ON ls.StrengthID = s.StrengthID
                        WHERE   ls.LaunchWorkstreamID = l.LaunchWorkstreamID
                                AND s.IsUndefined = 0
                        ORDER BY s.Name
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Strengths] ,
                COALESCE(asu.FullName, asu.ADUserName) AS [Lead] ,
                bbs.StateName AS [Status] ,
                cg.Name AS [Regions] ,
                STUFF(( SELECT  ', ' + vbbot.Tag
                        FROM    dbo.tblValidBBOTag vbbot
                                JOIN pm.LaunchWorkstreamTag pt ON pt.ValidBBOTagID = vbbot.ValidBBOTagID
                        WHERE   pt.LaunchWorkstreamID = l.LaunchWorkstreamID
                        ORDER BY vbbot.Tag
                      FOR
                        XML PATH('')
                      ), 1, 2, '') AS [Tags]
        FROM    pm.LaunchWorkstream l
                JOIN pm.LaunchWorkstream l2 ON l2.ProjectID = l.ProjectID
                JOIN dbo.admin_SecUser asu ON asu.UserID = l.LeadID
                JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = l.LaunchStatusID
                JOIN dbo.tblCountryLinkCountryGroup clcg ON clcg.CountryID = l.CountryID
                JOIN dbo.tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
                                               AND cg.CountryGroupType = 'KeyMkt'
        WHERE   l2.LaunchWorkstreamID = @LaunchID
                AND l.LaunchWorkstreamID != @LaunchID    
    END
GO
