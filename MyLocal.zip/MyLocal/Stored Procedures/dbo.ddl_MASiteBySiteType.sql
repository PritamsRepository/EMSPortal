SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MASiteBySiteType]  
    @SiteTypeName NVARCHAR(256) = NULL,    
    @UserID INT = NULL
    
AS 
    BEGIN TRY
        DECLARE @CompanyName NVARCHAR(128)
        DECLARE @Spc NCHAR(3) = ' : '
        DECLARE @PreFix NCHAR(5) = 'Mylan'
        DECLARE @NA NCHAR(3) = ''

        IF ( @SiteTypeName = ''
             OR @SiteTypeName = '0' ) 
            SET @SiteTypeName = NULL;

        SELECT  Sorter ,
                ID ,
                Name
        FROM    ( SELECT    0 AS Sorter ,
                            0 AS ID ,
                            'All' AS Name
                  UNION
                  SELECT    1 AS Sorter ,
                            vs.MASiteID AS ID ,
                            ( SELECT    CASE WHEN c.IsThirdParty = 0 THEN @PreFix + @Spc
                                             ELSE ''
                                        END + C.name /*+ @Spc*/ + CASE WHEN co.Code IS NULL THEN @NA
                                                                       ELSE @Spc + co.Code
                                                                  END AS Company
                              FROM      dbo.tblCompany C
                                        LEFT JOIN dbo.tblCountry Co ON C.CountryID = Co.CountryID
                              WHERE     C.CompanyID = vs.CompanyID ) AS Name
                  FROM      dbo.tblCompany c
                            INNER JOIN (
										--Only select the first MASiteID with duplicate CompanyIDs.
                                         SELECT DISTINCT
                                                MIN(s.MASiteID) AS MASiteID ,
                                                s.CompanyID
                                         FROM   dbo.tblMALicense l
												JOIN dbo.tblMAApplication maa ON l.MAApplicationID = maa.MAApplicationID
                                                JOIN dbo.tblMALicenseScope ls ON l.MALicenseID = ls.MALicenseID
                                                JOIN dbo.tblMARegisteredSite lss ON ls.MALicenseScopeID = lss.MALicenseScopeID
                                                JOIN dbo.tblMASite s ON lss.MASiteID = s.MASiteID
                                                JOIN dbo.tblValidSiteType vst ON s.ValidSiteTypeID = vst.ValidSiteTypeID
                                         WHERE  ( @SiteTypeName IS NULL
                                                  OR ( vst.Name = @SiteTypeName
                                                       OR vst.Category = @SiteTypeName ) )
                                         GROUP BY s.CompanyID ) AS vs ON c.CompanyID = vs.CompanyID ) T2
        ORDER BY Sorter ,
                CASE WHEN Name = 'All' THEN 1
                     WHEN NAME LIKE 'Mylan%' THEN 2
                     ELSE 3
                END ,
                Name

    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MASiteBySiteType] TO [mp_db_execute]
GO
