SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetProjectFormsByName]
	@Name nvarchar(256) = NULL
AS
	SELECT DISTINCT
		f.FormID AS ID,
		f.Name
	FROM 
		dbo.tblForm f
			JOIN PM.Project pr ON f.FormID = pr.FormID
	WHERE 
		(@Name IS NULL OR f.Name LIKE @Name + '%')
		AND f.IsPublic = 1
	ORDER BY
		f.Name;
GO
