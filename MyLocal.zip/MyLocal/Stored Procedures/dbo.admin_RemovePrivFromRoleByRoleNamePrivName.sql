SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




CREATE PROCEDURE [dbo].[admin_RemovePrivFromRoleByRoleNamePrivName] 
 @RoleName NVARCHAR(100) ,
        @PrivCode NVARCHAR(20)
AS 
/* 
remove priv to role by Role name
2011-03-31

*/

BEGIN TRY


/* local variables */
    DECLARE @RoleID INT ,
        @RolesFound TINYINT ,
        @PrivID INT

SET NOCOUNT ON

    SET @RolesFound = ( SELECT  COUNT(*)
                        FROM    dbo.admin_SecRole
                        WHERE   Name = @RoleName )

    IF ( @RolesFound > 1 ) 
        BEGIN
            SELECT  RoleID ,
                    Name
            FROM    dbo.admin_SecRole
            WHERE   Name = @RoleName

            RAISERROR('More then one role matches criteria', 16, 2 )
        END

    ELSE 
        BEGIN
            SET @RoleID = ( SELECT  RoleID
                            FROM    dbo.admin_SecRole
                            WHERE   Name = @RoleName )

        END

    SET @PrivID = ( SELECT  PrivID
                    FROM    admin_secpriv
                    WHERE   PrivCode = @PrivCode )
    IF ( @PrivID IS NULL ) 
        BEGIN
            RAISERROR('No Priv code matches %s in table admin_SecPriv',  16, 2 ,@PrivCode)
        END

    ELSE 
        BEGIN

            IF EXISTS ( SELECT  RoleID ,
                                    PrivID
                            FROM    dbo.admin_SecRolePriv
                            WHERE   RoleID = @RoleID
                                    AND PrivID = @PrivID ) 
                BEGIN
					DELETE FROM dbo.admin_SecRolePriv
					WHERE PrivID=@PrivID
					AND RoleID=@RoleID

                    PRINT 'Removed PrivID ' + CAST(@PrivID AS NVARCHAR(20)) + ' to RoleID '
                        + CAST(@RoleID AS NVARCHAR(100))
                    IF ( @@ERROR = 0
                         AND @@TRANCOUNT > 0 ) 
                        BEGIN
                            COMMIT
                        END
                END

            ELSE 
                BEGIN
                    RAISERROR(' RoleID and PrivID Coould not be removed ',  10, 2 ,@PrivCode)
                END
        END
    SELECT  sr.RoleID ,
            sr.Name AS N'Rolename' ,
            sp.PrivID ,
            sp.Name AS N'PrivName'
    FROM    dbo.admin_SecRolePriv srp
            JOIN dbo.admin_SecPriv sp ON srp.PrivID = sp.PrivID
            JOIN dbo.admin_SecRole sr ON srp.RoleID = sr.RoleID
    WHERE   srp.PrivID = @PrivID
            AND srp.RoleID = @RoleID

END TRY

BEGIN CATCH
    EXEC dbo.sp_RollAndRaise
END CATCH

GO
GRANT EXECUTE ON  [dbo].[admin_RemovePrivFromRoleByRoleNamePrivName] TO [mp_db_execute]
GO
