SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[Comment_GetByFilter] 
	@BBOID INT, 
	@ObjectID INT, 
	@UserID INT, 
	@ID INT = NULL,
	@PrivCode VARCHAR(64) = ''
AS
BEGIN
    SELECT  c.CommentID,
			c.CommentDate, 
			COALESCE(su.FullName, su.ADUserName) AS UserName,
			c.Comment,
			c.UserID
    FROM   dbo.tblComment c
    LEFT JOIN dbo.admin_SecUser su on c.UserID = su.UserID
    WHERE  (@BBOID Is Null OR c.BBOID = @BBOID)
			AND (@ObjectID Is Null OR c.ObjectID = @OBJECTID)
			AND (@ID Is Null OR c.CommentID = @ID)
END
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Comment_GetByFilter] TO [mp_db_execute]
GO
