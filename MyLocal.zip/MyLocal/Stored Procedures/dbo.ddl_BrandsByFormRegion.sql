SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE PROCEDURE [dbo].[ddl_BrandsByFormRegion]
    (
      @FormID INT = NULL,
      @CountryGroupID INT = NULL,
      @BrandID INT = NULL
    )
AS /**********************************************************************************
Created By:		Robin Abramson
Create Date:	8/7/2010

Purpose:  DDL Procedure 
Sprint Item: 513
Parameters:
@FormID
@CountryGroupID
 
Return 
BrandID, and BrandName, CountryName
 
Where tblBrand.FormID = @FormID and tblBrand.CountryID in (Countries for @CountryGroupID)

**********************************************************************************/

    BEGIN TRY 

		SELECT * FROM (
        SELECT DISTINCT
                b.BrandID,
                b.[Name] AS BrandName,
                c.[Name] AS CountryName
        FROM    dbo.tblBrand AS b
                JOIN dbo.tblCountry AS c ON b.CountryID = c.CountryID
                JOIN dbo.[tblCountryLinkCountryGroup] AS clcg ON [c].[CountryID] = [clcg].[CountryID]
                JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = clcg.[CountryGroupID]

        WHERE   ( b.FormID = @FormID
                  OR @FormID IS NULL
                )
                AND ( cg.CountryGroupID = @CountryGroupID
                      OR @CountryGroupID IS NULL
                    )
        UNION
        SELECT b.BrandID,
                b.[Name] AS BrandName,
                c.[Name] AS CountryName
        FROM    dbo.tblBrand AS b
                JOIN dbo.tblCountry AS c ON b.CountryID = c.CountryID
        WHERE   b.BrandID = @BrandID
        ) a 
        ORDER BY a.[BrandID], a.CountryName
                
        RETURN 0 ;

    END TRY

    BEGIN CATCH
        EXECUTE dbo.sp_RollAndRaise
    END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_BrandsByFormRegion] TO [mp_db_execute]
GO
