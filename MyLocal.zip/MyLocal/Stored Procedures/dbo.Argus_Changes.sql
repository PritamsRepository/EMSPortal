SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[Argus_Changes]
AS
BEGIN
    DECLARE @start DATETIME;
    DECLARE @end DATETIME;

    SELECT @start = DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, -7);
    SELECT @end = DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, 0);

    -- Sheet 4 - Changes
    SELECT mals.MALicenseScopeID AS [MALicenseScopeID],
           mal.LicenseNumber AS MANumber,
           s.StrengthID AS [StrengthID],
           p.ProductID AS [ProductID],
           p.Name AS [Product],
           s.Name AS [Strength],
           cty.Name AS [Country],
           CONVERT(NVARCHAR(11), aud.EntryDate, 106) AS [Change Date],
           '"' + CONVERT(NVARCHAR(MAX), ObjectChanges.query('/AuditTrail/Changes/Property')) + '"' AS [Changes]
    FROM dbo.admin_ChangeTracking_Audit aud
        JOIN dbo.tblMALicenseScope mals
            ON (
                   aud.BusinessBasedObjectID = 60
                   AND aud.ObjectID = mals.MALicenseID
               )
               OR
               (
                   aud.BusinessBasedObjectID = 61
                   AND aud.ObjectID = mals.MALicenseScopeID
               )
        JOIN dbo.tblMALicense mal
            ON mal.MALicenseID = mals.MALicenseID
        JOIN dbo.tblMAStrength ms
            ON ms.MAStrengthID = mals.MAStrengthID
        JOIN dbo.tblStrength s
            ON s.StrengthID = ms.StrengthID
               AND s.IsUndefined = 0
        JOIN dbo.tblForm f
            ON f.FormID = s.FormID
        JOIN dbo.tblProduct p
            ON p.ProductID = f.ProductID
        JOIN dbo.tblCountry cty
            ON mals.CountryID = cty.CountryID
    WHERE (
              aud.BusinessBasedObjectID = 60
              AND aud.EntryDate > @start
              AND aud.EntryDate < @end
              AND
              (
                  ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Status"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Application Number"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Holder"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Created"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Marketing Status"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Approval Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Withdrawal Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Marketing Cessation Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Product Launch Date"]') = 1
              )
          )
          OR
          (
              aud.BusinessBasedObjectID = 61
              AND aud.EntryDate > @start
              AND aud.EntryDate < @end
              AND
              (
                  ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Status"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Application Number"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Holder"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Created"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Marketing Status"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Approval Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="MA Withdrawal Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Marketing Cessation Date"]') = 1
                  OR ObjectChanges.exist('/AuditTrail/Changes/Property[./@name="Product Launch Date"]') = 1
              )
          )
    ORDER BY 1;
END;
GO
