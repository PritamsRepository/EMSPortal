SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MA_AddAPInfo]
@MAApplicationID INT
AS
BEGIN TRY
	SELECT K.KPIID,
	VKI.Name + ISNULL(' ' + VS.Name, '') kpiName
	FROM dbo.tblKPI K
	JOIN dbo.tblProductLinkKPI PLK ON K.KPIID = PLK.KPIID
	JOIN dbo.tblProduct P ON PLK.ProductID = P.ProductID
	JOIN dbo.tblMAApplication MA ON P.ProductID = MA.ProductGroupID
	JOIN dbo.tblValidKeyIngredient VKI ON K.ValidKeyIngredientID = VKI.ValidKeyIngredientID
	LEFT JOIN dbo.tblValidSalt VS ON K.ValidSaltID=VS.ValidSaltID
	WHERE MA.MAApplicationID=@MAApplicationID
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MA_AddAPInfo] TO [mp_db_execute]
GO
