SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicenseByApplicationID] @MAApplicationID INT
AS 
    BEGIN TRY
        SELECT DISTINCT
                MAL.MALicenseID ,
                LicenseNumber
        FROM    dbo.tblMALicense MAL
				  JOIN dbo.tblValidMALicenseScopeType v ON mal.ValidMALicenseScopeTypeID = v.ValidMALicenseScopeTypeID
        WHERE   MAL.MAApplicationID = @MAApplicationID
			    AND v.Name NOT LIKE 'Per Packaging Size and Type%'
        ORDER BY LicenseNumber
    END  TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicenseByApplicationID] TO [mp_db_execute]
GO
