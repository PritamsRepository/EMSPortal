SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[admin_SecPriv_Delete] @PrivID INT
AS 
    SET NOCOUNT ON 
    SET XACT_ABORT ON  
	
    BEGIN TRAN

    IF NOT EXISTS ( SELECT  *
                    FROM    dbo.admin_SecPriv SP
                            JOIN dbo.admin_SecRolePriv SRP ON SP.PrivID = SRP.PrivID
                            JOIN dbo.admin_SecRole SR ON SRP.RoleID = SR.RoleID
                    WHERE   SP.PrivID = @PrivID ) 
        BEGIN
            DELETE  FROM [dbo].[admin_SecPriv]
            WHERE   [PrivID] = @PrivID

            COMMIT
        END

    ELSE 
        BEGIN
            RAISERROR('PrivID  %d is linked to a Role', 16, 42, @PrivID) WITH NoWait ;
        END


GO
GRANT EXECUTE ON  [dbo].[admin_SecPriv_Delete] TO [mp_db_execute]
GO
