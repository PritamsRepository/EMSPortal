SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

--EXEC [Core.Reporting].[MAApplication_Report_MALicenseScope]
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_MALicenseScope]
(
    @MAApplicationID INT = NULL,
    @Country NVARCHAR(MAX) = NULL,
    @Region NVARCHAR(MAX) = NULL
)
AS
BEGIN
    DECLARE @CountryID INT =
            (
                SELECT CountryID FROM dbo.tblCountry WHERE Code = @Country
            );

    DECLARE @CountryGroupID INT =
            (
                SELECT CountryGroupID
                FROM dbo.tblCountryGroup
                WHERE CountryGroupType = 'MAMkt'
                      AND Name = @Region
            );
    DECLARE @swbboid INT =
            (
                SELECT BBOID FROM dbo.tblBusinessBaseObject WHERE BBOCode = 'SW'
            );

    SELECT DISTINCT
           mals.MALicenseScopeID,
           mal.MALicenseID,
           c.Code AS [Country],
           mals.MarketingName AS [Marketing Name],
           com.Name AS [Marketing Company],
           bbs.StateName AS [Market Status],
           REPLACE(CONVERT(VARCHAR(15), mals.MarketingCessationDate, 106), ' ', '-') AS [Marketing Cessation Date],
           REPLACE(CONVERT(VARCHAR(15), mals.ProductLaunchDate, 106), ' ', '-') AS [Product Launch Date],
           trs.Name AS [Transfer Receiving Site],
           (CASE
                WHEN vss.Name = 'Active' THEN
                    'Yes'
                ELSE
                    'No'
            END
           ) AS [IsActive],
           s.Name AS [Strengths],
           s.StrengthID AS [StrengthID],
           mals.NDCCode AS [NDC Code],
           vpt.Name AS [Packaging Type],
           masp.PackageSize AS [Packaging Size],
           masp.ShelfLife AS [Shelf Life],
           masp.StorageCondition AS [Storage Condition],
           masp.PackageComment AS [Package Comment],
           (
               SELECT TOP (1)
                      EntryDate
               FROM dbo.admin_ChangeTracking_Audit
               WHERE ObjectID = mals.MALicenseScopeID
                     AND BusinessBasedObjectID = 61
               ORDER BY EntryDate DESC
           ) AS UpdateDate
    FROM dbo.tblMALicenseScope mals
        JOIN dbo.tblMALicense mal
            ON mal.MALicenseID = mals.MALicenseID
        JOIN dbo.tblCountry c
            ON c.CountryID = mals.CountryID
        JOIN dbo.tblBusinessBaseStates bbs
            ON bbs.StateID = mals.MarketStatusID
        JOIN dbo.tblValidScopeStatus vss
            ON vss.ValidScopeStatusID = mals.ValidScopeStatusID
        LEFT JOIN dbo.tblCompany com
            ON com.CompanyID = mals.MarketingCompanyID
        LEFT JOIN dbo.tblMAStrength mas
            ON mas.MAStrengthID = mals.MAStrengthID
        LEFT JOIN tblStrength s
            ON s.StrengthID = mas.StrengthID
        LEFT JOIN dbo.tblMaStrengthPackage masp
            ON masp.MAStrengthPackageID = mals.MaStrengthPackageID
        LEFT JOIN dbo.tblValidMAPackType vpt
            ON vpt.ValidMAPackTypeID = masp.ValidPackagingTypeID
        LEFT JOIN dbo.tblCompany trs
            ON trs.CompanyID = mals.TransferReceivingSiteID
    WHERE (
              @MAApplicationID IS NULL
              OR mal.MAApplicationID = @MAApplicationID
          )
          AND
          (
              @CountryID IS NULL
              OR @CountryID = mals.CountryID
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID IN
                 (
                     SELECT cg.CountryGroupID
                     FROM dbo.tblCountryLinkCountryGroup clcg
                         JOIN tblCountryGroup cg
                             ON cg.CountryGroupID = clcg.CountryGroupID
                     WHERE CountryID = mals.CountryID
                           AND cg.CountryGroupType = 'MAMkt'
                 )
          );
END;
GO
