SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_ThirdPartyQuality_Countries] AS
BEGIN TRY

	DECLARE @US int, @Canada int
	
	SET @US = (SELECT c.CountryID FROM tblCountry c WHERE c.Name = 'United States')
	SET @Canada = (SELECT c.CountryID FROM tblCountry c WHERE c.Name = 'Canada')
	
	SELECT co.CountryID AS ID, co.Name, 1 AS UberOrder FROM tblCountry co WHERE co.CountryID = @US
	UNION
	SELECT co.CountryID AS ID, co.Name, 2 AS UberOrder FROM tblCountry co WHERE co.CountryID = @Canada
	UNION
  SELECT DISTINCT
	co.CountryID AS ID,
	co.Name,
	3 AS UberOrder
  FROM
	dbo.tblCompany C
	  JOIN dbo.tblCompanyLinkCompanyGroup CLCG ON C.CompanyID = CLCG.CompanyID
	  JOIN dbo.tblCompanyGroup CG ON CLCG.CompanyGroupID = CG.CompanyGroupID
	  JOIN dbo.tblValidSiteType vst ON cg.[Text] = vst.Name
	  JOIN dbo.tblCountry co ON c.CountryID = co.CountryID
	WHERE co.CountryID NOT IN(@US, @Canada)
	ORDER BY UberOrder, co.Name
	
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_ThirdPartyQuality_Countries] TO [mp_db_execute]
GO
