SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_SubmissionRouteConfig_MACountries]
    @SubmissionRouteID INT,
    @HealthAuthorityID INT,
    @UserID INT
AS
BEGIN
    BEGIN TRY

        DECLARE @Country TABLE
        (
            CountryID INT NOT NULL,
            Name NVARCHAR(256) NOT NULL,
            HasPriv BIT NOT NULL
        );

        INSERT INTO @Country
        (
            CountryID,
            Name,
            HasPriv
        )
        SELECT DISTINCT
               c.CountryID,
               c.Name,
               (CASE
                    WHEN dbo.udf_UserHasPrivForCountry(@UserID, 'MA04', c.CountryID) = 1 THEN
                        1
                    ELSE
                        0
                END
               )
        FROM dbo.tblSubmissionRouteConfig src
            JOIN dbo.tblSubmissionRoute sr
                ON sr.SubmissionRouteID = src.SubmissionRouteID
            JOIN dbo.tblCountry c
                ON c.CountryID = src.CountryID
        WHERE sr.SubmissionRouteID = @SubmissionRouteID
              AND
              (
                  sr.IsHADependent = 0
                  OR (src.HealthAuthorityID = @HealthAuthorityID)
              ) --<- sr.IsHADependent seems to make it not work??
        --AND ( src.HealthAuthorityID = @HealthAuthorityID )
        ORDER BY c.Name;

        DECLARE @IsMultiCountry BIT =
                (
                    SELECT sr.IsMultiCountry
                    FROM dbo.tblSubmissionRoute sr
                    WHERE sr.SubmissionRouteID = @SubmissionRouteID
                );

        --User must have at least 1 country priv to return all countries.
        SELECT c.CountryID,
               c.Name
        FROM @Country c
        WHERE (
                  (
                      @IsMultiCountry = 1
                      AND (
                          (
                              SELECT COUNT(c2.HasPriv) FROM @Country c2 WHERE c2.HasPriv = 1
                          ) > 0
                          )
                  )
                  OR c.HasPriv = 1
              );

    END TRY
    BEGIN CATCH

        EXEC dbo.sp_RollAndRaise;

    END CATCH;
END;
GO
