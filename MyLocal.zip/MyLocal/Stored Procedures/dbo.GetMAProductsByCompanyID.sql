SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[GetMAProductsByCompanyID] @CompanyID INT
AS
SELECT STUFF(
                (
                    SELECT DISTINCT
                           ', ' + f.Name
                    FROM rim.RimApplication app
                        JOIN rim.RimRegisteredSite site
                            ON site.ApplicationID = app.MAApplicationID
                        JOIN rim.ApplicationLinkStrength link
                            ON link.MAApplicationID = app.MAApplicationID
                        JOIN dbo.tblForm f
                            ON f.FormID = link.FormID
                    WHERE site.SiteID = @CompanyID
                    ORDER BY ', ' + f.Name
                    FOR XML PATH(''), ROOT('mystring'), TYPE
                ).value('/mystring[1]', 'varchar(max)'),
                1,
                2,
                ''
            ) AS MAProducts;
GO
