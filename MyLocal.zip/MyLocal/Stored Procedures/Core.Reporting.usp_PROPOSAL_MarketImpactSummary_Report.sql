SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_PROPOSAL_MarketImpactSummary_Report]
    @UserID INT = NULL,
    @PrivCode NVARCHAR(10) = NULL,
    @ProposalID INT
AS
SET NOCOUNT ON;
BEGIN TRY

    DECLARE @FormID INT =
            (
                SELECT FormID
                FROM pm.ProductProposal
                WHERE ProductProposalID = @ProposalID
            );

    SELECT cg.Name Market,
           dbo.udf_FormatDate(MIN(e.ImpactOnFilingDate)) ImpactOnFilingDate,
           dbo.udf_FormatDate(MIN(li.MktFormationDate)) GxMktApprovalDate,
           dbo.udf_FormatDate(MIN(li.MylanApprovalDate)) MylanApprovalDate
    FROM pm.LegalInfo li
        LEFT JOIN pm.Exclusivity AS e
            ON li.CountryID = e.CountryID
               AND li.FormID = e.FormID
        LEFT JOIN dbo.tblValidExclusivityType AS vet
            ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
        JOIN dbo.tblCountryLinkCountryGroup AS clcg
            ON clcg.CountryID = li.CountryID
        JOIN dbo.tblCountryGroup AS cg
            ON cg.CountryGroupID = clcg.CountryGroupID
    WHERE li.FormID = @FormID
          AND cg.CountryGroupType = 'SumMkt'
          AND ISNULL(vet.Category, '') <> 'MISEXCLUDE'
          AND dbo.udf_UserHasPrivForCountryGroup(@UserID, @PrivCode, cg.CountryGroupID) = 'true'
    GROUP BY cg.Name
    ORDER BY cg.Name;

END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
