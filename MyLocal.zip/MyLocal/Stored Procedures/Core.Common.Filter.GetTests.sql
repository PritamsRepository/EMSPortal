SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetTests]
	@Name nvarchar(256)
	
AS
	SELECT
		prb.PRBSessionID AS ID,
		prb.Name
	FROM
		pm.PRBSession prb;
GO
