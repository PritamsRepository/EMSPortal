SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MARegisteredSite_MarketingCompany] @CompanyID INT
AS 
    BEGIN TRY

        SELECT DISTINCT
                mc.CompanyID AS ID ,
                ( mc.Name + ' : ' + ISNULL(CTY.Code, '') ) AS NAME /* replace the UDF udf_FormatCompanyName */
  
        FROM    dbo.tblMARegisteredSite mars /* Site JOINs */
                JOIN dbo.tblMASite mas ON mars.MASiteID = mas.MASiteID
                JOIN dbo.tblValidQualityStatus vqs ON mars.ValidQualityStatusID = vqs.ValidQualityStatusID
	
	/* Scope JOINs */
                JOIN dbo.tblMALicenseScope mals
                JOIN dbo.tblCompany mc
                LEFT JOIN dbo.tblCountry CTY ON mc.CountryID = CTY.CountryID ON mals.MarketingCompanyID = mc.CompanyID ON mars.MALicenseScopeID = mals.MALicenseScopeID
        WHERE   mas.CompanyID = @CompanyID
	
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MARegisteredSite_MarketingCompany] TO [mp_db_execute]
GO
