SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ddl_GetFXDatesByCurrencyID]
@ValidCurrencyID INT = NULL
AS
/* Return the ID, date, and currency ID that corresponds */

BEGIN TRY
	
SELECT 
		exrl.EXRateLoadID, 
		exrl.EffectiveDate,
		ex.ValidCurrencyID
	FROM 
		tblExchangeRateLoad exrl
		JOIN dbo.tblExchangeRate ex ON exrl.ExRateLoadID = ex.ExRateLoadID
		WHERE (@ValidCurrencyID IS NULL OR ex.ValidCurrencyID=@ValidCurrencyID)
	ORDER BY 
		EffectiveDate DESC, exrl.ExRateLoadID, ex.ValidCurrencyID

END TRY
BEGIN CATCH
	EXEC sp_RollAndRaise
END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_GetFXDatesByCurrencyID] TO [mp_db_execute]
GO
