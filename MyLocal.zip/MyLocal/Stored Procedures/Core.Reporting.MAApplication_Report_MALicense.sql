SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_MALicense]
(
    @MAApplicationID INT = NULL,
    @Country NVARCHAR(MAX) = NULL,
    @Region NVARCHAR(MAX) = NULL
)
AS
BEGIN
    DECLARE @CountryID INT =
            (
                SELECT CountryID FROM dbo.tblCountry WHERE Code = @Country
            );

    DECLARE @CountryGroupID INT =
            (
                SELECT CountryGroupID
                FROM dbo.tblCountryGroup
                WHERE CountryGroupType = 'MAMkt'
                      AND Name = @Region
            );
    DECLARE @swbboid INT =
            (
                SELECT BBOID FROM dbo.tblBusinessBaseObject WHERE BBOCode = 'SW'
            );

    SELECT DISTINCT
           ma.MAApplicationID,
           mal.MASubmissionWorkstreamID,
           mal.MALicenseID,
           mal.LicenseNumber AS [MA Number],
           vls.Name AS [MA Status],
           REPLACE(CONVERT(VARCHAR(15), mal.LicenseApprovalDate, 106), ' ', '-') AS [MA Approval Date],
           REPLACE(CONVERT(VARCHAR(15), mal.LicenseExpiryDate, 106), ' ', '-') AS [MA Expiry Date],
           mal.RegisteredProductName AS [Registered Name],
           holder.Name AS [MA Holder],
           REPLACE(CONVERT(VARCHAR(15), mal.SunsetClause, 106), ' ', '-') AS [Sunset Clause Date],
           ha.ShortName + ' [' + cou.Code + ']' AS [Assessing HA / Country],
           REPLACE(CONVERT(VARCHAR(15), mal.MylOwnershipDate, 106), ' ', '-') AS [Mylan Ownership Date],
           REPLACE(CONVERT(VARCHAR(15), mal.LicenseWithdrawalDate, 106), ' ', '-') AS [Withdrawal Date],
           REPLACE(CONVERT(VARCHAR(15), ma.EstimatedRenewalSubmissionDate, 106), ' ', '-') AS [Est. Renewal Submission Date],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + cg.Name
               FROM dbo.tblCountryGroup cg
                   JOIN dbo.tblCountryLinkCountryGroup clcg
                       ON clcg.CountryGroupID = cg.CountryGroupID
                   JOIN dbo.tblMALicenseScope mals
                       ON mals.CountryID = clcg.CountryID
               WHERE mals.MALicenseID = mal.MALicenseID
                     AND cg.CountryGroupType = 'KeyMkt'
               ORDER BY ', ' + cg.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Region,
           CASE
               WHEN holder.IsThirdParty = 0 THEN
                   'Yes'
               ELSE
                   'No'
           END AS MylanOwned,
           maas.Name AS AdminStatus,
           (
               SELECT TOP (1)
                      EntryDate
               FROM dbo.admin_ChangeTracking_Audit
               WHERE ObjectID = mal.MALicenseID
                     AND BusinessBasedObjectID = 60
               ORDER BY EntryDate DESC
           ) AS UpdateDate
    FROM dbo.tblMALicense mal
        JOIN dbo.tblMAApplication ma
            ON ma.MAApplicationID = mal.MAApplicationID
        LEFT JOIN dbo.tblCompany holder
            ON holder.CompanyID = mal.LicenseHolderID
        LEFT JOIN dbo.tblValidLicenseStatus vls
            ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
        LEFT JOIN dbo.MASubmissionWorkstream masw
            ON masw.MASubmissionWorkstreamID = mal.MASubmissionWorkstreamID
        LEFT JOIN dbo.tblCompany ha
            ON ha.CompanyID = masw.HealthAuthorityID
        LEFT JOIN dbo.tblCountry cou
            ON cou.CountryID = ha.CountryID
        LEFT JOIN dbo.tblMALicenseScope mals
            ON mals.MALicenseID = mal.MALicenseID
        LEFT JOIN dbo.tblCountry c
            ON c.CountryID = mals.CountryID
        LEFT JOIN dbo.tblValidMAAdminStatus maas
            ON maas.ValidMAAdminStatusID = mal.ValidMAAdminStatusID
    WHERE (
              @MAApplicationID IS NULL
              OR masw.MAApplicationID = @MAApplicationID
          )
          AND
          (
              @CountryID IS NULL
              OR @CountryID = mals.CountryID
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID IN
                 (
                     SELECT cg.CountryGroupID
                     FROM dbo.tblCountryLinkCountryGroup clcg
                         JOIN dbo.tblCountryGroup cg
                             ON cg.CountryGroupID = clcg.CountryGroupID
                     WHERE clcg.CountryID = mals.CountryID
                           AND cg.CountryGroupType = 'MAMkt'
                 )
          )
    --      AND NOT EXISTS
    --(
    --    SELECT 1
    --    FROM dbo.MAApplicationTag t
    --        JOIN dbo.tblValidBBOTag b
    --            ON b.ValidBBOTagID = t.ValidBBOTagID
    --    WHERE b.Tag = 'Migrated to Veeva'
    --          AND t.MAApplicationID = mal.MAApplicationID
    --);
END;
GO
