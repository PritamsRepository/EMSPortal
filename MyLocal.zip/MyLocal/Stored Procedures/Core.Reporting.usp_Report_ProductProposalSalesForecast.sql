SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_Report_ProductProposalSalesForecast]
    @FormIDs NVARCHAR(MAX) = NULL,
    @StatusID INT = NULL,
    @ValidPRBDecisionID INT = NULL,
    @CountryGroupID INT = NULL,
    @PRBSessionID INT = NULL,
    @DevelopmentRouteID INT = NULL,
    @UserID INT,
    @Privcode NVARCHAR(20),
    @MarketResponseIDs NVARCHAR(100) = NULL
AS
BEGIN TRY

    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @StatusID = 0
        SET @StatusID = NULL;
    IF @ValidPRBDecisionID = 0
        SET @ValidPRBDecisionID = NULL;
    IF @CountryGroupID = 0
        SET @CountryGroupID = NULL;
    IF @PRBSessionID = 0
        SET @PRBSessionID = NULL;
    IF @DevelopmentRouteID = 0
        SET @DevelopmentRouteID = NULL;

    DECLARE @MarketResponseIDsTbl AS ValidResponseType;
    INSERT INTO @MarketResponseIDsTbl
    SELECT id
    FROM dbo.udf_GetValuesFromCSV(@MarketResponseIDs);

    DECLARE @Forms TABLE
    (
        FormID INT
    );

    IF (@FormIDs IS NOT NULL)
    BEGIN
        INSERT INTO @Forms
        (
            FormID
        )
        SELECT CONVERT(INT, ISNULL(Value, '-1'))
        FROM dbo.udf_inline_split_list_numeric(@FormIDs);
    END;

    DECLARE @USD INT;
    DECLARE @CountryGroupType NVARCHAR(100);
    SELECT @USD = vc.ValidCurrencyID
    FROM dbo.tblValidCurrency vc
    WHERE vc.Name = 'USD';

    SET @CountryGroupType = N'KeyMkt';

    CREATE TABLE #PSF
    (
        ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED,
        ProposalID INT NULL,
        FormName NVARCHAR(256) NULL,
        ShortName NVARCHAR(50) NULL,
        FormID INT NULL,
        Product NVARCHAR(256) NULL,
        Form NVARCHAR(256) NULL,
        Identifier NVARCHAR(MAX) NULL,
        Strength NVARCHAR(256) NULL,
		Status NVARCHAR(256) NULL,
        EHSAlert NVARCHAR(MAX) NULL,
        OEBClassifications NVARCHAR(MAX) NULL,
        DrugClassifications NVARCHAR(MAX) NULL,
        ProposalClass NVARCHAR(MAX) NULL,
        ScopeChange NVARCHAR(MAX) NULL,
        MakeBuy NVARCHAR(MAX) NULL,
        CountryGroup NVARCHAR(MAX) NULL,
        MarketSubType NVARCHAR(MAX) NULL,
        Response NVARCHAR(MAX) NULL,
        PRBSession NVARCHAR(MAX) NULL,
        PRBDecision NVARCHAR(MAX) NULL,
        Country NVARCHAR(MAX) NULL,
        VCD NVARCHAR(MAX) NULL,
        StrategicRationale NVARCHAR(MAX) NULL,
        MarketSegment NVARCHAR(MAX) NULL,
        TradeDress NVARCHAR(MAX) NULL,
        PackSize NVARCHAR(MAX) NULL,
        MylanLatestFileDate DATETIME NULL,
        MylanLatestFileDateComments NVARCHAR(MAX) NULL,
        MylanRequestedLaunchDate DATETIME NULL,
        MylanRequestedLaunchDateComments NVARCHAR(MAX) NULL,
        GxMarketFormDate DATETIME NULL,
        GxMarketFormDateComments NVARCHAR(MAX) NULL,
        MylanApprovalDate DATETIME NULL,
        ForecastYear INT NULL,
        turnover DECIMAL(20, 5) NULL,
        ForecastVolume DECIMAL(20, 5) NULL,
        volumeUnits DECIMAL(20, 5) NULL,
        pricePer DECIMAL(20, 5) NULL
    );

    CREATE INDEX tmpIDX_PSF01 ON #PSF (FormID);

    INSERT INTO #PSF
    (
        ProposalID,
        FormName,
        ShortName,
        FormID,
        Product,
        Form,
        Identifier,
        Strength,
		Status,
        ProposalClass,
        EHSAlert,
        OEBClassifications,
        DrugClassifications,
        ScopeChange,
        MakeBuy,
        CountryGroup,
        MarketSubType,
        Response,
        PRBSession,
        PRBDecision,
        Country,
        VCD,
        StrategicRationale,
        MarketSegment,
        TradeDress,
        PackSize,
        MylanLatestFileDate,
        MylanLatestFileDateComments,
        MylanRequestedLaunchDate,
        MylanRequestedLaunchDateComments,
        GxMarketFormDate,
        GxMarketFormDateComments,
        MylanApprovalDate,
        ForecastYear,
        turnover,
        ForecastVolume,
        volumeUnits,
        pricePer
    )
    SELECT DISTINCT
           p.ProductProposalID,
           f.Name,
           p.ShortName,
           p.FormID,
           pr.Name,
           vf.Name,
           f.Identifier,
           s.Name,
		   bbs.StateName,
           vpc.Name,
           dbo.udf_EHSAlert(f.ProductID, NULL),
           dbo.udf_GetMPBClassifications(f.ProductID),
           dbo.udf_GetDrugClassifications(f.ProductID),
           (
               SELECT STUFF(
                      (
                          SELECT DISTINCT
                                 ', ' + vsc.[Name]
                          FROM pm.ProductProposalLinkProjectScopeChange lsc
                              JOIN dbo.tblValidProjectScopeChange vsc
                                  ON vsc.ValidProjectScopeChangeID = lsc.ValidProjectScopeChangeID
                          WHERE lsc.ProductProposalID = p.ProductProposalID
                          FOR XML PATH('')
                      ),
                      1,
                      2,
                      ''
                           )
           ),
           vmb.Name,
           cg.Name,
           (
               SELECT STUFF(
                      (
                          SELECT DISTINCT
                                 ', ' + vmst.[Name]
                          FROM pm.ProductProposalLinkMarketSubtype lmst
                              JOIN dbo.tblValidMarketSubtype vmst
                                  ON vmst.ValidMarketSubtypeID = lmst.ValidMarketSubtypeID
                          WHERE lmst.ProductProposalID = p.ProductProposalID
                          FOR XML PATH('')
                      ),
                      1,
                      2,
                      ''
                           )
           ),
           vr.Name,
           prb.Name,
           prd.Name,
           cty.Code,
           vcd.Name,
           vsr.Name,
           ms.Name,
           ptd.TradeDressName,
           ptd.PackSize,
           p.MylanLatestFileDate,
           p.MylanLatestFileDateComment,
           p.MylanRequestedLaunchDate,
           p.MylanRequestedLaunchDateComment,
           p.GxMarketFormDate,
           p.GxMarketFormDateComment,
           li.MylanApprovalDate,
           psf.ForecastYear,
           [dbo].[udf_ConvertCurrencyByExRateLoad](prb.ExRateLoadID, psf.ForecastTurnover, psf.ValidCurrencyID, @USD),
           psf.ForecastVolume,
           psf.ForecastVolume * ptd.PackSize,
           [dbo].[udf_ConvertCurrencyByExRateLoad](prb.ExRateLoadID, psf.ForecastPricePerUnit, psf.ValidCurrencyID, @USD)
    FROM pm.ProductProposal p
        JOIN dbo.tblForm f
            ON f.FormID = p.FormID
        JOIN dbo.tblProduct pr
            ON pr.ProductID = f.ProductID
			JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = p.StatusID
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = f.ValidFormID
        JOIN dbo.tblStrength s
            ON s.FormID = f.FormID
        JOIN dbo.tblCountryGroup cg
            ON cg.CountryGroupID = p.CountryGroupID
               AND cg.CountryGroupType = @CountryGroupType
        JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @Privcode) AS a
            ON a.CountryGroupID = cg.[CountryGroupID]
               AND a.Privs = 1
        JOIN pm.ProductProposalCountryInterest pci
            ON pci.ProductProposalID = p.ProductProposalID
        JOIN dbo.tblCountry cty
            ON cty.CountryID = pci.CountryID
        JOIN pm.ProductProposalTradeDress ptd
            ON ptd.ProductProposalID = p.ProductProposalID
               AND ptd.StrengthID = s.StrengthID
        JOIN pm.ProductProposalSalesForecast psf
            ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
               AND psf.ProductProposalCountryInterestID = pci.ProductProposalCountryInterestID
        LEFT JOIN pm.LegalInfo li
            ON f.FormID = li.FormID
               AND cty.CountryID = li.CountryID
        LEFT JOIN dbo.tblValidProposalClass vpc
            ON vpc.ValidProposalClassID = p.ValidProposalClassID
        LEFT JOIN dbo.tblValidMakeBuy vmb
            ON vmb.ValidMakeBuyID = p.ValidMakeBuyID
        LEFT JOIN dbo.tblValidResponse vr
            ON vr.ValidResponseID = p.ValidResponseID
        LEFT JOIN dbo.udf_GetValuesFromCSV(@FormIDs) v
            ON p.FormID = v.id
        LEFT JOIN(pm.Candidate c
        JOIN pm.PRBSession prb
            ON prb.PRBSessionID = c.TargetPRBSessionID
        JOIN dbo.tblValidMarketSegment ms
            ON ms.ValidMarketSegmentID = c.ValidMarketSegmentID)
            ON c.CandidateID = p.CandidateID
        LEFT JOIN dbo.tblValidPRBDecision prd
            ON prd.ValidPRBDecisionID = p.ValidPRBDecisionID
        LEFT JOIN dbo.tblValidPRBDecision vcd
            ON vcd.ValidPRBDecisionID = pci.ValidPRBDecisionID
        LEFT JOIN dbo.tblValidStrategicRationale vsr
            ON vsr.ValidStrategicRationaleID = c.ValidStrategicRationaleID
    WHERE s.IsUndefined = 0
          AND
          (
              @MarketResponseIDs IS NULL
              OR p.ValidResponseID IN
                 (
                     SELECT ValidResponseID FROM @MarketResponseIDsTbl
                 )
          )
          AND
          (
              @FormIDs IS NULL
              OR [p].[FormID] IN
                 (
                     SELECT FormID FROM @Forms
                 )
          )
          AND
          (
              @StatusID IS NULL
              OR [p].StatusID = @StatusID
          )
          AND
          (
              @ValidPRBDecisionID IS NULL
              OR p.ValidPRBDecisionID = @ValidPRBDecisionID
          )
          AND
          (
              @CountryGroupID IS NULL
              OR [cg].[CountryGroupID] = @CountryGroupID
          )
          AND
          (
              @PRBSessionID IS NULL
              OR prb.PRBSessionID = @PRBSessionID
          )
          AND
          (
              @DevelopmentRouteID IS NULL
              OR vmb.ValidMakeBuyID = @DevelopmentRouteID
          )
    ORDER BY p.ProductProposalID;

    SELECT DISTINCT
           ProposalID,
           FormName,
           ShortName,
           Product,
           Form,
           Identifier,
           Strength,
		   Status,
           EHSAlert,
           OEBClassifications,
           DrugClassifications,
           ProposalClass AS [Proposal Class],
           ScopeChange AS [Scope Change],
           MakeBuy AS [Make/Buy],
           CountryGroup AS [Country Group],
           MarketSubType,
           Response,
           PRBSession AS [PRB Session],
           PRBDecision AS [PRB Decision],
           Country,
           VCD,
           StrategicRationale AS [Strategic Rationale],
           MarketSegment AS [Market Segment],
           TradeDress AS [Trade Dress],
           PackSize,
           MylanLatestFileDate AS [Mylan Latest File Date],
           MylanLatestFileDateComments AS [Mylan Latest File Date Comments],
           MylanRequestedLaunchDate,
           MylanRequestedLaunchDateComments AS [Mylan Requested Launch Date Comments],
           GxMarketFormDate AS [Gx Market Formation Date],
           GxMarketFormDateComments AS [Gx Market Formation Date Comments],
           MylanApprovalDate,
           ForecastYear,
           turnover,
           ForecastVolume,
           volumeUnits,
           pricePer
    FROM #PSF;

    IF EXISTS
    (
        SELECT *
        FROM tempdb..sysobjects
        WHERE id = OBJECT_ID('tempdb..#PSF')
    )
        DROP TABLE #PSF;

END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
