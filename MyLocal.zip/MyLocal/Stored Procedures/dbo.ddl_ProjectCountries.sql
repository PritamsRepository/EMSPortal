SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_ProjectCountries]
		
AS

BEGIN TRY

    SELECT DISTINCT 
		c.CountryID AS ID, 
		c.Name
	FROM
		pm.ProjectLinkCountry pc 
		JOIN dbo.tblCountry c ON c.CountryID = pc.CountryID	
	ORDER BY
		c.Name;

END TRY
BEGIN CATCH

	EXEC sp_RollAndRaise;

END CATCH
GO
