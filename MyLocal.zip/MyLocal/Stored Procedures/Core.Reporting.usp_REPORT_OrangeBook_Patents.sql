SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_OrangeBook_Patents]
    @FormID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN TRY
    SELECT DISTINCT
           p.[PatentID],
           c.[Code] AS Country,
           p.[PatentNum],
           p.[Description],
           --p.PatentStrategyComments,
           --p.CertStrategyComments,
           STUFF(
           (
               SELECT ', ' + vos.Name
               FROM dbo.tblValidStudyStatus vos
                   JOIN pm.LegalInfoLinkPatent lilp
                       ON lilp.ValidOpinionStatusID = vos.ValidStudyStatusID
					   WHERE lilp.PatentID = p.PatentID
               ORDER BY ', ' + vos.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS OpinionStatus,
		   STUFF(
           (
               SELECT ', ' + lilp.OpinionComments
               FROM pm.LegalInfoLinkPatent lilp
               WHERE lilp.PatentID = p.PatentID
               ORDER BY ', ' + lilp.OpinionComments
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS OpinionComments,
		   STUFF(
           (
               SELECT ', ' + lilp.PatentComments
               FROM pm.LegalInfoLinkPatent lilp
               WHERE lilp.PatentID = p.PatentID
               ORDER BY ', ' + lilp.PatentComments
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentComments,
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + vpt.Name
                        FROM pm.PatentLinkValidPatentType plvpt
                            JOIN dbo.tblValidPatentType vpt
                                ON vpt.ValidPatentTypeID = plvpt.ValidPatentTypeID
                        WHERE plvpt.PatentID = p.PatentID
                        ORDER BY ', ' + vpt.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    2,
                    ''
                ) AS PatentType,
           STUFF(
           (
               SELECT ', ' + vcs.Name
               FROM dbo.tblValidCertStrategy vcs
                   JOIN pm.LegalInfoLinkPatentLinkValidCertStrategy link
                       ON link.ValidCertStrategyID = vcs.ValidCertStrategyID
                   JOIN pm.LegalInfoLinkPatent lilp
                       ON lilp.LegalInfoLinkPatentID = link.LegalInfoLinkPatentID
               WHERE lilp.PatentID = p.PatentID
               ORDER BY vcs.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentStrategy,
           STUFF(
                    (
                        SELECT DISTINCT
                               '<br/>' + vc.Name
                        FROM dbo.tblValidCert vc
                            JOIN pm.LegalInfoLinkPatentLinkValidCert plvc
                                ON plvc.ValidCertID = vc.ValidCertID
                            JOIN pm.LegalInfoLinkPatent lp
                                ON lp.LegalInfoLinkPatentID = plvc.LegalInfoLinkPatentID
                        WHERE lp.PatentID = p.PatentID
                        ORDER BY '<br/>' + vc.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    5,
                    ''
                ) AS PatentCert,
           (
               SELECT STUFF(
                      (
                          SELECT COALESCE(', ' + s.[Name], '')
                          FROM
                          (
                              SELECT DISTINCT
                                     sx.Name
                              FROM dbo.tblStrength sx
                                  JOIN pm.PatentLinkStrength AS link
                                      ON sx.[StrengthID] = link.[StrengthID]
                              WHERE link.PatentID = p.PatentID
                                    AND sx.[IsUndefined] = 'false'
                                    AND sx.FormID = @FormID
                                    AND sx.Name IS NOT NULL
                          ) s
                          FOR XML PATH('')
                      ),
                      1,
                      1,
                      ' '
                           )
           ) AS Strengths,
           --p.CertStrategyComments,
           --dbo.udf_PatentCertStrategyListByPatentID(p.PatentID) AS PatentStrategy,
           p.ExpiryDate AS ExpiryWithRationale,
		   		   STUFF(
           (
               SELECT ', ' + vpt.Name
               FROM pm.PatentLinkValidExpiryRationale lvpt
                   JOIN dbo.tblValidExpiryRationale vpt ON vpt.ValidExpiryRationaleID = lvpt.ValidExpiryRationaleID
               WHERE lvpt.PatentID = p.PatentID
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Rationales
    FROM pm.PatentFamilyLinkForm pflf
        JOIN pm.Patent p
            ON pflf.PatentFamilyID = p.PatentFamilyID
        JOIN dbo.tblStrength s
            ON pflf.FormID = s.FormID
               AND dbo.udf_PatentIsListedForForm(@FormID, p.PatentID) = 'true'
        JOIN dbo.tblCountry c
            ON p.CountryID = c.CountryID
        JOIN pm.PatentLinkStrength AS link
            ON s.[StrengthID] = link.[StrengthID]
               AND p.PatentID = link.PatentID
    WHERE s.[FormID] = @FormID
          AND c.[Code] = 'US'
          AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
    ORDER BY p.[PatentNum];

END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_OrangeBook_Patents] TO [mp_db_execute]
GO
