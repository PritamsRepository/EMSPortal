SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_MAApplication_Leads]
AS
BEGIN
    SELECT ma.MAApplicationID,
           asu.FullName AS GCCRALead,
           asu2.FullName AS RegulatoryLead,
           asu3.FullName AS LabelingLead
    FROM dbo.tblMAApplication ma
        LEFT JOIN dbo.admin_SecUser asu2
            ON asu2.UserID = ma.RegulatoryLeadID
        LEFT JOIN dbo.admin_SecUser asu
            ON asu.UserID = ma.GlobalCCRALeadID
        LEFT JOIN dbo.admin_SecUser asu3
            ON asu3.UserID = ma.LabelingLeadID
	ORDER BY ma.MAApplicationID;
END;
GO
