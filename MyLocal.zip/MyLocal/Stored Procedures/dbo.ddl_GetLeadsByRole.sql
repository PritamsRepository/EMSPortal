SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
CREATE PROCEDURE [dbo].[ddl_GetLeadsByRole]
    @RoleName NVARCHAR(50) = NULL,
    @UserID INT = NULL,
    @ActiveOnly BIT = 0
AS 
    BEGIN TRY

        SELECT DISTINCT
                su.UserID ,
                su.ADUserName ,
                CASE WHEN su.FullName IS NULL
                          OR su.FullName = '' OR LEN(su.fullname) <2 THEN su.ADUserName
                     ELSE su.FullName
                END AS FullName,
                su.FullName --DO NOT USE THIS FIELD (it's just for ORDER BY)
        FROM    dbo.admin_SecUser su
                JOIN dbo.admin_SecUserRole sur ON sur.UserID = su.UserID
                JOIN dbo.admin_SecRole sr ON sr.RoleID = sur.RoleID
        WHERE   
				(sr.Name = @RoleName 
					AND (@ActiveOnly = 0 
						OR (@ActiveOnly = 1 AND su.Active = 1)
						)
				)
				OR su.UserID = @UserID
        GROUP BY  su.UserID ,
                su.ADUserName ,su.FullName
        ORDER BY su.FullName
 
    END TRY
 
 
    BEGIN CATCH
        EXEC SP_ROLLANDRAISE
    END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_GetLeadsByRole] TO [mp_db_execute]
GO
