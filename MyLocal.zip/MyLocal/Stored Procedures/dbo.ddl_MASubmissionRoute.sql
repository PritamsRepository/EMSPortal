SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MASubmissionRoute]
  @UserID INT = NULL

AS
BEGIN TRY

	SELECT
		sr.SubmissionRouteID AS ID,
		sr.Name,
		sr.Category AS Code
	FROM
		dbo.tblSubmissionRoute sr
	WHERE
		IsActive = 1
	ORDER BY
		DisplayOrder;
		
END  TRY
BEGIN CATCH

	EXEC dbo.sp_RollAndRaise;
	
END CATCH
GO
