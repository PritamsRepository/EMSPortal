SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [config].[GetDepartmentsAndAssigneesBySNCWorkstreamID]
(@SNCWorkstreamID INT)
AS
BEGIN
    IF EXISTS
    (
        SELECT *
        FROM tempdb..sysobjects
        WHERE id = OBJECT_ID('tempdb..#Tmp_assignees')
    )
    BEGIN
        DROP TABLE #Tmp_assignees;
    END;

    CREATE TABLE #Tmp_assignees
    (
        ValidDepartmentID INT NULL,
        UserID INT NULL,
        ValidSCSiteTypeID INT NULL,
        CompanyID INT NULL
    );

    --DECLARE @Quality INT =
    --        (
    --            SELECT ValidDepartmentID
    --            FROM dbo.tblValidDepartment
    --            WHERE Name = 'Quality'
    --        );
    DECLARE @Legal INT =
            (
                SELECT ValidDepartmentID
                FROM dbo.tblValidDepartment
                WHERE Name = 'IP/Legal'
            );
    --DECLARE @Europe INT =
    --        (
    --            SELECT CountryGroupID
    --            FROM dbo.tblCountryGroup
    --            WHERE Name = 'Europe'
    --                  AND CountryGroupType = 'KeyMkt'
    --        );

    DECLARE @GuidanceAssigneeRole INT =
            (
                SELECT RoleID FROM dbo.admin_SecRole WHERE Name = 'SNC Decision Assignee'
            );
    DECLARE @ValidSNCRequestID INT;
    DECLARE @CountryGroupID INT;
    DECLARE @ProductID INT =
            (
                SELECT f.ProductID
                FROM dbo.tblForm f
                    JOIN pm.SNCWorkstream snc
                        ON snc.FormID = f.FormID
                WHERE snc.SNCWorkstreamID = @SNCWorkstreamID
            );
    DECLARE @Alert BIT = 0;
    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblProduct p
            JOIN dbo.tblProductLinkKPI plk1
                ON plk1.ProductID = p.ProductID
            JOIN dbo.tblKPI kpi
                ON kpi.KPIID = plk1.KPIID
            JOIN dbo.tblValidKeyIngredient AS vki
                ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            JOIN dbo.tblValidPECCategory AS pec
                ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
        WHERE (
                  pec.Category = 'EHS Alert'
                  OR pec.Name = 'OEB 3'
              )
              AND p.ProductID = @ProductID
    )
        SET @Alert = 1;

    DECLARE @ValidOperationsVerticalID INT;
    --DECLARE @Vertical NVARCHAR(MAX);

    SELECT
        @CountryGroupID = snc.CountryGroupID,
        @ValidOperationsVerticalID = snc.ValidOperationsVerticalID, --vv.ValidVerticalID,
        --@Vertical = vv.Name,
        @ValidSNCRequestID = snc.ValidSNCRequestID
    FROM pm.SNCWorkstream snc
        --JOIN dbo.tblForm f
        --    ON f.FormID = snc.FormID
        --JOIN dbo.tblValidVertical vv
        --    ON vv.ValidVerticalID = f.ValidVerticalID
    WHERE snc.SNCWorkstreamID = @SNCWorkstreamID;

    DECLARE @ValidSNCProcessID INT =
            (
                SELECT ValidSNCProcessID
                FROM pm.SNCWorkstream snc
                WHERE snc.SNCWorkstreamID = @SNCWorkstreamID
            );

    INSERT INTO #Tmp_assignees
    (
        ValidDepartmentID,
        UserID,
        ValidSCSiteTypeID,
        CompanyID
    )
    SELECT DISTINCT
           ValidDepartmentID,
           CASE
               WHEN ValidDepartmentID = @Legal
                    AND @SNCWorkstreamID IN
                        (
                            SELECT lp.SNCWorkstreamID
                            FROM pm.SNCWorkstreamLinkProject lp
                                JOIN pm.Project p
                                    ON p.ProjectID = lp.ProjectID
                                JOIN dbo.admin_SecUserRole sur
                                    ON sur.UserID = p.LegalLeadID
                                       AND sur.RoleID = @GuidanceAssigneeRole
                        ) THEN
               (
                   SELECT TOP (1)
                          COALESCE(p.LegalLeadID, gra.UserID)
                   FROM pm.SNCWorkstreamLinkProject lp
                       JOIN pm.Project p
                           ON p.ProjectID = lp.ProjectID
                       JOIN dbo.admin_SecUserRole sur
                           ON sur.UserID = p.LegalLeadID
                              AND sur.RoleID = @GuidanceAssigneeRole
                   WHERE lp.SNCWorkstreamID = @SNCWorkstreamID
                   ORDER BY lp.ProjectID DESC
               )
               ELSE
                   gra.UserID
           END AS UserID,
           gra.ValidSNCSiteTypeID,
           gra.CompanyID
    FROM [config].SNCGuidanceRequestAssignee gra
    WHERE (
            ValidOperationsVerticalID IS NULL
            OR ValidOperationsVerticalID = @ValidOperationsVerticalID
        )
        AND
        (
            CountryGroupID IS NULL
            OR CountryGroupID = @CountryGroupID
        )
        AND
        (
            ValidSNCRequestID IS NULL
            OR ValidSNCRequestID = @ValidSNCRequestID
        )
        AND
        (
            HasSNCAlert IS NULL
            OR gra.HasSNCAlert = 0
            OR HasSNCAlert = @Alert
        )
        -- special case for quality in Europe
        --AND
        --(
        --    ValidDepartmentID <> @Quality
        --    OR @CountryGroupID <> @Europe
        --)
        AND CASE
                WHEN ValidDepartmentID = @Legal
                     AND @SNCWorkstreamID IN
                         (
                             SELECT lp.SNCWorkstreamID
                             FROM pm.SNCWorkstreamLinkProject lp
                                 JOIN pm.Project p
                                     ON p.ProjectID = lp.ProjectID
                                 JOIN dbo.admin_SecUserRole sur
                                     ON sur.UserID = p.LegalLeadID
                                        AND sur.RoleID = @GuidanceAssigneeRole
                         ) THEN
                (
                    SELECT TOP (1)
                           COALESCE(p.LegalLeadID, gra.UserID)
                    FROM pm.SNCWorkstreamLinkProject lp
                        JOIN pm.Project p
                            ON p.ProjectID = lp.ProjectID
                        JOIN dbo.admin_SecUserRole sur
                            ON sur.UserID = p.LegalLeadID
                               AND sur.RoleID = @GuidanceAssigneeRole
                    WHERE lp.SNCWorkstreamID = @SNCWorkstreamID
                    ORDER BY lp.ProjectID DESC
                )
                ELSE
                    gra.UserID
            END IS NOT NULL
        AND
        (
            (
                gra.ValidSNCSiteTypeID IS NULL
                AND gra.CompanyID IS NULL
            )
            OR
            (
                gra.ValidSNCSiteTypeID IS NOT NULL
                AND gra.CompanyID IS NULL
                AND gra.ValidSNCSiteTypeID IN
                    (
                        SELECT cat.ValidSNCSiteTypeID
                        FROM pm.SNCWorkstreamCatalog cat
                            JOIN dbo.tblValidSNCModType mt
                                ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                        WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
                              AND mt.Name <> 'No Change'
                    )
            )
            OR
            (
                gra.ValidSNCSiteTypeID IS NULL
                AND gra.CompanyID IS NOT NULL
                AND gra.CompanyID IN
                    (
                        SELECT cat.SiteID
                        FROM pm.SNCWorkstreamCatalog cat
                            JOIN dbo.tblValidSNCModType mt
                                ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                        WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
                              AND mt.Name <> 'No Change'
                    )
            )
            OR
            (
                gra.ValidSNCSiteTypeID IS NOT NULL
                AND gra.CompanyID IS NOT NULL
                AND gra.ValidSNCSiteTypeID IN
                    (
                        SELECT cat.ValidSNCSiteTypeID
                        FROM pm.SNCWorkstreamCatalog cat
                            JOIN dbo.tblValidSNCModType mt
                                ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                        WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
                              AND mt.Name <> 'No Change'
                    )
                AND gra.CompanyID IN
                    (
                        SELECT cat.SiteID
                        FROM pm.SNCWorkstreamCatalog cat
                            JOIN dbo.tblValidSNCModType mt
                                ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                        WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
                              AND mt.Name <> 'No Change'
                    )
            )
        )
    --UNION
    --SELECT DISTINCT
    --       gra.ValidDepartmentID,
    --       gra.UserID,
    --       gra.ValidSNCSiteTypeID,
    --       gra.CompanyID
    --FROM [config].SNCGuidanceRequestAssignee gra
    --    JOIN dbo.tblForm f
    --        ON f.ProductID = @ProductID
    --    JOIN dbo.tblValidVertical vv
    --        ON vv.ValidVerticalID = f.ValidVerticalID
    --WHERE
    --    @CountryGroupID = @Europe
    --    AND
    --    (
    --        gra.ValidVerticalID IS NULL
    --        OR gra.ValidVerticalID = @ValidVerticalID
    --    )
    --    AND gra.CountryGroupID = @Europe
    --    AND gra.ValidDepartmentID = @Quality
    --    AND
    --    (
    --        gra.ValidSNCRequestID IS NULL
    --        OR gra.ValidSNCRequestID = @ValidSNCRequestID
    --    )
    --    AND
    --    (
    --        (
    --            gra.ValidSNCSiteTypeID IS NULL
    --            AND gra.CompanyID IS NULL
    --        )
    --        OR
    --        (
    --            gra.ValidSNCSiteTypeID IS NOT NULL
    --            AND gra.CompanyID IS NULL
    --            AND gra.ValidSNCSiteTypeID IN
    --                (
    --                    SELECT cat.ValidSNCSiteTypeID
    --                    FROM pm.SNCWorkstreamCatalog cat
    --                        JOIN dbo.tblValidSNCModType mt
    --                            ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
    --                    WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
    --                          AND mt.Name <> 'No Change'
    --                )
    --        )
    --        OR
    --        (
    --            gra.ValidSNCSiteTypeID IS NULL
    --            AND gra.CompanyID IS NOT NULL
    --            AND gra.CompanyID IN
    --                (
    --                    SELECT cat.SiteID
    --                    FROM pm.SNCWorkstreamCatalog cat
    --                        JOIN dbo.tblValidSNCModType mt
    --                            ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
    --                    WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
    --                          AND mt.Name <> 'No Change'
    --                )
    --        )
    --        OR
    --        (
    --            gra.ValidSNCSiteTypeID IS NOT NULL
    --            AND gra.CompanyID IS NOT NULL
    --            AND gra.ValidSNCSiteTypeID IN
    --                (
    --                    SELECT cat.ValidSNCSiteTypeID
    --                    FROM pm.SNCWorkstreamCatalog cat
    --                        JOIN dbo.tblValidSNCModType mt
    --                            ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
    --                    WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
    --                          AND mt.Name <> 'No Change'
    --                )
    --            AND gra.CompanyID IN
    --                (
    --                    SELECT cat.SiteID
    --                    FROM pm.SNCWorkstreamCatalog cat
    --                        JOIN dbo.tblValidSNCModType mt
    --                            ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
    --                    WHERE cat.SNCWorkstreamID = @SNCWorkstreamID
    --                          AND mt.Name <> 'No Change'
    --                )
    --        )
    --    )
    --    AND
    --    (
    --        gra.HasSNCAlert IS NULL
    --        OR gra.HasSNCAlert = 0
    --        OR gra.HasSNCAlert = @Alert
    --    );

    SELECT DISTINCT ValidDepartmentID,
           (
               SELECT TOP (1)
                      UserID
               FROM #Tmp_assignees
               WHERE ValidDepartmentID = t.ValidDepartmentID
               ORDER BY ValidSCSiteTypeID DESC,
                        CompanyID DESC
           ) AS UserID
    FROM #Tmp_assignees t
    ORDER BY t.ValidDepartmentID;
END;
GO
