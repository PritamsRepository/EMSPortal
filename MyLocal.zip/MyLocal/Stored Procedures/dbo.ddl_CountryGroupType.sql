SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------


Create Procedure [dbo].[ddl_CountryGroupType]

AS

/**********************************************************************************
CREATED BY:			Scott M. Dexter:	Software Specialists Consultant
CREATED DATE:		OCT 30, 2009
MODIFIED BY:
MODIFIED DATE:
PURPOSE:			The purpose of this script is to retrieve a list of 
					Country Group Types for passage back to a drop down list. 
					Hense the prefix ddl_.

SAMPLE USAGE:		EXEC [dbo].[ddl_CountryGroupType]

**********************************************************************************/

BEGIN TRY

	SELECT DISTINCT CountryGroupType, 
		CountryGroupTypeDescription 
	FROM 
		tblCountryGroup 
	WHERE 
		CountryGroupType IS NOT NULL

END TRY

BEGIN CATCH
	EXEC [dbo].[sp_RollAndRaise]
END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_CountryGroupType] TO [mp_db_execute]
GO
