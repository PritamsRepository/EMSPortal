SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_AddMAStrengthToMAApplication] @MAApplicationID INT
AS
BEGIN TRY
    SELECT DISTINCT
           s.StrengthID AS ID,
           f.Name + ' ' + s.Name AS Name
    FROM dbo.tblStrength s
        JOIN dbo.tblForm f
            ON s.FormID = f.FormID
        JOIN dbo.tblProduct p
            ON f.ProductID = p.ProductID
        JOIN dbo.tblMAApplication ma
            ON p.ProductID = ma.ProductGroupID
               AND ma.MAApplicationID = @MAApplicationID
    WHERE s.IsUndefined = 0
          AND f.IsPublic = 1
    EXCEPT
    SELECT DISTINCT
           xs.StrengthID AS ID,
           xf.Name + ' ' + xs.Name AS Name
    FROM dbo.tblMAStrength ms
        JOIN dbo.tblMAApplication xma
            ON ms.MAApplicationID = xma.MAApplicationID
               AND xma.MAApplicationID = @MAApplicationID
        JOIN dbo.tblStrength xs
            ON ms.StrengthID = xs.StrengthID
        JOIN dbo.tblForm xf
            ON xs.FormID = xf.FormID;
END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
GRANT EXECUTE ON  [dbo].[ddl_AddMAStrengthToMAApplication] TO [mp_db_execute]
GO
