SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE procedure [common].[GetProductsByName] @name nvarchar(100) = NULL
as
select FormID, Name as ProductName from tblForm where Name like '%' + @name + '%'	
GO
GRANT EXECUTE ON  [common].[GetProductsByName] TO [mp_db_execute]
GO
