SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC [Core.Reporting].[MAApplication_Report_Strength]
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Strength]
(@MAApplicationID INT = NULL)
AS
BEGIN
    SELECT DISTINCT
           p.[ProductID],
           p.Name AS [Product Group],
           f.[FormID],
           f.Name AS [Product],
           s.[StrengthID],
           s.Name AS [Strength]
    FROM dbo.tblStrength s
        JOIN dbo.tblForm f
            ON f.FormID = s.FormID
        JOIN dbo.tblProduct p
            ON p.ProductID = f.ProductID
        JOIN dbo.tblMAApplication ma
            ON ma.ProductGroupID = p.ProductID
    WHERE s.IsUndefined = 0
          AND
          (
              @MAApplicationID IS NULL
              OR ma.MAApplicationID = @MAApplicationID
          );
END;
GO
