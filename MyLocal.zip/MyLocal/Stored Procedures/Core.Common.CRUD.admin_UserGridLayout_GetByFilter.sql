SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[admin_UserGridLayout_GetByFilter]
    @UserID INT = NULL ,
    @GridName NVARCHAR(100) = NULL ,
    @ControllerName NVARCHAR(100) = NULL ,
    @isDefault BIT = NULL ,
    @Label NVARCHAR(100) = NULL
AS
    BEGIN
        SELECT  ugl.UserGridLayoutID ,
                ugl.UserID ,
                COALESCE(su.FullName, su.ADUserName) AS UserName ,
                ugl.GridName ,
                ugl.ControllerName ,
                ugl.isDefault ,
                ugl.Label ,
                ugl.Settings
        FROM    dbo.admin_UserGridLayout ugl
                JOIN dbo.admin_SecUser su ON ugl.UserID = su.UserID
        WHERE   ( @UserID IS NULL
                  OR ugl.UserID = @UserID
				  OR ugl.UserID = 2480
                )
                AND ( @GridName IS NULL
                      OR ugl.GridName = @GridName
                    )
                AND ( @ControllerName IS NULL
                      OR ugl.ControllerName = @ControllerName
                    )
                AND ( @isDefault IS NULL
                      OR ugl.isDefault = @isDefault
                    )
                AND ( @Label IS NULL
                      OR ugl.Label = @Label
                    )
    END
GO
