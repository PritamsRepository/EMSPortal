SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_ManagersByTeam](@TeamID int, @DefaultProcLeadID int = NULL)
as
/**********************************************************************************
Christian Duvall; Team Maintenance - get all of the managers on a given team.
**********************************************************************************/

BEGIN TRY 

	select 
		su.UserID as ID,
		su.FullName as [Name]
	from 
		admin_SecUserLinkTeam sult join admin_SecUser su on su.UserID = sult.UserID
	where 
		TeamID = @TeamID and IsManager = 1
	union
	select 
		su.UserID as ID,
		su.FullName as [Name]
	from 
		admin_SecUser su
	where 
		su.UserID = @DefaultProcLeadID
	
END TRY


BEGIN CATCH
	EXECUTE [dbo].[sp_RollAndRaise]
END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_ManagersByTeam] TO [mp_db_execute]
GO
