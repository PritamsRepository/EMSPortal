SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetSitesByFilter]
    @Name NVARCHAR(256) = NULL,
    @CompanyGroup NVARCHAR(256) = NULL,
    @CompanyType NVARCHAR(256) = 'Site'
AS
SELECT c.CompanyID,
       CASE
           WHEN c.IsThirdParty = 0 THEN
               'Mylan : '
           ELSE
               ''
       END + c.Name AS Name,
       c.Code
FROM dbo.tblCompany c
WHERE (
          @CompanyGroup IS NULL
          OR c.CompanyID IN
             (
                 SELECT CompanyID
                 FROM dbo.tblCompanyLinkCompanyGroup lnk
                     LEFT JOIN dbo.tblCompanyGroup cg
                         ON cg.CompanyGroupID = lnk.CompanyGroupID
                 WHERE cg.[Text] = @CompanyGroup
             )
      )
      AND
      (
          @Name IS NULL
          OR c.Name LIKE '%' + @Name + '%'
      )
      AND
      (
          @CompanyType IS NULL
          OR (c.ValidCompanyTypeID =
             (
                 SELECT ValidCompanyTypeID
                 FROM dbo.tblValidCompanyType
                 WHERE Name = @CompanyType
             )
             )
      )
ORDER BY c.IsThirdParty,
         c.Name;
GO
