SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [common].[Form_GetByID] @ID int
AS
		SELECT
			f.ProductID,
			f.FormID,
			f.ValidFormID,
			f.[Name],
			f.ATCID,
			f.ATC AS FullATCCode,
			f.ValidReleaseCategoryID,
			f.ValidGMDFormID,
			f.ValidReleaseMechanismID,
			f.Identifier,
			f.GeneralRemarks,
			f.Issues,
			f.MedicalLandscape,
			f.IsPublic,
			f.ConcurrencyID,
		-- Details
			p.[Name] as APIGroup,
			vf.[Name] as ValidForm,
			vrm.[Name] as ValidReleaseMechanism,
			vgf.[Name] as ValidGMDForm,
			vrc.[Name] as ValidReleaseCategory,
			i.[Name] as Innovator
		FROM
			dbo.tblForm AS f
			join dbo.tblProduct p ON p.ProductID = f.ProductID
			join dbo.tblValidForm vf ON vf.ValidFormID = f.ValidFormID
			left join dbo.tblValidReleaseMechanism vrm ON vrm.ValidReleaseMechanismID = f.ValidReleaseMechanismID
			left join dbo.tblValidGMDForm vgf ON vgf.ValidGMDFormID = f.ValidGMDFormID
			left join dbo.tblValidReleaseCategory vrc ON vrc.ValidReleaseCategoryID = f.ValidReleaseCategoryID
			left join dbo.tblCompany i ON i.CompanyID = p.InnovatorID
		WHERE
			f.FormID = @ID
		ORDER BY
			f.[Name]
GO
GRANT EXECUTE ON  [common].[Form_GetByID] TO [mp_db_execute]
GO
