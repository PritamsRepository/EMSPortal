SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[admin_UserGridLayout_Insert]
    @UserID INT ,
    @GridName NVARCHAR(100) ,
    @ControllerName NVARCHAR(100) ,
    @isDefault BIT = 0 ,
    @Label NVARCHAR(100) = NULL ,
    @Settings NVARCHAR(MAX)
AS
    BEGIN TRY
        DECLARE @RowsAffected INT
        DECLARE @ReturnValue INT
        BEGIN TRANSACTION
    
		-- There can be only one
        IF ( @isDefault = 1 )
            UPDATE  [dbo].[admin_UserGridLayout]
            SET     isDefault = 0
            WHERE   UserID = @UserID
                    AND GridName = @GridName
                    AND ControllerName = @ControllerName
			
        INSERT  INTO [dbo].[admin_UserGridLayout]
                ( [UserID] ,
                  [GridName] ,
                  [ControllerName] ,
                  [isDefault] ,
                  [Label] ,
                  [Settings]
			    )
        VALUES  ( @UserID ,
                  @GridName ,
                  @ControllerName ,
                  @isDefault ,
                  @Label ,
                  @Settings
			    )
        SET @RowsAffected = @@ROWCOUNT;
        SET @ReturnValue = SCOPE_IDENTITY()
        SELECT  @ReturnValue AS ID ,
                ConcurrencyID
        FROM    [admin_UserGridLayout]
        WHERE   UserGridLayoutID = @ReturnValue
                
        IF ( @RowsAffected = 0 )
            BEGIN
                EXEC sp_RaiseCustomError 3
            END
        COMMIT;
        RETURN @ReturnValue;
    END TRY
 
    BEGIN CATCH
        EXEC SP_ROLLANDRAISE
    END CATCH
GO
