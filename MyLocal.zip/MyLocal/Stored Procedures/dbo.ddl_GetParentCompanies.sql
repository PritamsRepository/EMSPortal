SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_GetParentCompanies]
@CompanyID INT = NULL
AS
BEGIN TRY

/*
Author:			JRG
Date:			2011-06-13
Description:	Provide a list of companies that can become a parent company 
				Cannot be a parent of yourself
				Other restrictions may apply in the future
*/	

	SELECT CompanyID,Name AS Company 
	FROM dbo.tblCompany
	WHERE (@CompanyID IS NULL OR CompanyID != @CompanyID)
	ORDER BY Name
	
END TRY

BEGIN CATCH
	EXEC dbo.sp_RollAndRaise	
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_GetParentCompanies] TO [mp_db_execute]
GO
