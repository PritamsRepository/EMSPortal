SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Alert_GetByFilter]
    @BBOID INT = NULL ,
    @ObjectID INT = NULL ,
    @UserID INT ,
    @PrivCode VARCHAR(64) = ''
AS
    BEGIN

        SELECT  oa.BBOID ,
                oa.ObjectID ,
                oa.ValidAlertTypeID ,
                oa.ValidAlertTypeName ,
                oa.Description
        FROM    dbo.ObjectAlert oa
                JOIN tblValidAlertType v ON v.ValidAlertTypeID = oa.ValidAlertTypeID
        WHERE   oa.BBOID = @BBOID
                AND ( @ObjectID IS NULL
                      OR oa.ObjectID = @ObjectID
                    )
        ORDER BY v.DisplayOrder
		
    END
GO
