SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_RoleSummary]
	@UserID int,
	@PrivCode nvarchar(10)
AS
	SELECT r.RoleID,
		   r.Name as 'RoleName',
		   r.[Description] as 'RoleDescription',
		   p.PrivID,
		   p.PrivCode,
		   p.Name as 'PrivName',
		   p.[LongDescription] as 'PrivDescription' 
	FROM dbo.admin_SecRole r
	LEFT JOIN ( SELECT srp.RoleID, pr.*
				FROM dbo.admin_SecPriv pr
				JOIN dbo.admin_SecRolePriv srp
					on pr.PrivID = srp.PrivID 
			  ) as p
			ON r.RoleID = p.RoleID 
	WHERE dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
	GROUP BY
		r.RoleID,
		   r.Name,
		   r.[Description],
		   p.PrivID,
		   p.PrivCode,
		   p.Name,
		   p.[LongDescription] 
			



GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_RoleSummary] TO [mp_db_execute]
GO
