SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_SecurityUserSummary]
	@SelectedUsers nvarchar(max)= NULL,
	@UserID int,
	@PrivCode nvarchar(10)
AS
	--table for users we want
    DECLARE @Users TABLE
        (
        ID INT IDENTITY(1,1),
        UserID INT
        )
	
	IF @SelectedUsers IS NULL
		BEGIN
		INSERT INTO @Users (UserID)
		SELECT UserID
		FROM dbo.admin_SecUser 
		END
	ELSE
		BEGIN
			INSERT INTO @Users (UserID)
			SELECT CONVERT(INT,ISNULL(Value, '-1'))
			FROM dbo.udf_inline_split_list_numeric(@SelectedUsers)
		END
	
	SELECT 
		su.ADUserName,
		su.FullName,
		su.Department,
		su.JobTitle,
		su.Active,
		res.Unrestricted,
		res.[Role],
		res.RestrictionName,
		res.RestrictionType,
		mgr.[Name] as DirectManager,
		su.Requests
	FROM dbo.admin_SecUser su
	JOIN @Users usr
		on su.UserID = usr.UserID
	LEFT JOIN [dbo].[tblValidManager] AS mgr
		on su.DirectManagerID = mgr.ValidManagerID
	LEFT JOIN ( SELECT	sur.UserID,
					'Unrestricted' = CASE sur.IsUnrestricted 
							WHEN 1 then 'Yes'
							ELSE 'No'
							END,
						r.[Name] as 'Role',
						rlc.Name  as 'RestrictionName',
						'Country Restrictions' as 'RestrictionType'  
				FROM dbo.admin_SecUserRole sur
				JOIN @Users as us
					on sur.UserID = us.UserID
				JOIN dbo.admin_SecRole r
					on sur.RoleID = r.RoleID 
				LEFT JOIN (SELECT lc.UserRoleID, c.Name
							FROM dbo.admin_SecUserRoleLinkCountry lc
							join dbo.tblCountry c
								on lc.CountryID = c.CountryID 
							) as rlc
					on sur.UserRoleID = rlc.UserRoleID 
				GROUP BY sur.UserID,
						CASE sur.IsUnrestricted 
							WHEN 1 then 'Yes'
							ELSE 'No'
							END,
						r.[Name],
						r.[Description] ,
						rlc.Name
						
				UNION
				
				SELECT	sur.UserID,
						'Unrestricted' = CASE sur.IsUnrestricted 
							WHEN 1 then 'Yes'
							ELSE 'No'
							END,
						r.[Name] as 'Role',
						rlcg.Name  as 'RestrictionName',
						'Market Restrictions' as 'RestrictionType'  
				FROM dbo.admin_SecUserRole sur
				JOIN @Users as us
					on sur.UserID = us.UserID
				JOIN dbo.admin_SecRole r
					on sur.RoleID = r.RoleID 
				LEFT JOIN (SELECT lcg.UserRoleID, cg.Name 
							FROM dbo.admin_SecUserRoleLinkCountryGroup lcg
							join dbo.tblCountryGroup cg
								on lcg.CountryGroupID = cg.CountryGroupID 
							) as rlcg
					on sur.UserRoleID = rlcg.UserRoleID 
				GROUP BY sur.UserID,
						CASE sur.IsUnrestricted 
							WHEN 1 then 'Yes'
							ELSE 'No'
							END,
						r.[Name],
						r.[Description] ,
						rlcg.Name
				) AS res 
				ON su.UserID = res.UserID
	WHERE dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_SecurityUserSummary] TO [mp_db_execute]
GO
