SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[Proposal_PRB_Proposals_CountryInterest]
    @UserID INT = NULL,
    @PrivCode NVARCHAR(10) = NULL,
    @TargetPRBSessionID INT = NULL,
    @ProposalID INT = NULL,
    @FormName NVARCHAR(256) = NULL,
    @CountryGroupID INT = NULL,
    @ValidProposalStatusID INT = NULL,
    @ValidPRBDecisionID INT = NULL,
    @ValidMakeBuyID INT = NULL,
    @ShowNonCandidatesOnly BIT = 0,
    @MarketResponseIDs NVARCHAR(100) = NULL
AS
SET NOCOUNT ON;

BEGIN TRY;
    DECLARE @MarketResponseIDsTbl AS ValidResponseType;
    INSERT INTO @MarketResponseIDsTbl
    SELECT id
    FROM dbo.udf_GetValuesFromCSV(@MarketResponseIDs);

    SELECT ci.ProductProposalCountryInterestID,
           p.ProductProposalID,
           prb.Name AS TargetPRBSession,
           f.Name + ' : ' + cg.Name + ' [' + bbs.StateName + ']' AS Proposal,
           c.Name AS Country,
           --ci.[ProductProposalID],
           cir.Name AS ValidResponse,
           opt.Name AS ValidOpportunityType,
           ci.NumberLicensesProposed,
           ci.LicenseComments,
           ci.CurrentCopySPC,
           ci.GenericBrandName,
           ci.GMFDate,
           ci.GMFIsASAP,
           ci.GMFComments,
           ci.LatestFileDate,
           ci.LatestFileIsASAP,
           ci.LatestFileComments,
           ci.ConcurrencyID,
           ci.RegionalComments,
           ci.CountryComments,
           ci.BrandName,
           ci.BrandInnovator,
           prbd2.Name AS PRBDecision,
           ci.MylanMarketShare,
           ci.GxMarketShare,
           ci.UpdateUserID,
           ci.UpdateDate,
           ci.APICost,
           ci.OverheadCost,
           ci.RLDCost,
           ci.BiostudyCost,
           ci.ClinicalCost,
           ci.ZoneIVCost,
           ci.RegulatoryCost,
           ci.OtherCost,
           ci.TotalCost,
           ci.RDComments,
           ci.RegulatoryStrategyComments,
           ci.ProjectPortfolioComments,
           ci.PNS,
           ci.PeakVolume,
           ci.AOI,
           ci.NPV,
           ci.GMPercent,
           ci.GMCost,
           ci.FinanceComments,
           ci.LeadDevelopmentMarket,
           ci.LeadMarketDataExclusivity,
           ci.LeadMarketTargetSub,
           ci.LeadMarketTargetLaunch,
           ci.CountryPatentsEstimatedMarketFormationLOEComment,
           ci.LeadOriginCountrySupportDocumentTypeRequired,
           ci.LeadOriginCountrySupportDocumentAvailabilityDate,
           ci.ExhibitBatchInitiation,
           ci.ProposedWPEntry,
           ci.ProposedPRBReviewComment,
           ci.CountryTargetSubmissionDate,
           ci.CountryTargetRegulatoryApprovalDate,
           ci.CountryTargetMarketLaunchDate,
           ci.PostPRBActions,
           civmb.Name AS DevelopmentRoute,
           STUFF(
           (
               SELECT ', ' + s.Name
               FROM dbo.tblStrength s
                   JOIN pm.ProductProposalCountryInterestApprovedStrength ps
                       ON s.StrengthID = ps.StrengthID
               WHERE ps.ProductProposalCountryInterestID = ci.ProductProposalCountryInterestID
                     AND s.IsUndefined = 0
               ORDER BY s.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [ApprovedStrengths]
    FROM pm.ProductProposal p
        JOIN dbo.tblForm f
            ON p.FormID = f.FormID
        JOIN dbo.tblCountryGroup AS cg
            ON cg.CountryGroupID = p.CountryGroupID
        JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
            ON a.CountryGroupID = cg.[CountryGroupID]
               AND a.Privs = 1
        JOIN dbo.tblBusinessBaseStates AS bbs
            ON p.StatusID = bbs.StateID
        JOIN pm.ProductProposalCountryInterest ci
            ON ci.ProductProposalID = p.ProductProposalID
        JOIN dbo.tblCountry c
            ON ci.CountryID = c.CountryID
        LEFT JOIN dbo.tblValidResponse cir
            ON ci.ValidResponseID = cir.ValidResponseID
        LEFT JOIN dbo.tblValidOpportunityType opt
            ON ci.ValidOpportunityTypeID = opt.ValidOpportunityTypeID
        LEFT JOIN pm.Candidate AS can
            ON p.CandidateID = can.CandidateID
        LEFT JOIN pm.PRBSession AS prb
            ON can.TargetPRBSessionID = prb.PRBSessionID
        LEFT JOIN dbo.tblValidPRBDecision AS prbd
            ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
        LEFT JOIN dbo.tblValidPRBDecision AS prbd2
            ON ci.ValidPRBDecisionID = prbd2.ValidPRBDecisionID
        LEFT JOIN dbo.tblValidMakeBuy civmb
            ON ci.ValidMakeBuyID = civmb.ValidMakeBuyID
    WHERE (
              @FormName IS NULL
              OR f.Name LIKE @FormName
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID = cg.CountryGroupID
          )
          AND
          (
              @MarketResponseIDs IS NULL
              OR ci.ValidResponseID IN
                 (
                     SELECT ValidResponseID FROM @MarketResponseIDsTbl
                 )
          )
          AND
          (
              @TargetPRBSessionID IS NULL
              OR @TargetPRBSessionID = can.TargetPRBSessionID
          )
          AND
          (
              @ValidPRBDecisionID IS NULL
              OR @ValidPRBDecisionID = prbd2.ValidPRBDecisionID
          )
          AND
          (
              @ShowNonCandidatesOnly = 0
              OR p.CandidateID IS NULL
          )
          AND
          (
              @ValidMakeBuyID IS NULL
              OR @ValidMakeBuyID = ci.ValidMakeBuyID
          )
          AND
          (
              @ValidProposalStatusID IS NULL
              OR p.StatusID = @ValidProposalStatusID
          )
    ORDER BY p.ProductProposalID,
             p.Name;

END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
