SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_MASitePrimarySecondary] AS
BEGIN TRY
	/* Predefined company groups will be shown to pick from */
	
	
	SELECT ValidPrimarySecondaryID,name AS ValidPrimarySecondary  
	FROM dbo.tblValidPrimarySecondary
	ORDER BY NAME
	
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MASitePrimarySecondary] TO [mp_db_execute]
GO
