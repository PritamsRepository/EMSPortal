SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------


CREATE Procedure [dbo].[ddl_ReferenceStrength]
@StrengthID INT = NULL,
@FormID INT
AS

/**********************************************************************************
CREATED BY:			JRG
CREATED DATE:		OCT 12, 2010
MODIFIED BY:
MODIFIED DATE:
PURPOSE:				The purpose of this script is to retrieve a list of 
							strength IDs that are not already a reference strengthID 
						for a specific form 
**********************************************************************************/

BEGIN TRY 

	SELECT 
		StrengthID,[Name]
	FROM tblstrength
		WHERE FormID = @FormID
		AND (@StrengthID is null or StrengthID <> @StrengthID)
		AND ReferenceStrengthID IS NULL
		AND IsUndefined=0
	 
	ORDER BY 
		Name

END TRY

BEGIN CATCH
	EXECUTE [dbo].[sp_RollAndRaise]
END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_ReferenceStrength] TO [mp_db_execute]
GO
