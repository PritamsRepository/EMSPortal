SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetBBOTagsByBBOID] @BBOID INT
AS
    SELECT VBT.ValidBBOTagID AS ID,
			VBT.Tag AS Name
    FROM dbo.tblValidBBOTag AS VBT 
		JOIN dbo.tblBusinessBaseObjectTag AS BBOT 
			ON VBT.ValidBBOTagID = BBOT.ValidBBOTagID
	WHERE bbot.BBOID = @BBOID 
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetBBOTagsByBBOID] TO [mp_db_execute]
GO
