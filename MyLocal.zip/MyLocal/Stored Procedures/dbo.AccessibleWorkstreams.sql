SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[AccessibleWorkstreams] ( @BBOID INT, @UserID INT )
AS
BEGIN
    IF ( @BBOID = 40 )
        BEGIN
            SELECT  ProjectID AS ID
            FROM    pm.Project
        END
    ELSE
        IF ( @BBOID = 48 )
            BEGIN
                SELECT  LaunchWorkstreamID AS ID
                FROM    pm.LaunchWorkstream
            END
        ELSE
            IF ( @BBOID = 78 )
                BEGIN
                    SELECT  DevWorkstreamID AS ID
                    FROM    pm.DevWorkstream
                END
            ELSE
                IF ( @BBOID = 82 )
                    BEGIN
                        SELECT  TradeDressWorkstreamID AS ID
                        FROM    pm.TradeDressWorkstream
                    END
                ELSE
                    IF ( @BBOID = 84 )
                        BEGIN
                            SELECT  PivotalWorkstreamID AS ID
                            FROM    pm.PivotalWorkstream
                        END
                    ELSE
                        IF ( @BBOID = 83 )
                            BEGIN
                                SELECT    DISTINCT
                                        masw.MASubmissionWorkstreamID AS ID
                                FROM    dbo.MASubmissionWorkstream masw
                                        JOIN dbo.tblMAApplication maa ON maa.MAApplicationID = masw.MAApplicationID
                                        JOIN dbo.tblSubmissionRoute sr ON maa.SubmissionRouteID = sr.SubmissionRouteID
                                        JOIN dbo.tblSubmissionRouteConfig src ON sr.SubmissionRouteID = src.SubmissionRouteID
                                        JOIN dbo.udf_UserHasPrivForCountry_TableValued(@UserID,
                                                              'MA01') p ON src.CountryID = p.CountryID
                                                              AND p.Privs = 1
                                WHERE   sr.ISHADependent = 0
                                        OR ( sr.ISHADependent = 1
                                             AND maa.HealthAuthorityID = src.HealthAuthorityID
                                           )
                            END
END
GO
