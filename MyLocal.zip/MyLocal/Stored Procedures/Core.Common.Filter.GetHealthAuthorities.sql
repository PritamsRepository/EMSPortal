SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetHealthAuthorities]
	@Name nvarchar(256) = NULL
AS
	SELECT 
		c.CompanyID, co.code + ' - ' + c.Name AS Name, c.Code
	FROM 
		dbo.tblCompany c
		JOIN tblCompanyLinkCompanyGroup lnk ON lnk.CompanyID = c.CompanyID
		JOIN tblCompanyGroup cg ON cg.CompanyGroupID = lnk.CompanyGroupID
		JOIN tblCountry co ON c.CountryID = co.CountryID
	WHERE 
		cg.[Text] = 'Health Authority' AND 
		(@Name IS Null OR co.code + ' - ' + c.Name like '%' + @Name + '%')
GO
