SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[PivotalWorkstream_Summary_ParameterTranslation]
    @ID INT = NULL ,
    @ProjectID INT = NULL ,
    @ProductGroupID INT = NULL ,
    @PivotalWorkstreamStatusID INT = NULL ,
    @CountryGroupFiltersList NVARCHAR(MAX) = NULL ,
    @BBOTagFiltersList NVARCHAR(MAX) = NULL ,
    @SubmissionYearFiltersList NVARCHAR(MAX) = NULL ,
    @FormFiltersList NVARCHAR(MAX) = NULL ,
    @LeadID INT = NULL ,
    @DevSiteID INT = NULL ,
    @ParentID INT = NULL ,
    @ParentType INT = NULL ,
    @UserId INT ,
    @PrivCode NVARCHAR(10) ,
    @FormFiltersInclusionID INT = NULL ,
    @DevSiteInclusionID INT = NULL ,
    @CountryGroupFiltersInclusionID INT = NULL ,
    @LeadInclusionID INT = NULL ,
    @SubmissionYearFiltersInclusionID INT = NULL ,
    @PivotalWorkstreamStatusInclusionID INT = NULL ,
    @BBOTagFiltersInclusionID INT = NULL ,
    @SiteCompanyGroups NVARCHAR(MAX) = NULL , -- Replace | with ,
    @SiteFiltersList NVARCHAR(MAX) = NULL ,
    @SiteNameFiltersInclusionID INT = NULL
AS
    BEGIN
        DECLARE @CountryGroupFilters CountryGroupType
        DECLARE @BBOTagFilters BBOTagType
        DECLARE @SubmissionYearFilters TimeframeType
        DECLARE @FormFilters FormType
        DECLARE @SiteFilters IdType
                
        DECLARE @PivotalWorkstreamStatus NVARCHAR(MAX) = 'All'
        DECLARE @CountryGroups NVARCHAR(MAX) = 'All'
        DECLARE @BBOTags NVARCHAR(MAX) = 'All'
        DECLARE @ProjectTypes NVARCHAR(MAX) = 'All'
        DECLARE @SubmissionYears NVARCHAR(MAX) = 'All'
        DECLARE @Forms NVARCHAR(MAX) = 'All'
        DECLARE @PivotalWorkstreamLead NVARCHAR(MAX) = 'All'
        DECLARE @DevSite NVARCHAR(MAX) = 'All'
        DECLARE @User NVARCHAR(MAX)
        DECLARE @ProductGroup NVARCHAR(MAX) = 'All'
        DECLARE @ParentObject NVARCHAR(MAX)
        DECLARE @Sites NVARCHAR(MAX) = 'All' --Null should return 'All'
        DECLARE @SiteNames NVARCHAR(MAX) = 'All' --Null should return 'All'
        IF LEN(@CountryGroupFiltersList) > 0
            BEGIN
                INSERT  @CountryGroupFilters
                        ( CountryGroupID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList)
		
                SET @CountryGroups = ( SELECT   STUFF(( SELECT DISTINCT
                                                              ', ' + Name
                                                        FROM  dbo.tblCountryGroup
                                                        WHERE CountryGroupID IN (
                                                              SELECT
                                                              CountryGroupID
                                                              FROM
                                                              @CountryGroupFilters )
                                                        ORDER BY ', ' + Name
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                     )
                
            END
            
        IF LEN(@BBOTagFiltersList) > 0
            BEGIN
                INSERT  @BBOTagFilters
                        ( BBOTagID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@BBOTagFiltersList)
                    
                DECLARE @Tag TABLE ( Sequence INT, Name NVARCHAR(256) );

				INSERT INTO @Tag
				SELECT DISTINCT
						0 AS Sequence,
						vt.Tag AS Name
				FROM    dbo.tblValidBBOTag vt
						JOIN @BBOTagFilters tf ON vt.ValidBBOTagID = tf.BBOTagID
						JOIN dbo.tblBusinessBaseObjectTag bbot ON vt.ValidBBOTagID = bbot.ValidBBOTagID
				WHERE   bbot.BBOID = 84 --Pivotal Workstream
				        
				UNION ALL
				        
				SELECT DISTINCT
						1 AS Sequence,
						(vt.Tag + ' (Project)') AS Name
				FROM    dbo.tblValidBBOTag vt
						JOIN dbo.tblBusinessBaseObjectTag bbot ON vt.ValidBBOTagID = bbot.ValidBBOTagID
						JOIN @BBOTagFilters tf ON vt.ValidBBOTagID = tf.BBOTagID
				WHERE   bbot.BBOID = 40 --Project

				ORDER BY Sequence, Name;
				                    
				SET @BBOTags = ( SELECT STUFF(( SELECT   (', ' + t.Name)
												FROM	 @Tag t                                                        
												ORDER BY t.Sequence, t.Name
											  FOR
												XML PATH('')
											  ), 1, 2, ''));
            
            END
       
        IF LEN(@SubmissionYearFiltersList) > 0
            BEGIN
                INSERT  @SubmissionYearFilters
                        ( Timeframe
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList)
                 
                SET @SubmissionYears = ( SELECT STUFF(( SELECT DISTINCT
                                                              ', '
                                                              + CASE
                                                              WHEN Timeframe = '-12'
                                                              THEN N'12 mos.'
                                                              ELSE CONVERT(NVARCHAR(10), Timeframe)
                                                              END
                                                        FROM  @SubmissionYearFilters
                                                        ORDER BY 1
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '')
                                       )
                
            END
       
        IF LEN(@FormFiltersList) > 0
            BEGIN
                INSERT  @FormFilters
                        ( FormID
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@FormFiltersList)
                    
                SET @Forms = ( SELECT   STUFF(( SELECT DISTINCT
                                                        ', ' + Name
                                                FROM    dbo.tblForm
                                                WHERE   FormID IN ( SELECT
                                                              FormID
                                                              FROM
                                                              @FormFilters )
                                                ORDER BY ', ' + Name
                                              FOR
                                                XML PATH('')
                                              ), 1, 2, '')
                             )
                
            END

        IF LEN(@SiteCompanyGroups) > 0
            BEGIN
                SET @Sites = REPLACE(@SiteCompanyGroups, '|', ', ')
        
                INSERT  INTO @SiteFilters
                        ( id
                        )
                        SELECT  *
                        FROM    dbo.udf_GetValuesFromCSV(@SiteFiltersList)
		
                SET @SiteNames = ( SELECT   STUFF(( SELECT DISTINCT
                                                            ', ' + Name
                                                    FROM    dbo.tblCompany
                                                    WHERE   CompanyID IN (
                                                            SELECT
                                                              id
                                                            FROM
                                                              @SiteFilters )
                                                    ORDER BY ', ' + Name
                                                  FOR
                                                    XML PATH('')
                                                  ), 1, 2, '')
                                 )
            END

        SELECT  @PivotalWorkstreamLead = COALESCE(FullName, ADUserName)
        FROM    dbo.admin_SecUser
        WHERE   UserID = @LeadID
       
        
        SELECT  @PivotalWorkstreamStatus = StateName
        FROM    dbo.tblBusinessBaseStates
        WHERE   StateID = @PivotalWorkstreamStatusID
        
        SELECT  @DevSite = Name
        FROM    tblCompany
        WHERE   CompanyID = @DevSiteID
        
        SELECT  @User = COALESCE(FullName, ADUserName)
        FROM    dbo.admin_SecUser
        WHERE   UserID = @UserID
        
        SELECT  @ProductGroup = P.Name
        FROM    dbo.tblProduct AS P
        WHERE   P.ProductID = @ProductGroupID
        
        SELECT  @ParentObject = BBO.BBOCode
        FROM    dbo.tblBusinessBaseObject AS BBO
        WHERE   BBO.BBOID = @ParentType
                
        SELECT  dbo.udf_InclusionParameterTranslate(@PivotalWorkstreamStatusInclusionID,
                                                    @PivotalWorkstreamStatus,
                                                    1) AS AdminStatus ,
                dbo.udf_InclusionParameterTranslate(@CountryGroupFiltersInclusionID,
                                                    @CountryGroups, 0) AS Regions ,
                dbo.udf_InclusionParameterTranslate(@BBOTagFiltersInclusionID,
                                                    @BBOTags, 0) AS Tags ,
                dbo.udf_InclusionParameterTranslate(@SubmissionYearFiltersInclusionID,
                                                    @SubmissionYears, 0) AS SubmissionYears ,
                dbo.udf_InclusionParameterTranslate(@FormFiltersInclusionID,
                                                    @Forms, 0) AS Forms ,
                dbo.udf_InclusionParameterTranslate(@LeadInclusionID,
                                                    @PivotalWorkstreamLead, 1) AS PivotalWorkstreamLead ,
                dbo.udf_InclusionParameterTranslate(@DevSiteInclusionID,
                                                    @DevSite, 1) AS DevSite ,
                dbo.udf_InclusionParameterTranslate(@SiteNameFiltersInclusionID,
                                                    @Sites, 0) AS Sites ,
                dbo.udf_InclusionParameterTranslate(@SiteNameFiltersInclusionID,
                                                    @SiteNames, 0) AS SiteNames ,
                @ProductGroup AS ProductGroup ,
                ISNULL(@ParentObject, '') AS ParentPrefix ,
                @User AS [User]
    END



GO
