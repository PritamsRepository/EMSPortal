SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ddl_GetUserFullNames]
AS
/*===========================================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS CONSULTANT
CREATED ON:				NOV 25, 2009		
MODIFIED BY:				ANDREW DECKER	
MODIFIED ON:				Added Order By
PURPOSE:					The purpose of this procedure is to get all of the names of all of the users for administrative control.
-----------------------------------------------------------------------------------------------------------------------
EXAMPLE:					EXECUTE ddl_GetUserFullNames
===========================================================================================*/

BEGIN TRY
	SELECT DISTINCT 
		su.UserID,
		su.FullName
	FROM
		admin_SecUser su
		inner join admin_SecUserRole sur on su.UserID = sur.UserID
	WHERE 
		-- Do not show Mary Yvonne Presley.
		(su.FullName IS NOT NULL or su.FullName <> '') AND
		su.UserID <> 1
	ORDER BY
		FullName
END TRY

BEGIN CATCH
	Execute sp_RollAndRaise
END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_GetUserFullNames] TO [mp_db_execute]
GO
