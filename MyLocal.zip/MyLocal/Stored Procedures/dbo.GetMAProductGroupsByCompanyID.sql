SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[GetMAProductGroupsByCompanyID]
	@CompanyID INT
AS
	SELECT 
       STUFF(
                (
                    SELECT DISTINCT
                           '<br/>' + p.Name
                    FROM dbo.tblMASite mas
                        JOIN dbo.tblMARegisteredSite mars
                            ON mars.MASiteID = mas.MASiteID
                        JOIN dbo.tblMALicenseScope mals
                            ON mals.MALicenseScopeID = mars.MALicenseScopeID
                        JOIN dbo.tblMALicense mal
                            ON mal.MALicenseID = mals.MALicenseID
                        JOIN dbo.tblMAStrength mastr
                            ON mastr.MAStrengthID = mals.MAStrengthID
                        JOIN dbo.tblStrength s
                            ON s.StrengthID = mastr.StrengthID
                        JOIN dbo.tblForm f
                            ON f.FormID = s.FormID
                        JOIN dbo.tblProduct p
                            ON p.ProductID = f.ProductID
                    WHERE mas.CompanyID = @CompanyID
                    ORDER BY '<br/>' + p.Name
                    FOR XML PATH(''), ROOT('mystring'), TYPE
                ).value('/mystring[1]', 'varchar(max)'),
                1,
                5,
                ''
            ) AS MAProductGroups
GO
