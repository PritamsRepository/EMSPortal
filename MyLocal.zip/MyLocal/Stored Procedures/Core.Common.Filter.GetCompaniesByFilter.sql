SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetCompaniesByFilter]
    @Name NVARCHAR(256) = NULL ,
    @Type NVARCHAR(256) = NULL ,
    @SiteType NVARCHAR(256) = NULL
AS
    SELECT  c.CompanyID ,
            CASE WHEN c.IsThirdParty = 0 THEN 'Mylan : '
                 ELSE ''
            END + c.Name AS Name ,
            c.Code
    FROM    dbo.tblCompany c
            --LEFT JOIN tblCompanyLinkCompanyGroup lnk ON lnk.CompanyID = c.CompanyID
            --LEFT JOIN tblCompanyGroup cg ON cg.CompanyGroupID = lnk.CompanyGroupID
    WHERE   ( @Type IS NULL
              OR c.CompanyID IN (
              SELECT    CompanyID
              FROM      tblCompanyLinkCompanyGroup lnk
                        LEFT JOIN tblCompanyGroup cg ON cg.CompanyGroupID = lnk.CompanyGroupID
              WHERE     cg.[Text] = @Type )
            )
            AND ( @Name IS NULL
                  OR c.Name LIKE '%' + @Name + '%'
                )
            AND ( @SiteType IS NULL
                  OR ( c.ValidCompanyTypeID = ( SELECT  ValidCompanyTypeID
                                                FROM    dbo.tblValidCompanyType
                                                WHERE   name = @SiteType
                                              )
                       AND c.CompanyID IN ( SELECT  SiteID
                                            FROM    GA.GuidanceRequestSite )
                     )
                )
    ORDER BY c.IsThirdParty ,
            c.Name
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetCompaniesByFilter] TO [mp_db_execute]
GO
