SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_ReferencedMASubmissionRoutes] 
  @UserID INT = NULL

AS
BEGIN TRY

	SELECT DISTINCT
	  VPR.SubmissionRouteID ID, vpr.NAME
	FROM
	  dbo.tblSubmissionRoute VPR
		JOIN dbo.tblMAApplication MA ON VPR.SubmissionRouteID = MA.SubmissionRouteID
		
END  TRY
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH
GO
