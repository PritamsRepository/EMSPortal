SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


--EXEC [Core.Reporting].[GetPivotalWorkstreamMilestone]
CREATE PROCEDURE [Core.Reporting].[GetPivotalWorkstreamMilestone]
AS
BEGIN
    DECLARE @BBOID INT;
    SELECT @BBOID = BBOID
    FROM dbo.tblBusinessBaseObject
    WHERE BBOCode = 'PVW';
    SELECT DISTINCT
           pw.PivotalWorkstreamID AS [MSPivotalWorkstreamID],
           BBO.BBOCode AS [MilestoneBBOPivotal],
           mti.Name AS [MilestoneNamePivotal],
           mti.Code AS [MilestoneCodePivotal],
           vms.Name AS [MilestoneStatusPivotal],
           CASE
               WHEN M.ReferenceMilestoneID IS NULL THEN
                   M.BestEstimateDate
               ELSE
                   refm.BestEstimateDate
           END AS [MilestoneDatePivotal],
           CASE
               WHEN M.ReferenceMilestoneID IS NULL THEN
                   M.TargetDate
               ELSE
                   refm.TargetDate
           END AS [TargetDate],
           mti.DisplayOrder AS [MilestoneOrderPivotal]
    FROM pm.PivotalWorkstream pw
        JOIN dbo.tblMilestoneTemplateItem AS mti
            ON mti.MilestoneTemplateID = pw.MilestoneTemplateID
        JOIN dbo.tblMilestone AS M
            ON M.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
               AND M.ObjectID = pw.PivotalWorkstreamID
               AND M.BBOID = @BBOID
        JOIN dbo.tblGlobalMilestone AS GM
            ON mti.GlobalMilestoneID = GM.GlobalMileStoneID
        JOIN dbo.tblBusinessBaseObject AS BBO
            ON GM.BBOID = BBO.BBOID
        LEFT JOIN dbo.tblMilestone refm
            ON M.ReferenceMilestoneID = refm.MileStoneID
        LEFT JOIN dbo.tblValidMilestoneStatus vms
            ON COALESCE(refm.StatusID, M.StatusID) = vms.ValidMilestoneStatusID;
END;
GO
