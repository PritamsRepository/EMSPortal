SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[GetLinkedItems]
(@BBOID INT, @ObjectID INT)
AS
BEGIN
	-- Project
	IF (@BBOID = 40)
	BEGIN
		EXEC [pm.CRUD].Project_GetLinkedItems @ObjectID
	END
	-- DevWorkstream
	IF (@BBOID = 78)
	BEGIN
		EXEC [pm.CRUD].DevWorkstream_GetLinkedItems @ObjectID
	END
	-- TradeDressWorkstream
	IF (@BBOID = 82)
	BEGIN
		EXEC [pm.CRUD].TradeDressWorkstream_GetLinkedItems @ObjectID
	END
	-- PivotalWorkstream
	IF (@BBOID = 84)
	BEGIN
		EXEC [pm.CRUD].PivotalWorkstream_GetLinkedItems @ObjectID
	END
	-- Launch
	IF (@BBOID = 48)
	BEGIN
		EXEC [dbo].LaunchWorkstream_GetLinkedItems @ObjectID
	END 
	-- MASubmissionWorkstream
	IF (@BBOID = 83)
	BEGIN
		EXEC [dbo].MASubmissionWorkstream_GetLinkedItems @ObjectID
	END
	-- SNCWorkstream
	IF (@BBOID = 119)
	BEGIN
		EXEC [dbo].SNCWorkstream_GetLinkedItems @ObjectID
	END
END
GO
