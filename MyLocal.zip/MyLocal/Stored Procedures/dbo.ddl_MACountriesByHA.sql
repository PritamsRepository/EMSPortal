SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MACountriesByHA]
    @HAID INT ,
    @SubmissionRouteID INT = NULL ,
    @UserID INT
AS /* 
Author:	ARD
Desc:	Drop down list for Countries by HealthAuthority
Date:	2011-08-3

Modified by JRG
Date:	2011-09-07
add logic to return countries based on submission route

National return HA country
Centralised Procedure return all EMA Europe countries
MRP or DCP return all countries for HA EMA
Procedure route and Submission route are the same syntatical sugar 
JRG-1 2012-01-12 fix issue with Health Authoirties not showing up
when they are not a national, only has one HA, or centralized has 27
Decentralized or MRP would have all in the EU country group

*/
    BEGIN TRY 
        DECLARE @PCID INT ,
            @CID INT ,
            @Privcode NVARCHAR(10) ,
            @SubmissionRouteName NVARCHAR(256) ;
	
        SET @Privcode = 'MA03'

        SET @SubmissionRouteName = ( SELECT NAME
                                     FROM   dbo.tblSubmissionRoute
                                     WHERE  SubmissionRouteID = @SubmissionRouteID )

        IF ( @SubmissionRouteName = 'Centralised (CP)' ) /* this assumes EU Centralized is the intent */ 
            BEGIN
                SELECT  @PCID = ParentCompanyID ,
                        @CID = CountryID
                FROM    dbo.tblCompany
                WHERE   CompanyID = ( SELECT    CompanyID
                                      FROM      dbo.tblCompany
                                      WHERE     Name LIKE 'European Medicines Agency%' )
                SET @HAID = ( SELECT    CompanyID
                              FROM      dbo.tblCompany
                              WHERE     Name LIKE 'European Medicines Agency%' )
                              
                IF ( @PCID IS NULL
                     AND @CID IS NULL ) 
                    BEGIN /* I am a parent but use my child countries lookup child records and use their countries EMA e.g.*/
                        SELECT  C.CountryID ,
                                C.Name
                        FROM    dbo.tblCountry C
                                JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                        WHERE   ParentCompanyID = @HAID
                                AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                        ORDER BY C.Name
	
	
                    END

                ELSE 
                    IF ( @PCID IS NULL
                         AND @CID IS NOT NULL ) 
                        BEGIN /* I am the parent and have a country use mine FDA e.g*/
                            SELECT  C.CountryID ,
                                    C.Name
                            FROM    dbo.tblCountry C
                                    JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                            WHERE   CompanyID = @HAID
                                    AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                            ORDER BY C.Name
                        END
                    ELSE 
                        IF ( @PCID IS NOT NULL
                             AND @CID IS NULL ) 
                            BEGIN /* I am a child and do not have a country use my parent*/
                                SELECT  C.CountryID ,
                                        C.Name
                                FROM    dbo.tblCountry C
                                        JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                                WHERE   ParentCompanyID = ( SELECT  CompanyID
                                                            FROM    dbo.tblCompany
                                                            WHERE   ParentCompanyID = @HAID )
                                        AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                                ORDER BY C.Name
                            END
                        ELSE 
                            IF ( @PCID IS NOT NULL
                                 AND @CID IS NOT NULL ) 
                                BEGIN
                                    SELECT  C.CountryID ,
                                            C.Name
                                    FROM    dbo.tblCountry C
                                            JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                                    WHERE   CompanyID = @HAID
                                            AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                                    ORDER BY C.Name
                                END
                            ELSE 
                                BEGIN
                                    RAISERROR('Unexpected event occured while looking up company countries', 16, 10) WITH NoWait ;

                                END                                           
            END

		
        ELSE 
            IF ( @SubmissionRouteName = 'National' ) 
                BEGIN
	
			/* is a national  */
                    SELECT  @PCID = ParentCompanyID ,
                            @CID = CountryID
                    FROM    dbo.tblCompany
                    WHERE   CompanyID = @HAID
                
                
                    IF ( @PCID IS NULL
                         AND @CID IS NULL ) 
                        BEGIN /* I am a parent but use my child countries lookup child records and use their countries EMA e.g.*/
                            SELECT  C.CountryID ,
                                    C.Name
                            FROM    dbo.tblCountry C
                                    JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                            WHERE   ParentCompanyID = @HAID
                                    AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                            ORDER BY C.Name
	
                        END

                    ELSE 
                        IF ( @PCID IS NULL
                             AND @CID IS NOT NULL ) 
                            BEGIN /* I am the parent and have a country use mine FDA e.g*/
                                SELECT  C.CountryID ,
                                        C.Name
                                FROM    dbo.tblCountry C
                                        JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                                WHERE   CompanyID = @HAID
                                        AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                                ORDER BY C.Name
                            END
                        ELSE 
                            IF ( @PCID IS NOT NULL
                                 AND @CID IS NULL ) 
                                BEGIN /* I am a child and do not have a country use my parent*/
                                    SELECT  C.CountryID ,
                                            C.Name
                                    FROM    dbo.tblCountry C
                                            JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                                    WHERE   ParentCompanyID = ( SELECT  CompanyID
                                                                FROM    dbo.tblCompany
                                                                WHERE   ParentCompanyID = @HAID )
                                            AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                                    ORDER BY C.Name
                                END
                            ELSE 
                                IF ( @PCID IS NOT NULL
                                     AND @CID IS NOT NULL ) 
                                    BEGIN
                                        SELECT  C.CountryID ,
                                                C.Name
                                        FROM    dbo.tblCountry C
                                                JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                                        WHERE   CompanyID = @HAID
                                                AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                                    END
                                ELSE 
                                    BEGIN
                                        RAISERROR('Unexpected event occurred while looking up company countries', 16, 10) WITH NoWait ;

                                    END                             
                END       

            ELSE 
                BEGIN
/* Return all Health Authorities in the Europe Region including nordic countries not just EU members*/
                    SELECT  C.CountryID ,
                            C.Name
                    FROM    dbo.tblCountry C
                            JOIN dbo.tblCountryLinkCountryGroup CLCG ON C.CountryID = CLCG.CountryID
                            JOIN dbo.tblCountryGroup CG ON CLCG.CountryGroupID = CG.CountryGroupID
                                                           AND cg.CountryGroupType = 'MAMktFilter'
                                                           AND cg.Name = 'EU' /* not sure the grouping name */
                    ORDER BY c.Name
                            

                            
                END                            

/* JRG -1 left this in here as a reference to get companies and parents

        IF ( @PCID IS NULL
             AND @CID IS NULL ) 
            BEGIN /* I am a parent but use my child countries lookup child records and use their countries EMA e.g.*/
                SELECT  C.CountryID ,
                        C.Name
                FROM    dbo.tblCountry C
                        JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                WHERE   ParentCompanyID = @HAID
                        AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
	
            END

        ELSE 
            IF ( @PCID IS NULL
                 AND @CID IS NOT NULL ) 
                BEGIN /* I am the parent and have a country use mine FDA e.g*/
                    SELECT  C.CountryID ,
                            C.Name
                    FROM    dbo.tblCountry C
                            JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                    WHERE   CompanyID = @HAID
                            AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                END
            ELSE 
                IF ( @PCID IS NOT NULL
                     AND @CID IS NULL ) 
                    BEGIN /* I am a child and do not have a country use my parent*/
                        SELECT  C.CountryID ,
                                C.Name
                        FROM    dbo.tblCountry C
                                JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                        WHERE   ParentCompanyID = ( SELECT  CompanyID
                                                    FROM    dbo.tblCompany
                                                    WHERE   ParentCompanyID = @HAID )
                                AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                    END
                ELSE 
                    IF ( @PCID IS NOT NULL
                         AND @CID IS NOT NULL ) 
                        BEGIN
                            SELECT  C.CountryID ,
                                    C.Name
                            FROM    dbo.tblCountry C
                                    JOIN dbo.tblCompany CP ON C.CountryID = CP.CountryID
                            WHERE   CompanyID = @HAID
                                    AND dbo.udf_UserHasPrivForCountry(@UserID, @Privcode, C.CountryID) = 1
                        END
                    ELSE 
                        BEGIN
                            RAISERROR('Unexpected event occured while looking up company countries', 16, 10) WITH NoWait ;

                        END     
                        */        
        
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 

GO
GRANT EXECUTE ON  [dbo].[ddl_MACountriesByHA] TO [mp_db_execute]
GO
