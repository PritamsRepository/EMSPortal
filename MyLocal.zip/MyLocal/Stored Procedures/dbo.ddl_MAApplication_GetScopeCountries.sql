SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAApplication_GetScopeCountries]
  @MAApplicationID INT
  
AS 
BEGIN TRY

  SELECT DISTINCT
	c.CountryID,
	c.Name
  FROM	
	dbo.tblMALicense mal
	  JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
	  JOIN dbo.tblCountry c ON mals.CountryID = c.CountryID
  WHERE
	mal.MAApplicationID = @MAApplicationID	  
  ORDER BY
	c.Name;
            
END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplication_GetScopeCountries] TO [mp_db_execute]
GO
