SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAApplication_GetScopeProducts]
  @MAApplicationID INT
  
AS 
BEGIN TRY

  SELECT DISTINCT
	(CAST(f.FormID AS NVARCHAR) + ':' + CAST(s.StrengthID AS NVARCHAR)) AS ID,	
	(f.name + ' ' + s.Name) AS Name	
  FROM	
	dbo.tblMALicense mal
	  JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
	  JOIN dbo.tblMAStrength mas ON mals.MAStrengthID = mas.MAStrengthID
	  JOIN dbo.tblStrength s ON mas.StrengthID = s.StrengthID
	  JOIN dbo.tblForm f ON s.FormID = f.FormID
  WHERE
	mal.MAApplicationID = @MAApplicationID	  
  ORDER BY
	Name;

END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplication_GetScopeProducts] TO [mp_db_execute]
GO
