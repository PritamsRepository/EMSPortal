SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_ValidSiteType] AS
BEGIN TRY
  
  DECLARE @PackagingDisplayOrder INT = (SELECT TOP 1 DisplayOrder FROM dbo.tblValidSiteType WHERE Name LIKE '%Packaging%');
  
  SELECT
	DisplayOrder,
	Value,
	Name
  FROM
	(  
	  SELECT
		(CASE WHEN vt.Name LIKE '%Packaging%' THEN @PackagingDisplayOrder ELSE vt.DisplayOrder END) AS DisplayOrder,
		vt.Name AS Value,
		(CASE WHEN vt.Name = 'Packaging Site' THEN 'All Packaging Sites' ELSE vt.Name END) AS Name
	  FROM
		dbo.tblValidSiteType vt	  
		  JOIN dbo.tblCompanyGroup cg ON vt.Name = cg.[Text]  
      
	  UNION
      
	  SELECT DISTINCT
		(CASE WHEN vt.Category LIKE '%Packaging%' THEN @PackagingDisplayOrder ELSE vt.DisplayOrder END) AS DisplayOrder,
		vt.Category AS Value,
		vt.Category AS Name
	  FROM
		dbo.tblValidSiteType vt
		  JOIN dbo.tblCompanyGroup cg ON vt.Name = cg.[Text]
	) st
	ORDER BY
		DisplayOrder,
		Name
	
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 

GO
GRANT EXECUTE ON  [dbo].[ddl_ValidSiteType] TO [mp_db_execute]
GO
