SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MarketedLicenseStatus]
AS 
    BEGIN TRY
	
        SELECT  DISTINCT ls.MarketStatusID ,
                BBS.StateName AS MarketStatus 
        FROM    dbo.tblMALicenseScope ls
                JOIN dbo.tblBusinessBaseStates BBS ON ls.MarketStatusID = BBS.StateID 
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 

GO
GRANT EXECUTE ON  [dbo].[ddl_MarketedLicenseStatus] TO [mp_db_execute]
GO
