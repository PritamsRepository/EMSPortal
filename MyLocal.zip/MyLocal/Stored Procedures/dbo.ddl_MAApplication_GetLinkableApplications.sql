SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MAApplication_GetLinkableApplications]
    @FormID INT ,
    @CountryGroupID INT
AS
    BEGIN TRY
        SELECT DISTINCT
                maa.MAApplicationID AS ID ,
                MAName + ' - ' + sr.Category + ' - ' + maa.ProcedureNumber AS Name
        FROM    dbo.tblMAApplication maa
                JOIN dbo.tblSubmissionRouteConfig src ON src.HealthAuthorityID = maa.HealthAuthorityID
                                                         AND src.SubmissionRouteID = maa.SubmissionRouteID
                JOIN dbo.tblSubmissionRoute sr ON sr.SubmissionRouteID = src.SubmissionRouteID
                JOIN dbo.tblCountryLinkCountryGroup clcg ON clcg.CountryID = src.CountryID
                JOIN tblMAStrength mas ON mas.MAApplicationID = maa.MAApplicationID
                JOIN tblStrength s ON s.StrengthID = mas.StrengthID
        WHERE   clcg.CountryGroupID = @CountryGroupID
                AND s.FormID = @FormID
        ORDER BY maa.MAApplicationID
    END TRY

    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
