SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[Attachment_GetByID] @AttachmentID INT
AS 
    SELECT  a.AttachmentID AS ID,
            a.BBOID,
            a.Comment,
            a.ConcurrencyID,
            a.Name,
            a.ObjectID,
            a.OriginalFileName,
            a.URL,
            a.ValidFileExtID,
            a.UpdateUserID,
            a.UpdateDate
            
    FROM    dbo.tblAttachment a
    WHERE   a.AttachmentID = @AttachmentID
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Attachment_GetByID] TO [mp_db_execute]
GO
