SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[GetCEESDDatesByUser]
    (
      @UserID INT ,
      @PrivCode NVARCHAR(10)
    )
AS
    BEGIN
        DECLARE @BBOID INT = ( SELECT   BBOID
                               FROM     dbo.tblBusinessBaseObject
                               WHERE    BBOCode = 'PJM'
                             )
        SELECT DISTINCT
                YEAR(CASE WHEN m.ReferenceMilestoneID IS NULL
                          THEN m.BestEstimateDate
                          ELSE refm.BestEstimateDate
                     END) AS VALUE,
                CONVERT(NVARCHAR(4),YEAR(CASE WHEN m.ReferenceMilestoneID IS NULL
                          THEN m.BestEstimateDate
                          ELSE refm.BestEstimateDate
                     END)) AS Label
        FROM    dbo.tblMilestone m
                JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                         AND mti.Code = 'Submission'
                JOIN pm.Project p ON m.ObjectID = p.ProjectID
                LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
        WHERE   m.BBOID = @BBOID
        AND ((m.ReferenceMilestoneID IS NULL AND m.BestEstimateDate IS NOT NULL)
        OR (M.ReferenceMilestoneID IS NOT NULL AND refm.BestEstimateDate IS NOT NULL))

--UNION 
--select year(pr.CurrentEarliestEstimatedSubDate) from dbo.tblProject pr 
ORDER BY        Value
    END


GO
