SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetValidByFilter]
    @Table NVARCHAR(256) = NULL ,
    @Name NVARCHAR(256) = NULL
AS -- 
--Notes:
--	You must pass schema in with the table name.
--

    IF EXISTS ( SELECT  *
                FROM    dbo.sysobjects
                WHERE   id = OBJECT_ID(@Table)
                        AND OBJECTPROPERTY(id, N'IsTable') = 1 )
        BEGIN
		--find the primary key name for the query
            DECLARE @TableName NVARCHAR(256) = RTRIM(SUBSTRING(@Table,
                                                              CHARINDEX('.',
                                                              @Table) + 1,
                                                              LEN(@Table)))
            DECLARE @SchemaName NVARCHAR(256)= SUBSTRING(@Table, 0,
                                                         CHARINDEX('.', @Table))
            DECLARE @PrimaryKey NVARCHAR(256)

            SELECT  @PrimaryKey = COLUMN_NAME
            FROM    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE   OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_NAME), 'IsPrimaryKey') = 1
                    AND TABLE_NAME = @TableName
                    AND TABLE_SCHEMA = @SchemaName
		
            DECLARE @ValidTable TABLE
                (
                  ID INT ,
                  [Name] NVARCHAR(256) , 
                  [Description] NVARCHAR(2000) ,
                  IsActive BIT ,
                  DisplayOrder INT ,
                  Category NVARCHAR(200) ,
                  IsSystem BIT
                )
						  
            DECLARE @Select NVARCHAR(600) = 'SELECT ' + @PrimaryKey + ', '
                + '[Name], [Description], IsActive, DisplayOrder, Category,  IsSystem '
                + 'FROM ' + @Table + ' WHERE IsActive = 1 '
		
            IF @Name IS NULL
                INSERT  INTO @ValidTable
                        EXEC ( @Select + ' ORDER BY DisplayOrder'
                            )
			
            ELSE
                INSERT  INTO @ValidTable
                        EXEC
                            ( @Select + ' AND Name like ''%' + @Name
                              + '%'' ORDER BY DisplayOrder'
                            )
		
            SELECT  *
            FROM    @ValidTable AS VT 
        END
    ELSE
        RETURN -1;
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetValidByFilter] TO [mp_db_execute]
GO
