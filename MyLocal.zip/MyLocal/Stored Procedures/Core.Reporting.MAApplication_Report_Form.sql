SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Form]
AS
BEGIN

    SELECT f.FormID,
           f.Name AS Form
    FROM dbo.tblForm f
    ORDER BY f.FormID;
END;
GO
