SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicenseHolder] @UserID INT = NULL
AS
BEGIN TRY
    SELECT LicenseHolderID,
           LicenseHolder
    FROM
    (
        SELECT DISTINCT
               mal.LicenseHolderID,
               dbo.udf_MA_FormatCompanies(c.CompanyID) AS LicenseHolder
        FROM dbo.tblMALicense mal
            JOIN dbo.tblMAApplication ma
                ON mal.MAApplicationID = ma.MAApplicationID
            --JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
            JOIN dbo.tblCompany c
                ON mal.LicenseHolderID = c.CompanyID
    ) T2
    ORDER BY CASE
                 WHEN LicenseHolder LIKE 'Mylan%' THEN
                     0
                 ELSE
                     1
             END,
             LicenseHolder;
END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;

GO
GRANT EXECUTE ON  [dbo].[ddl_MALicenseHolder] TO [mp_db_execute]
GO
