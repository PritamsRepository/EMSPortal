SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[admin_AuditTrailReader]
    @StartDate DATE ,
    @EndDate DATE ,
    @StartBBOID INT = NULL ,
    @EndBBOID INT = NULL
AS 
    BEGIN TRY
        IF EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..#Tmp_AuditReader') ) 
            BEGIN
                DROP TABLE #Tmp_AuditReader
            END



        CREATE TABLE #Tmp_AuditReader
            (
              [ChangeTrackingID] BIGINT ,
              ChangeType NVARCHAR(64) ,
              identifier NVARCHAR(1000) ,
              DateChanges NVARCHAR(100) ,
              BusinessObject NVARCHAR(64) ,
              old NVARCHAR(1000) NULL ,
              new NVARCHAR(1000) NULL ,
              UserName NVARCHAR(64) )


        DECLARE @XmlDocument XML ,
            @ChangeTrackingID BIGINT

        DECLARE @DocHandle INT


        IF ( @StartBBOID IS NOT NULL
             AND @EndBBOID IS NOT NULL ) 
            BEGIN
	

                DECLARE c8 CURSOR FAST_FORWARD READ_ONLY LOCAL
                FOR
                    SELECT  [ChangeTrackingID] ,
                            [ObjectChanges]
                    FROM    [dbo].[admin_ChangeTracking_Audit] ct
                            JOIN dbo.admin_SecUser su ON ct.UserID = su.UserID
                    WHERE   ( EntryDate >= @StartDate
                              AND EntryDate <= @EndDate )
                            AND ( BusinessBasedObjectID >= @StartBBOID
                                  AND BusinessBasedObjectID <= @EndBBOID )
                    ORDER BY ChangeTrackingID
            
                OPEN /* cursor name */ c8

                FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument



                WHILE @@FETCH_STATUS = 0 
                    BEGIN

-- Create an internal representation of the XML document.
                        EXEC sp_xml_preparedocument @DocHandle OUTPUT, @XmlDocument

                        INSERT  INTO #Tmp_AuditReader
                                SELECT  @ChangeTrackingID ,
                                        *
                                FROM    OPENXML (@DocHandle, '/AuditTrail',1)
      WITH (ChangeType  NVARCHAR(64) 'Changes/Property/@name',
      identifier NVARCHAR(1000) 'BusinessObject/@identifier',
      DateChanges NVARCHAR(100) 'DateChanges',
      BusinessObject NVARCHAR(64) 'BusinessObject',
      old NVARCHAR(1000) 'Changes/Property/Old',
      new NVARCHAR(1000) 'Changes/Property/New',
      UserName NVARCHAR(64) 'User'
            )
                        EXEC sp_xml_removedocument @DocHandle

                        FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument

                    END

                CLOSE c8
                DEALLOCATE c8
            
            END            
            

            


        IF ( @StartBBOID IS NOT NULL
             AND @EndBBOID IS NULL ) 
            BEGIN

                SET @EndBBOID = @StartBBOID ;

                DECLARE c8 CURSOR FAST_FORWARD READ_ONLY LOCAL
                FOR
                    SELECT  [ChangeTrackingID] ,
                            [ObjectChanges]
                    FROM    [dbo].[admin_ChangeTracking_Audit] ct
                            JOIN dbo.admin_SecUser su ON ct.UserID = su.UserID
                    WHERE   ( EntryDate >= @StartDate
                              AND EntryDate <= @EndDate )
                            AND ( BusinessBasedObjectID >= @StartBBOID
                                  AND BusinessBasedObjectID <= @EndBBOID )
                    ORDER BY ChangeTrackingID
            
                OPEN /* cursor name */ c8

                FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument



                WHILE @@FETCH_STATUS = 0 
                    BEGIN

-- Create an internal representation of the XML document.
                        EXEC sp_xml_preparedocument @DocHandle OUTPUT, @XmlDocument

                        INSERT  INTO #Tmp_AuditReader
                                SELECT  @ChangeTrackingID ,
                                        *
                                FROM    OPENXML (@DocHandle, '/AuditTrail',1)
      WITH (ChangeType  NVARCHAR(64) 'Changes/Property/@name',
      identifier NVARCHAR(1000) 'BusinessObject/@identifier',
      DateChanges NVARCHAR(100) 'DateChanges',
      BusinessObject NVARCHAR(64) 'BusinessObject',
      old NVARCHAR(1000) 'Changes/Property/Old',
      new NVARCHAR(1000) 'Changes/Property/New',
      UserName NVARCHAR(64) 'User'
            )
                        EXEC sp_xml_removedocument @DocHandle

                        FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument

                    END

                CLOSE c8
                DEALLOCATE c8
            END
     
        IF ( @StartBBOID IS NULL
             AND @EndBBOID IS NULL ) 
            BEGIN

                DECLARE c8 CURSOR FAST_FORWARD READ_ONLY LOCAL
                FOR
                    SELECT  [ChangeTrackingID] ,
                            [ObjectChanges]
                    FROM  [dbo].[admin_ChangeTracking_Audit] ct
                            JOIN dbo.admin_SecUser su ON ct.UserID = su.UserID
                    WHERE   ( EntryDate > @StartDate
                              AND EntryDate < @EndDate )
                    ORDER BY ChangeTrackingID
            
                OPEN /* cursor name */ c8

                FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument



                WHILE @@FETCH_STATUS = 0 
                    BEGIN

-- Create an internal representation of the XML document.
                        EXEC sp_xml_preparedocument @DocHandle OUTPUT, @XmlDocument

                        INSERT  INTO #Tmp_AuditReader
                                SELECT  @ChangeTrackingID ,
                                        *
                                FROM    OPENXML (@DocHandle, '/AuditTrail',1)
      WITH (ChangeType  NVARCHAR(64) 'Changes/Property/@name',
      identifier NVARCHAR(1000) 'BusinessObject/@identifier',
      DateChanges NVARCHAR(100) 'DateChanges',
      BusinessObject NVARCHAR(64) 'BusinessObject',
      old NVARCHAR(1000) 'Changes/Property/Old',
      new NVARCHAR(1000) 'Changes/Property/New',
      UserName NVARCHAR(64) 'User'
            )
                        EXEC sp_xml_removedocument @DocHandle

                        FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument

                    END

                CLOSE c8
                DEALLOCATE c8
            END
                        
            
--        OPEN /* cursor name */ c8

--        FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument



--        WHILE @@FETCH_STATUS = 0 
--            BEGIN

---- Create an internal representation of the XML document.
--                EXEC sp_xml_preparedocument @DocHandle OUTPUT, @XmlDocument

--                INSERT  INTO #Tmp_AuditReader
--                        SELECT  @ChangeTrackingID ,
--                                *
--                        FROM    OPENXML (@DocHandle, '/AuditTrail',1)
--      WITH (ChangeType  NVARCHAR(64) 'Changes/Property/@name',
--      identifier NVARCHAR(1000) 'BusinessObject/@identifier',
--      DateChanges NVARCHAR(100) 'DateChanges',
--      BusinessObject NVARCHAR(64) 'BusinessObject',
--      old NVARCHAR(1000) 'Changes/Property/Old',
--      new NVARCHAR(1000) 'Changes/Property/New',
--      UserName NVARCHAR(64) 'User'
--            )
--                EXEC sp_xml_removedocument @DocHandle

--                FETCH NEXT FROM c8  INTO @ChangeTrackingID, @XmlDocument

--            END

        --CLOSE c8
        --DEALLOCATE c8

/* Retreive the results from the shredded xml */

        SELECT  ChangeTrackingID ,
                ChangeType ,
                old ,
                new ,
                identifier ,
                DateChanges ,
                BusinessObject ,
                UserName
        FROM    #Tmp_AuditReader
        ORDER BY 1

        IF EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..#Tmp_AuditReader') ) 
            BEGIN
                DROP TABLE #Tmp_AuditReader
            END


    END TRY

    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[admin_AuditTrailReader] TO [mp_db_execute]
GO
