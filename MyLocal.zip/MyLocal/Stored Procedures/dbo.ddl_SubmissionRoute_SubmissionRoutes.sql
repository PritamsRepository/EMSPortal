SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
 
CREATE Procedure [dbo].[ddl_SubmissionRoute_SubmissionRoutes]

AS
 
BEGIN TRY

  SELECT DISTINCT
	vst.SubmissionRouteID,
	vst.Name
  FROM
	dbo.tblSubmissionRoute vst
	  JOIN dbo.tblSubmissionRouteConfig src ON vst.SubmissionRouteID = src.SubmissionRouteID
  ORDER BY
	vst.Name	  

END TRY 
BEGIN CATCH
	EXEC SP_ROLLANDRAISE
END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_SubmissionRoute_SubmissionRoutes] TO [mp_db_execute]
GO
