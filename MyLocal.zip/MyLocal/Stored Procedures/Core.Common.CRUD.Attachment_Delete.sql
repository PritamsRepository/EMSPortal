SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
  
CREATE PROCEDURE [Core.Common.CRUD].[Attachment_Delete]
    @AttachmentID INT,
    @UpdateUserID INT = NULL
AS 
    DECLARE @BBOID INT
    DECLARE @BBOCode VARCHAR(64)
    
    SELECT  @BBOID = BBOID
    FROM    dbo.tblAttachment
    WHERE   AttachmentID = @AttachmentID
            
    -- If the attachment didn't exist, this prevents an error 
    IF ( @BBOID > 0 ) 
        BEGIN
            SELECT  @BBOCode = BBOCode
            FROM    dbo.tblBusinessBaseObject
            WHERE   BBOID = @BBOID

            DELETE  FROM dbo.tblAttachment
            WHERE   AttachmentID = @AttachmentID

            EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                @UserID = @UpdateUserID, @ObjectID = @AttachmentID,
                @ActionType = 'D'
        END
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Attachment_Delete] TO [mp_db_execute]
GO
