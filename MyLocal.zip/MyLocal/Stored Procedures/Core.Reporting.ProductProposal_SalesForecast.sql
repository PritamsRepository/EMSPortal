SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[ProductProposal_SalesForecast]
    @TargetPRBSessionID INT ,
    @FormID INT = NULL ,
    @StatusID INT = NULL ,
    @CountryGroupID INT = NULL ,
    @UserID INT
AS
    BEGIN
        DECLARE @Years INT = 5
        DECLARE @StartYear INT = YEAR(GETDATE())
		
        DECLARE @gpe BIT = 0
        DECLARE @RoleID INT = ( SELECT  RoleID
                                FROM    admin_SecRole
                                WHERE   Name = 'Global Portfolio Editor'
                              )
        DECLARE @Complete INT = ( SELECT    StateID
                                  FROM      dbo.tblBusinessBaseStates
                                  WHERE     StateControlID = 1
                                            AND StateName = 'Complete'
                                )
        DECLARE @PostPRB INT = ( SELECT StateID
                                 FROM   dbo.tblBusinessBaseStates
                                 WHERE  StateControlID = 1
                                        AND StateName = 'Post PRB'
                               )
		-- Check to see if User is Global Portfolio Editor
        IF EXISTS ( SELECT  1
                    FROM    dbo.admin_SecUserRole
                    WHERE   UserID = @UserID
                            AND RoleID = @RoleID )
            BEGIN
                SET @gpe = 1
            END

        SELECT  pci.ProductProposalCountryInterestID ,
                pp.ProductProposalID ,
                td.ProductProposalTradeDressID ,
                f.Name AS Product ,
                s.Name + ' - ' + COALESCE(vpt.Name + ' ', '')
                + COALESCE(CONVERT(NVARCHAR, td.PackSize) + ' ', '')
                + COALESCE(uom.Name, '') + COALESCE(' - ' + vbl.Name, '') AS [TradeDress] ,
                c.Code AS Country ,
                vsc.Name AS [SalesChannel] ,
                num.Number AS [Year] ,
                sf.ForecastVolume ,
                sf.ForecastPricePerUnit ,
                cur.Name AS Currency ,
                CASE WHEN sf.KeyMarket = 1 THEN 'True'
                     ELSE 'False'
                END AS KeyMarket ,
                sf.MktShare
        FROM    pm.ProductProposal pp
                JOIN dbo.tblForm f ON f.FormID = pp.FormID
                JOIN pm.ProductProposalTradeDress td ON td.ProductProposalID = pp.ProductProposalID
                JOIN dbo.tblStrength s ON s.StrengthID = td.StrengthID
                JOIN pm.Candidate can ON can.CandidateID = pp.CandidateID
                JOIN pm.ProductProposalCountryInterest pci ON pci.ProductProposalID = pp.ProductProposalID
                JOIN dbo.tblCountry c ON c.CountryID = pci.CountryID
                --JOIN dbo.utility_Numbers num ON num.Number >= pp.ForecastStartYear
                --                                AND num.Number <= pp.ForecastStartYear
                --                                + @Years
                JOIN dbo.utility_Years num ON num.Number >= COALESCE(pp.ForecastStartYear,
                                                              ( SELECT
                                                              MIN(ForecastYear)
                                                              FROM
                                                              pm.ProductProposalSalesForecast
                                                              WHERE
                                                              ProductProposalTradeDressID = td.ProductProposalTradeDressID
                                                              ), @StartYear)
                                              AND num.Number <= COALESCE(( SELECT
                                                              MAX(ForecastYear)
                                                              FROM
                                                              pm.ProductProposalSalesForecast
                                                              WHERE
                                                              ProductProposalTradeDressID = td.ProductProposalTradeDressID
                                                              ),
                                                              pp.ForecastStartYear,
                                                              @StartYear)
                                              + @Years
                LEFT JOIN dbo.tblValidCurrency cur ON cur.ValidCurrencyID = pp.ValidCurrencyID
                LEFT JOIN dbo.tblValidPackType vpt ON vpt.ValidPackTypeID = td.ValidPackTypeID
                LEFT JOIN dbo.tblValidPackSizeUOM uom ON uom.ValidPackSizeUOMID = td.ValidPackSizeUOMID
                LEFT JOIN dbo.tblValidBreakline vbl ON vbl.ValidBreaklineID = td.ValidBreaklineID
                LEFT JOIN dbo.tblValidSalesChannel vsc ON vsc.ValidSalesChannelID = td.ValidSalesChannelID
                LEFT JOIN pm.ProductProposalSalesForecast sf ON sf.ProductProposalCountryInterestID = pci.ProductProposalCountryInterestID
                                                              AND sf.ProductProposalTradeDressID = td.ProductProposalTradeDressID
                                                              AND sf.ForecastYear = num.Number
        WHERE   can.TargetPRBSessionID = @TargetPRBSessionID
                AND ( @gpe = 1
                      OR pp.StatusID NOT IN ( @Complete, @PostPRB )
                    )
                AND ( @FormID IS NULL
                      OR @FormID = pp.FormID
                    )
                AND ( @StatusID IS NULL
                      OR pp.StatusID = @StatusID
                    )
                AND ( @CountryGroupID IS NULL
                      OR @CountryGroupID = pp.CountryGroupID
                    )
        ORDER BY pp.ProductProposalID ,
                td.ProductProposalTradeDressID ,
                pci.ProductProposalCountryInterestID ,
                num.Number
    END
GO
