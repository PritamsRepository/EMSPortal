SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[admin_UserGridLayout_Delete]
    @UserGridLayoutID INT
AS
    BEGIN TRY	
        BEGIN TRANSACTION
        DELETE  FROM [dbo].[admin_UserGridLayout]
        WHERE   [UserGridLayoutID] = @UserGridLayoutID
	
        COMMIT
        RETURN 0
    END TRY

    BEGIN CATCH
        EXEC [dbo].[sp_RollAndRaise]
    END CATCH





GO
