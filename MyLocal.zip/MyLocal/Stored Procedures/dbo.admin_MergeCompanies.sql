SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[admin_MergeCompanies]
    @OldID INT,
    @NewID INT
AS
BEGIN TRY
    /*
	Merges two existing companies
	into one company, and assigns company groups to the new company 
	if the are not already a member where applicable 
 
 */
    SET XACT_ABORT ON;
    SET NOCOUNT ON;
    BEGIN TRANSACTION;

    IF NOT EXISTS (SELECT Name FROM dbo.tblCompany WHERE CompanyID = @OldID)
    BEGIN
        PRINT 'Old ID does not exists';
        ROLLBACK;
        RETURN -1;
    END;

    IF NOT EXISTS (SELECT Name FROM dbo.tblCompany WHERE CompanyID = @NewID)
    BEGIN
        PRINT 'New ID does not exists';
        ROLLBACK;
        RETURN -1;
    END;

    -- Track X went into Y and such details for fun reporting later
    INSERT INTO dbo.Company_Audit
    (
        CompanyID,
        Name,
        Description,
        CountryID,
        WebSite,
        IsThirdParty,
        ShortName,
        ADDRESS,
        ValidCompanyTypeID,
        ParentCompanyID,
        Code,
        Address1,
        Address2,
        Address3,
        City,
        Region,
        PostalCode,
        AuditActionDescription,
        UpdatedName,
        UpdatedCompanyID
    )
    SELECT CompanyID,
           Name,
           Description,
           CountryID,
           WebSite,
           IsThirdParty,
           ShortName,
           ADDRESS,
           ValidCompanyTypeID,
           ParentCompanyID,
           Code,
           Address1,
           Address2,
           Address3,
           City,
           Region,
           Postalcode,
           'Merged',
           (
               SELECT Name FROM dbo.tblCompany WHERE CompanyID = @NewID
           ),
           @NewID
    FROM dbo.tblCompany
    WHERE CompanyID = @OldID;

    /* sync company groups */
    INSERT INTO dbo.tblCompanyLinkCompanyGroup
    (
        CompanyID,
        CompanyGroupID
    )
    (SELECT @NewID,
            CompanyGroupID
     FROM dbo.tblCompanyLinkCompanyGroup
     WHERE CompanyID = @OldID
     EXCEPT
     SELECT CompanyID,
            CompanyGroupID
     FROM dbo.tblCompanyLinkCompanyGroup
     WHERE CompanyID = @NewID);

    /* Remove old from company groups*/
    DELETE FROM dbo.tblCompanyLinkCompanyGroup
    WHERE CompanyID = @OldID;

    /* Update Submission Routes */
    UPDATE dbo.tblSubmissionRouteConfig
    SET HealthAuthorityID = @NewID
    WHERE HealthAuthorityID = @OldID
          AND CountryID NOT IN
              (
                  SELECT CountryID
                  FROM dbo.tblSubmissionRouteConfig src
                  WHERE src.HealthAuthorityID = @NewID
                        AND src.SubmissionRouteID = SubmissionRouteID
              );

    DELETE FROM dbo.tblSubmissionRouteConfig
    WHERE HealthAuthorityID = @OldID;

	-- SNC Workstream Catalogs
	DELETE FROM pm.SNCWorkstreamCatalogLinkCountry WHERE SNCWorkstreamCatalogID IN (
	SELECT SNCWorkstreamCatalogID FROM pm.SNCWorkstreamCatalog
	WHERE SiteID = @OldID
	AND SNCWorkstreamID IN (SELECT SNCWorkstreamID FROM pm.SNCWorkstreamCatalog cat WHERE cat.SiteID = @NewID
	AND cat.ValidSNCSiteTypeID = pm.SNCWorkstreamCatalog.ValidSNCSiteTypeID))

	DELETE FROM pm.SNCWorkstreamCatalogLinkKPI WHERE SNCWorkstreamCatalogID IN (
	SELECT SNCWorkstreamCatalogID FROM pm.SNCWorkstreamCatalog
	WHERE SiteID = @OldID
	AND SNCWorkstreamID IN (SELECT SNCWorkstreamID FROM pm.SNCWorkstreamCatalog cat WHERE cat.SiteID = @NewID
	AND cat.ValidSNCSiteTypeID = pm.SNCWorkstreamCatalog.ValidSNCSiteTypeID))

	DELETE FROM pm.SNCWorkstreamCatalog
	WHERE SiteID = @OldID
	AND SNCWorkstreamID IN (SELECT SNCWorkstreamID FROM pm.SNCWorkstreamCatalog cat WHERE cat.SiteID = @NewID
	AND cat.ValidSNCSiteTypeID = pm.SNCWorkstreamCatalog.ValidSNCSiteTypeID)

    --/* Sync tblSupplierRawMaterial */
    IF EXISTS
    (
        SELECT SupplierID
        FROM pm.RawMaterialSupplier
        WHERE SupplierID = @OldID
    )
    BEGIN
        /* Only update records that do not have the same RMID and VendorID so we don't break the unique key constraint */
        UPDATE pm.RawMaterialSupplier
        SET SupplierID = @NewID
        WHERE SupplierID = @OldID
              AND RawMaterialID NOT IN
                  (
                      SELECT RawMaterialID FROM pm.RawMaterialSupplier WHERE SupplierID = @NewID
                  )
              --AND ISNULL(VendorID, -1) NOT IN
              --    (
              --        SELECT ISNULL(VendorID, -1)
              --        FROM dbo.tblSupplierRawMaterial
              --        WHERE SupplierID = @NewID
              --    );

        DECLARE @RawMaterialSupplierID INT;

        /* Get the SupplierRMID that we will need to update tblRMRequest with*/
        SELECT @RawMaterialSupplierID = RawMaterialSupplierID
        FROM pm.RawMaterialSupplier
        WHERE SupplierID = @NewID
              AND RawMaterialID IN
                  (
                      SELECT RawMaterialID FROM pm.RawMaterialSupplier WHERE SupplierID = @OldID
                  )
              AND ISNULL(VendorID, -1) IN
                  (
                      SELECT ISNULL(VendorID, -1)
                      FROM pm.RawMaterialSupplier
                      WHERE SupplierID = @OldID
                  );

        /* Update any records in tblRMRequest so we don't break the SupplierRMID FK constraint */
        IF (@RawMaterialSupplierID IS NOT NULL)
        BEGIN
            UPDATE pm.RawMaterialOrder
            SET RawMaterialSupplierID = @RawMaterialSupplierID
            WHERE RawMaterialSupplierID IN
                  (
                      SELECT RawMaterialSupplierID
                      FROM pm.RawMaterialSupplier
                      WHERE SupplierID = @OldID
                  );

            UPDATE pm.RawMaterialSupplierSource
            SET RawMaterialSupplierID = @RawMaterialSupplierID
            WHERE RawMaterialSupplierID IN
                  (
                      SELECT RawMaterialSupplierID
                      FROM pm.RawMaterialSupplier
                      WHERE SupplierID = @OldID
                  );
        END;

        /* Get rid of any remaining records for the old company that didn't need updated */
        DELETE FROM pm.RawMaterialSupplier
        WHERE SupplierID = @OldID;
    END;

    IF OBJECT_ID('tempdb..#Temp') IS NOT NULL
    BEGIN
        DROP TABLE #Temp;
    END;

    CREATE TABLE #Temp
    (
        id INT IDENTITY(1, 1),
        SQLStmt NVARCHAR(2000)
    );

    INSERT INTO #Temp
    (
        SQLStmt
    )
    SELECT 'IF Exists (select ' + COL_NAME(fc.parent_object_id, fc.parent_column_id) + ' from  '
           + SCHEMA_NAME(f.schema_id) + '.' + OBJECT_NAME(f.parent_object_id) + ' where '
           + COL_NAME(fc.parent_object_id, fc.parent_column_id) + '  = ' + CAST(@OldID AS NVARCHAR(6)) + ')
 update '  + SCHEMA_NAME(f.schema_id) + '.' + OBJECT_NAME(f.parent_object_id) + ' set '
           + COL_NAME(fc.parent_object_id, fc.parent_column_id) + ' = ' + CAST(@NewID AS NVARCHAR(6)) + ' where '
           + COL_NAME(fc.parent_object_id, fc.parent_column_id) + ' = ' + CAST(@OldID AS NVARCHAR(6))
    FROM sys.foreign_keys AS f
        INNER JOIN sys.foreign_key_columns AS fc
            ON f.object_id = fc.constraint_object_id
        INNER JOIN sys.objects AS o
            ON o.object_id = fc.referenced_object_id
    WHERE o.object_id = OBJECT_ID('tblcompany');

    DECLARE @RID INT =
            (
                SELECT MIN(id) FROM #Temp
            );

    DECLARE @MaxRID INT =
            (
                SELECT MAX(id) FROM #Temp
            );

    DECLARE @SQL NVARCHAR(1000);

    WHILE (@RID <= @MaxRID)
    BEGIN

        SET @SQL =
        (
            SELECT SQLStmt FROM #Temp WHERE id = @RID
        );

        EXEC (@SQL);

        SET @RID += 1;
    END;

    -- remove old from company table
    DELETE FROM dbo.tblCompany
    WHERE CompanyID = @OldID;

    IF OBJECT_ID('tempdb..#Temp') IS NOT NULL
    BEGIN
        DROP TABLE #Temp;

    END;

    IF (@@ERROR = 0 AND @@TRANCOUNT = 1)
    BEGIN
        COMMIT;
        RETURN 0;
    END;
    ELSE
    BEGIN
        ROLLBACK;
        RETURN -1;
    END;
END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
GRANT EXECUTE ON  [dbo].[admin_MergeCompanies] TO [mp_db_execute]
GO
