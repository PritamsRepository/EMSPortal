SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_BDPartnersForLicenses] @UserID INT = NULL
AS
BEGIN TRY
    -- Applying our usual treatment although Mylan companies, by definition
    --  are not BD Partners...        
    DECLARE @PrimarySortPriority NVARCHAR(256) = N'Mylan, Inc.';
    DECLARE @SecondarySortPriority NVARCHAR(256) = N'Mylan : %';

    SELECT DISTINCT
           (CASE
                WHEN c.Name = @PrimarySortPriority THEN
                    0
                WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN
                    1
                ELSE
                    2
            END
           ) AS SortPriority,
           c.CompanyID,
           dbo.udf_MA_FormatCompanies(c.CompanyID) AS 'Name'
    --FROM dbo.tblMALicenseScope ls
    --    JOIN dbo.tblMALicense mal
    --        ON ls.MALicenseID = mal.MALicenseID
    --    JOIN dbo.tblMAApplication ma
    --        ON mal.MAApplicationID = ma.MAApplicationID
FROM dbo.tblMAApplication ma
        JOIN dbo.tblCompany c
            ON c.CompanyID = ma.BDPartnerID
    ORDER BY SortPriority,
             Name;
END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
GRANT EXECUTE ON  [dbo].[ddl_BDPartnersForLicenses] TO [mp_db_execute]
GO
