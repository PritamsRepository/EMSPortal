SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAPackConfigsByStrength]
@MAStrengthID int,
@PackTypeOnly bit = 0
AS 

   BEGIN TRY 
      
		IF (@PackTypeOnly = 1)
			BEGIN
				SELECT DISTINCT
					VPT.Name,
					(SELECT TOP 1 MAStrengthPackageID
					FROM [dbo].[tblMaStrengthPackage] MASP
					WHERE MASP.ValidPackagingTypeID = MSP.ValidPackagingTypeID
						AND MASP.MAStrengthID = MS.MAStrengthID ) AS ID
				FROM [dbo].[tblMAStrength] MS
				JOIN [dbo].[tblMaStrengthPackage] MSP ON MS.MAStrengthID = MSP.MAStrengthID
				JOIN [dbo].[tblValidMAPackType] VPT ON MSP.ValidPackagingTypeID = VPT.ValidMAPackTypeID
				WHERE MS.MAStrengthID = @MAStrengthID
				ORDER BY vpt.Name ASC
			END
		ELSE
			BEGIN
				SELECT VPT.Name + ' (' + MSPC.PackageSize + ')' AS Name,
					MSPC.MAStrengthPackageID AS ID
				FROM tblMaStrengthPackage MSPC
				JOIN tblValidMAPackType VPT ON MSPC.ValidPackagingTypeID = VPT.ValidMAPackTypeID
				WHERE MSPC.MAStrengthID = @MAStrengthID --and mspc.IsAllTypes = @PackTypeOnly
				ORDER BY VPT.Name ASC
			END
        
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAPackConfigsByStrength] TO [mp_db_execute]
GO
