SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_FormattedCompanies]
    @CompanyGroup NVARCHAR(256) ,
    @Format INT = NULL ,
    @CompanyID INT = NULL
AS 
    BEGIN TRY 

        IF ( @Format IS NULL
             OR @Format = 1 ) 
            BEGIN

                SELECT DISTINCT
                        c.CompanyID ,
                        ( CASE WHEN c.CountryID IS NULL THEN 0
                               ELSE 1
                          END ) SortPriority ,
                        ( c.Name + ' : ' + ISNULL(CTY.Code, '') ) AS NAME /* replace the UDF udf_FormatCompanyName */
                        
                FROM    dbo.tblCompany c
                        JOIN dbo.tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                        JOIN dbo.tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
                        LEFT JOIN dbo.tblCountry CTY ON c.CountryID = CTY.CountryID
                WHERE   ( @CompanyGroup IS NULL
                          OR cg.[Text] = @CompanyGroup )
                UNION
                SELECT DISTINCT
                        c.CompanyID ,
                        ( CASE WHEN c.CountryID IS NULL THEN 0
                               ELSE 1
                          END ) SortPriority ,
                        ( c.Name + ' : ' + ISNULL(CTY.Code, '') ) AS NAME /* replace the UDF udf_FormatCompanyName */
                       
                FROM    dbo.tblCompany c
                        JOIN dbo.tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                        JOIN dbo.tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
                        LEFT JOIN dbo.tblCountry CTY ON c.CountryID = CTY.CountryID
                WHERE   ( c.CompanyID = @CompanyID )
                ORDER BY SortPriority ,
                        Name


            END

        ELSE /* 2 passed in may need to add additional logic if we want to extend this later */ 
            BEGIN
                SELECT DISTINCT
                        c.CompanyID ,
                        ( CASE WHEN c.CountryID IS NULL THEN 0
                               ELSE 1
                          END ) SortPriority ,
                        ( ISNULL(( CTY.Code + ' : ' ), '') + c.Name + ' [' + ISNULL(c.ShortName, 'No Short Name Avail') + ']' ) AS Name
	
                FROM    dbo.tblCompany c
                        JOIN dbo.tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                        JOIN dbo.tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
                        LEFT JOIN dbo.tblCountry CTY ON c.CountryID = CTY.CountryID
                WHERE   ( @CompanyGroup IS NULL
                          OR cg.[Text] = @CompanyGroup )
                UNION
                SELECT DISTINCT
                        c.CompanyID ,
                        ( CASE WHEN c.CountryID IS NULL THEN 0
                               ELSE 1
                          END ) SortPriority ,
                        ( ISNULL(( CTY.Code + ' : ' ), '') + c.Name + ' [' + ISNULL(c.ShortName, 'No Short Name Avail') + ']' ) AS Name
	
                FROM    dbo.tblCompany c
                        JOIN dbo.tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                        JOIN dbo.tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
                        LEFT JOIN dbo.tblCountry CTY ON c.CountryID = CTY.CountryID
                WHERE   ( c.CompanyID = @CompanyID )
                ORDER BY SortPriority ,
                        Name
            END

	
    END TRY
    BEGIN CATCH
        EXECUTE [dbo].[sp_RollAndRaise]
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_FormattedCompanies] TO [mp_db_execute]
GO
