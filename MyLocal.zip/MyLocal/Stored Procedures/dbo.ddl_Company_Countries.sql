SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_Company_Countries]
AS

BEGIN TRY

SELECT DISTINCT
  co.CountryID,
  co.Name
FROM
  dbo.tblCountry co
    JOIN dbo.tblCompany c ON co.CountryID = c.CountryID
ORDER BY
  co.Name

END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_Company_Countries] TO [mp_db_execute]
GO
