SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[Attachment_GetByFilter]
    @BBOID INT = NULL,
    @ObjectID INT = NULL,
    @UserID INT,
    @ID INT = NULL,
    @PrivCode VARCHAR(64) = ''
AS 
    BEGIN
        SELECT  DISTINCT a.AttachmentID,
                a.BBOID,
                a.Comment,
                a.ConcurrencyID,
                a.Name,
                a.ObjectID,
                a.OriginalFileName,
                a.ValidFileExtID,
                a.URL,
                CAST(case when vfe.Name = 'lnk' then 1
                else 0
                END AS BIT) AS IsLink,
                a.UpdateDate,
                a.UpdateUserID,
                vfe.Name AS ValidFileExt,
                COALESCE(asu.FullName,asu.ADUserName) AS UpdateUser
        FROM    dbo.tblAttachment a
                JOIN dbo.tblValidFileExt vfe ON a.ValidFileExtID = vfe.ValidFileExtID
                LEFT JOIN dbo.admin_SecUser AS ASU ON a.UpdateUserID = asu.UserID 
        WHERE   ( @BBOID IS NULL
                  OR a.BBOID = @BBOID
                )
                AND ( @ObjectID IS NULL
                      OR a.ObjectID = @OBJECTID
                    )
                AND ( @ID IS NULL
                      OR a.AttachmentID = @ID
                    )
    END
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Attachment_GetByFilter] TO [mp_db_execute]
GO
