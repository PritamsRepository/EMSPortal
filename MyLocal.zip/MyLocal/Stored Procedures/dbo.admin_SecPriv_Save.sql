SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[admin_SecPriv_Save]
    @PrivCode NVARCHAR(20) ,
    @Name NVARCHAR(100) ,
    @Description NVARCHAR(256) ,
    @IsAudited BIT ,
    @IsCountrySpecific BIT ,
    @IsCGSpecific BIT ,
    @Object NCHAR(10) ,
    @Action NVARCHAR(50) ,
    @Num NCHAR(10) ,
    @PrivType NCHAR(10) ,
    @RowSpecific BIT ,
    @VisibleOrEnable CHAR(1) ,
    @HasPrivParam NVARCHAR(50) ,
    @IsTeamSpecific BIT ,
    @CanEditComments BIT ,
    @LongDescription NVARCHAR(800) = NULL,
    @IsActive BIT = 1,
    @ID INT OUTPUT ,
    @ConcurrencyID TIMESTAMP OUTPUT ,
    @UpdateUserID INT
AS 
    SET NOCOUNT ON 

    BEGIN TRY 	

        DECLARE @ReturnValue INT
        DECLARE @ActionType CHAR(1)
        DECLARE @RowsAffected INT
        DECLARE @ConcurIDinDB TIMESTAMP

        BEGIN TRAN
        DECLARE @PrivID INT = @ID

        IF ( @ID IS NULL ) 
            BEGIN
				INSERT  INTO [dbo].[admin_SecPriv]
                        ( [PrivCode] ,
                          [Name] ,
                          [Description] ,
                          [IsAudited] ,
                          [IsCountrySpecific] ,
                          [IsCGSpecific] ,
                          [Object] ,
                          [Action] ,
                          [Num] ,
                          [PrivType] ,
                          [RowSpecific] ,
                          [VisibleOrEnable] ,
                          [HasPrivParam] ,
                          [IsTeamSpecific] ,
                          [CanEditComments], LongDescription, IsActive )
                        SELECT  @PrivCode ,
                                @Name ,
                                @Description ,
                                @IsAudited ,
                                @IsCountrySpecific ,
                                @IsCGSpecific ,
                                @Object ,
                                @Action ,
                                @Num ,
                                @PrivType ,
                                @RowSpecific ,
                                @VisibleOrEnable ,
                                @HasPrivParam ,
                                @IsTeamSpecific ,
                                @CanEditComments,
                                @LongDescription, 
                                @IsActive
            END
        ELSE 
            BEGIN
                IF EXISTS ( SELECT  PrivId
                            FROM    dbo.admin_SecPriv
                            WHERE   PrivID = @PrivID ) 
                    BEGIN

                        UPDATE  [dbo].[admin_SecPriv]
                        SET     [PrivCode] = @PrivCode ,
                                [Name] = @Name ,
                                [Description] = @Description ,
                                [IsAudited] = @IsAudited ,
                                [IsCountrySpecific] = @IsCountrySpecific ,
                                [IsCGSpecific] = @IsCGSpecific ,
                                [Object] = @Object ,
                                [Action] = @Action ,
                                [Num] = @Num ,
                                [PrivType] = @PrivType ,
                                [RowSpecific] = @RowSpecific ,
                                [VisibleOrEnable] = @VisibleOrEnable ,
                                [HasPrivParam] = @HasPrivParam ,
                                [IsTeamSpecific] = @IsTeamSpecific ,
                                [CanEditComments] = @CanEditComments,
                                LongDescription=  @LongDescription, 
                                IsActive = @IsActive
                        WHERE   [PrivID] = @PrivID
	
                        SET @RowsAffected = @@ROWCOUNT
                        IF @RowsAffected = 0 
                            EXEC dbo.sp_RaiseCustomError 3

                        SELECT  @ReturnValue = @ID

                    END

                ELSE 
                    BEGIN
                        RAISERROR('PrivID  %d not found to edit', 16, 42, @PrivID) WITH NoWait ;

                    END
            END
        SET @ConcurrencyID = ( SELECT   [ConcurrencyID]
                               FROM     [dbo].[admin_SecPriv]
                               WHERE    [PrivID] = @ReturnValue )
        SET @ID = @ReturnValue
        COMMIT TRAN

    END TRY 

    BEGIN CATCH
        EXEC dbo.Sp_RollAndRaise 
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[admin_SecPriv_Save] TO [mp_db_execute]
GO
