SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetProductsByName]
	@Name nvarchar(256) = NULL
AS
	SELECT 
		p.ProductID AS ID, p.Name
	FROM 
		dbo.tblProduct p
	WHERE 
		(@Name IS Null OR p.Name like @Name + '%')
	ORDER BY p.Name
GO
