SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_MAApplication_ReferenceMAApplications]
(@MAApplicationID INT = NULL)
AS
BEGIN TRY
    DECLARE @ProductGroupID INT = NULL;
    IF @MAApplicationID IS NOT NULL
        SELECT @ProductGroupID = ProductGroupID
        FROM dbo.tblMAApplication
        WHERE MAApplicationID = @MAApplicationID;

    SELECT DISTINCT
           ma.MAApplicationID AS ID,
           ma.MAName + COALESCE(' : ' + p.Name, '') + COALESCE(' : ' + ma.ProcedureNumber, '')
           + COALESCE(' : ' + zc.Name, '') AS Name
    FROM dbo.tblMAApplication ma
        JOIN dbo.tblProduct p
            ON p.ProductID = ma.ProductGroupID
        JOIN(dbo.tblCompany c4
        LEFT JOIN dbo.tblCountry zc
            ON c4.CountryID = zc.CountryID)
            ON ma.HealthAuthorityID = c4.CompanyID
    WHERE (
              @MAApplicationID IS NULL
              OR EXISTS
    (
        SELECT 1
        FROM dbo.tblMAApplication
        WHERE ma.ProductGroupID = @ProductGroupID
    )
          )
    ORDER BY ma.MAApplicationID;
END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
