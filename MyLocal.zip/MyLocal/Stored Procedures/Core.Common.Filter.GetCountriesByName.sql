SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetCountriesByName]
	@Name nvarchar(256) = NULL,
	@UserID INT, @PrivCode NVARCHAR(20)
AS
	SELECT 
		c.CountryID, c.[Name], c.Code
	FROM 
		dbo.tblCountry c
		JOIN udf_UserHasPrivForCountry_TableValued(@UserID, @PrivCode) uhp ON c.CountryID = uhp.CountryID AND uhp.Privs = 1
	WHERE 
		@Name IS Null OR c.Name like @Name + '%' OR(@Name IS NOT NULL AND c.Code = @Name)
		


GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetCountriesByName] TO [mp_db_execute]
GO
