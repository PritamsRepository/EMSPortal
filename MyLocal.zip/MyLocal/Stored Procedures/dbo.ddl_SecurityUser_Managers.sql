SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE PROC [dbo].[ddl_SecurityUser_Managers]

AS 

BEGIN TRY

  SELECT ValidManagerID,
		[Name]
  FROM tblValidManager
  WHERE IsActive = 1
  ORDER BY [Name]

END TRY
BEGIN CATCH
  EXEC dbo.sp_RollAndRaise
END  CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_SecurityUser_Managers] TO [mp_db_execute]
GO
