SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ddl_BCRASessions]
AS
/*===========================================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS CONSULTANT
CREATED ON:				DEC 31, 2009		
MODIFIED BY:				
MODIFIED ON:	
PURPOSE:					The purpose of this procedure is to get all of the names of all of the users with a security role.
-----------------------------------------------------------------------------------------------------------------------
EXAMPLE:					EXECUTE ddl_BCRASessions
===========================================================================================*/

BEGIN TRY

		SELECT DISTINCT 
			bcra.Name as BCRASession,
			bcra.BCRASessionID
		FROM
			tblBCRASession bcra
		ORDER BY
			Name
END TRY

BEGIN CATCH
	EXEC sp_RollAndRaise
END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_BCRASessions] TO [mp_db_execute]
GO
