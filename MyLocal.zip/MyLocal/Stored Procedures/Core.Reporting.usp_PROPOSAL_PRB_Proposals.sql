SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_PROPOSAL_PRB_Proposals]
    @UserID INT = NULL ,
    @PrivCode NVARCHAR(10) = NULL ,
    @TargetPRBSessionID INT = NULL ,
    @ProposalID INT = NULL ,
    @FormName NVARCHAR(256) = NULL ,
    @CountryGroupID INT = NULL ,
    @ValidProposalStatusID INT = NULL ,
    @ValidPRBDecisionID INT = NULL ,
    @ValidMakeBuyID INT = NULL ,
    @ShowNonCandidatesOnly BIT = 0 ,
    @MarketResponseIDs NVARCHAR(100)
AS
    SET NOCOUNT ON

    BEGIN TRY;

        IF ( @ProposalID IS NOT NULL )
            BEGIN
                SELECT  NULL AS TargetPRBSessionID ,
                        @ProposalID AS ProposalID;
            END		
        ELSE
            BEGIN
                DECLARE @MarketResponseIDsTbl AS ValidResponseType;
                INSERT  INTO @MarketResponseIDsTbl
                        SELECT  id
                        FROM    dbo.udf_GetValuesFromCSV(@MarketResponseIDs)
    
                IF ( @ValidProposalStatusID = -1 ) /* old export -1 value bbs.StateName NOT IN ( 'Complete', 'On Hold','Cancelled' ) */
                    BEGIN
					
                        SELECT  can.TargetPRBSessionID ,
                                p.ProductProposalID AS ProposalID
                        FROM    pm.ProductProposal AS p
                                JOIN dbo.tblForm AS f ON p.FormID = f.FormID
                                JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = p.CountryGroupID
                                JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,
                                                              @PrivCode) AS a ON a.CountryGroupID = cg.[CountryGroupID]
                                                              AND a.Privs = 1
                                JOIN dbo.tblBusinessBaseStates AS bbs ON p.StatusID = bbs.StateID
                                                              AND [bbs].[StateName] NOT IN (
                                                              'Complete',
                                                              'On Hold',
                                                              'Cancelled' )
                                LEFT OUTER JOIN pm.Candidate AS can ON p.CandidateID = can.CandidateID
                                LEFT OUTER JOIN pm.PRBSession AS prb ON can.TargetPRBSessionID = prb.PRBSessionID
                                LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
                        WHERE   ( @FormName IS NULL
                                  OR f.Name LIKE @FormName
                                )
                                AND ( @CountryGroupID IS NULL
                                      OR @CountryGroupID = cg.CountryGroupID
                                    )
                                AND ( @MarketResponseIDs IS NULL
                                      OR p.ValidResponseID IN (
                                      SELECT    ValidResponseID
                                      FROM      @MarketResponseIDsTbl )
                                    )
                                AND ( @TargetPRBSessionID IS NULL
                                      OR @TargetPRBSessionID = can.TargetPRBSessionID
                                    )
                                AND ( @ValidPRBDecisionID IS NULL
                                      OR @ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                    )
                                AND ( @ShowNonCandidatesOnly = 0
                                      OR p.CandidateID IS NULL
                                    )
                                AND ( @ValidMakeBuyID IS NULL
                                      OR @ValidMakeBuyID = p.ValidMakeBuyID
                                    )
                        ORDER BY p.ProductProposalID ,
                                p.Name

                    END
	                            
                ELSE
                    IF ( @ValidProposalStatusID = -2 ) /* old -2 bbs.StateName IN ( 'Complete', 'On Hold','Cancelled' ) */
                        BEGIN
                            SELECT  can.TargetPRBSessionID ,
                                    p.ProductProposalID AS ProposalID
                            FROM    pm.ProductProposal AS p
                                    JOIN dbo.tblForm AS f ON p.FormID = f.FormID
                                    JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = p.CountryGroupID
                                    JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,
                                                              @PrivCode) AS a ON a.CountryGroupID = cg.[CountryGroupID]
                                                              AND a.Privs = 1
                                    JOIN dbo.tblBusinessBaseStates AS bbs ON p.StatusID = bbs.StateID
                                                              AND [bbs].[StateName] IN (
                                                              'Complete',
                                                              'On Hold',
                                                              'Cancelled' )
                                    LEFT OUTER JOIN pm.Candidate AS can ON p.CandidateID = can.CandidateID
                                    LEFT OUTER JOIN pm.PRBSession AS prb ON can.TargetPRBSessionID = prb.PRBSessionID
                                    LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
                            WHERE   ( @FormName IS NULL
                                      OR f.Name LIKE @FormName
                                    )
                                    AND ( @CountryGroupID IS NULL
                                          OR @CountryGroupID = cg.CountryGroupID
                                        )
                                    AND ( @MarketResponseIDs IS NULL
                                          OR p.ValidResponseID IN (
                                          SELECT    ValidResponseID
                                          FROM      @MarketResponseIDsTbl )
                                        )
                                    AND ( @TargetPRBSessionID IS NULL
                                          OR @TargetPRBSessionID = can.TargetPRBSessionID
                                        )
                                    AND ( @ValidPRBDecisionID IS NULL
                                          OR @ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                        )
                                    AND ( @ShowNonCandidatesOnly = 0
                                          OR p.CandidateID IS NULL
                                        )
                                    AND ( @ValidMakeBuyID IS NULL
                                          OR @ValidMakeBuyID = p.ValidMakeBuyID
                                        )
                            ORDER BY p.ProductProposalID ,
                                    p.Name
                        END
	                    
				/* filter on ValidProposalStatus  */
                    ELSE
                        IF ( @ValidProposalStatusID > 0 ) /* new filter / export when status is positive value  */
                            BEGIN
                                SELECT  can.TargetPRBSessionID ,
                                        p.ProductProposalID AS ProposalID
                                FROM    pm.ProductProposal p
                                        JOIN dbo.tblForm f ON p.FormID = f.FormID
                                        JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = p.CountryGroupID
                                        JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,
                                                              @PrivCode) AS a ON a.CountryGroupID = cg.[CountryGroupID]
                                                              AND a.Privs = 1
                                        JOIN dbo.tblBusinessBaseStates AS bbs ON p.StatusID = bbs.StateID
                                        LEFT OUTER JOIN pm.Candidate AS can ON p.CandidateID = can.CandidateID
                                        LEFT OUTER JOIN pm.PRBSession AS prb ON can.TargetPRBSessionID = prb.PRBSessionID
                                        LEFT OUTER JOIN dbo.tblValidPRBDecision
                                        AS prbd ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                WHERE   ( @FormName IS NULL
                                          OR f.Name LIKE @FormName
                                        )
                                        AND ( @CountryGroupID IS NULL
                                              OR @CountryGroupID = cg.CountryGroupID
                                            )
                                        AND ( @MarketResponseIDs IS NULL
                                              OR p.ValidResponseID IN (
                                              SELECT    ValidResponseID
                                              FROM      @MarketResponseIDsTbl )
                                            )
                                        AND ( @TargetPRBSessionID IS NULL
                                              OR @TargetPRBSessionID = can.TargetPRBSessionID
                                            )
                                        AND ( @ValidPRBDecisionID IS NULL
                                              OR @ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                            )
                                        AND ( @ShowNonCandidatesOnly = 0
                                              OR p.CandidateID IS NULL
                                            )
                                        AND ( @ValidMakeBuyID IS NULL
                                              OR @ValidMakeBuyID = p.ValidMakeBuyID
                                            )
                                        AND ( p.StatusID = @ValidProposalStatusID )
                                ORDER BY p.ProductProposalID ,
                                        p.Name
	                                
                            END
	                
                        ELSE 
						 /* Old @ValidProposalStatusID NOT IN ( -1, -2 ) OR @ValidProposalStatusID IS NULL*/
                            BEGIN
	            						
                                SELECT  can.TargetPRBSessionID ,
                                        p.ProductProposalID AS ProposalID
                                FROM    pm.ProductProposal AS p
                                        JOIN dbo.tblForm AS f ON p.FormID = f.FormID
                                        JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = p.CountryGroupID
                                        JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,
                                                              @PrivCode) AS a ON a.CountryGroupID = cg.[CountryGroupID]
                                                              AND a.Privs = 1
                                        JOIN dbo.tblBusinessBaseStates AS bbs ON p.StatusID = bbs.StateID
                                        LEFT OUTER JOIN pm.Candidate AS can ON p.CandidateID = can.CandidateID
                                        LEFT OUTER JOIN pm.PRBSession AS prb ON can.TargetPRBSessionID = prb.PRBSessionID
                                        LEFT OUTER JOIN dbo.tblValidPRBDecision
                                        AS prbd ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                WHERE   ( @FormName IS NULL
                                          OR f.Name LIKE @FormName
                                        )
                                        AND ( @CountryGroupID IS NULL
                                              OR @CountryGroupID = cg.CountryGroupID
                                            )
                                        AND ( @MarketResponseIDs IS NULL
                                              OR p.ValidResponseID IN (
                                              SELECT    ValidResponseID
                                              FROM      @MarketResponseIDsTbl )
                                            )
                                        AND ( @TargetPRBSessionID IS NULL
                                              OR @TargetPRBSessionID = can.TargetPRBSessionID
                                            )
                                        AND ( @ValidPRBDecisionID IS NULL
                                              OR @ValidPRBDecisionID = prbd.ValidPRBDecisionID
                                            )
                                        AND ( @ShowNonCandidatesOnly = 0
                                              OR p.CandidateID IS NULL
                                            )
                                        AND ( @ValidMakeBuyID IS NULL
                                              OR @ValidMakeBuyID = p.ValidMakeBuyID
                                            )
                                ORDER BY p.ProductProposalID ,
                                        p.Name
                            END
            END
    END TRY
    BEGIN CATCH
        EXECUTE sp_RollAndRaise;
    END CATCH
GO
