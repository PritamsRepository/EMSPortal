SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[LaunchWorkstreamStrengthInfo_APIInfo]
    (
      @LaunchWorkstreamStrengthInfoID INT
    )
AS -- (kg/batch) @ Cost [Qty] [Status]
    SELECT  STUFF(( SELECT DISTINCT ', ' + vki.Name + COALESCE(' ' + vs.Name, '')
                            + COALESCE(' '
                                       + CAST(lwsapi.Requirement AS NVARCHAR),
                                       '') + COALESCE(' @ '
                                                      + CAST(scapi.Cost AS NVARCHAR),
                                                      '') + COALESCE(' ['
                                                              + CAST(scapi.MinimumOrderQuantity AS NVARCHAR)
                                                              + ']', '')
                            + COALESCE(' [' + vapids.Name + ']', ' [TBD]')
                    FROM    pm.SupplyChainAPI scapi
                            JOIN pm.SupplyChain sc ON sc.SupplyChainID = scapi.SupplyChainID
                            JOIN pm.LaunchWorkstreamLinkSupplyChain lwlsc ON lwlsc.SupplyChainID = sc.SupplyChainID
                            JOIN pm.LaunchWorkstreamStrengthInfo lws ON lws.LaunchWorkstreamID = lwlsc.LaunchWorkstreamID
                            LEFT JOIN pm.LaunchWorkstreamStrengthAPI lwsapi ON lwsapi.KPIID = scapi.KPIID
                                                              AND lwsapi.StrengthID = lws.StrengthID
                                                              AND lwsapi.LaunchWorkstreamID = lws.LaunchWorkstreamID
                            JOIN tblKPI kpi ON kpi.KPIID = scapi.KPIID
                            JOIN dbo.tblValidKeyIngredient vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            JOIN dbo.tblValidSupplyChainSitePurpose vscsp ON vscsp.ValidSupplyChainSitePurposeID = scapi.ValidSupplyChainSitePurposeID
                            LEFT JOIN tblValidSalt vs ON vs.ValidSaltID = kpi.ValidSaltID
                            LEFT JOIN tblValidAPIDeliveryStatus vapids ON vapids.APIDeliveryStatusID = scapi.ValidAPIDeliveryStatusID
                    WHERE   lws.LaunchWorkstreamStrengthInfoID = @LaunchWorkstreamStrengthInfoID
                            AND vscsp.Name = 'Primary'
                    ORDER BY ', ' + vki.Name + COALESCE(' ' + vs.Name, '')
                            + COALESCE(' '
                                       + CAST(lwsapi.Requirement AS NVARCHAR),
                                       '') + COALESCE(' @ '
                                                      + CAST(scapi.Cost AS NVARCHAR),
                                                      '') + COALESCE(' ['
                                                              + CAST(scapi.MinimumOrderQuantity AS NVARCHAR)
                                                              + ']', '')
                            + COALESCE(' [' + vapids.Name + ']', ' [TBD]')
                  FOR
                    XML PATH('')
                  ), 1, 2, '')
GO
