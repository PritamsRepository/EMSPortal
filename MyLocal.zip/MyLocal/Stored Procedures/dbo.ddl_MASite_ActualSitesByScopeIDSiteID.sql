SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MASite_ActualSitesByScopeIDSiteID]
    @MALicenseScopeID INT
AS 
    BEGIN TRY 
            SELECT DISTINCT
                RS.MASiteID AS MASiteID ,
                ST.Category + ' : ' + c.Name AS [Name]
            FROM dbo.tblMARegisteredSite RS
            JOIN dbo.tblMASite S ON RS.MASiteID = S.MASiteID
            JOIN dbo.tblValidSiteType ST ON S.ValidSiteTypeID = ST.ValidSiteTypeID
            JOIN dbo.tblCompany C ON S.CompanyID = C.CompanyID
            WHERE RS.MALicenseScopeID = @MALicenseScopeID AND RS.IsUsed = 0
	
    END TRY
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MASite_ActualSitesByScopeIDSiteID] TO [mp_db_execute]
GO
