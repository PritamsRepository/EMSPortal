SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MASubmission_HealthAuthority]
(
    @CompanyID INT = NULL,
    @ExcludedCompanyID INT = NULL,
    @SubmissionRouteID INT = NULL,
    @MAApplicationID INT = NULL, --Not currently used, but please do not remove.
    @UserID INT
)
AS
BEGIN TRY
    DECLARE @Privcode NVARCHAR(10);

    SET @Privcode = N'MA03'; /* MA Add priv*/
    SELECT DISTINCT
           c.CompanyID,
           (CASE
                WHEN cty.Code IS NULL THEN
                    ISNULL(c.ShortName, 'N/A')
                ELSE
                    cty.Code
            END + ': ' + c.Name
           ) AS Name
    FROM dbo.tblSubmissionRouteConfig src
        JOIN dbo.tblCompany c
            ON src.HealthAuthorityID = c.CompanyID
        JOIN dbo.tblCompanyLinkCompanyGroup clcg
            ON c.CompanyID = clcg.CompanyID
        JOIN dbo.tblCompanyGroup cg
            ON clcg.CompanyGroupID = cg.CompanyGroupID
               AND cg.[Text] = 'Health Authority'
        JOIN dbo.tblCompanyLinkCountry CLC
            ON c.CompanyID = CLC.CompanyID
        JOIN dbo.tblCountryLinkCountryGroup CTYLCG
            ON CLC.CountryID = CTYLCG.CountryID
        JOIN dbo.tblCountryGroup CCG
            ON CTYLCG.CountryGroupID = CCG.CountryGroupID
               AND CCG.CountryGroupType = 'MAMkt'
        LEFT JOIN dbo.tblCountry cty
            ON c.CountryID = cty.CountryID
    WHERE dbo.udf_UserHasPrivForCountryGroup(@UserID, @Privcode, CCG.CountryGroupID) = 1
          AND src.SubmissionRouteID = @SubmissionRouteID
          AND
          (
              @ExcludedCompanyID IS NULL
              OR c.CompanyID <> @ExcludedCompanyID
          )
    ORDER BY Name;
END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
