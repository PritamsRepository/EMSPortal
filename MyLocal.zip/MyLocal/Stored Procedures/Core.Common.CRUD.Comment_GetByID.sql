SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[Comment_GetByID] @CommentID INT
AS
    SELECT  c.CommentID,
			c.BBOID,
			c.Category,
			c.Comment,
			c.CommentDate, 
			c.ConcurrencyID,
			c.ObjectID,
			c.UserID			
    FROM   dbo.tblComment c
    LEFT JOIN dbo.admin_SecUser su on c.UserID = su.UserID
    WHERE  c.CommentID = @CommentID
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Comment_GetByID] TO [mp_db_execute]
GO
