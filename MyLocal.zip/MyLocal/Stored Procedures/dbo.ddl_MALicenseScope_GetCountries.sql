SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicenseScope_GetCountries]
@MAPPID INT
AS
BEGIN TRY 

/* retreive a list of countries for a group of license scopes associated with a MA Application */

SELECT DISTINCT MLS.CountryID AS ID, C.Name
FROM dbo.tblMALicenseScope MLS
JOIN dbo.tblMALicense ML ON MLS.MALicenseID = ML.MALicenseID
JOIN dbo.tblMAApplication MA ON ML.MAApplicationID = MA.MAApplicationID
JOIN dbo.tblCountry C ON MLS.CountryID = C.CountryID
WHERE MA.MAApplicationID=@MAPPID
ORDER BY c.Name

	
END TRY 
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicenseScope_GetCountries] TO [mp_db_execute]
GO
