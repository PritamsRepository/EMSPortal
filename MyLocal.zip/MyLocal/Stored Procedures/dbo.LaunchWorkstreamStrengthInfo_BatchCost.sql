SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[LaunchWorkstreamStrengthInfo_BatchCost]
    (
      @LaunchWorkstreamStrengthInfoID INT
    )
AS
    SELECT  SUM(lwsapi.Requirement * scapi.Cost) / 1000000
    FROM    pm.SupplyChainAPI scapi
            JOIN pm.SupplyChain sc ON sc.SupplyChainID = scapi.SupplyChainID
            JOIN pm.LaunchWorkstreamLinkSupplyChain lwlsc ON lwlsc.SupplyChainID = sc.SupplyChainID
            JOIN pm.LaunchWorkstreamStrengthInfo lws ON lws.LaunchWorkstreamID = lwlsc.LaunchWorkstreamID
            JOIN pm.LaunchWorkstreamStrengthAPI lwsapi ON lwsapi.KPIID = scapi.KPIID
                                                          AND lwsapi.StrengthID = lws.StrengthID
                                                          AND lwsapi.LaunchWorkstreamID = lws.LaunchWorkstreamID
            JOIN dbo.tblValidSupplyChainSitePurpose vscsp ON vscsp.ValidSupplyChainSitePurposeID = scapi.ValidSupplyChainSitePurposeID
    WHERE   lws.LaunchWorkstreamStrengthInfoID = @LaunchWorkstreamStrengthInfoID
            AND lwsapi.Requirement IS NOT NULL
            AND scapi.Cost IS NOT NULL
            AND vscsp.Name = 'Primary'
GO
