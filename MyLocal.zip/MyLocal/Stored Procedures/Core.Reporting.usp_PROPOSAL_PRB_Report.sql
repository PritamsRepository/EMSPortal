SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_PROPOSAL_PRB_Report]
    @UserID INT = NULL ,
    @PrivCode NVARCHAR(10) = NULL ,
    @ProposalID INT
AS
    SET NOCOUNT ON
    BEGIN TRY
        SELECT  p.ShortName AS ProposalNumber ,
                f.Name AS FormName ,
                prb.Name AS PRBSessionName ,
                cg.Name AS Market ,
                ISNULL(dbo.udf_EHSAlert(f.ProductID, NULL), '[None]') AS EHSAlert ,
                ISNULL(dbo.udf_GetMPBClassifications(f.ProductID), '[None]') AS OEBClassifications ,
                ISNULL(dbo.udf_GetDrugClassifications(f.ProductID), '[None]') AS DrugClassifications ,
                ISNULL(dbo.udf_InnovatorBrandListForIPPRBByProposalID(p.CountryGroupID,
                                                              @ProposalID),
                       '[None]') AS MarketedNames ,
                vf.Name AS DosageForm
        FROM    pm.ProductProposal p
                JOIN dbo.tblForm f ON p.FormID = f.FormID
                JOIN dbo.tblCountryGroup AS cg ON cg.CountryGroupID = p.CountryGroupID
                JOIN dbo.tblValidForm vf ON f.ValidFormID = vf.ValidFormID
                LEFT JOIN pm.Candidate AS c ON p.CandidateID = c.CandidateID
                LEFT JOIN pm.PRBSession AS prb ON c.TargetPRBSessionID = prb.PRBSessionID
        WHERE   p.ProductProposalID = @ProposalID
                AND [dbo].[udf_UserHasPrivForCountryGroup](@UserID, @PrivCode,
                                                           cg.CountryGroupID) = 'true';	

    END TRY
    BEGIN CATCH
        EXECUTE dbo.sp_RollAndRaise
    END CATCH
GO
