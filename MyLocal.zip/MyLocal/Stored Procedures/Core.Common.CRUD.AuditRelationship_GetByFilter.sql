SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [Core.Common.CRUD].[AuditRelationship_GetByFilter]
	@ChangeTrackingRelationshipID BIGINT = NULL,
    @ParentBBOID INT = NULL,
    @ParentObjectID INT = NULL,
    @ChangeTrackingID INT = NULL
AS 
    BEGIN
        SELECT  c.ChangeTrackingRelationshipID,
				c.ParentBBOID,
				c.ParentObjectID,
				c.ChangeTrackingID
        FROM    dbo.admin_ChangeTrackingRelationships_Audit c
        WHERE   ( @ChangeTrackingRelationshipID IS NULL
                  OR c.ChangeTrackingRelationshipID = @ChangeTrackingRelationshipID
                )
                AND ( @ParentBBOID IS NULL
                      OR c.ParentBBOID = @ParentBBOID
                    )
                AND ( @ParentObjectID IS NULL
						OR c.ParentObjectID = @ParentObjectID
					)
				AND ( @ChangeTrackingID IS NULL
						OR c.ChangeTrackingID = @ChangeTrackingID
                    )                
    END

GO
