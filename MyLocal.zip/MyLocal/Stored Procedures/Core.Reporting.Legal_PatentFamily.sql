SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[Legal_PatentFamily]
    @PatentFamilyID INT = NULL,
    @PatentID INT = NULL,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN
    DECLARE @Result BIT;

    EXEC dbo.admin_UserHasPrivs @UserID = @UserID,
                                @PrivCodes = @PrivCode,
                                @Result = @Result OUTPUT;

    IF (@Result = 0)
        RETURN 0;

    IF (@PatentFamilyID IS NULL)
    BEGIN

        SET @PatentFamilyID =
        (
            SELECT PatentFamilyID FROM pm.Patent WHERE PatentID = @PatentID
        );

    END;

    SELECT p.PatentID,
           pf.Name AS PatentFamily,
           c.Code AS Country,
           ISNULL(p.PatentNum, 'N/A') AS PatentNumber,
           STUFF(
           (
               SELECT ', ' + vpt.Name
               FROM pm.PatentLinkValidPatentType lvpt
                   JOIN dbo.tblValidPatentType vpt ON vpt.ValidPatentTypeID = lvpt.ValidPatentTypeID
               WHERE lvpt.PatentID = p.PatentID
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentType,
		   STUFF(
           (
               SELECT ', ' + vpt.Name
               FROM pm.PatentLinkValidExpiryRationale lvpt
                   JOIN dbo.tblValidExpiryRationale vpt ON vpt.ValidExpiryRationaleID = lvpt.ValidExpiryRationaleID
               WHERE lvpt.PatentID = p.PatentID
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS RecentRationales,
		   --vpt.Name AS PatentType,
           --STUFF(
           --(
           --    SELECT ', ' + xver.Name
           --    FROM pm.PatentExpiryLinkValidExpiryRationale xpelr
           --        JOIN dbo.tblValidExpiryRationale xver
           --            ON xpelr.ValidExpiryRationaleID = xver.ValidExpiryRationaleID
           --    WHERE xpelr.PatentExpiryID =
           --    (
           --        SELECT TOP(1)
           --               PatentExpiryID
           --        FROM pm.PatentExpiry xpe
           --        WHERE xpe.PatentID = p.PatentID
           --        ORDER BY xpe.ExpiryDate DESC
           --    )
           --    FOR XML PATH('')
           --),
           --1,
           --2,
           --''
           --     ) AS RecentRationales,
           p.ExpiryDate AS RecentExpiryDate,
           --(
           --    SELECT TOP(1)
           --           ExpiryDate
           --    FROM pm.PatentExpiry xpe
           --    WHERE xpe.PatentID = p.PatentID
           --    ORDER BY xpe.ExpiryDate DESC
           --) AS RecentExpiryDate,
           (
               SELECT TOP (1)
                      AsOfDate
               FROM pm.PatentStatus xps
               WHERE xps.PatentID = p.PatentID
               ORDER BY xps.AsOfDate DESC
           ) AS RecentAsOfDate,
           STUFF(
           (
               SELECT ', ' + xgs.Name
               FROM pm.PatentStatusLinkValidGrantedStatus xpslgs
                   JOIN dbo.tblValidGrantedStatus xgs
                       ON xpslgs.ValidGrantedStatusID = xgs.ValidGrantedStatusID
                   JOIN pm.PatentStatus xps
                       ON xpslgs.PatentStatusID = xps.PatentStatusID
               WHERE xps.PatentStatusID =
               (
                   SELECT TOP (1)
                          xps.PatentStatusID
                   FROM pm.PatentStatus xps
                   WHERE xps.PatentID = p.PatentID
                   ORDER BY xps.AsOfDate DESC
               )
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS RecentStatuses
    FROM pm.PatentFamily pf
        JOIN pm.Patent p
            ON pf.PatentFamilyID = p.PatentFamilyID
        JOIN dbo.tblCountry c
            ON p.CountryID = c.CountryID
    WHERE pf.PatentFamilyID = @PatentFamilyID
          AND dbo.udf_UserHasPrivForCountry(@UserID, @PrivCode, c.CountryID) = 1
    ORDER BY c.Code;

END;
GO
