SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetStrengthsByProductID] ( @ProductID INT )
AS 
    BEGIN
        SELECT  s.StrengthID AS ID,
                f.Name + ' - ' + s.Name AS Name
        FROM    dbo.tblStrength s
                JOIN tblForm f ON s.FormID = f.FormID
        WHERE   f.ProductID = @ProductID
                AND s.IsUndefined = 0
    END
    

GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetStrengthsByProductID] TO [mp_db_execute]
GO
