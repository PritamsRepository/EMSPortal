SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_SubmissionRouteConfig_HealthAuthorities]
  @SubmissionRouteID INT,
  @UserID INT
  
AS 
BEGIN TRY

  SELECT
	0 AS ID,
	'[None]' AS Name
	
  UNION	

  SELECT DISTINCT
	c.CompanyID AS ID,
	(CASE WHEN cty.Code IS NULL THEN ISNULL(c.ShortName, 'N/A') ELSE cty.Code END  + ': ' + c.Name) AS Name
  FROM
	dbo.tblSubmissionRouteConfig src
	  JOIN dbo.tblCompany c ON src.HealthAuthorityID = c.CompanyID
	  LEFT JOIN dbo.tblCountry cty ON c.CountryID = cty.CountryID
	  JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
	  JOIN tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID AND cg.[Text] = 'Health Authority'
	  JOIN dbo.tblCountryLinkCountryGroup ctylcg ON src.CountryID = ctylcg.CountryID
	  JOIN dbo.tblCountryGroup ctyg ON ctylcg.CountryGroupID = ctyg.CountryGroupID 
		AND ctyg.CountryGroupType = 'MAMkt'
  WHERE
	dbo.udf_UserHasPrivForCountry(@UserID, 'MA03' , src.CountryID) = 1
	AND src.SubmissionRouteID = @SubmissionRouteID
  ORDER BY
	Name
            
END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_SubmissionRouteConfig_HealthAuthorities] TO [mp_db_execute]
GO
