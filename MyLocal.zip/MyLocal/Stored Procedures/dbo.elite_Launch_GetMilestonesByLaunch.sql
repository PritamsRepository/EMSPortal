SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[elite_Launch_GetMilestonesByLaunch]
		@LaunchID INT,
		@UserID INT = 3,
		@PrivCode NVARCHAR(20) = 'LNCH01'
AS
BEGIN TRY
	
	DECLARE @BBOCode NVARCHAR(32) = 'LNCH'
	
	SELECT    
		m.MilestoneID AS "id",
		COALESCE (refm.ActualDate, m.ActualDate) AS "actualDate",
		COALESCE (refm.TargetDate, m.TargetDate) AS "targetDate",
		COALESCE (refm.BestEstimateDate, m.BestEstimateDate) AS "bestEstimateDate",
		COALESCE (rvs.Name, vms.Name) AS "status",
		COALESCE (refm.InitialTargetDate, m.InitialTargetDate) AS "initialTargetDate",
		COALESCE (rvs.ValidMilestoneStatusID, vms.ValidMilestoneStatusID) AS "state",
		gm.Code AS "code",
		gm.Name AS "name",
		gm.isSystem AS "isSystem",
		gm.systemcode AS "systemcode"
	FROM
		dbo.tblGlobalMilestone gm
		JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
		LEFT JOIN ( dbo.tblMilestone m
															JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
															JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
														) ON m.ObjectID = @LaunchID AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
        LEFT JOIN dbo.tblMilestone refm on m.ReferenceMilestoneID = refm.MileStoneID
        LEFT JOIN dbo.tblValidMilestoneStatus rvs on rvs.ValidMilestoneStatusID = refm.StatusID
	WHERE     
		bbo.BBOCode = @BBOCode AND gm.Level = 1
		AND gm.Code IN ('Launch', 'Submission', 'SW - Reg Proc Close')
	ORDER BY mti.DisplayOrder, LEN(gm.code), gm.code ASC
											
	END TRY

	BEGIN CATCH
			EXEC dbo.SP_ROLLANDRAISE
	END CATCH
		
		


GO
GRANT EXECUTE ON  [dbo].[elite_Launch_GetMilestonesByLaunch] TO [mp_db_execute]
GO
