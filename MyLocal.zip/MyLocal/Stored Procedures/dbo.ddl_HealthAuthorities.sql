SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_HealthAuthorities]
AS
BEGIN TRY

    SELECT DISTINCT
           c.CompanyID AS ID,
           (CASE
                WHEN c.CountryID IS NULL THEN
                    0
                ELSE
                    1
            END
           ) AS SortPriority,
           (ISNULL((cty.Code + ' : '), '') + c.Name + ' [' + ISNULL(c.ShortName, 'No Short Name Avail') + ']') AS Name
    FROM dbo.tblCompany c
        JOIN dbo.tblCompanyLinkCompanyGroup clcg
            ON c.CompanyID = clcg.CompanyID
        JOIN dbo.tblCompanyGroup cg
            ON clcg.CompanyGroupID = cg.CompanyGroupID
        LEFT JOIN dbo.tblCountry cty
            ON c.CountryID = cty.CountryID
    WHERE cg.[Text] = 'Health Authority'
    ORDER BY SortPriority,
             Name;
END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
