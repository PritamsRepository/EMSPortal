SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_SecurityUserCleanup]
	@StartDate DATETIME = NULL,
	@UserID int,
	@PrivCode nvarchar(10)
AS
	DECLARE @MaxDate DATETIME
	
	SET @StartDate = CONVERT(DATETIME,(CONVERT(VARCHAR,ISNULL(@StartDate,GetDate()), 101)))
	
	SET @MaxDate = DATEADD(d,-180,@StartDate)
	
	SELECT	su.UserID,
			su.ADUserName,
			su.FullName,
			su.EmailAddress,
			su.Active,
			su.Phone,
			su.JobTitle,
			su.Location,
			su.Department,
			su.CountryID,
			su.UpdateDate,
			mgr.[Name] as DirectManager,
			adt.LastLogin,
			su.Requests
	FROM dbo.admin_SecUser AS su
	LEFT JOIN [dbo].[tblValidManager] AS mgr
		on su.DirectManagerID = mgr.ValidManagerID
	JOIN (SELECT UserID, 
			'LastLogin' = MAX(ISNULL(LogDate, '1/1/1900')) 
			FROM dbo.admin_AuditTrail
			WHERE ATEventID = 1 
			GROUP BY UserID) AS adt
		on su.UserID = adt.UserID 
	WHERE adt.LastLogin < @MaxDate 
	AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
	
	UNION
	
	SELECT	su.UserID,
			su.ADUserName,
			su.FullName,
			su.EmailAddress,
			su.Active,
			su.Phone,
			su.JobTitle,
			su.Location,
			su.Department,
			su.CountryID,
			su.UpdateDate,
			mgr.FullName as DirectManager,
			adt.LastLogin,
			su.Requests
	FROM dbo.admin_SecUser AS su
	LEFT JOIN [dbo].[admin_SecUser] AS mgr
		on su.DirectManagerID = mgr.UserID
	JOIN dbo.admin_secUser_audit as aud
		on su.UserID = aud.UserID
			and aud.AuditAction = 'I'
	LEFT JOIN (SELECT UserID, 
			'LastLogin' = MAX(ISNULL(LogDate, '1/1/1900')) 
			FROM dbo.admin_AuditTrail
			WHERE ATEventID = 1
			GROUP BY UserID) AS adt
		on su.UserID = adt.UserID 
	WHERE ISNULL(adt.LastLogin, '1/1/1900') ='1/1/1900' 
		AND aud.AuditDate < @MaxDate 
	AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1



GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_SecurityUserCleanup] TO [mp_db_execute]
GO
