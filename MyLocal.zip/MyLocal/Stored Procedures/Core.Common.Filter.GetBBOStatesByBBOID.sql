SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetBBOStatesByBBOID] @BBOID INT
AS
    SELECT  bbs.StateID AS [ID], bbs.StateName AS [Name]
    FROM   dbo.tblBusinessBaseStateControl bbsc
    JOIN   dbo.tblBusinessBaseStates bbs ON bbsc.StateControlID = bbs.StateControlID
    WHERE  bbsc.BBOID = @BBOID
    ORDER BY bbs.[Order]
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetBBOStatesByBBOID] TO [mp_db_execute]
GO
