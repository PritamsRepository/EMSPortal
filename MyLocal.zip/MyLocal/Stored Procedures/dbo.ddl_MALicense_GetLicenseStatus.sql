SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicense_GetLicenseStatus]
  @UserID INT = NULL

AS 
    BEGIN TRY
    /* Display license status for drop which have records in the table maLicense */
    
        SELECT DISTINCT
                VL.ValidLicenseStatusID AS ID ,
                VL.NAME
        FROM    dbo.tblValidLicenseStatus VL
                JOIN dbo.tblMALicense L ON VL.ValidLicenseStatusID = L.ValidLicenseStatusID
                JOIN dbo.tblMAApplication MAA ON L.MAApplicationID = MAA.MAApplicationID
    WHERE IsActive = 1            
    END TRY 
    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicense_GetLicenseStatus] TO [mp_db_execute]
GO
