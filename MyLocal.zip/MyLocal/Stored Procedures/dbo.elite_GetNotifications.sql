SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[elite_GetNotifications]
		@Filter NVARCHAR(1000) = NULL,
		@UserID INT = 3,
		@PrivCode NVARCHAR(20) = 'LNCH01'
AS /* */
---------------------------------------------------------------------------------------------------------------------------
-- Date 10-Deb-2012 | CLD | Create  | Added for new dashboard.
-- Example: EXEC	@return_value = [dbo].[elite_Launch_GetNotifications]
-- Filter is for furture expansion, can be used to limit results to relevant dashboards.
---------------------------------------------------------------------------------------------------------------------------

		BEGIN TRY
		
		--DECLARE @filterDoc INT
		--EXEC sp_xml_preparedocument @filterDoc OUTPUT, @Filter
	
		DECLARE @BBOID INT, @BBOCode NVARCHAR(32) = 'LNCH', @LaunchMilestone NVARCHAR(64) = 'Launch', @SubMilestone NVARCHAR(64) = 'Submission', @TechMilestone NVARCHAR(64) = 'SW - Reg Proc Close'
		SELECT @BBOID = BBOID FROM dbo.tblBusinessBaseObject WHERE BBOCode = @BBOCode
		DECLARE @CancelledStatus INT = 0
		SELECT @CancelledStatus = StateID FROM 
			dbo.tblBusinessBaseStateControl sc
			JOIN dbo.tblBusinessBaseStates s ON sc.StateControlID = s.StateControlID 
		WHERE BBOID = @BBOID AND s.StateName = 'Cancelled'
		
		DECLARE @Now DATETIME = CURRENT_TIMESTAMP
		DECLARE @Complete INT, @Estimate INT
		SELECT @Complete = ValidMilestoneStatusID FROM dbo.tblValidMilestoneStatus WHERE Name = 'Complete'
		SELECT @Estimate = ValidMilestoneStatusID FROM dbo.tblValidMilestoneStatus WHERE Name = 'Estimate'								
		
		DECLARE @TechTransferType INT
		SELECT @TechTransferType = ValidLaunchProjectTypeID FROM dbo.tblValidLaunchProjectType WHERE Name = 'Tech Transfer'	

		DECLARE @info INT
		SELECT @info = NotificationTypeID FROM elite_NotificationType WHERE Code = 'INFO'
		DECLARE @LNCH_LATE INT
		SELECT @LNCH_LATE = NotificationTypeID FROM elite_NotificationType WHERE Code = 'LNCH_LATE'
		DECLARE @LNCH_ERROR INT
		SELECT @LNCH_ERROR = NotificationTypeID FROM elite_NotificationType WHERE Code = 'LNCH_ERROR'
								
		SELECT  
			n.NotificationID,
			n.[Message],
			n.BBOID,
			bbo.BBOCode,
			n.ObjectID,
			n.AlwaysShow,
			nt.Code AS [TypeCode],
			ns.Code AS [SeverityCode],
			n.InsertDate
		FROM    
			dbo.elite_Notification n
			JOIN dbo.elite_NotificationType nt ON nt.NotificationTypeID = n.NotificationTypeID
			JOIN dbo.elite_NotificationSeverity ns ON ns.NotificationSeverityID = nt.NotificationSeverityID
			LEFT JOIN dbo.tblBusinessBaseObject bbo ON bbo.BBOID = n.BBOID
		ORDER BY AlwaysShow desc, InsertDate DESC, NotificationID DESC -- newest atop
			
		--EXEC sp_xml_removedocument @filterDoc
	END TRY


	BEGIN CATCH
			EXEC SP_ROLLANDRAISE
	END CATCH
		
		




GO
GRANT EXECUTE ON  [dbo].[elite_GetNotifications] TO [mp_db_execute]
GO
