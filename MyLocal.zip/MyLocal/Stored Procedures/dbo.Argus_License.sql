SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[Argus_License]
AS
BEGIN
    DECLARE @start DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, -7)
            );
    DECLARE @end DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, 0)
            );

    -- Sheet 3 - License
    SELECT DISTINCT
           MALicenseScopeID AS [MALicenseScopeID],
           s.StrengthID AS [StrengthID],
           p.ProductID AS [ProductID],
           p.name AS [Product Name],
           f.Name AS [Form],
           s.Name AS [Strength],
           --COALESCE(s.DrugCode, '') AS [Drug Code],
           COALESCE(ls.MarketingName, '') AS [Marketing Name],
           ml.RegisteredProductName AS [Registered Product Name],
           c.name AS [Market Authorization Holder],
           --COALESCE(PVC.name, '') AS [PV Responsible],
           CTY.name AS [Authorization Country],
           ml.LicenseNumber AS [License #],
           COALESCE(REPLACE(CONVERT(NVARCHAR(11), ml.LicenseApprovalDate, 106), ' ', '-'), '') AS [Approval #],
           bbs.StateName AS [Marketed],
           CASE
               WHEN ml.ReviewedOn IS NOT NULL THEN
                   'Reviewed'
               ELSE
                   ''
           END AS [Approved/Reviewed],
           COALESCE(vls.Name, '') AS [MA Status],
           vf.Name AS [Formulation]
    FROM dbo.tblForm f
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = f.ValidFormID
        JOIN dbo.tblStrength s
            ON f.FormID = s.FormID
               AND s.IsUndefined = 0
        JOIN dbo.tblProduct p
            ON p.ProductID = f.ProductID
        JOIN dbo.tblMAStrength MS
            ON s.StrengthID = MS.StrengthID
        JOIN dbo.tblMALicenseScope ls
            ON MS.MAStrengthID = ls.MAStrengthID
        JOIN dbo.tblCountry CTY
            ON ls.CountryID = CTY.CountryID
        JOIN dbo.tblBusinessBaseStates bbs
            ON ls.MarketStatusID = bbs.StateID
        JOIN dbo.tblMALicense ml
            ON ls.MALicenseID = ml.MALicenseID
        LEFT JOIN dbo.tblCompany c
            ON ml.LicenseHolderID = c.CompanyID
        LEFT JOIN dbo.tblValidLicenseStatus vls
            ON ml.ValidLicenseStatusID = vls.ValidLicenseStatusID
        LEFT JOIN tblcompany PVC
            ON ml.PharmacovigilanceResponsibilityID = PVC.companyid
    WHERE ml.MALicenseID IN
          (
              SELECT ObjectID
              FROM
              (
                  SELECT ObjectID,
                         pref.value('@name[1]', 'varchar(32)') AS Name
                  FROM dbo.admin_ChangeTracking_Audit
                      CROSS APPLY ObjectChanges.nodes('/AuditTrail/Changes/Property') AS AuditTrail(pref)
                  WHERE BusinessBasedObjectID = 60
                        AND EntryDate > @start
                        AND EntryDate < @end
                        AND objectID = ml.MALicenseID
              ) AS Result
              WHERE (
                        Name = 'MA Application Number'
                        OR Name = 'MA Holder'
                        OR Name = 'Marketing Status'
                        OR Name = 'Created'
                        OR Name = 'MA Status'
                        OR Name = 'MA Approval Date'
                        OR Name = 'MA Withdrawal Date'
                        OR Name = 'Marketing Cessation Date'
                        OR Name = 'Product Launch Date'
                    )
          )
          OR ls.MALicenseScopeID IN
             (
                 SELECT ObjectID
                 FROM
                 (
                     SELECT ObjectID,
                            pref.value('@name[1]', 'varchar(32)') AS Name
                     FROM dbo.admin_ChangeTracking_Audit
                         CROSS APPLY ObjectChanges.nodes('/AuditTrail/Changes/Property') AS AuditTrail(pref)
                     WHERE BusinessBasedObjectID = 61
                           AND EntryDate > @start
                           AND EntryDate < @end
                           AND objectID = ls.MALicenseScopeID
                 ) AS Result
                 WHERE (
                           Name = 'MA Application Number'
                           OR Name = 'MA Holder'
                           OR Name = 'Marketing Status'
                           OR Name = 'Created'
                           OR Name = 'MA Status'
                           OR Name = 'MA Approval Date'
                           OR Name = 'MA Withdrawal Date'
                           OR Name = 'Marketing Cessation Date'
                           OR Name = 'Product Launch Date'
                       )
             )
    ORDER BY p.Name;
END;
GO
