SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_PackagingConfigByStrength]
    @MAStrengthID INT ,
    @MALicenseID INT ,
    @CountryID INT
AS 
    BEGIN TRY
        SELECT DISTINCT
                PC.MAStrengthPackageID ID ,
                PT.name + ' ' + PC.PackageSize AS Name
        FROM    dbo.tblMaStrengthPackage PC
                JOIN dbo.tblValidMAPackType PT ON PC.ValidPackagingTypeID = PT.ValidMAPackTypeID
        WHERE   MAStrengthID = @MAStrengthID
                AND PC.MAStrengthPackageID NOT IN ( SELECT DISTINCT ISNULL(MaStrengthPackageID,'')
                                                             FROM   dbo.tblMALicenseScope
                                                             WHERE  MALicenseID = @MALicenseID
                                                                    AND CountryID = @CountryID
                                                                    AND MAStrengthID = @MAStrengthID )
        ORDER BY name
    END  TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_PackagingConfigByStrength] TO [mp_db_execute]
GO
