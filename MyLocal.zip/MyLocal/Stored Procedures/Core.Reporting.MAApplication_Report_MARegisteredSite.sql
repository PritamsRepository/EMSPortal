SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- New (Approved or not) – 1,215,466
-- Old Approved –            805,673
-- Old Unapproved –          388,947
--                         2,410,086
--EXEC [Core.Reporting].[MAApplication_Report_MARegisteredSite]
--EXEC [Core.Reporting].[MAApplication_Report_MARegisteredSite] @old = 0
--EXEC [Core.Reporting].[MAApplication_Report_MARegisteredSite] @old = 1, @Approved = 1
--EXEC [Core.Reporting].[MAApplication_Report_MARegisteredSite] @old = 1, @Approved = 0

CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_MARegisteredSite]
(
    @MAApplicationID INT = NULL,
    @Country NVARCHAR(MAX) = NULL,
    @Region NVARCHAR(MAX) = NULL,
    @Approved BIT = NULL,
    @Old BIT = NULL
)
AS
BEGIN
    DECLARE @CountryID INT;
    DECLARE @CountryGroupID INT;

    SELECT @CountryID = CountryID
    FROM dbo.tblCountry
    WHERE Code = @Country;

    SELECT @CountryGroupID = CountryGroupID
    FROM dbo.tblCountryGroup
    WHERE CountryGroupType = 'MAMkt'
          AND Name = @Region;

    SELECT DISTINCT
           ma.MAApplicationID,
           mal.MALicenseID,
           com.CompanyID,
           f.Name AS [Product],
           p.Name AS [Product Group],
           s.Name AS [Strength],
           c.Code AS Country,
           vst.Name AS [Site Type],
           com.Name AS [Site name],
           vls.Name AS [License Status],
           mal.LicenseApprovalDate,
           (
               SELECT TOP (1)
                      ct.EntryDate
               FROM dbo.admin_ChangeTracking_Audit ct
               WHERE ct.ObjectID = masite.MASiteID
                     AND ct.BusinessBasedObjectID = 63
           ) AS LastUpdatedDate
    FROM dbo.tblMALicense mal
        JOIN dbo.tblMAApplication ma
            ON ma.MAApplicationID = mal.MAApplicationID
        JOIN dbo.tblMALicenseScope mals
            ON mals.MALicenseID = mal.MALicenseID
        JOIN dbo.tblCountry c
            ON c.CountryID = mals.CountryID
        JOIN dbo.tblMARegisteredSite mars
            ON mars.MALicenseScopeID = mals.MALicenseScopeID
        JOIN dbo.tblMAStrength mas
            ON mas.MAStrengthID = mals.MAStrengthID
        JOIN dbo.tblStrength s
            ON s.StrengthID = mas.StrengthID
        JOIN dbo.tblForm f
            ON f.FormID = s.FormID
        JOIN dbo.tblProduct p
            ON p.ProductID = f.ProductID
        JOIN dbo.tblMASite masite
            ON masite.MASiteID = mars.MASiteID
        JOIN dbo.tblCompany com
            ON com.CompanyID = masite.CompanyID
        JOIN dbo.tblValidSiteType vst
            ON vst.ValidSiteTypeID = masite.ValidSiteTypeID
        LEFT JOIN dbo.tblValidLicenseStatus vls
            ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
    WHERE (
              mal.LicenseWithdrawalDate IS NULL
              OR mal.LicenseWithdrawalDate > DATEADD(YEAR, -5, GETDATE())
          )
          AND
          (
              @Approved IS NULL
              OR
              (
                  @Approved = 1
                  AND vls.Name = 'Approved'
              )
              OR
              (
                  @Approved = 0
                  AND
                  (
                      vls.Name IS NULL
                      OR vls.Name <> 'Approved'
                  )
              )
          )
          AND
          (
              @Old IS NULL
              OR
              (
                  @Old = 1
                  AND
                  (
                      NOT EXISTS
    (
        SELECT 1
        FROM dbo.admin_ChangeTracking_Audit ct
        WHERE ct.ObjectID = masite.MASiteID
              AND ct.BusinessBasedObjectID = 63
    )
                      OR (DATEADD(YEAR, -1, GETDATE()) >
                         (
                             SELECT TOP (1)
                                    ct.EntryDate
                             FROM dbo.admin_ChangeTracking_Audit ct
                             WHERE ct.ObjectID = masite.MASiteID
                                   AND ct.BusinessBasedObjectID = 63
                         )
                         )
                  )
              )
              OR
              (
                  @Old = 0
                  AND (DATEADD(YEAR, -1, GETDATE()) <=
                      (
                          SELECT TOP (1)
                                 ct.EntryDate
                          FROM dbo.admin_ChangeTracking_Audit ct
                          WHERE ct.ObjectID = masite.MASiteID
                                AND ct.BusinessBasedObjectID = 63
                      )
                      )
              )
          )

          -- )
          AND
          (
              @MAApplicationID IS NULL
              OR ma.MAApplicationID = @MAApplicationID
          )
          AND
          (
              @CountryID IS NULL
              OR @CountryID = mals.CountryID
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID IN
                 (
                     SELECT cg.CountryGroupID
                     FROM dbo.tblCountryLinkCountryGroup clcg
                         JOIN dbo.tblCountryGroup cg
                             ON cg.CountryGroupID = clcg.CountryGroupID
                     WHERE clcg.CountryID = mals.CountryID
                           AND cg.CountryGroupType = 'MAMkt'
                 )
          );
END;
GO
