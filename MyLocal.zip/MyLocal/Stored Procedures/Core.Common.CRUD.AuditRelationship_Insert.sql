SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[AuditRelationship_Insert]
    @ParentBBOID INT ,
    @ParentObjectID INT ,
    @ChangeTrackingID INT = NULL
AS 
    SET XACT_ABORT ON  
    SET NOCOUNT ON

	
        INSERT  INTO [dbo].[admin_ChangeTrackingRelationships_Audit]
                (   [ParentBBOID],
					[ParentObjectID] ,
					[ChangeTrackingID] )
                SELECT  @ParentBBOID,
						@ParentObjectID,
						@ChangeTrackingID
		
		SELECT  SCOPE_IDENTITY() AS ID

GO
