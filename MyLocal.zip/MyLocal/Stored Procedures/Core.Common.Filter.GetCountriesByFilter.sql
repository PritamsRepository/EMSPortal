SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetCountriesByFilter]
    @Name NVARCHAR(256) = NULL,
    @CountryGroupFilters CountryGroupType READONLY,
    @UserID INT,
    @PrivCode NVARCHAR(20)
AS 
    DECLARE @IsCountryGroupFilter BIT = 0
    SELECT  @IsCountryGroupFilter = CASE WHEN COUNT(*) > 0 THEN 1
                                         ELSE 0
                                    END
    FROM    @CountryGroupFilters

    SELECT  c.CountryID AS ID,
            c.[Name],
            c.Code
    FROM    dbo.tblCountry c
            JOIN udf_UserHasPrivForCountry_TableValued(@UserID, @PrivCode) uhp ON c.CountryID = uhp.CountryID
                                                              AND uhp.Privs = 1
    WHERE   ( @Name IS NULL
              OR c.Name LIKE '%' + @Name + '%'
            )
            AND ( @IsCountryGroupFilter = 0
                  OR EXISTS ( SELECT    *
                              FROM      tblCountryLinkCountryGroup lnk
                                        JOIN @CountryGroupFilters cgf ON cgf.CountryGroupID = lnk.CountryGroupID
                              WHERE     c.CountryID = lnk.CountryID )
                )      
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetCountriesByFilter] TO [mp_db_execute]
GO
