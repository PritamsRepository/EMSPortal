SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ama_REGISTERIMPORT_ErrorCapture] 
(
					@Source NVARCHAR(20) = NULL
)

AS
SET NOCOUNT ON

BEGIN TRY
	BEGIN TRANSACTION
				
		DELETE 
			mpa
		FROM 
			tblMarketedProductArchive mpa
		WHERE NOT EXISTS
			(
			SELECT Source, Country, DrugCode, Form, Molecule, Strength, MarketingStatus, MANumber, MAHolder, MAHolderType, TradeBrandNames, PVResponsible, InternalBDProduct, BDProdPartner, IsTransferActivityScheduled, ReceivingSite, ManufacturingSite1, ManufacturingSite2, ManufacturingSite3, ActualPackSite1, ActualPackSite2, ActualPackSite3, CreateDate, GrantDate, Err
			FROM
				tblMarketedProductStage mps
			WHERE  
				mps.Source = mpa.Source AND
				mps.Country = mpa.Country AND
				mps.DrugCode = mpa.DrugCode AND
				mps.Form = mpa.Form AND
				mps.Molecule = mpa.Molecule AND
				mps.Strength = mpa.Strength AND
				mps.MarketingStatus = mpa.MarketingStatus AND
				mps.MANumber = mpa.MANumber AND
				mps.MAHolder = mpa.MAHolder AND
				mps.MAHolderType = mpa.MAHolderType AND
				mps.TradeBrandNames = mpa.TradeBrandNames AND
				mps.PVResponsible = mpa.PVResponsible AND
				mps.InternalBDProduct = mpa.InternalBDProduct AND
				mps.BDProdPartner = mpa.BDProdPartner AND
				mps.IsTransferActivityScheduled = mpa.IsTransferActivityScheduled AND
				mps.ReceivingSite = mpa.ReceivingSite AND
				mps.ManufacturingSite1 = mpa.ManufacturingSite1 AND
				mps.ManufacturingSite2 = mpa.ManufacturingSite2 AND
				mps.ManufacturingSite3 = mpa.ManufacturingSite3 AND
				mps.ActualPackSite1 = mpa.ActualPackSite1 AND
				mps.ActualPackSite2 = mpa.ActualPackSite2 AND
				mps.ActualPackSite3 = mpa.ActualPackSite3 AND
				mps.CreateDate = mpa.CreateDate AND 
				mps.Err = mpa.ErrorMessage
			) 
			
		
		-- INSERT NEW RECORDS WHERE THEIR ARE NO MATCHES.
			
		INSERT INTO tblMarketedProductArchive (Source, Country, DrugCode, Form, Molecule, Strength, MarketingStatus, MANumber, MAHolder, MAHolderType, TradeBrandNames, PVResponsible, InternalBDProduct, BDProdPartner, IsTransferActivityScheduled, ReceivingSite, ManufacturingSite1, ManufacturingSite2, ManufacturingSite3, ActualPackSite1, ActualPackSite2, ActualPackSite3, CreateDate, GrantDate, ErrorMessage)
		SELECT DISTINCT Source, Country, DrugCode, Form, Molecule, Strength, MarketingStatus, MANumber, MAHolder, MAHolderType, TradeBrandNames, PVResponsible, InternalBDProduct, BDProdPartner, IsTransferActivityScheduled, ReceivingSite, ManufacturingSite1, ManufacturingSite2, ManufacturingSite3, ActualPackSite1, ActualPackSite2, ActualPackSite3, CreateDate, GrantDate, CAST(Err AS NVARCHAR(256)) as ERR
		FROM 
			tblMarketedProductStage mps
		WHERE NOT EXISTS 
		(
		SELECT Source, Country, DrugCode, Form, Molecule, Strength, MarketingStatus, MANumber, MAHolder, MAHolderType, TradeBrandNames, PVResponsible, InternalBDProduct, BDProdPartner, IsTransferActivityScheduled, ReceivingSite, ManufacturingSite1, ManufacturingSite2, ManufacturingSite3, ActualPackSite1, ActualPackSite2, ActualPackSite3, CreateDate, GrantDate, Err
		FROM
			tblMarketedProductArchive mpa
		WHERE  
				mpa.Source = mps.Source AND
				mpa.Country = mps.Country AND
				mpa.DrugCode = mps.DrugCode AND
				mpa.Form = mps.Form AND
				mpa.Molecule = mps.Molecule AND
				mpa.Strength = mps.Strength AND
				mpa.MarketingStatus = mps.MarketingStatus AND
				mpa.MANumber = mps.MANumber AND
				mpa.MAHolder = mps.MAHolder AND
				mpa.MAHolderType = MAHolderType AND
				mpa.TradeBrandNames = mps.TradeBrandNames AND
				mpa.PVResponsible = mps.PVResponsible AND
				mpa.InternalBDProduct = mps.InternalBDProduct AND
				mpa.BDProdPartner = mps.BDProdPartner AND
				mpa.IsTransferActivityScheduled = mps.IsTransferActivityScheduled AND
				mpa.ReceivingSite = mps.ReceivingSite AND
				mpa.ManufacturingSite1 = mpa.ManufacturingSite1 AND
				mpa.ManufacturingSite2 = mps.ManufacturingSite2 AND
				mpa.ManufacturingSite3 = mps.ManufacturingSite3 AND
				mpa.ActualPackSite1 = mps.ActualPackSite1 AND
				mpa.ActualPackSite2 = mps.ActualPackSite2 AND
				mpa.ActualPackSite3 = mps.ActualPackSite3 AND
				mpa.CreateDate = mps.CreateDate AND 
				mpa.ErrorMessage = mps.Err
				)
		
		-- UPDATE THE ERROR MESSAGES IN THE TABLE
		UPDATE tblMarketedProductArchive
			SET errorMessage = CASE 
													WHEN errorMessage LIKE ';Duplicate row for Country %' THEN REPLACE(REPLACE(ErrorMessage, ';Duplicate row for Country ', 'A duplicate country was found: '), '"', '') 
													WHEN errorMessage LIKE ';Cannot find strength for Drugcode %' THEN REPLACE(REPLACE(ErrorMessage, ';Cannot find strength for Drugcode', 'No drug code: '), '"', '')
													WHEN errorMessage LIKE ';Cannot convert Grant Date %' THEN REPLACE(REPLACE(ErrorMessage, ';Cannot convert Grant Date ', 'Bad date format (grant date): '), '"', '')
													WHEN errorMessage LIKE ';Cannot convert Create Date %' THEN REPLACE(REPLACE(ErrorMessage, ';Cannot convert Create Date ', 'Bad date format (create date): '), '"', '')
													WHEN errorMessage LIKE ';Cannot find Country %' THEN REPLACE(REPLACE(ErrorMessage, ';Cannot find Country ', 'Invalid country: '), '"', '')
													ELSE errorMessage
												END
		FROM tblMarketedProductArchive
		
		--REMOVE FOR PRODUCTION ROLL BUT MAKE SURE TO CHANGE THE DATABASE	
		DELETE FROM tblMarketedProductStage
		
	COMMIT TRANSACTION
	SET NOCOUNT OFF
	SELECT 0 AS [ReturnValue]
END TRY

BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
	SET NOCOUNT OFF
	SELECT -1 AS [ReturnValue]
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ama_REGISTERIMPORT_ErrorCapture] TO [mp_db_execute]
GO
GRANT EXECUTE ON  [dbo].[ama_REGISTERIMPORT_ErrorCapture] TO [mp_db_register]
GO
