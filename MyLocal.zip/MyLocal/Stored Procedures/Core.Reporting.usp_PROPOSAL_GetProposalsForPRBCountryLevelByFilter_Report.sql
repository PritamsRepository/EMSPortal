SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_PROPOSAL_GetProposalsForPRBCountryLevelByFilter_Report]
    @FormName NVARCHAR(256) = NULL ,
    @CountryGroupID INT = NULL ,
    @ValidProposalStatusID INT = NULL ,
    @TargetPRBSessionID INT = NULL ,
    @ValidPRBDecisionID INT = NULL ,
    @ValidMakeBuyID INT = NULL ,
    @ShowNonCandidatesOnly BIT = FALSE ,
    @MaxLen INT = NULL ,
    @UserID INT ,
    @PrivCode NVARCHAR(10) ,
    @MarketResponseIDs NVARCHAR(100) = NULL
AS /*============================================================================================
CREATED BY:				SCOTT DEXTER
CREATED ON:				DEC 3, 2009
MODIFIED BY:			Christian Duvall
MODIFIED ON:			07-Dec-2009
MODIFIED BY:			SCOTT DEXTER
MODIFIED ON:			DEC 15, 2009
MODIFIED PURPOSE:		Removed SQL Statements within Select statement of query and replaced with CTE's as the data 
								elements on the CTE's are small. Executes in 6 seconds with all input variables as null.

MODIFIED ON:			20-May-2010
MODIFIED BY:			Robin Abramson
MODIFIED PURPOSE:		Removed CTE's & Created Temp table with update statements instead of very large amounts of 
						left joins in select statements.  Decreased time of EXEC [dbo].sp_PROPOSAL_GetProposalsForPRBCountryLevelByFilter_NEW @UserID = 3, @PrivCode = 'IP01'
						from 1:16 to :10 on MyPortfolio.
						
						Fixed issue where @ValidProposalStatusID = -1 was bringing back 2 result sets.


-------------------------------------------------------------------------------------------------------------------------
PURPOSE:			Proposal Country Level Report.
==============================================================================================
EXAMPLE:		EXEC [dbo].sp_PROPOSAL_GetProposalsForPRBCountryLevelByFilter @UserID = 3, @PrivCode = 'IP01', @ValidProposalStatusID = -2
=============================================================================================*/


------------------------------------------------------------------------------------------------------------------------
-- 1-JULY-2010 |JRG | Modify SDLC 430 replace SummaryExpiryDate with expirydate
------------------------------------------------------------------------------------------------------------------------

    SET NOCOUNT ON
    BEGIN TRY;

        DECLARE @MarketResponseIDsTbl AS ValidResponseType
        INSERT  INTO @MarketResponseIDsTbl
                SELECT  id
                FROM    dbo.udf_GetValuesFromCSV(@MarketResponseIDs)

/**********************************
First, put all the currency factors into 
a variable table to avoid use of UDFs.
************************************/
        CREATE TABLE #CurrencyFactors
            (
              EffectiveDate DATETIME ,
              ExRateLoadID INT ,
              ValidCurrencyID INT ,
              ConversionFactor2USD DECIMAL(12, 4) ,
              ToAmount DECIMAL(20, 5) ,
              ReturnAmount DECIMAL(20, 5)
                PRIMARY KEY CLUSTERED
                ( EffectiveDate, ValidCurrencyID, ExRateLoadID )
            )

        INSERT  #CurrencyFactors
                ( EffectiveDate ,
                  ExRateLoadID ,
                  ValidCurrencyID ,
                  ConversionFactor2USD
                )
                SELECT  erl.EffectiveDate ,
                        erl.ExRateLoadID ,
                        er.ValidCurrencyID ,
                        er.ConversionFactor2USD
                FROM    dbo.tblExchangeRate er
                        JOIN dbo.tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
		
        CREATE TABLE #PRBList
            (
              [PRBSessionID] INT ,
              [PRBSession] [NVARCHAR](512) NULL ,
              [Candidate] [NVARCHAR](512) NULL ,
              [Proposal] [NVARCHAR](512) NULL ,
              [ProposalStatus] [VARCHAR](512) NULL ,
              [ProposalClass] [VARCHAR](512) NULL ,
              [Product] [NVARCHAR](512) NULL ,
              [FormID] [INT] NOT NULL ,
              [CountryID] [INT] NULL ,
              [Market] [NVARCHAR](512) NULL ,
              [MarketSubType] [NVARCHAR](512) NULL ,
              [ValidMakeBuyID] [INT] NULL ,
              [MakeBuy] [VARCHAR](512) NULL ,
              [PRBDecision] [VARCHAR](512) NULL ,
              [Countries] [NVARCHAR](512) NULL ,
              [CountryPRBDecision] [VARCHAR](512) NULL ,
              [RegionalLevelMarketResponse] [VARCHAR](512) NULL ,
              [CountryLevelResponse] [VARCHAR](512) NULL ,
              [NoOfLicenses] [INT] NULL ,
              [SalesForecastPeakSales] [VARCHAR](512) NULL ,
              [SalesViewByCountry] [VARCHAR](512) NULL ,
              [SalesForecastVolumeByCountry] [VARCHAR](512) NULL ,
              [ExclusivityExpiration] [DATETIME] NULL ,
              [PatentSummary] [DATETIME] NULL ,
              [MylanApprovalDate] [DATETIME] NULL ,
              [MylanRequestedLaunchDate] [DATETIME] NULL ,
              [MylanGlobalComments] [NVARCHAR](MAX) NULL ,
              [MylanRegionalComments] [NVARCHAR](MAX) NULL ,
              [RDComments] [NVARCHAR](MAX) NULL ,
              [ExternalPartner] [NVARCHAR](512) NULL ,
              [ValidLevelOfAnticipatedCompetition] [NVARCHAR](512) NULL ,
              [ValidBDRationale] [NVARCHAR](512) NULL ,
              [ValidBDAgreementType] [NVARCHAR](512) NULL ,
              [BDTimingAdvantage] [INT] NULL ,
              [AnticipatedAccessFee] [DECIMAL](20, 5) NULL ,
              [InitialTermAgreement] [INT] NULL ,
              [RenewalTermAgreement] [INT] NULL ,
              [TermAgreementComment] [NVARCHAR](MAX) NULL ,
              [ValidBCRADecision] [NVARCHAR](512) NULL ,
              [BDGeneralComment] [NVARCHAR](MAX) NULL ,
              [OriginalBCRASession] [NVARCHAR](512) NULL ,
              [TargetedBCRASession] [NVARCHAR](512) NULL ,
              [StrategicRationale] [NVARCHAR](512) NULL ,
              [MarketSegment] [NVARCHAR](512) NULL ,
              [CountryGroupID] [INT] NOT NULL ,
              [TargetPRBSessionID] [INT] NULL ,
              [ValidPRBDecisionID] [INT] NULL ,
              [CandidateID] [INT] NULL ,
              [ValidProposalStatusID] [INT] NULL ,
              [ValidResponseID] INT NULL ,
              [ExternalPartnerID] INT NULL ,
              [ValidLevelOfAnticipatedCompetitionID] INT NULL ,
              [ValidBDRationaleID] INT NULL ,
              [ValidBDAgreementTypeID] INT NULL ,
              [ValidBCRADecisionID] INT NULL ,
              [OriginalBCRASessionID] INT NULL ,
              [TargetedBCRASessionID] INT NULL ,
              [ValidStrategicRationaleID] INT NULL ,
              [ValidMarketSegmentID] INT NULL ,
              [ValidProposalClassID] INT NULL ,
              [PCountryInterestID] [INT] NULL ,
              [PECCategory] NVARCHAR(512) NULL ,
              [ProjectScopeChange] NVARCHAR(512) NULL ,
              [ProjectScopeChangeID] INT NULL ,
              [ValidCommOpsRating] NVARCHAR(512) NULL ,
              [ValidCommOpsRatingID] INT NULL ,
              [ValidTechOpsRating] NVARCHAR(512) NULL ,
              [ValidTechOpsRatingID] INT NULL ,
              [EHSAlert] [NVARCHAR](512) NULL ,
              [OEBClassifications] [NVARCHAR](1000) NULL ,
              [DrugClassifications] [NVARCHAR](1000) NULL
            ) 

        CREATE NONCLUSTERED INDEX idx_PRBList_ValidProposalStatusID ON #PRBList ( [ValidProposalStatusID] )
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidMakeBuyID ON #PRBList ( [ValidMakeBuyID] )
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidBDRationaleID ON #PRBList ( [ValidBDRationaleID] )
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidBDAgreementTypeID ON #PRBList ( [ValidBDAgreementTypeID] )
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidBCRADecisionID ON #PRBList ( [ValidBCRADecisionID] )	
        CREATE NONCLUSTERED INDEX idx_PRBList_OriginalBCRADecisionID ON #PRBList ( [OriginalBCRASessionID] )	
        CREATE NONCLUSTERED INDEX idx_PRBList_TargetedBCRASessionID ON #PRBList ( [TargetedBCRASessionID] )	
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidStrategicRationaleID ON #PRBList ( [ValidStrategicRationaleID] )		
        CREATE NONCLUSTERED INDEX idx_PRBList_ValidMarketSegmentID ON #PRBList ( [ValidMarketSegmentID] )		
        CREATE NONCLUSTERED INDEX idx_PRBList_FormID ON #PRBList ( [FormID] )
        CREATE NONCLUSTERED INDEX idx_PRBList_CountryID ON #PRBList ( [CountryID] )
                
        IF @ValidProposalStatusID = -1
            BEGIN
                INSERT  INTO #PRBList
                        ( PRBSessionID ,
                          PRBSession ,
                          Candidate ,
                          Proposal ,
                          ProposalStatus ,
                          ProposalClass ,
                          Product ,
                          FormID ,
                          CountryID ,
                          Market ,
                          MarketSubType ,
                          ValidMakeBuyID ,
                          MakeBuy ,
                          PRBDecision ,
                          Countries ,
                          CountryPRBDecision ,
                          RegionalLevelMarketResponse ,
                          CountryLevelResponse ,
                          NoOfLicenses ,
                          SalesForecastPeakSales ,
                          SalesViewByCountry ,
                          SalesForecastVolumeByCountry ,
                          ExclusivityExpiration ,
                          PatentSummary ,
                          MylanApprovalDate ,
                          MylanRequestedLaunchDate ,
                          MylanGlobalComments ,
                          MylanRegionalComments ,
                          RDComments ,
                          ExternalPartner ,
                          ValidLevelOfAnticipatedCompetition ,
                          ValidBDRationale ,
                          ValidBDAgreementType ,
                          BDTimingAdvantage ,
                          AnticipatedAccessFee ,
                          InitialTermAgreement ,
                          RenewalTermAgreement ,
                          TermAgreementComment ,
                          ValidBCRADecision ,
                          BDGeneralComment ,
                          OriginalBCRASession ,
                          TargetedBCRASession ,
                          StrategicRationale ,
                          MarketSegment ,
                          CountryGroupID ,
                          TargetPRBSessionID ,
                          ValidPRBDecisionID ,
                          CandidateID ,
                          ValidProposalStatusID ,
                          ValidResponseID ,
                          ExternalPartnerID ,
                          ValidLevelOfAnticipatedCompetitionID ,
                          ValidBDRationaleID ,
                          ValidBDAgreementTypeID ,
                          ValidBCRADecisionID ,
                          OriginalBCRASessionID ,
                          TargetedBCRASessionID ,
                          ValidStrategicRationaleID ,
                          ValidMarketSegmentID ,
                          ValidProposalClassID ,
                          PCountryInterestID ,
                          PECCategory ,
                          ProjectScopeChange ,
                          ValidCommOpsRating ,
                          ValidCommOpsRatingID ,
                          ValidTechOpsRating ,
                          ValidTechOpsRatingID ,
                          EHSAlert ,
                          OEBClassifications ,
                          DrugClassifications
                        )
                        SELECT DISTINCT
                                PRBSessionID ,
                                PRBSession ,
                                Candidate ,
                                Proposal ,
                                ProposalStatus ,
                                ProposalClass ,
                                Product ,
                                FormID ,
                                CountryID ,
                                Market ,
                                MarketSubType ,
                                ValidMakeBuyID ,
                                MakeBuy ,
                                PRBDecision ,
                                Countries ,
                                CountryPRBDecision ,
                                RegionalLevelMarketResponse ,
                                CountryLevelResponse ,
                                NoOfLicenses ,
                                SalesForecastPeakSales ,
                                SalesViewByCountry ,
                                SalesForecastVolumeByCountry ,
                                ExclusivityExpiration ,
                                PatentSummary ,
                                MylanApprovalDate ,
                                MylanRequestedLaunchDate ,
                                MylanGlobalComments ,
                                MylanRegionalComments ,
                                RDComments ,
                                ExternalPartner ,
                                ValidLevelOfAnticipatedCompetition ,
                                ValidBDRationale ,
                                ValidBDAgreementType ,
                                BDTimingAdvantage ,
                                AnticipatedAccessFee ,
                                InitialTermAgreement ,
                                RenewalTermAgreement ,
                                TermAgreementComment ,
                                ValidBCRADecision ,
                                BDGeneralComment ,
                                OriginalBCRASession ,
                                TargetedBCRASession ,
                                StrategicRationale ,
                                MarketSegment ,
                                CountryGroupID ,
                                TargetPRBSessionID ,
                                ValidPRBDecisionID ,
                                CandidateID ,
                                ValidProposalStatusID ,
                                ValidResponseID ,
                                ExternalPartnerID ,
                                ValidLevelOfAnticipatedCompetitionID ,
                                ValidBDRationaleID ,
                                ValidBDAgreementTypeID ,
                                ValidBCRADecisionID ,
                                OriginalBCRASessionID ,
                                TargetedBCRASessionID ,
                                ValidStrategicRationaleID ,
                                ValidMarketSegmentID ,
                                ValidProposalClassID ,
                                PCountryInterestID ,
                                PECCategory ,
                                ValidProjectScopeChange ,
                                ValidCommOpsRating ,
                                ValidCommOpsRatingID ,
                                ValidTechOpsRating ,
                                ValidTechOpsRatingID ,
                                dbo.udf_EHSAlert(p.ProductID, NULL) AS EHSAlert ,
                                dbo.udf_GetMPBClassifications(p.ProductID) AS OEBClassifications ,
                                dbo.udf_GetDrugClassifications(p.ProductID) AS DrugClassifications
                        FROM    dbo.[vw_PRBCountryLevelByFilter_WithPotency] p
                        WHERE   ( @FormName IS NULL
                                  OR p.[Product] LIKE @FormName + '%'
                                )
                                AND ( @CountryGroupID IS NULL
                                      OR @CountryGroupID = p.[CountryGroupID]
                                    )
                                AND ( @MarketResponseIDs IS NULL
                                      OR p.ValidResponseID IN (
                                      SELECT    ValidResponseID
                                      FROM      @MarketResponseIDsTbl )
                                    )
                                AND ( @TargetPRBSessionID IS NULL
                                      OR @TargetPRBSessionID = p.[TargetPRBSessionID]
                                    )
                                AND ( @ValidPRBDecisionID IS NULL
                                      OR @ValidPRBDecisionID = p.[ValidPRBDecisionID]
                                    )
                                AND ( @ShowNonCandidatesOnly = 'false'
                                      OR p.[CandidateID] IS NULL
                                    )
                                AND ( @ValidMakeBuyID IS NULL
                                      OR @ValidMakeBuyID = p.[ValidMakeBuyID]
                                    )
                                AND
                                [dbo].[udf_UserHasPrivForCountryGroup](@UserID,
                                                              @PrivCode,
                                                              p.[CountryGroupID]) = 'true'
							
                UPDATE  p
                SET     ProposalStatus = bbs.StateName
                FROM    #PRBList p
                        JOIN dbo.tblBusinessBaseStates bbs ON p.[ValidProposalStatusID] = bbs.[StateID]
					
                UPDATE  p
                SET     ProposalClass = vpc.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidProposalClass vpc ON vpc.ValidProposalClassID = p.ValidProposalClassID
			
                UPDATE  p
                SET     MakeBuy = vmb.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidMakeBuy vmb ON vmb.ValidMakeBuyID = p.ValidMakeBuyID
			
                UPDATE  p
                SET     PRBDecision = vd.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID
					
                UPDATE  p
                SET     RegionalLevelMarketResponse = vrp.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidResponse vrp ON vrp.ValidResponseID = p.ValidResponseID
					
                UPDATE  p
                SET     CountryLevelResponse = vrci.[Name]
                FROM    #PRBList p
                        JOIN pm.ProductProposalCountryInterest pci ON pci.ProductProposalCountryInterestID = p.PCountryInterestID
                        JOIN dbo.tblValidResponse vrci ON vrci.ValidResponseID = pci.ValidResponseID
					
                UPDATE  p
                SET     SalesForecastPeakSales = ISNULL(sfps.TotalAmount,
                                                        'No Data Available')
                FROM    #PRBList p
                        JOIN ( SELECT   ProductProposalCountryInterestID ,
                                        CAST(MAX(TotalAmount) AS NVARCHAR(30)) AS TotalAmount ,
                                        [PRBSessionID]
                               FROM     ( SELECT    psf1.ProductProposalCountryInterestID ,
                                                    CAST(SUM(psf1.ForecastTurnover
                                                             / b.ConversionFactor2USD) AS DECIMAL(20, 5)) AS TotalAmount ,
                                                    prb.[PRBSessionID]
                                          FROM      pm.ProductProposalSalesForecast psf1
                                                    JOIN pm.ProductProposalTradeDress ptd ON ptd.ProductProposalTradeDressID = psf1.ProductProposalTradeDressID
                                                    JOIN pm.ProductProposal prop ON prop.ProductProposalID = ptd.ProductProposalID
                                                    JOIN pm.Candidate c ON c.CandidateID = prop.CandidateID
                                                    JOIN pm.PRBSession prb ON prb.PRBSessionID = c.TargetPRBSessionID
                                                    JOIN #CurrencyFactors b ON psf1.ValidCurrencyID = b.ValidCurrencyID
                                                              AND prb.ExRateLoadID = b.ExRateLoadID
                                          GROUP BY  psf1.ForecastYear ,
                                                    psf1.ProductProposalCountryInterestID ,
                                                    prb.[PRBSessionID]
                                        ) AS PeakSales
                               GROUP BY ProductProposalCountryInterestID ,
                                        [PRBSessionID]
                             ) sfps ON sfps.ProductProposalCountryInterestID = p.PCountryInterestID
                                       AND [sfps].[PRBSessionID] = p.PRBSessionID
                             
				
                UPDATE  p
                SET     SalesViewByCountry = ISNULL(svbc.TotalAmount,
                                                    'No Data Available')
                FROM    #PRBList p
                        JOIN ( SELECT   stg.FormID ,
                                        sales.CountryID ,
                                        CAST(SUM(sales.TotalAmt) AS NVARCHAR(30)) AS TotalAmount
                               FROM     dbo.tblStrength AS stg
                                        JOIN dbo.tblSales AS sales ON stg.StrengthID = sales.StrengthID
                               GROUP BY stg.FormID ,
                                        sales.CountryID
                             ) svbc ON svbc.FormID = p.FormID
                                       AND svbc.CountryID = p.CountryID
						
                UPDATE  p
                SET     SalesForecastVolumeByCountry = ISNULL(sfvbc.TotalVolume,
                                                              'No Data Available')
                FROM    #PRBList p
                        JOIN ( SELECT   ProductProposalCountryInterestID ,
                                        CAST(SUM(TotalVolume) AS NVARCHAR(30)) AS TotalVolume
                               FROM     ( SELECT    psf.ProductProposalCountryInterestID ,
                                                    MAX(psf.[ForecastVolume]
                                                        * ptd.[PackSize]) AS TotalVolume
                                          FROM      pm.ProductProposalSalesForecast psf
                                                    JOIN pm.ProductProposalTradeDress ptd ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
                                          GROUP BY  psf.ProductProposalCountryInterestID ,
                                                    ptd.[PackSize]
                                        ) AS PeakVolume
                               GROUP BY ProductProposalCountryInterestID
                             ) sfvbc ON sfvbc.ProductProposalCountryInterestID = p.PCountryInterestID
							
                UPDATE  p
                SET     ExclusivityExpiration = ee.ExpirationDate
                FROM    #PRBList p
                        JOIN ( SELECT   CountryID ,
                                        FormID ,
                                        MIN(ExpiryDate) AS ExpirationDate
                               FROM     pm.Exclusivity
                               GROUP BY CountryID ,
                                        FormID
                             ) ee ON ee.CountryID = p.CountryID
                                     AND ee.FormID = p.FormID
					
                UPDATE  p
                SET     PatentSummary = pa.ExpiryDate ,
                        MylanApprovalDate = l.MylanApprovalDate
                FROM    #PRBList p
                        JOIN pm.LegalInfo l ON l.FormID = p.FormID
                                                   AND l.CountryID = p.CountryID
												   LEFT JOIN pm.Patent pa ON pa.PatentID = l.BlockingPatentID
					
                UPDATE  p
                SET     ExternalPartner = cc.[Name]
                FROM    #PRBList p
                        JOIN dbo.tblCompany cc ON cc.CompanyID = p.ExternalPartnerID
					
                UPDATE  p
                SET     ValidLevelOfAnticipatedCompetition = vlac.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidLevelOfAnticipatedCompetition vlac ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
				
                UPDATE  p
                SET     ValidBDRationale = vbdr.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidBDRationale vbdr ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
					
                UPDATE  p
                SET     ValidBDAgreementType = vbdat.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidBDAgreementType vbdat ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
				
                UPDATE  p
                SET     ValidBCRADecision = vbcrad.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidBCRADecision vbcrad ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID			 

                UPDATE  p
                SET     OriginalBCRASession = bcras.Name
                FROM    #PRBList p
                        JOIN dbo.tblBCRASession bcras ON bcras.BCRASessionID = p.OriginalBCRASessionID 

                UPDATE  p
                SET     TargetedBCRASession = bcra.Name
                FROM    #PRBList p
                        JOIN dbo.tblBCRASession bcra ON bcra.BCRASessionID = p.TargetedBCRASessionID

                UPDATE  p
                SET     StrategicRationale = vsr.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidStrategicRationale vsr ON vsr.ValidStrategicRationaleID = p.ValidStrategicRationaleID

                UPDATE  p
                SET     MarketSegment = vms.Name
                FROM    #PRBList p
                        JOIN dbo.tblValidMarketSegment vms ON vms.ValidMarketSegmentID = p.ValidMarketSegmentID

                UPDATE  p
                SET     ValidPRBDecisionID = vd.ValidPRBDecisionID
                FROM    #PRBList p
                        JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID

		      -- Now perform final select
                SELECT DISTINCT
                        p.PRBSession ,
                        p.Candidate ,
                        p.Proposal ,
                        p.ProposalStatus ,
                        p.ProposalClass ,
                        p.Product ,
                        p.Market ,
                        p.MarketSubType ,
                        p.[MakeBuy] ,
                        p.[PRBDecision] ,
                        p.Countries ,
                        p.CountryPRBDecision ,
                        p.[RegionalLevelMarketResponse] ,
                        p.[CountryLevelResponse] ,
                        p.[NoOfLicenses] ,
                        p.SalesForecastPeakSales ,
                        p.SalesViewByCountry ,
                        p.SalesForecastVolumeByCountry ,
                        p.ExclusivityExpiration ,
                        p.PatentSummary ,
                        p.MylanApprovalDate ,
                        p.MylanRequestedLaunchDate ,
                        p.[MylanGlobalComments] ,
                        p.[MylanRegionalComments] ,
                        p.RDComments ,
                        p.ExternalPartner ,
                        p.ValidLevelOfAnticipatedCompetition ,
                        p.ValidBDRationale ,
                        p.ValidBDAgreementType ,
                        p.BDTimingAdvantage ,
                        p.AnticipatedAccessFee ,
                        p.InitialTermAgreement ,
                        p.RenewalTermAgreement ,
                        p.TermAgreementComment ,
                        p.ValidBCRADecision ,
                        p.BDGeneralComment ,
                        p.OriginalBCRASession ,
                        p.TargetedBCRASession ,
                        p.StrategicRationale ,
                        p.MarketSegment ,
                        p.PECCategory ,
                        p.ProjectScopeChange ,
                        p.ProjectScopeChangeID ,
                        p.ValidCommOpsRatingID ,
                        p.ValidCommOpsRating ,
                        p.ValidTechOpsRatingID ,
                        p.ValidTechOpsRating ,
                        NULL AS isExpirySummaryAllStrengths,
                        p.EHSAlert ,
                        p.OEBClassifications ,
                        p.DrugClassifications
                FROM    #PRBList p /* JRG added for Sprint Item 577*/
                        LEFT JOIN  pm.LegalInfo l
                                   ON l.FormID = p.FormID
                                       AND l.CountryID = p.CountryID
                WHERE   p.ProposalStatus NOT IN ( 'Complete', 'On Hold',
                                                  'Cancelled' )
                ORDER BY p.PRBSession ,
                        p.Proposal ,
                        p.Countries
            END
        ELSE
            IF @ValidProposalStatusID = -2
                BEGIN
                    INSERT  INTO #PRBList
                            ( PRBSessionID ,
                              PRBSession ,
                              Candidate ,
                              Proposal ,
                              ProposalStatus ,
                              ProposalClass ,
                              Product ,
                              FormID ,
                              CountryID ,
                              Market ,
                              MarketSubType ,
                              ValidMakeBuyID ,
                              MakeBuy ,
                              PRBDecision ,
                              Countries ,
                              CountryPRBDecision ,
                              RegionalLevelMarketResponse ,
                              CountryLevelResponse ,
                              NoOfLicenses ,
                              SalesForecastPeakSales ,
                              SalesViewByCountry ,
                              SalesForecastVolumeByCountry ,
                              ExclusivityExpiration ,
                              PatentSummary ,
                              MylanApprovalDate ,
                              MylanRequestedLaunchDate ,
                              MylanGlobalComments ,
                              MylanRegionalComments ,
                              RDComments ,
                              ExternalPartner ,
                              ValidLevelOfAnticipatedCompetition ,
                              ValidBDRationale ,
                              ValidBDAgreementType ,
                              BDTimingAdvantage ,
                              AnticipatedAccessFee ,
                              InitialTermAgreement ,
                              RenewalTermAgreement ,
                              TermAgreementComment ,
                              ValidBCRADecision ,
                              BDGeneralComment ,
                              OriginalBCRASession ,
                              TargetedBCRASession ,
                              StrategicRationale ,
                              MarketSegment ,
                              CountryGroupID ,
                              TargetPRBSessionID ,
                              ValidPRBDecisionID ,
                              CandidateID ,
                              ValidProposalStatusID ,
                              ValidResponseID ,
                              ExternalPartnerID ,
                              ValidLevelOfAnticipatedCompetitionID ,
                              ValidBDRationaleID ,
                              ValidBDAgreementTypeID ,
                              ValidBCRADecisionID ,
                              OriginalBCRASessionID ,
                              TargetedBCRASessionID ,
                              ValidStrategicRationaleID ,
                              ValidMarketSegmentID ,
                              ValidProposalClassID ,
                              PCountryInterestID ,
                              PECCategory ,
                              ProjectScopeChange ,
                              ValidCommOpsRatingID ,
                              ValidCommOpsRating ,
                              ValidTechOpsRatingID ,
                              ValidTechOpsRating ,
                              EHSAlert ,
                              OEBClassifications ,
                              DrugClassifications
                            )
                            SELECT DISTINCT
                                    PRBSessionID ,
                                    PRBSession ,
                                    Candidate ,
                                    Proposal ,
                                    ProposalStatus ,
                                    ProposalClass ,
                                    Product ,
                                    FormID ,
                                    CountryID ,
                                    Market ,
                                    MarketSubType ,
                                    ValidMakeBuyID ,
                                    MakeBuy ,
                                    PRBDecision ,
                                    Countries ,
                                    CountryPRBDecision ,
                                    RegionalLevelMarketResponse ,
                                    CountryLevelResponse ,
                                    NoOfLicenses ,
                                    SalesForecastPeakSales ,
                                    SalesViewByCountry ,
                                    SalesForecastVolumeByCountry ,
                                    ExclusivityExpiration ,
                                    PatentSummary ,
                                    MylanApprovalDate ,
                                    MylanRequestedLaunchDate ,
                                    MylanGlobalComments ,
                                    MylanRegionalComments ,
                                    RDComments ,
                                    ExternalPartner ,
                                    ValidLevelOfAnticipatedCompetition ,
                                    ValidBDRationale ,
                                    ValidBDAgreementType ,
                                    BDTimingAdvantage ,
                                    AnticipatedAccessFee ,
                                    InitialTermAgreement ,
                                    RenewalTermAgreement ,
                                    TermAgreementComment ,
                                    ValidBCRADecision ,
                                    BDGeneralComment ,
                                    OriginalBCRASession ,
                                    TargetedBCRASession ,
                                    StrategicRationale ,
                                    MarketSegment ,
                                    CountryGroupID ,
                                    TargetPRBSessionID ,
                                    ValidPRBDecisionID ,
                                    CandidateID ,
                                    ValidProposalStatusID ,
                                    ValidResponseID ,
                                    ExternalPartnerID ,
                                    ValidLevelOfAnticipatedCompetitionID ,
                                    ValidBDRationaleID ,
                                    ValidBDAgreementTypeID ,
                                    ValidBCRADecisionID ,
                                    OriginalBCRASessionID ,
                                    TargetedBCRASessionID ,
                                    ValidStrategicRationaleID ,
                                    ValidMarketSegmentID ,
                                    ValidProposalClassID ,
                                    PCountryInterestID ,
                                    PECCategory ,
                                    ValidProjectScopeChange ,
                                    ValidCommOpsRatingID ,
                                    ValidCommOpsRating ,
                                    ValidTechOpsRatingID ,
                                    ValidTechOpsRating ,
                                    dbo.udf_EHSAlert(p.ProductID, NULL) AS EHSAlert ,
                                    dbo.udf_GetMPBClassifications(p.ProductID) AS OEBClassifications ,
                                    dbo.udf_GetDrugClassifications(p.ProductID) AS DrugClassifications
                            FROM    dbo.[vw_PRBCountryLevelByFilter_WithPotency] p
                            WHERE   ( @FormName IS NULL
                                      OR p.[Product] LIKE @FormName + '%'
                                    )
                                    AND ( @CountryGroupID IS NULL
                                          OR @CountryGroupID = p.[CountryGroupID]
                                        )
                                    AND ( @TargetPRBSessionID IS NULL
                                          OR @TargetPRBSessionID = p.[TargetPRBSessionID]
                                        )
                                    AND ( @ValidPRBDecisionID IS NULL
                                          OR @ValidPRBDecisionID = p.[ValidPRBDecisionID]
                                        )
                                    AND ( @ShowNonCandidatesOnly = 'false'
                                          OR p.[CandidateID] IS NULL
                                        )
                                    AND ( @ValidMakeBuyID IS NULL
                                          OR @ValidMakeBuyID = p.[ValidMakeBuyID]
                                        )
                                    AND
                                    [dbo].[udf_UserHasPrivForCountryGroup](@UserID,
                                                              @PrivCode,
                                                              p.[CountryGroupID]) = 'true'






                    UPDATE  p
                    SET     ProposalStatus = bbs.StateName
                    FROM    #PRBList p
                            JOIN dbo.tblBusinessBaseStates bbs ON p.[ValidProposalStatusID] = bbs.[StateID]
			
                    UPDATE  p
                    SET     ProposalClass = vpc.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidProposalClass vpc ON vpc.ValidProposalClassID = p.ValidProposalClassID
						
                    UPDATE  p
                    SET     MakeBuy = vmb.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidMakeBuy vmb ON vmb.ValidMakeBuyID = p.ValidMakeBuyID
	
                    UPDATE  p
                    SET     PRBDecision = vd.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID
			
                    UPDATE  p
                    SET     RegionalLevelMarketResponse = vrp.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidResponse vrp ON vrp.ValidResponseID = p.ValidResponseID
			
                    UPDATE  p
                    SET     CountryLevelResponse = vrci.[Name]
                    FROM    #PRBList p
                            JOIN pm.ProductProposalCountryInterest pci ON pci.ProductProposalCountryInterestID = p.PCountryInterestID
                            JOIN dbo.tblValidResponse vrci ON vrci.ValidResponseID = pci.ValidResponseID
			
                    UPDATE  p
                    SET     SalesForecastPeakSales = ISNULL(sfps.TotalAmount,
                                                            'No Data Available')
                    FROM    #PRBList p
                            JOIN ( SELECT   ProductProposalCountryInterestID ,
                                            CAST(MAX(TotalAmount) AS NVARCHAR(30)) AS TotalAmount ,
                                            [PRBSessionID]
                                   FROM     ( SELECT    psf1.ProductProposalCountryInterestID ,
                                                        CAST(SUM(psf1.ForecastTurnover
                                                              / b.ConversionFactor2USD) AS DECIMAL(20, 5)) AS TotalAmount ,
                                                        prb.[PRBSessionID]
                                              FROM      pm.ProductProposalSalesForecast psf1
                                                        JOIN pm.ProductProposalTradeDress ptd ON ptd.ProductProposalTradeDressID = psf1.ProductProposalTradeDressID
                                                        JOIN pm.ProductProposal prop ON prop.ProductProposalID = ptd.ProductProposalID
                                                        JOIN pm.Candidate c ON c.CandidateID = prop.CandidateID
                                                        JOIN pm.PRBSession prb ON prb.PRBSessionID = c.TargetPRBSessionID
                                                        JOIN #CurrencyFactors b ON psf1.ValidCurrencyID = b.ValidCurrencyID
                                                              AND prb.ExRateLoadID = b.ExRateLoadID
                                              GROUP BY  psf1.ForecastYear ,
                                                        psf1.ProductProposalCountryInterestID ,
                                                        prb.[PRBSessionID]
                                            ) AS PeakSales
                                   GROUP BY ProductProposalCountryInterestID ,
                                            [PRBSessionID]
                                 ) sfps ON sfps.ProductProposalCountryInterestID = p.PCountryInterestID
                                           AND [sfps].[PRBSessionID] = p.PRBSessionID
		
                    UPDATE  p
                    SET     SalesViewByCountry = ISNULL(svbc.TotalAmount,
                                                        'No Data Available')
                    FROM    #PRBList p
                            JOIN ( SELECT   stg.FormID ,
                                            sales.CountryID ,
                                            CAST(SUM(sales.TotalAmt) AS NVARCHAR(30)) AS TotalAmount
                                   FROM     dbo.tblStrength AS stg
                                            JOIN dbo.tblSales AS sales ON stg.StrengthID = sales.StrengthID
                                   GROUP BY stg.FormID ,
                                            sales.CountryID
                                 ) svbc ON svbc.FormID = p.FormID
                                           AND svbc.CountryID = p.CountryID
				
                    UPDATE  p
                    SET     SalesForecastVolumeByCountry = ISNULL(sfvbc.TotalVolume,
                                                              'No Data Available')
                    FROM    #PRBList p
                            JOIN ( SELECT   ProductProposalCountryInterestID ,
                                            CAST(SUM(TotalVolume) AS NVARCHAR(30)) AS TotalVolume
                                   FROM     ( SELECT    psf.ProductProposalCountryInterestID ,
                                                        MAX(psf.[ForecastVolume]
                                                            * ptd.[PackSize]) AS TotalVolume
                                              FROM      pm.ProductProposalSalesForecast psf
                                                        JOIN pm.ProductProposalTradeDress ptd ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
                                              GROUP BY  psf.ProductProposalCountryInterestID ,
                                                        ptd.[PackSize]
                                            ) AS PeakVolume
                                   GROUP BY ProductProposalCountryInterestID
                                 ) sfvbc ON sfvbc.ProductProposalCountryInterestID = p.PCountryInterestID
					
                    UPDATE  p
                    SET     ExclusivityExpiration = ee.ExpirationDate
                    FROM    #PRBList p
                            JOIN ( SELECT   CountryID ,
                                            FormID ,
                                            MIN(ExpiryDate) AS ExpirationDate
                                   FROM     pm.Exclusivity
                                   GROUP BY CountryID ,
                                            FormID
                                 ) ee ON ee.CountryID = p.CountryID
                                         AND ee.FormID = p.FormID
			
                    UPDATE  p
                    SET     PatentSummary = pa.ExpiryDate ,
                            MylanApprovalDate = l.MylanApprovalDate
                    FROM    #PRBList p
                            JOIN pm.LegalInfo l ON l.FormID = p.FormID
                                                       AND l.CountryID = p.CountryID
							LEFT JOIN pm.Patent pa ON pa.PatentID = l.BlockingPatentID
    		
                    UPDATE  p
                    SET     ExternalPartner = cc.[Name]
                    FROM    #PRBList p
                            JOIN dbo.tblCompany cc ON cc.CompanyID = p.ExternalPartnerID
			
                    UPDATE  p
                    SET     ValidLevelOfAnticipatedCompetition = vlac.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidLevelOfAnticipatedCompetition vlac ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
		
                    UPDATE  p
                    SET     ValidBDRationale = vbdr.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidBDRationale vbdr ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
			
                    UPDATE  p
                    SET     ValidBDAgreementType = vbdat.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidBDAgreementType vbdat ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
		
                    UPDATE  p
                    SET     ValidBCRADecision = vbcrad.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidBCRADecision vbcrad ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID			 

                    UPDATE  p
                    SET     OriginalBCRASession = bcras.Name
                    FROM    #PRBList p
                            JOIN dbo.tblBCRASession bcras ON bcras.BCRASessionID = p.OriginalBCRASessionID 

                    UPDATE  p
                    SET     TargetedBCRASession = bcra.Name
                    FROM    #PRBList p
                            JOIN dbo.tblBCRASession bcra ON bcra.BCRASessionID = p.TargetedBCRASessionID

                    UPDATE  p
                    SET     StrategicRationale = vsr.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidStrategicRationale vsr ON vsr.ValidStrategicRationaleID = p.ValidStrategicRationaleID

                    UPDATE  p
                    SET     MarketSegment = vms.Name
                    FROM    #PRBList p
                            JOIN dbo.tblValidMarketSegment vms ON vms.ValidMarketSegmentID = p.ValidMarketSegmentID

                    UPDATE  p
                    SET     ValidPRBDecisionID = vd.ValidPRBDecisionID
                    FROM    #PRBList p
                            JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID
			
				-- Now perform final select
                    SELECT  DISTINCT
                            p.PRBSession ,
                            p.Candidate ,
                            p.Proposal ,
                            p.ProposalStatus ,
                            p.ProposalClass ,
                            p.Product ,
                            p.Market ,
                            p.MarketSubType ,
                            p.[MakeBuy] ,
                            p.[PRBDecision] ,
                            p.Countries ,
                            p.CountryPRBDecision ,
                            p.[RegionalLevelMarketResponse] ,
                            p.[CountryLevelResponse] ,
                            p.[NoOfLicenses] ,
                            p.SalesForecastPeakSales ,
                            p.SalesViewByCountry ,
                            p.SalesForecastVolumeByCountry ,
                            p.ExclusivityExpiration ,
                            p.PatentSummary ,
                            p.MylanApprovalDate ,
                            p.MylanRequestedLaunchDate ,
                            p.[MylanGlobalComments] ,
                            p.[MylanRegionalComments] ,
                            p.RDComments ,
                            p.ExternalPartner ,
                            p.ValidLevelOfAnticipatedCompetition ,
                            p.ValidBDRationale ,
                            p.ValidBDAgreementType ,
                            p.BDTimingAdvantage ,
                            p.AnticipatedAccessFee ,
                            p.InitialTermAgreement ,
                            p.RenewalTermAgreement ,
                            p.TermAgreementComment ,
                            p.ValidBCRADecision ,
                            p.BDGeneralComment ,
                            p.OriginalBCRASession ,
                            p.TargetedBCRASession ,
                            p.StrategicRationale ,
                            p.MarketSegment ,
                            p.PECCategory ,
                            p.ProjectScopeChange ,
                            p.ProjectScopeChangeID ,
                            p.ValidCommOpsRatingID ,
                            p.ValidCommOpsRating ,
                            p.ValidTechOpsRatingID ,
                            p.ValidTechOpsRating ,
							NULL AS isExpirySummaryAllStrengths,
                            p.EHSAlert ,
                            p.OEBClassifications ,
                            p.DrugClassifications
                    FROM    #PRBList p /* JRG added for Sprint Item 577*/
                            LEFT JOIN  pm.LegalInfo l
                                       ON l.FormID = p.FormID
                                           AND l.CountryID = p.CountryID
                    WHERE   ( @FormName IS NULL
                              OR p.[Product] LIKE @FormName + '%'
                            )
                            AND ( @CountryGroupID IS NULL
                                  OR @CountryGroupID = p.[CountryGroupID]
                                )
                            AND ( @TargetPRBSessionID IS NULL
                                  OR @TargetPRBSessionID = p.[TargetPRBSessionID]
                                )
                            AND ( @ValidPRBDecisionID IS NULL
                                  OR @ValidPRBDecisionID = p.[ValidPRBDecisionID]
                                )
                            AND ( @ShowNonCandidatesOnly = 'false'
                                  OR p.[CandidateID] IS NULL
                                )
                            AND ( @ValidMakeBuyID IS NULL
                                  OR @ValidMakeBuyID = p.[ValidMakeBuyID]
                                )
                            AND p.ProposalStatus IN ( 'Complete', 'On Hold',
                                                      'Cancelled' )
                            AND [dbo].[udf_UserHasPrivForCountryGroup](@UserID,
                                                              @PrivCode,
                                                              p.[CountryGroupID]) = 'true'
                    ORDER BY p.PRBSession ,
                            p.Proposal ,
                            p.Countries
                END 
            /* JRG-2011-02-18 */
            ELSE
                IF ( @ValidProposalStatusID IS NULL
                     OR @ValidProposalStatusID > 0
                   )
                    BEGIN
                        INSERT  INTO #PRBList
                                ( PRBSessionID ,
                                  PRBSession ,
                                  Candidate ,
                                  Proposal ,
                                  ProposalStatus ,
                                  ProposalClass ,
                                  Product ,
                                  FormID ,
                                  CountryID ,
                                  Market ,
                                  MarketSubType ,
                                  ValidMakeBuyID ,
                                  MakeBuy ,
                                  PRBDecision ,
                                  Countries ,
                                  CountryPRBDecision ,
                                  RegionalLevelMarketResponse ,
                                  CountryLevelResponse ,
                                  NoOfLicenses ,
                                  SalesForecastPeakSales ,
                                  SalesViewByCountry ,
                                  SalesForecastVolumeByCountry ,
                                  ExclusivityExpiration ,
                                  PatentSummary ,
                                  MylanApprovalDate ,
                                  MylanRequestedLaunchDate ,
                                  MylanGlobalComments ,
                                  MylanRegionalComments ,
                                  RDComments ,
                                  ExternalPartner ,
                                  ValidLevelOfAnticipatedCompetition ,
                                  ValidBDRationale ,
                                  ValidBDAgreementType ,
                                  BDTimingAdvantage ,
                                  AnticipatedAccessFee ,
                                  InitialTermAgreement ,
                                  RenewalTermAgreement ,
                                  TermAgreementComment ,
                                  ValidBCRADecision ,
                                  BDGeneralComment ,
                                  OriginalBCRASession ,
                                  TargetedBCRASession ,
                                  StrategicRationale ,
                                  MarketSegment ,
                                  CountryGroupID ,
                                  TargetPRBSessionID ,
                                  ValidPRBDecisionID ,
                                  CandidateID ,
                                  ValidProposalStatusID ,
                                  ValidResponseID ,
                                  ExternalPartnerID ,
                                  ValidLevelOfAnticipatedCompetitionID ,
                                  ValidBDRationaleID ,
                                  ValidBDAgreementTypeID ,
                                  ValidBCRADecisionID ,
                                  OriginalBCRASessionID ,
                                  TargetedBCRASessionID ,
                                  ValidStrategicRationaleID ,
                                  ValidMarketSegmentID ,
                                  ValidProposalClassID ,
                                  PCountryInterestID ,
                                  PECCategory ,
                                  ProjectScopeChange ,
                                  ValidCommOpsRatingID ,
                                  ValidCommOpsRating ,
                                  ValidTechOpsRatingID ,
                                  ValidTechOpsRating ,
                                  EHSAlert ,
                                  OEBClassifications ,
                                  DrugClassifications
                                )
                                SELECT DISTINCT
                                        PRBSessionID ,
                                        PRBSession ,
                                        Candidate ,
                                        Proposal ,
                                        ProposalStatus ,
                                        ProposalClass ,
                                        Product ,
                                        FormID ,
                                        CountryID ,
                                        Market ,
                                        MarketSubType ,
                                        ValidMakeBuyID ,
                                        MakeBuy ,
                                        PRBDecision ,
                                        Countries ,
                                        CountryPRBDecision ,
                                        RegionalLevelMarketResponse ,
                                        CountryLevelResponse ,
                                        NoOfLicenses ,
                                        SalesForecastPeakSales ,
                                        SalesViewByCountry ,
                                        SalesForecastVolumeByCountry ,
                                        ExclusivityExpiration ,
                                        PatentSummary ,
                                        MylanApprovalDate ,
                                        MylanRequestedLaunchDate ,
                                        MylanGlobalComments ,
                                        MylanRegionalComments ,
                                        RDComments ,
                                        ExternalPartner ,
                                        ValidLevelOfAnticipatedCompetition ,
                                        ValidBDRationale ,
                                        ValidBDAgreementType ,
                                        BDTimingAdvantage ,
                                        AnticipatedAccessFee ,
                                        InitialTermAgreement ,
                                        RenewalTermAgreement ,
                                        TermAgreementComment ,
                                        ValidBCRADecision ,
                                        BDGeneralComment ,
                                        OriginalBCRASession ,
                                        TargetedBCRASession ,
                                        StrategicRationale ,
                                        MarketSegment ,
                                        CountryGroupID ,
                                        TargetPRBSessionID ,
                                        ValidPRBDecisionID ,
                                        CandidateID ,
                                        ValidProposalStatusID ,
                                        ValidResponseID ,
                                        ExternalPartnerID ,
                                        ValidLevelOfAnticipatedCompetitionID ,
                                        ValidBDRationaleID ,
                                        ValidBDAgreementTypeID ,
                                        ValidBCRADecisionID ,
                                        OriginalBCRASessionID ,
                                        TargetedBCRASessionID ,
                                        ValidStrategicRationaleID ,
                                        ValidMarketSegmentID ,
                                        ValidProposalClassID ,
                                        PCountryInterestID ,
                                        PECCategory ,
                                        ValidProjectScopeChange ,
                                        ValidCommOpsRatingID ,
                                        ValidCommOpsRating ,
                                        ValidTechOpsRatingID ,
                                        ValidTechOpsRating ,
                                        dbo.udf_EHSAlert(p.ProductID, NULL) AS EHSAlert ,
                                        dbo.udf_GetMPBClassifications(p.ProductID) AS OEBClassifications ,
                                        dbo.udf_GetDrugClassifications(p.ProductID) AS DrugClassifications
                                FROM    dbo.[vw_PRBCountryLevelByFilter_WithPotency] p
                                WHERE   ( @FormName IS NULL
                                          OR p.[Product] LIKE @FormName + '%'
                                        )
                                        AND ( @CountryGroupID IS NULL
                                              OR p.[CountryGroupID] = @CountryGroupID
                                            )
                                        AND ( @ValidProposalStatusID IS NULL
                                              OR p.[ValidProposalStatusID] = @ValidProposalStatusID
                                            )
                                        AND ( @TargetPRBSessionID IS NULL
                                              OR p.[TargetPRBSessionID] = @TargetPRBSessionID
                                            )
                                        AND ( @ValidPRBDecisionID IS NULL
                                              OR p.[ValidPRBDecisionID] = @ValidPRBDecisionID
                                            )
                                        AND ( @ShowNonCandidatesOnly = 'false'
                                              OR p.[CandidateID] IS NULL
                                            )
                                        AND ( @ValidMakeBuyID IS NULL
                                              OR p.[ValidMakeBuyID] = @ValidMakeBuyID
                                            )
                                        AND [dbo].[udf_UserHasPrivForCountryGroup](@UserID,
                                                              @PrivCode,
                                                              p.[CountryGroupID]) = 'true'
							
                        UPDATE  p
                        SET     ProposalStatus = bbs.StateName
                        FROM    #PRBList p
                                JOIN dbo.tblBusinessBaseStates bbs ON p.[ValidProposalStatusID] = bbs.[StateID]
			
                        UPDATE  p
                        SET     ProposalClass = vpc.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidProposalClass vpc ON vpc.ValidProposalClassID = p.ValidProposalClassID
	
                        UPDATE  p
                        SET     MakeBuy = vmb.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidMakeBuy vmb ON vmb.ValidMakeBuyID = p.ValidMakeBuyID
	
                        UPDATE  p
                        SET     PRBDecision = vd.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID
			
                        UPDATE  p
                        SET     RegionalLevelMarketResponse = vrp.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidResponse vrp ON vrp.ValidResponseID = p.ValidResponseID
			
                        UPDATE  p
                        SET     CountryLevelResponse = vrci.[Name]
                        FROM    #PRBList p
                                JOIN pm.ProductProposalCountryInterest pci ON pci.ProductProposalCountryInterestID = p.PCountryInterestID
                                JOIN dbo.tblValidResponse vrci ON vrci.ValidResponseID = pci.ValidResponseID
			
                        UPDATE  p
                        SET     SalesForecastPeakSales = ISNULL(sfps.TotalAmount,
                                                              'No Data Available')
                        FROM    #PRBList p
                                JOIN ( SELECT   ProductProposalCountryInterestID ,
                                                CAST(MAX(TotalAmount) AS NVARCHAR(30)) AS TotalAmount ,
                                                [PRBSessionID]
                                       FROM     ( SELECT    psf1.ProductProposalCountryInterestID ,
                                                            CAST(SUM(psf1.ForecastTurnover
                                                              / b.ConversionFactor2USD) AS DECIMAL(20, 5)) AS TotalAmount ,
                                                            prb.[PRBSessionID]
                                                  FROM      pm.ProductProposalSalesForecast psf1
                                                            JOIN pm.ProductProposalTradeDress ptd ON ptd.ProductProposalTradeDressID = psf1.ProductProposalTradeDressID
                                                            JOIN pm.ProductProposal prop ON prop.ProductProposalID = ptd.ProductProposalID
                                                            JOIN pm.Candidate c ON c.CandidateID = prop.CandidateID
                                                            JOIN pm.PRBSession prb ON prb.PRBSessionID = c.TargetPRBSessionID
                                                            JOIN #CurrencyFactors b ON psf1.ValidCurrencyID = b.ValidCurrencyID
                                                              AND prb.ExRateLoadID = b.ExRateLoadID
                                                  GROUP BY  psf1.ForecastYear ,
                                                            psf1.ProductProposalCountryInterestID ,
                                                            prb.[PRBSessionID]
                                                ) AS PeakSales
                                       GROUP BY ProductProposalCountryInterestID ,
                                                [PRBSessionID]
                                     ) sfps ON sfps.ProductProposalCountryInterestID = p.PCountryInterestID
                                               AND [sfps].[PRBSessionID] = p.PRBSessionID
		
                        UPDATE  p
                        SET     SalesViewByCountry = ISNULL(svbc.TotalAmount,
                                                            'No Data Available')
                        FROM    #PRBList p
                                JOIN ( SELECT   stg.FormID ,
                                                sales.CountryID ,
                                                CAST(SUM(sales.TotalAmt) AS NVARCHAR(30)) AS TotalAmount
                                       FROM     dbo.tblStrength AS stg
                                                JOIN dbo.tblSales AS sales ON stg.StrengthID = sales.StrengthID
                                       GROUP BY stg.FormID ,
                                                sales.CountryID
                                     ) svbc ON svbc.FormID = p.FormID
                                               AND svbc.CountryID = p.CountryID
				
                        UPDATE  p
                        SET     SalesForecastVolumeByCountry = ISNULL(sfvbc.TotalVolume,
                                                              'No Data Available')
                        FROM    #PRBList p
                                JOIN ( SELECT   ProductProposalCountryInterestID ,
                                                CAST(SUM(TotalVolume) AS NVARCHAR(30)) AS TotalVolume
                                       FROM     ( SELECT    psf.ProductProposalCountryInterestID ,
                                                            MAX(psf.[ForecastVolume]
                                                              * ptd.[PackSize]) AS TotalVolume
                                                  FROM      pm.ProductProposalSalesForecast psf
                                                            JOIN pm.ProductProposalTradeDress ptd ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
                                                  GROUP BY  psf.ProductProposalCountryInterestID ,
                                                            ptd.[PackSize]
                                                ) AS PeakVolume
                                       GROUP BY ProductProposalCountryInterestID
                                     ) sfvbc ON sfvbc.ProductProposalCountryInterestID = p.PCountryInterestID
					
                        UPDATE  p
                        SET     ExclusivityExpiration = ee.ExpirationDate
                        FROM    #PRBList p
                                JOIN ( SELECT   CountryID ,
                                                FormID ,
                                                MIN(ExpiryDate) AS ExpirationDate
                                       FROM     pm.Exclusivity
                                       GROUP BY CountryID ,
                                                FormID
                                     ) ee ON ee.CountryID = p.CountryID
                                             AND ee.FormID = p.FormID
			
                        UPDATE  p
                        SET     /*PatentSummary = pe.ExpiryDate ,*/
                                MylanApprovalDate = l.MylanApprovalDate
                        FROM    #PRBList p
                                JOIN pm.LegalInfo l ON l.FormID = p.FormID
                                                           AND l.CountryID = p.CountryID
               
				    /* JRG 2011-03-15 updated joins to pull correct date*/
                        UPDATE  p
                        SET     PatentSummary = p2.ExpiryDate
                        FROM    #PRBList p
                                JOIN pm.LegalInfo li ON p.FormID = li.FormID
                                                              AND p.CountryID = li.CountryID
                                JOIN pm.Patent p2 ON p2.PatentID = li.BlockingPatentID
			
                        UPDATE  p
                        SET     ExternalPartner = cc.[Name]
                        FROM    #PRBList p
                                JOIN dbo.tblCompany cc ON cc.CompanyID = p.ExternalPartnerID
			
                        UPDATE  p
                        SET     ValidLevelOfAnticipatedCompetition = vlac.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidLevelOfAnticipatedCompetition vlac ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
		
                        UPDATE  p
                        SET     ValidBDRationale = vbdr.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidBDRationale vbdr ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
			
                        UPDATE  p
                        SET     ValidBDAgreementType = vbdat.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidBDAgreementType vbdat ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
		
                        UPDATE  p
                        SET     ValidBCRADecision = vbcrad.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidBCRADecision vbcrad ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID			 

                        UPDATE  p
                        SET     OriginalBCRASession = bcras.Name
                        FROM    #PRBList p
                                JOIN dbo.tblBCRASession bcras ON bcras.BCRASessionID = p.OriginalBCRASessionID 

                        UPDATE  p
                        SET     TargetedBCRASession = bcra.Name
                        FROM    #PRBList p
                                JOIN dbo.tblBCRASession bcra ON bcra.BCRASessionID = p.TargetedBCRASessionID

                        UPDATE  p
                        SET     StrategicRationale = vsr.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidStrategicRationale vsr ON vsr.ValidStrategicRationaleID = p.ValidStrategicRationaleID

                        UPDATE  p
                        SET     MarketSegment = vms.Name
                        FROM    #PRBList p
                                JOIN dbo.tblValidMarketSegment vms ON vms.ValidMarketSegmentID = p.ValidMarketSegmentID

                        UPDATE  p
                        SET     ValidPRBDecisionID = vd.ValidPRBDecisionID
                        FROM    #PRBList p
                                JOIN dbo.tblValidPRBDecision vd ON vd.ValidPRBDecisionID = p.ValidPRBDecisionID
			
			    		-- Now perform final select
                        SELECT DISTINCT
                                p.PRBSession ,
                                p.Candidate ,
                                p.Proposal ,
                                p.ProposalStatus ,
                                p.ProposalClass ,
                                p.Product ,
                                p.Market ,
                                p.MarketSubType ,
                                p.[MakeBuy] ,
                                p.[PRBDecision] ,
                                p.Countries ,
                                p.CountryPRBDecision ,
                                p.[RegionalLevelMarketResponse] ,
                                p.[CountryLevelResponse] ,
                                p.[NoOfLicenses] ,
                                p.SalesForecastPeakSales ,
                                p.SalesViewByCountry ,
                                p.SalesForecastVolumeByCountry ,
                                p.ExclusivityExpiration ,
                                p.PatentSummary ,
                                p.MylanApprovalDate ,
                                p.MylanRequestedLaunchDate ,
                                p.[MylanGlobalComments] ,
                                p.[MylanRegionalComments] ,
                                p.RDComments ,
                                p.ExternalPartner ,
                                p.ValidLevelOfAnticipatedCompetition ,
                                p.ValidBDRationale ,
                                p.ValidBDAgreementType ,
                                p.BDTimingAdvantage ,
                                p.AnticipatedAccessFee ,
                                p.InitialTermAgreement ,
                                p.RenewalTermAgreement ,
                                p.TermAgreementComment ,
                                p.ValidBCRADecision ,
                                p.BDGeneralComment ,
                                p.OriginalBCRASession ,
                                p.TargetedBCRASession ,
                                p.StrategicRationale ,
                                p.MarketSegment ,
                                p.PECCategory ,
                                p.ProjectScopeChange ,
                                p.ProjectScopeChangeID ,
                                p.ValidCommOpsRatingID ,
                                p.ValidCommOpsRating ,
                                p.ValidTechOpsRatingID ,
                                p.ValidTechOpsRating ,
								NULL AS isExpirySummaryAllStrengths,
                                p.EHSAlert ,
                                p.OEBClassifications ,
                                p.DrugClassifications
                        FROM    #PRBList p /* JRG added for Sprint Item 577*/
                                LEFT JOIN pm.LegalInfo l
                                           ON l.FormID = p.FormID
                                               AND l.CountryID = p.CountryID
                        ORDER BY p.PRBSession ,
                                p.Proposal ,
                                p.Countries
                    END 
                ELSE
                    BEGIN
	                   /* JRG added this to logic to complete the else if change from single if statements */
                        RAISERROR('@ValidProposalStatusID parameter was out of expected range', 0, 42) WITH NOWAIT;

                        RETURN 1;
                    END
        DROP TABLE #PRBList

    END TRY
    BEGIN CATCH
        EXECUTE dbo.sp_RollAndRaise
    END CATCH
GO
