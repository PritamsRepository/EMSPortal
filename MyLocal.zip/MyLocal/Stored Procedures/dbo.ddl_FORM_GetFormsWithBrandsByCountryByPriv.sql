SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------


Create Procedure [dbo].[ddl_FORM_GetFormsWithBrandsByCountryByPriv]
		@UserID int = NULL,
		@PrivCode nvarchar(10)= NULL,
		@CountryCode nvarchar(2) = NULL
AS
/**********************************************************************************
CREATED BY:			Scott M. Dexter:	Software Specialists Consultant
CREATED DATE:		NOV 03, 2009
MODIFIED BY:
MODIFIED DATE:
PURPOSE:			The purpose of this script is to retrieve a list of 
					Form Names and IDs with brands, by country and by 
					privilages into a drop down list, hense the ddl_ prefix.

SAMPLE USAGE:		EXEC [dbo].[ddl_FORM_GetFormsWithBrandsByCountryByPriv] 
					@USERID = 4, @PrivCode = 'ADM01', @CountryCode = 'AF'

**********************************************************************************/

BEGIN TRY 

		SELECT 
			f.FormID, 
			f.Name

		FROM 
			tblBrand b INNER JOIN tblCountry c on
			b.CountryID = c.CountryID INNER JOIN tblForm f ON
			b.FormID = f.FormID
		WHERE
			c.Code = @CountryCode AND
			[dbo].[udf_UserHasPriv]( @UserID, @Privcode) = 'true'

		ORDER BY
			f.Name


END TRY


BEGIN CATCH
	EXECUTE [dbo].[SP_RollAndRaise]
END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_FORM_GetFormsWithBrandsByCountryByPriv] TO [mp_db_execute]
GO
