SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[admin_UserHasPrivs]
    @UserID INT,
    @PrivCodes NVARCHAR(1000),    
    @Result BIT OUTPUT
    
AS 

BEGIN TRY

  SET @Result = 0;
  
  IF(@PrivCodes IS NOT NULL AND @UserID IS NOT NULL)
  BEGIN

	DECLARE @PrivCodeList TABLE ( Value NVARCHAR(20) );
    
	INSERT INTO @PrivCodeList SELECT DISTINCT Value FROM dbo.udf_inline_split_list_characters(@PrivCodes, ',');

	DECLARE @HasPrivCount INT =
	(
	  SELECT
		COUNT(p.PrivCode)
	  FROM
	  (
		SELECT DISTINCT
		  sp.PrivCode
		FROM
		  dbo.admin_SecPriv AS sp
			JOIN dbo.admin_SecRolePriv AS srp ON sp.PrivID = srp.PrivID
			JOIN dbo.admin_SecRole AS sr ON srp.RoleID = sr.RoleID
			JOIN dbo.admin_SecUserRole AS sur ON sr.RoleID = sur.RoleID
			JOIN @PrivCodeList pl ON sp.PrivCode = pl.Value
		WHERE
		  sur.[UserID] = @UserID
	  ) p
	);

	IF (@HasPrivCount = (SELECT COUNT(Value) FROM @PrivCodeList))
	BEGIN
	  SET @Result = 1;
	END
	
  END

  RETURN @Result;          

END TRY
BEGIN CATCH
  EXEC dbo.sp_RollAndRaise
END CATCH
GO
GRANT EXECUTE ON  [dbo].[admin_UserHasPrivs] TO [mp_db_execute]
GO
