SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_SubmissionRoute_AllSubmissionRoutes]
AS 
BEGIN TRY

  SELECT DISTINCT
	sr.SubmissionRouteID,
    sr.Name
  FROM
	dbo.tblSubmissionRoute sr
  WHERE
	sr.IsActive = 1	
  ORDER BY
	sr.Name

END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_SubmissionRoute_AllSubmissionRoutes] TO [mp_db_execute]
GO
