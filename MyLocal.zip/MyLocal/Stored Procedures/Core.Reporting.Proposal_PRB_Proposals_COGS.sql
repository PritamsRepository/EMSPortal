SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[Proposal_PRB_Proposals_COGS]
    @UserID INT = NULL,
    @PrivCode NVARCHAR(10) = NULL,
    @TargetPRBSessionID INT = NULL,
    @ProposalID INT = NULL,
    @FormName NVARCHAR(256) = NULL,
    @CountryGroupID INT = NULL,
    @ValidProposalStatusID INT = NULL,
    @ValidPRBDecisionID INT = NULL,
    @ValidMakeBuyID INT = NULL,
    @ShowNonCandidatesOnly BIT = 0,
    @MarketResponseIDs NVARCHAR(100) = NULL
AS
SET NOCOUNT ON;

BEGIN TRY;

    --IF (@ProposalID IS NOT NULL)
    --BEGIN
    --    SELECT NULL AS TargetPRBSessionID,
    --           @ProposalID AS ProposalID;
    --END;
    --ELSE
    --BEGIN
    DECLARE @MarketResponseIDsTbl AS ValidResponseType;
    INSERT INTO @MarketResponseIDsTbl
    SELECT id
    FROM dbo.udf_GetValuesFromCSV(@MarketResponseIDs);

    SELECT DISTINCT
           can.TargetPRBSessionID,
           prb.Name AS PRBSessionName,
           can.CandidateID,
           --p.ProductProposalID AS ProposalID,
           cls.CandidateLinkStrengthID,
           f.Name + ' ' + s.Name AS Strength,
           cls.APICost,
           cls.ExcipientsCost,
           cls.PackagingCost,
           cls.SiteCost,
           cls.DeviceCost,
           --cls.TotalCostPerUnitRDFinance,
           cls.CostOfGoods,
           COALESCE(cls.APICost, 0) + COALESCE(cls.ExcipientsCost, 0) + COALESCE(cls.PackagingCost, 0)
           + COALESCE(cls.SiteCost, 0) + COALESCE(cls.DeviceCost, 0) AS TotalCostPerUnitGPSEstimate,
           vcogs.Name AS COGSource
    FROM pm.ProductProposal p
        JOIN dbo.tblForm f
            ON p.FormID = f.FormID
        JOIN dbo.tblCountryGroup AS cg
            ON cg.CountryGroupID = p.CountryGroupID
        JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
            ON a.CountryGroupID = cg.[CountryGroupID]
               AND a.Privs = 1
        JOIN dbo.tblBusinessBaseStates AS bbs
            ON p.StatusID = bbs.StateID
        JOIN pm.ProductProposalCountryInterest ci
            ON ci.ProductProposalID = p.ProductProposalID
        JOIN pm.Candidate AS can
            ON p.CandidateID = can.CandidateID
        JOIN pm.CandidateLinkStrength cls
            ON cls.CandidateID = can.CandidateID
        JOIN dbo.tblStrength s
            ON s.StrengthID = cls.StrengthID
        LEFT JOIN dbo.tblValidCOGSource vcogs
            ON vcogs.ValidCOGSourceID = cls.ValidCOGSourceID
        LEFT OUTER JOIN pm.PRBSession AS prb
            ON can.TargetPRBSessionID = prb.PRBSessionID
        LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd
            ON prbd.ValidPRBDecisionID = ci.ValidPRBDecisionID
    WHERE (
              @FormName IS NULL
              OR f.Name LIKE @FormName
          )
          AND
          (
              @CountryGroupID IS NULL
              OR @CountryGroupID = cg.CountryGroupID
          )
          AND
          (
              @MarketResponseIDs IS NULL
              OR ci.ValidResponseID IN
                 (
                     SELECT ValidResponseID FROM @MarketResponseIDsTbl
                 )
          )
          AND
          (
              @TargetPRBSessionID IS NULL
              OR @TargetPRBSessionID = can.TargetPRBSessionID
          )
          AND
          (
              @ValidPRBDecisionID IS NULL
              OR @ValidPRBDecisionID = prbd.ValidPRBDecisionID
          )
          AND
          (
              @ShowNonCandidatesOnly = 0
              OR p.CandidateID IS NULL
          )
          AND
          (
              @ValidMakeBuyID IS NULL
              OR @ValidMakeBuyID = ci.ValidMakeBuyID
          )
          AND
          (
              @ValidProposalStatusID IS NULL
              OR p.StatusID = @ValidProposalStatusID
          )
    ORDER BY f.Name + ' ' + s.Name;

--END;

END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
