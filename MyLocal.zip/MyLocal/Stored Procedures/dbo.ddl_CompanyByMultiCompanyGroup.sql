SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_CompanyByMultiCompanyGroup]
    (
      @CompanyGroups NVARCHAR(255) )
AS /**********************************************************************************
ARD; DropDown to get all the Companies for a list of Company Groups
*********************************************************************************
Update by JRg
Date Nov 15, 2010
Re-wrote dynamic sql use inline function 

*/

    BEGIN TRY 
        SET NOCOUNT ON

        SELECT DISTINCT
                c.Name ,
                c.CompanyID AS ID
        FROM    tblCompany c
                INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                INNER JOIN tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
                JOIN ( SELECT   Value
                       FROM     dbo.udf_inline_split_list_characters(@CompanyGroups, '|') ) tcg ON cg.Text = tcg.value
        GROUP BY c.Name ,
                c.CompanyID
        ORDER BY c.Name


    END TRY


    BEGIN CATCH
        EXECUTE [dbo].[sp_RollAndRaise]
    END CATCH





GO
GRANT EXECUTE ON  [dbo].[ddl_CompanyByMultiCompanyGroup] TO [mp_db_execute]
GO
