SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MAStrength_ByMAApplicationByMAStrength]
    @MAApplicationID INT 
AS /* 
	Author:	JRG
	Date:	13-Sep-2011
	Description: Provide a list of MAStrengths that can be used to add packaging
	
	
	*/
    BEGIN TRY	
    
    SELECT  DISTINCT MAS.MAStrengthID ,/* need MAStrength not the Strength ID*/
                F.Name + ' ' + S.Name AS Product
                FROM    dbo.tblMAStrength MAS
                       JOIN dbo.tblStrength S ON MAS.StrengthID = S.StrengthID
                       JOIN dbo.tblForm F ON S.FormID = F.FormID 
                       JOIN tblMAApplication MAA on MAA.MAApplicationID=@MAApplicationID AND MAA.ProductGroupID = F.ProductID  AND MAS.MAApplicationID=MAA.MAApplicationID
                       

	
    END TRY

    BEGIN CATCH 
        EXEC dbo.sp_RollAndRaise
    END CATCH 






GO
GRANT EXECUTE ON  [dbo].[ddl_MAStrength_ByMAApplicationByMAStrength] TO [mp_db_execute]
GO
