SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

--EXEC [Core.Reporting].[usp_REPORT_TPDSheets_Patents] 653, 1426, 'MA01'

/*------------------------------------------------------------------------------------------------------------------------
-- ALTERED SCRIPT:		ANDREW DECKER APPLICATION ENGINEER
-- MODIFIED DATE:		2009-11-03
-- MODIFIED FOR:		ADDED FORMID PARAM to STRENGTHLIST function
---------------------------------------------------------------------------------------  
-- Date 04/30/2010 | JRG-1 | Modify for SDLC 430 DBR 656 | Modify sp    
---------------------------------------------------------------------------------------  
 
MODIFIED DATE:	6/3/2010
MODIFIED BY:	Robin Abramson

Modification:	Altered to accept formID parameter for udf_PatentSummaryAllStrengths and renamed to 
				udf_PatentFormUseCodeSummary.

------------------------------------------------------------------------------------------------------------------------*/
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_TPDSheets_Patents]
    @FormID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN TRY

    SELECT DISTINCT
           p.[PatentID],
           c.[Code] AS Country,
           p.[PatentNum],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + vpt.Name
                        FROM pm.PatentLinkValidPatentType plvpt
                            JOIN dbo.tblValidPatentType vpt
                                ON vpt.ValidPatentTypeID = plvpt.ValidPatentTypeID
                        WHERE plvpt.PatentID = p.PatentID
                        ORDER BY ', ' + vpt.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    2,
                    ''
                ) AS PatentType,
           STUFF(
           (
               SELECT ', ' + vos.Name
               FROM dbo.tblValidStudyStatus vos
                   JOIN pm.LegalInfoLinkPatent link
                       ON link.ValidOpinionStatusID = vos.ValidStudyStatusID
               WHERE link.PatentID = p.PatentID
               ORDER BY ', ' + vos.Name
               FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
           1,
           2,
           ''
                ) AS PatentOpinionStatus,
           p.[Description],
           [dbo].[udf_StrengthListByPatentID](p.[PatentID], s.[FormID]) AS Strengths,
           STUFF(
           (
               SELECT ', ' + vcs.Name
               FROM dbo.tblValidCertStrategy vcs
                   JOIN pm.LegalInfoLinkPatentLinkValidCertStrategy link
                       ON link.ValidCertStrategyID = vcs.ValidCertStrategyID
                   JOIN pm.LegalInfoLinkPatent lilp
                       ON link.LegalInfoLinkPatentID = lilp.LegalInfoLinkPatentID
               WHERE lilp.PatentID = p.PatentID
               ORDER BY vcs.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentStrategy,
                      STUFF(
           (
               SELECT '<br/>' + link.OpinionComments
               FROM pm.LegalInfoLinkPatent link
               WHERE link.PatentID = p.PatentID
               ORDER BY '<br/>' + link.OpinionComments
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
           1,
           5,
           ''
                ) AS PatentOpinion,
           STUFF(
                    (
                        SELECT DISTINCT
                               '<br/>' + vc.Name
                        FROM dbo.tblValidCert vc
                            JOIN pm.LegalInfoLinkPatentLinkValidCert plvc
                                ON plvc.ValidCertID = vc.ValidCertID
                            JOIN pm.LegalInfoLinkPatent lp
                                ON lp.LegalInfoLinkPatentID = plvc.LegalInfoLinkPatentID
                        WHERE lp.PatentID = p.PatentID
                        ORDER BY '<br/>' + vc.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    5,
                    ''
                ) AS PatentCert,
           p.ExpiryDate AS ExpiryWithRationale,
		   		   		   STUFF(
           (
               SELECT ', ' + vpt.Name
               FROM pm.PatentLinkValidExpiryRationale lvpt
                   JOIN dbo.tblValidExpiryRationale vpt ON vpt.ValidExpiryRationaleID = lvpt.ValidExpiryRationaleID
               WHERE lvpt.PatentID = p.PatentID
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Rationales
    FROM pm.PatentFamilyLinkForm pflf
        JOIN pm.Patent p
            ON pflf.PatentFamilyID = p.PatentFamilyID
        JOIN [dbo].[tblStrength] AS s
            ON pflf.FormID = s.FormID
               AND dbo.udf_PatentIsListedForForm(@FormID, p.[PatentID]) = 'true'
        JOIN dbo.tblCountry c
            ON p.CountryID = c.CountryID
    WHERE s.[FormID] = @FormID
          AND c.[Code] = 'CA'
          AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
    ORDER BY p.[PatentNum];

END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
