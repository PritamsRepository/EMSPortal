SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetCountryGroupsByFilter]
	@Name nvarchar(256) = NULL,
	@Type nvarchar(256) = NULL,
  @UserID INT, @PrivCode NVARCHAR(20)
AS
	SELECT 
		cg.CountryGroupID, cg.[Name]
	FROM 
		dbo.tblCountryGroup cg
		JOIN udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) uhp ON cg.CountryGroupID = uhp.CountryGroupID AND uhp.Privs = 1
	WHERE 
		(@Name is NULL or cg.NAME LIKE '%' + @Name + '%') AND
		(@Type is NULL or cg.CountryGroupType = @Type) AND  
		isActive = 1  
		

GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetCountryGroupsByFilter] TO [mp_db_execute]
GO
