SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[admin_UserGridLayout_GetByID]
    @UserGridLayoutID INT
AS
    SELECT  UserGridLayoutID ,
            UserID ,
            GridName ,
            ControllerName ,
            isDefault ,
            Label ,
            Settings ,
            ConcurrencyID
    FROM    dbo.admin_UserGridLayout
    WHERE   UserGridLayoutID = @UserGridLayoutID
GO
