SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_PATCERTREV_Patents]
    @FormID INT,
    @CountryID INT,
    @IsListed BIT,
    @IsApplication BIT = NULL,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN TRY

    SELECT DISTINCT
           [p].[PatentID],
           [c].[Code] AS Country,
           [p].[PatentNum],
           [p].[Description],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + s.Name
                        FROM pm.Patent p
                            JOIN pm.PatentFamily pf
                                ON pf.PatentFamilyID = p.PatentFamilyID
                            JOIN pm.PatentFamilyLinkForm pflf
                                ON pf.PatentFamilyID = pflf.PatentFamilyID
                            JOIN dbo.tblStrength s
                                ON pflf.FormID = s.FormID
                        WHERE pflf.FormID = @FormID
                              AND s.IsUndefined = 0
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'VARCHAR(Max)'),
                    1,
                    1,
                    ''
                ) AS Strengths,
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + vpt.Name
                        FROM pm.PatentLinkValidPatentType plvpt
                            JOIN dbo.tblValidPatentType vpt
                                ON vpt.ValidPatentTypeID = plvpt.ValidPatentTypeID
                        WHERE plvpt.PatentID = p.PatentID
                        ORDER BY ', ' + vpt.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    2,
                    ''
                ) AS PatentType,
           STUFF(
           (
               SELECT ', ' + vcs.Name
               FROM dbo.tblValidCertStrategy vcs
                   JOIN pm.LegalInfoLinkPatentLinkValidCertStrategy link
                       ON link.ValidCertStrategyID = vcs.ValidCertStrategyID
                   JOIN pm.LegalInfoLinkPatent lilp
                       ON lilp.LegalInfoLinkPatentID = link.LegalInfoLinkPatentID
               WHERE lilp.PatentID = p.PatentID
               ORDER BY vcs.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentStrategy,
           STUFF(
           (
               SELECT ', ' + lilp.OpinionComments
               FROM pm.LegalInfoLinkPatent lilp
               WHERE lilp.PatentID = p.PatentID
               ORDER BY ', ' + lilp.OpinionComments
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentOpinion,
           STUFF(
           (
               SELECT ', ' + lilp.PatentComments
               FROM pm.LegalInfoLinkPatent lilp
               WHERE lilp.PatentID = p.PatentID
               ORDER BY ', ' + lilp.PatentComments
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS PatentComments,
           STUFF(
                    (
                        SELECT DISTINCT
                               '<br/>' + vc.Name
                        FROM dbo.tblValidCert vc
                            JOIN pm.LegalInfoLinkPatentLinkValidCert plvc
                                ON plvc.ValidCertID = vc.ValidCertID
                            JOIN pm.LegalInfoLinkPatent lp
                                ON lp.LegalInfoLinkPatentID = plvc.LegalInfoLinkPatentID
                        WHERE lp.PatentID = p.PatentID
                        ORDER BY '<br/>' + vc.Name
                        FOR XML PATH(''), ROOT('mystring'), TYPE
                    ).value('/mystring[1]', 'varchar(max)'),
                    1,
                    5,
                    ''
                ) AS PatentCert,
           --[dbo].[udf_PatentCertStrategyListByPatentID](p.[PatentID]) AS PatentStrategy,
           CAST(link.IsListed AS BIT) AS PatentIsListed,
           p.ExpiryDate AS ExpiryWithRationale,
		   		   		   STUFF(
           (
               SELECT ', ' + vpt.Name
               FROM pm.PatentLinkValidExpiryRationale lvpt
                   JOIN dbo.tblValidExpiryRationale vpt ON vpt.ValidExpiryRationaleID = lvpt.ValidExpiryRationaleID
               WHERE lvpt.PatentID = p.PatentID
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Rationales
    FROM pm.PatentFamilyLinkForm pflf
        JOIN pm.Patent p
            ON pflf.PatentFamilyID = p.PatentFamilyID
        JOIN dbo.tblStrength s
            ON pflf.FormID = s.FormID
        JOIN dbo.tblForm f
            ON s.FormID = f.FormID
        JOIN dbo.tblCountry c
            ON p.CountryID = c.CountryID
        LEFT JOIN pm.PatentLinkStrength AS link
            ON s.[StrengthID] = link.[StrengthID]
               AND p.PatentID = link.PatentID
    WHERE (
              (
                  @IsListed = 1
                  AND p.PatentID IN
                      (
                          SELECT PatentID
                          FROM pm.PatentLinkStrength slp
                          WHERE slp.StrengthID = s.StrengthID
                                AND p.PatentID = slp.PatentID
                      )
              )
              OR
              (
                  @IsListed = 0
                  AND p.PatentID NOT IN
                      (
                          SELECT p.PatentID
                          FROM pm.PatentLinkStrength slp
                              JOIN pm.Patent p2
                                  ON slp.PatentID = p2.PatentID
                              JOIN dbo.tblStrength s2
                                  ON slp.StrengthID = s2.StrengthID
                              JOIN dbo.tblForm f2
                                  ON s2.FormID = f2.FormID
                          WHERE s2.StrengthID = slp.StrengthID
                                AND p.PatentID = slp.PatentID
                                AND f2.FormID = f.FormID
                      )
              )
          )
          AND
          (
              @IsApplication IS NULL
              OR p.[IsApplication] = @IsApplication
          )
          AND f.[FormID] = @FormID
          AND c.CountryID = @CountryID
          AND s.IsUndefined = 0
          AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
    ORDER BY p.[PatentNum];

END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
