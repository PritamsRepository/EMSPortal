SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Product]
AS
BEGIN

    SELECT p.ProductID,
           p.Name AS Product
    FROM dbo.tblProduct p
    ORDER BY p.ProductID;
END;
GO
