SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MA_AddAPI_Manufacturer] @MAApplicationID INT
AS 
    BEGIN TRY 
        DECLARE @VSTID INT
        SET @VSTID = ( SELECT   ST.ValidSiteTypeID
                       FROM     dbo.tblValidSiteType ST
                       WHERE    ST.NAME = 'API Manufacturer' )
                       
	DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
	DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';
	
	SELECT
		(
			CASE 
			  WHEN c.Name = @PrimarySortPriority THEN 0
			  WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
			  ELSE 2 
			  END
		  ) AS SortPriority,
		  MAS.MASiteID ID ,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS Name
		  FROM    dbo.tblMASite MAS
		        JOIN dbo.tblMAApplication MA ON MAS.MAApplicationID = MA.MAApplicationID
                                                AND MA.MAApplicationID = @MAApplicationID
                JOIN dbo.tblCompany C ON MAS.CompanyID = C.CompanyID
                JOIN dbo.tblValidSiteType VST ON MAS.ValidSiteTypeID = VST.ValidSiteTypeID
                                                 AND VST.ValidSiteTypeID = @VSTID
			ORDER BY SortPriority, Name
	
    END TRY 
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_MA_AddAPI_Manufacturer] TO [mp_db_execute]
GO
