SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
Create Procedure [dbo].[ddl_GetLeadsByBBO]
 @BBOCode NVARCHAR(50)=NULL,
 @BBOID INT =NULL
AS
 
/*
 
CREATED BY:			JRG
CREATED DATE:		DEC 06, 2010
 
Sprint Item:		
PURPOSE:
 
 
 
*/
 
BEGIN TRY
 SELECT DISTINCT
		T.BBOID ,
        BBO.BBOCode ,
        SU.UserID AS ID ,
        SU.FullName AS [Name]
FROM    admin_SecUserLinkTeam SULT
        JOIN admin_SecUser SU ON SU.UserID = SULT.UserID
        JOIN dbo.tblTeam T ON SULT.TeamID = T.TeamID
        JOIN dbo.tblBusinessBaseObject BBO ON T.BBOID = BBO.BBOID
WHERE   IsManager = 1
 AND (@BBOCode IS NULL OR BBO.BBOCode = @BBOCode)
 AND (@BBOID IS NULL OR BBO.BBOID = @BBOID)
 
END TRY
 
 
BEGIN CATCH
	EXEC SP_ROLLANDRAISE
END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_GetLeadsByBBO] TO [mp_db_execute]
GO
