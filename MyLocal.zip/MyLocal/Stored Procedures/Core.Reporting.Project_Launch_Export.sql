SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[Project_Launch_Export]
    @ID INT = NULL ,
    @DevWorkstreamID INT = NULL ,
    @TradeDressWorkstreamID INT = NULL ,
    @ProductGroupID INT = NULL ,
    @FormFiltersList NVARCHAR(MAX) = NULL ,
    @CountryGroupFiltersList NVARCHAR(MAX) = NULL ,
    @CountryFiltersList NVARCHAR(MAX) = NULL ,
    @BBOTagFiltersList NVARCHAR(MAX) = NULL ,
    @ValidProjectTypeFiltersList NVARCHAR(MAX) = NULL ,
    @SubmissionYearFiltersList NVARCHAR(MAX) = NULL ,
    @ProjectLeadID INT = NULL ,
    @FocusNumber NVARCHAR(10) = NULL ,
    @EvaluationDateStart DATETIME = NULL ,
    @EvaluationDateEnd DATETIME = NULL ,
    @ValidWorkPlanID INT = NULL ,
    @ValidTechOpsRatingFiltersList NVARCHAR(MAX) = NULL ,
    @ValidOpportunityTypeFiltersList NVARCHAR(MAX) = NULL ,
    @ProjectStatusID INT = NULL ,
    @ParentID INT = NULL ,
    @ParentType INT = NULL ,
    @UserId INT ,
    @PrivCode NVARCHAR(10) ,
    @SiteCompanyGroupsFiltersList NVARCHAR(MAX) = NULL ,
    @SiteFiltersList NVARCHAR(MAX) = NULL ,
    @SiteNameFiltersInclusionID INT = 1 ,
    @FormFiltersInclusionID INT = 1 ,
    @CountryGroupFiltersInclusionID INT = 1 ,
    @CountryFiltersInclusionID INT = 1 ,
    @BBOTagFiltersInclusionID INT = 1 ,
    @ValidProjectTypeFiltersInclusionID INT = 1 ,
    @SubmissionYearFiltersInclusionID INT = 1 ,
    @ProjectLeadInclusionID INT = 1 ,
    @ValidTechOpsRatingFiltersInclusionID INT = 1 ,
    @ValidOpportunityTypeFiltersInclusionID INT = 1 ,
    @ProjectStatusInclusionID INT = 1 ,
    @ProjectTeamRoleFiltersList NVARCHAR(256) = NULL ,
    @TeamMemberFiltersList NVARCHAR(MAX) = NULL ,
    @TeamMemberFiltersInclusionID INT = 1 ,
    @AlertTypesFiltersList NVARCHAR(MAX) = NULL ,
    @AlertTypesInclusionID INT = 1
AS /* Get Top 5 Comments */
    IF EXISTS ( SELECT  *
                FROM    tempdb.dbo.sysobjects
                WHERE   ID = OBJECT_ID(N'tempdb..#LaunchProjComments') )
        BEGIN
            DROP TABLE #LaunchProjComments
        END
    IF EXISTS ( SELECT  *
                FROM    tempdb.dbo.sysobjects
                WHERE   ID = OBJECT_ID(N'tempdb..#LCPPivot') )
        BEGIN
            DROP TABLE #LCPPivot
        END

    DECLARE @SiteFilters IdType
    DECLARE @CommentCategory NVARCHAR(20) = 'Launch'
    DECLARE @BBOID INT = ( SELECT   BBOID
                           FROM     dbo.tblBusinessBaseObject
                           WHERE    BBOCode = 'PJM'
                         )
    DECLARE @PROJLNCHBBOID INT = ( SELECT   BBOID
                                   FROM     dbo.tblBusinessBaseObject
                                   WHERE    BBOCode = 'ProjLnch'
                                 )
    DECLARE @PWBBOID INT = ( SELECT BBOID
                             FROM   dbo.tblBusinessBaseObject
                             WHERE  BBOCode = 'PVW'
                           );
    DECLARE @SWBBOID INT = ( SELECT BBOID
                             FROM   dbo.tblBusinessBaseObject
                             WHERE  BBOCode = 'SW'
                           );
    DECLARE @PLWBBOID INT = ( SELECT    BBOID
                              FROM      dbo.tblBusinessBaseObject
                              WHERE     BBOCode = 'PLW'
                            );
    DECLARE @TDWBBOID INT = ( SELECT    BBOID
                              FROM      dbo.tblBusinessBaseObject
                              WHERE     BBOCode = 'TDW'
                            );
    DECLARE @IncludeScaleUpSites INT = CHARINDEX('Scale Up Site',
                                                 @SiteCompanyGroupsFiltersList)
    DECLARE @IncludeDevelopmentSites INT = CHARINDEX('Development Site',
                                                     @SiteCompanyGroupsFiltersList)
    DECLARE @IncludePackagingSites INT = CHARINDEX('Packaging Site',
                                                   @SiteCompanyGroupsFiltersList)
    DECLARE @IncludeManufacturingSites INT = CHARINDEX('Manufacturing Site',
                                                       @SiteCompanyGroupsFiltersList)

    IF LEN(@SiteFiltersList) > 0
        INSERT  @SiteFilters
                ( id
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@SiteFiltersList)
    CREATE TABLE #LaunchProjComments
        (
          ProjectID INT ,
          [Comment] NVARCHAR(MAX) NULL ,
          commentNumber INT NULL
        )
    CREATE CLUSTERED INDEX IX_temp_01 ON #LaunchProjComments ( commentNumber, ProjectID );
    WITH    tbxProject ( ProjectID, Comment, CommentDate, CommentID )
              AS ( SELECT TOP ( 100 ) PERCENT
                            ProjectID ,
                            c.Comment ,
                            CommentDate ,
                            c.CommentID
                   FROM     [pm].ProjectLaunchInfo p
                            JOIN [dbo].tblComment c ON c.ObjectID = p.ProjectID
                                                       --AND c.Category = @CommentCategory
                                                       AND c.BBOID = @PROJLNCHBBOID
                   ORDER BY ProjectID DESC ,
                            CommentDate DESC
                 )
        INSERT  INTO #LaunchProjComments
                ( ProjectID ,
                  Comment ,
                  commentNumber 
                )
                SELECT  ProjectID ,
                        Comment ,
                        ( SELECT    COUNT(*) + 1
                          FROM      tbxProject y
                          WHERE     ( ( y.CommentDate < tbxProject.CommentDate )
                                      OR ( y.CommentDate = tbxProject.CommentDate
                                           AND y.CommentID < tbxProject.CommentID
                                         )
                                    )
                                    AND y.ProjectID = tbxProject.ProjectID
                        ) AS CommentNum
                FROM    tbxProject;

    CREATE TABLE #LCPPivot
        (
          ProjectID INT ,
          Comment1 NVARCHAR(MAX) NULL ,
          Comment2 NVARCHAR(MAX) NULL ,
          Comment3 NVARCHAR(MAX) NULL ,
          Comment4 NVARCHAR(MAX) NULL ,
          Comment5 NVARCHAR(MAX) NULL
        );
 
    INSERT  INTO #LCPPivot
            SELECT  ProjectID ,
                    [1] ,
                    [2] ,
                    [3] ,
                    [4] ,
                    [5]
            FROM    #LaunchProjComments PIVOT ( MAX(Comment) FOR CommentNumber IN ( [1],
                                                              [2], [3], [4],
                                                              [5] ) ) AS pt
            ORDER BY ProjectID

    DECLARE @CountryGroupFilters AS CountryGroupType
    DECLARE @CountryFilters AS CountryType
    DECLARE @BBOTagFilters BBOTagType
    DECLARE @ValidProjectTypeFilters AS ValidProjectTypeType
    DECLARE @SubmissionYearFilters TimeframeType
    DECLARE @ValidOpportunityTypeFilters AS ValidOpportunityTypeType
    DECLARE @FormFilters FormType
    DECLARE @ValidTechOpsRatingFilters ValidTechOpsRatingType
    DECLARE @TeamMembers IdType
    DECLARE @AlertTypesList IdType
            
    --@CountryFiltersList NVARCHAR(MAX) = NULL,
    IF LEN(@CountryFiltersList) > 0
        INSERT  @CountryFilters
                ( CountryID
                
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@CountryFiltersList)
			  
    IF LEN(@CountryGroupFiltersList) > 0
        INSERT  @CountryGroupFilters
                ( CountryGroupID
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList)
			 
    IF LEN(@BBOTagFiltersList) > 0
        INSERT  @BBOTagFilters
                ( BBOTagID
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@BBOTagFiltersList)
		
    IF LEN(@ValidProjectTypeFiltersList) > 0
        INSERT  @ValidProjectTypeFilters
                ( ValidProjectTypeID
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@ValidProjectTypeFiltersList)
			 
    IF LEN(@SubmissionYearFiltersList) > 0
        INSERT  @SubmissionYearFilters
                ( Timeframe
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList)
			 
    IF LEN(@ValidOpportunityTypeFiltersList) > 0
        INSERT  @ValidOpportunityTypeFilters
                ( ValidOpportunityTypeID
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@ValidOpportunityTypeFiltersList)	
	
    IF LEN(@ValidTechOpsRatingFiltersList) > 0
        INSERT  @ValidTechOpsRatingFilters
                ( ValidTechOpsRatingID
					
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@ValidTechOpsRatingFiltersList)
							 
    IF LEN(@FormFiltersList) > 0
        INSERT  @FormFilters
                ( FormID
                    
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@FormFiltersList);

    IF LEN(@TeamMemberFiltersList) > 0
        INSERT  @TeamMembers
                ( ID
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@TeamMemberFiltersList);

    IF LEN(@AlertTypesFiltersList) > 0
        INSERT  @AlertTypesList
                ( ID
                )
                SELECT  *
                FROM    dbo.udf_GetValuesFromCSV(@AlertTypesFiltersList);
                    
/* **************** */
    SELECT DISTINCT
            p.ProjectID AS [ID] ,
            p.ProjectName AS [Name] ,
            vpt.Name AS [Project Type] ,
            f.Name AS [Product] ,
            f.FormID AS [FormID] ,
            cg.Name AS [Region] ,
            cg.CountryGroupID AS [CountryGroupID] ,
            STUFF((SELECT   ', ' + c.Name + ' [' + bbs.StateName + ']'
                   FROM     pm.PivotalWorkstreamLinkProject pwlp
                            JOIN pm.PivotalWorkstream pw ON pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                            JOIN tblcompany c ON pw.DevSiteID = c.CompanyID
                            JOIN dbo.tblBusinessBaseStates bbs ON pw.PivotalWorkstreamStatusID = bbs.StateID
                   WHERE    pwlp.ProjectID = p.ProjectID
                   ORDER BY ', ' + c.NAME + ' [' + bbs.StateName + ']'
            FOR   XML PATH('') ,
                      TYPE).value('.[1]', 'varchar(MAX)'), 1, 2, '') AS [Pivotal Development Site] ,
            STUFF((SELECT   ', ' + s.name
                   FROM     pm.ProjectStrength ps
                            JOIN dbo.tblStrength s ON ps.StrengthID = s.StrengthID
                                                      AND ps.ProjectID = p.ProjectID
                   WHERE    s.IsUndefined = 0
                   ORDER BY s.Name
            FOR   XML PATH('') ,
                      TYPE).value('.[1]', 'varchar(MAX)'), 1, 2, '') AS [Strengths] ,
            bbs.StateName AS [Status] ,
            STUFF((SELECT   DISTINCT
                            ', ' + COALESCE(asu.FullName, asu.ADUserName)
                   FROM     admin_secuser asu
                            JOIN dbo.tblMAApplication ma ON asu.UserID = ma.RegulatoryLeadID
                            JOIN dbo.MASubmissionWorkstream masw ON ma.MAApplicationID = masw.MAApplicationID
                   WHERE    masw.ProjectID = p.ProjectID
                   ORDER BY ', ' + COALESCE(asu.FullName, asu.ADUserName)
            FOR   XML PATH('') ,
                      TYPE).value('.[1]', 'varchar(MAX)'), 1, 2, '') AS [App Plan Reg Leads] ,
            STUFF((SELECT  DISTINCT
                            ', ' + c.Name
                   FROM     tblCompany c
                            JOIN dbo.tblMAApplication ma ON c.CompanyID = ma.RegulatoryTeamID
                            JOIN dbo.MASubmissionWorkstream masw ON ma.MAApplicationID = masw.MAApplicationID
                   WHERE    masw.ProjectID = p.ProjectID
                   ORDER BY ', ' + c.Name
            FOR   XML PATH('') ,
                      TYPE).value('.[1]', 'varchar(MAX)'), 1, 2, '') AS [App Plan Reg Team] ,
            STUFF((SELECT   ', ' + prb.Name
                   FROM     pm.ProductProposalLinkProject plp
                            JOIN pm.ProductProposal prop ON plp.ProductProposalID = prop.ProductProposalID
                            JOIN pm.Candidate c ON prop.CandidateID = c.CandidateID
                            JOIN pm.PRBSession prb ON prb.PRBSessionID = c.TargetPRBSessionID
                   WHERE    plp.ProjectID = p.ProjectID
                   ORDER BY prb.Name
            FOR   XML PATH('') ,
                      TYPE).value('.[1]', 'varchar(MAX)'), 1, 2, '') AS [PRB Approval] ,
            pli.LastRegMeetingDate AS [Last Reg Meeting] ,
            pli.NextRegMeetingDate AS [Next Reg Meeting] ,
            pli.LastRDMeetingDate AS [Last RD Review Meeting] ,
            vpot.Name AS [Opportunity Type] ,
            -- Fix this
            ( SELECT TOP 1
                        CASE WHEN l.IsGlobalKeyLaunch = 1 THEN 'Yes'
                             ELSE 'No'
                        END
              FROM      pm.LaunchWorkstream l
              WHERE     l.ProjectID = p.ProjectID
              ORDER BY  IsGlobalKeyLaunch DESC
            ) AS [Key Launch Product] ,
            vrc.Name AS [Portfolio Category] ,
            p.FocusNumber AS [Focus Report Number] ,
            REPLACE(CONVERT(NVARCHAR(11), CASE WHEN m.ReferenceMilestoneID IS NULL
                                               THEN m.BestEstimateDate
                                               ELSE refm.BestEstimateDate
                                          END, 106), ' ', '-') + ' ['
            + vms.NAME + ']' AS [CEES Date] ,
            p.LatestFileDate AS [Commercial Latest File Date] ,
            pli.GeneralComment AS [Launch General Comment] ,
            pli.IPComment AS [Comment on IP Situation] ,
            pli.RegComment AS [Comment on Regulatory Situation] ,
            pli.SNCComment AS [Comment on SNC Situation] ,
            pli.BCRAComment AS [Comment on BCRA Situation] ,
            pli.QAComment AS [Comment on QA Situation] ,
            #LCPPivot.Comment1 ,
            #LCPPivot.Comment2 ,
            #LCPPivot.Comment3 ,
            #LCPPivot.Comment4 ,
            #LCPPivot.Comment5
    FROM    pm.Project p
            JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserId,
                                                              @privcode) a ON a.[CountryGroupID] = p.CountryGroupID
                                                              AND a.Privs = 1
            JOIN dbo.tblValidProjectType vpt ON p.ValidProjectTypeID = vpt.ValidProjectTypeID
            JOIN dbo.tblCountryGroup cg ON p.CountryGroupID = cg.CountryGroupID
            JOIN dbo.tblBusinessBaseStates bbs ON p.ProjectStatusID = bbs.StateID
            JOIN dbo.tblForm f ON p.FormID = f.FormID
            LEFT JOIN dbo.tblValidReleaseCategory vrc ON f.ValidReleaseCategoryID = vrc.ValidReleaseCategoryID
            LEFT JOIN ( tblmilestone m
                        JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                        LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                        JOIN dbo.tblValidMilestoneStatus vms ON COALESCE(refm.StatusID,
                                                              m.StatusID) = vms.ValidMilestoneStatusID
                      ) ON m.BBOID = @BBOID
                           AND m.ObjectID = p.ProjectID
            LEFT JOIN pm.ProjectLaunchInfo pli ON p.ProjectID = pli.ProjectID
            LEFT JOIN dbo.tblValidProjectOppType vpot ON p.ValidOpportunityTypeID = vpot.ValidProjectOppTypeID
            LEFT JOIN pm.ProjectTag pt ON pt.ProjectID = p.ProjectID
            LEFT JOIN pm.DevWorkstreamLinkProject dwlp ON p.ProjectID = dwlp.ProjectID
            LEFT JOIN pm.TradeDressWorkstreamLinkProject tdwlp ON p.ProjectID = tdwlp.ProjectID
            LEFT JOIN #LCPPivot ON #LCPPivot.ProjectID = p.ProjectID
    WHERE   ( dbo.udf_UserHasPrivForCountryGroup(@UserId, @PrivCode,
                                                 p.CountryGroupID) = 'true' )
            AND ( @ID IS NULL
                  OR p.ProjectID = @ID
                )
            AND ( @ProductGroupID IS NULL
                  OR f.ProductID = @ProductGroupID
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @FormFilters
                  ) = 0
                  AND @FormFiltersInclusionID != 4
                  OR ( @FormFiltersInclusionID = 1
                       AND p.formid IN ( SELECT FormID
                                         FROM   @FormFilters )
                     )
                  OR ( @FormFiltersInclusionID = 2
                       AND ( SELECT COUNT(DISTINCT f.FormID)
                             FROM   dbo.tblForm f
                                    JOIN @FormFilters ff ON ff.FormID = f.FormID
                                                            AND f.FormID = p.FormID
                           ) = ( SELECT COUNT(DISTINCT FormID)
                                 FROM   @FormFilters
                               )
                     )
                  OR ( @FormFiltersInclusionID = 3
                       AND p.formid NOT IN ( SELECT FormID
                                             FROM   @FormFilters )
                     )
                  OR ( @FormFiltersInclusionID = 4
                       AND p.FormID IS NULL
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @CountryGroupFilters
                  ) = 0
                  AND @CountryGroupFiltersInclusionID != 4
                  OR ( @CountryGroupFiltersInclusionID = 1
                       AND p.CountryGroupID IN ( SELECT CountryGroupID
                                                 FROM   @CountryGroupFilters )
                     )
                  OR ( @CountryGroupFiltersInclusionID = 3
                       AND p.CountryGroupID NOT IN (
                       SELECT   CountryGroupID
                       FROM     @CountryGroupFilters )
                     )
                )
            -- Task 3375 Added Country Filter logic
            AND ( ( ( SELECT    COUNT(*)
                      FROM      @CountryFilters
                    ) = 0
                    AND @CountryFiltersInclusionID != 4
                  )
                  OR ( @CountryFiltersInclusionID = 1
                       AND p.ProjectID IN (
                       SELECT   ProjectID
                       FROM     pm.ProjectLinkCountry
                       WHERE    CountryID IN ( SELECT   CountryID
                                               FROM     @CountryFilters ) )
                     )
                  OR ( @CountryFiltersInclusionID = 2
                       AND ( SELECT COUNT(DISTINCT plc.CountryID)
                             FROM   pm.ProjectLinkCountry plc
                                    JOIN @CountryFilters cf ON cf.CountryID = plc.CountryID
                                                              AND plc.ProjectID = p.ProjectID
                           ) = ( SELECT COUNT(DISTINCT CountryID)
                                 FROM   @CountryFilters
                               )
                     )
                  OR ( @CountryFiltersInclusionID = 3
                       AND p.ProjectID NOT IN (
                       SELECT   ProjectID
                       FROM     pm.ProjectLinkCountry
                       WHERE    CountryID IN ( SELECT   CountryID
                                               FROM     @CountryFilters ) )
                     )
                  OR ( @CountryFiltersInclusionID = 4
                       AND p.ProjectID NOT IN (
                       SELECT   ProjectID
                       FROM     pm.ProjectLinkCountry plc )
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @BBOTagFilters
                  ) = 0
                  AND @BBOTagFiltersInclusionID != 4
                  OR ( @BBOTagFiltersInclusionID = 1
                       AND pt.ValidBBOTagID IN ( SELECT BBOTagID
                                                 FROM   @BBOTagFilters )
                     )
                  OR ( @BBOTagFiltersInclusionID = 2
                       AND ( SELECT COUNT(DISTINCT ValidBBOTagID)
                             FROM   pm.ProjectTag pt
                                    JOIN @BBOTagFilters tf ON tf.BBOTagID = pt.ValidBBOTagID
                                                              AND pt.ProjectID = p.ProjectID
                           ) = ( SELECT COUNT(DISTINCT BBOTagID)
                                 FROM   @BBOTagFilters
                               )
                     )
                  OR ( @BBOTagFiltersInclusionID = 3
                       AND ( p.ProjectID NOT IN (
                             SELECT ProjectID
                             FROM   pm.ProjectTag
                             WHERE  ValidBBOTagID IN ( SELECT BBOTagID
                                                       FROM   @BBOTagFilters ) ) )
                     )
                  OR ( @BBOTagFiltersInclusionID = 4
                       AND p.ProjectID NOT IN ( SELECT  ProjectID
                                                FROM    pm.ProjectTag )
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @ValidProjectTypeFilters
                  ) = 0
                  OR ( @ValidProjectTypeFiltersInclusionID = 1
                       AND p.ValidProjectTypeID IN (
                       SELECT   ValidProjectTypeID
                       FROM     @ValidProjectTypeFilters )
                     )
                  OR ( @ValidProjectTypeFiltersInclusionID = 3
                       AND p.ValidProjectTypeID NOT IN (
                       SELECT   ValidProjectTypeID
                       FROM     @ValidProjectTypeFilters )
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @ValidOpportunityTypeFilters
                  ) = 0
                  AND @ValidOpportunityTypeFiltersInclusionID != 4
                  OR ( @ValidOpportunityTypeFiltersInclusionID = 1
                       AND p.ValidOpportunityTypeID IN (
                       SELECT   ValidOpportunityTypeID
                       FROM     @ValidOpportunityTypeFilters )
                     )
                  OR ( @ValidOpportunityTypeFiltersInclusionID = 3
                       AND ( p.ValidOpportunityTypeID NOT IN (
                             SELECT ValidOpportunityTypeID
                             FROM   @ValidOpportunityTypeFilters )
                             OR p.ValidOpportunityTypeID IS NULL
                           )
                     )
                  OR ( @ValidOpportunityTypeFiltersInclusionID = 4
                       AND p.ValidOpportunityTypeID IS NULL
                     )
                )
            AND ( @DevWorkstreamID IS NULL
                  OR dwlp.DevWorkstreamID = @DevWorkstreamID
                )
            AND ( @ParentType != @PLWBBOID
                  OR @ParentID IS NULL
                  OR ( @ParentType = @PLWBBOID
                       AND dwlp.DevWorkstreamID = @ParentID
                     )
                )
            AND ( @TradeDressWorkstreamID IS NULL
                  OR tdwlp.TradeDressWorkstreamID = @TradeDressWorkstreamID
                )
            AND ( @ParentType != @TDWBBOID
                  OR @ParentID IS NULL
                  OR ( @ParentType = @TDWBBOID
                       AND tdwlp.TradeDressWorkstreamID = @ParentID
                     )
                )
            AND ( @ParentType != @PWBBOID
                  OR @ParentID IS NULL
                  OR ( @ParentType = @PWBBOID
                       AND @ParentID IN (
                       SELECT   pivotalWorkstreamID
                       FROM     pm.PivotalWorkstreamLinkProject
                       WHERE    ProjectID = p.ProjectID )
                     )
                )
            AND ( @ProjectLeadID IS NULL
                  OR ( @ProjectLeadInclusionID = 1
                       AND p.ProjectLeadID = @ProjectLeadID
                     )
                  OR ( @ProjectLeadInclusionID = 3
                       AND p.ProjectLeadID != @ProjectLeadID
                     )
                )
            AND ( @FocusNumber IS NULL
                  OR p.FocusNumber LIKE @FocusNumber
                )
            AND ( ( @EvaluationDateStart IS NULL
                    AND @EvaluationDateEnd IS NULL
                  )
                  OR ( p.EvaluationDate BETWEEN ISNULL(@EvaluationDateStart,
                                                       '01/01/1899')
                                        AND     ISNULL(@EvaluationDateEnd,
                                                       '01/01/2050') )
                )
            AND ( @ValidWorkPlanID IS NULL
                  OR p.ValidWorkPlanID = @ValidWorkPlanID
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @ValidTechOpsRatingFilters
                  ) = 0
                  AND @ValidTechOpsRatingFiltersInclusionID != 4
                  OR ( @ValidTechOpsRatingFiltersInclusionID = 1
                       AND ISNULL(p.ValidTechopsRatingID, -1) IN (
                       SELECT   ValidTechOpsRatingID
                       FROM     @ValidTechOpsRatingFilters )
                     )
                  OR ( @ValidTechOpsRatingFiltersInclusionID = 3
                       AND ISNULL(p.ValidTechOpsRatingID, -1) NOT IN (
                       SELECT   ValidTechOpsRatingID
                       FROM     @ValidTechOpsRatingFilters )
                     )
                  OR ( @ValidTechOpsRatingFiltersInclusionID = 4
                       AND p.ValidTechOpsRatingID IS NULL
                     )
                )
            AND ( @ProjectStatusID IS NULL
                  OR ( @ProjectStatusInclusionID = 1
                       AND p.ProjectStatusID = @ProjectStatusID
                     )
                  OR ( @ProjectStatusInclusionID = 3
                       AND p.ProjectStatusID != @ProjectStatusID
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @SubmissionYearFilters
                  ) = 0
                  AND @SubmissionYearFiltersInclusionID != 4
                  --OR ( EXISTS ( SELECT  *
                  --              FROM    @SubmissionYearFilters
                  --              WHERE   Timeframe = -12 )
                  --     AND ( ( SELECT   CASE WHEN m.ReferenceMilestoneID IS NULL
                  --                           THEN m.BestEstimateDate
                  --                           ELSE refm.BestEstimateDate
                  --                      END
                  --             FROM     dbo.tblMilestone m
                  --                      JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                  --                                        AND mti.Code = 'Submission'
                  --                      LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                  --             WHERE    m.BBOID = @BBOID
                  --                      AND m.ObjectID = p.ProjectID
                  --           ) BETWEEN DATEADD(day, -1, CURRENT_TIMESTAMP)
                  --             AND     DATEADD(month, 12,
                  --                             CURRENT_TIMESTAMP) )
                  --   )
                  OR ( @SubmissionYearFiltersInclusionID = 1
                       AND ( SELECT CASE WHEN m.ReferenceMilestoneID IS NULL
                                         THEN YEAR(m.BestEstimateDate)
                                         ELSE YEAR(refm.BestEstimateDate)
                                    END
                             FROM   dbo.tblMilestone m
                                    JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                    LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                             WHERE  m.BBOID = @BBOID
                                    AND m.ObjectID = p.ProjectID
                           ) IN ( SELECT    Timeframe
                                  FROM      @SubmissionYearFilters )
                     )
                  OR ( @SubmissionYearFiltersInclusionID = 3
                       AND ISNULL(( SELECT  CASE WHEN m.ReferenceMilestoneID IS NULL
                                                 THEN YEAR(m.BestEstimateDate)
                                                 ELSE YEAR(refm.BestEstimateDate)
                                            END
                                    FROM    dbo.tblMilestone m
                                            JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                            LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                                    WHERE   m.BBOID = @BBOID
                                            AND m.ObjectID = p.ProjectID
                                  ), -1) NOT IN (
                       SELECT   Timeframe
                       FROM     @SubmissionYearFilters )
                     )
                  OR ( @SubmissionYearFiltersInclusionID = 4
                       AND ( ( SELECT   CASE WHEN m.ReferenceMilestoneID IS NULL
                                             THEN YEAR(m.BestEstimateDate)
                                             ELSE YEAR(refm.BestEstimateDate)
                                        END
                               FROM     dbo.tblMilestone m
                                        JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                        LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                               WHERE    m.BBOID = @BBOID
                                        AND m.ObjectID = p.ProjectID
                             ) IS NULL )
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @SiteFilters
                  ) = 0
                      -- Include
                  OR ( ( @SiteNameFiltersInclusionID = 1
                       AND ( ( @IncludeScaleUpSites > 0
                               AND p.ProjectID IN (
                               SELECT   pwlp.ProjectID
                               FROM     pm.PivotalWorkstreamLinkProject pwlp
                                        JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                               WHERE    pw.scaleUpSiteID IN ( SELECT
                                                              id
                                                              FROM
                                                              @SiteFilters ) )
                             )
                             OR ( @IncludePackagingSites > 0
                                  AND p.PackagingSiteID IN ( SELECT
                                                              id
                                                             FROM
                                                              @SiteFilters )
                                )
                             OR ( @IncludeManufacturingSites > 0
                                  AND p.ManufacturingSiteID IN ( SELECT
                                                              id
                                                              FROM
                                                              @SiteFilters )
                                )
                             OR ( @IncludeDevelopmentSites > 0
                                  AND p.ProjectID IN (
                                  SELECT    pwlp.ProjectID
                                  FROM      pm.PivotalWorkstreamLinkProject pwlp
                                            JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE     pw.DevSiteID IN ( SELECT
                                                              id
                                                              FROM
                                                              @SiteFilters ) )
                                )
                           ))
                     )
                -- Exclude
                  OR ( @SiteNameFiltersInclusionID = 3
                       AND ( ( @IncludeScaleUpSites > 0
                               AND p.ProjectID NOT IN (
                               SELECT   pwlp.ProjectID
                               FROM     pm.PivotalWorkstreamLinkProject pwlp
                                        JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                               WHERE    ScaleUpSiteID IN ( SELECT
                                                              id
                                                           FROM
                                                              @SiteFilters ) )
                             )
                             OR ( @IncludePackagingSites > 0
                                  AND ( p.PackagingSiteID IS NULL
                                        OR p.PackagingSiteID NOT IN ( SELECT
                                                              id
                                                              FROM
                                                              @SiteFilters )
                                      )
                                )
                             OR ( @IncludeManufacturingSites > 0
                                  AND ( p.ManufacturingSiteID IS NULL
                                        OR p.ManufacturingSiteID NOT IN (
                                        SELECT  id
                                        FROM    @SiteFilters )
                                      )
                                )
                             OR ( @IncludeDevelopmentSites > 0
                                  AND p.ProjectID NOT IN (
                                  SELECT    pwlp.ProjectID
                                  FROM      pm.PivotalWorkstreamLinkProject pwlp
                                            JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE     pw.DevSiteID IN ( SELECT
                                                              id
                                                              FROM
                                                              @SiteFilters ) )
                                )
                           )
                     )
                )
            AND ( ( ( SELECT    COUNT(*)
                      FROM      @TeamMembers
                    ) = 0
                    AND @TeamMemberFiltersInclusionID != 4
                  )
                  OR ( @TeamMemberFiltersInclusionID = 1
                       AND p.ProjectID IN (
                       SELECT   ProjectID
                       FROM     ProjectTeam
                       WHERE    Role = @ProjectTeamRoleFiltersList
                                AND UserID IN ( SELECT  ID
                                                FROM    @TeamMembers ) )
                     )
                  OR ( @TeamMemberFiltersInclusionID = 2
                       AND ( SELECT COUNT(DISTINCT ProjectID)
                             FROM   dbo.ProjectTeam pt
                                    JOIN @TeamMembers tf ON tf.ID = pt.UserID
                                                            AND pt.ProjectID = p.ProjectID
                             WHERE  pt.Role = @ProjectTeamRoleFiltersList
                           ) = ( SELECT COUNT(DISTINCT ID)
                                 FROM   @TeamMembers
                               )
                     )
                  OR ( @TeamMemberFiltersInclusionID = 3
                       AND p.ProjectID NOT IN (
                       SELECT   ProjectID
                       FROM     dbo.ProjectTeam pt
                       WHERE    pt.Role = @ProjectTeamRoleFiltersList
                                AND UserID IN ( SELECT  ID
                                                FROM    @TeamMembers ) )
                     )
                  OR ( @TeamMemberFiltersInclusionID = 4
                       AND p.ProjectID IN (
                       SELECT   ProjectID
                       FROM     pm.Project
                       WHERE    ProjectID NOT IN (
                                SELECT  ProjectID
                                FROM    dbo.ProjectTeam
                                WHERE   Role = @ProjectTeamRoleFiltersList ) )
                     )
                )
            AND ( ( SELECT  COUNT(*)
                    FROM    @AlertTypesList
                  ) = 0
                  AND @AlertTypesInclusionID != 4
                  OR ( @AlertTypesInclusionID = 1
                       AND ( EXISTS ( SELECT    xoa.ValidAlertTypeID
                                      FROM      dbo.ObjectAlert xoa
                                                JOIN @AlertTypesList xvatf ON xoa.ValidAlertTypeID = xvatf.Id
                                      WHERE     xoa.BBOID = @BBOID
                                                AND xoa.ObjectID = p.ProjectID ) )
                     )
                  OR ( @AlertTypesInclusionID = 2
                       AND ( SELECT COUNT(DISTINCT xoa.ValidAlertTypeID)
                             FROM   dbo.ObjectAlert xoa
                                    JOIN @AlertTypesList xvatf ON xoa.ValidAlertTypeID = xvatf.Id
                             WHERE  xoa.BBOID = @BBOID
                                    AND xoa.ObjectID = p.ProjectID
                           ) = ( SELECT COUNT(DISTINCT Id)
                                 FROM   @AlertTypesList
                               )
                     )
                  OR ( @AlertTypesInclusionID = 3
                       AND ( NOT EXISTS ( SELECT    xoa.ValidAlertTypeID
                                          FROM      dbo.ObjectAlert xoa
                                                    JOIN @AlertTypesList xvatf ON xoa.ValidAlertTypeID = xvatf.Id
                                          WHERE     xoa.BBOID = @BBOID
                                                    AND xoa.ObjectID = p.ProjectID )
                           )
                     )
                  OR ( @AlertTypesInclusionID = 4
                       AND ( dbo.udf_EHSAlert(f.ProductID, NULL) IS NULL )
                     )
                )
    ORDER BY f.Name

    IF EXISTS ( SELECT  *
                FROM    tempdb.dbo.sysobjects
                WHERE   ID = OBJECT_ID(N'tempdb..#LaunchProjComments') )
        BEGIN
            DROP TABLE #LaunchProjComments
        END
    IF EXISTS ( SELECT  *
                FROM    tempdb.dbo.sysobjects
                WHERE   ID = OBJECT_ID(N'tempdb..#LCPPivot') )
        BEGIN
            DROP TABLE #LCPPivot
        END

GO
