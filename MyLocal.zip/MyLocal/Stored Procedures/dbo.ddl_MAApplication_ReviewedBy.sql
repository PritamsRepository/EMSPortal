SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MAApplication_ReviewedBy]
AS
  
BEGIN TRY 

  SELECT DISTINCT 
	maa.ReviewedByID AS UserID,
	(
	  CASE WHEN asu.FullName IS NULL OR asu.FullName = '' OR LEN(asu.fullname) < 2 THEN asu.ADUserName
	  ELSE asu.FullName
	  END
	) AS FullName,
	asu.FullName AS FullName
  FROM
	dbo.tblMAApplication maa
	  JOIN dbo.admin_SecUser asu ON maa.ReviewedByID = asu.UserID
  ORDER BY
	asu.FullName;

END TRY
BEGIN CATCH 
  EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplication_ReviewedBy] TO [mp_db_execute]
GO
