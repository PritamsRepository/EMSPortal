SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[Argus_Product]
AS
BEGIN
    DECLARE @start DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, -7)
            );
    DECLARE @end DATETIME =
            (
                SELECT DATEADD(WEEK, DATEDIFF(DAY, 0, GETDATE()) / 7, 0)
            );

    -- Sheet 2 - Product
    SELECT DISTINCT
           S.StrengthID AS [Strength ID],
           p.ProductID AS [Product ID],
           p.NAME AS [Product Family Name],
           F.name AS [Product Name],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + vki.Name + ISNULL(' ' + vs.Name, '')
               FROM dbo.tblProductLinkKPI lnk
                   JOIN dbo.tblKPI kpi
                       ON lnk.KPIID = kpi.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE p.ProductID = lnk.ProductID
               ORDER BY ', ' + vki.Name + ISNULL(' ' + vs.Name, '')
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Active Ingredients],
           S.name AS Strength,
           --COALESCE(S.DrugCode, '') AS [Drug Code],
           vf.Name AS [Formulation],
           COALESCE(STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + CAST([Code] AS NVARCHAR(10))
                        FROM tblCountry
                        WHERE CountryID IN
                              (
                                  SELECT mals.CountryID
                                  FROM tblMALicenseScope mals
                                      JOIN dbo.tblMAStrength mas
                                          ON mals.MAStrengthID = mas.MAStrengthID
                                      JOIN dbo.tblMALicense mal
                                          ON mals.MALicenseID = mal.MALicenseID
                                  WHERE mas.StrengthID = S.StrengthID
                                        AND mal.ValidLicenseStatusID IN
                                            (
                                                SELECT ValidLicenseStatusID FROM dbo.ValidApprovedLicenseStatus
                                            )
                              )
                        ORDER BY ', ' + CAST([Code] AS NVARCHAR(10))
                        FOR XML PATH('')
                    ),
                    1,
                    2,
                    ''
                         ),
                    ''
                   ) AS [Countries]
    FROM dbo.tblForm F
        JOIN dbo.tblStrength S
            ON F.FormID = S.FormID
               AND S.IsUndefined = 0
        JOIN dbo.tblProduct p
            ON p.ProductID = F.ProductID
        JOIN dbo.tblProductLinkKPI lnk
            ON F.ProductID = lnk.ProductID
        JOIN dbo.tblKPI kpi
            ON lnk.KPIID = kpi.KPIID
        JOIN dbo.tblValidKeyIngredient vki
            ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
        LEFT JOIN dbo.tblValidSalt vs
            ON vs.ValidSaltID = kpi.ValidSaltID
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = F.ValidFormID
    WHERE (
              F.UpdateDate >= @start
              AND F.UpdateDate < @end
          )
          OR
          (
              S.UpdateDate >= @start
              AND S.UpdateDate < @end
          )
    ORDER BY 1;
END;
GO
