SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MAApp_HealthAuthority] 
(							
  @CompanyID INT = NULL,
  @USERID INT
)
AS


BEGIN TRY
	DECLARE @Privcode NVARCHAR(10)				
	SET @Privcode='MA03' /* MA Add priv*/
	
		SELECT DISTINCT		  
		  c.CompanyID,
		  c.Name,
		 (case when co.Code is NULL THEN COALESCE(ShortName,'N/A') ELSE co.Code END  + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c 
			INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
			INNER JOIN tblCompanyGroup cg ON  clcg.CompanyGroupID = cg.CompanyGroupID AND cg.[Text] = 'Health Authority'
			JOIN dbo.tblCompanyLinkCountry CLC ON c.CompanyID=CLC.CompanyID
			JOIN dbo.tblCountryLinkCountryGroup CTYLCG ON CLC.CountryID = CTYLCG.CountryID
			JOIN dbo.tblCountryGroup CCG ON CTYLCG.CountryGroupID = CCG.CountryGroupID AND CCG.CountryGroupType='MAMkt'
		    --JOIN dbo.[udf_UserHasPrivForCountry_TableValued](@UserID,@privcode) a ON a.countryID=CLC.CountryID AND a.Privs=1
			--JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,@privcode) a ON a.CountryGroupID = ccg.CountryGroupID AND a.Privs=1  AND CCG.CountryGroupType='MAMkt'
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID					
		WHERE dbo.udf_UserHasPrivForCountryGroup(@userid,@Privcode,ccg.CountryGroupID) =1
	
		UNION
		
		SELECT		  
		  c.CompanyID,
		  c.Name,
		 (case when co.Code is NULL THEN COALESCE(ShortName,'N/A') ELSE co.Code END  + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE 
		  CompanyID = @CompanyID
		ORDER BY
		  FullName;
			
END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_MAApp_HealthAuthority] TO [mp_db_execute]
GO
