SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
------------------------------------------------------------------------------------------------------------------------
-- CREATED SCRIPT:		SCOTT DEXTER	DATA ARCHITECT
-- CREATED DATE:			29 JAN 2010
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_PATCERTREV_Exclusivities]
    @FormID INT,
    @CountryID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN TRY
    SELECT DISTINCT
           e.[ExclusivityID],
           c.[Code] AS Country,
           vet.[Name] AS ExclusivityCode,
           e.[Definition] AS Definition,
           e.[ExpiryDate],
           ISNULL([dbo].[udf_StrengthListByExclusivityID](e.[ExclusivityID]), 'No Strengths') AS Strengths,
           e.[Comment]
    FROM pm.Exclusivity e
        JOIN [dbo].tblCountry c
            ON e.CountryID = c.CountryID
        JOIN [dbo].tblValidExclusivityType vet
            ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
    WHERE e.[FormID] = @FormID
          AND e.[IsListed] = 'yes'
          AND c.CountryID = @CountryID
          AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
    ORDER BY e.[ExpiryDate];

END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_PATCERTREV_Exclusivities] TO [mp_db_execute]
GO
