SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_PATCERTREV_ApprovalDates]
    @FormID INT,
    @CountryID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
/*===============================================================================================================
CREATED BY:							SCOTT DEXTER				DATA ARCHITECT				SOFTWARE SPECIALISTS CONSULTANT
CREATED ON:							29 JAN 2010		
PURPOSE:								The purpose of this procedure is to get the legal infos by form id.
-----------------------------------------------------------------------------------------------------------------------
EXAMPLE:								Execute sp_REPORT_PATCERTREV_ApprovalDates @FormID = 6228, @CountryID = 159 --Sandbox
												@UserID = 4, @PrivCode = 'ADM01'
================================================================================================================*/

BEGIN TRY
    SELECT li.[MktFormationDate],
           [dbo].[udf_MFADateRationaleListByLegalInfoID](li.[LegalInfoID]) AS MFADateRationaleList,
           li.[MktFormationDateComments],
           li.[MylanApprovalDate],
           [dbo].[udf_MYLADateRationaleListByLegalInfoID](li.[LegalInfoID]) AS MYLADateRationaleList,
           li.[MylanApprovalDateComments]
    FROM pm.LegalInfo AS li
        JOIN [dbo].[tblCountry] AS co
            ON li.[CountryID] = co.[CountryID]
        JOIN [dbo].[tblForm] AS f
            ON li.[FormID] = f.[FormID]
        JOIN [dbo].[tblProduct] prod
            ON prod.[ProductID] = f.[ProductID]
    WHERE li.[FormID] = @FormID
          AND co.CountryID = @CountryID
          AND [dbo].[udf_UserHasPrivForCountry](@UserID, @PrivCode, co.[CountryID]) = 'true'
    ORDER BY co.Code;
END TRY

BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_PATCERTREV_ApprovalDates] TO [mp_db_execute]
GO
