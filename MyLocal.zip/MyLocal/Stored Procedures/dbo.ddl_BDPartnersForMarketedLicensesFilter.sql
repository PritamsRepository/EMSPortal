SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_BDPartnersForMarketedLicensesFilter]
as

BEGIN TRY 

	SELECT DISTINCT
			c.CompanyID ,
			c.Name AS [Name]
	FROM    tblMALicenseScope ls
			JOIN dbo.tblMARegisteredSite LSLMS ON ls.MALicenseScopeID = LSLMS.MALicenseScopeID
			JOIN dbo.tblMASite MAS ON MAS.MASiteID = LSLMS.MASiteID
									  AND LSLMS.IsUsed = 1
			JOIN dbo.tblMALicense l ON l.MALicenseID = ls.MALicenseID
			JOIN dbo.tblMAApplication ma ON ma.MAApplicationID = l.MAApplicationID
			JOIN tblCompany c ON c.CompanyID = ma.BDPartnerID
								 AND c.IsThirdParty = 1
	ORDER BY c.Name
		
	
END TRY


BEGIN CATCH
	EXECUTE [dbo].[sp_RollAndRaise]
END CATCH






GO
GRANT EXECUTE ON  [dbo].[ddl_BDPartnersForMarketedLicensesFilter] TO [mp_db_execute]
GO
