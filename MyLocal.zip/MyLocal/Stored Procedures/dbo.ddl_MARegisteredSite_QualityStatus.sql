SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MARegisteredSite_QualityStatus]
  @CompanyID INT
        
AS 
BEGIN TRY

SELECT DISTINCT
  vqs.ValidQualityStatusID AS ID,
  vqs.Name
FROM
  dbo.tblMARegisteredSite mars
	JOIN dbo.tblMASite mas ON mars.MASiteID = mas.MASiteID
	JOIN dbo.tblValidQualityStatus vqs ON mars.ValidQualityStatusID = vqs.ValidQualityStatusID
WHERE
  mas.CompanyID = @CompanyID
	
END TRY
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MARegisteredSite_QualityStatus] TO [mp_db_execute]
GO
