SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAApplication_GetDevelopmentSitesByProject]
  @ProjectID INT

AS 
BEGIN TRY

	SELECT
		c.CompanyID,
		dbo.udf_MA_FormatCompanies(c.CompanyID) AS Name
	FROM
		pm.PivotalWorkstreamLinkProject pwp
		JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwp.PivotalWorkstreamID
		JOIN dbo.tblCompany c ON c.CompanyID = pw.DevSiteID
		JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = pw.PivotalWorkstreamStatusID
	WHERE pwp.ProjectID = @ProjectID	   
	ORDER BY
		CASE WHEN Name LIKE 'Mylan%' THEN 0 ELSE 1 END,
		Name;
	
END TRY 
BEGIN CATCH

    EXEC dbo.sp_RollAndRaise;
    
END CATCH
GO
