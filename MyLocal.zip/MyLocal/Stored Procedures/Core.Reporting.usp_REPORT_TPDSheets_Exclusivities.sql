SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
------------------------------------------------------------------------------------------------------------------------
-- ALTERED SCRIPT:		SCOTT DEXTER	DATA ARCHITECT
-- MODIFIED DATE:		2009-11-03
-- MODIFIED FOR:		ELIMINATION OF DYNAMIC SQL
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_TPDSheets_Exclusivities]
    @FormID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
BEGIN TRY

    SELECT DISTINCT
           e.[ExclusivityID],
           c.[Code] AS Country,
           vet.[Name] AS ExclusivityCode,
           e.[Definition] AS Definition,
           e.[ExpiryDate],
           ISNULL([dbo].[udf_StrengthListByExclusivityID](e.[ExclusivityID]), 'No Strengths') AS Strengths,
           e.[Comment]
    FROM pm.Exclusivity e
        JOIN [dbo].tblCountry c
            ON e.CountryID = c.CountryID
        JOIN dbo.tblValidExclusivityType vet
            ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
    WHERE e.[FormID] = @FormID
          AND e.[IsListed] = 'yes'
          AND c.[Code] = 'CA'
          AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
    ORDER BY e.[ExpiryDate];

END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_TPDSheets_Exclusivities] TO [mp_db_execute]
GO
