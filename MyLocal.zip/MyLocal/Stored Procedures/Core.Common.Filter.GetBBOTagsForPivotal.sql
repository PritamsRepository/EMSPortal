SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetBBOTagsForPivotal]
AS
BEGIN

    SELECT
		0 AS Sequence,	
		t.ValidBBOTagID AS ID,
		t.Tag AS Name
    FROM
		dbo.tblValidBBOTag t
			JOIN dbo.tblBusinessBaseObjectTag bbot ON t.ValidBBOTagID = bbot.ValidBBOTagID
	WHERE
		bbot.BBOID = 84
		
	UNION ALL
	
	SELECT
		1 AS Sequence,
		t.ValidBBOTagID AS ID,
		t.Tag + ' (Project)' AS Name
    FROM
		dbo.tblValidBBOTag t
			JOIN dbo.tblBusinessBaseObjectTag bbot ON t.ValidBBOTagID = bbot.ValidBBOTagID
	WHERE
		bbot.BBOID = 40
		
	ORDER BY
		Sequence,
		Name;		

END
GO
