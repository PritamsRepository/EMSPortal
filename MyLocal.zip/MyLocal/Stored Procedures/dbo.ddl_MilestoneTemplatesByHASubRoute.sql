SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MilestoneTemplatesByHASubRoute] (@HealthAuthorityID INT, @SubmissionRouteID int, @IsLead bit)
as

	SELECT 
		DISTINCT MT.MilestoneTemplateID ,
	  MT.Name 
	FROM    
		dbo.tblMilestoneTemplate MT
		JOIN dbo.tblSubmissionRouteConfig src ON MT.MilestoneTemplateID = src.MilestoneTemplateID
	WHERE 
		src.HealthAuthorityID = @HealthAuthorityID AND src.SubmissionRouteID = @SubmissionRouteID
		-- Let's not include these.
		AND src.IsLead=@IsLead AND mt.IsPublic = 1 AND mt.IsActive = 1
GO
GRANT EXECUTE ON  [dbo].[ddl_MilestoneTemplatesByHASubRoute] TO [mp_db_execute]
GO
