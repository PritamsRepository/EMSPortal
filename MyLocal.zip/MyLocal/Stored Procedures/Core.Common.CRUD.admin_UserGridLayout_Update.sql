SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[admin_UserGridLayout_Update]
    @ID INT ,
    @UserID INT ,
    @GridName NVARCHAR(100) ,
    @ControllerName NVARCHAR(100) ,
    @isDefault BIT = 0 ,
    @Label NVARCHAR(100) = NULL ,
    @Settings NVARCHAR(MAX) ,
    @ConcurrencyID TIMESTAMP
AS
    BEGIN TRY  
        DECLARE @ReturnValue INT
        DECLARE @ConcurIDinDB TIMESTAMP
        DECLARE @RowsAffected INT
		
        SELECT  @ConcurIDinDB = ConcurrencyID
        FROM    [dbo].[admin_UserGridLayout]
        WHERE   UserGridLayoutID = @ID
					
        IF @ConcurIDinDB IS NULL
            BEGIN 
                EXEC sp_RaiseCustomError 2
            END
        ELSE
            IF @ConcurIDinDB != @ConcurrencyID
                BEGIN
                    EXEC sp_RaiseCustomError 1
                END
	                   
        BEGIN TRANSACTION 
         
  		-- There can be only one
        IF ( @isDefault = 1 )
            UPDATE  [dbo].[admin_UserGridLayout]
            SET     isDefault = 0
            WHERE   UserID = @UserID
                    AND GridName = @GridName
                    AND ControllerName = @ControllerName

        UPDATE  [dbo].[admin_UserGridLayout]
        SET     [UserID] = @UserID ,
                [GridName] = @GridName ,
                [ControllerName] = @ControllerName ,
                [isDefault] = @isDefault ,
                [Label] = @Label ,
                [Settings] = @Settings
        WHERE   [UserGridLayoutID] = @ID
		
        SET @RowsAffected = @@ROWCOUNT
        IF @RowsAffected = 0
            EXEC sp_RaiseCustomError 3
        COMMIT
		-- Set output parameter values.
        SET @ReturnValue = @ID 

        SELECT  @ReturnValue AS ID,
                ConcurrencyID
        FROM    dbo.admin_UserGridLayout
        WHERE   UserGridLayoutID = @ReturnValue
 
    END TRY
 
    BEGIN CATCH
        EXEC SP_ROLLANDRAISE
    END CATCH
GO
