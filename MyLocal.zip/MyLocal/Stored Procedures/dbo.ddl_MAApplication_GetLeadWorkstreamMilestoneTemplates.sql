SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_MAApplication_GetLeadWorkstreamMilestoneTemplates]
	@HealthAuthorityID INT,
	@SubmissionRouteID INT
AS 
SET NOCOUNT ON 

BEGIN TRY 	

	SELECT
		mt.MilestoneTemplateID AS ID,
		mt.Name AS Name
	FROM
		dbo.tblSubmissionRouteConfig src 
			LEFT JOIN  dbo.tblCompany xha ON xha.CompanyID = src.HealthAuthorityID
			JOIN dbo.tblSubmissionRoute sr ON sr.SubmissionRouteID = @SubmissionRouteID
			JOIN dbo.tblMilestoneTemplate mt ON src.MilestoneTemplateID = mt.MilestoneTemplateID
	WHERE
		src.SubmissionRouteID = @SubmissionRouteID AND src.HealthAuthorityID = @HealthAuthorityID AND src.IsLead = 1
	ORDER BY 
		mt.Name
                            
END TRY 

BEGIN CATCH
    EXEC dbo.Sp_RollAndRaise 
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplication_GetLeadWorkstreamMilestoneTemplates] TO [mp_db_execute]
GO
