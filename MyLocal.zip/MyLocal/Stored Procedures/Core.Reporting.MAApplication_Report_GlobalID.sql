SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC [Core.Reporting].[MAApplication_Report_GlobalID]
CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_GlobalID]
(@MAApplicationID INT = NULL)
AS
BEGIN
    SELECT DISTINCT
           link.MAApplicationID AS MAApplicationID,
           sc.BrandName AS GLOBAL_BRAND_NAME,
           link.GlobalID AS ID_VALUE,
           sc.Strength AS COMB_STRN,
           sc.LineOfBusiness AS PROD_TYPE,
           sc.Description AS UNIQUE_DESCR,
           sc.PrimaryPackagingType AS COMB_PACK,
           sc.ActiveIngredient AS COMB_MOL_SALT,
           sc.DosageForm AS FORM4,
           sc.Internal AS ORIG_BIZ,
           sc.ReportingCategory AS RPT_CAT,
           sc.LocalBrandName AS LOCAL_BRAND_NAME,
           sc.ReportingProduct AS REPORTING_PROD_2,
           sc.Country AS SOLD_TO_CNTRY,
           sc.UpdateDate AS UpdateDate
    FROM pm.SNCWorkstreamSupplyChain sc
        JOIN pm.GlobalIDLinkRimApplication link
            ON link.GlobalID = sc.GlobalID
    WHERE (
              @MAApplicationID IS NULL
              OR link.MAApplicationID = @MAApplicationID
          );
END;
GO
