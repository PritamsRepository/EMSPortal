SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_REPORT_PATCERTREV_Main]
    @FormID INT,
    @CountryID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS

DECLARE @UpdatedBy NVARCHAR(100);
DECLARE @UpdatedDate NVARCHAR(30);
DECLARE @UpdatedTime NVARCHAR(30);

BEGIN TRY;

    WITH MaxUpdateDate (FullName, UpdateDate)
    AS (SELECT su.FullName,
               MAX(bblu.UpdateDate) AS UpdateDate
        FROM dbo.tblStrength s
            JOIN pm.PatentLinkStrength slp
                ON s.StrengthID = slp.StrengthID
            JOIN pm.Patent p
                ON slp.PatentID = p.PatentID
            JOIN [dbo].tblBusinessBaseLastUpdated bblu
                ON p.PatentID = bblu.ObjectID
            JOIN dbo.admin_SecUser su
                ON bblu.UserID = su.UserID
        WHERE s.[FormID] = @FormID
              AND p.[CountryID] =
              (
                  SELECT CountryID FROM [dbo].tblCountry WHERE CountryID = @CountryID
              )
              AND s.IsUndefined <> 1
        GROUP BY su.FullName
        UNION
        SELECT su.FullName,
               MAX(bblu.UpdateDate) AS UpdateDate
        FROM [pm].[Exclusivity] AS e
            JOIN pm.ExclusivityLinkStrength AS sle
                ON e.[ExclusivityID] = sle.[ExclusivityID]
            JOIN [dbo].[tblStrength] AS s
                ON sle.[StrengthID] = s.[StrengthID]
            JOIN [dbo].tblBusinessBaseLastUpdated bblu
                ON e.ExclusivityID = bblu.ObjectID
            JOIN dbo.admin_SecUser su
                ON bblu.UserID = su.UserID
        WHERE s.IsUndefined <> 1
              AND s.[FormID] = @FormID
              AND e.[CountryID] =
              (
                  SELECT CountryID FROM [dbo].tblCountry WHERE CountryID = @CountryID
              )
        GROUP BY su.FullName)
    SELECT @UpdatedBy = FullName,
           @UpdatedDate = REPLACE(CONVERT(NVARCHAR(11), UpdateDate, 106), ' ', '-'),
           @UpdatedTime = SUBSTRING(CONVERT(NVARCHAR(30), UpdateDate, 100), 13, 20)
    FROM MaxUpdateDate
    WHERE UpdateDate =
    (
        SELECT MAX(UpdateDate) FROM MaxUpdateDate
    );

    SELECT DISTINCT
           dbo.udf_MarketedStrengthListByBrandID(cty.CountryID, b.BrandCompanyID, @FormID) AS Strengths,
           vf.Name AS Form,
           b.Name AS InnovatorProduct,
           c.Name AS InnovatorCompany,
           p.Name AS APIGroup,
           F.Name AS Product,
           li.MANumberComments,
           li.MANumber,
           cty.Code AS CountryCode
    FROM dbo.tblCountry AS cty
        JOIN [dbo].tblForm AS F
            JOIN [dbo].tblValidForm AS vf
                ON F.ValidFormID = vf.ValidFormID
            JOIN [dbo].tblProduct AS p
                ON F.ProductID = p.ProductID
            JOIN pm.LegalInfo AS li
                ON F.FormID = li.FormID
            ON cty.CountryID = li.CountryID
        LEFT JOIN ([dbo].tblCompany AS c
            JOIN [dbo].tblBrand AS b
                ON c.CompanyID = b.BrandCompanyID)
            ON li.FormID = b.FormID
               AND li.CountryID = b.CountryID
    WHERE li.FormID = @FormID
          AND li.CountryID = @CountryID;

END TRY
BEGIN CATCH
    EXEC [dbo].[sp_RollAndRaise];
END CATCH;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_PATCERTREV_Main] TO [mp_db_execute]
GO
