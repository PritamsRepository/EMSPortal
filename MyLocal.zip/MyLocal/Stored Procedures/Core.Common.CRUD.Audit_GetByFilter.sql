SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.CRUD].[Audit_GetByFilter]
    @ChangeTrackingID BIGINT = NULL,
    @BBOID INT = NULL,
    @ObjectID INT = NULL,
    @UserID INT = NULL,
    @EntryDate DATETIME = NULL,
    @CurrentUserID INT = NULL
AS
BEGIN
    DECLARE @ShowAll BIT = 1;
    DECLARE @viewer INT =
            (
                SELECT PrivID FROM dbo.admin_SecPriv WHERE PrivCode = 'CPY04'
            );
    DECLARE @editor INT =
            (
                SELECT PrivID FROM dbo.admin_SecPriv WHERE PrivCode = 'CPY02'
            );
    DECLARE @CompanyBBOID INT =
            (
                SELECT BBOID FROM dbo.tblBusinessBaseObject WHERE BBOTable = 'tblCompany'
            );

    -- Check to see if the user should only see the top level items
    -- Right now this is only when looking at Company audit trail where the user is a viewer and not an editor
    IF (
           @BBOID = @CompanyBBOID
           AND dbo.udf_UserHasPriv(@CurrentUserID, 'CPY04') = 1
           AND dbo.udf_UserHasPriv(@CurrentUserID, 'CPY02') = 0
       )
        SET @ShowAll = 0;

    IF (@ShowAll = 1)
    BEGIN
        SELECT c.BusinessBasedObjectID AS BBOID,
               c.ChangeTrackingID,
               c.EntryDate,
               c.ObjectChanges,
               c.ObjectID,
               c.UserID
        FROM dbo.admin_ChangeTracking_Audit c
            CROSS APPLY
        (
            SELECT allAudit.ChangeTrackingID
            FROM
            (
                SELECT acta.ChangeTrackingID
                FROM dbo.admin_ChangeTracking_Audit acta
                    JOIN
                    (
                        SELECT ChangeTrackingID
                        FROM dbo.admin_ChangeTrackingRelationships_Audit CTR
                        WHERE (
                                  @ObjectID IS NOT NULL
                                  AND ParentObjectID = @ObjectID
                                  AND @BBOID IS NOT NULL
                                  AND CTR.ParentBBOID = @BBOID
                              )
                              OR
                              (
                                  @ChangeTrackingID IS NOT NULL
                                  AND CTR.ChangeTrackingID = @ChangeTrackingID
                              )
                    ) relAudit
                        ON acta.ChangeTrackingID = relAudit.ChangeTrackingID
                UNION ALL
                SELECT acta.ChangeTrackingID
                FROM dbo.admin_ChangeTracking_Audit acta
                WHERE (
                          @BBOID IS NULL
                          OR acta.BusinessBasedObjectID = @BBOID
                      )
                      AND
                      (
                          @ChangeTrackingID IS NULL
                          OR acta.ChangeTrackingID = @ChangeTrackingID
                      )
                      AND
                      (
                          @ObjectID IS NULL
                          OR acta.ObjectID = @ObjectID
                      )
            ) allAudit
            WHERE allAudit.ChangeTrackingID = c.ChangeTrackingID
                  AND
                  (
                      @EntryDate IS NULL
                      OR CAST(c.EntryDate AS DATE) = CAST(@EntryDate AS DATE)
                  )
                  AND
                  (
                      @UserID IS NULL
                      OR c.UserID = @UserID
                  )
            GROUP BY allAudit.ChangeTrackingID
        ) t4;
    END;
    ELSE
    BEGIN
        SELECT c.BusinessBasedObjectID AS BBOID,
               c.ChangeTrackingID,
               c.EntryDate,
               c.ObjectChanges,
               c.ObjectID,
               c.UserID
        FROM dbo.admin_ChangeTracking_Audit c
            CROSS APPLY
        (
            SELECT acta.ChangeTrackingID
            FROM dbo.admin_ChangeTracking_Audit acta
            WHERE (
                      @BBOID IS NULL
                      OR acta.BusinessBasedObjectID = @BBOID
                  )
                  AND
                  (
                      @ChangeTrackingID IS NULL
                      OR acta.ChangeTrackingID = @ChangeTrackingID
                  )
                  AND
                  (
                      @ObjectID IS NULL
                      OR acta.ObjectID = @ObjectID
                  )
        ) allAudit
        WHERE allAudit.ChangeTrackingID = c.ChangeTrackingID
              AND
              (
                  @EntryDate IS NULL
                  OR CAST(c.EntryDate AS DATE) = CAST(@EntryDate AS DATE)
              )
              AND
              (
                  @UserID IS NULL
                  OR c.UserID = @UserID
              )
       -- GROUP BY allAudit.ChangeTrackingID;
    --                            ) t4
    END;
END;

GO
