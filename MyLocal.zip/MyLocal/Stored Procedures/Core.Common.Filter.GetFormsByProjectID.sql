SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetFormsByProjectID] @ProductID INT
AS --Products Menu List
    BEGIN TRY
		-- Only return Forms that have a project associated with it.
        SELECT DISTINCT
                f.FormID AS ID ,
                f.Name AS Name
        FROM    tblForm f
                JOIN pm.Project p ON p.FormID = f.FormID
		--JOIN tblProduct p on p.ProductID = f.ProductID
        WHERE   f.ProductID = @ProductID
        ORDER BY f.Name
    END TRY

    BEGIN CATCH
        EXEC sp_RollAndRaise
    END CATCH
GO
