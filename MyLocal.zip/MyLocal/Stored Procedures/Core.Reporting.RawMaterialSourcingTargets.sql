SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--EXEC [Core.Reporting].[RawMaterialSourcingTargets]

CREATE PROCEDURE [Core.Reporting].[RawMaterialSourcingTargets]
AS
BEGIN
    SELECT DISTINCT
           p.ProjectID,
           cg.Name AS Market,
           STUFF(
           (
               SELECT ', ' + c.Code
               FROM dbo.tblCountry c
                   JOIN pm.ProjectLinkCountry plc
                       ON c.CountryID = plc.CountryID
               WHERE plc.ProjectID = p.ProjectID
               ORDER BY ', ' + c.Code
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Countries],
           f.Name AS Product,
           LTRIM(RTRIM(   ISNULL(vrm.Name, '') + ' ' + vf.Name + CASE
                                                                     WHEN ISNULL(f.Identifier, '') = '' THEN
                                                                         ''
                                                                     ELSE
                                                                         ' (' + f.Identifier + ')'
                                                                 END
                      )
                ) AS [PharmForm],
           brnd.Name AS [Brand Name],
           (
               SELECT DISTINCT
                      cmp.Name
               FROM dbo.tblBrand brnd
                   JOIN dbo.tblCountry cntry
                       ON cntry.CountryID = brnd.CountryID
                   JOIN dbo.tblCompany cmp
                       ON cmp.CompanyID = brnd.BrandCompanyID
               WHERE brnd.BrandID = p.BrandID
           ) AS [Brand Company],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + s.Name
               FROM dbo.tblStrength s
                   JOIN pm.ProjectStrength ps
                       ON s.StrengthID = ps.StrengthID
               WHERE ps.ProjectID = p.ProjectID
                     AND s.IsUndefined = 0
               ORDER BY ', ' + s.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS Strengths,
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + COALESCE(co.ShortName, co.Name)
               FROM dbo.tblCompany co
                   JOIN pm.PivotalWorkstream pw
                       ON co.CompanyID = pw.DevSiteID
                   JOIN pm.PivotalWorkstreamLinkProject pwlp
                       ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
               WHERE pwlp.ProjectID = p.ProjectID
               ORDER BY ', ' + COALESCE(co.ShortName, co.Name)
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [PivotalDevelopmentSite],
           bbs.StateName AS [ProjectStatus],
           vot.Name AS [OpportunityType],
           tor.Name AS [RDRating],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + c.Name
               FROM pm.RawMaterialSupplierSource rms
                   JOIN pm.RawMaterialSupplier rm
                       ON rms.RawMaterialSupplierID = rm.RawMaterialSupplierID
                   JOIN dbo.tblCompany c
                       ON rm.SupplierID = c.CompanyID
                   JOIN dbo.tblCompanyLinkCompanyGroup clcg
                       ON c.CompanyID = clcg.CompanyID
                   JOIN dbo.tblCompanyGroup cg
                       ON clcg.CompanyGroupID = cg.CompanyGroupID
               WHERE p.ProjectID = rms.ProjectID
               --AND
               --(
               --    cg.Text = 'API Manufacturer'
               --    OR cg.Text = 'API Vendor'
               --)
               ORDER BY ', ' + c.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [APIManufacturer],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + c.Name
               FROM pm.RawMaterialSupplierSource rms
                   JOIN pm.PivotalWorkstreamLinkProject pwlp
                       ON pwlp.ProjectID = rms.ProjectID
                   JOIN pm.PivotalWorkstream pw
                       ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                   JOIN dbo.tblCompany c
                       ON c.CompanyID = pw.ScaleUpSiteID
               WHERE p.ProjectID = rms.ProjectID
               ORDER BY ', ' + c.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS ScaleUpSite,
           --p.Sales AS PeakNetSales,
           p.EstFirstYearValue AS PeakNetSales,
           p.ExpectedMylLaunchDate AS [CommExpectedLaunchDate],
           (
               SELECT CASE
                          WHEN m.ReferenceMilestoneID IS NULL THEN
                              m.BestEstimateDate
                          ELSE
                              refm.BestEstimateDate
                      END
               FROM dbo.tblMilestone m
                   JOIN dbo.tblMilestoneTemplateItem mti
                       ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                          AND mti.Code = 'Submission'
                   JOIN dbo.tblBusinessBaseObject bbo
                       ON bbo.BBOID = m.BBOID
                          AND bbo.BBOCode = 'PJM'
                   LEFT JOIN dbo.tblMilestone refm
                       ON refm.MileStoneID = m.MileStoneID
               WHERE m.ObjectID = p.ProjectID
           ) AS CEESD,
           STUFF(
           (
               SELECT DISTINCT
                      '+++SRC' + CONVERT(NVARCHAR(MAX), rmss.RawMaterialSupplierSourceID) + '|||' + asu.FullName
               FROM pm.RawMaterialSupplierSource rmss
                   JOIN dbo.admin_SecUser asu
                       ON asu.UserID = rmss.LeadID
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY 1
               FOR XML PATH('')
           ),
           1,
           3,
           ''
                ) AS SourcingLead,
           --API Manufacturer (from Supplier) - Date Rcv'd (from fulfillment) - Qty Rcv'd (from fulfillment) - Polymorph (new from fulfillment)
           STUFF(
                    (
                        SELECT DISTINCT
                               '+++RMO' + CONVERT(NVARCHAR(MAX), rmo.RawMaterialOrderID) + '-' + CONVERT(NVARCHAR(MAX), rmof.RawMaterialOrderFulfillmentID) + '|||' + c.Name + ' - '
                               + REPLACE(CONVERT(VARCHAR(15), rmof.DeliverDate, 106), ' ', '-') + ' - '
                               + CONVERT(NVARCHAR(MAX), rmof.UnitsReceived) + COALESCE(' (' + apiu.Name + ')', '')
                               + COALESCE(' - ' + rmo.Polymorph, '')
                        FROM pm.RawMaterialSupplierSource rmss
                            JOIN pm.RawMaterialSupplier rms
                                ON rms.RawMaterialSupplierID = rmss.RawMaterialSupplierID
                            JOIN dbo.tblCompany c
                                ON c.CompanyID = rms.SupplierID
                            JOIN pm.RawMaterialOrder rmo
                                ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
                            JOIN pm.RawMaterialOrderFulfillment rmof
                                ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
                            JOIN pm.RawMaterial rm
                                ON rm.RawMaterialID = rms.RawMaterialID
                            JOIN dbo.tblValidRMRequestPurpose vrp
                                ON vrp.ValidRMRequestPurposeID = rmo.ValidRMRequestPurposeID
                            JOIN pm.RawMaterialOrderLinkProject link
                                ON link.RawMaterialOrderID = rmo.RawMaterialOrderID
                            JOIN dbo.tblValidAPIUnit apiu
                                ON apiu.ValidAPIUnitID = rmo.ValidAPIUnitID
                        WHERE link.ProjectID = p.ProjectID
                              AND vrp.Name = 'Sample Testing'
                        ORDER BY 1
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'varchar(MAX)'),
                    1,
                    3,
                    ''
                ) AS SampleOrderSummary,
           --STUFF(
           --         (
           --             SELECT DISTINCT
           --                    '+++RMO' + CONVERT(NVARCHAR(MAX), rmo.RawMaterialOrderID) + '|||' + c.Name + ' - '
           --                    + REPLACE(CONVERT(VARCHAR(15), rmof.DeliverDate, 106), ' ', '-') + ' - '
           --                    + CONVERT(NVARCHAR(MAX), rmof.UnitsReceived) + COALESCE(' (' + apiu.Name + ')', '')
           --                    + COALESCE(' - ' + rmo.Polymorph, '')
           --           FROM pm.RawMaterialSupplierSource rmss
           --                 JOIN pm.RawMaterialSupplier rms
           --                     ON rms.RawMaterialSupplierID = rmss.RawMaterialSupplierID
           --                 JOIN dbo.tblCompany c
           --                     ON c.CompanyID = rms.SupplierID
           --                 JOIN pm.RawMaterialOrder rmo
           --                     ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
           --                 JOIN pm.RawMaterialOrderFulfillment rmof
           --                     ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
           --                 JOIN pm.RawMaterial rm
           --                     ON rm.RawMaterialID = rms.RawMaterialID
           --                 JOIN dbo.tblValidRMRequestPurpose vrp
           --                     ON vrp.ValidRMRequestPurposeID = rmo.ValidRMRequestPurposeID
           --                 JOIN dbo.tblValidAPIUnit apiu
           --                     ON apiu.ValidAPIUnitID = rmo.ValidAPIUnitID
           --             WHERE rmss.ProjectID = p.ProjectID
           --                   AND vrp.Name <> 'Sample Testing'
           --             ORDER BY 1
           --             FOR XML PATH(''), TYPE
           --         ).value('.[1]', 'varchar(MAX)'),
           --         1,
           --         3,
           --         ''
           --     ) AS OrderSummary,
           --         STUFF(
           --             (
           --                 SELECT DISTINCT
           --                        '+++RMO' + CONVERT(NVARCHAR(MAX), rmo.RawMaterialOrderID) + '|||' + c.Name + ' - '
           --                        + REPLACE(CONVERT(VARCHAR(15), rmof.DeliverDate, 106), ' ', '-') + ' - '
           --                        + CONVERT(NVARCHAR(MAX), rmof.UnitsReceived) + COALESCE(' (' + apiu.Name + ')', '')
           --                        + COALESCE(' - ' + rmo.Polymorph, '')
           --               FROM pm.RawMaterialSupplier rms
           --                     JOIN dbo.tblCompany c
           --                         ON c.CompanyID = rms.SupplierID
           --                     JOIN pm.RawMaterialOrder rmo
           --                         ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
           --                     JOIN pm.RawMaterialOrderLinkProject link ON link.RawMaterialOrderID = rmo.RawMaterialOrderID
           --JOIN pm.RawMaterialOrderFulfillment rmof
           --                         ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
           --                     JOIN pm.RawMaterial rm
           --                         ON rm.RawMaterialID = rms.RawMaterialID
           --                     JOIN dbo.tblValidRMRequestPurpose vrp
           --                         ON vrp.ValidRMRequestPurposeID = rmo.ValidRMRequestPurposeID
           --                     JOIN dbo.tblValidAPIUnit apiu
           --                         ON apiu.ValidAPIUnitID = rmo.ValidAPIUnitID
           --                 WHERE link.ProjectID = p.ProjectID
           --                       AND vrp.Name <> 'Sample Testing'
           --                 ORDER BY 1
           --                 FOR XML PATH(''), TYPE
           --             ).value('.[1]', 'varchar(MAX)'),
           --             1,
           --             3,
           --             ''
           --         ) AS OrderSummary,
           STUFF(
                    (
                        SELECT DISTINCT
                               '+++RMO' + CONVERT(NVARCHAR(MAX), rmo.RawMaterialOrderID) + '-' + CONVERT(NVARCHAR(MAX), rmof.RawMaterialOrderFulfillmentID) + '|||' + c.Name + ' - '
                               + COALESCE(REPLACE(CONVERT(VARCHAR(15), rmof.DeliverDate, 106), ' ', '-') + ' - ', '')
                               + COALESCE(CONVERT(NVARCHAR(MAX), rmof.UnitsReceived), '')
                               + COALESCE(' (' + apiu.Name + ')', '') + COALESCE(' - ' + rmo.Polymorph, '')
                        FROM pm.RawMaterialOrder rmo
                            --JOIN pm.RawMaterialOrderLinkProject link
                            --    ON link.RawMaterialOrderID = rmo.RawMaterialOrderID
                            JOIN pm.RawMaterialOrderFulfillment rmof
                                ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
                            JOIN dbo.tblValidRMRequestPurpose vrp
                                ON vrp.ValidRMRequestPurposeID = rmo.ValidRMRequestPurposeID
                            JOIN dbo.tblValidAPIUnit apiu
                                ON apiu.ValidAPIUnitID = rmo.ValidAPIUnitID
                            --                            JOIN pm.RawMaterialSupplier rms
                            --                                ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
                            JOIN pm.RawMaterialOrderLinkRawMaterialSupplierSource link
                                ON link.RawMaterialOrderID = rmo.RawMaterialOrderID
                            JOIN pm.RawMaterialSupplierSource rmss
                                ON rmss.RawMaterialSupplierSourceID = link.RawMaterialSupplierSourceID
                            --                                ON rmss.RawMaterialSupplierID = rms.RawMaterialSupplierID
                            JOIN pm.RawMaterialSupplier rms
                                ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
                            JOIN dbo.tblCompany c
                                ON c.CompanyID = rms.SupplierID

                        --LEFT JOIN pm.RawMaterial rm
                        --         ON rm.RawMaterialID = rms.RawMaterialID
                        WHERE rmss.ProjectID = p.ProjectID
                              AND vrp.Name <> 'Sample Testing'
                        ORDER BY 1
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'varchar(MAX)'),
                    1,
                    3,
                    ''
                ) AS OrderSummary,
           --Include SRCxxxx - Supplier - Raw Material - Status in the cell for each sourcing record
           STUFF(
           (
               SELECT DISTINCT
                      '+++SRC' + CONVERT(NVARCHAR(20), rmss.RawMaterialSupplierSourceID) + '|||' + c.Name + ' - ' + vki.Name
                      + COALESCE(' ' + vs.Name, '') + COALESCE(' - ' + vsd.Name, '')
               FROM pm.RawMaterialSupplierSource rmss
                   JOIN dbo.tblValidSourceDecision vsd
                       ON vsd.ValidSourceDecisionID = rmss.ValidSourceDecisionID
                   JOIN pm.RawMaterialSupplier rms
                       ON rms.RawMaterialSupplierID = rmss.RawMaterialSupplierID
                   JOIN dbo.tblCompany c
                       ON c.CompanyID = rms.SupplierID
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY '+++SRC' + CONVERT(NVARCHAR(20), rmss.RawMaterialSupplierSourceID) + '|||' + c.Name + ' - '
                        + vki.Name + COALESCE(' ' + vs.Name, '') + COALESCE(' - ' + vsd.Name, '')
               FOR XML PATH('')
           ),
           1,
           3,
           ''
                ) AS SRCApprovalStatus,
           STUFF(
           (
               SELECT DISTINCT
                      '+++SRC' + CONVERT(NVARCHAR(MAX), rmss.RawMaterialSupplierSourceID) + '|||'
                      + REPLACE(CONVERT(VARCHAR(15), rmss.TargetSourceSelectionDate, 106), ' ', '-')
               FROM pm.RawMaterialSupplierSource rmss
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY 1
               FOR XML PATH('')
           ),
           1,
           3,
           ''
                ) AS TargetSourceSelectionDate,
           STUFF(
           (
               SELECT DISTINCT
                      '+++SRC' + CONVERT(NVARCHAR(MAX), rmss.RawMaterialSupplierSourceID) + '|||'
                      + REPLACE(CONVERT(VARCHAR(15), rmss.ActualSourceSelectionDate, 106), ' ', '-')
               FROM pm.RawMaterialSupplierSource rmss
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY 1
               FOR XML PATH('')
           ),
           1,
           3,
           ''
                ) AS ActualSourceSelectionDate,
           STUFF(
           (
               SELECT DISTINCT
                      '+++SRC' + CONVERT(NVARCHAR(MAX), rmss.RawMaterialSupplierSourceID) + '|||' + rmss.Comment
               FROM pm.RawMaterialSupplierSource rmss
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY 1
               FOR XML PATH('')
           ),
           1,
           3,
           ''
                ) AS Remarks
    FROM pm.Project p
        --JOIN pm.RawMaterialOrderLinkProject rmolp ON rmolp.ProjectID = p.ProjectID
        JOIN dbo.tblForm f
            ON p.FormID = f.FormID
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = f.ValidFormID
        JOIN dbo.tblBusinessBaseStates bbs
            ON bbs.StateID = p.ProjectStatusID
        LEFT JOIN dbo.tblValidReleaseMechanism vrm
            ON vrm.ValidReleaseMechanismID = f.ValidReleaseMechanismID
        LEFT JOIN dbo.tblCountryGroup cg
            ON p.CountryGroupID = cg.CountryGroupID
        LEFT JOIN dbo.tblValidProjectType vpt
            ON p.ValidProjectTypeID = vpt.ValidProjectTypeID
        LEFT JOIN dbo.tblValidProjectOppType vot
            ON p.ValidOpportunityTypeID = vot.ValidProjectOppTypeID
        LEFT JOIN dbo.tblBrand brnd
            ON p.BrandID = brnd.BrandID
        LEFT JOIN dbo.tblValidTechOpsRating tor
            ON p.ValidTechOpsRatingID = tor.ValidTechOpsRatingID;
--WHERE bbs.StateName IN ( 'In Development', 'Approved for Development' )
--      AND p.ProjectID IN
--          (
--              SELECT pwlp.ProjectID
--              FROM dbo.tblCompany co
--                  JOIN pm.PivotalWorkstream pw
--                      ON co.CompanyID = pw.DevSiteID
--                  JOIN pm.PivotalWorkstreamLinkProject pwlp
--                      ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
--              WHERE pwlp.ProjectID = p.ProjectID
--                    AND co.ShortName IN ( 'DPT-SA', 'Mylan GRG', 'Galway', 'MTI-MGW' )
--          );
END;
GO
