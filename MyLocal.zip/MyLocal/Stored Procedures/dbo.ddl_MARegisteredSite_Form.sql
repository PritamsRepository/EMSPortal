SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MARegisteredSite_Form]
  @CompanyID INT
        
AS 
BEGIN TRY

SELECT DISTINCT
  f.FormID AS ID,
  f.Name
FROM
  dbo.tblMARegisteredSite mars
	/* Site JOINs */
	JOIN dbo.tblMASite mas ON mars.MASiteID = mas.MASiteID
	  JOIN dbo.tblCompany masc ON mas.CompanyID = masc.CompanyID
	  
	/* Scope JOINs */
	JOIN dbo.tblMALicenseScope mals 
	  JOIN dbo.tblMAStrength mast
		JOIN tblStrength s ON mast.StrengthID = s.StrengthID
		JOIN tblForm f ON s.FormID = f.FormID
	  ON mals.MAStrengthID = mast.MAStrengthID	  		  
	ON mars.MALicenseScopeID = mals.MALicenseScopeID
WHERE
  mas.CompanyID = @CompanyID
	
END TRY
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MARegisteredSite_Form] TO [mp_db_execute]
GO
