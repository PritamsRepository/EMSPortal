SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetGASiteTypesByName]
    @Name NVARCHAR(256) = NULL
AS
    SELECT DISTINCT
            vst.ValidGASiteTypeID AS ID ,
            vst.Name AS [Name]--cg.Text AS [Name]
    FROM    --dbo.tblCompanyGroup cg
            --JOIN 
			dbo.tblValidGASiteType vst --ON cg.Text = vst.NAME
            --JOIN dbo.tblCompanylinkcompanygroup clcg ON clcg.CompanyGroupID = cg.CompanyGroupID
            --JOIN dbo.tblCompany c ON c.CompanyID = clcg.CompanyID
    WHERE   --c.ValidCompanyTypeID = 3
            --AND
			( @Name IS NULL
                  OR vst.Name LIKE '%' + @Name + '%'
                )
GO
