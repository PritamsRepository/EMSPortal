SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_CountryByMALicenseID] @MALicenseID INT
AS 
    BEGIN TRY
        SELECT DISTINCT
                LS.CountryID AS ID ,
                C.Name
        FROM    dbo.tblMALicenseScope LS
                JOIN dbo.tblCountry C ON LS.CountryID = C.CountryID
        WHERE   MALicenseID = @MALicenseID
    END  TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_CountryByMALicenseID] TO [mp_db_execute]
GO
