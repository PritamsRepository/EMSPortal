SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetStrengthsByForms]
    @FormFilter FormType READONLY
AS
    SELECT  s.StrengthID AS ID ,
            ( f.Name + ' - ' + s.Name ) AS Name
    FROM    dbo.tblStrength s
            JOIN @FormFilter ff ON s.FormID = ff.FormID
            JOIN dbo.tblForm f ON s.FormID = f.FormID
    WHERE   s.IsUndefined = 0
    ORDER BY Name;
GO
