SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicenseScope_GetStrengths]
@MAPPID INT
AS
BEGIN TRY 

/* retreive a list of countries for a group of license scopes associated with a MA Application */

SELECT  MLS.MAStrengthID AS ID, S.Name
FROM dbo.tblMALicenseScope MLS
JOIN dbo.tblMAStrength MS ON MLS.MAStrengthID = MS.MAStrengthID
JOIN dbo.tblStrength S ON MS.StrengthID = S.StrengthID
JOIN dbo.tblMALicense ML ON MLS.MALicenseID = ML.MALicenseID
JOIN dbo.tblMAApplication MA ON ML.MAApplicationID = MA.MAApplicationID
WHERE MA.MAApplicationID=@MAPPID
GROUP BY  MLS.MAStrengthID , S.Name
ORDER BY LEN(S.name), S.Name

	
END TRY 
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicenseScope_GetStrengths] TO [mp_db_execute]
GO
