SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO









------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [Core.Reporting].[usp_Report_SecurityUser_GetAuditEvents]
	@SelectedUsers nvarchar(max)= NULL,
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL,
	@EventType int = NULL,
	@UserID int,
	@PrivCode nvarchar(10)
AS
BEGIN TRY
	--table for users we want
    DECLARE @Users TABLE
        (
        ID INT IDENTITY(1,1),
        UserID INT
        )
	
	IF @SelectedUsers IS NULL
		BEGIN
		INSERT INTO @Users (UserID)
		SELECT UserID
		FROM dbo.admin_SecUser 
		END
	ELSE
		BEGIN
			INSERT INTO @Users (UserID)
			SELECT CONVERT(INT,ISNULL(Value, '-1'))
			FROM dbo.udf_inline_split_list_numeric(@SelectedUsers)
		END
		
	SELECT 
		at.AuditTrailID ,
		us.FullName ,
		te.Name as 'TypeName',
		te.[Description] ,
		at.LogDate ,
		at.[message] 
	FROM dbo.admin_AuditTrail at 
	JOIN dbo.admin_AuditTrailEvent te
		on at.ATEventID = te.ATEventID 
	JOIN dbo.admin_SecUser as US
		on at.UserID = US.UserID
	JOIN @Users su
		on US.UserID = su.UserID
	WHERE 
		(@EventType IS NULL OR at.ATEventID = @EventType)
		AND(@StartDate IS NULL OR at.LogDate >= @StartDate)
		AND (@EndDate IS NULL OR at.LogDate <=@EndDate)
		AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
	ORDER BY US.FullName, at.LogDate desc

END TRY
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH









GO
GRANT EXECUTE ON  [Core.Reporting].[usp_Report_SecurityUser_GetAuditEvents] TO [mp_db_execute]
GO
