SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[LinkableLaunches_GetByProjectID]
(@ProjectID INT)
AS
BEGIN
    SELECT DISTINCT
           l.LaunchWorkstreamID AS ObjectID,
           l.WorkstreamName + ' - ' + cty.Name + ' - ' + f.Name + ' (' + bbs.StateName + ')'
           + COALESCE('[' + l.ReferenceLabel + ']', '') AS Name
    FROM pm.LaunchWorkstream l
        JOIN dbo.tblForm f
            ON f.FormID = l.FormID
        JOIN dbo.tblCountry cty
            ON l.CountryID = cty.CountryID
        JOIN dbo.tblBusinessBaseStates bbs
            ON l.LaunchStatusID = bbs.StateID
    WHERE l.ProjectID = @ProjectID;
END;
GO
