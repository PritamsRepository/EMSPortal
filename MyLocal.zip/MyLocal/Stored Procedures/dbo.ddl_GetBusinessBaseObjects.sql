SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROC [dbo].[ddl_GetBusinessBaseObjects] 
AS 
    SET NOCOUNT ON 
    SET XACT_ABORT ON  

    BEGIN TRY

        SELECT  BBOID ,
                BBO.TemplateName
        FROM    dbo.tblBusinessBaseObject BBO
        WHERE BBO.CanHaveTemplate =1
        ORDER BY BBOCode

    END TRY

    BEGIN CATCH
        EXEC [dbo].[sp_RollAndRaise]
    END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_GetBusinessBaseObjects] TO [mp_db_execute]
GO
