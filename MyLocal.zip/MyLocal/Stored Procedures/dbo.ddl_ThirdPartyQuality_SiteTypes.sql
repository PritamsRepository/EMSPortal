SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_ThirdPartyQuality_SiteTypes] AS
BEGIN TRY

  SELECT DISTINCT 
	vst.Name
  FROM
	dbo.tblCompany C
	  JOIN dbo.tblCompanyLinkCompanyGroup CLCG ON C.CompanyID = CLCG.CompanyID
	  JOIN dbo.tblCompanyGroup CG ON CLCG.CompanyGroupID = CG.CompanyGroupID
	  JOIN dbo.tblValidSiteType vst ON cg.[Text] = vst.Name
  GROUP BY
	vst.Name
  ORDER BY
	vst.Name	  
	
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_ThirdPartyQuality_SiteTypes] TO [mp_db_execute]
GO
