SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetFormsByProductGroups]
	@ProductFilter ProductType READONLY
AS

	SELECT 
		f.FormID AS ID,
		f.Name
	FROM 
		dbo.tblForm f			
			JOIN @ProductFilter pf ON f.ProductID = pf.ProductID
	ORDER BY
		f.Name;
GO
