SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [dbo].[ddl_GetCountryGroupsByType]
	@CountryGroupType NVARCHAR(25) = NULL, @UserID INT = NULL, @PrivCode NVARCHAR(100) = NULL, @Name NVARCHAR(100) = NULL
AS
BEGIN TRY 
DECLARE @test As nvarchar(100)
SET @test = (SELECT '%' + IsNull(@Name, '') + '%')
print @test
Declare @test2 As bit
set @test2 = (SELECT ISNULL((select 1 WHERE @Name Is NULL), 0))
print @test2

	SELECT  CountryGroupID, Name AS CountryGroup, CountryGroupType + ' : ' + Name AS CountryGroupWithType
	FROM dbo.tblCountryGroup
	WHERE 
		(@Name IS NULL OR (tblCountryGroup.[Name] Like '%' + @Name + '%') OR (tblCountryGroup.CountryGroupType Like '%' + @Name + '%') ) AND
		@CountryGroupType IS NULL OR CountryGroupType = @CountryGroupType AND
		(@UserID is NULL OR dbo.udf_UserHasPrivForCountryGroup(@UserID, @PrivCode, CountryGroupID) = 'True')		
		ORDER BY CountryGroupType, Name	
END TRY 
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_GetCountryGroupsByType] TO [mp_db_execute]
GO
