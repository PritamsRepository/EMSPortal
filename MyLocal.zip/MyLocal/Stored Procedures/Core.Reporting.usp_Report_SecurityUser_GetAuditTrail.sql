SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




CREATE PROCEDURE [Core.Reporting].[usp_Report_SecurityUser_GetAuditTrail]
    @SelectedUsers nvarchar(max)= NULL
AS 
   
    SET NOCOUNT ON 

    BEGIN TRY
    
    --table for users we want
    DECLARE @Users TABLE
        (
        ID INT IDENTITY(1,1),
        UserID INT,
        ADUserName NVARCHAR(100) NULL,
        FullName NVARCHAR(100) NULL
        )
	
	IF @SelectedUsers IS NULL
		BEGIN
		INSERT INTO @Users (UserID, ADUserName, FullName )
		SELECT UserID, ADUserName, FullName 
		FROM dbo.admin_SecUser 
		END
	ELSE
		BEGIN
			INSERT INTO @Users (UserID, ADUserName, FullName )
			SELECT CONVERT(INT,ISNULL(Value, '-1')), su.ADUserName, su.FullName 
			FROM udf_inline_split_list_numeric(@SelectedUsers) l
			JOIN dbo.admin_SecUser su ON l.Value = su.UserID 
		END
		
 DECLARE @parentBBOID INT = (SELECT BBOID from [dbo].tblBusinessBaseObject where BBOCode = 'SECU')
   
SELECT			--acta.ChangeTrackingID, acta.ObjectID, /* JRG needed for debug */
                t4.SelectedUser,
                t4.ADUserName, 
                t4.FullName,
                acta.UserID as 'EditUserID',
                dbo.udf_GetUserNameByUserID(acta.UserID) AS EditUserName ,
                acta.EntryDate ,
                acta.ObjectChanges.value('(AuditTrail/DateChanges)[1]','nvarchar(100)') as DateChanges,
                acta.ObjectChanges.value('(AuditTrail/User)[1]','nvarchar(100)') as AuditUserName,
                'EntityName' = '[' 
							+ REPLACE(acta.ObjectChanges.value('(AuditTrail/BusinessObject)[1]','nvarchar(100)'), 
								'Mylan.MyPortfolio.BLL.BusinessObjects.', '') 
							+ '] ' 
							+ REPLACE(acta.ObjectChanges.value('(AuditTrail/BusinessObject/@identifier)[1]','nvarchar(100)'), 
								acta.ObjectChanges.value('(AuditTrail/BusinessObject)[1]','nvarchar(100)'), '') ,
				'PropertyName' = Properties.value('./@name', 'nvarchar(100)'),
                'Change' = CASE 
							WHEN (Properties.value('./@name', 'nvarchar(100)') = 'Created') THEN Properties.value('./@name', 'nvarchar(100)')
							WHEN (Properties.value('./@name', 'nvarchar(100)')= 'Deleted') THEN Properties.value('./@name', 'nvarchar(100)')
							WHEN ISNULL(Properties.value('./Old[1]', 'nvarchar(100)'),'') = ISNULL(Properties.value('./New[1]', 'nvarchar(100)'),'') THEN Properties.value('./@name', 'nvarchar(100)')
							ELSE Properties.value('./@name', 'nvarchar(100)') +
								 ' changed from ' +
								 COALESCE(NULLIF(Properties.value('./Old[1]', 'nvarchar(100)'),''),'Nothing')+
								  ' to ' +
								  COALESCE(NULLIF(Properties.value('./New[1]', 'nvarchar(100)'),''),'Nothing') +'.'
						  END
        FROM    dbo.admin_ChangeTracking_Audit acta
                JOIN dbo.tblBusinessBaseObject bbo ON bbo.BBOID = acta.BusinessBasedObjectID 
                JOIN dbo.admin_SecUser asu ON asu.UserID = acta.UserID
    CROSS APPLY acta.ObjectChanges.nodes('AuditTrail/Changes/Property') as P1(Properties)
	CROSS APPLY                      
	(SELECT   t3.ChangeTrackingID, t3.SelectedUser, t3.ADUserName, t3.FullName FROM        
		   ( SELECT   acta.ChangeTrackingID, t1.ParentObjectID  as 'SelectedUser', t1.ADUserName,t1.FullName
	                
			FROM    dbo.admin_ChangeTracking_Audit acta
					JOIN dbo.tblBusinessBaseObject bbo ON bbo.BBOID = acta.BusinessBasedObjectID
					JOIN dbo.admin_SecUser asu ON asu.UserID = acta.UserID
					JOIN ( SELECT   ChangeTrackingID, ParentObjectID, selU.ADUserName, selU.FullName  
						   FROM     dbo.admin_ChangeTrackingRelationships_Audit CTR
						   JOIN @Users selU ON selU.UserID = CTR.ParentObjectID
						   WHERE    
						    CTR.ParentBBOID=@parentBBOID) t1 ON acta.ChangeTrackingID = t1.ChangeTrackingID
	        
			UNION ALL
	        
			SELECT  acta.ChangeTrackingID, acta.ObjectID as 'SelectedUser', selU.ADUserName, selU.FullName
	               
			FROM    dbo.admin_ChangeTracking_Audit acta
					JOIN dbo.tblBusinessBaseObject bbo ON bbo.BBOID = acta.BusinessBasedObjectID
					JOIN dbo.admin_SecUser asu ON asu.UserID = acta.UserID
					JOIN @Users selU ON selU.UserID = acta.ObjectID
			WHERE acta.BusinessBasedObjectID=@parentBBOID
			) t3
	        
	WHERE t3.ChangeTrackingID=acta.ChangeTrackingID       
	GROUP BY t3.ChangeTrackingID, t3.SelectedUser, t3.ADUserName, t3.FullName 
	) t4                
                
ORDER BY t4.ADUserName, acta.EntryDate DESC
    
 
    
    END TRY

    BEGIN CATCH
        EXEC [dbo].[sp_RollAndRaise]
    END CATCH








GO
GRANT EXECUTE ON  [Core.Reporting].[usp_Report_SecurityUser_GetAuditTrail] TO [mp_db_execute]
GO
