SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MALicenseScope_GetMarketingStatus]
AS
BEGIN TRY 
	SELECT DISTINCT StateID AS ID, StateName AS NAME 
FROM dbo.tblBusinessBaseStates BBS
JOIN dbo.tblBusinessBaseStateControl BBSC ON BBS.StateControlID = BBSC.StateControlID AND BBSC.BBOID=(SELECT bboid FROM dbo.tblBusinessBaseObject WHERE BBOCode='ML')
JOIN dbo.tblMALicenseScope LS ON BBS.StateID = LS.MarketStatusID
END TRY 
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END  CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_MALicenseScope_GetMarketingStatus] TO [mp_db_execute]
GO
