SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_CompanyByCompanyGroupName]
    (
      @CompanyGroup NVARCHAR(256) ,
      @CompanyID INT = NULL )
AS /*********************************************************************************
CREATED BY:							Scott M. Dexter			Software Specialists Consultant
CREATED DATE:						02 DEC 2010
MODIFIED BY:						Scott M. Dexter			Software Specialists Consultant
MODIFIED DATE:					20 JAN 2010
MODIFIED PURPOSE:			The modifiecation purpose for this is to introduce the ability for the
												user to select a company that is not a part of the CompanyGroup or
												has previously been disabled.
PURPOSE:								The purpose of this script is to retrieve a list of 
												company names and company id'sfor passage back to a drop down list. 
												Hense the prefix ddl_.
==================================================================================
SAMPLE USAGE:		EXEC [dbo].[ddl_CompanyByCompanyGroup] @CompanyGroup = 'Innovator'
*********************************************************************************/

    BEGIN TRY
		
        SELECT DISTINCT
                c.Name ,
                c.CompanyID
        FROM    tblCompany c
                INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID
                INNER JOIN tblCompanyGroup cg ON clcg.CompanyGroupID = cg.CompanyGroupID
        WHERE   cg.[Text] = @CompanyGroup
        UNION /* JRG 2011-05-03 add when the case the company has been removed from a company group or a company has been deactivated*/
        SELECT  Name ,
                CompanyID
        FROM    tblCompany
        WHERE   ( CompanyID = @CompanyID )
        ORDER BY Name
			
    END TRY

    BEGIN CATCH
        EXECUTE sp_RollAndRaise 
    END CATCH



GO
GRANT EXECUTE ON  [dbo].[ddl_CompanyByCompanyGroupName] TO [mp_db_execute]
GO
