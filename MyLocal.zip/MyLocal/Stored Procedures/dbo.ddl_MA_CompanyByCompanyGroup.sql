SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MA_CompanyByCompanyGroup] 
(							
  @CompanyGroup NVARCHAR(256),
  @CompanyID INT = NULL
)
AS

/*
copied CompanyByCompanyGroup and created new Sp for MA Module
*/

BEGIN TRY
				
		SELECT  CompanyID ,
		        FullName AS Name FROM 
		(SELECT DISTINCT		  
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS FullName
		FROM 
		  tblCompany c 
			INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
			INNER JOIN tblCompanyGroup cg ON  clcg.CompanyGroupID = cg.CompanyGroupID
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID					
		WHERE cg.[Text] = @CompanyGroup
		
		UNION
		
		SELECT		  
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS FullName
		FROM 
		  tblCompany c
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE 
		  CompanyID = @CompanyID
		)T2
		
		ORDER BY
		  CASE WHEN FullName LIKE 'Mylan%' THEN 0 ELSE 1 END , name 
			
END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_MA_CompanyByCompanyGroup] TO [mp_db_execute]
GO
