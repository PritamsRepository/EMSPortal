SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE PROCEDURE [dbo].[admin_AddUserToRole]
    @RoleID INT,
    @UserID INT,
    @IsUnrestricted INT=0 -- Default is restricted.
AS 
    BEGIN TRY
	
	/* check if role exist if so let caller know and exit*/
       IF EXISTS ( SELECT  UserID,RoleID
                FROM    dbo.admin_SecUserRole
                WHERE   RoleID = @RoleID AND UserID=@UserID ) 
        BEGIN
            RAISERROR('UserID %d is already assigned to the Role %d', 0, 42,@UserID ,@RoleID) WITH NoWait ;
        END
        ELSE IF NOT EXISTS (SELECT  RoleID
                FROM    dbo.admin_SecRole
                WHERE   RoleID = @RoleID) 
			BEGIN
				RAISERROR('RoleID %d not available on admin_SecRole table', 0, 42,@RoleID) WITH NoWait ;
			END
	
        ELSE 
            BEGIN
	
                IF ( @RoleID IS NOT NULL AND @RoleID <>0
                     AND @UserID IS NOT NULL AND @UserID <>0) 
                    BEGIN
                        INSERT  INTO dbo.admin_SecUserRole
                                (RoleID, 
                                UserID,
                                IsUnrestricted)
                        VALUES  ( @RoleID, 
                                  @UserID, 
                                  @IsUnrestricted
                                  )
                        RETURN 0;
                    END
				
				DECLARE @WasNullOrBlank NVARCHAR(100)
				
				SELECT @WasNullOrBlank = STUFF((SELECT ',  ' + 
							CASE 
							WHEN @RoleID is NULL THEN 'RoleID was NULL'
							WHEN @UserID is NULL THEN 'UserID was NULL'
						    WHEN @RoleID ='' THEN 'RoleID was zero.'
						    WHEN @UserID ='' THEN 'UserID was zero.'
						END
						FOR XML PATH('')), 1, 2, '')
						
                RAISERROR(' %s  ', 0, 45, @WasNullOrBlank) WITH NoWait ;
	
            END
	
    END TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH





GO
