SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[usp_PROPOSAL_GetProposalsForListByFilter_Report]
    @FormName NVARCHAR(256) = NULL,
    @CountryGroupID INT = NULL,
    @ValidProposalStatusID INT = NULL,
    @TargetPRBSessionID INT = NULL,
    @ValidPRBDecisionID INT = NULL,
    @ValidMakeBuyID INT = NULL,
    @ShowNonCandidatesOnly BIT = 0,
    @MaxLen INT = NULL,
    @UserID INT,
    @PrivCode NVARCHAR(10),
    @MarketResponseIDs NVARCHAR(100)
AS
SET NOCOUNT ON;
/*
This SP includes sp_PROPOSAL_GetProposalsForListByFilter and sp_PROPOSAL_GetProposalsForListByFilterForExport
the status for @ValidProposalStatusID is passed in as a negative integer to determine 
what part is executed

@ValidProposalStatusID :

	-1 bbs.StateName NOT IN ( 'Complete', 'On Hold','Cancelled')	GetProposalsForListByFilter GetProposalsForListByFilterForExport

	-2 bbs.StateName IN ('Complete', 'On Hold', 'Cancelled')		GetProposalsForListByFilter GetProposalsForListByFilterForExport

	Null Everything regardless of bbs state							GetProposalsForListByFilter GetProposalsForListByFilterForExport

All result sets will be returned in Relational Table. 

Using the export portions and the UI will map and format the return set through as necessary
Modified By:  Pradeep Challagundla
Modified Date: 9/29/2011
Modified: Modified according to Reporting services Report requirement and deleted unnecessary columns.  
*/
BEGIN TRY;

    /*
    Set up Country Group IDs
    */
    DECLARE @MarketResponseIDsTbl AS ValidResponseType;
    INSERT INTO @MarketResponseIDsTbl
    SELECT id
    FROM dbo.udf_GetValuesFromCSV(@MarketResponseIDs);

    /********************************************************
First - check for country group privs
*********************************************************/
    -- Set Max Length

    IF @MaxLen = NULL
       OR @MaxLen <= 0
    BEGIN
        SET @MaxLen = 25;
    END;


    /********************************************************
First Create tables holding the valid currency information
from the ExchangeRateLoad Tables.
**********************************************************/
    CREATE TABLE #Forecasts
    (
        ProposalID INT,
        ForecastYear INT,
        TotalAmount DECIMAL(20, 5)
    );

    DECLARE @USD INT;
    SELECT @USD = ValidCurrencyID
    FROM [dbo].tblValidCurrency
    WHERE Name = 'USD';

    DECLARE @MaxRate INT;
    SELECT TOP 1
           @MaxRate = ExRateLoadID
    FROM [dbo].tblExchangeRateLoad x
    ORDER BY EffectiveDate DESC;

    WITH xxx (ProposalID, ForecastYear, ForecastTotal, CurrencyID)
    AS (SELECT DISTINCT
               p.ProductProposalID AS ProposalID,
               psf.ForecastYear,
               ISNULL(SUM(psf.ForecastTurnover), 0),
               ISNULL(psf.ValidCurrencyID, @USD)
        FROM pm.ProductProposal p
            LEFT JOIN(pm.ProductProposalTradeDress ptd
            JOIN pm.ProductProposalSalesForecast psf
                ON ptd.ProductProposalTradeDressID = psf.ProductProposalTradeDressID)
                ON ptd.ProductProposalID = p.ProductProposalID
        GROUP BY p.ProductProposalID,
                 psf.ForecastYear,
                 psf.ValidCurrencyID)
    INSERT INTO #Forecasts
    (
        ProposalID,
        ForecastYear,
        TotalAmount
    )
    SELECT DISTINCT
           xxx.ProposalID,
           ForecastYear,
           SUM(ForecastTotal / x.ConversionFactor2USD)
    FROM xxx
        JOIN pm.ProductProposal p
            ON p.ProductProposalID = xxx.ProposalID
        JOIN pm.Candidate c
            ON c.CandidateID = p.CandidateID
        JOIN pm.PRBSession prb
            ON prb.PRBSessionID = c.TargetPRBSessionID
        JOIN [dbo].tblExchangeRate x
            ON x.ExRateLoadID = prb.ExRateLoadID
               AND x.ValidCurrencyID = xxx.CurrencyID
    GROUP BY xxx.ProposalID,
             ForecastYear
    UNION
    SELECT DISTINCT
           xxx.ProposalID,
           ForecastYear,
           SUM(ForecastTotal / x.ConversionFactor2USD)
    FROM xxx
        JOIN pm.ProductProposal p
            ON p.ProductProposalID = xxx.ProposalID
        JOIN dbo.tblExchangeRate x
            ON x.ValidCurrencyID = xxx.CurrencyID
    WHERE p.CandidateID IS NULL
          AND x.ExRateLoadID = @MaxRate
    GROUP BY xxx.ProposalID,
             ForecastYear;
    /*************************************************
Table For RD Costs to reduce execution time
**************************************************/

    DECLARE @SPECIAL DECIMAL(20, 5);
    SET @SPECIAL = -1974.00;

    CREATE TABLE #RD
    (
        ProposalID INT,
        RDCost DECIMAL(20, 5)
    );

    INSERT [#RD]
    (
        [ProposalID],
        [RDCost]
    )
    SELECT p.ProductProposalID,
           CONVERT(
                      DECIMAL(20, 5),
                      (
                          SELECT SUM(ISNULL(prop.RDBiostudyCost, 0) + ISNULL(prop.RDOverheadCost, 0)
                                     + ISNULL(prop.RDRegulatoryCost, 0) + ISNULL(prop.RDOtherCost, 0)
                                     + ISNULL(prop.ZoneIVCosts, 0) + ISNULL(prop.ClinicalCost, 0)
                                    )
                          FROM pm.ProductProposal prop
                          WHERE prop.ProductProposalID = p.ProductProposalID
                      ) +
                      (
                          SELECT SUM((ISNULL(CostPerUnit / 1000000, 0) * ISNULL(NumOfUnits, 0)))
                          FROM pm.ProductProposalAPI api
                          WHERE ProductProposalID = p.ProductProposalID
                      )
                  )
    FROM pm.ProductProposal p
    GROUP BY p.[ProductProposalID],
             p.[ValidCurrencyID];

    CREATE CLUSTERED INDEX IX_TMP1
    ON #Forecasts (
                      ProposalID,
                      ForecastYear,
                      TotalAmount
                  )/* JRG needs added o source*/;
    CREATE CLUSTERED INDEX IX_TMP2 ON #RD (ProposalID, RDCost);
    /* Add Export events here with the status */

    IF (@ValidProposalStatusID = -1) /* old export -1 value bbs.StateName NOT IN ( 'Complete', 'On Hold','Cancelled' ) */
    BEGIN
        ;
        WITH PeakSalesForecastByProposalID (ProposalId, TotalAmount)
        AS (SELECT ProposalID,
                   MAX(TotalAmount)
            FROM #Forecasts
            GROUP BY ProposalID)
        SELECT p.ProductProposalID AS id,
               p.[ShortName] AS name,
               f.[Name] AS Formname,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Rejected'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesRejected,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Accepted'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesAccepted,
               STUFF(
               (
                   SELECT ', ' + S.Name
                   FROM dbo.tblStrength S
                       JOIN pm.ProductProposalTradeDress ptd
                           ON ptd.ProductProposalID = p.ProductProposalID
                              AND ptd.StrengthID = S.StrengthID
                   WHERE S.[FormID] = f.FormID
                         AND S.[IsUndefined] = 0
                   GROUP BY S.Name
                   ORDER BY LEN(S.Name),
                            S.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS Strengths,
               vmb.Name AS MakeBuyname,
               vmb.ValidMakeBuyID AS MakeBuyid,
               cg.CountryGroupID AS CountryGroupid,
               bbs.StateID AS ProposalStatusid,
               prb.PRBSessionID AS TargetPRBSessionid,
               prbd.ValidPRBDecisionID AS PRBDecisionid,
               bbs.StateName AS ProposalStatusname,
               cg.Name AS CountryGroupname,
               --                            vmst.Name AS ValidMarketSubType ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vmst.[Name]
                              FROM pm.ProductProposalLinkMarketSubtype lmst
                                  JOIN dbo.tblValidMarketSubtype vmst
                                      ON vmst.ValidMarketSubtypeID = lmst.ValidMarketSubtypeID
                              WHERE lmst.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ValidMarketSubType,
               vr.Name AS ValidResponsename,
               prb.Name AS TargetPRBSessionname,
               psfbp.TotalAmount AS PeakSalesTotalAmount,
               rd.RDCost AS RDCost,
               prbd.Name AS PRBDecisionname,
               vpc.Name AS ProposalClassname,
               --vpsc.Name AS ProjectScopeChangename ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vsc.[Name]
                              FROM pm.ProductProposalLinkProjectScopeChange lsc
                                  JOIN dbo.tblValidProjectScopeChange vsc
                                      ON vsc.ValidProjectScopeChangeID = lsc.ValidProjectScopeChangeID
                              WHERE lsc.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ProjectScopeChangename,
               p.MylanRequestedLaunchDate AS MylanRequestedLaunchDate,
               p.MylanRequestedLaunchDateComment AS MylanRequestedLaunchDateComments,
               p.GxMarketFormDate AS MktFormationDate,
               p.GxMarketFormDateComment AS MktFormationDateComments,
               p.MylanLatestFileDate AS MylanLatestFileDate,
               p.MylanLatestFileDateComment AS MylanLatestFileDateComments,
               p.MktPaybackYears AS MarketPaybackYears,
               --vrl.Name AS ValidRationalename,
               STUFF(
               (
                   SELECT ', ' + vr.Name
                   FROM dbo.tblValidRationale vr
                       JOIN pm.ProductProposalLinkValidRationale l
                           ON l.ValidRationaleID = vr.ValidRationaleID
                   WHERE l.ProductProposalID = p.ProductProposalID
                   ORDER BY ', ' + vr.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS ValidRationalename,
               CASE
                   WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPICostPerUnit], 0) AS VARCHAR(22))
               END AS RDAPICostPerUnit,
               CONVERT(   DECIMAL(20, 5),
                          CASE
                              WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                                  0
                              ELSE
                                  ISNULL([p].[RDAPICostPerUnit], 0)
                          END * CASE
                                    WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                                        0
                                    ELSE
                                        ISNULL([p].[RDAPINumOfUnits], 0)
                                END
                      ) AS RDAPICost,
               CASE
                   WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPINumOfUnits], 0) AS VARCHAR(22))
               END AS RDAPINumOfUnits,
               va.Name AS ValidAPIUnitname,
               CASE
                   WHEN [p].[RDNumOfBiostudies] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDNumOfBiostudies], 0) AS VARCHAR(22))
               END AS RDNumOfBiostudies,
               CASE
                   WHEN [p].[RDBiostudyCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDBiostudyCost], 0) AS VARCHAR(22))
               END AS RDBioStudyCost,
               CASE
                   WHEN [p].[RDOverheadCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOverheadCost], 0) AS VARCHAR(22))
               END AS RDOverHeadCost,
               CASE
                   WHEN [p].[RDRegulatoryCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDRegulatoryCost], 0) AS VARCHAR(22))
               END AS RDRegulatoryCost,
               CASE
                   WHEN [p].[RDOtherCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOtherCost], 0) AS VARCHAR(22))
               END AS RDOtherCost,
               p.RDCostComment AS RDCostComment,
               p.IsRDCostComplete AS IsRDCostComplete,
               vsr.Name AS ValidStrategicRationalename,
               vms.Name AS ValidMarketSegmentname,
               vlac.Name AS ValidLevelOfAnticipatedCompetitionname,
               p.BDAssumedGP AS BDAssumedGP,
               vbdr.Name AS ValidBDRationalename,
               vbdat.Name AS ValidBDAgreementTypename,
               p.BDTimingAdvantage AS BDTimingAdvantage,
               p.AnticipatedAccessFee AS AnticipatedAccessFee,
               p.InitialTermAgreement AS InitialTermAgreement,
               p.RenewalTermAgreement AS RenewalTermAgreement,
               p.TermAgreementComment AS TermAgreementComment,
               vbcrad.Name AS ValidBCRADecisionname,
               p.BDGeneralComment AS BDGeneralComment,
               bcra.Name AS OriginalBCRASessionname,
               bcras.Name AS TargetedBCRASessionname,
               PEC.PECCategory AS PECCategory,
               cor.NAME AS ValidCommOpsRatingname,
               tor.NAME AS ValidTechOpsRatingname,
               dbo.udf_InnovatorBrandListByCountryGroupID(p.CountryGroupID, p.FormID, -2) AS InnovatorBrand,
               (
                   SELECT CASE
                              WHEN COUNT(*) > 0 THEN
                                  1
                              ELSE
                                  0
                          END
                   FROM dbo.tblAttachment a
                       JOIN [dbo].tblBusinessBaseObject bbo
                           ON bbo.BBOID = a.BBOID
                   WHERE bbo.BBOCode = 'P'
                         AND a.ObjectID = p.ProductProposalID
               ) AS HasAttachment
        FROM pm.ProductProposal AS p
            JOIN dbo.tblForm AS f
                ON p.FormID = f.FormID
            JOIN dbo.tblCountryGroup AS cg
                ON cg.CountryGroupID = p.CountryGroupID
            JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
                ON a.CountryGroupID = cg.[CountryGroupID]
                   AND a.Privs = 1
            JOIN dbo.tblBusinessBaseStates AS bbs
                ON p.StatusID = bbs.StateID
                   AND [bbs].[StateName] NOT IN ( 'Complete', 'On Hold', 'Cancelled' )
            LEFT OUTER JOIN dbo.tblValidResponse AS vr
                ON vr.ValidResponseID = p.ValidResponseID
            LEFT OUTER JOIN dbo.tblValidMakeBuy AS vmb
                ON p.ValidMakeBuyID = vmb.ValidMakeBuyID
            LEFT OUTER JOIN pm.Candidate AS can
                ON p.CandidateID = can.CandidateID
            LEFT OUTER JOIN pm.PRBSession AS prb
                ON can.TargetPRBSessionID = prb.PRBSessionID
            LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd
                ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
            --LEFT OUTER JOIN dbo.tblValidRationale AS vrl
            --    ON vrl.ValidRationaleID = p.ValidRationaleID
            LEFT JOIN PeakSalesForecastByProposalID AS psfbp
                ON psfbp.ProposalId = p.ProductProposalID
            LEFT JOIN dbo.tblValidAPIUnit AS va
                ON va.ValidAPIUnitID = p.ValidAPIUnitID
            LEFT JOIN dbo.tblValidProposalClass AS vpc
                ON vpc.ValidProposalClassID = p.ValidProposalClassID
            LEFT JOIN dbo.tblValidStrategicRationale AS vsr
                ON vsr.ValidStrategicRationaleID = can.ValidStrategicRationaleID
            LEFT JOIN dbo.tblValidMarketSegment AS vms
                ON vms.ValidMarketSegmentID = can.ValidMarketSegmentID
            LEFT JOIN dbo.tblValidLevelOfAnticipatedCompetition AS vlac
                ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
            LEFT JOIN dbo.tblValidBDRationale AS vbdr
                ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
            LEFT JOIN dbo.tblValidBDAgreementType AS vbdat
                ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
            LEFT JOIN dbo.tblValidBCRADecision AS vbcrad
                ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID
            LEFT JOIN dbo.tblBCRASession AS bcra
                ON bcra.BCRASessionID = p.OriginalBCRASessionID
            LEFT JOIN dbo.tblBCRASession AS bcras
                ON bcras.BCRASessionID = p.TargetedBCRASessionID
            LEFT JOIN dbo.[udf_PECCategoryByFormID_table]() AS PEC
                ON f.[FormID] = PEC.FormID
            LEFT JOIN [#RD] AS rd
                ON rd.ProposalID = p.[ProductProposalID]
            --                            LEFT JOIN dbo.tblValidProjectScopeChange vpsc ON p.ValidProjectScopeChangeID = vpsc.ValidProjectScopeChangeID
            LEFT JOIN dbo.tblValidCommOpsRating cor
                ON cor.ValidCommOpsRatingID = p.ValidCommOpsRatingID
            LEFT JOIN dbo.tblValidTechOpsRating tor
                ON tor.ValidTechOpsRatingID = p.ValidTechOpsRatingID
        --                            LEFT JOIN dbo.tblValidMarketSubtype vmst ON p.ValidMarketSubtypeID = vmst.ValidMarketSubtypeID
        WHERE (
                  @FormName IS NULL
                  OR [f].[Name] LIKE @FormName
              )
              AND
              (
                  @CountryGroupID IS NULL
                  OR @CountryGroupID = [cg].[CountryGroupID]
              )
              AND
              (
                  @MarketResponseIDs IS NULL
                  OR p.ValidResponseID IN
                     (
                         SELECT ValidResponseID FROM @MarketResponseIDsTbl
                     )
              )
              AND
              (
                  @TargetPRBSessionID IS NULL
                  OR @TargetPRBSessionID = [can].[TargetPRBSessionID]
              )
              AND
              (
                  @ValidPRBDecisionID IS NULL
                  OR @ValidPRBDecisionID = [prbd].[ValidPRBDecisionID]
              )
              AND
              (
                  @ShowNonCandidatesOnly = 0
                  OR [p].[CandidateID] IS NULL
              )
              AND
              (
                  @ValidMakeBuyID IS NULL
                  OR @ValidMakeBuyID = [p].[ValidMakeBuyID]
              )
        ORDER BY [p].[ProductProposalID],
                 [p].[Name];
    END;
    ELSE IF (@ValidProposalStatusID = -2) /* old -2 bbs.StateName IN ( 'Complete', 'On Hold','Cancelled' ) */
    BEGIN
        ;
        WITH PeakSalesForecastByProposalID (ProposalId, TotalAmount)
        AS (SELECT ProposalID,
                   MAX(TotalAmount)
            FROM #Forecasts
            GROUP BY ProposalID)
        SELECT p.ProductProposalID AS id,
               p.[ShortName] AS name,
               f.[Name] AS Formname,
               STUFF(
               (
                   SELECT ', ' + S.Name
                   FROM dbo.tblStrength S
                       JOIN pm.ProductProposalTradeDress ptd
                           ON ptd.ProductProposalID = p.ProductProposalID
                              AND ptd.StrengthID = S.StrengthID
                   WHERE S.[FormID] = f.FormID
                         AND S.[IsUndefined] = 0
                   GROUP BY S.Name
                   ORDER BY LEN(S.Name),
                            S.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS Strengths,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Accepted'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesAccepted,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Rejected'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesRejected,
               vmb.Name AS MakeBuyname,
               vmb.ValidMakeBuyID AS MakeBuyid,
               cg.CountryGroupID AS CountryGroupid,
               bbs.StateID AS ProposalStatusid,
               prb.PRBSessionID AS TargetPRBSessionid,
               prbd.ValidPRBDecisionID AS PRBDecisionid,
               bbs.StateName AS ProposalStatusname,
               cg.Name AS CountryGroupname,
               --vmst.Name AS ValidMarketSubType ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vmst.[Name]
                              FROM pm.ProductProposalLinkMarketSubtype lmst
                                  JOIN dbo.tblValidMarketSubtype vmst
                                      ON vmst.ValidMarketSubtypeID = lmst.ValidMarketSubtypeID
                              WHERE lmst.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ValidMarketSubType,
               vr.Name AS ValidResponsename,
               prb.Name AS TargetPRBSessionname,
               psfbp.TotalAmount AS PeakSalesTotalAmount,
               rd.RDCost AS RDCost,
               prbd.Name AS PRBDecisionname,
               vpc.Name AS ProposalClassname,
               --vpsc.Name AS ProjectScopeChangename ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vsc.[Name]
                              FROM pm.ProductProposalLinkProjectScopeChange lsc
                                  JOIN dbo.tblValidProjectScopeChange vsc
                                      ON vsc.ValidProjectScopeChangeID = lsc.ValidProjectScopeChangeID
                              WHERE lsc.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ProjectScopeChangename,
               p.MylanRequestedLaunchDate AS MylanRequestedLaunchDate,
               p.MylanRequestedLaunchDateComment AS MylanRequestedLaunchDateComments,
               p.GxMarketFormDate AS MktFormationDate,
               p.GxMarketFormDateComment AS MktFormationDateComments,
               p.MylanLatestFileDate AS MylanLatestFileDate,
               p.MylanLatestFileDateComment AS MylanLatestFileDateComments,
               p.MktPaybackYears AS MarketPaybackYears,
               --vrl.Name AS ValidRationalename,
               STUFF(
               (
                   SELECT ', ' + vr.Name
                   FROM dbo.tblValidRationale vr
                       JOIN pm.ProductProposalLinkValidRationale l
                           ON l.ValidRationaleID = vr.ValidRationaleID
                   WHERE l.ProductProposalID = p.ProductProposalID
                   ORDER BY ', ' + vr.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS ValidRationalename,
               CASE
                   WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPICostPerUnit], 0) AS VARCHAR(22))
               END AS RDAPICostPerUnit,
               CONVERT(   DECIMAL(20, 5),
                          CASE
                              WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                                  0
                              ELSE
                                  ISNULL([p].[RDAPICostPerUnit], 0)
                          END * CASE
                                    WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                                        0
                                    ELSE
                                        ISNULL([p].[RDAPINumOfUnits], 0)
                                END
                      ) AS RDAPICost,
               CASE
                   WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPINumOfUnits], 0) AS VARCHAR(22))
               END AS RDAPINumOfUnits,
               va.Name AS ValidAPIUnitname,
               CASE
                   WHEN [p].[RDNumOfBiostudies] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDNumOfBiostudies], 0) AS VARCHAR(22))
               END AS RDNumOfBiostudies,
               CASE
                   WHEN [p].[RDBiostudyCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDBiostudyCost], 0) AS VARCHAR(22))
               END AS RDBioStudyCost,
               CASE
                   WHEN [p].[RDOverheadCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOverheadCost], 0) AS VARCHAR(22))
               END AS RDOverHeadCost,
               CASE
                   WHEN [p].[RDRegulatoryCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDRegulatoryCost], 0) AS VARCHAR(22))
               END AS RDRegulatoryCost,
               CASE
                   WHEN [p].[RDOtherCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOtherCost], 0) AS VARCHAR(22))
               END AS RDOtherCost,
               p.RDCostComment AS RDCostComment,
               p.IsRDCostComplete AS IsRDCostComplete,
               vsr.Name AS ValidStrategicRationalename,
               vms.Name AS ValidMarketSegmentname,
               vlac.Name AS ValidLevelOfAnticipatedCompetitionname,
               p.BDAssumedGP AS BDAssumedGP,
               vbdr.Name AS ValidBDRationalename,
               vbdat.Name AS ValidBDAgreementTypename,
               p.BDTimingAdvantage AS BDTimingAdvantage,
               p.AnticipatedAccessFee AS AnticipatedAccessFee,
               p.InitialTermAgreement AS InitialTermAgreement,
               p.RenewalTermAgreement AS RenewalTermAgreement,
               p.TermAgreementComment AS TermAgreementComment,
               vbcrad.Name AS ValidBCRADecisionname,
               p.BDGeneralComment AS BDGeneralComment,
               bcra.Name AS OriginalBCRASessionname,
               bcras.Name AS TargetedBCRASessionname,
               pec.PECCategory AS PECCategory,
               cor.NAME AS ValidCommOpsRatingname,
               tor.NAME AS ValidTechOpsRatingname,
               dbo.udf_InnovatorBrandListByCountryGroupID(p.CountryGroupID, p.FormID, -2) AS InnovatorBrand,
               (
                   SELECT CASE
                              WHEN COUNT(*) > 0 THEN
                                  1
                              ELSE
                                  0
                          END
                   FROM dbo.tblAttachment a
                       JOIN [dbo].tblBusinessBaseObject bbo
                           ON bbo.BBOID = a.BBOID
                   WHERE bbo.BBOCode = 'P'
                         AND a.ObjectID = p.ProductProposalID
               ) AS HasAttachment
        FROM pm.ProductProposal AS p
            JOIN dbo.tblForm AS f
                ON p.FormID = f.FormID
            JOIN dbo.tblCountryGroup AS cg
                ON cg.CountryGroupID = p.CountryGroupID
            JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
                ON a.CountryGroupID = cg.[CountryGroupID]
                   AND a.Privs = 1
            JOIN dbo.tblBusinessBaseStates AS bbs
                ON p.StatusID = bbs.StateID
                   AND [bbs].[StateName] IN ( 'Complete', 'On Hold', 'Cancelled' )
            LEFT OUTER JOIN dbo.tblValidResponse AS vr
                ON vr.ValidResponseID = p.ValidResponseID
            LEFT OUTER JOIN dbo.tblValidMakeBuy AS vmb
                ON p.ValidMakeBuyID = vmb.ValidMakeBuyID
            LEFT OUTER JOIN pm.Candidate AS can
                ON p.CandidateID = can.CandidateID
            LEFT OUTER JOIN pm.PRBSession AS prb
                ON can.TargetPRBSessionID = prb.PRBSessionID
            LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd
                ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
            --LEFT OUTER JOIN dbo.tblValidRationale AS vrl
            --    ON vrl.ValidRationaleID = p.ValidRationaleID
            LEFT JOIN PeakSalesForecastByProposalID AS psfbp
                ON psfbp.ProposalId = p.ProductProposalID
            LEFT JOIN dbo.tblValidAPIUnit AS va
                ON va.ValidAPIUnitID = p.ValidAPIUnitID
            LEFT JOIN dbo.tblValidProposalClass AS vpc
                ON vpc.ValidProposalClassID = p.ValidProposalClassID
            LEFT JOIN dbo.tblValidStrategicRationale AS vsr
                ON vsr.ValidStrategicRationaleID = can.ValidStrategicRationaleID
            LEFT JOIN dbo.tblValidMarketSegment AS vms
                ON vms.ValidMarketSegmentID = can.ValidMarketSegmentID
            LEFT JOIN dbo.tblValidLevelOfAnticipatedCompetition AS vlac
                ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
            LEFT JOIN dbo.tblValidBDRationale AS vbdr
                ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
            LEFT JOIN dbo.tblValidBDAgreementType AS vbdat
                ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
            LEFT JOIN dbo.tblValidBCRADecision AS vbcrad
                ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID
            LEFT JOIN dbo.tblBCRASession AS bcra
                ON bcra.BCRASessionID = p.OriginalBCRASessionID
            LEFT JOIN dbo.tblBCRASession AS bcras
                ON bcras.BCRASessionID = p.TargetedBCRASessionID
            LEFT JOIN dbo.[udf_PECCategoryByFormID_table]() AS pec
                ON f.FormID = pec.FormID
            LEFT JOIN [#RD] AS rd
                ON rd.ProposalID = p.ProductProposalID
            --                                LEFT JOIN dbo.tblValidProjectScopeChange vpsc ON p.ValidProjectScopeChangeID = vpsc.ValidProjectScopeChangeID
            LEFT JOIN dbo.tblValidCommOpsRating cor
                ON cor.ValidCommOpsRatingID = p.ValidCommOpsRatingID
            LEFT JOIN dbo.tblValidTechOpsRating tor
                ON tor.ValidTechOpsRatingID = p.ValidTechOpsRatingID
        --                                LEFT JOIN dbo.tblValidMarketSubtype vmst ON p.ValidMarketSubtypeID = vmst.ValidMarketSubtypeID
        WHERE (
                  @FormName IS NULL
                  OR [f].[Name] LIKE @FormName
              )
              AND
              (
                  @CountryGroupID IS NULL
                  OR @CountryGroupID = [cg].[CountryGroupID]
              )
              AND
              (
                  @MarketResponseIDs IS NULL
                  OR p.ValidResponseID IN
                     (
                         SELECT ValidResponseID FROM @MarketResponseIDsTbl
                     )
              )
              AND
              (
                  @TargetPRBSessionID IS NULL
                  OR @TargetPRBSessionID = [can].[TargetPRBSessionID]
              )
              AND
              (
                  @ValidPRBDecisionID IS NULL
                  OR @ValidPRBDecisionID = [prbd].[ValidPRBDecisionID]
              )
              AND
              (
                  @ShowNonCandidatesOnly = 0
                  OR [p].[CandidateID] IS NULL
              )
              AND
              (
                  @ValidMakeBuyID IS NULL
                  OR @ValidMakeBuyID = [p].[ValidMakeBuyID]
              )
        ORDER BY p.ProductProposalID,
                 p.Name;
    END;

    /* filter on ValidProposalStatus  */
    ELSE IF (@ValidProposalStatusID > 0) /* new filter / export when status is positive value  */
    BEGIN

        ;
        WITH PeakSalesForecastByProposalID (ProposalId, TotalAmount)
        AS (SELECT ProposalID,
                   MAX(TotalAmount)
            FROM #Forecasts
            GROUP BY ProposalID)
        SELECT p.ProductProposalID AS id,
               p.[ShortName] AS name,
               f.[Name] AS Formname,
               STUFF(
               (
                   SELECT ', ' + s.Name
                   FROM dbo.tblStrength s
                       JOIN pm.ProductProposalTradeDress ptd
                           ON ptd.ProductProposalID = p.ProductProposalID
                              AND ptd.StrengthID = s.StrengthID
                   WHERE s.[FormID] = f.FormID
                         AND s.[IsUndefined] = 0
                   GROUP BY s.Name
                   ORDER BY LEN(s.Name),
                            s.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS Strengths,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Accepted'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesAccepted,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Rejected'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesRejected,
               vmb.Name AS MakeBuyname,
               vmb.ValidMakeBuyID AS MakeBuyid,
               cg.CountryGroupID AS CountryGroupid,
               bbs.StateID AS ProposalStatusid,
               prb.PRBSessionID AS TargetPRBSessionid,
               prbd.ValidPRBDecisionID AS PRBDecisionid,
               bbs.StateName AS ProposalStatusname,
               cg.Name AS CountryGroupname,
               --vmst.Name AS ValidMarketSubType ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vmst.[Name]
                              FROM pm.ProductProposalLinkMarketSubtype lmst
                                  JOIN dbo.tblValidMarketSubtype vmst
                                      ON vmst.ValidMarketSubtypeID = lmst.ValidMarketSubtypeID
                              WHERE lmst.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ValidMarketSubType,
               vr.Name AS ValidResponsename,
               prb.Name AS TargetPRBSessionname,
               psfbp.TotalAmount AS PeakSalesTotalAmount,
               rd.RDCost AS RDCost,
               prbd.Name AS PRBDecisionname,
               vpc.Name AS ProposalClassname,
               --vpsc.Name AS ProjectScopeChangename ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vsc.[Name]
                              FROM pm.ProductProposalLinkProjectScopeChange lsc
                                  JOIN dbo.tblValidProjectScopeChange vsc
                                      ON vsc.ValidProjectScopeChangeID = lsc.ValidProjectScopeChangeID
                              WHERE lsc.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ProjectScopeChangename,
               p.MylanRequestedLaunchDate AS MylanRequestedLaunchDate,
               p.MylanRequestedLaunchDateComment AS MylanRequestedLaunchDateComments,
               p.GxMarketFormDate AS MktFormationDate,
               p.GxMarketFormDateComment AS MktFormationDateComments,
               p.MylanLatestFileDate AS MylanLatestFileDate,
               p.MylanLatestFileDateComment AS MylanLatestFileDateComments,
               p.MktPaybackYears AS MarketPaybackYears,
               --vrl.Name AS ValidRationalename,
               STUFF(
               (
                   SELECT ', ' + vr.Name
                   FROM dbo.tblValidRationale vr
                       JOIN pm.ProductProposalLinkValidRationale l
                           ON l.ValidRationaleID = vr.ValidRationaleID
                   WHERE l.ProductProposalID = p.ProductProposalID
                   ORDER BY ', ' + vr.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS ValidRationalename,
               CASE
                   WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPICostPerUnit], 0) AS VARCHAR(22))
               END AS RDAPICostPerUnit,
               CONVERT(   DECIMAL(20, 5),
                          CASE
                              WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                                  0
                              ELSE
                                  ISNULL([p].[RDAPICostPerUnit], 0)
                          END * CASE
                                    WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                                        0
                                    ELSE
                                        ISNULL([p].[RDAPINumOfUnits], 0)
                                END
                      ) AS RDAPICost,
               CASE
                   WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPINumOfUnits], 0) AS VARCHAR(22))
               END AS RDAPINumOfUnits,
               va.Name AS ValidAPIUnitname,
               CASE
                   WHEN [p].[RDNumOfBiostudies] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDNumOfBiostudies], 0) AS VARCHAR(22))
               END AS RDNumOfBiostudies,
               CASE
                   WHEN [p].[RDBiostudyCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDBiostudyCost], 0) AS VARCHAR(22))
               END AS RDBioStudyCost,
               CASE
                   WHEN [p].[RDOverheadCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOverheadCost], 0) AS VARCHAR(22))
               END AS RDOverHeadCost,
               CASE
                   WHEN [p].[RDRegulatoryCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDRegulatoryCost], 0) AS VARCHAR(22))
               END AS RDRegulatoryCost,
               CASE
                   WHEN [p].[RDOtherCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOtherCost], 0) AS VARCHAR(22))
               END AS RDOtherCost,
               p.RDCostComment AS RDCostComment,
               p.IsRDCostComplete AS IsRDCostComplete,
               vsr.Name AS ValidStrategicRationalename,
               vms.Name AS ValidMarketSegmentname,
               vlac.Name AS ValidLevelOfAnticipatedCompetitionname,
               p.BDAssumedGP AS BDAssumedGP,
               vbdr.Name AS ValidBDRationalename,
               vbdat.Name AS ValidBDAgreementTypename,
               p.BDTimingAdvantage AS BDTimingAdvantage,
               p.AnticipatedAccessFee AS AnticipatedAccessFee,
               p.InitialTermAgreement AS InitialTermAgreement,
               p.RenewalTermAgreement AS RenewalTermAgreement,
               p.TermAgreementComment AS TermAgreementComment,
               vbcrad.Name AS ValidBCRADecisionname,
               p.BDGeneralComment AS BDGeneralComment,
               bcra.Name AS OriginalBCRASessionname,
               bcras.Name AS TargetedBCRASessionname,
               pec.PECCategory AS PECCategory,
               cor.NAME AS ValidCommOpsRatingname,
               tor.NAME AS ValidTechOpsRatingname,
               dbo.udf_InnovatorBrandListByCountryGroupID(p.CountryGroupID, p.FormID, -2) AS InnovatorBrand,
               (
                   SELECT CASE
                              WHEN COUNT(*) > 0 THEN
                                  1
                              ELSE
                                  0
                          END
                   FROM dbo.tblAttachment a
                       JOIN [dbo].tblBusinessBaseObject bbo
                           ON bbo.BBOID = a.BBOID
                   WHERE bbo.BBOCode = 'P'
                         AND a.ObjectID = p.ProductProposalID
               ) AS HasAttachment
        FROM pm.ProductProposal AS p
            JOIN dbo.tblForm AS f
                ON p.FormID = f.FormID
            JOIN dbo.tblCountryGroup AS cg
                ON cg.CountryGroupID = p.CountryGroupID
            JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
                ON a.CountryGroupID = cg.[CountryGroupID]
                   AND a.Privs = 1
            JOIN dbo.tblBusinessBaseStates AS bbs
                ON p.StatusID = bbs.StateID
            LEFT OUTER JOIN dbo.tblValidResponse AS vr
                ON vr.ValidResponseID = p.ValidResponseID
            LEFT OUTER JOIN dbo.tblValidMakeBuy AS vmb
                ON p.ValidMakeBuyID = vmb.ValidMakeBuyID
            LEFT OUTER JOIN pm.Candidate AS can
                ON p.CandidateID = can.CandidateID
            LEFT OUTER JOIN pm.PRBSession AS prb
                ON can.TargetPRBSessionID = prb.PRBSessionID
            LEFT OUTER JOIN dbo.tblValidPRBDecision AS prbd
                ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
            --LEFT OUTER JOIN dbo.tblValidRationale AS vrl
            --    ON vrl.ValidRationaleID = p.ValidRationaleID
            LEFT JOIN PeakSalesForecastByProposalID AS psfbp
                ON psfbp.ProposalId = p.ProductProposalID
            LEFT JOIN dbo.tblValidAPIUnit AS va
                ON va.ValidAPIUnitID = p.ValidAPIUnitID
            LEFT JOIN dbo.tblValidProposalClass AS vpc
                ON vpc.ValidProposalClassID = p.ValidProposalClassID
            LEFT JOIN dbo.tblValidStrategicRationale AS vsr
                ON vsr.ValidStrategicRationaleID = can.ValidStrategicRationaleID
            LEFT JOIN dbo.tblValidMarketSegment AS vms
                ON vms.ValidMarketSegmentID = can.ValidMarketSegmentID
            LEFT JOIN dbo.tblValidLevelOfAnticipatedCompetition AS vlac
                ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
            LEFT JOIN dbo.tblValidBDRationale AS vbdr
                ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
            LEFT JOIN dbo.tblValidBDAgreementType AS vbdat
                ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
            LEFT JOIN dbo.tblValidBCRADecision AS vbcrad
                ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID
            LEFT JOIN dbo.tblBCRASession AS bcra
                ON bcra.BCRASessionID = p.OriginalBCRASessionID
            LEFT JOIN dbo.tblBCRASession AS bcras
                ON bcras.BCRASessionID = p.TargetedBCRASessionID
            LEFT JOIN dbo.[udf_PECCategoryByFormID_table]() AS pec
                ON f.[FormID] = pec.FormID
            LEFT JOIN [#RD] AS rd
                ON rd.ProposalID = p.ProductProposalID
            --                                    LEFT JOIN dbo.tblValidProjectScopeChange vpsc ON p.ValidProjectScopeChangeID = vpsc.ValidProjectScopeChangeID
            LEFT JOIN dbo.tblValidCommOpsRating cor
                ON cor.ValidCommOpsRatingID = p.ValidCommOpsRatingID
            LEFT JOIN dbo.tblValidTechOpsRating tor
                ON tor.ValidTechOpsRatingID = p.ValidTechOpsRatingID
        --                                    LEFT JOIN dbo.tblValidMarketSubtype vmst ON p.ValidMarketSubtypeID = vmst.ValidMarketSubtypeID
        WHERE (
                  @FormName IS NULL
                  OR [f].[Name] LIKE @FormName
              )
              AND
              (
                  @CountryGroupID IS NULL
                  OR @CountryGroupID = [cg].[CountryGroupID]
              )
              AND
              (
                  @MarketResponseIDs IS NULL
                  OR p.ValidResponseID IN
                     (
                         SELECT ValidResponseID FROM @MarketResponseIDsTbl
                     )
              )
              AND
              (
                  @TargetPRBSessionID IS NULL
                  OR @TargetPRBSessionID = [can].[TargetPRBSessionID]
              )
              AND
              (
                  @ValidPRBDecisionID IS NULL
                  OR @ValidPRBDecisionID = [prbd].[ValidPRBDecisionID]
              )
              AND
              (
                  @ShowNonCandidatesOnly = 0
                  OR [p].[CandidateID] IS NULL
              )
              AND
              (
                  @ValidMakeBuyID IS NULL
                  OR @ValidMakeBuyID = [p].[ValidMakeBuyID]
              )
              AND (p.StatusID = @ValidProposalStatusID)
        ORDER BY p.ProductProposalID,
                 p.Name;

    END;
    ELSE
    /* Old @ValidProposalStatusID NOT IN ( -1, -2 ) OR @ValidProposalStatusID IS NULL*/
    BEGIN
        ;
        WITH PeakSalesForecastByProposalID (ProposalId, TotalAmount)
        AS (SELECT ProposalID,
                   MAX(TotalAmount)
            FROM #Forecasts
            GROUP BY ProposalID)
        SELECT p.ProductProposalID AS id,
               p.[ShortName] AS name,
               f.[Name] AS Formname,
               STUFF(
               (
                   SELECT ', ' + S.Name
                   FROM dbo.tblStrength S
                       JOIN pm.ProductProposalTradeDress ptd
                           ON ptd.ProductProposalID = p.ProductProposalID
                              AND ptd.StrengthID = S.StrengthID
                   WHERE S.[FormID] = f.FormID
                         AND S.[IsUndefined] = 0
                   GROUP BY S.Name
                   ORDER BY LEN(S.Name),
                            S.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS Strengths,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Accepted'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesAccepted,
               STUFF(
               (
                   SELECT ', ' + [tc].[Code]
                   FROM pm.ProductProposalCountryInterest AS tpci
                       JOIN [dbo].[tblCountry] AS tc
                           ON [tpci].[CountryID] = [tc].[CountryID]
                       JOIN [dbo].[tblValidPRBDecision] AS tvpd
                           ON [tpci].[ValidPRBDecisionID] = [tvpd].[ValidPRBDecisionID]
                              AND [tvpd].[Name] = 'Rejected'
                   WHERE [tpci].[ProductProposalID] = [p].[ProductProposalID]
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS CountriesRejected,
               vmb.Name AS MakeBuyname,
               vmb.ValidMakeBuyID AS MakeBuyid,
               cg.CountryGroupID AS CountryGroupid,
               bbs.StateID AS ProposalStatusid,
               prb.PRBSessionID AS TargetPRBSessionid,
               prbd.ValidPRBDecisionID AS PRBDecisionid,
               bbs.StateName AS ProposalStatusname,
               cg.Name AS CountryGroupname,
               --vmst.Name AS ValidMarketSubType ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vmst.[Name]
                              FROM pm.ProductProposalLinkMarketSubtype lmst
                                  JOIN dbo.tblValidMarketSubtype vmst
                                      ON vmst.ValidMarketSubtypeID = lmst.ValidMarketSubtypeID
                              WHERE lmst.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ValidMarketSubType,
               vr.Name AS ValidResponsename,
               prb.Name AS TargetPRBSessionname,
               psfbp.TotalAmount AS PeakSalesTotalAmount,
               rd.RDCost AS RDCost,
               prbd.Name AS PRBDecisionname,
               vpc.Name AS ProposalClassname,
               --vpsc.Name AS ProjectScopeChangename ,
               (
                   SELECT STUFF(
                          (
                              SELECT DISTINCT
                                     ', ' + vsc.[Name]
                              FROM pm.ProductProposalLinkProjectScopeChange lsc
                                  JOIN dbo.tblValidProjectScopeChange vsc
                                      ON vsc.ValidProjectScopeChangeID = lsc.ValidProjectScopeChangeID
                              WHERE lsc.ProductProposalID = p.ProductProposalID
                              FOR XML PATH('')
                          ),
                          1,
                          2,
                          ''
                               )
               ) AS ProjectScopeChangename,
               p.MylanRequestedLaunchDate AS MylanRequestedLaunchDate,
               p.MylanRequestedLaunchDateComment AS MylanRequestedLaunchDateComments,
               p.GxMarketFormDate AS MktFormationDate,
               p.GxMarketFormDateComment AS MktFormationDateComments,
               p.MylanLatestFileDate AS MylanLatestFileDate,
               p.MylanLatestFileDateComment AS MylanLatestFileDateComments,
               p.MktPaybackYears AS MarketPaybackYears,
               --vrl.Name AS ValidRationalename,
               STUFF(
               (
                   SELECT ', ' + vr.Name
                   FROM dbo.tblValidRationale vr
                       JOIN pm.ProductProposalLinkValidRationale l
                           ON l.ValidRationaleID = vr.ValidRationaleID
                   WHERE l.ProductProposalID = p.ProductProposalID
                   ORDER BY ', ' + vr.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    ) AS ValidRationalename,
               CASE
                   WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPICostPerUnit], 0) AS VARCHAR(22))
               END AS RDAPICostPerUnit,
               CONVERT(   DECIMAL(20, 5),
                          CASE
                              WHEN [p].[RDAPICostPerUnit] = @SPECIAL THEN
                                  0
                              ELSE
                                  ISNULL([p].[RDAPICostPerUnit], 0)
                          END * CASE
                                    WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                                        0
                                    ELSE
                                        ISNULL([p].[RDAPINumOfUnits], 0)
                                END
                      ) AS RDAPICost,
               CASE
                   WHEN [p].[RDAPINumOfUnits] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDAPINumOfUnits], 0) AS VARCHAR(22))
               END AS RDAPINumOfUnits,
               va.Name AS ValidAPIUnitname,
               CASE
                   WHEN [p].[RDNumOfBiostudies] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDNumOfBiostudies], 0) AS VARCHAR(22))
               END AS RDNumOfBiostudies,
               CASE
                   WHEN [p].[RDBiostudyCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDBiostudyCost], 0) AS VARCHAR(22))
               END AS RDBioStudyCost,
               CASE
                   WHEN [p].[RDOverheadCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOverheadCost], 0) AS VARCHAR(22))
               END AS RDOverHeadCost,
               CASE
                   WHEN [p].[RDRegulatoryCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDRegulatoryCost], 0) AS VARCHAR(22))
               END AS RDRegulatoryCost,
               CASE
                   WHEN [p].[RDOtherCost] = @SPECIAL THEN
                       'N/A'
                   ELSE
                       CAST(ISNULL([p].[RDOtherCost], 0) AS VARCHAR(22))
               END AS RDOtherCost,
               p.RDCostComment AS RDCostComment,
               p.IsRDCostComplete AS IsRDCostComplete,
               vsr.Name AS ValidStrategicRationalename,
               vms.Name AS ValidMarketSegmentname,
               vlac.Name AS ValidLevelOfAnticipatedCompetitionname,
               p.BDAssumedGP AS BDAssumedGP,
               vbdr.Name AS ValidBDRationalename,
               vbdat.Name AS ValidBDAgreementTypename,
               p.BDTimingAdvantage AS BDTimingAdvantage,
               p.AnticipatedAccessFee AS AnticipatedAccessFee,
               p.InitialTermAgreement AS InitialTermAgreement,
               p.RenewalTermAgreement AS RenewalTermAgreement,
               p.TermAgreementComment AS TermAgreementComment,
               vbcrad.Name AS ValidBCRADecisionname,
               p.BDGeneralComment AS BDGeneralComment,
               bcra.Name AS OriginalBCRASessionname,
               bcras.Name AS TargetedBCRASessionname,
               LTRIM(STUFF(
                     (
                         SELECT DISTINCT
                                '|' + pec.PECCategory + ' - ' + vki.Name
                         FROM dbo.tblForm f1
                             JOIN dbo.tblProductLinkKPI AS plk
                                 ON f1.ProductID = plk.ProductID
                             JOIN dbo.tblKPI kpi
                                 ON kpi.KPIID = plk.KPIID
                             JOIN dbo.tblValidKeyIngredient AS vki
                                 ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                             LEFT JOIN dbo.[udf_PECCategoryByFormID_table]() AS pec
                                 ON f1.FormID = pec.FormID
                         WHERE f1.FormID = p.FormID
                         ORDER BY '|' + pec.PECCategory + ' - ' + vki.Name DESC
                         FOR XML PATH('')
                     ),
                     1,
                     1,
                     ''
                          )
                    ) AS PECCategory,
               dbo.udf_EHSAlert(f.ProductID, NULL) AS EHSAlert,
               dbo.udf_GetMPBClassifications(f.ProductID) AS OEBClassifications,
               dbo.udf_GetDrugClassifications(f.ProductID) AS DrugClassifications,
               cor.NAME AS ValidCommOpsRatingname,
               tor.NAME AS ValidTechOpsRatingname,
               dbo.udf_InnovatorBrandListByCountryGroupID(p.CountryGroupID, p.FormID, -2) AS InnovatorBrand,
               (
                   SELECT CASE
                              WHEN COUNT(*) > 0 THEN
                                  1
                              ELSE
                                  0
                          END
                   FROM dbo.tblAttachment a
                       JOIN [dbo].tblBusinessBaseObject bbo
                           ON bbo.BBOID = a.BBOID
                   WHERE bbo.BBOCode = 'P'
                         AND a.ObjectID = p.ProductProposalID
               ) AS HasAttachment
        FROM pm.ProductProposal AS p
            JOIN dbo.tblForm AS f
                ON p.FormID = f.FormID
            JOIN dbo.tblCountryGroup AS cg
                ON cg.CountryGroupID = p.CountryGroupID
            JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID, @PrivCode) AS a
                ON a.CountryGroupID = cg.[CountryGroupID]
                   AND a.Privs = 1
            JOIN dbo.tblBusinessBaseStates AS bbs
                ON p.StatusID = bbs.StateID
            LEFT JOIN dbo.tblValidResponse AS vr
                ON vr.ValidResponseID = p.ValidResponseID
            LEFT JOIN dbo.tblValidMakeBuy AS vmb
                ON p.ValidMakeBuyID = vmb.ValidMakeBuyID
            LEFT JOIN pm.Candidate AS can
                ON p.CandidateID = can.CandidateID
            LEFT JOIN pm.PRBSession AS prb
                ON can.TargetPRBSessionID = prb.PRBSessionID
            LEFT JOIN dbo.tblValidPRBDecision AS prbd
                ON p.ValidPRBDecisionID = prbd.ValidPRBDecisionID
            --LEFT JOIN dbo.tblValidRationale AS vrl
            --    ON vrl.ValidRationaleID = p.ValidRationaleID
            LEFT JOIN PeakSalesForecastByProposalID AS psfbp
                ON psfbp.ProposalId = p.ProductProposalID
            LEFT JOIN dbo.tblValidAPIUnit AS va
                ON va.ValidAPIUnitID = p.ValidAPIUnitID
            LEFT JOIN dbo.tblValidProposalClass AS vpc
                ON vpc.ValidProposalClassID = p.ValidProposalClassID
            LEFT JOIN dbo.tblValidStrategicRationale AS vsr
                ON vsr.ValidStrategicRationaleID = can.ValidStrategicRationaleID
            LEFT JOIN dbo.tblValidMarketSegment AS vms
                ON vms.ValidMarketSegmentID = can.ValidMarketSegmentID
            LEFT JOIN dbo.tblValidLevelOfAnticipatedCompetition AS vlac
                ON vlac.ValidLevelOfAnticipatedCompetitionID = p.ValidLevelOfAnticipatedCompetitionID
            LEFT JOIN dbo.tblValidBDRationale AS vbdr
                ON vbdr.ValidBDRationaleID = p.ValidBDRationaleID
            LEFT JOIN dbo.tblValidBDAgreementType AS vbdat
                ON vbdat.ValidBDAgreementTypeID = p.ValidBDAgreementTypeID
            LEFT JOIN dbo.tblValidBCRADecision AS vbcrad
                ON vbcrad.ValidBCRADecisionID = p.ValidBCRADecisionID
            LEFT JOIN dbo.tblBCRASession AS bcra
                ON bcra.BCRASessionID = p.OriginalBCRASessionID
            LEFT JOIN dbo.tblBCRASession AS bcras
                ON bcras.BCRASessionID = p.TargetedBCRASessionID
            LEFT JOIN dbo.[udf_PECCategoryByFormID_table]() AS pec
                ON f.FormID = pec.FormID
            LEFT JOIN [#RD] AS rd
                ON rd.ProposalID = p.ProductProposalID
            --                                    LEFT JOIN dbo.tblValidProjectScopeChange vpsc ON p.ValidProjectScopeChangeID = vpsc.ValidProjectScopeChangeID
            LEFT JOIN dbo.tblValidCommOpsRating cor
                ON cor.ValidCommOpsRatingID = p.ValidCommOpsRatingID
            LEFT JOIN dbo.tblValidTechOpsRating tor
                ON tor.ValidTechOpsRatingID = p.ValidTechOpsRatingID
        --                                    LEFT JOIN dbo.tblValidMarketSubtype vmst ON p.ValidMarketSubtypeID = vmst.ValidMarketSubtypeID
        WHERE (
                  @FormName IS NULL
                  OR [f].[Name] LIKE @FormName
              )
              AND
              (
                  @CountryGroupID IS NULL
                  OR @CountryGroupID = [cg].[CountryGroupID]
              )
              AND
              (
                  @MarketResponseIDs IS NULL
                  OR p.ValidResponseID IN
                     (
                         SELECT ValidResponseID FROM @MarketResponseIDsTbl
                     )
              )
              AND
              (
                  @TargetPRBSessionID IS NULL
                  OR @TargetPRBSessionID = [can].[TargetPRBSessionID]
              )
              AND
              (
                  @ValidPRBDecisionID IS NULL
                  OR @ValidPRBDecisionID = [prbd].[ValidPRBDecisionID]
              )
              AND
              (
                  @ShowNonCandidatesOnly = 0
                  OR [p].[CandidateID] IS NULL
              )
              AND
              (
                  @ValidMakeBuyID IS NULL
                  OR @ValidMakeBuyID = [p].[ValidMakeBuyID]
              )
        ORDER BY p.ProductProposalID,
                 p.Name;
    END;

    DROP TABLE [#RD];
    DROP TABLE #Forecasts;

    RETURN 0;
END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
