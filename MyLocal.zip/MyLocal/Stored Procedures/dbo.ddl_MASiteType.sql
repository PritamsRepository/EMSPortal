SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[ddl_MASiteType] AS
BEGIN TRY
	/* Predefined company groups will be shown to pick from */
	
	
	SELECT VT.ValidSiteTypeID AS CompanyGroupID, VT.Category AS NAME, VT.Name AS CompanyGroupName 
	
	FROM dbo.tblValidSiteType VT 
	JOIN dbo.tblCompanyGroup CG ON VT.NAME=CG.[Text]
	ORDER BY DisplayOrder
	
END TRY
BEGIN CATCH 
	EXEC dbo.sp_RollAndRaise
END CATCH 



GO
GRANT EXECUTE ON  [dbo].[ddl_MASiteType] TO [mp_db_execute]
GO
