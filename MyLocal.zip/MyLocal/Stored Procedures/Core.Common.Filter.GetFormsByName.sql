SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Common.Filter].[GetFormsByName]
	@Name nvarchar(256) = NULL
AS
	SELECT 
		F.FormID, F.Name
	FROM 
		dbo.tblForm F
	WHERE 
		(@Name IS Null OR F.Name like @Name + '%')
		AND isPublic = 1
	ORDER BY f.name

GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetFormsByName] TO [mp_db_execute]
GO
