SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_ProjectCountryGroups]
	@UserID INT,
	@PrivCode NVARCHAR(100) = NULL
	
AS

BEGIN TRY

	SELECT DISTINCT
		cg.CountryGroupID AS ID,
		cg.Name
	FROM
		pm.Project p
		JOIN dbo.tblCountryGroup cg ON p.CountryGroupID = cg.CountryGroupID
	WHERE
		(@UserID IS NULL OR dbo.udf_UserHasPrivForCountryGroup(@UserID, @PrivCode, p.CountryGroupID) = 'True')
	ORDER BY
		cg.Name;

END TRY
BEGIN CATCH

	EXEC sp_RollAndRaise;

END CATCH
GO
