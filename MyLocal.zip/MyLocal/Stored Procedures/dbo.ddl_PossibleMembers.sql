SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_PossibleMembers] ( @TeamID INT, @BBOID INT )
AS /*
*********************************************************************************
Christian Duvall; Team Maintenance - get all of the managers on a given team.
*********************************************************************************
*/

    BEGIN TRY 

        SELECT DISTINCT
                su.UserID AS ID ,
                su.FullName AS [Name]
        FROM    admin_SecUser su /* add condition for where the user has at least one privilege with the BBOID of the team. */
                JOIN admin_SecUserRole sur ON sur.UserID = su.UserID
                JOIN admin_SecRolePriv srp ON srp.RoleID = sur.RoleID  
				--join admin_SecPriv sp on sp.PrivID = srp.PrivID
                JOIN tblTeam t ON t.BBOID = srp.BBOID 
                --OR  srp.BBOID = (select distinct t.BBOID from tblTeam where t.TeamID = @TeamID)
        WHERE   NOT EXISTS ( SELECT sult.UserID
                             FROM   admin_SecUserLinkTeam sult
                             WHERE  sult.UserID = su.UserID
                                    AND sult.TeamID = @TeamID )
                AND su.FullName IS NOT NULL	
	
    END TRY


    BEGIN CATCH
        EXECUTE [dbo].[sp_RollAndRaise]
    END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_PossibleMembers] TO [mp_db_execute]
GO
