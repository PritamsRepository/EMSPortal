SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO








------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_SecurityUserDetail_Listing]
	@ID INT = NULL,
	@SearchUserName NVARCHAR(100) = NULL,
	@RoleID INT = NULL,
	@CountryGroupID INT = NULL,
	@CountryID INT = NULL,
	@Inactive BIT = NULL,
	@IsUnrestricted BIT = NULL,
	@DirectManagerID INT = NULL,
	@RegionalManagerID INT = NULL,
	@GlobalHeadID INT = NULL,
	@UserID int,
	@PrivCode nvarchar(10)
AS
BEGIN TRY
		
		 DECLARE @Users TABLE
            (
            UserID INT,
            ADUserName NVARCHAR(100) NULL
            )
        INSERT INTO @Users (UserID, ADUserName )    
		SELECT su.UserID, su.ADUserName 
		FROM dbo.udf_SecurityUsers_Filtered(@ID,@SearchUserName,@RoleID,@CountryGroupID, @CountryID,@Inactive, @IsUnrestricted, @DirectManagerID, @RegionalManagerID, @GlobalHeadID, @UserID,@PrivCode) as uf
		JOIN dbo.admin_SecUser su
			on uf.UserID = su.UserID 
			
		IF @@ROWCOUNT = 0
		BEGIN
		INSERT INTO @Users (UserID) 
		VALUES(0)
		END
		
		SELECT UserID, ADUserName from @Users	
		
		
	
END TRY
BEGIN CATCH
	EXEC dbo.sp_RollAndRaise
END CATCH








GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_SecurityUserDetail_Listing] TO [mp_db_execute]
GO
