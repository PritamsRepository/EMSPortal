SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[MAApplication_Report_Submission]
    (
      @MAApplicationID INT = NULL ,
      @Country NVARCHAR(MAX) = NULL ,
      @Region NVARCHAR(MAX) = NULL
    )
AS
    BEGIN
        DECLARE @CountryID INT = ( SELECT   CountryID
                                   FROM     dbo.tblCountry
                                   WHERE    Code = @Country
                                 )

        DECLARE @CountryGroupID INT = ( SELECT  CountryGroupID
                                        FROM    dbo.tblCountryGroup
                                        WHERE   CountryGroupType = 'MAMkt'
                                                AND Name = @Region
                                      )
        DECLARE @swbboid INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'SW'
                               )

-- Sheet 2 Submissions
        SELECT  masw.MASubmissionWorkstreamID ,
                masw.MAApplicationID ,
                ( SELECT    c.Code
                  FROM      dbo.tblCountry c
                  WHERE     c.CountryID = ha.CountryID
                ) AS Country ,
                ha.Name AS [Assessing HA] ,
                CASE WHEN masw.ParentSubmissionID IS NULL THEN 'No'
                     ELSE 'Yes'
                END AS [HA is CMS] ,
                vst.Name AS [Submission Type] ,
                bbs.StateName AS [Submission Status] ,
                ( SELECT    CASE WHEN m.ReferenceMilestoneID IS NULL
                                 THEN REPLACE(CONVERT(VARCHAR(15), m.BestEstimateDate, 106),
                                              ' ', '-')
                                 ELSE REPLACE(CONVERT(VARCHAR(15), refm.BestEstimateDate, 106),
                                              ' ', '-')
                            END
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'Submission'
                ) AS [Submission Date] ,
                ( SELECT    vms.Name
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'Submission'
                ) AS [Submission Date Status] ,
                ( SELECT    CASE WHEN m.ReferenceMilestoneID IS NULL
                                 THEN REPLACE(CONVERT(VARCHAR(15), m.BestEstimateDate, 106),
                                              ' ', '-')
                                 ELSE REPLACE(CONVERT(VARCHAR(15), refm.BestEstimateDate, 106),
                                              ' ', '-')
                            END
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'SW - Reg Proc Close'
                ) AS [Regulatory Procedure Closed Date] ,
                ( SELECT    vms.Name
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'SW - Reg Proc Close'
                ) AS [Regulatory Procedure Closed Status] ,
                ( SELECT    CASE WHEN m.ReferenceMilestoneID IS NULL
                                 THEN REPLACE(CONVERT(VARCHAR(15), m.BestEstimateDate, 106),
                                              ' ', '-')
                                 ELSE REPLACE(CONVERT(VARCHAR(15), refm.BestEstimateDate, 106),
                                              ' ', '-')
                            END
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'SW - Final Reg Approval'
                ) AS [Final Reg Approval Date] ,
                ( SELECT    vms.Name
                  FROM      dbo.tblGlobalMilestone gm
                            JOIN dbo.tblBusinessBaseObject bbo ON gm.BBOID = bbo.BBOID
                            JOIN ( dbo.tblMilestone m
                                   JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                   JOIN dbo.tblValidMilestoneStatus vms ON vms.ValidMilestoneStatusID = m.StatusID
                                 ) ON m.ObjectID = masw.MASubmissionWorkstreamID
                                      AND mti.GlobalMilestoneID = gm.GlobalMileStoneID
                            LEFT JOIN dbo.tblMilestone refm ON m.ReferenceMilestoneID = refm.MileStoneID
                  WHERE     m.ObjectID = masw.MASubmissionWorkstreamID
                            AND m.BBOID = @swbboid
                            AND gm.Code = 'SW - Final Reg Approval'
                ) AS [Final Reg Approval Status] ,
                ( SELECT    c.Name
                  FROM      dbo.tblCompany c
                            JOIN dbo.tblBrand b ON b.BrandCompanyID = c.CompanyID
                            JOIN pm.Project p ON p.BrandID = b.BrandID
                  WHERE     p.ProjectID = masw.ProjectID
                ) AS [Innovator] ,
                ( SELECT    b.Name
                  FROM      dbo.tblBrand b
                            JOIN pm.Project p ON p.BrandID = b.BrandID
                  WHERE     p.ProjectID = masw.ProjectID
                ) AS [Brand Name]
        FROM    dbo.MASubmissionWorkstream masw
                JOIN dbo.tblCompany ha ON ha.CompanyID = masw.HealthAuthorityID
                JOIN dbo.tblSubmissionRoute sr ON sr.SubmissionRouteID = masw.SubmissionRouteID
                JOIN dbo.tblMAApplication ma ON ma.MAApplicationID = masw.MAApplicationID
                JOIN dbo.tblValidMASubmissionType vst ON vst.ValidMASubmissionTypeID = masw.ValidMASubmissionTypeID
                JOIN dbo.tblBusinessBaseStates bbs ON bbs.StateID = masw.MASubmissionWorkstreamStatusID
                LEFT JOIN dbo.tblCompany dev ON dev.CompanyID = ma.DevelopmentSiteID
        WHERE   ( CASE WHEN @MAApplicationID IS NULL THEN 1
                       WHEN ma.MAApplicationID = @MAApplicationID THEN 1
                       ELSE 0
                  END ) = 1
                AND ( CASE WHEN @CountryID IS NULL THEN 1
                           WHEN @CountryID = ha.CountryID THEN 1
                           ELSE 0
                      END ) = 1
                AND ( @CountryGroupID IS NULL
                      OR @CountryGroupID IN (
                      SELECT    cg.CountryGroupID
                      FROM      dbo.tblCountryLinkCountryGroup clcg
                                JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
                      WHERE     CountryID = ha.CountryID
                                AND CountryGroupType = 'MAMkt' )
                    )
    END
GO
