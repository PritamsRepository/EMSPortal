SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
CREATE PROCEDURE [Core.Common.CRUD].[Comment_Delete]
    @CommentID INT ,
    @UpdateUserID INT = NULL 
AS 

    DECLARE @BBOID INT ,
        @BBOCode NVARCHAR(50) ,
        @ActionType CHAR(1) ,
        @RowsAffected INT,
		@LocalCommentID INT,
		@UserOnComment INT 
		
    SET @ActionType = 'D'
    
	/* Check to see if the record exists and get the bboid for our audit look-up*/
    
    SELECT  @BBOID = BBOID, @UserOnComment= UserID
    FROM    dbo.tblComment
    WHERE   CommentID = @CommentID ;
    
	SELECT @BBOCode = BBOCode FROM dbo.tblBusinessBaseObject
	WHERE BBOID = @BBOID;
			
	/* Only allow the user to delete their comments */
	
	IF (@UpdateUserID <> @UserOnComment)
		BEGIN
            RETURN 2 ; /* Not your comment delete not allowed*/
        END          

    ELSE 
        BEGIN	
            BEGIN TRAN DeleteComment
			
			/* Retreive the bbocode for the bboid for auditing */
			
            DELETE  FROM dbo.tblComment
            WHERE   CommentID = @CommentID ;
	 
			
			/* Add the delete audit event to the auditing system */
			
            EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                @UserID = @UpdateUserID, @ObjectID = @CommentID,
                @ActionType = @ActionType

		
            COMMIT ;
        END
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Comment_Delete] TO [mp_db_execute]
GO
