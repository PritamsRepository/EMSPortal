SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------


CREATE Procedure [dbo].[ddl_RegulatoryTeamsByRegion] ( @CountryGroupID int, @CompanyID int = NULL )
AS /**********************************************************************************
By:			Robin Abramson
Intent:		Input: @CountryGroupID int 

Returns:
CompanyID as RegTeamID
Name as RegTeam
 
 
---
 
Return all regulatory teams for a given region.  
To access the countries within a region, use the provided @CountryGroupID ("KeyMkt").
**********************************************************************************/

    BEGIN TRY 

        SELECT DISTINCT
                [tc].[CompanyID],
                [tc].[name]
        FROM    [dbo].[tblCompany] AS tc
                JOIN [dbo].[tblCountry] AS tc2 ON [tc].[CountryID] = [tc2].[CountryID]
                JOIN [dbo].[tblCountryLinkCountryGroup] AS tclcg ON [tc2].[CountryID] = [tclcg].[CountryID]
                JOIN [dbo].[tblCountryGroup] AS tcg ON [tclcg].[CountryGroupID] = [tcg].[CountryGroupID]
        WHERE   [tcg].[CountryGroupID] = @CountryGroupID
				UNION
				SELECT [c].[CompanyID], [c].[name]
				FROM dbo.tblCompany c
				WHERE c.CompanyID = @CompanyID

        RETURN 0 ;
    END TRY

    BEGIN CATCH
        EXECUTE [dbo].[sp_RollAndRaise]
    END CATCH


GO
GRANT EXECUTE ON  [dbo].[ddl_RegulatoryTeamsByRegion] TO [mp_db_execute]
GO
