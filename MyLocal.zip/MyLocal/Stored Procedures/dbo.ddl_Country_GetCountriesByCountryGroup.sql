SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
CREATE PROCEDURE [dbo].[ddl_Country_GetCountriesByCountryGroup]
    @CountryGroup NVARCHAR(32) = NULL
AS /*
 
CREATED BY:			JRG
CREATED DATE:		03-Jun-2011
;
Sprint Item:		576
PURPOSE:			Returns a distinct list of Countries by country group
 
 
*/
 
    BEGIN TRY
        SELECT 
 DISTINCT       C.CountryID ,
                C.Name AS Country
        FROM    dbo.tblCountry C
                JOIN dbo.tblCountryLinkCountryGroup Link ON C.CountryID = Link.CountryID
                JOIN dbo.tblCountryGroup CG ON Link.CountryGroupID = CG.CountryGroupID
        WHERE   CG.Name = @CountryGroup
    END TRY
 
 
    BEGIN CATCH
        EXEC SP_ROLLANDRAISE
    END CATCH




GO
GRANT EXECUTE ON  [dbo].[ddl_Country_GetCountriesByCountryGroup] TO [mp_db_execute]
GO
