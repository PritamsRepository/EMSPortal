SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_MARegisteredSite_SiteType]
  @CompanyID INT
        
AS 
BEGIN TRY

SELECT DISTINCT  
  vst.Category AS Name
FROM
  dbo.tblMARegisteredSite mars
	/* Site JOINs */
	JOIN dbo.tblMASite mas ON mars.MASiteID = mas.MASiteID
	  JOIN dbo.tblValidSiteType vst ON mas.ValidSiteTypeID = vst.ValidSiteTypeID	  
WHERE
  mas.CompanyID = @CompanyID
	
END TRY
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 




GO
GRANT EXECUTE ON  [dbo].[ddl_MARegisteredSite_SiteType] TO [mp_db_execute]
GO
