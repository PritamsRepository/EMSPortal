SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_ProjectDevSites]
	
AS

BEGIN TRY

	SELECT DISTINCT
		c.CompanyID AS ID,
		c.Name
	FROM
		pm.PivotalWorkstreamLinkProject pwp
		JOIN pm.PivotalWorkstream pw ON pw.PivotalWorkstreamID = pwp.PivotalWorkstreamID
		JOIN dbo.tblCompany c ON c.CompanyID = pw.DevSiteID
	ORDER BY
		c.Name;

END TRY
BEGIN CATCH

	EXEC sp_RollAndRaise;

END CATCH
GO
