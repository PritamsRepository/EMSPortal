SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Reporting].[usp_REPORT_SecurityUserDetail_Roles]
    @SecurityUserID INT,
    @UserID INT,
    @PrivCode NVARCHAR(10)
AS
SELECT 'Unrestricted' = CASE sur.IsUnrestricted
                            WHEN 1 THEN
                                'Yes'
                            ELSE
                                'No'
                        END,
       r.[Name] AS Role,
       r.[Description] AS RoleDescription,
       CASE
           WHEN sur.IsUnrestricted = 1 THEN
               NULL
           ELSE
               rlc.Name
       END AS CountryName,
       'Countries' AS CountryType
FROM dbo.admin_SecUserRole sur
    JOIN dbo.admin_SecRole r
        ON sur.RoleID = r.RoleID
    LEFT JOIN
    (
        SELECT lc.UserRoleID,
               c.Name
        FROM dbo.admin_SecUserRoleLinkCountry lc
            JOIN dbo.tblCountry c
                ON lc.CountryID = c.CountryID
    ) AS rlc
        ON sur.UserRoleID = rlc.UserRoleID
WHERE sur.UserID = @SecurityUserID
      AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
--GROUP BY CASE sur.IsUnrestricted
--             WHEN 1 THEN
--                 'Yes'
--             ELSE
--                 'No'
--         END,
--         r.[Name],
--         r.[Description],
--         rlc.Name
UNION
SELECT 'Unrestricted' = CASE sur.IsUnrestricted
                            WHEN 1 THEN
                                'Yes'
                            ELSE
                                'No'
                        END,
       r.[Name] AS Role,
       r.[Description] AS RoleDescription,
       CASE
           WHEN sur.IsUnrestricted = 1 THEN
               NULL
           ELSE
               rlcg.CountryGroupType + ' : ' + rlcg.Name
       END AS CountryName,
       'Country Groups' AS CountryType
FROM dbo.admin_SecUserRole sur
    JOIN dbo.admin_SecRole r
        ON sur.RoleID = r.RoleID
    LEFT JOIN
    (
        SELECT lcg.UserRoleID,
               cg.Name,
               cg.CountryGroupType
        FROM dbo.admin_SecUserRoleLinkCountryGroup lcg
            JOIN dbo.tblCountryGroup cg
                ON lcg.CountryGroupID = cg.CountryGroupID
    ) AS rlcg
        ON sur.UserRoleID = rlcg.UserRoleID
WHERE sur.UserID = @SecurityUserID
      AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
--GROUP BY CASE sur.IsUnrestricted
--             WHEN 1 THEN
--                 'Yes'
--             ELSE
--                 'No'
--         END,
--         r.[Name],
--         r.[Description],
--         rlcg.Name,
--         rlcg.CountryGroupType
UNION
SELECT 'Unrestricted' = CASE sur.IsUnrestricted
                            WHEN 1 THEN
                                'Yes'
                            ELSE
                                'No'
                        END,
       r.[Name] AS Role,
       r.[Description] AS RoleDescription,
       CASE
           WHEN sur.IsUnrestricted = 1 THEN
               NULL
           ELSE
               rlcg.Name
       END AS CountryName,
       'Departments' AS CountryType
FROM dbo.admin_SecUserRole sur
    JOIN dbo.admin_SecRole r
        ON sur.RoleID = r.RoleID
    LEFT JOIN
    (
        SELECT lcg.UserRoleID,
               cg.Name
        FROM dbo.admin_SecUserRoleLinkValidDepartment lcg
            JOIN dbo.tblValidDepartment cg
                ON lcg.ValidDepartmentID = cg.ValidDepartmentID
    ) AS rlcg
        ON sur.UserRoleID = rlcg.UserRoleID
WHERE sur.UserID = @SecurityUserID
      AND dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
--GROUP BY CASE sur.IsUnrestricted
--             WHEN 1 THEN
--                 'Yes'
--             ELSE
--                 'No'
--         END,
--         r.[Name],
--         r.[Description],
--         rlcg.Name;
GO
GRANT EXECUTE ON  [Core.Reporting].[usp_REPORT_SecurityUserDetail_Roles] TO [mp_db_execute]
GO
