SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Audit_Insert]
    @BusinessBasedObjectID INT ,
    @ObjectID INT ,
    @UserID INT = NULL ,
    @EntryDate DATETIME = NULL ,
    @ObjectChanges XML
AS 
    SET XACT_ABORT ON  
    SET NOCOUNT ON

        IF ( @EntryDate IS NULL ) 
            BEGIN
                SET @EntryDate = GETDATE()
            END
	
	
        INSERT  INTO [dbo].[admin_ChangeTracking_Audit]
                ( [BusinessBasedObjectID] ,
                  [ObjectID] ,
                  [UserID] ,
                  [EntryDate] ,
                  [ObjectChanges] )
                SELECT  @BusinessBasedObjectID ,
                        @ObjectID ,
                        @UserID ,
                        @EntryDate ,
                        @ObjectChanges
                        
        SELECT  SCOPE_IDENTITY() AS ID

GO
