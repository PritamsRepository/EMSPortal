SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO





-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [Core.Common.Filter].[GetSiteTypesByName]
    @Name NVARCHAR(256) = NULL
AS
    SELECT DISTINCT
            cg.CompanyGroupID AS ID ,
            cg.Text AS [Name]
    FROM    dbo.tblCompanyGroup cg
			JOIN dbo.tblValidSiteType vst ON cg.Text = vst.NAME
            JOIN dbo.tblCompanylinkcompanygroup clcg ON clcg.CompanyGroupID = cg.CompanyGroupID
            JOIN dbo.tblCompany c ON c.CompanyID = clcg.CompanyID
    WHERE   ValidCompanyTypeID = 3	
    AND (@Name IS NULL OR cg.Text LIKE '%' + @Name + '%')



GO
