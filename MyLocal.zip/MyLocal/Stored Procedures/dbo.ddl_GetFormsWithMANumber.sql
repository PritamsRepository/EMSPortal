SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_GetFormsWithMANumber]
    @UserID INT = NULL,
    @PrivCode NVARCHAR(10) = NULL,
    @CountryCode NVARCHAR(10) = NULL
AS
DECLARE @CountryID INT;
SELECT @CountryID = CountryID
FROM dbo.tblCountry
WHERE Code = COALESCE(@CountryCode, 'US');

SELECT DISTINCT
       f.FormID,
       f.Name
FROM dbo.tblForm f
    JOIN pm.LegalInfo li
        ON f.FormID = li.FormID
WHERE li.CountryID = @CountryID
      AND li.MANumber IS NOT NULL
      AND [dbo].[udf_UserHasPriv](@UserID, @PrivCode) = 'true'
ORDER BY f.Name;
GO
