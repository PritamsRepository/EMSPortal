SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MAApplication_GetApplicationTypes]
  @UserID INT = NULL

AS 
BEGIN TRY

  SELECT DISTINCT
	v.ValidApplicationTypeID AS ID,
    v.Name
  FROM
	dbo.tblValidApplicationType v
	  JOIN dbo.tblMAApplication maa ON v.ValidApplicationTypeID = maa.ValidApplicationTypeID
  ORDER BY v.NAME
            
END TRY 
BEGIN CATCH 
    EXEC dbo.sp_RollAndRaise
END CATCH 
GO
GRANT EXECUTE ON  [dbo].[ddl_MAApplication_GetApplicationTypes] TO [mp_db_execute]
GO
