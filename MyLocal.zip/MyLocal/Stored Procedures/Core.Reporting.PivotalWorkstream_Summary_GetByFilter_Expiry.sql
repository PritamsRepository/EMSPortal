SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [Core.Reporting].[PivotalWorkstream_Summary_GetByFilter_Expiry]
    @ID INT = NULL ,
    @ProjectID INT = NULL ,
    @ProductGroupID INT = NULL ,
    @PivotalWorkstreamStatusID INT = NULL ,
    @CountryGroupFiltersList NVARCHAR(MAX) = NULL ,
    @BBOTagFiltersList NVARCHAR(MAX) = NULL ,
    @SubmissionYearFiltersList NVARCHAR(MAX) = NULL ,
    @FormFiltersList NVARCHAR(MAX) = NULL ,
    @LeadID INT = NULL ,
    @DevSiteID INT = NULL ,
    @ParentID INT = NULL ,
    @ParentType INT = NULL ,
    @UserId INT ,
    @PrivCode NVARCHAR(10) ,
    @FormFiltersInclusionID INT = NULL ,
    @DevSiteInclusionID INT = NULL ,
    @CountryGroupFiltersInclusionID INT = NULL ,
    @LeadInclusionID INT = NULL ,
    @SubmissionYearFiltersInclusionID INT = NULL ,
    @PivotalWorkstreamStatusInclusionID INT = NULL ,
    @BBOTagFiltersInclusionID INT = NULL
AS
    BEGIN
    --pivotal
        DECLARE @BBOID INT = ( SELECT   BBOID
                               FROM     dbo.tblBusinessBaseObject
                               WHERE    BBOCode = 'PVW'
                             )
        --pilot                     
        DECLARE @PLWBBOID INT = ( SELECT    BBOID
                                  FROM      dbo.tblBusinessBaseObject
                                  WHERE     BBOCode = 'PLW'
                                )
        --project                       
        DECLARE @PJBBOID INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'PJM'
                               )
	    --submission
        DECLARE @SWBBOID INT = ( SELECT BBOID
                                 FROM   dbo.tblBusinessBaseObject
                                 WHERE  BBOCode = 'SW'
                               )
                                 
        DECLARE @IsUnrestricted INT = ( SELECT  COUNT(sur.IsUnrestricted)
                                        FROM    dbo.admin_secrolepriv srp
                                                JOIN dbo.admin_SecPriv sp ON srp.PrivID = sp.PrivID
                                                JOIN dbo.admin_SecUserRole sur ON sur.RoleID = srp.RoleID
                                        WHERE   sp.PrivCode = @privCode
                                                AND sur.UserID = @UserID
                                      )			
		
        DECLARE @CountryGroupFilters CountryGroupType ,
            @FormFilters FormType ,
            @BBOTagFilters BBOTagType ,
            @SubmissionYearFilters TimeframeType;
			  
        IF LEN(@CountryGroupFiltersList) > 0
            INSERT  @CountryGroupFilters
                    ( CountryGroupID
                    )
                    SELECT  *
                    FROM    dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList)
				 
        IF LEN(@BBOTagFiltersList) > 0
            INSERT  @BBOTagFilters
                    ( BBOTagID
                    )
                    SELECT  *
                    FROM    dbo.udf_GetValuesFromCSV(@BBOTagFiltersList)
			
				 
        IF LEN(@SubmissionYearFiltersList) > 0
            INSERT  @SubmissionYearFilters
                    ( Timeframe
                    )
                    SELECT  *
                    FROM    dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList)
				 
        IF LEN(@FormFiltersList) > 0
            INSERT  @FormFilters
                    ( FormID
                    )
                    SELECT  *
                    FROM    dbo.udf_GetValuesFromCSV(@FormFiltersList);
        IF OBJECT_ID('tempdb..#ExpiryCountryGroups') IS NOT NULL
            BEGIN
                DROP TABLE #ExpiryCountryGroups
            END

        CREATE TABLE #ExpiryCountryGroups ( CountryGroupID INT );
      
        CREATE CLUSTERED INDEX IX_temp_CountryGroupID ON #ExpiryCountryGroups (CountryGroupID);

        INSERT  INTO #ExpiryCountryGroups
                ( CountryGroupID
                )
                SELECT  CountryGroupID
                FROM    dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserID,
                                                              @PrivCode)
                WHERE   Privs = 1
        

         		
        SELECT  DISTINCT
                pw.PivotalWorkstreamID ,
                p.ProjectID ,
                    dbo.udf_EHSAlert(f.ProductID, NULL) AS EHSAlert ,
                    dbo.udf_GetMPBClassifications(f.ProductID) AS OEBClassifications ,
                    dbo.udf_GetDrugClassifications(f.ProductID) AS DrugClassifications ,                 
                ( SELECT    MIN(e.[ImpactOnFilingDate])
                  FROM      [pm].[Exclusivity] e
                            JOIN pm.LegalInfo li ON li.CountryID = e.CountryID
                                                        AND li.FormID = e.FormID
                            JOIN [dbo].[tblCountryLinkCountryGroup] AS clcg ON clcg.[CountryID] = li.[CountryID]
                            JOIN ( SELECT   PLC.ProjectID ,
                                            PLC.CountryID
                                   FROM     pm.ProjectLinkCountry AS PLC
                                   WHERE    PLC.ProjectID = p.projectID
                                   UNION
                                   SELECT   proj.ProjectID ,
                                            PLCG.CountryID
                                   FROM     pm.Project proj
                                            JOIN dbo.tblCountryLinkCountryGroup plcg ON plcg.CountryGroupID = proj.CountryGroupID
                                   WHERE    proj.ProjectID = p.ProjectID
                                            AND plcg.CountryGroupID = proj.CountryGroupID
                                            AND proj.ProjectID NOT IN (
                                            SELECT  iplc.ProjectID
                                            FROM    pm.projectLinkCountry iplc )
                                 ) AS epc ON epc.CountryID = e.CountryID
                            LEFT JOIN [dbo].[tblValidExclusivityType] AS vet ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
                  WHERE     li.FormID = pw.FormID
                            AND e.FormID = pw.FormID
                            AND ( vet.Category IS NULL
                                  OR vet.Category != 'MISEXCLUDE'
                                )
                            AND clcg.CountryGroupID IN (
                            SELECT  CountryGroupID
                            FROM    #ExpiryCountryGroups )
                ) AS [ExclusivityExpirationDate]
        FROM    pm.PivotalWorkstream pw
                JOIN dbo.tblform f ON pw.FormID = f.FormID
                JOIN dbo.tblValidForm vfo ON vfo.ValidFormID = f.ValidFormID
                LEFT JOIN pm.PivotalWorkstreamLinkProject pwp ON pwp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                LEFT JOIN pm.Project p ON pwp.ProjectID = p.ProjectID
            WHERE   ( @IsUnrestricted > 0
                      OR pw.PivotalWorkstreamID IN (
                      SELECT    PivotalWorkstreamID
                      FROM      pm.PivotalWorkstreamLinkCountryGroup pwlcg
                                JOIN dbo.udf_UserHasPrivForCountryGroup_TableValued(@UserId,
                                                              @PrivCode) uhp ON pwlcg.CountryGroupID = uhp.CountryGroupID
                                                              AND uhp.Privs = 1 )
                    )
                    AND ( @ID IS NULL
                          OR @ID = pw.PivotalWorkstreamID
                        )
                    AND ( @ProductGroupID IS NULL
                          OR f.ProductID = @ProductGroupID
                        )
                    AND ( @ProjectID IS NULL
                          OR @ProjectID IN (
                          SELECT    ProjectID
                          FROM      pm.PivotalWorkstreamLinkProject pwlp
                          WHERE     pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID )
                        )
                    AND ( @parentType IS NULL
                          OR @ParentID IS NULL
                          OR ( @ParentType = 0
                               AND @ParentID = 0
                             )
                          OR ( @ParentType = @PJBBOID
                               AND @ParentID IN (
                               SELECT   ProjectID
                               FROM     pm.PivotalWorkstreamLinkProject pwlp
                               WHERE    pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID )
                             )
                        )
                    AND ( @PivotalWorkstreamStatusID IS NULL
                          OR ( @PivotalWorkstreamStatusInclusionID = 1
                               AND @PivotalWorkstreamStatusID = PivotalWorkstreamStatusID
                             )
                          OR ( @PivotalWorkstreamStatusInclusionID = 3
                               AND @PivotalWorkstreamStatusID != PivotalWorkstreamStatusID
                             )
                        )
                    AND ( ( SELECT  COUNT(*)
                            FROM    @CountryGroupFilters
                          ) = 0
                          OR ( @CountryGroupFiltersInclusionID = 1
                               AND pw.PivotalWorkstreamID IN (
                               SELECT   PivotalWorkstreamID
                               FROM     pm.PivotalWorkstreamLinkCountryGroup pwlcg
                               WHERE    pwlcg.PivotalWorkstreamID = pw.PivotalWorkstreamID
                                        AND pwlcg.CountryGroupID IN (
                                        SELECT  CountryGroupID
                                        FROM    @CountryGroupFilters ) )
                             )
                          OR ( @CountryGroupFiltersInclusionID = 3
                               AND pw.PivotalWorkstreamID NOT IN (
                               SELECT   PivotalWorkstreamID
                               FROM     pm.PivotalWorkstreamLinkCountryGroup pwlcg
                               WHERE    pwlcg.CountryGroupID IN (
                                        SELECT  CountryGroupID
                                        FROM    @CountryGroupFilters ) )
                             )
                        )
                    AND ( ( SELECT  COUNT(*)
                            FROM    @FormFilters
                          ) = 0
                          AND @FormFiltersInclusionID != 4
                          OR ( @FormFiltersInclusionID = 1
                               AND pw.FormID IN ( SELECT    FormID
                                                  FROM      @FormFilters )
                             )
                          OR ( @FormFiltersInclusionID = 2
                               AND ( SELECT COUNT(DISTINCT f.FormID)
                                     FROM   dbo.tblForm f
                                            JOIN @FormFilters ff ON ff.FormID = f.FormID
                                                              AND f.FormID = pw.FormID
                                   ) = ( SELECT COUNT(DISTINCT FormID)
                                         FROM   @FormFilters
                                       )
                             )
                          OR ( @FormFiltersInclusionID = 3
                               AND pw.FormID NOT IN ( SELECT  FormID
                                                      FROM    @FormFilters )
                             )
                          OR ( @FormFiltersInclusionID = 4
                               AND pw.FormID IS NULL
                             )
                        )
                    AND ( ( ( SELECT    COUNT(*)
                              FROM      @SubmissionYearFilters
                            ) = 0
                            AND @SubmissionYearFiltersInclusionID != 4
                          )
                          OR ( @SubmissionYearFiltersInclusionID = 1
                               AND ( SELECT MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                                     THEN YEAR(m.BestEstimateDate)
                                                     ELSE YEAR(refm.BestEstimateDate)
                                                END)
                                     FROM   pm.Project p
                                            JOIN pm.PivotalWorkstreamLinkProject pwlp ON pwlp.ProjectID = p.ProjectID
                                            JOIN dbo.tblMilestone m ON m.BBOID = @PJBBOID
                                                              AND m.ObjectID = p.ProjectID
                                            JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                            LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                                     WHERE  pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                                   ) IN ( SELECT    Timeframe
                                          FROM      @SubmissionYearFilters )
                             )
                          OR ( @SubmissionYearFiltersInclusionID = 3
                               AND ISNULL(( SELECT  MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                                             THEN YEAR(m.BestEstimateDate)
                                                             ELSE YEAR(refm.BestEstimateDate)
                                                        END)
                                            FROM    pm.Project p
                                                    JOIN pm.PivotalWorkstreamLinkProject pwlp ON pwlp.ProjectID = p.ProjectID
                                                    JOIN dbo.tblMilestone m ON m.BBOID = @PJBBOID
                                                              AND m.ObjectID = p.ProjectID
                                                    JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                                    LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                                            WHERE   pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                                          ), -1) NOT IN (
                               SELECT   Timeframe
                               FROM     @SubmissionYearFilters )
                             )
                          OR ( @SubmissionYearFiltersInclusionID = 4
                               AND ISNULL(( SELECT  MIN(CASE WHEN m.ReferenceMilestoneID IS NULL
                                                             THEN YEAR(m.BestEstimateDate)
                                                             ELSE YEAR(refm.BestEstimateDate)
                                                        END)
                                            FROM    pm.Project p
                                                    JOIN pm.PivotalWorkstreamLinkProject pwlp ON pwlp.ProjectID = p.ProjectID
                                                    JOIN dbo.tblMilestone m ON m.BBOID = @PJBBOID
                                                              AND m.ObjectID = p.ProjectID
                                                    JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                                              AND mti.Code = 'Submission'
                                                    LEFT JOIN tblMilestone refm ON refm.MileStoneID = m.MileStoneID
                                            WHERE   pwlp.PivotalWorkstreamID = pw.PivotalWorkstreamID
                                          ), -1) IS NULL
                             )
                        )
                    AND ( @LeadID IS NULL
                          OR ( @LeadInclusionID = 1
                               AND @LeadID = pw.LeadID
                             )
                          OR ( @LeadInclusionID = 3
                               AND @LeadID != pw.LeadID
                             )
                        )
                    AND ( @DevSiteID IS NULL
                          AND @DevSiteInclusionID != 4
                          OR ( @DevSiteInclusionID = 1
                               AND @DevSiteID = pw.DevSiteID
                             )
                          OR ( @DevSiteInclusionID = 3
                               AND @DevSiteID != pw.DevSiteID
                             )
                          OR ( @DevSiteInclusionID = 4
                               AND pw.DevSiteID IS NULL
                             )
                        )
                    AND ( ( SELECT  COUNT(*)
                            FROM    @BBOTagFilters
                          ) = 0
                          AND @BBOTagFiltersInclusionID != 4
                          OR ( @BBOTagFiltersInclusionID = 1
                               AND pw.PivotalWorkstreamID IN (
                               SELECT   PivotalWorkstreamID
                               FROM     pm.PivotalWorkstreamTag
                               WHERE    ValidBBOTagID IN ( SELECT
                                                              BBOTagID
                                                           FROM
                                                              @BBOTagFilters ) )
                             )
                          OR ( @BBOTagFiltersInclusionID = 2
                               AND ( SELECT COUNT(DISTINCT ValidBBOTagID)
                                     FROM   pm.PivotalWorkstreamTag pwt
                                            JOIN @BBOTagFilters tf ON tf.BBOTagID = pwt.ValidBBOTagID
                                                              AND pwt.PivotalWorkstreamID = pw.PivotalWorkstreamID
                                   ) = ( SELECT COUNT(DISTINCT BBOTagID)
                                         FROM   @BBOTagFilters
                                       )
                             )
                          OR ( @BBOTagFiltersInclusionID = 3
                               AND pw.PivotalWorkstreamID NOT IN (
                               SELECT   PivotalWorkstreamID
                               FROM     pm.PivotalWorkstreamTag
                               WHERE    ValidBBOTagID IN ( SELECT
                                                              BBOTagID
                                                           FROM
                                                              @BBOTagFilters ) )
                             )
                          OR ( @BBOTagFiltersInclusionID = 4
                               AND pw.PivotalWorkstreamID IN (
                               SELECT   PivotalWorkstreamID
                               FROM     pm.PivotalWorkstream
                               WHERE    PivotalWorkstreamID NOT IN (
                                        SELECT  PivotalWorkstreamID
                                        FROM    pm.PivotalWorkstreamTag ) )
                             )
                        )
            ORDER BY pw.PivotalWorkstreamID, ProjectID
            
                    IF OBJECT_ID('tempdb..#ExpiryCountryGroups') IS NOT NULL
            BEGIN
                DROP TABLE #ExpiryCountryGroups
            END
    END
GO
