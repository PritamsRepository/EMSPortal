SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_CompanyByCompanyGroup] 
(							
  @CompanyGroup NVARCHAR(256),
  @CompanyID INT = NULL
)
AS

/*********************************************************************************
CREATED BY:							Scott M. Dexter			Software Specialists Consultant
CREATED DATE:						02 DEC 2010
MODIFIED BY:						Scott M. Dexter			Software Specialists Consultant
MODIFIED DATE:					20 JAN 2010
MODIFIED PURPOSE:			The modifiecation purpose for this is to introduce the ability for the
												user to select a company that is not a part of the CompanyGroup or
												has previously been disabled.
PURPOSE:								The purpose of this script is to retrieve a list of 
												company names and company id'sfor passage back to a drop down list. 
												Hense the prefix ddl_.
==================================================================================
SAMPLE USAGE:		EXEC [dbo].[ddl_CompanyByCompanyGroup] @CompanyGroup = 'Innovator'
*********************************************************************************/

BEGIN TRY

		DECLARE @PrimarySortPriority NVARCHAR(256) = 'Mylan, Inc.';
		DECLARE @SecondarySortPriority NVARCHAR(256) = 'Mylan : %';
						
		SELECT DISTINCT
		  (
			CASE 
			  WHEN c.Name = @PrimarySortPriority THEN 0
			  WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
			  ELSE 2 
			  END
		  ) AS SortPriority,
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS FormattedName,
		  (COALESCE(co.Code, 'N/A') + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c 
			INNER JOIN tblCompanyLinkCompanyGroup clcg ON c.CompanyID = clcg.CompanyID 
			INNER JOIN tblCompanyGroup cg ON  clcg.CompanyGroupID = cg.CompanyGroupID
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID					
		WHERE cg.[Text] = @CompanyGroup
		
		UNION
		
		SELECT
		  (
			CASE 
			  WHEN c.Name = @PrimarySortPriority THEN 0
			  WHEN dbo.udf_MA_FormatCompanies(c.CompanyID) LIKE @SecondarySortPriority THEN 1 
			  ELSE 2 
			  END
		  ) AS SortPriority,
		  c.CompanyID,
		  c.Name,
		  dbo.udf_MA_FormatCompanies(c.CompanyID) AS FormattedName,
		  (COALESCE(co.Code, 'N/A') + ': ' + c.Name) AS FullName
		FROM 
		  tblCompany c
			LEFT JOIN tblCountry co ON c.CountryID = co.CountryID
		WHERE 
		  CompanyID = @CompanyID
		ORDER BY
		  SortPriority,
		  FormattedName;
			
END TRY

BEGIN CATCH
	EXECUTE sp_RollAndRaise 
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_CompanyByCompanyGroup] TO [mp_db_execute]
GO
