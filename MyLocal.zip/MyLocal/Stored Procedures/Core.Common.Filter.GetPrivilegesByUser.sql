SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.Filter].[GetPrivilegesByUser]
    @UserID INT,
    @SystemID INT
AS
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

BEGIN TRY

    SELECT p.PrivCode,
           CAST(CASE
                    WHEN EXISTS
                         (
                             SELECT 1
                             FROM dbo.admin_SecUserRole ur
                                 JOIN dbo.admin_SecRolePriv rp
                                     ON rp.RoleID = ur.RoleID
                             WHERE rp.PrivID = p.PrivID
                                   AND ur.IsUnrestricted = 1
                                   AND ur.UserID = @UserID
                         ) THEN
                        1
                    ELSE
                        NULL
                END AS BIT) AS Unrestricted,
           -- This query gets explicit country permissions.
           (
               SELECT c.CountryID AS [@ID],
                      c.Code AS [@Code],
                      (
                          SELECT CR.CountryGroupID AS [@RegionID]
                          FROM dbo.tblCountryLinkCountryGroup AS CR
                          WHERE CR.CountryID = c.CountryID
                          FOR XML PATH('countryRegion'), TYPE
                      ) RegionXML
               FROM dbo.tblCountry c
               WHERE EXISTS
               (
                   SELECT TOP(1)
                          rlc.CountryID
                   FROM dbo.admin_SecUserRoleLinkCountry rlc
                       JOIN dbo.admin_SecUserRole ur
                           ON ur.UserRoleID = rlc.UserRoleID
                              AND ur.UserID = @UserID
                       JOIN dbo.admin_SecRolePriv rp
                           ON ur.RoleID = rp.RoleID
                              AND rp.PrivID = p.PrivID
                   WHERE rlc.CountryID = c.CountryID
               )
                     OR EXISTS
               (
                   SELECT TOP(1)
                          clcg.CountryID
                   FROM dbo.admin_SecUserRoleLinkCountryGroup rlgc
                       JOIN dbo.tblCountryLinkCountryGroup clcg
                           ON clcg.CountryGroupID = rlgc.CountryGroupID
                       JOIN dbo.admin_SecUserRole ur
                           ON ur.UserRoleID = rlgc.UserRoleID
                              AND ur.UserID = @UserID
                       JOIN dbo.admin_SecRolePriv rp
                           ON ur.RoleID = rp.RoleID
                              AND rp.PrivID = p.PrivID
                   WHERE clcg.CountryID = c.CountryID
               )
               FOR XML PATH('country'), ROOT('countries'), TYPE
           ) CountriesXML,
           -- This query gets the explicit country group permissions.
           (
               SELECT cg.CountryGroupID AS [@ID],
                      cg.Name AS [@Code],
                      cg.CountryGroupType AS [@CountryGroupType]
               FROM dbo.tblCountryGroup cg
               WHERE EXISTS
               (
                   SELECT TOP(1)
                          rlcg.CountryGroupID
                   FROM dbo.admin_SecUserRoleLinkCountryGroup rlcg
                       JOIN dbo.admin_SecUserRole ur
                           ON ur.UserRoleID = rlcg.UserRoleID
                              AND ur.UserID = @UserID
                       JOIN dbo.admin_SecRolePriv rp
                           ON ur.RoleID = rp.RoleID
                              AND rp.PrivID = p.PrivID
                   WHERE rlcg.CountryGroupID = cg.CountryGroupID
               )
               FOR XML PATH('countryGroup'), ROOT('countryGroups'), TYPE
           ) CountryGroupsXML,
           -- Departments
           (
               SELECT vd.ValidDepartmentID AS [@ID],
                      vd.Name AS [@Code]
               FROM dbo.tblValidDepartment vd
               WHERE EXISTS
               (
                   SELECT TOP(1)
                          rld.ValidDepartmentID
                   FROM dbo.admin_SecUserRoleLinkValidDepartment rld
                       JOIN dbo.admin_SecUserRole ur
                           ON ur.UserRoleID = rld.UserRoleID
                              AND ur.UserID = @UserID
                       JOIN dbo.admin_SecRolePriv rp
                           ON ur.RoleID = rp.RoleID
                              AND rp.PrivID = p.PrivID
                   WHERE rld.ValidDepartmentID = vd.ValidDepartmentID
               )
               FOR XML PATH('department'), ROOT('departments'), TYPE
           ) DepartmentsXML
    FROM dbo.admin_SecPriv p
    WHERE p.ValidSoftwareSystemID = @SystemID
          AND
        -- Does at least one role/priv record exist for this privilege.
        EXISTS
    (
        SELECT 1
        FROM dbo.admin_SecUserRole ur
            JOIN dbo.admin_SecRolePriv rp
                ON ur.RoleID = rp.RoleID
                   AND rp.PrivID = p.PrivID
				   JOIN dbo.admin_SecUser asu ON asu.UserID = ur.UserID
        WHERE ur.UserID = @UserID AND asu.Active = 1
    )
    ORDER BY PrivCode;

    RETURN 0;

END TRY
BEGIN CATCH
    EXEC dbo.sp_RollAndRaise;
END CATCH;
GO
GRANT EXECUTE ON  [Core.Common.Filter].[GetPrivilegesByUser] TO [mp_db_execute]
GO
