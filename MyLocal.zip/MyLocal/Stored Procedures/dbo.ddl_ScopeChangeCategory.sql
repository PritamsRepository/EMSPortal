SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

 
------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
 
 
Create Procedure [dbo].[ddl_ScopeChangeCategory]
 
AS
 
/*
 
CREATED BY:			JRG
CREATED DATE:		OCT 04, 2010
SI:					546/534
PURPOSE:			Drop Down List of Scope Change Categories 
 
 
 
*/
 
BEGIN TRY
 
 SELECT [ValidProjectScopeChangeID]
      ,[Name]
  FROM [dbo].[tblValidProjectScopeChange]
  WHERE  [IsActive]=1
  ORDER BY DisplayOrder

 
END TRY
 
 
BEGIN CATCH
	EXEC SP_ROLLANDRAISE
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_ScopeChangeCategory] TO [mp_db_execute]
GO
