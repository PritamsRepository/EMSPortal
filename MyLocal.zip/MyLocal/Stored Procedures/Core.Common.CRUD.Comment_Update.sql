SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [Core.Common.CRUD].[Comment_Update]
    @BBOID INT,
    @ObjectID INT,
    @Comment NVARCHAR(MAX),
    @UpdateUserId INT,
    @ConcurrencyID TIMESTAMP,
    @ID INT,
    @Category NVARCHAR(128)
AS 
    BEGIN

        DECLARE @BBOCode NVARCHAR(50),
            @ActionType CHAR(1),
            @RowsAffected INT,
            @ReturnValue INT,
            @ConcurIDinDB TIMESTAMP

        SELECT  @BBOCode = BBOCode
        FROM    dbo.tblBusinessBaseObject
        WHERE   BBOID = @BBOID;

        SELECT  @ConcurIDinDB = ConcurrencyID
        FROM    tblComment
        WHERE   CommentID = @ID;

        IF @ConcurIDinDB IS NULL 
            EXEC sp_RaiseCustomError 2                   
        ELSE 
            IF ( @ConcurIDinDB <> @ConcurrencyID ) 
                EXEC sp_RaiseCustomError 1
    
            ELSE 
                BEGIN 
                    BEGIN TRAN EditComment
	
                    UPDATE  dbo.tblComment
                    SET     BBOID = @BBOID,
                            ObjectID = @ObjectID,
                            Comment = @Comment,
                            UserID = @UpdateUserID,
                            CommentDate = GETDATE(),
                            Category = @Category
                    WHERE   CommentID = @ID
                END             
	
        SET @RowsAffected = @@ROWCOUNT;
        SET @ActionType = 'U'
        SET @ReturnValue = @ID 

        SELECT  @ReturnValue AS ID,
                ConcurrencyID
        FROM    dbo.tblComment
        WHERE   CommentID = @ReturnValue
/* Audit information */  

        IF ( @RowsAffected = 1 ) 
            BEGIN
                EXEC [dbo].[sp_BUSINESSBASE_AuditByCode] @BBOCode = @BBOCode,
                    @UserID = @UpdateUserID, @ObjectID = @ObjectID,
                    @ActionType = @ActionType

            END
        COMMIT;
        RETURN 0;
    END
GO
GRANT EXECUTE ON  [Core.Common.CRUD].[Comment_Update] TO [mp_db_execute]
GO
