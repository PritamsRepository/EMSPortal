SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_StrengthsByLicenseScope]
    @MALicenseID INT ,
    @CountryID INT
AS 
    BEGIN TRY
        SELECT DISTINCT
                MS.MAStrengthID ID ,
                F.NAME + ' ' + S.Name AS Name
        FROM    dbo.tblForm F
                JOIN dbo.tblStrength S ON F.FormID = S.FormID
                JOIN dbo.tblMAStrength MS ON S.StrengthID = MS.StrengthID
                JOIN dbo.tblMALicenseScope LS ON MS.MAStrengthID = LS.MAStrengthID
        WHERE   LS.MALicenseID = @MALicenseID
                AND LS.CountryID = @CountryID
        ORDER BY Name
    END  TRY
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH
GO
GRANT EXECUTE ON  [dbo].[ddl_StrengthsByLicenseScope] TO [mp_db_execute]
GO
