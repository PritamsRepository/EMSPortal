SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[Brand_GetBrandsByFormID] @FormID INT
AS
BEGIN TRY
    SELECT b.BrandID,
           c.CountryID,
           cy.CompanyID,
           c.[Name] + ' (' + c.[Code] + ')' AS Country,
           b.Name AS BrandName,
           cy.Name AS CompanyName,
           dbo.udf_MarketedStrengthListByBrandID(c.CountryID, b.BrandCompanyID, @FormID) AS MarketedStrengths
    FROM dbo.tblCountryGroup cg
        JOIN dbo.tblCountryLinkCountryGroup clcg
            ON cg.CountryGroupID = clcg.CountryGroupID
        JOIN dbo.tblCountry c
            ON clcg.CountryID = c.CountryID
        JOIN dbo.tblBrand b
            ON c.CountryID = b.CountryID
        LEFT JOIN dbo.tblCompany cy
            ON cy.CompanyID = b.BrandCompanyID
    WHERE b.FormID = @FormID
          AND cg.CountryGroupTypeDescription = 'Key Brands'
    ORDER BY c.Code;
END TRY
BEGIN CATCH
    EXECUTE dbo.sp_RollAndRaise;
END CATCH;
GO
