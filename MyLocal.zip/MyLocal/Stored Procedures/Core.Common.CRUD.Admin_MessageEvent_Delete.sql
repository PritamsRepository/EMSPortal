SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

create PROC [Core.Common.CRUD].[Admin_MessageEvent_Delete] 
    @MessageEventID BIGINT
AS 
BEGIN 
	IF EXISTS ( SELECT  1
                FROM    [dbo].[admin_MessageEvent]
                WHERE   MessageEventID = @MessageEventID ) 
        BEGIN 
            DELETE  FROM [dbo].[admin_MessageEvent]
            WHERE   [MessageEventID] <= @MessageEventID
        END 
END 
	




GO
