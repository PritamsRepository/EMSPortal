SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-----------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ddl_MAMilestoneTemplatesBySubRtHA] (
@SubmissionRouteID int,
@HealthAuthorityID int
)
as
/**********************************************************************************
JRG
DATE: 20101117
DropDown to get all the MilestoneTemplates for a give BBO
******
CLD
Making it less stupid.
**********************************************************************************/
	SELECT 
		MT.MilestoneTemplateID ,
	  MT.Name 
	FROM    
		tblsubmissionrouteconfig src join dbo.tblMilestoneTemplate MT on src.MilestoneTemplateID = mt.MilestoneTemplateID
	WHERE 
		src.SubmissionRouteID = @SubmissionRouteID and src.HealthAuthorityID = @HealthAuthorityID
		-- Let's not include these.
		AND mt.IsPublic = 1 AND mt.IsActive = 1
GO
GRANT EXECUTE ON  [dbo].[ddl_MAMilestoneTemplatesBySubRtHA] TO [mp_db_execute]
GO
