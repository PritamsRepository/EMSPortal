SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[ddl_Labeling_GetCountries] @UserID INT = NULL
AS
BEGIN TRY
    SELECT DISTINCT
           c1.CountryID,
           c1.Name,
           CASE
               WHEN c1.Code = 'US' THEN
                   1
               WHEN c1.Code = 'CA' THEN
                   2
               WHEN c1.Code = 'AU' THEN
                   3
               WHEN c1.Code = 'JP' THEN
                   4
               WHEN c1.Code = 'NZ' THEN
                   5
               WHEN c1.Code = 'IT' THEN
                   6
               WHEN c1.Code = 'ES' THEN
                   7
               ELSE
                   8
           END AS [Priority]
    FROM dbo.tblMALicenseScope mals
        JOIN dbo.tblCountry c1
            ON c1.CountryID = mals.CountryID
    UNION
    SELECT CountryID,
           Name,
           8
    FROM dbo.tblCountry
    WHERE Code = 'EMA' AND CountryID NOT IN (SELECT CountryID FROM dbo.tblMALicenseScope)
    ORDER BY [Priority],
             c1.Name;
END TRY
BEGIN CATCH
    EXECUTE [dbo].[sp_RollAndRaise];
END CATCH;
GO
