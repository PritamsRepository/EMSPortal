SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROC [dbo].[ddl_MarketLicenseGetNextStatus]

AS 
    BEGIN TRY
        DECLARE @BBOName NVARCHAR(256) ,
            @BBOField NVARCHAR(256) 
            

        SET @BBOName = N'Mylan.Myportfolio.BLL.BusinessObjects.MALicenseScope'
        SET @BBOField = N'MarketStatusID'


--        SELECT DISTINCT  NextStates.StateName ,
--                NextStates.StateID
--        FROM    ( ( tblBusinessBaseStateControl
--                    INNER JOIN tblBusinessBaseObject ON tblBusinessBaseStateControl.BBOID = tblBusinessBaseObject.BBOID )
--                  INNER JOIN tblBusinessBaseStates AS CurrentState ON tblBusinessBaseStateControl.StateControlID = CurrentState.StateControlID )
--                INNER JOIN ( tblBusinessBaseStateFlow
--                             LEFT JOIN tblBusinessBaseStates AS NextStates ON tblBusinessBaseStateFlow.NextStateID = NextStates.StateID ) ON CurrentState.StateID = tblBusinessBaseStateFlow.StateID
--        WHERE   tblBusinessBaseObject.BBOName = @BBOName
--                AND tblBusinessBaseStateControl.BBOField = @BBOField
--UNION 
        SELECT DISTINCT  CurrentState.StateName ,
                CurrentState.StateID
        FROM    ( ( tblBusinessBaseStateControl
                    INNER JOIN tblBusinessBaseObject ON tblBusinessBaseStateControl.BBOID = tblBusinessBaseObject.BBOID )
                  INNER JOIN tblBusinessBaseStates AS CurrentState ON tblBusinessBaseStateControl.StateControlID = CurrentState.StateControlID )
                INNER JOIN ( tblBusinessBaseStateFlow
                             LEFT JOIN tblBusinessBaseStates AS NextStates ON tblBusinessBaseStateFlow.NextStateID = NextStates.StateID ) ON CurrentState.StateID = tblBusinessBaseStateFlow.StateID
        WHERE   tblBusinessBaseObject.BBOName = @BBOName
                AND tblBusinessBaseStateControl.BBOField = @BBOField
             --   AND CurrentState.StateID = @CurrentStateID
                
		ORDER BY 1,2
	
    END TRY 
    BEGIN CATCH
        EXEC dbo.sp_RollAndRaise
    END CATCH 


GO
GRANT EXECUTE ON  [dbo].[ddl_MarketLicenseGetNextStatus] TO [mp_db_execute]
GO
