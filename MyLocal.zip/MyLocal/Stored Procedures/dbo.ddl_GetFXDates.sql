SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create stored procedure
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ddl_GetFXDates]
AS
/*======================================================================
CREATED BY:					SCOTT DEXTER					DATA ARCHITECT
CREATED ON:					01 FEB 2010
PURPOSE:						TO GET THE EFFECTIVE DATE AND LOAD ID FOR 
										tblExchangeRateLoad.
======================================================================*/

BEGIN TRY
	
	SELECT 
		EXRateLoadID, 
		EffectiveDate 
	FROM 
		tblExchangeRateLoad 
	ORDER BY 
		EffectiveDate DESC

END TRY
BEGIN CATCH
	EXEC sp_RollAndRaise
END CATCH

GO
GRANT EXECUTE ON  [dbo].[ddl_GetFXDates] TO [mp_db_execute]
GO
