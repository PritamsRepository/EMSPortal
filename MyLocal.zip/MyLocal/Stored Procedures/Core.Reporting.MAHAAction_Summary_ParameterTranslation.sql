SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROC [Core.Reporting].[MAHAAction_Summary_ParameterTranslation]
    @ProductName NVARCHAR(256) = NULL,
    @ApplicationNum NVARCHAR(256) = NULL,
	@ApplicationID INT = NULL,	
    @SubmissionTracking NVARCHAR(256) = NULL,	
    @MASubmissionWorkstreamID INT = NULL,
    @CountryGroupID INT = NULL, --Region
    @CountryID INT = NULL,
    @RegLeadID INT = NULL, --SubmissionLead
    @RegTeamID INT = NULL,    
    @MASubmissionWorkstreamStatusID INT = NULL,
    @SubmissionRouteID INT = NULL,
    @ValidMASubmissionTypeID INT = NULL, --<< New for Phase 2
    @ShowCMSSubmissions INT, --<< New for Phase 2
    @SubmissionStartDate NVARCHAR(256) = NULL,
    @SubmissionEndDate NVARCHAR(256) = NULL,
    @RegCloseStartDate NVARCHAR(256) = NULL,
    @RegCloseEndDate NVARCHAR(256) = NULL,
    @FinalApproveStartDate NVARCHAR(256) = NULL,
    @FinalApproveEndDate NVARCHAR(256) = NULL,        
    @UserID INT
   
AS 

	DECLARE @rProdName NVARCHAR(MAX) = 'All'
	DECLARE @rApplicationNum NVARCHAR(MAX) = 'All'
	DECLARE @rApplicationID NVARCHAR(MAX) = 'All'
	DECLARE @rSubmissionTrackingNum NVARCHAR(MAX) = 'All'
	DECLARE @rSubmissionID NVARCHAR(MAX) = 'All'
	DECLARE @rRegion NVARCHAR(MAX) = 'All'	
    DECLARE @rCountry NVARCHAR(MAX) = 'All'
    DECLARE @rRegLead NVARCHAR(MAX) = 'All'
    DECLARE @rRegTeam NVARCHAR(MAX) = 'All'
    DECLARE @rMASubmissionWorkstreamStatusID NVARCHAR(MAX) = 'All'
    DECLARE @rSubmissionRoute NVARCHAR(MAX) = 'All (Excluding Export Listing)'    
    DECLARE @rSubmissionType NVARCHAR(MAX) = 'All'    
    DECLARE @rShowCMS NVARCHAR(MAX) = 'All'
    DECLARE @User NVARCHAR(MAX)
    
    IF @ProductName IS NOT NULL
    BEGIN
		SET @rProdName = @ProductName
    END
    
    IF @ApplicationNum IS NOT NULL
    BEGIN
		SET @rApplicationNum=@ApplicationNum
    END
    
    IF ISNUMERIC(@ApplicationID) = 1
    BEGIN
		SELECT @rApplicationID = MAApplicationID 
		FROM dbo.tblMAApplication
		WHERE MAApplicationID = @ApplicationID;
    END    
    
    IF @SubmissionTracking IS NOT NULL
    BEGIN
		SET @rSubmissionTrackingNum = @SubmissionTracking
    END
     
    IF ISNUMERIC(@MASubmissionWorkstreamID) = 1
    BEGIN
		SELECT @rSubmissionID = MASubmissionWorkstreamID 
		FROM dbo.MASubmissionWorkstream
		WHERE MASubmissionWorkstreamID = @MASubmissionWorkstreamID;
    END 
        
    SELECT	@rRegion = Name
    FROM	dbo.tblCountryGroup
    WHERE	CountryGroupID = @CountryGroupID    
        
    SELECT  @rCountry = Name 
    FROM    dbo.tblCountry
    WHERE   CountryID = @CountryID
        
    SELECT  @rRegLead = COALESCE(FullName, ADUserName)
    FROM    dbo.admin_SecUser
    WHERE   UserID = @RegLeadID    
        
    SELECT  @rRegTeam = C.Name 
    FROM    dbo.tblCompany AS C 
    WHERE   CompanyID  = @RegTeamID
        
    SELECT	@rMASubmissionWorkstreamStatusID = StateName
    FROM	dbo.tblBusinessBaseStates bbs
    WHERE	StateID = @MASubmissionWorkstreamStatusID 
    
    SELECT	@rSubmissionRoute = Name
    FROM	dbo.tblSubmissionRoute
    WHERE	SubmissionRouteID = @SubmissionRouteID

	SELECT  @rSubmissionType = Name
    FROM    dbo.tblValidMASubmissionType AS VMST 
    WHERE   ValidMASubmissionTypeID = @ValidMASubmissionTypeID
    
	SELECT @rShowCMS = CASE 
							WHEN @ShowCMSSubmissions = 0 THEN 'False'
							WHEN @ShowCMSSubmissions IS NULL THEN 'False'
							WHEN @ShowCMSSubmissions = 1 THEN 'True'
							ELSE 'Error'
							END
	
	IF @SubmissionStartDate IS NULL
	BEGIN
		SET @SubmissionStartDate = 'All'
	END
	
	IF @SubmissionEndDate IS NULL
	BEGIN
		SET @SubmissionEndDate = 'All'
	END
	
	IF @RegCloseStartDate IS NULL
	BEGIN
		SET @RegCloseStartDate = 'All'
	END	
	
	IF @RegCloseEndDate IS NULL
	BEGIN
		SET @RegCloseEndDate = 'All'
	END	
	
	IF @FinalApproveStartDate IS NULL
	BEGIN
		SET @FinalApproveStartDate = 'All'
	END	
	
	IF @FinalApproveEndDate IS NULL
	BEGIN
		SET @FinalApproveEndDate = 'All'
	END				
							
	SELECT  @User = COALESCE(FullName, ADUserName)
    FROM    dbo.admin_SecUser
    WHERE   UserID = @UserID								

	SELECT  @rProdName AS ProdName,
			@rApplicationNum AS [MAApplication],
			@rApplicationID AS ApplicationID,
			@rSubmissionTrackingNum AS SubmissionTrackingNum,
			@rSubmissionID AS SubmissionID,
			@rRegion AS Region,
			@rCountry AS Country,
			@rRegLead AS RegLead,
            @rRegTeam AS RegTeam,                
            @rMASubmissionWorkstreamStatusID AS SubmissionStatus,
            @rSubmissionRoute AS SubmissionRoute,
            @rSubmissionType AS SubmissionType,
            @rShowCMS AS ShowCMS,  
            @SubmissionStartDate AS SubmissionStartDate,
            @SubmissionEndDate AS SubmissionEndDate,
            @RegCloseStartDate AS RegCloseStartDate,
            @RegCloseEndDate AS RegCloseEndDate,
            @FinalApproveStartDate AS FinalApproveStartDate,
            @FinalApproveEndDate AS FinalApproveEndDate,                         
            @User AS [User]
  
GO
