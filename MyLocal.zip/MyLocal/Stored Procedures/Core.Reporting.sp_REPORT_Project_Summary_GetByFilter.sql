SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- EXEC [Core.Reporting].[sp_REPORT_Project_Summary_GetByFilter] @UserId = 1426, @PrivCode = 'MA01', @ID = 302


CREATE PROCEDURE [Core.Reporting].[sp_REPORT_Project_Summary_GetByFilter]
(
    @ID INT = NULL,
    @DevWorkstreamID INT = NULL,
    @TradeDressWorkstreamID INT = NULL,
    @ProductGroupID INT = NULL,
    @FormFiltersList NVARCHAR(MAX) = NULL,
    @CountryGroupFiltersList NVARCHAR(MAX) = NULL,
    @CountryFiltersList NVARCHAR(MAX) = NULL,
    @BBOTagFiltersList NVARCHAR(MAX) = NULL,
    @ValidProjectTypeFiltersList NVARCHAR(MAX) = NULL,
    @SubmissionYearFiltersList NVARCHAR(MAX) = NULL,
    @ProjectLeadID INT = NULL,
    @FocusNumber NVARCHAR(10) = NULL,
    @EvaluationDateStart DATETIME = NULL,
    @EvaluationDateEnd DATETIME = NULL,
    @ValidWorkPlanID INT = NULL,
    @ValidTechOpsRatingFiltersList NVARCHAR(MAX) = NULL,
    @ValidOpportunityTypeFiltersList NVARCHAR(MAX) = NULL,
    @ProjectStatusID INT = NULL,
    @ParentID INT = NULL,
    @ParentType INT = NULL,
    @UserId INT,
    @PrivCode NVARCHAR(10),
    @SiteCompanyGroupsFiltersList NVARCHAR(MAX) = NULL,
    @SiteFiltersList NVARCHAR(MAX) = NULL,
    @SiteNameFiltersInclusionID INT = 1,
    @FormFiltersInclusionID INT = 1,
    @CountryGroupFiltersInclusionID INT = 1,
    @CountryFiltersInclusionID INT = 1,
    @BBOTagFiltersInclusionID INT = 1,
    @ValidProjectTypeFiltersInclusionID INT = 1,
    @SubmissionYearFiltersInclusionID INT = 1,
    @ProjectLeadInclusionID INT = 1,
    @ValidTechOpsRatingFiltersInclusionID INT = 1,
    @ValidOpportunityTypeFiltersInclusionID INT = 1,
    @ProjectStatusInclusionID INT = 1,
    @ProjectTeamRoleFiltersList NVARCHAR(256) = NULL,
    @TeamMemberFiltersList NVARCHAR(MAX) = NULL,
    @TeamMemberFiltersInclusionID INT = 1,
    @AlertTypesFiltersList NVARCHAR(MAX) = NULL,
    @AlertTypesInclusionID INT = 1
)
AS
BEGIN
    DECLARE @BBOID INT =
            (
                SELECT TOP (1)
                       BBOID
                FROM dbo.tblBusinessBaseObject
                WHERE BBOCode = 'PJM'
                ORDER BY BBOID
            );
    DECLARE @PWBBOID INT =
            (
                SELECT TOP (1)
                       BBOID
                FROM dbo.tblBusinessBaseObject
                WHERE BBOCode = 'PVW'
                ORDER BY BBOID
            );
    DECLARE @PLWBBOID INT =
            (
                SELECT TOP (1)
                       BBOID
                FROM dbo.tblBusinessBaseObject
                WHERE BBOCode = 'PLW'
                ORDER BY BBOID
            );
    DECLARE @TDWBBOID INT =
            (
                SELECT TOP (1)
                       BBOID
                FROM dbo.tblBusinessBaseObject
                WHERE BBOCode = 'TDW'
                ORDER BY BBOID
            );

    DECLARE @IncludeScaleUpSites INT = CHARINDEX('Scale Up Site', @SiteCompanyGroupsFiltersList);
    DECLARE @IncludeDevelopmentSites INT = CHARINDEX('Development Site', @SiteCompanyGroupsFiltersList);
    DECLARE @IncludePackagingSites INT = CHARINDEX('Packaging Site', @SiteCompanyGroupsFiltersList);
    DECLARE @IncludeManufacturingSites INT = CHARINDEX('Manufacturing Site', @SiteCompanyGroupsFiltersList);

    DECLARE @CountryGroupFilters CountryGroupType;
    DECLARE @CountryFilters CountryType;
    DECLARE @BBOTagFilters BBOTagType;
    DECLARE @ValidProjectTypeFilters ValidProjectTypeType;
    DECLARE @SubmissionYearFilters TimeframeType;
    DECLARE @ValidOpportunityTypeFilters ValidOpportunityTypeType;
    DECLARE @FormFilters FormType;
    DECLARE @ValidTechOpsRatingFilters ValidTechOpsRatingType;
    DECLARE @SiteFilters IdType;
    DECLARE @TeamMembers IdType;
    DECLARE @AlertTypesList IdType;

    IF LEN(@CountryGroupFiltersList) > 0
        INSERT @CountryGroupFilters
        (
            CountryGroupID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@CountryGroupFiltersList);

    IF LEN(@SiteFiltersList) > 0
        INSERT @SiteFilters
        (
            Id
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@SiteFiltersList);

    IF LEN(@CountryFiltersList) > 0
        INSERT @CountryFilters
        (
            CountryID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@CountryFiltersList);

    IF LEN(@BBOTagFiltersList) > 0
        INSERT @BBOTagFilters
        (
            BBOTagID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@BBOTagFiltersList);

    IF LEN(@ValidProjectTypeFiltersList) > 0
        INSERT @ValidProjectTypeFilters
        (
            ValidProjectTypeID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@ValidProjectTypeFiltersList);

    IF LEN(@SubmissionYearFiltersList) > 0
        INSERT @SubmissionYearFilters
        (
            Timeframe
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@SubmissionYearFiltersList);

    IF LEN(@ValidOpportunityTypeFiltersList) > 0
        INSERT @ValidOpportunityTypeFilters
        (
            ValidOpportunityTypeID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@ValidOpportunityTypeFiltersList);

    IF LEN(@ValidTechOpsRatingFiltersList) > 0
        INSERT @ValidTechOpsRatingFilters
        (
            ValidTechOpsRatingID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@ValidTechOpsRatingFiltersList);

    IF LEN(@FormFiltersList) > 0
        INSERT @FormFilters
        (
            FormID
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@FormFiltersList);
    IF LEN(@TeamMemberFiltersList) > 0
        INSERT INTO @TeamMembers
        (
            Id
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@TeamMemberFiltersList);

    IF LEN(@AlertTypesFiltersList) > 0
        INSERT INTO @AlertTypesList
        (
            Id
        )
        SELECT id
        FROM dbo.udf_GetValuesFromCSV(@AlertTypesFiltersList);

    DECLARE @tmp_ID TABLE
    (
        id INT NOT NULL
    );

    DECLARE @mtiCode TABLE
    (
        [ProjectId] INT NOT NULL INDEX ix1 CLUSTERED,
        [MilestoneCode] NVARCHAR(32) NOT NULL INDEX ix2 NONCLUSTERED,
        [MilestoneStatus] NVARCHAR(MAX) NULL,
        [EstimatedDate] DATETIME NULL,
        [Name] NVARCHAR(MAX) NULL
    );

    INSERT INTO @mtiCode
    (
        [ProjectId],
        [MilestoneCode],
        [MilestoneStatus],
        [EstimatedDate],
        [Name]
    )
    (SELECT DISTINCT
            pmp.ProjectID,
            mti.Code,
            vms.Name,
            CASE
                WHEN m.ReferenceMilestoneID IS NULL THEN
                    m.BestEstimateDate
                ELSE
                    refm.BestEstimateDate
            END,
            f.NAME
     FROM pm.Project pmp
         JOIN dbo.tblMilestoneTemplateItem AS mti
             ON mti.MilestoneTemplateID = pmp.MilestoneTemplateID
         JOIN dbo.tblMilestone AS m
             ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                AND m.ObjectID = pmp.ProjectID
                AND m.BBOID = @BBOID
         LEFT JOIN dbo.tblMilestone refm
             ON m.ReferenceMilestoneID = refm.MileStoneID
         LEFT JOIN dbo.tblValidMilestoneStatus vms
             ON COALESCE(refm.StatusID, m.StatusID) = vms.ValidMilestoneStatusID
         LEFT JOIN dbo.vwLinkObjectToRegionForm f
             ON m.ObjectID = f.ObjectID
                AND m.BBOID = f.BBOID
     --WHERE MTI.Code IN ( 'BE Met', 'SNC Decision', 'PVW - SU Complete', 'PVW - PK Report', 'PVW - Stab. Report' ));
     WHERE mti.Code IN ( 'Submission', 'Initial RLD', 'API Selection Final', 'Form Process Final', 'EB Man Init.',
                         'Final EB Stab. Set Dwn.', 'BE/Clin. or API Same Start', 'BE/API Same. Results',
                         'Last Doc. to RA'
                       ));

    INSERT INTO @tmp_ID
    SELECT DISTINCT
           p.ProjectID AS [ID]
    FROM pm.Project p
        JOIN dbo.tblForm f
            ON p.FormID = f.FormID
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = f.ValidFormID
        JOIN dbo.tblProduct prod
            ON f.FormID = p.FormID
               AND f.ProductID = prod.ProductID
        LEFT JOIN pm.ProjectTag pt
            ON pt.ProjectID = p.ProjectID
        LEFT JOIN dbo.admin_SecUser con
            ON p.ProjectLeadID = con.UserID
        LEFT JOIN dbo.tblCountryGroup cg
            ON p.CountryGroupID = cg.CountryGroupID
        LEFT JOIN dbo.tblValidProjectType vpt
            ON p.ValidProjectTypeID = vpt.ValidProjectTypeID
        LEFT JOIN dbo.tblValidBBOTag bt
            ON pt.ValidBBOTagID = bt.ValidBBOTagID
        LEFT JOIN dbo.tblValidProjectOppType vot
            ON p.ValidOpportunityTypeID = vot.ValidProjectOppTypeID
        LEFT JOIN dbo.tblBusinessBaseStates bbs
            ON p.ProjectStatusID = bbs.StateID
        LEFT JOIN pm.DevWorkstreamLinkProject dwlp
            ON p.ProjectID = dwlp.ProjectID
        LEFT JOIN pm.TradeDressWorkstreamLinkProject tdwlp
            ON p.ProjectID = tdwlp.ProjectID
        LEFT JOIN dbo.tblCompany pk
            ON p.PackagingSiteID = pk.CompanyID
        LEFT JOIN dbo.tblValidPjMRating pjm
            ON p.ValidPjMRatingID = pjm.ValidPjMRatingID
        LEFT JOIN dbo.admin_SecUser u
            ON p.LegalLeadID = u.UserID
        LEFT JOIN dbo.tblBrand brnd
            ON p.BrandID = brnd.BrandID
        LEFT JOIN dbo.tblValidTechOpsRating tor
            ON p.ValidTechOpsRatingID = tor.ValidTechOpsRatingID
        LEFT JOIN dbo.tblCompany bp
            ON p.BusinessPartnerID = bp.CompanyID
        LEFT JOIN dbo.tblValidProjectAgreementType pat
            ON p.ProjectAgreementTypeID = pat.ValidProjectAgreementTypeID
        LEFT JOIN dbo.tblBCRASession bcra
            ON p.BCRASessionID = bcra.BCRASessionID
        LEFT JOIN dbo.tblValidReleaseCategory vrc
            ON f.ValidReleaseCategoryID = vrc.ValidReleaseCategoryID
        LEFT JOIN dbo.tblValidReleaseMechanism AS VRM
            ON f.ValidReleaseMechanismID = VRM.ValidReleaseMechanismID
        LEFT JOIN pm.PRBSession prb
            ON p.PRBApprovalSessionID = prb.PRBSessionID
        LEFT JOIN dbo.tblValidYesNoTBD ynt
            ON ynt.ValidYesNoTBDID = p.UseForMetricsID
    --LEFT JOIN @mtiCode AS msub
    --    ON msub.ProjectId = p.ProjectID
    --       AND msub.MilestoneCode = 'Submission'
    --LEFT JOIN @mtiCode AS mir
    --    ON mir.ProjectId = p.ProjectID
    --       AND mir.MilestoneCode = 'Initial RLD'
    --LEFT JOIN @mtiCode AS masf
    --    ON masf.ProjectId = p.ProjectID
    --       AND masf.MilestoneCode = 'API Selection Final'
    --LEFT JOIN @mtiCode AS mfpf
    --    ON mfpf.ProjectId = p.ProjectID
    --       AND mfpf.MilestoneCode = 'Form Process Final'
    --LEFT JOIN @mtiCode AS memi
    --    ON memi.ProjectId = p.ProjectID
    --       AND memi.MilestoneCode = 'EB Man Init.'
    --LEFT JOIN @mtiCode AS mfes
    --    ON mfes.ProjectId = p.ProjectID
    --       AND mfes.MilestoneCode = 'Final EB Stab. Set Dwn.'
    --LEFT JOIN @mtiCode AS mbc
    --    ON mbc.ProjectId = p.ProjectID
    --       AND mbc.MilestoneCode = 'BE/Clin. or API Same Start'
    --LEFT JOIN @mtiCode AS mba
    --    ON mba.ProjectId = p.ProjectID
    --       AND mba.MilestoneCode = 'BE/API Same. Results'
    --LEFT JOIN @mtiCode AS mldr
    --    ON mldr.ProjectId = p.ProjectID
    --       AND mldr.MilestoneCode = 'Last Doc. to RA'
    WHERE (dbo.udf_UserHasPrivForCountryGroup(@UserId, @PrivCode, p.CountryGroupID) = 'true')
          AND
          (
              @ID IS NULL
              OR p.ProjectID = @ID
          )
          AND
          (
              @ProductGroupID IS NULL
              OR f.ProductID = @ProductGroupID
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @FormFilters
    )
              AND @FormFiltersInclusionID <> 4
              OR
              (
                  @FormFiltersInclusionID = 1
                  AND EXISTS
    (
        SELECT 1 FROM @FormFilters WHERE FormID = p.FormID
    )
              )
              OR
              (
                  @FormFiltersInclusionID = 2
                  AND
                  (
                      SELECT COUNT(DISTINCT f.FormID)
                      FROM dbo.tblForm f
                          JOIN @FormFilters ff
                              ON ff.FormID = f.FormID
                                 AND f.FormID = p.FormID
                  ) =
                  (
                      SELECT COUNT(DISTINCT FormID)FROM @FormFilters
                  )
              )
              OR
              (
                  @FormFiltersInclusionID = 3
                  AND NOT EXISTS
    (
        SELECT 1 FROM @FormFilters WHERE FormID = p.FormID
    )
              )
              OR
              (
                  @FormFiltersInclusionID = 4
                  AND p.FormID IS NULL
              )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @CountryGroupFilters
    )
              AND @CountryGroupFiltersInclusionID <> 4
              OR
              (
                  @CountryGroupFiltersInclusionID = 1
                  AND EXISTS
    (
        SELECT 1 FROM @CountryGroupFilters WHERE CountryGroupID = p.CountryGroupID
    )
              )
              OR
              (
                  @CountryGroupFiltersInclusionID = 3
                  AND NOT EXISTS
    (
        SELECT 1 FROM @CountryGroupFilters WHERE CountryGroupID = p.CountryGroupID
    )
              )
          )
          AND
          (
              (
                  NOT EXISTS
    (
        SELECT 1 FROM @CountryFilters
    )
                  AND @CountryFiltersInclusionID <> 4
              )
              OR
              (
                  @CountryFiltersInclusionID = 1
                  AND p.ProjectID IN
                      (
                          SELECT plc.ProjectID
                          FROM pm.ProjectLinkCountry plc
                              JOIN @CountryFilters cf
                                  ON cf.CountryID = plc.CountryID
                      )
              )
              OR
              (
                  @CountryFiltersInclusionID = 2
                  AND
                  (
                      SELECT COUNT(DISTINCT plc.CountryID)
                      FROM pm.ProjectLinkCountry plc
                          JOIN @CountryFilters cf
                              ON cf.CountryID = plc.CountryID
                                 AND plc.ProjectID = p.ProjectID
                  ) =
                  (
                      SELECT COUNT(DISTINCT CountryID)FROM @CountryFilters
                  )
              )
              OR
              (
                  @CountryFiltersInclusionID = 3
                  AND p.ProjectID NOT IN
                      (
                          SELECT plc.ProjectID
                          FROM pm.ProjectLinkCountry plc
                              JOIN @CountryFilters cf
                                  ON cf.CountryID = plc.CountryID
                      )
              )
              OR
              (
                  @CountryFiltersInclusionID = 4
                  AND p.ProjectID NOT IN
                      (
                          SELECT ProjectID FROM pm.ProjectLinkCountry plc
                      )
              )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @BBOTagFilters
    )
              AND @BBOTagFiltersInclusionID <> 4
              OR
              (
                  @BBOTagFiltersInclusionID = 1
                  AND pt.ValidBBOTagID IN
                      (
                          SELECT BBOTagID FROM @BBOTagFilters
                      )
              )
              OR
              (
                  @BBOTagFiltersInclusionID = 2
                  AND
                  (
                      SELECT COUNT(DISTINCT pt.ValidBBOTagID)
                      FROM pm.ProjectTag pt
                          JOIN @BBOTagFilters tf
                              ON tf.BBOTagID = pt.ValidBBOTagID
                                 AND pt.ProjectID = p.ProjectID
                  ) =
                  (
                      SELECT COUNT(DISTINCT BBOTagID)FROM @BBOTagFilters
                  )
              )
              OR
              (
                  @BBOTagFiltersInclusionID = 3
                  AND (p.ProjectID NOT IN
                       (
                           SELECT pt.ProjectID
                           FROM pm.ProjectTag pt
                               JOIN @BBOTagFilters btf
                                   ON btf.BBOTagID = pt.ValidBBOTagID
                       )
                      )
              )
              OR
              (
                  @BBOTagFiltersInclusionID = 4
                  AND p.ProjectID NOT IN
                      (
                          SELECT ProjectID FROM pm.ProjectTag
                      )
              )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @ValidProjectTypeFilters
    )
              OR
              (
                  @ValidProjectTypeFiltersInclusionID = 1
                  AND p.ValidProjectTypeID IN
                      (
                          SELECT ValidProjectTypeID FROM @ValidProjectTypeFilters
                      )
              )
              OR
              (
                  @ValidProjectTypeFiltersInclusionID = 3
                  AND p.ValidProjectTypeID NOT IN
                      (
                          SELECT ValidProjectTypeID FROM @ValidProjectTypeFilters
                      )
              )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @ValidOpportunityTypeFilters
    )
              AND @ValidOpportunityTypeFiltersInclusionID <> 4
              OR
              (
                  @ValidOpportunityTypeFiltersInclusionID = 1
                  AND p.ValidOpportunityTypeID IN
                      (
                          SELECT ValidOpportunityTypeID FROM @ValidOpportunityTypeFilters
                      )
              )
              OR
              (
                  @ValidOpportunityTypeFiltersInclusionID = 3
                  AND
                  (
                      p.ValidOpportunityTypeID NOT IN
                      (
                          SELECT ValidOpportunityTypeID FROM @ValidOpportunityTypeFilters
                      )
                      OR p.ValidOpportunityTypeID IS NULL
                  )
              )
              OR
              (
                  @ValidOpportunityTypeFiltersInclusionID = 4
                  AND p.ValidOpportunityTypeID IS NULL
              )
          )
          AND
          (
              @DevWorkstreamID IS NULL
              OR dwlp.DevWorkstreamID = @DevWorkstreamID
          )
          AND
          (
              @ParentType <> @PLWBBOID
              OR @ParentID IS NULL
              OR
              (
                  @ParentType = @PLWBBOID
                  AND dwlp.DevWorkstreamID = @ParentID
              )
          )
          AND
          (
              @TradeDressWorkstreamID IS NULL
              OR tdwlp.TradeDressWorkstreamID = @TradeDressWorkstreamID
          )
          AND
          (
              @ParentType <> @TDWBBOID
              OR @ParentID IS NULL
              OR
              (
                  @ParentType = @TDWBBOID
                  AND tdwlp.TradeDressWorkstreamID = @ParentID
              )
          )
          AND
          (
              @ParentType <> @PWBBOID
              OR @ParentID IS NULL
              OR
              (
                  @ParentType = @PWBBOID
                  AND @ParentID IN
                      (
                          SELECT PivotalWorkstreamID
                          FROM pm.PivotalWorkstreamLinkProject
                          WHERE ProjectID = p.ProjectID
                      )
              )
          )
          AND
          (
              @ProjectLeadID IS NULL
              OR
              (
                  @ProjectLeadInclusionID = 1
                  AND p.ProjectLeadID = @ProjectLeadID
              )
              OR
              (
                  @ProjectLeadInclusionID = 3
                  AND p.ProjectLeadID <> @ProjectLeadID
              )
          )
          AND
          (
              @FocusNumber IS NULL
              OR p.FocusNumber LIKE @FocusNumber
          )
          AND
          (
              (
                  @EvaluationDateStart IS NULL
                  AND @EvaluationDateEnd IS NULL
              )
              OR (p.EvaluationDate
          BETWEEN ISNULL(@EvaluationDateStart, '01/01/1899') AND ISNULL(@EvaluationDateEnd, '01/01/2050')
                 )
          )
          AND
          (
              @ValidWorkPlanID IS NULL
              OR p.ValidWorkPlanID = @ValidWorkPlanID
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @ValidTechOpsRatingFilters
          )   = 0
          AND @ValidTechOpsRatingFiltersInclusionID <> 4
          OR
          (
              @ValidTechOpsRatingFiltersInclusionID = 1
              AND ISNULL(p.ValidTechOpsRatingID, -1)IN
                  (
                      SELECT ValidTechOpsRatingID FROM @ValidTechOpsRatingFilters
                  )
          )
          OR
          (
              @ValidTechOpsRatingFiltersInclusionID = 3
              AND ISNULL(p.ValidTechOpsRatingID, -1) NOT IN
                  (
                      SELECT ValidTechOpsRatingID FROM @ValidTechOpsRatingFilters
                  )
          )
          OR
          (
              @ValidTechOpsRatingFiltersInclusionID = 4
              AND p.ValidTechOpsRatingID IS NULL
          )
          )
          AND
          (
              @ProjectStatusID IS NULL
              OR
              (
                  @ProjectStatusInclusionID = 1
                  AND p.ProjectStatusID = @ProjectStatusID
              )
              OR
              (
                  @ProjectStatusInclusionID = 3
                  AND p.ProjectStatusID <> @ProjectStatusID
              )
          )
          AND
          (
          (
              SELECT COUNT(*)FROM @SubmissionYearFilters
          )   = 0
          AND @SubmissionYearFiltersInclusionID <> 4
          OR
          (
              @SubmissionYearFiltersInclusionID = 1
              AND
              (
                  SELECT CASE
                             WHEN m.ReferenceMilestoneID IS NULL THEN
                                 YEAR(m.BestEstimateDate)
                             ELSE
                                 YEAR(refm.BestEstimateDate)
                         END
                  FROM dbo.tblMilestone m
                      JOIN dbo.tblMilestoneTemplateItem mti
                          ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                             AND mti.Code = 'Submission'
                      LEFT JOIN dbo.tblMilestone refm
                          ON refm.MileStoneID = m.MileStoneID
                  WHERE m.BBOID = @BBOID
                        AND m.ObjectID = p.ProjectID
              ) IN
              (
                  SELECT Timeframe FROM @SubmissionYearFilters
              )
          )
          OR
          (
              @SubmissionYearFiltersInclusionID = 3
              AND ISNULL(
                  (
                      SELECT CASE
                                 WHEN m.ReferenceMilestoneID IS NULL THEN
                                     YEAR(m.BestEstimateDate)
                                 ELSE
                                     YEAR(refm.BestEstimateDate)
                             END
                      FROM dbo.tblMilestone m
                          JOIN dbo.tblMilestoneTemplateItem mti
                              ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 AND mti.Code = 'Submission'
                          LEFT JOIN dbo.tblMilestone refm
                              ON refm.MileStoneID = m.MileStoneID
                      WHERE m.BBOID = @BBOID
                            AND m.ObjectID = p.ProjectID
                  ),
                  -1
                        ) NOT IN
                  (
                      SELECT Timeframe FROM @SubmissionYearFilters
                  )
          )
          OR
          (
              @SubmissionYearFiltersInclusionID = 4
              AND (
                  (
                      SELECT CASE
                                 WHEN m.ReferenceMilestoneID IS NULL THEN
                                     YEAR(m.BestEstimateDate)
                                 ELSE
                                     YEAR(refm.BestEstimateDate)
                             END
                      FROM dbo.tblMilestone m
                          JOIN dbo.tblMilestoneTemplateItem mti
                              ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                                 AND mti.Code = 'Submission'
                          LEFT JOIN dbo.tblMilestone refm
                              ON refm.MileStoneID = m.MileStoneID
                      WHERE m.BBOID = @BBOID
                            AND m.ObjectID = p.ProjectID
                  ) IS NULL
                  )
          )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @SiteFilters
    )
              -- Include
              OR (
              (
                  @SiteNameFiltersInclusionID = 1
                  AND
                  (
                      (
                          @IncludeScaleUpSites > 0
                          AND p.ProjectID IN
                              (
                                  SELECT pwlp.ProjectID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.PivotalWorkstream pw
                                          ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE pw.ScaleUpSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                      OR
                      (
                          @IncludePackagingSites > 0
                          AND p.PackagingSiteID IN
                              (
                                  SELECT Id FROM @SiteFilters
                              )
                      )
                      OR
                      (
                          @IncludeManufacturingSites > 0
                          AND p.ManufacturingSiteID IN
                              (
                                  SELECT Id FROM @SiteFilters
                              )
                      )
                      OR
                      (
                          @IncludeDevelopmentSites > 0
                          AND p.ProjectID IN
                              (
                                  SELECT pwlp.ProjectID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.PivotalWorkstream pw
                                          ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE pw.DevSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                  )
              )
                 )
              -- Exclude
              OR
              (
                  @SiteNameFiltersInclusionID = 3
                  AND
                  (
                      (
                          @IncludeScaleUpSites > 0
                          AND p.ProjectID NOT IN
                              (
                                  SELECT pwlp.ProjectID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.PivotalWorkstream pw
                                          ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE ScaleUpSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                      OR
                      (
                          @IncludePackagingSites > 0
                          AND
                          (
                              p.PackagingSiteID IS NULL
                              OR p.PackagingSiteID NOT IN
                                 (
                                     SELECT Id FROM @SiteFilters
                                 )
                          )
                      )
                      OR
                      (
                          @IncludeManufacturingSites > 0
                          AND
                          (
                              p.ManufacturingSiteID IS NULL
                              OR p.ManufacturingSiteID NOT IN
                                 (
                                     SELECT Id FROM @SiteFilters
                                 )
                          )
                      )
                      OR
                      (
                          @IncludeDevelopmentSites > 0
                          AND p.ProjectID NOT IN
                              (
                                  SELECT pwlp.ProjectID
                                  FROM pm.PivotalWorkstreamLinkProject pwlp
                                      JOIN pm.PivotalWorkstream pw
                                          ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                                  WHERE pw.DevSiteID IN
                                        (
                                            SELECT Id FROM @SiteFilters
                                        )
                              )
                      )
                  )
              )
          )
          AND
          (
              (
                  NOT EXISTS
    (
        SELECT 1 FROM @TeamMembers
    )
                  AND @TeamMemberFiltersInclusionID <> 4
              )
              OR
              (
                  @TeamMemberFiltersInclusionID = 1
                  AND p.ProjectID IN
                      (
                          SELECT ProjectID
                          FROM ProjectTeam
                          WHERE Role = @ProjectTeamRoleFiltersList
                                AND UserID IN
                                    (
                                        SELECT Id FROM @TeamMembers
                                    )
                      )
              )
              OR
              (
                  @TeamMemberFiltersInclusionID = 2
                  AND
                  (
                      SELECT COUNT(DISTINCT ProjectID)
                      FROM dbo.ProjectTeam pt
                          JOIN @TeamMembers tf
                              ON tf.Id = pt.UserID
                                 AND pt.ProjectID = p.ProjectID
                      WHERE pt.Role = @ProjectTeamRoleFiltersList
                  ) =
                  (
                      SELECT COUNT(DISTINCT Id)FROM @TeamMembers
                  )
              )
              OR
              (
                  @TeamMemberFiltersInclusionID = 3
                  AND p.ProjectID NOT IN
                      (
                          SELECT ProjectID
                          FROM dbo.ProjectTeam pt
                          WHERE pt.Role = @ProjectTeamRoleFiltersList
                                AND UserID IN
                                    (
                                        SELECT Id FROM @TeamMembers
                                    )
                      )
              )
              OR
              (
                  @TeamMemberFiltersInclusionID = 4
                  AND p.ProjectID IN
                      (
                          SELECT ProjectID
                          FROM pm.Project
                          WHERE ProjectID NOT IN
                                (
                                    SELECT ProjectID
                                    FROM dbo.ProjectTeam
                                    WHERE Role = @ProjectTeamRoleFiltersList
                                )
                      )
              )
          )
          AND
          (
              NOT EXISTS
    (
        SELECT 1 FROM @AlertTypesList
    )
              AND @AlertTypesInclusionID <> 4
              OR
              (
                  @AlertTypesInclusionID = 1
                  AND (EXISTS
    (
        SELECT xoa.ValidAlertTypeID
        FROM dbo.ProjectAlert xoa
            JOIN @AlertTypesList xvatf
                ON xoa.ValidAlertTypeID = xvatf.Id
        WHERE xoa.ObjectID = p.ProjectID
    )
                      )
              )
              OR
              (
                  @AlertTypesInclusionID = 2
                  AND
                  (
                      SELECT COUNT(DISTINCT xoa.ValidAlertTypeID)
                      FROM dbo.ProjectAlert xoa
                          JOIN @AlertTypesList xvatf
                              ON xoa.ValidAlertTypeID = xvatf.Id
                      WHERE xoa.ObjectID = p.ProjectID
                  ) =
                  (
                      SELECT COUNT(DISTINCT Id)FROM @AlertTypesList
                  )
              )
              OR
              (
                  @AlertTypesInclusionID = 3
                  AND (NOT EXISTS
    (
        SELECT xoa.ValidAlertTypeID
        FROM dbo.ProjectAlert xoa
            JOIN @AlertTypesList xvatf
                ON xoa.ValidAlertTypeID = xvatf.Id
        WHERE xoa.ObjectID = p.ProjectID
    )
                      )
              )
              OR
              (
                  @AlertTypesInclusionID = 4
                  AND (dbo.udf_EHSAlert(f.ProductID, NULL) IS NULL)
              )
          );

    SELECT DISTINCT
           p.ProjectID AS [ID],
           bt.Tag AS [Tag Name],
           bt.ValidBBOTagID AS [Tag Value],
           f.Name AS Form,
           vv.Name AS Vertical,
           VRM.Name AS ValidReleaseMechanism,
           cg.Name AS [Market],
           prod.Name AS Product,
           vf.Name AS ValidForm,
           vta.Name AS ValidTherapeuticArea,
           f.Identifier,
           f.IQVIAMolecules,
           f.IQVIAForms,
           p.PTRS,
           p.PTRSAsOfDate,
           LTRIM(RTRIM(   ISNULL(VRM.Name, '') + ' ' + vf.Name + CASE
                                                                     WHEN ISNULL(f.Identifier, '') = '' THEN
                                                                         ''
                                                                     ELSE
                                                                         ' (' + f.Identifier + ')'
                                                                 END
                      )
                ) AS [Pharm. Form],
           brnd.Name AS [Brand Name],
           (
               SELECT DISTINCT
                      cmp.Name
               FROM dbo.tblBrand brnd
                   JOIN dbo.tblCountry cntry
                       ON cntry.CountryID = brnd.CountryID
                   JOIN dbo.tblCompany cmp
                       ON cmp.CompanyID = brnd.BrandCompanyID
               WHERE brnd.BrandID = p.BrandID
           ) AS [Brand Company],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + s.Name
                        FROM dbo.tblStrength s
                            JOIN pm.ProjectStrength ps
                                ON s.StrengthID = ps.StrengthID
                        WHERE ps.ProjectID = p.ProjectID
                              AND s.IsUndefined = 0
                        ORDER BY ', ' + s.Name
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS Strengths,
                       --STUFF(
                       --(
                       --    SELECT DISTINCT
                       --           ', ' + COALESCE(co.ShortName, co.Name)
                       --    FROM dbo.tblCompany co
                       --        JOIN pm.PivotalWorkstream pw
                       --            ON co.CompanyID = pw.DevSiteID
                       --        JOIN pm.PivotalWorkstreamLinkProject pwlp
                       --            ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                       --    WHERE pwlp.ProjectID = p.ProjectID
                       --    ORDER BY ', ' + COALESCE(co.ShortName, co.Name)
                       --    FOR XML PATH('')
                       --),
                       --1,
                       --2,
                       --''
                       --     ) AS [Pivotal Development Site],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + COALESCE(co.ShortName, co.Name)
                        FROM dbo.tblCompany co
                            JOIN pm.PivotalWorkstream pw
                                ON co.CompanyID = pw.DevSiteID
                            JOIN pm.PivotalWorkstreamLinkProject pwlp
                                ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                        WHERE pwlp.ProjectID = p.ProjectID
                        ORDER BY ', ' + COALESCE(co.ShortName, co.Name)
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS [Pivotal Development Site],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + COALESCE(su.FullName, su.ADUserName)
                        FROM dbo.admin_SecUser su
                            JOIN pm.PivotalWorkstream pw
                                ON su.UserID = pw.LeadID
                            JOIN pm.PivotalWorkstreamLinkProject pwlp
                                ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                        WHERE pwlp.ProjectID = p.ProjectID
                        ORDER BY ', ' + COALESCE(su.FullName, su.ADUserName)
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS [Pivotal Lead],
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + COALESCE(co.ShortName, co.Name)
                        FROM dbo.tblCompany co
                            JOIN pm.PivotalWorkstream pw
                                ON co.CompanyID = pw.ScaleUpSiteID
                            JOIN pm.PivotalWorkstreamLinkProject pwlp
                                ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                        WHERE pwlp.ProjectID = p.ProjectID
                        ORDER BY ', ' + COALESCE(co.ShortName, co.Name)
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS [Pivotal Scale Up Site],
           vpt.Name AS [Project Type],
           bbs.StateName AS [Project Status],
           prb.Name AS [PRB Approval],
           STUFF(
                    (
                        SELECT (', ' + prb1.Name + ' (' + COALESCE(pc1.Name, 'None') + ' [' + COALESCE(vpsc1.Name, 'N/A')
                                + '])'
                               )
                        FROM pm.ProductProposal prop1
                            JOIN pm.ProductProposalLinkProject plp1
                                ON prop1.ProductProposalID = plp1.ProductProposalID
                            JOIN dbo.tblForm f1
                                ON prop1.FormID = f1.FormID
                            LEFT JOIN pm.Candidate c1
                                ON prop1.CandidateID = c1.CandidateID
                            LEFT JOIN pm.PRBSession prb1
                                ON prb1.PRBSessionID = c1.TargetPRBSessionID
                            LEFT JOIN dbo.tblValidProposalClass pc1
                                ON prop1.ValidProposalClassID = pc1.ValidProposalClassID
                            LEFT JOIN pm.ProductProposalLinkProjectScopeChange lsc
                                ON lsc.ProductProposalID = prop1.ProductProposalID
                            LEFT JOIN dbo.tblValidProjectScopeChange vpsc1
                                ON lsc.ValidProjectScopeChangeID = vpsc1.ValidProjectScopeChangeID
                        WHERE plp1.ProjectID = p.ProjectID
                        ORDER BY prb1.SessionDate
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS [PRB History],
           vot.Name AS [Opportunity Type],
           tor.NAME AS [R&D Rating],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + Alert
               FROM dbo.udf_EHSAlert_Table(f.ProductID, NULL)
               ORDER BY ', ' + Alert
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS EHSAlert,
           STUFF(
                    (
                        SELECT DISTINCT
                               ', ' + ISNULL(pec.Name, '[None]') + ' - ' + vki.Name
                        FROM dbo.tblForm f1
                            JOIN dbo.tblProductLinkKPI AS plk
                                ON f1.ProductID = plk.ProductID
                            JOIN dbo.tblKPI kpi
                                ON kpi.KPIID = plk.KPIID
                            JOIN dbo.tblValidKeyIngredient AS vki
                                ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            LEFT JOIN dbo.tblValidPECCategory AS pec
                                ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                        WHERE f1.FormID = f.FormID
                        ORDER BY ', ' + ISNULL(pec.Name, '[None]') + ' - ' + vki.Name DESC
                        FOR XML PATH(''), TYPE
                    ).value('.[1]', 'nvarchar(max)'),
                    1,
                    2,
                    ''
                ) AS OEBClassifications,
           STUFF(
           (
               SELECT ', ' + vki.Name + ' - '
                      + ISNULL(STUFF(
                                        (
                                            SELECT DISTINCT
                                                   ', ' + vdc.NAME
                                            FROM dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc
                                                JOIN dbo.tblValidDrugClassification vdc
                                                    ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
                                            WHERE vki.ValidKeyIngredientID = vkilvdc.ValidKeyIngredientID
                                            FOR XML PATH(''), TYPE
                                        ).value('.[1]', 'nvarchar(max)'),
                                        1,
                                        2,
                                        ''
                                    ),
                               '[None]'
                              )
               FROM dbo.tblForm f2
                   JOIN dbo.tblProductLinkKPI plk
                       ON f2.ProductID = plk.ProductID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = plk.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidPECCategory AS pec
                       ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
               WHERE f2.FormID = f.FormID
               ORDER BY pec.Name DESC
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS DrugClassifications,
           p.Sales AS [IMS Sales],
           p.MATDate AS [IMS as of date],
           (
               SELECT msub.EstimatedDate
               FROM @mtiCode msub
               WHERE msub.ProjectId = p.ProjectID
                     AND msub.MilestoneCode = 'Submission'
           ) AS CEESD, -- [Submission],
           (
               SELECT msub.MilestoneStatus
               FROM @mtiCode msub
               WHERE msub.ProjectId = p.ProjectID
                     AND msub.MilestoneCode = 'Submission'
           ) AS [CEESD Status],
           (
               SELECT mir.EstimatedDate
               FROM @mtiCode mir
               WHERE mir.ProjectId = p.ProjectID
                     AND mir.MilestoneCode = 'Initial RLD'
           ) AS [Initial RLD],
           (
               SELECT mir.MilestoneStatus
               FROM @mtiCode mir
               WHERE mir.ProjectId = p.ProjectID
                     AND mir.MilestoneCode = 'Initial RLD'
           ) AS [Initial RLD Status],
           (
               SELECT masf.EstimatedDate
               FROM @mtiCode masf
               WHERE masf.ProjectId = p.ProjectID
                     AND masf.MilestoneCode = 'API Selection Final'
           ) AS [API Selection Final],
           (
               SELECT masf.MilestoneStatus
               FROM @mtiCode masf
               WHERE masf.ProjectId = p.ProjectID
                     AND masf.MilestoneCode = 'API Selection Final'
           ) AS [API Selection Final Status],
           (
               SELECT mfpf.EstimatedDate
               FROM @mtiCode mfpf
               WHERE mfpf.ProjectId = p.ProjectID
                     AND mfpf.MilestoneCode = 'Form Process Final'
           ) AS [Form Process Final],
           (
               SELECT mfpf.MilestoneStatus
               FROM @mtiCode mfpf
               WHERE mfpf.ProjectId = p.ProjectID
                     AND mfpf.MilestoneCode = 'Form Process Final'
           ) AS [Form Process Final Status],
           (
               SELECT memi.EstimatedDate
               FROM @mtiCode memi
               WHERE memi.ProjectId = p.ProjectID
                     AND memi.MilestoneCode = 'EB Man Init.'
           ) AS [EB Man Init],
           (
               SELECT memi.MilestoneStatus
               FROM @mtiCode memi
               WHERE memi.ProjectId = p.ProjectID
                     AND memi.MilestoneCode = 'EB Man Init.'
           ) AS [EB Man Init Status],
           (
               SELECT mfes.EstimatedDate
               FROM @mtiCode mfes
               WHERE mfes.ProjectId = p.ProjectID
                     AND mfes.MilestoneCode = 'Final EB Stab. Set Dwn.'
           ) AS [Final EB Stab Set Dwn],
           (
               SELECT mfes.MilestoneStatus
               FROM @mtiCode mfes
               WHERE mfes.ProjectId = p.ProjectID
                     AND mfes.MilestoneCode = 'Final EB Stab. Set Dwn.'
           ) AS [Final EB Stab Set Dwn Status],
           (
               SELECT mbc.EstimatedDate
               FROM @mtiCode mbc
               WHERE mbc.ProjectId = p.ProjectID
                     AND mbc.MilestoneCode = 'BE/Clin. or API Same Start'
           ) AS [BE Clin or API Same Start],
           (
               SELECT mbc.MilestoneStatus
               FROM @mtiCode mbc
               WHERE mbc.ProjectId = p.ProjectID
                     AND mbc.MilestoneCode = 'BE/Clin. or API Same Start'
           ) AS [BE Clin or API Same Start Status],
           (
               SELECT mba.EstimatedDate
               FROM @mtiCode mba
               WHERE mba.ProjectId = p.ProjectID
                     AND mba.MilestoneCode = 'BE/API Same. Results'
           ) AS [BE API Same Results],
           (
               SELECT mba.MilestoneStatus
               FROM @mtiCode mba
               WHERE mba.ProjectId = p.ProjectID
                     AND mba.MilestoneCode = 'BE/API Same. Results'
           ) AS [BE API Same Results Status],
           (
               SELECT mldr.EstimatedDate
               FROM @mtiCode mldr
               WHERE mldr.ProjectId = p.ProjectID
                     AND mldr.MilestoneCode = 'Last Doc. to RA'
           ) AS [Last Doc to RA],
           (
               SELECT mldr.MilestoneStatus
               FROM @mtiCode mldr
               WHERE mldr.ProjectId = p.ProjectID
                     AND mldr.MilestoneCode = 'Last Doc. to RA'
           ) AS [Last Doc to RA Status],
           STUFF(
           (
               SELECT DISTINCT ', ' + c.Name
               FROM pm.RawMaterialSupplierSource rms
                   JOIN pm.RawMaterialSupplier rm
                       ON rms.RawMaterialSupplierID = rm.RawMaterialSupplierID
                   JOIN dbo.tblCompany c
                       ON rm.SupplierID = c.CompanyID
                   JOIN dbo.tblCompanyLinkCompanyGroup clcg
                       ON c.CompanyID = clcg.CompanyID
                   JOIN dbo.tblCompanyGroup cg
                       ON clcg.CompanyGroupID = cg.CompanyGroupID
               WHERE p.ProjectID = rms.ProjectID
                     AND
                     (
                         cg.Text = 'API Manufacturer'
                         OR cg.Text = 'API Vendor'
                     )
               ORDER BY ', ' + c.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [API Manufacturer],
           p.EstFirstYearValueAsOfDate AS [Value as of Date],
           p.LatestFileDate AS [Comm. Latest Filing Date],
           p.GxMarketFormationDate AS [Comm. Generic Market Formation Date],
           p.ExpectedMylLaunchDate AS [Comm. Expected Launch Date],
           p.LaunchDateLogicComments AS [Launch Logic],
           vlf.Name AS [Launch Status],
           p.FocusNumber AS [ARVRating],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + c.Name
               FROM dbo.tblCompany c
                   JOIN pm.RawMaterialSupplier rms
                       ON rms.SupplierID = c.CompanyID
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN pm.RawMaterialSupplierSource rmss
                       ON rmss.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + c.Name
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS APISource,
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] '
                      + REPLACE(CONVERT(NVARCHAR(11), MAX(rmo.ActualDeliveryDate), 106), ' ', '-')
               FROM pm.RawMaterialSupplier rms
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN pm.RawMaterialSupplierSource rmss
                       ON rmss.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN pm.RawMaterialOrder rmo
                       ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN pm.RawMaterialOrderFulfillment rmof
                       ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               GROUP BY vki.Name,
                        vs.Name
               ORDER BY ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] '
                        + REPLACE(CONVERT(NVARCHAR(11), MAX(rmo.ActualDeliveryDate), 106), ' ', '-')
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [APIDeliveryDate],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] '
                      + REPLACE(CONVERT(NVARCHAR(11), MAX(rmo.TargetDeliveryDate), 106), ' ', '-')
               FROM pm.RawMaterialSupplierSource rmss
                   JOIN pm.RawMaterialOrderLinkRawMaterialSupplierSource link
                       ON link.RawMaterialSupplierSourceID = rmss.RawMaterialSupplierSourceID
                   JOIN pm.RawMaterialOrder rmo
                       ON rmo.RawMaterialOrderID = link.RawMaterialOrderID
                   JOIN pm.RawMaterialOrderFulfillment rmof
                       ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
                   JOIN pm.RawMaterialSupplier rms
                       ON rms.RawMaterialSupplierID = rmo.RawMaterialSupplierID
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               GROUP BY vki.Name,
                        vs.Name
               ORDER BY ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] '
                        + REPLACE(CONVERT(NVARCHAR(11), MAX(rmo.TargetDeliveryDate), 106), ' ', '-')
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [APITargetDeliveryDate],
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + bbs.StateName
               FROM pm.RawMaterialSupplier rms
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN pm.RawMaterialSupplierSource rmss
                       ON rmss.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN pm.RawMaterialOrderLinkRawMaterialSupplierSource link
                       ON link.RawMaterialSupplierSourceID = rmss.RawMaterialSupplierSourceID
                   JOIN pm.RawMaterialOrder rmo
                       ON rmo.RawMaterialOrderID = link.RawMaterialOrderID
                   JOIN dbo.tblBusinessBaseStates bbs
                       ON bbs.StateID = rmo.ValidRMRequestStatusID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + bbs.StateName
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS RawMaterialOrderStatus,
           STUFF(
           (
               SELECT DISTINCT
                      ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + vsd.NAME
               FROM pm.RawMaterialSupplier rms
                   JOIN pm.RawMaterial rm
                       ON rm.RawMaterialID = rms.RawMaterialID
                   JOIN pm.RawMaterialSupplierSource rmss
                       ON rmss.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN pm.RawMaterialOrder rmo
                       ON rmo.RawMaterialSupplierID = rms.RawMaterialSupplierID
                   JOIN dbo.tblValidSourceDecision vsd
                       ON vsd.ValidSourceDecisionID = rmss.ValidSourceDecisionID
                   JOIN pm.RawMaterialOrderFulfillment rmof
                       ON rmof.RawMaterialOrderID = rmo.RawMaterialOrderID
                   JOIN dbo.tblKPI kpi
                       ON kpi.KPIID = rm.KPIID
                   JOIN dbo.tblValidKeyIngredient vki
                       ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                   LEFT JOIN dbo.tblValidSalt vs
                       ON vs.ValidSaltID = kpi.ValidSaltID
               WHERE rmss.ProjectID = p.ProjectID
               ORDER BY ', ' + '[' + vki.Name + COALESCE(' ' + vs.Name, '') + '] ' + vsd.NAME
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS ValidAPISourceSelectionStatus,
           REPLACE(CONVERT(NVARCHAR(11), p.EvaluationDate, 106), ' ', '-') AS [ARVRatingAsOfDate],
           (
               SELECT MIN(   CASE
                                 WHEN m3.ReferenceMilestoneID IS NULL THEN
                                     m3.BestEstimateDate
                                 ELSE
                                     refm.BestEstimateDate
                             END
                         )
               FROM dbo.tblMilestone m3
                   JOIN pm.PivotalWorkstreamLinkProject pwlp
                       ON pwlp.PivotalWorkstreamID = m3.ObjectID
                          AND m3.BBOID = @PWBBOID
                          AND p.ProjectID = pwlp.ProjectID
                   JOIN pm.PivotalWorkstream pw
                       ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                   JOIN dbo.tblMilestoneTemplateItem mti3
                       ON mti3.MilestoneTemplateItemID = m3.MilestoneTemplateItemID
                          AND mti3.Code = 'PVW - Dosing Start'
                   LEFT JOIN dbo.tblMilestone refm
                       ON m3.ReferenceMilestoneID = refm.MileStoneID
               WHERE pw.MilestoneTemplateID = mti3.MilestoneTemplateID
           ) AS [Pivotal Dosing Date],
           (
               SELECT TOP (1)
                      vms.Name
               FROM dbo.tblMilestone m3
                   JOIN pm.PivotalWorkstreamLinkProject pwlp
                       ON pwlp.PivotalWorkstreamID = m3.ObjectID
                          AND m3.BBOID = @PWBBOID
                          AND p.ProjectID = pwlp.ProjectID
                   JOIN pm.PivotalWorkstream pw
                       ON pw.PivotalWorkstreamID = pwlp.PivotalWorkstreamID
                   JOIN dbo.tblMilestoneTemplateItem mti3
                       ON mti3.MilestoneTemplateItemID = m3.MilestoneTemplateItemID
                          AND mti3.Code = 'PVW - Dosing Start'
                   LEFT JOIN dbo.tblMilestone refm
                       ON m3.ReferenceMilestoneID = refm.MileStoneID
                   JOIN dbo.tblValidMilestoneStatus vms
                       ON COALESCE(refm.StatusID, m3.StatusID) = vms.ValidMilestoneStatusID
               WHERE pw.MilestoneTemplateID = mti3.MilestoneTemplateID
           ) AS [Pivotal Dosing Date Status],
           pat.Name AS [Aggrement Type],
           bcra.Name AS [BCRA Approval],
           bp.Name AS [Business Partner],
           p.EstFirstYearValue AS [Est. First Year Value(M)],
           p.Comments AS [Project General Comment],
           p.ProjectID AS Proj_ID,
           ynt.Name AS UseForMetrics,
           'Not Used' AS [TherapeuticFranchise],
                       --(
                       --    SELECT CASE
                       --               WHEN m.ReferenceMilestoneID IS NULL THEN
                       --                   m.BestEstimateDate
                       --               ELSE
                       --                   refm.BestEstimateDate
                       --           END
                       --    FROM dbo.tblMilestone m
                       --        JOIN dbo.tblMilestoneTemplateItem mti
                       --            ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                       --               AND mti.Code = 'Submission'
                       --        LEFT JOIN dbo.tblMilestone refm
                       --            ON refm.MileStoneID = m.MileStoneID
                       --    WHERE m.BBOID = @BBOID
                       --          AND m.ObjectID = p.ProjectID
                       --) AS CEESD,
           (
               SELECT TOP (1)
                      e.ImpactOnFilingDate
               FROM pm.LegalInfo li
                   JOIN pm.Exclusivity AS e
                       ON li.CountryID = e.CountryID
                          AND li.FormID = e.FormID
                   JOIN dbo.tblCountryLinkCountryGroup AS clcg
                       ON clcg.CountryID = li.CountryID
                   LEFT JOIN dbo.tblValidExclusivityType AS vet
                       ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
               WHERE e.ImpactOnFilingDate IS NOT NULL
                     AND li.FormID = f.FormID
                     AND ISNULL(vet.Category, '') <> 'MISEXCLUDE'
                     AND dbo.udf_UserHasPrivForCountryGroup(@UserId, @PrivCode, cg.CountryGroupID) = 'true'
                     AND
                     (
                         li.CountryID IN
                         (
                             SELECT CountryID FROM pm.ProjectLinkCountry WHERE ProjectID = p.ProjectID
                         )
                         OR li.CountryID IN
                            (
                                SELECT CountryID
                                FROM dbo.tblCountryLinkCountryGroup
                                WHERE CountryGroupID = p.CountryGroupID
                                      AND p.ProjectID NOT IN
                                          (
                                              SELECT ProjectID FROM pm.ProjectLinkCountry
                                          )
                            )
                     )
               ORDER BY e.ImpactOnFilingDate
           ) AS [Exclusivity Expiration (IP Impact on Filing Date)],
           STUFF(
           (
               SELECT ', ' + c.Code
               FROM dbo.tblCountry c
                   JOIN pm.ProjectLinkCountry plc
                       ON c.CountryID = plc.CountryID
               WHERE plc.ProjectID = p.ProjectID
               ORDER BY ', ' + c.Code
               FOR XML PATH('')
           ),
           1,
           2,
           ''
                ) AS [Country Codes],
           (
               SELECT COUNT(c.CountryID)
               FROM dbo.tblCountry c
                   JOIN pm.ProjectLinkCountry plc
                       ON c.CountryID = plc.CountryID
               WHERE plc.ProjectID = p.ProjectID
           ) AS [Country Count]
    FROM pm.Project p
        JOIN dbo.tblForm f
            ON p.FormID = f.FormID
        JOIN dbo.tblValidForm vf
            ON vf.ValidFormID = f.ValidFormID
        JOIN dbo.tblValidVertical vv
            ON vv.ValidVerticalID = f.ValidVerticalID
        JOIN dbo.tblProduct prod
            ON f.ProductID = prod.ProductID
        LEFT JOIN dbo.tblValidReleaseMechanism VRM
            ON VRM.ValidReleaseMechanismID = f.ValidReleaseMechanismID
        LEFT JOIN dbo.tblValidTherapeuticArea vta
            ON vta.ValidTherapeuticAreaID = f.ValidTherapeuticAreaID
        LEFT JOIN pm.ProjectTag pt
            ON pt.ProjectID = p.ProjectID
        LEFT JOIN dbo.tblValidBBOTag bt
            ON pt.ValidBBOTagID = bt.ValidBBOTagID
        LEFT JOIN dbo.admin_SecUser con
            ON p.ProjectLeadID = con.UserID
        LEFT JOIN dbo.tblCountryGroup cg
            ON p.CountryGroupID = cg.CountryGroupID
        LEFT JOIN dbo.tblValidProjectType vpt
            ON p.ValidProjectTypeID = vpt.ValidProjectTypeID
        LEFT JOIN dbo.tblValidProjectOppType vot
            ON p.ValidOpportunityTypeID = vot.ValidProjectOppTypeID
        LEFT JOIN dbo.tblBusinessBaseStates bbs
            ON p.ProjectStatusID = bbs.StateID
        LEFT JOIN pm.DevWorkstreamLinkProject dwlp
            ON p.ProjectID = dwlp.ProjectID
        LEFT JOIN pm.TradeDressWorkstreamLinkProject tdwlp
            ON p.ProjectID = tdwlp.ProjectID
        LEFT JOIN dbo.tblCompany pk
            ON p.PackagingSiteID = pk.CompanyID
        LEFT JOIN dbo.admin_SecUser u
            ON p.LegalLeadID = u.UserID
        LEFT JOIN dbo.tblBrand brnd
            ON p.BrandID = brnd.BrandID
        LEFT JOIN dbo.tblValidTechOpsRating tor
            ON p.ValidTechOpsRatingID = tor.ValidTechOpsRatingID
        LEFT JOIN dbo.tblCompany bp
            ON p.BusinessPartnerID = bp.CompanyID
        LEFT JOIN dbo.tblValidProjectAgreementType pat
            ON p.ProjectAgreementTypeID = pat.ValidProjectAgreementTypeID
        LEFT JOIN dbo.tblBCRASession bcra
            ON p.BCRASessionID = bcra.BCRASessionID
        LEFT JOIN dbo.tblValidLaunchFlag vlf
            ON p.ValidLaunchFlagID = vlf.ValidLaunchFlagID
        LEFT JOIN pm.PRBSession prb
            ON p.PRBApprovalSessionID = prb.PRBSessionID
        LEFT JOIN dbo.tblValidYesNoTBD ynt
            ON ynt.ValidYesNoTBDID = p.UseForMetricsID
    WHERE EXISTS
    (
        SELECT 1 FROM @tmp_ID WHERE id = p.ProjectID
    );
END;
GO
