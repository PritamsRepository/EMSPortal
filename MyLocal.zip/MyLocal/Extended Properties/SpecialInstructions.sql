EXEC sp_addextendedproperty N'SpecialInstructions', N'Special Instructions', NULL, NULL, NULL, NULL, NULL, NULL
GO
