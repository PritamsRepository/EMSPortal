SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/*------------------------------------------------------------------------------------------------------------------------
CREATE DATE: 6/21/2010
Changed By:  Robin Abramson
Purpose: Return all strengths with equivs for a form ID
------------------------------------------------------------------------------------------------------------------------*/
CREATE FUNCTION [dbo].[udf_StrengthListByFormID_StrengthID_WithAlias]
(
    @FormID INT,
    @StrengthID INT
)
RETURNS NVARCHAR(2000)
WITH SCHEMABINDING
AS
BEGIN

    DECLARE @StrengthList NVARCHAR(2000);

    SELECT @StrengthList = STUFF(
                           (
                               SELECT ',  ' + s.[Name]
                               FROM dbo.tblStrength s
                               WHERE s.[FormID] = @FormID
                                     AND s.StrengthID = @StrengthID
                                     AND s.[IsUndefined] = 'false'
                               FOR XML PATH('')
                           ),
                           1,
                           2,
                           ''
                                );


    RETURN (@StrengthList);

END;
GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListByFormID_StrengthID_WithAlias] TO [mp_db_execute]
GO
