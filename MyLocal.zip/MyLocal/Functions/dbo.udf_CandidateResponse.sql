SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_CandidateResponse]
    (
      @CandidateID INT ,
      @CountryGroupID INT
    )
RETURNS NVARCHAR(MAX)
AS
    BEGIN
        DECLARE @Response NVARCHAR(MAX) = NULL
        SET @Response = ( SELECT TOP 1
                                    vr.Name
                          FROM      pm.ProductProposal p
                                    JOIN dbo.tblValidResponse vr ON vr.ValidResponseID = p.ValidResponseID
                          WHERE     p.CandidateID = @CandidateID
                                    AND p.CountryGroupID = @CountryGroupID
                        )
        RETURN @Response
    END
GO
