SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[ApplicationPaediatricUseIndicatorIDFromMAs]
(
    @MAApplicationID INT
)
RETURNS INT
AS
BEGIN
    DECLARE @PaediatricUseIndicatorID INT = NULL;

    -- If at least one of the MAs is set to ‘Yes’ then ‘Yes’ should display at the Application level.
    -- IF no MAs = ‘Yes’ but there is at least one of the MAs = ‘No’ then ‘No’ should display at the Application level
    -- IF all MAs are set to the default ‘None’ than ‘None; should display at the Application Level
    SELECT @PaediatricUseIndicatorID = yn.ValidYesNoTBDID
    FROM dbo.tblValidYesNoTBD yn
        JOIN dbo.tblMALicense mal
            ON mal.PaediatricUseIndicatorID = yn.ValidYesNoTBDID
    WHERE mal.MAApplicationID = @MAApplicationID
    ORDER BY yn.DisplayOrder;

    RETURN @PaediatricUseIndicatorID;
END;
GO
