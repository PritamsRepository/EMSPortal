SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_MALicense_GetPackagingList] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS

BEGIN

  DECLARE @Scope TABLE
  (
	ID INT IDENTITY(1, 1),
	MALicenseID INT,
	ScopeType NVARCHAR(256),
	FormName NVARCHAR(256),
	StrengthName NVARCHAR(256),
	PackType NVARCHAR(256),
	PackageSize NVARCHAR(256),
	IsDeregistered BIT
  );

  INSERT INTO @Scope
  (
	MALicenseID,
	ScopeType,
	--FormName,
	--StrengthName,
	PackType,
	PackageSize,
	IsDeregistered
  )
  SELECT
	mal.MALicenseID,
	st.Name AS ScopeType,
	--f.Name AS FormName,
	--s.Name AS StrengthName,
	(CASE WHEN LEN(vpt.Name) > 0 THEN vpt.Name ELSE NULL END) AS PackType,
	(CASE WHEN LEN(masp.PackageSize) > 0 THEN masp.PackageSize ELSE NULL END) AS PackageSize,
	(CASE WHEN vss.Name = 'Deregistered' THEN 1 ELSE NULL END) AS IsDeregistered
  FROM
	dbo.tblMALicense mal
	  JOIN dbo.tblValidMALicenseScopeType st ON mal.ValidMALicenseScopeTypeID = st.ValidMALicenseScopeTypeID
	  JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
	  JOIN dbo.tblValidScopeStatus vss ON mals.ValidScopeStatusID = vss.ValidScopeStatusID
	  JOIN dbo.tblMAStrength mas ON mals.MAStrengthID = mas.MAStrengthID
	  JOIN dbo.tblStrength s ON mas.StrengthID = s.StrengthID
	  JOIN dbo.tblForm f ON s.FormID = f.FormID    
	  LEFT JOIN dbo.tblMaStrengthPackage masp ON mals.MaStrengthPackageID = masp.MAStrengthPackageID
	  LEFT JOIN dbo.tblValidMAPackType vpt ON masp.ValidPackagingTypeID = vpt.ValidMAPackTypeID
  WHERE
	mal.MALicenseID = @MALicenseID
  ORDER BY
	--f.Name,
	--s.Name,
	vpt.Name,
	masp.PackageSize;

  DECLARE @CurrentID INT = 1;
  DECLARE @Result TABLE 
  (
	Product NVARCHAR(500),
	IsDeregistered BIT
  );

  DECLARE
	@IsDeregistered BIT,
	@ScopeType NVARCHAR(256),
	--@FormName NVARCHAR(256),
	--@StrengthName NVARCHAR(256),	
	@PackageType NVARCHAR(256),
	@PackageSize NVARCHAR(256),
	@Packaging NVARCHAR(500);

  WHILE (@CurrentID <= (SELECT MAX(ID) FROM @Scope))
  BEGIN
	SELECT
	  @ScopeType = ScopeType,
	  --@FormName = COALESCE(FormName, 'N/A'),
	  --@StrengthName = COALESCE(StrengthName, 'N/A'),
	  @PackageType = PackType,
	  @PackageSize = PackageSize,
	  @IsDeregistered = IsDeregistered
	FROM
	  @Scope
	WHERE
	  ID = @CurrentID;
	
	IF (@ScopeType LIKE '%Size%')
	BEGIN
	  SET @PackageType = COALESCE(@PackageType, 'N/A');
	  SET @PackageSize = COALESCE(@PackageSize, 'N/A');
	  	
	  SET @Packaging = (@PackageType + ' (' + @PackageSize + ')');
	END
	ELSE IF (LEN(@PackageType) > 0)
	  SET @Packaging = (@PackageType + ' (All)');
	ELSE BEGIN
	  SET @Packaging = 'All';
	END

	INSERT INTO @Result
	(
	  Product, 
	  IsDeregistered
	)
	VALUES
	(
	    @Packaging ,
	  @IsDeregistered
	);

	SET @CurrentID = (@CurrentID + 1);
  END

  DECLARE @Delimited AS NVARCHAR(1000);
  SELECT  
	--@Delimited = (COALESCE((@Delimited + '|'), '') + Result)
	@Delimited = (COALESCE((@Delimited + '|'), '') + (r.Product + (CASE WHEN COUNT(Product) = COUNT(IsDeregistered) THEN '**' ELSE '' END)))
  FROM
	@Result r
  GROUP BY
	r.Product;

  RETURN @Delimited;
END
GO
