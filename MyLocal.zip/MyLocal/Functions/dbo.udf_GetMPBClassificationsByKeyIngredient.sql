SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_GetMPBClassificationsByKeyIngredient] ( @ValidKeyIngredientID INT )
RETURNS NVARCHAR(MAX) WITH SCHEMABINDING
AS
BEGIN

	RETURN
		LTRIM(STUFF(( SELECT   
								('|' + COALESCE(pec.NAME, '[None]') + ' - ' + vki.Name)
                      FROM      dbo.tblForm f1
                                JOIN dbo.tblProductLinkKPI AS plk ON f1.productID = plk.ProductID
                                JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                                JOIN dbo.tblvalidkeyingredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                                LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                      WHERE     vki.ValidKeyIngredientID = @ValidKeyIngredientID
                      GROUP BY pec.Name, vki.Name
                      ORDER BY  ('|' + pec.Name + ' - ' + vki.Name) DESC
                    FOR
                      XML PATH('')
                    ), 1, 1, ''))

END

GO
