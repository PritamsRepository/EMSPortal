SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_FirstUpdatedOn] ( 
	@BBOCode nvarchar(10),
	@ObjectID int)
RETURNS datetime
AS

BEGIN

DECLARE @ReturnDate datetime


SELECT TOP 1
	@ReturnDate= a.[Date]
FROM
	[dbo].[tblBusinessBaseObjectStateActions] AS a
	JOIN [dbo].[tblBusinessBaseObject] AS bbo ON bbo.[BBOID] = a.[BBOID]
WHERE
	bbo.[BBOCode] = @BBOCode AND
	a.[ObjectID] = @ObjectID
ORDER BY
	a.[Date] ASC

RETURN @ReturnDate

END




GO
GRANT EXECUTE ON  [dbo].[udf_FirstUpdatedOn] TO [mp_db_execute]
GO
