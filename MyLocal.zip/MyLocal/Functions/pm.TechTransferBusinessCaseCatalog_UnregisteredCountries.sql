SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [pm].[TechTransferBusinessCaseCatalog_UnregisteredCountries]
(
    @TechTransferBusinessCaseCatalogID INT
)
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @Countries NVARCHAR(MAX);

    IF NOT EXISTS
    (
        SELECT 1
        FROM pm.TechTransferBusinessCaseCatalog ttbcc
            JOIN dbo.tblValidSNCSiteType vscst
                ON vscst.ValidSNCSiteTypeID = ttbcc.ValidSNCSiteTypeID
            JOIN dbo.tblValidSiteType vst
                ON vst.Name = vscst.Category
        WHERE ttbcc.TechTransferBusinessCaseCatalogID = @TechTransferBusinessCaseCatalogID
    )
        SET @Countries = N'N/A';
    ELSE
    BEGIN
        DECLARE @count1 INT =
                (
                    SELECT COUNT(*)
                    FROM dbo.tblCountry c
                        JOIN rim.ApplicationLinkCountry sncc
                            ON sncc.CountryID = c.CountryID
                        JOIN pm.TechTransferBusinessCaseLinkRimApplication link
                            ON link.MAApplicationID = sncc.MAApplicationID
                        JOIN pm.TechTransferBusinessCaseCatalog sncwc
                            ON sncwc.TechTransferBusinessCaseID = link.TechTransferBusinessCaseID
                        JOIN pm.TechTransferBusinessCase snc
                            ON snc.TechTransferBusinessCaseID = link.TechTransferBusinessCaseID
                        JOIN dbo.tblValidSNCSiteType vscst
                            ON vscst.ValidSNCSiteTypeID = sncwc.ValidSNCSiteTypeID
                        JOIN dbo.tblCompany cmp
                            ON sncwc.SiteID = cmp.CompanyID
                    WHERE sncwc.TechTransferBusinessCaseCatalogID = @TechTransferBusinessCaseCatalogID
                          AND sncwc.SiteID NOT IN
                              (
                                  --SELECT rrs.SiteID
                                  --FROM rim.RimRegisteredSite rrs
                                  --    JOIN pm.TechTransferBusinessCaseLinkRimApplication link
                                  --        ON rrs.ApplicationID = link.MAApplicationID
                                  --    JOIN rim.ApplicationLinkCountry alc
                                  --        ON alc.MAApplicationID = link.MAApplicationID
                                  --WHERE link.TechTransferBusinessCaseID = snc.TechTransferBusinessCaseID
                                  --      AND vscst.Name = rrs.SiteType
                                  --      AND alc.CountryID = c.CountryID

                                  SELECT rs.SiteID
                                  FROM pm.TechTransferBusinessCaseLinkRimApplication link
                                      JOIN rim.RimRegisteredSite rs
                                          ON rs.ApplicationID = link.MAApplicationID
                                      JOIN rim.ApplicationLinkCountry alc
                                          ON alc.MAApplicationID = link.MAApplicationID
                                      JOIN dbo.tblValidSiteType vst2
                                          ON vst2.Category = rs.SiteType
                                      LEFT JOIN config.RIM_MyP_SiteTypeMap stm
                                          ON LTRIM(RTRIM(rs.SiteType)) = stm.RIMSiteType
                                      LEFT JOIN dbo.tblCompany c1
                                          ON rs.SiteID = c1.CompanyID
                                  WHERE link.TechTransferBusinessCaseID = snc.TechTransferBusinessCaseID
                                        AND alc.CountryID = c.CountryID
                                        AND
                                        (
                                            (
                                                rs.SiteID = cmp.CompanyID
                                                AND vst2.Category = vst2.Name
                                            )
                                            OR
                                            (
                                                c1.CompanyID = cmp.CompanyID
                                                AND stm.MyPSiteType = vst2.Name
                                            )
                                        )
                              )
                );
        DECLARE @count2 INT =
                (
                    SELECT COUNT(*)
                    FROM rim.ApplicationLinkCountry sncwlc
                        JOIN pm.TechTransferBusinessCaseLinkRimApplication link
                            ON link.MAApplicationID = sncwlc.MAApplicationID
                        JOIN pm.TechTransferBusinessCaseCatalog snccat
                            ON snccat.TechTransferBusinessCaseID = link.TechTransferBusinessCaseID
                    WHERE snccat.TechTransferBusinessCaseCatalogID = @TechTransferBusinessCaseCatalogID
                );
        IF (@count1 = @count2)
            SET @Countries = N'All';
        ELSE
            SELECT @Countries = STUFF(
                                (
                                    SELECT DISTINCT
                                           ', ' + c.Code
                                    FROM dbo.tblCountry c
                                        JOIN rim.ApplicationLinkCountry sncc
                                            ON sncc.CountryID = c.CountryID
                                        JOIN pm.TechTransferBusinessCaseLinkRimApplication link
                                            ON link.MAApplicationID = sncc.MAApplicationID
                                        JOIN pm.TechTransferBusinessCaseCatalog sncwc
                                            ON sncwc.TechTransferBusinessCaseID = link.TechTransferBusinessCaseID
                                        JOIN pm.TechTransferBusinessCase snc
                                            ON snc.TechTransferBusinessCaseID = link.TechTransferBusinessCaseID
                                        JOIN dbo.tblValidSNCSiteType vscst
                                            ON vscst.ValidSNCSiteTypeID = sncwc.ValidSNCSiteTypeID
                                        JOIN dbo.tblCompany cmp
                                            ON sncwc.SiteID = cmp.CompanyID
                                    WHERE sncwc.TechTransferBusinessCaseCatalogID = @TechTransferBusinessCaseCatalogID
                                          AND sncwc.SiteID NOT IN
            (
                --SELECT SiteID
                --FROM rim.RimRegisteredSite rrs
                --    JOIN pm.TechTransferBusinessCaseLinkRimApplication link
                --        ON rrs.ApplicationID = link.MAApplicationID
                --    JOIN rim.ApplicationLinkCountry alc
                --        ON alc.MAApplicationID = link.MAApplicationID
                --WHERE link.TechTransferBusinessCaseID = snc.TechTransferBusinessCaseID
                --      AND vscst.Name = rrs.SiteType
                --      AND alc.CountryID = c.CountryID





                SELECT rs.SiteID
                FROM pm.TechTransferBusinessCaseLinkRimApplication link
                    JOIN rim.RimRegisteredSite rs
                        ON rs.ApplicationID = link.MAApplicationID
                    JOIN rim.ApplicationLinkCountry alc
                        ON alc.MAApplicationID = link.MAApplicationID
                    JOIN dbo.tblValidSiteType vst2
                        ON vst2.Category = rs.SiteType
                    LEFT JOIN config.RIM_MyP_SiteTypeMap stm
                        ON LTRIM(RTRIM(rs.SiteType)) = stm.RIMSiteType
                    LEFT JOIN dbo.tblCompany c1
                        ON rs.SiteID = c1.CompanyID
                WHERE link.TechTransferBusinessCaseID = snc.TechTransferBusinessCaseID
                      AND alc.CountryID = c.CountryID
                      AND
                      (
                          (
                              rs.SiteID = cmp.CompanyID
                              AND vst2.Category = vst2.Name
                          )
                          OR
                          (
                              c1.CompanyID = cmp.CompanyID
                              AND stm.MyPSiteType = vst2.Name
                          )
                      )
            )
                                    ORDER BY ', ' + c.Code
                                    FOR XML PATH('')
                                ),
                                1,
                                2,
                                ''
                                     );
    END;
    RETURN @Countries;
END;
GO
