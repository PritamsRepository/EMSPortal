SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[udf_ProposalRDCostByCandidateID] ( @CandidateID INT )
RETURNS DECIMAL(20, 5)
AS 
    BEGIN 
        DECLARE @sum DECIMAL(20, 5)
        DECLARE @apisum DECIMAL(20, 5)
		
        SELECT  @sum = SUM(ISNULL(prop.RDBiostudyCost, 0)
                           + ISNULL(prop.RDOverheadCost, 0)
                           + ISNULL(prop.RDRegulatoryCost, 0)
                           + ISNULL(prop.ClinicalCost, 0)
                           + ISNULL(prop.ZoneIVCosts, 0)
                           + ISNULL(prop.RDOtherCost, 0))
        FROM    pm.ProductProposal prop
                JOIN pm.Candidate can ON can.CandidateID = prop.CandidateID
        WHERE   can.CandidateID = @CandidateID

        SELECT  @apisum = SUM(( ISNULL(api.CostPerUnit / 1000000, 0)
                                * ISNULL(api.NumOfUnits, 0) ))
        FROM    pm.ProductProposalAPI api
				JOIN pm.ProductProposal prop ON prop.ProductProposalID = api.ProductProposalID
                JOIN pm.Candidate can ON can.CandidateID = prop.CandidateID
        WHERE   can.CandidateID = @CandidateID

        RETURN @sum + @apisum
    END 
GO
