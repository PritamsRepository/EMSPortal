SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_EHSAlert_Table]
    (
      @ProductID INT = NULL ,
      @RMID INT = NULL
    )
RETURNS TABLE
WITH SCHEMABINDING
AS 
RETURN
    SELECT  'OEB' AS [Alert]
    FROM    dbo.tblProductLinkKPI plk
            LEFT JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
            LEFT JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN pm.RawMaterial rm ON rm.KPIID = kpi.KPIID
            LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
    WHERE   ( plk.ProductID = @ProductID
              OR ( rm.RawMaterialID = @RMID
                   AND @RMID IS NOT NULL
                 )
            )
            AND pec.Category = 'EHS Alert'
    UNION
    SELECT  'Drug Class'
    FROM    dbo.tblProductLinkKPI plk
            LEFT JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
            LEFT JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN pm.RawMaterial rm ON rm.KPIID = kpi.KPIID
            LEFT JOIN dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc ON vkilvdc.ValidKeyIngredientID = vki.ValidKeyIngredientID
            LEFT JOIN dbo.tblValidDrugClassification vdc ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
    WHERE   ( plk.ProductID = @ProductID
              OR ( rm.RawMaterialID = @RMID
                   AND @RMID IS NOT NULL
                 )
            )
            AND vdc.Category = 'EHS Alert'
    UNION
    SELECT  'API Controlled'
    FROM    dbo.tblProductLinkKPI plk
            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
            JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            JOIN dbo.ValidKeyIngredientLinkValidDeaControlledSchedule vkilvdcs ON vkilvdcs.ValidKeyIngredientID = vki.ValidKeyIngredientID
            LEFT JOIN pm.RawMaterial rm ON rm.KPIID = kpi.KPIID
    WHERE   ( plk.ProductID = @ProductID
              OR ( rm.RawMaterialID = @RMID
                   AND @RMID IS NOT NULL
                 )
            ) 
GO
