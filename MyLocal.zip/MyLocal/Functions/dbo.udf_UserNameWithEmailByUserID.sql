SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_UserNameWithEmailByUserID] (
	@UserID int)
RETURNS nvarchar(256)
AS

BEGIN


DECLARE @FullNameWithEmail as nvarchar(256), @EMailAddress NVARCHAR(128), @FullName NVARCHAR(128), @ADUserName NVARCHAR(128)

SET @FullNameWithEmail=''
SET @EMailAddress=null

SELECT

		@EMailAddress=ISNULL('<a href="mailto:' + su.[EmailAddress] + '">',''),
		@FullName=su.[FullName],
		@ADUserName=su.ADUserName
		 
	FROM
		[dbo].[admin_SecUser] as su
	WHERE
		su.[UserID] = @UserID
		
IF (LEN(@EMailAddress)>2)
	BEGIN
	
		SET @FullNameWithEmail = @EMailAddress + @FullName + '</a>'
		
	END
	
ELSE IF (@FullName IS NULL)
	BEGIN
		
		SET @FullNameWithEmail=@ADUserName
	END	

ELSE 	

	BEGIN
		
		SET @FullNameWithEmail=@FullName
	END	
	
RETURN @FullNameWithEmail


END


GO
GRANT EXECUTE ON  [dbo].[udf_UserNameWithEmailByUserID] TO [mp_db_execute]
GO
