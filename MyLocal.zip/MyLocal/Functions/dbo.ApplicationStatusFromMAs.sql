SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[ApplicationStatusFromMAs]
(
    @MAApplicationID INT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @Status NVARCHAR(MAX) = NULL;

    SELECT @Status = Name
    FROM dbo.tblValidApplicationStatus
    WHERE ValidApplicationStatusID = [dbo].[ApplicationStatusIDFromMAs](@MAApplicationID);

    RETURN @Status;
END;
GO
