SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_GetCountryOrHA] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @Data TABLE
  (
	ID INT IDENTITY(1, 1),
	HealthAuthority nvarchar(256),
	CountryCode nvarchar(256)
  );

  INSERT INTO @Data
  (
	HealthAuthority,
	CountryCode
  )
  SELECT DISTINCT
	ha.ShortName,
	sc.Code
  FROM
	dbo.tblMALicense mal
	  JOIN dbo.tblMAApplication maa ON mal.MAApplicationID = maa.MAApplicationID  
	  JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID		
	  LEFT JOIN dbo.tblCountry sc ON mals.CountryID = sc.CountryID    
  	
	  LEFT JOIN dbo.tblCompany ha ON maa.HealthAuthorityID = ha.CompanyID
	  LEFT JOIN dbo.tblCountry hac ON ha.CountryID = hac.CountryID
  WHERE
	mal.MALicenseID = @MALicenseID

  DECLARE @Result NVARCHAR(256);
  IF ((SELECT COUNT(ID) FROM @Data) > 1)
  BEGIN
	SET @Result = (SELECT TOP(1) HealthAuthority FROM @Data);
  END
  ELSE BEGIN
	SET @Result = (SELECT TOP(1) CountryCode FROM @Data);
  END

  RETURN @Result;

END


GO
GRANT EXECUTE ON  [dbo].[udf_GetCountryOrHA] TO [mp_db_execute]
GO
