SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_NoneIfNullOrEmpty] (@Value SQL_VARIANT)
RETURNS SQL_VARIANT

AS
BEGIN

  DECLARE @Temp AS NVARCHAR(MAX) = CAST(@Value AS NVARCHAR);
  
  IF(@Temp IS NULL OR LEN(@Temp) = 0) SET @Value = '[None]';
  
  --ISNULL(NULLIF(@Value, '[None]'), @Value)

  --RETURN ISNULL(NULLIF(@Value, '[None]'), @Value);
  RETURN @Value;
   
END

GO
GRANT EXECUTE ON  [dbo].[udf_NoneIfNullOrEmpty] TO [mp_db_execute]
GO
