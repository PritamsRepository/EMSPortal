SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_AccessibleRimApplications]
(
    @UserID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
           maa.*
    FROM rim.RimApplication maa
        JOIN rim.ApplicationLinkCountry lc
            ON lc.MAApplicationID = maa.MAApplicationID
        JOIN dbo.udf_UserHasPrivForCountry_TableValued(@UserID, 'MA01') p
            ON lc.CountryID = p.CountryID
               AND p.Privs = 1
);
GO
