SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE FUNCTION [dbo].[udf_StrengthListForBrand] (@FormID INT, @CountryID INT)
RETURNS NVARCHAR(2000)
AS
BEGIN

		DECLARE @StrengthList NVARCHAR(2000)

		SELECT @StrengthList = COALESCE(@StrengthList + ', ', '') + s.Name
		FROM 
			tblBrand b
				INNER JOIN tblBrandStrengthMarketing bsm ON bsm.BrandID = b.BrandID
				INNER JOIN tblStrength s ON s.StrengthID = bsm.StrengthID

		WHERE 
			b.FormID = @FormID AND b.CountryID = @CountryID
		ORDER BY
			s.Name
			
	RETURN @StrengthList
END


GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListForBrand] TO [mp_db_execute]
GO
