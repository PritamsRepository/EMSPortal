SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_ConvertCurrencyToText] (@FromAmt decimal(19,4), @FromValidCurrencyID int, @ToValidCurrencyID int, @ToEffectiveDate datetime)
RETURNS nvarchar(256)
AS

BEGIN

	DECLARE @ConversionFactor2USD decimal(12,4)
	DECLARE @ToAmt decimal(19,4)
	DECLARE @ReturnAmt nvarchar(256)
	SET @ConversionFactor2USD = 0.0
	SET @ToAmt = 0.0
	SET @ReturnAmt = '#ERROR#'

	IF @FromValidCurrencyID = @ToValidCurrencyID
	-- No need to convert, just send back the original amount.
	BEGIN
		SET @ReturnAmt = CAST(CAST(ROUND(@FromAmt, 0) AS decimal(17,0)) AS nvarchar(256))
		RETURN(@ReturnAmt)
	END

	SELECT TOP 1
		@ConversionFactor2USD = er.ConversionFactor2USD
	FROM
		tblExchangeRate er
			INNER JOIN tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
	WHERE
		er.ValidCurrencyID = @FromValidCurrencyID AND
		erl.EffectiveDate = @ToEffectiveDate
	ORDER BY
		erl.EffectiveDate

	IF @@ROWCOUNT > 0
	BEGIN
		SET @ToAmt = @FromAmt * @ConversionFactor2USD

		SELECT TOP 1
			@ConversionFactor2USD = er.ConversionFactor2USD
		FROM
			tblExchangeRate er
				INNER JOIN tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
		WHERE
			er.ValidCurrencyID = @ToValidCurrencyID AND
			erl.EffectiveDate = @ToEffectiveDate
		ORDER BY
			erl.EffectiveDate

		IF @@ROWCOUNT > 0
		BEGIN
			-- Format the returned text value as rounded to the nearest two decimal places.
			SET @ReturnAmt = CAST(CAST(ROUND(@ToAmt * @ConversionFactor2USD, 0) AS decimal(17,0)) AS nvarchar(256))
		END
	END

	RETURN(@ReturnAmt)

END



GO
GRANT EXECUTE ON  [dbo].[udf_ConvertCurrencyToText] TO [mp_db_execute]
GO
