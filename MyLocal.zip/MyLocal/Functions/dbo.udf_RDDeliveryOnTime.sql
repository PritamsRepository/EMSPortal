SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_RDDeliveryOnTime] (@RDEstimatedFileDate DATETIME, @MylanLatestFileDate DATETIME)
RETURNS nvarchar(256)
AS

BEGIN

	DECLARE @ReturnStr nvarchar(256)

	IF @RDEstimatedFileDate IS NULL OR @MylanLatestFileDate IS NULL
		BEGIN
			SET @ReturnStr = '-'
		END
	ELSE
		IF @RDEstimatedFileDate <= @MylanLatestFileDate
			BEGIN
				SET @ReturnStr = 'Yes'
			END
		ELSE
			BEGIN
				SET @ReturnStr = 'No'
			END

		RETURN(@ReturnStr)

END


GO
GRANT EXECUTE ON  [dbo].[udf_RDDeliveryOnTime] TO [mp_db_execute]
GO
