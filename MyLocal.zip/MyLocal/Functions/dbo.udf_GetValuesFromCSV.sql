SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_GetValuesFromCSV] (
		@Source nvarchar(MAX))	
RETURNS @temptable TABLE (id int)

AS

BEGIN
	DECLARE @Target INT
	DECLARE @Length INT = 0
	DECLARE	@Result INT = 0
	
	WHILE(LEN(@Source) > 0)
	BEGIN
		IF PATINDEX('%,%',@Source) > 0
        BEGIN
	    	SET @Target = SUBSTRING(@Source, 0, PATINDEX('%,%', @Source))
		    SET @Source = LTRIM(RTRIM(SUBSTRING(@Source, LEN(@Target) + 2, LEN(@Source))))
		    --IF (@Target != ' ')
    			INSERT INTO @temptable(id) VALUES (@Target)
		END
		ELSE
		BEGIN
			SET @Target = @Source
			SET @Source = NULL
			--IF (@Target != ' ')
				INSERT INTO @temptable(id) VALUES (@Target)
		END
	END
	RETURN
END
GO
