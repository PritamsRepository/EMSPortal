SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE FUNCTION [dbo].[udf_convertForecastVolumeByProposalID]
    (
    )
RETURNS @ForecastVolumes TABLE
    (
      ProposalID INT,
      TotalAmount DECIMAL(19, 4)
    )

 /*********************************************************
Function to return a table containing forecastvolumes for
proposallist.

CREATED BY:	Robin Abramson
CREATE DATE:	8/19/2010

USAGE: select * FROM dbo.udf_convertForecastVolumeByProposalID ()

***********************************************************/
AS BEGIN
    DECLARE @ForecastVolume TABLE
        (
          ProposalID INT,
          [ForecastTurnover] DECIMAL(19, 4),
          FromValidCurrencyID INT,
          ToValidCurrencyID INT,
          PRBSessionID INT,
          ExRateLoadID INT,
          [ConversionFactor2USD] DECIMAL(19, 4),
          ForecastYear INT,
          ForecastTotal DECIMAL(19, 4)
        )


    INSERT  @ForecastVolume
            (
              [ProposalID],
              [ForecastTurnover],
              [FromValidCurrencyID],
              [ToValidCurrencyID],
              [ForecastYear]

            )
            SELECT  p.[ProposalID],
                    SUM(sf.[ForecastTurnover]),
                    sf.[ValidCurrencyID],
                    p.[ValidCurrencyID],
                    sf.[ForecastYear]
            FROM    [dbo].[tblProposalSalesForecast] AS sf
                    JOIN [dbo].[tblProposalCountryInterest] AS ci ON ci.[PCountryInterestID] = sf.[PCountryInterestID]
                    JOIN [dbo].[tblCountryLinkCountryGroup] AS clcg ON clcg.[CountryID] = ci.[CountryID]
                    JOIN [dbo].[tblProposal] AS p ON p.[ProposalID] = ci.[ProposalID]
            WHERE   p.[MarketCountryGroupID] = clcg.[CountryGroupID]
            GROUP BY p.[ProposalID],
                    sf.[ValidCurrencyID],
                    p.[ValidCurrencyID],
                    sf.[ForecastYear]
            ORDER BY p.[ProposalID],
                    [ForecastYear]
        
    UPDATE  @ForecastVolume
    SET     [ConversionFactor2USD] = 1
    WHERE   [FromValidCurrencyID] = [ToValidCurrencyID]
 
    UPDATE  [fv]
    SET     [PRBSessionID] = ps.PRBSessionID,
            [ExRateLoadID] = ps.[ExRateLoadID]
    FROM    @ForecastVolume AS fv
            JOIN dbo.[tblProposal] AS p2 ON [fv].[ProposalID] = [p2].[ProposalID]
            JOIN dbo.[tblCandidate] AS c ON c.[CandidateID] = p2.[CandidateID]
            JOIN dbo.[tblPRBSession] AS ps ON c.[TargetPRBSessionID] = ps.[PRBSessionID]
 
    UPDATE  [fv]
    SET     [ForecastTotal] = fv2.Amt
    FROM    @ForecastVolume AS fv
            JOIN ( SELECT   SUM([ForecastTurnover]) AS Amt,
                            [ForecastYear],
                            ProposalID
                   FROM     @ForecastVolume
                   WHERE    [FromValidCurrencyID] = 1
                            AND [ToValidCurrencyID] = 1
                   GROUP BY [ForecastYear],
                            [ProposalID]
                 ) AS fv2 ON [fv].[ProposalID] = [fv2].[ProposalID]
                             AND fv.[ForecastYear] = fv2.ForecastYear



    UPDATE  @ForecastVolume
    SET     [ForecastTotal] = [dbo].[udf_ConvertCurrencyByExRateLoad]([ExRateLoadID], [ForecastTurnover], [FromValidCurrencyID], [ToValidCurrencyID])
    WHERE   ( [FromValidCurrencyID] <> 1
              OR [ToValidCurrencyID] <> 1
            )
            --AND [ExRateLoadID] IS NOT NULL
 
 
    --UPDATE  @ForecastVolume
    --SET     [ForecastTotal] = [dbo].[udf_ConvertCurrencyByExRateLoad]([ExRateLoadID], [ForecastTurnover], [FromValidCurrencyID], [ToValidCurrencyID])
    --WHERE   ( [FromValidCurrencyID] <> 1
    --          OR [ToValidCurrencyID] <> 1
    --        )
    --        AND [ExRateLoadID] IS NULL
 
 
  
    INSERT  INTO @ForecastVolumes
            (
              [ProposalID],
              [TotalAmount] 
            )
            SELECT  ProposalID,
                    MAX(ForecastTotal) AS TotalAmount
            FROM    @ForecastVolume AS fv
            GROUP BY [ProposalID]
    RETURN ;
                

   END
GO
