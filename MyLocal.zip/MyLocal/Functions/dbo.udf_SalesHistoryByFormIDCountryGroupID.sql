SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_SalesHistoryByFormIDCountryGroupID]
    (
      @FormID INT ,
      @CountryGroupID INT,
      @ToValidCurrencyID INT
    )
RETURNS DECIMAL(20, 5)
AS
    BEGIN
        DECLARE @TotalAmt DECIMAL(20, 5)

        SELECT  @TotalAmt = SUM([dbo].[udf_ConvertCurrencyLatestFx](sh.[TotalAmt],
                                                              sh.[ValidCurrencyID],
                                                              @ToValidCurrencyID))
        FROM    [dbo].[tblSales] AS sh
                JOIN [dbo].[tblStrength] AS s ON s.[StrengthID] = sh.[StrengthID]
                JOIN dbo.tblCountryLinkCountryGroup clcg ON clcg.CountryID = sh.CountryID
        WHERE   s.[FormID] = @FormID AND clcg.CountryGroupID = @CountryGroupID

        RETURN (@TotalAmt)
    END


GO
