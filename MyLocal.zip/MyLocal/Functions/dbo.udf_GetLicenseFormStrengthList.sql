SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

create FUNCTION [dbo].[udf_GetLicenseFormStrengthList] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @StrengthList NVARCHAR(1000);

  SELECT
	@StrengthList = (COALESCE((@StrengthList + ', '), '') +
	(F.NAME + ' [' +
	LTRIM(STUFF( (
		SELECT
	  	  ', ' + xS.Name
		FROM
		  dbo.tblForm xF
			JOIN dbo.tblStrength xS ON xF.FormID = xS.FormID
    		JOIN dbo.tblMAStrength xMS ON xS.StrengthID = xMS.StrengthID
			JOIN dbo.tblMALicenseScope xMALS ON xMS.MAStrengthID = xMALS.MAStrengthID
			JOIN dbo.tblMALicense xMAL ON xMALS.MALicenseID = xMAL.MALicenseID
		WHERE
		  xF.FormID = F.FormID
		  AND xMAL.MALicenseID = MAL.MALicenseID
		GROUP BY xS.Name
		ORDER BY xS.Name
		FOR XML PATH('') ), 1, 1, '')) + ']'))
  FROM
	dbo.tblForm F
	  JOIN dbo.tblStrength S ON F.FormID = S.FormID
	  JOIN dbo.tblMAStrength MS ON S.StrengthID = MS.StrengthID
	  JOIN dbo.tblMALicenseScope MALS ON MS.MAStrengthID = MALS.MAStrengthID
	  JOIN dbo.tblMALicense MAL ON MALS.MALicenseID = MAL.MALicenseID
  WHERE
	MAL.MALicenseID = @MALicenseID
  GROUP BY
	MAL.MALicenseID,
	F.FormID,
	F.Name;
    
  RETURN @StrengthList;  

END



GO
GRANT EXECUTE ON  [dbo].[udf_GetLicenseFormStrengthList] TO [mp_db_execute]
GO
