SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--SELECT dbo.CalculateSunsetClauseDate(mal.malicenseID), mal.SunsetClause, *
--FROM dbo.tblMAApplication ma
--JOIN dbo.tblMALicense mal ON mal.MAApplicationID = ma.MAApplicationID
--WHERE ma.MAApplicationID = 17909

CREATE FUNCTION [dbo].[CalculateSunsetClauseDate]
(
    @MALicenseID INT
)
RETURNS NVARCHAR(MAX) WITH SCHEMABINDING
AS
BEGIN
    DECLARE @Value NVARCHAR(MAX);

	SELECT @Value = REPLACE(CONVERT(VARCHAR(15), DATEADD(YEAR, 3, SunsetClause), 106), ' ', '-')
	FROM dbo.tblMALicense mal WHERE mal.MALicenseID = @MALicenseID

	IF (@Value IS NULL)
BEGIN
	    SET @Value = N'not calculated';

		DECLARE @LicenseStatus NVARCHAR(MAX);

	    SELECT @LicenseStatus = vls.NAME
		FROM dbo.tblValidLicenseStatus vls
        JOIN dbo.tblMALicense mal
            ON mal.ValidLicenseStatusID = vls.ValidLicenseStatusID
    WHERE mal.MALicenseID = @MALicenseID;

    DECLARE @ApprovalDate DATETIME;
    SELECT @ApprovalDate = mal.LicenseApprovalDate
    FROM dbo.tblMALicense mal
    WHERE mal.MALicenseID = @MALicenseID;

    DECLARE @AnyMarketed BIT = 0;
    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblMALicenseScope mals
            JOIN dbo.tblBusinessBaseStates bbs
                ON mals.MarketStatusID = bbs.StateID
        WHERE mals.MALicenseID = @MALicenseID
              AND bbs.StateName = 'Marketed'
    )
        SET @AnyMarketed = 1;

    DECLARE @SomeNotMarketed BIT = 0;
    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblMALicenseScope mals
            JOIN dbo.tblBusinessBaseStates bbs
                ON mals.MarketStatusID = bbs.StateID
        WHERE mals.MALicenseID = @MALicenseID
              AND bbs.StateName = 'Not Marketed'
    )
        SET @SomeNotMarketed = 1;

    DECLARE @NoneMarketed BIT = 0;
    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.tblMALicenseScope mals
            JOIN dbo.tblBusinessBaseStates bbs
                ON mals.MarketStatusID = bbs.StateID
        WHERE mals.MALicenseID = @MALicenseID
              AND bbs.StateName <> 'Never Been Marketed'
    )
        SET @NoneMarketed = 1;

    DECLARE @LatestMarketCessationDate DATETIME;
    SET @LatestMarketCessationDate =
    (
        SELECT TOP (1)
               mals.MarketingCessationDate
        FROM dbo.tblMALicenseScope mals
        WHERE mals.MALicenseID = @MALicenseID
        ORDER BY mals.MarketingCessationDate DESC
    );

    DECLARE @ToBeChecked BIT = 0;
    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblMALicenseScope mals
            JOIN dbo.tblBusinessBaseStates bbs
                ON mals.MarketStatusID = bbs.StateID
        WHERE mals.MALicenseID = @MALicenseID
              AND bbs.StateName = '[To Be Checked]'
    )
        SET @ToBeChecked = 1;

    IF NOT EXISTS
    (
        SELECT DISTINCT
               c.CountryID
        FROM dbo.tblSubmissionRouteConfig src
            JOIN dbo.tblCountry c
                ON c.CountryID = src.CountryID
            JOIN dbo.tblMALicenseScope mals
                ON mals.CountryID = c.CountryID
        WHERE src.HealthAuthorityID = 6465
              AND mals.MALicenseID = @MALicenseID
    )
       OR @LicenseStatus IN ( 'Archived', 'Withdrawn', 'Divested', 'Rejected', 'Registration Exempt', 'Expired' )
        SET @Value = N'Does not apply';
    ELSE IF @AnyMarketed = 1
        SET @Value = N'Does not apply';
    ELSE IF @NoneMarketed = 1
        IF @ApprovalDate IS NOT NULL
            SET @Value = REPLACE(CONVERT(VARCHAR(15), DATEADD(YEAR, 3, @ApprovalDate), 106), ' ', '-');
        ELSE
            SET @Value = N'No MA Approval Date';
    ELSE IF @SomeNotMarketed = 1
        IF @LatestMarketCessationDate IS NOT NULL
            SET @Value = REPLACE(CONVERT(VARCHAR(15), DATEADD(YEAR, 3, @LatestMarketCessationDate), 106), ' ', '-');
        ELSE
            SET @Value = N'No Marketing Cessation Date';
    ELSE IF @ToBeChecked = 1
        SET @Value = N'Marketing Status [To Be Checked]';
		END
    RETURN @Value;
END;
GO
GRANT EXECUTE ON  [dbo].[CalculateSunsetClauseDate] TO [MYL\svc_MFG_MyPortfolio]
GO
