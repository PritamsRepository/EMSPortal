SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_BBActionDateByBBOCodeStateName] (
	@BBOCode nvarchar(256),
	@StateName nvarchar(256),
	@ObjectID int)
RETURNS datetime


AS

BEGIN

DECLARE @ReturnDate datetime

SELECT
	@ReturnDate = MAX(a.[Date])
FROM
	[dbo].[tblBusinessBaseObject] AS bbo
JOIN 
	[dbo].[tblBusinessBaseStateControl] AS bbsc 
ON 
	bbsc.[BBOID] = bbo.[BBOID]
JOIN 
	[dbo].[tblBusinessBaseStates] AS bbs 
ON 
	bbs.[StateControlID] = bbsc.[StateControlID]
JOIN 
	[dbo].[tblBusinessBaseObjectStateActions] a 
ON 
	a.[BBOID] = bbo.[BBOID]
WHERE
	bbo.[BBOCode] = @BBOCode AND
	bbs.[StateName] = @StateName AND
	a.[ObjectID] = @ObjectID AND
	a.[NewStateID] = bbs.[StateID]
	

RETURN(@ReturnDate)

END


GO
GRANT EXECUTE ON  [dbo].[udf_BBActionDateByBBOCodeStateName] TO [mp_db_execute]
GO
