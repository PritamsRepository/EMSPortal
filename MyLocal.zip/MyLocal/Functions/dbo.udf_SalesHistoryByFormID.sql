SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_SalesHistoryByFormID] (
	@FormID int,
	@ToValidCurrencyID int)
RETURNS DECIMAL( 19,4)
AS
BEGIN

DECLARE @TotalAmt DECIMAL( 19,4)

SELECT
	@TotalAmt = SUM( 
		[dbo].[udf_ConvertCurrencyLatestFx]( sh.[TotalAmt], sh.[ValidCurrencyID],
			@ToValidCurrencyID) )
FROM
	[dbo].[tblSales] AS sh
	JOIN [dbo].[tblStrength] AS s ON s.[StrengthID] = sh.[StrengthID]
WHERE
	s.[FormID] = @FormID

RETURN (@TotalAmt)

END


GO
GRANT EXECUTE ON  [dbo].[udf_SalesHistoryByFormID] TO [mp_db_execute]
GO
