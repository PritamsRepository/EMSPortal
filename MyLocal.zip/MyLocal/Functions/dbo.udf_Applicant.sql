SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_Applicant]
(
    @MAApplicationID INT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @ApplicantID NVARCHAR(MAX) = dbo.udf_ApplicantID(@MAApplicationID);
    DECLARE @Applicant NVARCHAR(MAX);

    SELECT @Applicant = c.Name
    FROM dbo.tblCompany c
    WHERE c.CompanyID = @ApplicantID;

    RETURN @Applicant;
END;
GO
