SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_StrengthBrandTradeDressListByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @BrandTradeDress NVARCHAR(2000)

SELECT
		@BrandTradeDress = COALESCE(@BrandTradeDress + ', ', '') + s.[BrandTradeDress]
	FROM
		[dbo].[tblStrength] AS s
	WHERE
		s.[FormID] = @FormID AND
		s.[IsUndefined] = 'false'
	ORDER BY
		s.[BrandTradeDress]

RETURN(@BrandTradeDress)

END


GO
GRANT EXECUTE ON  [dbo].[udf_StrengthBrandTradeDressListByFormID] TO [mp_db_execute]
GO
