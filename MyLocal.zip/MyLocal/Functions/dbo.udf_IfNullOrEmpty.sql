SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_IfNullOrEmpty] (@Value SQL_VARIANT, @EmptyText AS NVARCHAR(256))
RETURNS SQL_VARIANT

AS
BEGIN

  DECLARE @Temp AS NVARCHAR(MAX) = CAST(@Value AS NVARCHAR);
  
  IF(@Temp IS NULL OR LEN(@Temp) = 0) SET @Value = @EmptyText;
  
  RETURN @Value;
   
END


GO
GRANT EXECUTE ON  [dbo].[udf_IfNullOrEmpty] TO [mp_db_execute]
GO
