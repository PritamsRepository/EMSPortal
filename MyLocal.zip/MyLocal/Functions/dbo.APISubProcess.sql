SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[APISubProcess]
    (
      @SNCWorkstreamID INT ,
      @CompanyID INT
    )
RETURNS NVARCHAR(MAX)
    WITH SCHEMABINDING
AS
    BEGIN
        DECLARE @String NVARCHAR(MAX) = '('
        DECLARE @I INT = ( SELECT   ValidSNCSiteTypeID
                           FROM     dbo.tblValidSNCSiteType
                           WHERE    Name = 'API Intermediate Manufacturer'
                         )
        DECLARE @T INT = ( SELECT   ValidSNCSiteTypeID
                           FROM     dbo.tblValidSNCSiteType
                           WHERE    Name = 'API Test Site'
                         )
        DECLARE @M INT = ( SELECT   ValidSNCSiteTypeID
                           FROM     dbo.tblValidSNCSiteType
                           WHERE    Name = 'API Micronization Site'
                         )

        IF EXISTS ( SELECT  1
                    FROM    pm.SNCWorkstreamCatalog
                    WHERE   SNCWorkstreamID = @SNCWorkstreamID
                            AND SiteID = @CompanyID
                            AND ValidSNCSiteTypeID = @I )
            SET @String = @String + 'I, '

        IF EXISTS ( SELECT  1
                    FROM    pm.SNCWorkstreamCatalog
                    WHERE   SNCWorkstreamID = @SNCWorkstreamID
                            AND SiteID = @CompanyID
                            AND ValidSNCSiteTypeID = @T )
            SET @String = @String + 'T, '

        IF EXISTS ( SELECT  1
                    FROM    pm.SNCWorkstreamCatalog
                    WHERE   SNCWorkstreamID = @SNCWorkstreamID
                            AND SiteID = @CompanyID
                            AND ValidSNCSiteTypeID = @M )
            SET @String = @String + 'M, '

        SET @String = LEFT(@String, LEN(@String) - 1) + ')'

        RETURN @String
    END
GO
