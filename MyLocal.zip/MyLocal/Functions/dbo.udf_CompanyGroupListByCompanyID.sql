SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[udf_CompanyGroupListByCompanyID] (@CompanyID int)
RETURNS NVARCHAR(4000)


AS

BEGIN

		DECLARE @List NVARCHAR(4000)

		SELECT
				@List = COALESCE(@List + ', ', '') + cg.Text
		FROM 
			dbo.tblCompany c
		JOIN 
			dbo.tblCompanyLinkCompanyGroup clcg 
			ON 
				clcg.CompanyID = c.CompanyID
		JOIN 
			dbo.tblCompanyGroup cg 
			ON 
				cg.CompanyGroupID = clcg.CompanyGroupID
		WHERE	
			c.CompanyID = @CompanyID
		ORDER BY 
			cg.Text
			
		RETURN(@List)

END

GO
GRANT EXECUTE ON  [dbo].[udf_CompanyGroupListByCompanyID] TO [mp_db_execute]
GO
