SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_InclusionParameterTranslate] (@InclusionId int, @ParValue nvarchar(max), @IsSingleSelect bit)
RETURNS nvarchar(max)
AS

BEGIN
Declare @TranslatedParameter nvarchar(max)

	SELECT @TranslatedParameter = 
	(CASE 
		WHEN @InclusionId = 4 THEN VI.Name  --Should show None Set
		WHEN @ParValue = 'All' THEN @ParValue --We don't need to show the inclusion because we want all
		WHEN (@IsSingleSelect = 1 AND @InclusionId = 1) THEN @ParValue  --We don't want to show OR inclusion for items where you can choose only one
		ELSE VI.Name +' ' + @ParValue  --Display inclusion plus the parameter selections
	END) 
		 FROM dbo.tblValidInclusion AS VI 
	WHERE vi.ValidInclusionID = @InclusionId 


IF ISNULL(@TranslatedParameter, '') = '' 
BEGIN
	SET @TranslatedParameter = @ParValue 
END



	RETURN @TranslatedParameter
END




GO
