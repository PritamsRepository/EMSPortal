SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ProposalFilterNotApplicable_BOUND]
(
    @Value DECIMAL(20, 5)
)
RETURNS NVARCHAR(256)
WITH SCHEMABINDING
AS

/*=============================================================================
Notes:  The special value of -1974.00 is located in Candidate.vb and
        determines if the value is considered "N/A" or not.  It should be
        a value that is never used by a user, since these are costs and -1974 million
        is a very large value.
==============================================================================*/

BEGIN
    DECLARE @SPECIAL DECIMAL(20, 5);
    SET @SPECIAL = -1974.00;

    DECLARE @SUM NVARCHAR(256);
    SELECT @SUM = CASE
                      WHEN @Value = @SPECIAL THEN
                          'N/A'
                      ELSE
                          CAST(ISNULL(@Value, 0) AS NVARCHAR(256))
                  END;

    RETURN @SUM;
END;




GO
GRANT EXECUTE ON  [dbo].[udf_ProposalFilterNotApplicable_BOUND] TO [mp_db_execute]
GO
