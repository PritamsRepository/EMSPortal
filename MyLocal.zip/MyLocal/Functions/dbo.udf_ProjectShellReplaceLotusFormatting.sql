SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ProjectShellReplaceLotusFormatting](@Name NVARCHAR(256))
RETURNS
NVARCHAR(256) 
AS

BEGIN
	
/* 
this is a brute force pass through because it is testing day and this was not done prior to 
#JRG 
2011-11-17
*/
DECLARE @MyName nvarchar(256)
SET @MyName =(SELECT 

REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(
REPLACE(@Name,'CN=',''),'/OU=GBR/O=MYLAN',''),'/OU=MGCN/OU=Merck-Gen/O=Merck',''),'/OU=MGUK/OU=Merck-Gen/O=Merck',''),'/OU=FRA/O=MYLAN',''),'/OU=Dey_Labs/OU=Merck-Gen/O=Merck',''), '/OU=MGAA/OU=Merck-Gen/O=Merck',''),'/OU=MGFR/OU=Mylan-Gen/O=Merck',''),'/OU=IRL/O=MYLAN',''), '/OU=Pacific/OU=Merck-Gen/O=Merck',''), 'Nick Lee/OU=Gerard/OU=Merck-Gen/O=Merck',''),'/OU=AUS/O=MYLAN','' ),'/OU=CAN/O=MYLAN','')
,'/OU=CO/O=MATRIXLABSINDIA','')
,'/OU=MGW/O=MYLAN','')
,'/OU=NZL/O=MYLAN','')
,'/OU=JPN/O=MYLAN','')
,'/OU=STALBANS/O=MYLAN','')
,'/OU=SWE/O=MYLAN','')
,'/OU=MEFR/O=Merck','')
,'/O=MATRIXLABSINDIA','')
,'/OU=SWE/O=MYLAN','')
,'/OU=PITT/O=MYLAN','')
,'/C=CO','')
,'@Mylan','')
)




RETURN @MyName;
END


GO
GRANT EXECUTE ON  [dbo].[udf_ProjectShellReplaceLotusFormatting] TO [mp_db_execute]
GO
GRANT EXECUTE ON  [dbo].[udf_ProjectShellReplaceLotusFormatting] TO [mp_db_register]
GO
