SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_SupplierListByRMID] (@RMID INT)
RETURNS NVARCHAR(2000)
AS

BEGIN

	DECLARE @SupplierList NVARCHAR(2000)

	SELECT
		@SupplierList = COALESCE(@SupplierList + ', ', '') + c.Name

	FROM
		pm.RawMaterialSupplier srm
		INNER JOIN dbo.tblCompany c ON c.CompanyID =  srm.SupplierID
	WHERE
		srm.RawMaterialID = @RMID --AND srm.IsActive = 1
	ORDER BY
		
		c.Name
RETURN(@SupplierList)

END
GO
GRANT EXECUTE ON  [dbo].[udf_SupplierListByRMID] TO [mp_db_execute]
GO
