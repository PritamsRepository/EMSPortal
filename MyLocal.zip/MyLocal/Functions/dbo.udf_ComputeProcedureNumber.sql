SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ComputeProcedureNumber] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @FullProcedureNumber NVARCHAR(1000) = '';

  SELECT
	@FullProcedureNumber = (@FullProcedureNumber + ' ' + fpn.FullProcedureNumber)
  FROM
  (
	SELECT DISTINCT
	  mas.FullProcedureNumber
	FROM	  
	  dbo.tblMALicense mal
		JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID			
		JOIN dbo.tblMAStrength mas ON mals.MAStrengthID = mas.MAStrengthID
	WHERE
	  mal.MALicenseID = @MALicenseID AND
	  mas.FullProcedureNumber IS NOT NULL
  ) AS fpn;
  
  IF (LEN(@FullProcedureNumber) = 0) SET @FullProcedureNumber = NULL;
  
  SET @FullProcedureNumber = COALESCE(LTRIM(@FullProcedureNumber), 'N/A');
	
  RETURN @FullProcedureNumber;

END


GO
GRANT EXECUTE ON  [dbo].[udf_ComputeProcedureNumber] TO [mp_db_execute]
GO
