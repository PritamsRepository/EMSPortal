SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_PeakSalesForecastByProductProposalID_KeyMkt]
(
    @ProductProposalID INT,
    @ToValidCurrencyID INT,
    @ExRateID INT = NULL
)
RETURNS DECIMAL(20, 5) WITH SCHEMABINDING
AS
BEGIN

    DECLARE @forecasts TABLE
    (
        ProductProposalID INT NOT NULL,
        ForecastYear INT NULL,
        TotalAmount DECIMAL(20, 5) NULL,
        INDEX IX4 CLUSTERED (ProductProposalID, ForecastYear)
    );

    DECLARE @USD INT;
    SELECT @USD = ValidCurrencyID
    FROM dbo.tblValidCurrency
    WHERE Name = 'USD';

    IF @ExRateID IS NULL
        SELECT TOP (1)
               @ExRateID = ExRateLoadID
        FROM dbo.tblExchangeRateLoad x
        ORDER BY EffectiveDate DESC;

    DECLARE @FromUSFactor DECIMAL(20, 5);
    SELECT @FromUSFactor = x.ConversionFactor2USD
    FROM dbo.tblExchangeRate x
    WHERE x.ValidCurrencyID = @ToValidCurrencyID
          AND x.ExRateLoadID = @ExRateID;

    DECLARE @xxx TABLE
    (
        ProductProposalID INT NOT NULL,
        ForecastYear INT NOT NULL,
        CurrencyID INT NOT NULL,
        ForecastTotal DECIMAL(20, 5) NULL
        INDEX IX5 CLUSTERED (ProductProposalID, ForecastYear)
    );

    INSERT INTO @xxx
    (
        ProductProposalID,
        ForecastYear,
        CurrencyID,
        ForecastTotal
    )
    (SELECT DISTINCT
            p.ProductProposalID,
            psf.ForecastYear,
            ISNULL(psf.ValidCurrencyID, @USD),
            ISNULL(SUM(psf.ForecastTurnover), 0)
     FROM pm.ProductProposal p
         JOIN pm.ProductProposalTradeDress ptd
             ON ptd.ProductProposalID = p.ProductProposalID
         JOIN pm.ProductProposalSalesForecast psf
             ON ptd.ProductProposalTradeDressID = psf.ProductProposalTradeDressID
     WHERE p.ProductProposalID = @ProductProposalID AND psf.KeyMarket = 1
     GROUP BY p.ProductProposalID,
              psf.ForecastYear,
              psf.ValidCurrencyID);

    INSERT INTO @xxx
    (
        ProductProposalID,
        ForecastYear,
        CurrencyID,
        ForecastTotal
    )
    (SELECT DISTINCT
            rmf.ProductProposalID,
            rmf.Year,
            ISNULL(pp.ValidCurrencyID, @USD),
            ISNULL(rmf.SalesAmt, 0)
     FROM pm.ProductProposalRemainingMarketForecast rmf 
	 JOIN pm.ProductProposal pp ON pp.ProductProposalID = rmf.ProductProposalID
	 WHERE rmf.ProductProposalID = @ProductProposalID);


    INSERT INTO @forecasts
    (
        ProductProposalID,
        ForecastYear,
        TotalAmount
    )
    SELECT DISTINCT
           xxx.ProductProposalID,
           xxx.ForecastYear,
           SUM(xxx.ForecastTotal / x.ConversionFactor2USD)
    FROM @xxx xxx
        JOIN pm.ProductProposal p
            ON p.ProductProposalID = xxx.ProductProposalID
        JOIN pm.Candidate c
            ON c.CandidateID = p.CandidateID
        JOIN pm.PRBSession prb
            ON prb.PRBSessionID = c.TargetPRBSessionID
        JOIN dbo.tblExchangeRate x
            ON x.ExRateLoadID = prb.ExRateLoadID
               AND x.ValidCurrencyID = xxx.CurrencyID
    GROUP BY xxx.ProductProposalID,
             xxx.ForecastYear
    UNION
    SELECT DISTINCT
           xxx.ProductProposalID,
           xxx.ForecastYear,
           SUM(xxx.ForecastTotal / x.ConversionFactor2USD)
    FROM @xxx xxx
        JOIN pm.ProductProposal p
            ON p.ProductProposalID = xxx.ProductProposalID
        JOIN dbo.tblExchangeRate x
            ON x.ValidCurrencyID = xxx.CurrencyID
    WHERE p.CandidateID IS NULL
          AND x.ExRateLoadID = @ExRateID
    GROUP BY xxx.ProductProposalID,
             xxx.ForecastYear;

    DECLARE @TotalAmt DECIMAL(20, 5);

    IF @ToValidCurrencyID = @USD
        SELECT TOP (1)
               @TotalAmt = MAX(TotalAmount)
        FROM @forecasts;
    ELSE
        SELECT TOP (1)
               @TotalAmt = (MAX(TotalAmount) * @FromUSFactor)
        FROM @forecasts;

    RETURN @TotalAmt;
END;
GO
