SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_RoleIsCountryGroupSpecific] (@RoleID int)
RETURNS int
AS

BEGIN

DECLARE @Exists bit

DECLARE @FoundFalse bit
SET @FoundFalse = 0

DECLARE @FoundTrue bit
SET @FoundTrue = 1

IF EXISTS (
	SELECT
		p.[PrivID]
	FROM
		[dbo].[admin_SecRolePriv] AS rp
		JOIN [dbo].[admin_SecPriv] AS p on rp.[PrivID] = p.[PrivID]
	WHERE
		rp.[RoleID] = @RoleID AND
		p.[IsCGSpecific] = 'true')
	SET @Exists = @FoundTrue
ELSE
	SET @Exists = @FoundFalse

RETURN(@Exists)

END


GO
GRANT EXECUTE ON  [dbo].[udf_RoleIsCountryGroupSpecific] TO [mp_db_execute]
GO
