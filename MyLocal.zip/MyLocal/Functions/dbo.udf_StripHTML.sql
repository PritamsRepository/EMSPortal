SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_StripHTML]
(
    @HTMLText VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
    DECLARE @Tags TABLE
    (
        Tag NVARCHAR(MAX) NOT NULL
    );

    INSERT INTO @Tags
    (
        Tag
    )
    VALUES
    (N'a'),
    (N'b'),
    (N'br'),
    (N'col'),
    (N'colgroup'),
    (N'dir'),
    (N'div'),
    (N'em'),
    (N'font'),
    (N'i'),
    (N'img'),
    (N'li'),
    (N'o:p'),
    (N'p'),
    (N'q'),
    (N'span'),
    (N'st1:country-region'),
    (N'st1:place'),
    (N'strike'),
    (N'strong'),
    (N'sub'),
    (N'sup'),
    (N'table'),
    (N'tbody'),
    (N'td'),
    (N'tr'),
    (N'u'),
    (N'ul');

    DECLARE @Start INT;
    DECLARE @End INT;
    DECLARE @Length INT;
    DECLARE @ThisTag NVARCHAR(MAX);

    DECLARE c CURSOR FORWARD_ONLY LOCAL READ_ONLY FOR SELECT Tag FROM @Tags;

    OPEN c;
    FETCH NEXT FROM c
    INTO @ThisTag;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @str NVARCHAR(MAX);
        SET @str = N'<' + @ThisTag + N' ';

        SET @Start = CHARINDEX(@str, @HTMLText);
        SET @End = CHARINDEX('>', @HTMLText, CHARINDEX(@str, @HTMLText));
        SET @Length = (@End - @Start) + 1;
        WHILE @Start > 0 AND @End > 0 AND @Length > 0
        BEGIN
            SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '');
            SET @Start = CHARINDEX(@str, @HTMLText);
            SET @End = CHARINDEX('>', @HTMLText, CHARINDEX(@str, @HTMLText));
            SET @Length = (@End - @Start) + 1;
        END;
        FETCH NEXT FROM c
        INTO @ThisTag;

    END;
    CLOSE c;
    DEALLOCATE c;
    RETURN LTRIM(RTRIM(@HTMLText));
END;
GO
