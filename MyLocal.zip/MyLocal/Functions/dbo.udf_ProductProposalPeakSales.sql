SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_ProductProposalPeakSales]
(
    @ProductProposalID INT
)
RETURNS DECIMAL(19, 1)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @PeakSales DECIMAL(20, 1);

    DECLARE @a TABLE
    (
        ProductProposalID INT NOT NULL,
        ForecastYear INT NOT NULL,
        Amt DECIMAL(19, 1) NULL
    );

    INSERT INTO @a
    (
        ProductProposalID,
        ForecastYear,
        Amt
    )
    (SELECT DISTINCT
            p.ProductProposalID,
            sf.[ForecastYear],
            CASE
                WHEN c.CandidateID IS NULL THEN
                    SUM([dbo].[udf_ConvertCurrencyLatestFx](sf.[ForecastTurnover], sf.[ValidCurrencyID], p.ValidCurrencyID))
                ELSE
                    SUM([dbo].[udf_ConvertCurrencyByExRateLoad](
                                                                   prb.ExRateLoadID,
                                                                   sf.[ForecastTurnover],
                                                                   sf.[ValidCurrencyID],
                                                                   p.ValidCurrencyID
                                                               )
                       )
            END AS [TotalAmt]
     FROM [pm].[ProductProposalSalesForecast] AS sf
         JOIN [pm].[ProductProposalCountryInterest] AS ci
             ON ci.[ProductProposalCountryInterestID] = sf.[ProductProposalCountryInterestID]
         JOIN [pm].[ProductProposal] AS p
             ON p.[ProductProposalID] = ci.[ProductProposalID]
         LEFT JOIN pm.Candidate c
             ON c.CandidateID = p.CandidateID
         LEFT JOIN pm.PRBSession prb
             ON prb.PRBSessionID = c.TargetPRBSessionID
     WHERE p.ProductProposalID = @ProductProposalID
     GROUP BY c.CandidateID,
              p.ProductProposalID,
              sf.ForecastYear);

    SELECT @PeakSales = MAX(Amt)
    FROM @a;

    RETURN @PeakSales;
END;
GO
