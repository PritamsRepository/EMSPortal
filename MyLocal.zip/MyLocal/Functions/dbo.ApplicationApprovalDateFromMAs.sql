SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[ApplicationApprovalDateFromMAs]
(
    @MAApplicationID INT
)
RETURNS DATETIME
AS
BEGIN
    DECLARE @ApprovalDate DATETIME = NULL;

    SELECT @ApprovalDate = MIN(LicenseApprovalDate)
    FROM dbo.tblMALicense mal
    WHERE mal.MAApplicationID = @MAApplicationID
          AND mal.LicenseApprovalDate IS NOT NULL;

    RETURN @ApprovalDate;
END;
GO
