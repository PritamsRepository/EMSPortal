SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[DEFAULT_QualityStatus] ()
RETURNS INT
AS
BEGIN

DECLARE @Result INT

SET @Result = (SELECT ValidQualityStatusID FROM dbo.tblValidQualityStatus WHERE NAME='Pending')

RETURN @Result
	
END
GO
GRANT EXECUTE ON  [dbo].[DEFAULT_QualityStatus] TO [mp_db_execute]
GO
