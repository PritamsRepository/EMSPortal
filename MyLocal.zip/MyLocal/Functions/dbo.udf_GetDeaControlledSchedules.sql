SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetDeaControlledSchedules] ( @ProductID INT )
RETURNS NVARCHAR(MAX)
AS
    BEGIN          
        RETURN
LTRIM(STUFF(( SELECT  DISTINCT
                                        ', ' + vcs.Name
                              FROM 
                              dbo.tblProductLinkKPI plk
                            LEFT JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                            LEFT JOIN dbo.tblValidKeyIngredient vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            LEFT JOIN dbo.ValidKeyIngredientLinkValidDeaControlledSchedule vkilvcs ON vkilvcs.validKeyIngredientID = vki.ValidKeyIngredientID
                            LEFT JOIN dbo.tblValidDeaControlledSchedule vcs ON vcs.ValidDeaControlledScheduleID = vkilvcs.ValidDeaControlledScheduleID
                              WHERE     plk.ProductID = @ProductID
                              
                            FOR
                              XML PATH('')
                            ), 1, 2, ''))
    END
GO
