SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_GetDeaControlledSchedulesByKeyIngredient]
    (
      @ValidKeyIngredientID INT
    )
RETURNS NVARCHAR(MAX) WITH SCHEMABINDING
AS
    BEGIN
        RETURN
LTRIM(STUFF(( SELECT  DISTINCT
                                        ', ' + vcs.Name
                              FROM      dbo.ValidKeyIngredientLinkValidDeaControlledSchedule vkilvcs
                                        JOIN dbo.tblValidDeaControlledSchedule vcs ON vcs.ValidDeaControlledScheduleID = vkilvcs.ValidDeaControlledScheduleID
                              WHERE     vkilvcs.ValidKeyIngredientID = @ValidKeyIngredientID
                            FOR
                              XML PATH('')
                            ), 1, 2, ''))
    END


GO
