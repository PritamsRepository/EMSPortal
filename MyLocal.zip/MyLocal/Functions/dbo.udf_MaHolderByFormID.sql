SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_MaHolderByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS



BEGIN

DECLARE @MaHolder NVARCHAR(2000)

SELECT 
	@MaHolder = mp.maHolder
FROM 
	dbo.tblForm f 
JOIN 
	dbo.tblstrength s 
	on 
		f.formid = s.formid 
JOIN 
	dbo.tblMarketedProduct mp 
	ON 
		s.strengthid = mp.strengthid
WHERE 
	f.formid = @FormID

RETURN(@MaHolder)

END





GO
GRANT EXECUTE ON  [dbo].[udf_MaHolderByFormID] TO [mp_db_execute]
GO
