SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_GetUserNameByUserID] ( @UserID INT )
RETURNS NVARCHAR(256)
  WITH SCHEMABINDING
AS 
    BEGIN


        DECLARE @UserName AS NVARCHAR(256) ,
            @EMailAddress NVARCHAR(128) ,
            @FullName NVARCHAR(128) ,
            @ADUserName NVARCHAR(128)

        SET @UserName = ''



        SELECT  @EMailAddress = ISNULL('<a href="mailto:' + su.[EmailAddress] + '">', '') ,
                @FullName = su.FullName ,
                @ADUserName = su.ADUserName
        FROM    [dbo].[admin_SecUser] AS su
        WHERE   su.[UserID] = @UserID

        IF ( @FullName IS NOT NULL ) 
            BEGIN
                SET @UserName = @FullName
            END

        ELSE 
            IF ( @UserName IS NULL
                 OR LEN(@UserName) < 3
               ) 
                BEGIN
                    IF ( @ADUserName IS NOT NULL ) 
                        BEGIN
                            SET @UserName = @ADUserName
                        END 
                END	

            ELSE 
                IF ( @UserName IS NULL
                     OR LEN(@UserName) < 3
                   ) 
                    BEGIN
                        IF ( @EMailAddress IS NOT NULL ) 
                            BEGIN
                                SET @UserName = @EMailAddress
                            END
                        
                    END	

                ELSE 
                    BEGIN
                        SET @UserName = 'Unknown UserName'
                    END	
	
        RETURN @UserName


    END


GO
GRANT EXECUTE ON  [dbo].[udf_GetUserNameByUserID] TO [mp_db_execute]
GO
