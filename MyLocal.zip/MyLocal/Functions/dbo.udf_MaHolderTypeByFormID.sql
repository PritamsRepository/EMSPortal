SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_MaHolderTypeByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @MaHolderType NVARCHAR(2000)

SELECT 
	@MaHolderType = mp.maHolderType
FROM 
	tblForm f 
			INNER JOIN tblstrength s on f.formid = s.formid 
			INNER JOIN tblMarketedProduct mp ON s.strengthid = mp.strengthid
WHERE 
	f.formid = @FormID

RETURN(@MaHolderType)

END





GO
GRANT EXECUTE ON  [dbo].[udf_MaHolderTypeByFormID] TO [mp_db_execute]
GO
