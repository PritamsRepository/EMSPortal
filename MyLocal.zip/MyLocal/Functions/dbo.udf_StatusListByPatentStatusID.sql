SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_StatusListByPatentStatusID]
(
    @PatentStatusID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN
    DECLARE @PatentStatusList NVARCHAR(2000);

    SELECT @PatentStatusList = COALESCE(@PatentStatusList + ', ', '') + vgs.Name
    FROM pm.PatentStatusLinkValidGrantedStatus pslgs
        JOIN dbo.tblValidGrantedStatus vgs
            ON vgs.ValidGrantedStatusID = pslgs.ValidGrantedStatusID
    WHERE pslgs.PatentStatusID = @PatentStatusID
    ORDER BY vgs.Name;

    RETURN (@PatentStatusList);
END;

GO
GRANT EXECUTE ON  [dbo].[udf_StatusListByPatentStatusID] TO [mp_db_execute]
GO
