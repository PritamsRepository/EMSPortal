SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_FormatCompanyName]
(
    @CompanyID INT,
    @Format INT
)
RETURNS NVARCHAR(500)
AS
BEGIN

    DECLARE @Result NVARCHAR(1000);
    SET @Result =
    (
        SELECT (CASE
                    WHEN @Format IS NULL
                         OR @Format = 1 THEN
            (c.Name + COALESCE(' : ' + co.Code, ''))
                    WHEN @Format = 2 THEN
            (ISNULL((co.Code + ' : '), '') + c.Name + ' [' + ISNULL(c.ShortName, 'No Short Name Avail') + ']')
                END
               )
        FROM dbo.tblCompany c
            LEFT JOIN dbo.tblCountry co
                ON c.CountryID = co.CountryID
        WHERE c.CompanyID = @CompanyID
    );

    RETURN @Result;
END;
GO
GRANT EXECUTE ON  [dbo].[udf_FormatCompanyName] TO [mp_db_execute]
GO
