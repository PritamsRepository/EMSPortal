SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_SalesHistoryByCandidateID]
    (
      @CandidateID INT ,
      @ToValidCurrencyID INT
    )
RETURNS DECIMAL(20, 5)
AS
    BEGIN

        DECLARE @TotalAmt DECIMAL(20, 5)

        SELECT  @TotalAmt = SUM([dbo].[udf_ConvertCurrencyByExRateLoad](prbs.ExRateLoadID,
                                                              sh.[TotalAmt],
                                                              sh.[ValidCurrencyID],
                                                              @ToValidCurrencyID))
        FROM    [pm].[ProductProposalSales] AS sh
                JOIN [dbo].[tblStrength] AS s ON s.StrengthID = sh.StrengthID
                JOIN [dbo].[tblCountry] AS c ON c.CountryID = sh.CountryID
                JOIN [dbo].[tblCountryLinkCountryGroup] AS clcg ON clcg.CountryID = c.CountryID
                JOIN [dbo].[tblCountryGroup] AS cg ON cg.CountryGroupID = clcg.CountryGroupID
                JOIN pm.ProductProposal p ON p.CountryGroupID = cg.CountryGroupID
                JOIN pm.Candidate can ON can.FormID = s.FormID
                                         AND can.CandidateID = p.CandidateID
                JOIN pm.PRBSession prbs ON prbs.PRBSessionID = can.TargetPRBSessionID
        WHERE   can.[CandidateID] = @CandidateID

        RETURN (@TotalAmt)

    END
GO
