SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetMPBClassifications] ( @ProductID INT )
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
    BEGIN
        RETURN
		LTRIM(STUFF(( SELECT   
								('|' + COALESCE(pec.Name, '[None]')+ ' - ' + vki.Name)
                      FROM      dbo.tblForm f1
                                JOIN dbo.tblProductLinkKPI AS plk ON f1.productID = plk.ProductID
                                JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                                JOIN dbo.tblvalidkeyingredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                                LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                      WHERE     plk.ProductID = @ProductID
                      GROUP BY pec.Name, vki.Name
                      ORDER BY  pec.Name DESC, vki.Name
                    FOR
                      XML PATH('')
                    ), 1, 1, ''))
    END
GO
