SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_MarketingStates] (@MarketingStatusID INT)
RETURNS @State TABLE
(
  MarktedID INT,
  NeverBeenMarketedID INT,
  NotMarketedID INT
)

AS BEGIN  

DECLARE
  @MarktedID INT,
  @NeverBeenMarketedID INT,
  @NotMarketedID INT;

/* JRW: #FIXME If state names change, this logic will be impacted. */

IF ( @MarketingStatusID = 1 ) 
BEGIN
  SET @MarktedID = 
  ( 
	SELECT MBBS.StateID
    FROM
	  dbo.tblBusinessBaseStates MBBS
		JOIN dbo.tblBusinessBaseStateControl MBBSC ON MBBS.StateControlID = MBBSC.StateControlID
        JOIN dbo.tblBusinessBaseObject MBBO ON MBBSC.BBOID = MBBO.BBOID
        AND MBBO.BBOID =
        ( 
		  SELECT  BBOID
		  FROM	  dbo.tblBusinessBaseObject
		  WHERE   BBOTable = 'tblMALicenseScope' )
    WHERE  MBBS.StateName = 'Marketed' /* JRG #FIXME if sates change this will be impacted*/ )    
END           
ELSE IF ( @MarketingStatusID = 2 ) 
BEGIN
  SET @NeverBeenMarketedID = 
  ( 
	SELECT	MBBS.StateID
    FROM
	  dbo.tblBusinessBaseStates MBBS
		JOIN dbo.tblBusinessBaseStateControl MBBSC ON MBBS.StateControlID = MBBSC.StateControlID
        JOIN dbo.tblBusinessBaseObject MBBO ON MBBSC.BBOID = MBBO.BBOID
		  AND MBBO.BBOID = 
		  (
			SELECT	BBOID
            FROM	dbo.tblBusinessBaseObject
            WHERE   BBOTable = 'tblMALicenseScope' )
    WHERE MBBS.StateName = 'Never Been Marketed' /* JRG #FIXME if sates change this will be impacted*/ )

    SET @NotMarketedID = 
	(
	  SELECT MBBS.StateID
      FROM
		dbo.tblBusinessBaseStates MBBS
		  JOIN dbo.tblBusinessBaseStateControl MBBSC ON MBBS.StateControlID = MBBSC.StateControlID
          JOIN dbo.tblBusinessBaseObject MBBO ON MBBSC.BBOID = MBBO.BBOID
			AND MBBO.BBOID = 
			( 
			  SELECT  BBOID
			  FROM	  dbo.tblBusinessBaseObject
              WHERE   BBOTable = 'tblMALicenseScope' )
      WHERE MBBS.StateName = 'Not Marketed' )
                         
END

INSERT INTO @State
(
  MarktedID,
  NeverBeenMarketedID,
  NotMarketedID
)
SELECT
  @MarktedID,
  @NeverBeenMarketedID,
  @NotMarketedID;

RETURN;

END
GO
