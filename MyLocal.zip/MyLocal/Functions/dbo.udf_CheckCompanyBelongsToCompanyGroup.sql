SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE FUNCTION [dbo].[udf_CheckCompanyBelongsToCompanyGroup]
    (
      @CompanyID INT ,
      @CompanyGroupID INT )
RETURNS BIT
AS 
    BEGIN

        DECLARE @RetVal BIT

            BEGIN
                SET @RetVal = ( SELECT    DISTINCT
                                        1
                                FROM tblcompany C 
                                JOIN dbo.tblCompanyLinkCompanyGroup CLCG ON C.CompanyID = CLCG.CompanyID
                                JOIN dbo.tblCompanyGroup CG ON CLCG.CompanyGroupID = CG.CompanyGroupID
                                AND CG.CompanyGroupID=@CompanyGroupID
                                WHERE C.CompanyID=@CompanyID)
            END
        

        RETURN ISNULL(@RetVal, 0)

    END


GO
GRANT EXECUTE ON  [dbo].[udf_CheckCompanyBelongsToCompanyGroup] TO [mp_db_execute]
GO
