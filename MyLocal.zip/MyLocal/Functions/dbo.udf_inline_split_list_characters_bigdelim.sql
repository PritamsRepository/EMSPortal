SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_inline_split_list_characters_bigdelim]
    (
      @list nvarchar(MAX),
      @delim nvarchar(20) = ','
    )
RETURNS TABLE
    WITH SCHEMABINDING
AS
/*********************************************************
Function to parse comma delimited lists of strings.

CREATED BY:	Robin Abramson
CREATE DATE:	6/22/2010

USAGE: select * FROM dbo.udf_inline_split_list_characters ('sfasf,lksf,sfkkk,eeeee',',')

***********************************************************/
RETURN
    WITH    csvtbl ( start, stop )
              AS ( SELECT   start = convert(bigint, 1),
                            stop = charindex(@delim COLLATE SQL_Latin1_General_CP1_CI_AS,
                                             @list
                                             + convert(nvarchar(MAX), @delim))
                   UNION ALL
                   SELECT   start = stop + LEN(@delim),
                            stop = charindex(@delim COLLATE SQL_Latin1_General_CP1_CI_AS,
                                             @list
                                             + convert(nvarchar(MAX), @delim),
                                             stop + LEN(@delim))
                   FROM     csvtbl
                   WHERE    stop > 0
                 )
    SELECT  ltrim(rtrim(convert(nvarchar(4000), substring(@list, start,
                                                          CASE WHEN stop > 0 THEN stop - start
                                                               ELSE 0
                                                          END)))) AS Value
    FROM    csvtbl
    WHERE   stop > 0
    

GO
