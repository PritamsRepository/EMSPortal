SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetLicenseFormStrengthPackagingList] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN
  
  DECLARE @Products NVARCHAR(1000);
  
  SELECT
	@Products = (COALESCE((@Products + ', '), '') + x.Product)
  FROM    
	(SELECT	
	  (f.Name + ' [' +
	  LTRIM(STUFF( (
		  SELECT
			', ' + s2.Name
		  FROM
			dbo.tblForm f2
			  JOIN dbo.tblStrength s2 ON f2.FormID = s2.FormID
			  JOIN dbo.tblMAStrength ms2 ON s2.StrengthID = ms2.StrengthID
			  JOIN dbo.tblMALicenseScope mals2 ON ms2.MAStrengthID = mals2.MAStrengthID
			  JOIN dbo.tblMALicense mal2 ON mals2.MALicenseID = mal2.MALicenseID
		  WHERE f2.FormID = f.FormID
				AND mal2.MALicenseID = @MALicenseID
		  GROUP BY s2.Name
		  ORDER BY s2.Name
		  FOR XML PATH('') ), 1, 1, '')) + ']'
		   + ' [' +
	  ISNULL(LTRIM(STUFF( (
		  SELECT
			', ' + vpt.Name + ' (' + masp.PackageSize + ')'
		  FROM
			dbo.tblForm f2
			  JOIN dbo.tblStrength s2 ON f2.FormID = s2.FormID
			  JOIN dbo.tblMAStrength ms2 ON s2.StrengthID = ms2.StrengthID
			  JOIN dbo.tblMALicenseScope mals2 ON ms2.MAStrengthID = mals2.MAStrengthID
			  JOIN dbo.tblMaStrengthPackage masp ON masp.MAStrengthPackageID = mals2.MaStrengthPackageID
			  JOIN dbo.tblValidMAPackType vpt ON vpt.ValidMAPackTypeID = masp.ValidPackagingTypeID
			  JOIN dbo.tblMALicense mal2 ON mals2.MALicenseID = mal2.MALicenseID
		  WHERE f2.FormID = f.FormID
				AND mal2.MALicenseID = @MALicenseID
		  --GROUP BY vpt.Name + masp.PackageSize
		  ORDER BY vpt.Name + ' (' + masp.PackageSize + ')'
		  FOR XML PATH('') ), 1, 1, '')) , 'To Be Checked') + ']') AS Product
	FROM
	  dbo.tblForm f
		JOIN dbo.tblStrength s ON f.FormID = s.FormID
		JOIN dbo.tblMAStrength ms ON s.StrengthID = ms.StrengthID
		JOIN dbo.tblMALicenseScope mals ON ms.MAStrengthID = mals.MAStrengthID
		JOIN dbo.tblMALicense mal ON mals.MALicenseID = mal.MALicenseID
	WHERE mal.MALicenseID = @MALicenseID
	GROUP BY
	  f.FormID,
	  f.Name) x
	
  RETURN @Products;

END
GO
