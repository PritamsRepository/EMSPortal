SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_NotFiledPatentTypeID] ()
RETURNS int
AS

BEGIN
	DECLARE @ReturnValue int
	SET @ReturnValue = NULL

	SELECT
		@ReturnValue = [ValidPatentTypeID]
	FROM
		[dbo].[tblValidPatentType]
	WHERE
		[Name] = 'Not Filed'

	Return( @ReturnValue)
		
END


GO
GRANT EXECUTE ON  [dbo].[udf_NotFiledPatentTypeID] TO [mp_db_execute]
GO
