SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_CandidateMarketResponseByCandidateIDMarketID_table] ( )
RETURNS @MarketStatus TABLE
    (
      CandidateID INT ,
      MarketStatus NVARCHAR(256) ,
      CountryGroupID INT ,
      PRIMARY KEY ( CandidateID, MarketStatus, CountryGroupID )
    )

 /*********************************************************
Function to return a table containing forecastvolumes for
Candidate Market Status.

CREATED BY:	Robin Abramson
CREATE DATE:	9/20/2010

USAGE: select * FROM dbo.[udf_CandidateMarketResponseByCandidateIDMarketID_table] ()

***********************************************************/
AS
    BEGIN  
        INSERT  @MarketStatus
                ( [CandidateID] ,
                  [MarketStatus] ,
                  [CountryGroupID]
                )
-- First, any non-key market IDs that have proposals.
                SELECT DISTINCT
                        p.[CandidateID] ,
                        cg.[Name] ,
                        cg.[CountryGroupID]
                FROM    ( [dbo].[tblCountryGroup] AS cg
                          JOIN [pm].[ProductProposal] AS p ON cg.[CountryGroupID] = p.[CountryGroupID]
                        )
                WHERE   ( cg.[CountryGroupType] IS NULL
                          OR cg.[CountryGroupType] <> 'KeyMkt'
                        )
                        AND p.[CandidateID] IS NOT NULL
-- Now all key market requests.
        INSERT  @MarketStatus
                ( [CandidateID] ,
                  [MarketStatus] ,
                  [CountryGroupID]
                )
                SELECT DISTINCT
                        p.[CandidateID] ,
                        vr.Name ,
                        p.[CountryGroupID]
                FROM    [pm].[ProductProposal] AS p
                        JOIN [dbo].[tblValidResponse] AS vr ON p.[ValidResponseID] = vr.[ValidResponseID]
                        JOIN dbo.[tblCountryGroup] AS cg ON p.[CountryGroupID] = cg.[CountryGroupID]
                WHERE   cg.[CountryGroupType] = 'KeyMkt'
                        AND p.[CandidateID] IS NOT NULL

        RETURN;
    END
GO
