SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_MFADateRationaleListByLegalInfoID]
(
    @LegalInfoID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @List NVARCHAR(2000);

    SELECT @List = COALESCE(@List + '<br />', '') + vmfadr.[Name]
    FROM([dbo].[tblValidMFADateRationale] AS vmfadr
        JOIN [pm].[LegalInfoLinkValidMFADateRationale] AS link
            ON vmfadr.[ValidMFADateRationaleID] = link.[ValidMFADateRationaleID])
    WHERE link.[LegalInfoID] = @LegalInfoID
    ORDER BY vmfadr.[Name];

    RETURN (@List);

END;
GO
GRANT EXECUTE ON  [dbo].[udf_MFADateRationaleListByLegalInfoID] TO [mp_db_execute]
GO
