SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_MA_FormatCompanies](@CompanyID int)
RETURNS nvarchar(128)
AS
BEGIN

/*
 JRG
 Date: 20110915
 Decription:
 Prefix Mylan to Mylan Comapanies and add postfix Country Code 
 For MA Management Module
 */

DECLARE @CompanyName NVARCHAR(128)
DECLARE @Spc NCHAR(3) = ' : '
DECLARE @PreFix NCHAR(5) = 'Mylan'
DECLARE @NA NCHAR(3) = ''

SET @CompanyName =(
SELECT CASE WHEN c.IsThirdParty=0 THEN @PreFix + @Spc ELSE '' END + C.name /*+ @Spc*/ + CASE WHEN co.Code IS NULL THEN @NA ELSE @Spc + co.Code END AS Company
FROM dbo.tblCompany C
LEFT JOIN dbo.tblCountry Co ON C.CountryID=Co.CountryID 
WHERE C.CompanyID=@CompanyID
)
RETURN(@CompanyName)
END

GO
GRANT EXECUTE ON  [dbo].[udf_MA_FormatCompanies] TO [mp_db_execute]
GO
