SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_StrengthListWithListedPatentsByCountryByFormID]
(
    @FormID INT,
    @CountryID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @StrengthList NVARCHAR(2000);

    SELECT @StrengthList = RTRIM(LTRIM(COALESCE(@StrengthList + ', ', ''))) + [Name]
    FROM
    (
        SELECT DISTINCT
               s.Name
        FROM dbo.tblStrength s
            JOIN pm.PatentLinkStrength slp
                ON s.StrengthID = slp.StrengthID
            JOIN pm.Patent p
                ON slp.PatentID = p.PatentID
        WHERE s.[FormID] = @FormID
              AND p.[CountryID] = @CountryID
              AND dbo.udf_PatentIsListedForForm(@FormID, p.PatentID) = 'true'
              AND s.IsUndefined <> 1
        UNION
        SELECT DISTINCT
               s.Name
        FROM [pm].[Exclusivity] AS e
            JOIN [pm].[ExclusivityLinkStrength] AS sle
                ON e.[ExclusivityID] = sle.[ExclusivityID]
            JOIN [dbo].[tblStrength] AS s
                ON sle.[StrengthID] = s.[StrengthID]
        WHERE s.IsUndefined <> 1
              AND s.[FormID] = @FormID
              AND e.[IsListed] = 'yes'
              AND e.[CountryID] = @CountryID
    ) AS AdditionalStrengths;

    RETURN (@StrengthList);
END;
GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListWithListedPatentsByCountryByFormID] TO [mp_db_execute]
GO
