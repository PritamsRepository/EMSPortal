SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ImpactOnFilingDate_Table]
(
    @ProjectID INT
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN SELECT p.ProjectID,
              f.FormID,
              f.Name AS Product,
              cg.Name AS Region,
              (
                  SELECT MIN(e.ImpactOnFilingDate)
                  FROM pm.LegalInfo li
                      JOIN pm.Exclusivity AS e
                          ON li.CountryID = e.CountryID
                             AND li.FormID = e.FormID
                      JOIN dbo.tblCountryLinkCountryGroup AS clcg
                          ON clcg.CountryID = li.CountryID
                      LEFT JOIN dbo.tblValidExclusivityType AS vet
                          ON e.ValidExclusivityTypeID = vet.ValidExclusivityTypeID
                  WHERE li.FormID = f.FormID
                        AND ISNULL(vet.Category, '') <> 'MISEXCLUDE'
                        AND
                        (
                            li.CountryID IN
                            (
                                SELECT CountryID FROM pm.ProjectLinkCountry WHERE ProjectID = p.ProjectID
                            )
                            OR li.CountryID IN
                               (
                                   SELECT CountryID
                                   FROM dbo.tblCountryLinkCountryGroup
                                   WHERE CountryGroupID = p.CountryGroupID
                                         AND p.ProjectID NOT IN
                                             (
                                                 SELECT ProjectID FROM pm.ProjectLinkCountry
                                             )
                               )
                        )
              ) AS ImpactOnFilingDate
       FROM pm.Project p
           JOIN dbo.tblForm f
               ON f.FormID = p.FormID
           JOIN dbo.tblCountryGroup cg
               ON cg.CountryGroupID = p.CountryGroupID
       WHERE p.ProjectID = @ProjectID;

GO
