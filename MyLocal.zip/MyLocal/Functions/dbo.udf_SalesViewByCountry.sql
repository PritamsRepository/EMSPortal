SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

		
CREATE FUNCTION [dbo].[udf_SalesViewByCountry] 
		(@FormID INT, @CountryID INT)
RETURNS NVARCHAR(256)
AS			
/*=============================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS
CREATED ON:				DEC 3, 2009
MODIFIED BY:
MODIFIED ON:	
PURPOSE:					To get the peak sales forecasted sales by country interest id.
===============================================================================
EXAMPLE:					dbo.[udf_SalesViewByCountry] (can.FormID, pci.CountryID)
=============================================================================*/

BEGIN
		DECLARE @SalesViewByCountry NVARCHAR(256);

		SELECT 
			@SalesViewByCountry = ISNULL(CAST(Sum(sales.TotalAmt) AS NVARCHAR(256)),  'Data Not Available')
		FROM 
			tblStrength AS stg 
					INNER JOIN 	tblSales AS sales ON stg.StrengthID = sales.StrengthID
		WHERE 
			(stg.FormID = @FormID) AND 
			(sales.CountryID = @CountryID)
				
		RETURN(@SalesViewByCountry)
END


GO
GRANT EXECUTE ON  [dbo].[udf_SalesViewByCountry] TO [mp_db_execute]
GO
