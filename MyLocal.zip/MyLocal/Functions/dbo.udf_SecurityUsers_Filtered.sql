SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_SecurityUsers_Filtered] ( 
	@SearchID INT = NULL,
	@SearchUserName NVARCHAR(100) = NULL,
	@RoleID INT = NULL,
	@CountryGroupID INT = NULL,
	@CountryID INT = NULL,
	@Inactive BIT = NULL,
	@IsUnrestricted BIT = NULL,
	@DirectManagerID INT = NULL,
	@RegionalManagerID INT = NULL,
	@GlobalHeadID INT = NULL,
	@UserID int,
	@PrivCode nvarchar(10))
RETURNS @FilteredUsers TABLE
    (
	  UserID INT
    )
AS

BEGIN


INSERT INTO @FilteredUsers (UserID)
        

SELECT u.UserID
				FROM[dbo].[admin_SecUser] AS u 
				LEFT JOIN dbo.admin_SecUserRole AS ur ON u.UserID = ur.UserID
				LEFT JOIN dbo.admin_SecUserRoleLinkCountry AS urc ON ur.UserRoleID = urc.UserRoleID
				LEFT JOIN dbo.admin_SecUserRoleLinkCountryGroup as urcg ON ur.UserRoleID = urcg.UserRoleID
			WHERE
				(@SearchID IS NULL OR @SearchID = u.UserID) AND 
				(@SearchUserName IS NULL OR (u.ADUserName like '%' + @SearchUserName + '%' or u.FullName like '%' + @SearchUserName + '%' ) ) AND	
				(@RoleID IS NULL OR @RoleID = ur.RoleID) AND
				(@CountryGroupID IS NULL OR (ur.IsUnrestricted = 1 OR urcg.CountryGroupID = @CountryGroupID)) AND	
				(@CountryID IS NULL OR (ur.IsUnrestricted = 1 OR urc.CountryID = @CountryID)) AND
				(@Inactive IS NULL OR u.Active <> @Inactive) AND
				(@IsUnrestricted IS NULL OR ur.IsUnrestricted = @IsUnrestricted) AND
				(@DirectManagerID IS NULL OR @DirectManagerID = u.DirectManagerID) AND 
				(@RegionalManagerID IS NULL OR @RegionalManagerID = u.RegionalManagerID) AND 
				(@GlobalHeadID IS NULL OR @GlobalHeadID = u.GlobalHeadID) AND 
				dbo.udf_UserHasPriv(@UserID, @PrivCode) = 1
		GROUP BY u.UserID

	RETURN;


END




GO
