SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_CountryGroupListByUserRoleID] (@UserRoleID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @CountryGroupList NVARCHAR(2000)

SELECT
		@CountryGroupList = COALESCE(@CountryGroupList + ', ', '') + cg.Name
	FROM
		[dbo].[admin_SecUserRoleLinkCountryGroup] AS lcg
		JOIN [dbo].[tblCountryGroup] AS cg ON cg.[CountryGroupID] = lcg.[CountryGroupID]
	WHERE
		lcg.[UserRoleID] = @UserRoleID
	ORDER BY
		cg.Name

RETURN(@CountryGroupList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_CountryGroupListByUserRoleID] TO [mp_db_execute]
GO
