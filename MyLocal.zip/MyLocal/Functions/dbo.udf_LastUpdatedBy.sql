SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_LastUpdatedBy] ( 
	@BBOCode NVarchar(10),
	@ObjectID int)
RETURNS nvarchar(256)
AS

BEGIN

DECLARE @FullName as nvarchar(256)

SELECT TOP 1
	@FullName= u.[FullName]
FROM
	[dbo].[tblBusinessBaseObjectStateActions] AS a
	JOIN [dbo].[tblBusinessBaseObject] AS bbo ON bbo.[BBOID] = a.[BBOID]
	JOIN [dbo].[admin_SecUser] AS u ON u.[UserID] = a.[UserID]
WHERE
	bbo.[BBOCode] = @BBOCode AND
	a.[ObjectID] = @ObjectID
ORDER BY
	a.[Date] DESC

RETURN @FullName

END

GO
GRANT EXECUTE ON  [dbo].[udf_LastUpdatedBy] TO [mp_db_execute]
GO
