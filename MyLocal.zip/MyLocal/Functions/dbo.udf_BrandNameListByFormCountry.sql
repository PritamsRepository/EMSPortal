SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_BrandNameListByFormCountry] (@FormID int, @CountryID int)
RETURNS NVARCHAR(2000)


AS

BEGIN

DECLARE @BrandList NVARCHAR(2000)

SELECT
		@BrandList = COALESCE(@BrandList + ', ', '') + b.[Name]
	FROM
		[dbo].[tblBrand] AS b
	WHERE
		b.[FormID] = @FormID AND
		b.[CountryID] = @CountryID
	ORDER BY
		b.[Name]

RETURN(@BrandList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_BrandNameListByFormCountry] TO [mp_db_execute]
GO
