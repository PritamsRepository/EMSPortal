SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_MALicense_IsRMS]
(
    @MALicenseID INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @isRMS BIT = 0;

    SET @isRMS = CASE
                     WHEN @MALicenseID IN
                          (
                              SELECT mal.MALicenseID
                              FROM dbo.tblMALicense mal
                                  JOIN dbo.tblMAApplication ma
                                      ON ma.MAApplicationID = mal.MAApplicationID
                                  JOIN dbo.tblSubmissionRoute sr
                                      ON sr.SubmissionRouteID = ma.SubmissionRouteID
                                  JOIN dbo.MASubmissionWorkstream masw
                                      ON masw.MAApplicationID = ma.MAApplicationID
                                         AND masw.MASubmissionWorkstreamID = mal.MASubmissionWorkstreamID
										 LEFT JOIN dbo.MASubmissionWorkstream masw2 ON masw2.MASubmissionWorkstreamID = masw.ParentSubmissionID
                              WHERE sr.Category IN ( 'MRP', 'DCP' )
                                    AND (masw.ParentSubmissionID IS NULL OR masw2.ParentSubmissionID IS NULL)
                          ) THEN
                         1
                     ELSE
                         0
                 END;
    RETURN @isRMS;
END;
GO
