SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_FormListByPatentFamilyID]
(
    @PatentFamilyID INT,
    @FormID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @FormList NVARCHAR(2000);

    SELECT @FormList = COALESCE(@FormList + '<br />', '') + f.[Name]
    FROM([pm].[PatentFamilyLinkForm] AS pflf
        JOIN [dbo].[tblForm] AS f
            ON f.[FormID] = pflf.[FormID])
    WHERE pflf.[PatentFamilyID] = @PatentFamilyID
          AND pflf.[FormID] <> @FormID
    ORDER BY f.[Name];

    RETURN (@FormList);

END;
GO
GRANT EXECUTE ON  [dbo].[udf_FormListByPatentFamilyID] TO [mp_db_execute]
GO
