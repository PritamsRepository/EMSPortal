SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_IsStrengthUndefined]  
(@StrengthID INT )
RETURNS bit 
AS
BEGIN
DECLARE @Result bit

	SET @Result = (SELECT IsUndefined
	FROM tblstrength WHERE StrengthID=@StrengthID)
	
	RETURN @Result 
END

GO
GRANT EXECUTE ON  [dbo].[udf_IsStrengthUndefined] TO [mp_db_execute]
GO
