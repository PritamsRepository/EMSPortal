SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_ApplicantID]
(
    @MAApplicationID INT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @Applicant INT = NULL;
    DECLARE @Count INT;
    DECLARE @Procedure NVARCHAR(MAX);

    SELECT @Procedure = ProcedureNumber
    FROM dbo.tblMAApplication
    WHERE MAApplicationID = @MAApplicationID;

    SELECT @Count = COUNT(DISTINCT LicenseHolderID)
    FROM dbo.tblMALicense
    WHERE MAApplicationID = @MAApplicationID;

    IF (@Count < 2)
    BEGIN
        SET @Applicant = NULL;
        SELECT @Applicant = mal.LicenseHolderID
        FROM dbo.tblMALicense mal
        WHERE mal.MAApplicationID = @MAApplicationID;
    END;
    ELSE
    BEGIN
        -- Filter on RMS if MRP/DCP if only one, use it
        DECLARE @mrpdcp BIT = 0;
        IF EXISTS
        (
            SELECT 1
            FROM dbo.tblSubmissionRoute sr
                JOIN dbo.tblMAApplication ma
                    ON ma.SubmissionRouteID = sr.SubmissionRouteID
            WHERE ma.MAApplicationID = @MAApplicationID
                  AND sr.Category IN ( 'MRP', 'DCP' )
        )
        BEGIN
            SELECT @Count = COUNT(DISTINCT LicenseHolderID)
            FROM dbo.tblMALicense mal
            WHERE mal.LicenseHolderID IS NOT NULL
                  AND mal.MAApplicationID = @MAApplicationID
                  AND dbo.udf_MALicense_IsRMS(mal.MALicenseID) = 1;

            IF (@Count = 1)
            BEGIN
                SELECT @Applicant =
                (
                    SELECT DISTINCT
                           mal.LicenseHolderID
                    FROM dbo.tblMALicense mal
                    WHERE mal.LicenseHolderID IS NOT NULL
                          AND mal.MAApplicationID = @MAApplicationID
                          AND dbo.udf_MALicense_IsRMS(mal.MALicenseID) = 1
                );
            END;
            ELSE
            BEGIN
                -- It's an MRP/DCP but we don't know the RMS. Use Country from Procedure Number
                DECLARE @CountryID INT = NULL;
                SELECT @CountryID = c.CountryID
                FROM dbo.tblCountry c
                WHERE Code = LEFT(@Procedure, 2);

                SELECT @Count = COUNT(DISTINCT mal.LicenseHolderID)
                FROM dbo.tblMALicense mal
                    JOIN dbo.tblMALicenseScope mals
                        ON mals.MALicenseID = mal.MALicenseID
                WHERE mal.LicenseHolderID IS NOT NULL
                      AND mal.MAApplicationID = @MAApplicationID
                      AND mals.CountryID = @CountryID;

                IF (@Count = 1)
                BEGIN
                    SELECT @Applicant =
                    (
                        SELECT DISTINCT
                               mal.LicenseHolderID
                        FROM dbo.tblMALicense mal
                            JOIN dbo.tblMALicenseScope mals
                                ON mals.MALicenseID = mal.MALicenseID
                        WHERE mal.LicenseHolderID IS NOT NULL
                              AND mal.MAApplicationID = @MAApplicationID
                              AND mals.CountryID = @CountryID
                    );
                END;
            END;
        END;
    END;
    IF (@Applicant IS NULL)
    BEGIN
        -- Filter on MA Status = 'Approved'
        -- If still multiple, leave blank and provide regops with list of applications
        SELECT @Count = COUNT(DISTINCT mal.LicenseHolderID)
        FROM dbo.tblMALicense mal
            JOIN dbo.tblValidLicenseStatus vls
                ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
        WHERE mal.MAApplicationID = @MAApplicationID
              AND mal.LicenseHolderID IS NOT NULL
              AND vls.NAME IN ( 'Approved', 'Tentatively Approved' );
        IF (@Count < 2)
            SET @Applicant =
        (
            SELECT DISTINCT
                   mal.LicenseHolderID
            FROM dbo.tblMALicense mal
                JOIN dbo.tblValidLicenseStatus vls
                    ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
            WHERE mal.MAApplicationID = @MAApplicationID
                  AND mal.LicenseHolderID IS NOT NULL
                  AND vls.NAME IN ( 'Approved', 'Tentatively Approved' )
        )   ;
    END;
    RETURN @Applicant;
END;
GO
