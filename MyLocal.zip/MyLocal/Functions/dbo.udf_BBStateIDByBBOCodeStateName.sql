SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_BBStateIDByBBOCodeStateName] (
	@BBOCode nvarchar(256),
	@StateName nvarchar(256))
RETURNS int



AS

BEGIN

DECLARE @ReturnID int

SELECT
	@ReturnID = bbs.[StateID]
FROM
	[dbo].[tblBusinessBaseObject] AS bbo
JOIN 
	[dbo].[tblBusinessBaseStateControl] AS bbsc 
	ON 
		bbsc.[BBOID] = bbo.[BBOID]
JOIN 
	[dbo].[tblBusinessBaseStates] AS bbs 
	ON 
		bbs.[StateControlID] = bbsc.[StateControlID]
WHERE
	bbo.[BBOCode] = @BBOCode 
AND
	bbs.[StateName] = @StateName	

RETURN(@ReturnID)

END


GO
GRANT EXECUTE ON  [dbo].[udf_BBStateIDByBBOCodeStateName] TO [mp_db_execute]
GO
