SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_InnovatorBrandListForIPPRBByProposalID]
    (
      @CountryGroupID INT ,
      @ProposalID INT
    )
RETURNS NVARCHAR(3000)
AS /*====================================================================================================
CREATED BY:								SCOTT DEXTER				DATA ARCHITECT
CREATED ON:								MAR 3, 2009
PURPOSE:									The purpose of this function is to return a comma delimited list of the 
													innovator name and brand name separated by a dash.

======================================================================================================							
EXAMPLE:					SELECT [udf_InnovatorBrandListByProposalID] @CountryGroupID, @ProposalID
====================================================================================================*/
    BEGIN
        DECLARE @InnovatorBrand NVARCHAR(3000)
				
        BEGIN
            SELECT  @InnovatorBrand = ISNULL(@InnovatorBrand + ', ', '')
                    + InnovatorBrand
            FROM    ( SELECT 
										DISTINCT
                                CASE WHEN cp.Name IS NULL
                                          AND b.Name IS NULL
                                     THEN 'TBD - ' + '(' + c.Name + ')'
                                     ELSE ISNULL(cp.Name + ' - ', 'TBD - ')
                                          + ISNULL(b.Name, 'N/A')
                                          + ISNULL(' (' + c.Code + ')', 'N/A')
                                END AS InnovatorBrand
                      FROM      pm.ProductProposalCountryInterest pci
                                JOIN pm.ProductProposal p ON p.ProductProposalID = pci.ProductProposalID
                                JOIN tblCountry c ON pci.CountryID = c.CountryID
                                JOIN tblBrand b ON b.CountryID = pci.CountryID
                                                   AND b.FormID = p.FormID
                                JOIN tblCompany cp ON cp.CompanyID = b.BrandCompanyID
                                LEFT JOIN dbo.tblValidResponse vr ON pci.ValidResponseID = vr.ValidResponseID
                      WHERE     vr.Name = 'Yes - Interested'
                                AND pci.ProductProposalID = @ProposalID
                    ) AS BrandInnovator								
        END

        RETURN(@InnovatorBrand)
    END
GO
