SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_StrengthListMarketedProductByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS
/**********************************************************************************
CREATED BY:			Scott M. Dexter		Software Specialists Consultant
CREATED DATE:		NOV 12, 2009
MODIFIED BY:
MODIFIED DATE:
PURPOSE:				The purpose of this is to create a list of strengths that only
							exist for marketed products rather than both marketed and 
							unmarketed products.

SAMPLE USAGE:		SELECT [dbo].[udf_StrengthListMarketedProductByFormID] (@FormID)

**********************************************************************************/


BEGIN

DECLARE @StrengthList NVARCHAR(2000)

SELECT
		@StrengthList = COALESCE(@StrengthList + ', ', '') + x.[Name]
	FROM
	(SELECT DISTINCT s.Name
		FROM [dbo].[tblStrength] AS s 
			INNER JOIN tblMarketedProduct mp ON s.StrengthID = mp.StrengthID
		WHERE
			s.[FormID] = @FormID AND
			s.[IsUndefined] = 'false'
	) as x
	ORDER BY
		x.[Name]

RETURN(@StrengthList)

END




GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListMarketedProductByFormID] TO [mp_db_execute]
GO
