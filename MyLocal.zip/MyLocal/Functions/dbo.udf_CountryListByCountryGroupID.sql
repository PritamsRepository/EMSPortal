SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_CountryListByCountryGroupID] (@CountryGroupID int)
RETURNS NVARCHAR(max)
AS

BEGIN

DECLARE @countryList NVARCHAR(max)

SELECT
		@CountryList = COALESCE(@CountryList + ', ', '') + c.Name
	FROM
		(([dbo].[tblCountry] AS c INNER JOIN [dbo].[tblCountrylinkCountryGroup] AS clcg ON
		c.[CountryID] = clcg.[CountryID])
		INNER JOIN [dbo].[tblCountryGroup] AS cg ON
		clcg.[CountryGroupID] = cg.[CountryGroupID])
	WHERE
		cg.[CountryGroupID] = @CountryGroupID
	ORDER BY
		c.Name

RETURN(@countryList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_CountryListByCountryGroupID] TO [mp_db_execute]
GO
