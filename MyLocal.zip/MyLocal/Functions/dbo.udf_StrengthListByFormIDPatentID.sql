SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_StrengthListByFormIDPatentID]
(
    @FormID INT,
    @PatentID INT,
    @OnlyListed BIT = 0
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @StrengthList NVARCHAR(1980);
    DECLARE @Prefix NVARCHAR(20);
    DECLARE @StrCount INT;
    DECLARE @CountryID INT;

    SET @Prefix = N'';
    SELECT @StrCount = COUNT(*)
    FROM [dbo].[tblStrength] AS s
    WHERE s.[FormID] = @FormID
          AND s.[IsUndefined] = 'false'
          AND NOT EXISTS
    (
        SELECT slp.[StrengthID]
        FROM [pm].[PatentLinkStrength] slp
        WHERE slp.[StrengthID] = s.[StrengthID]
              AND slp.[PatentID] = @PatentID
    );

    IF (@OnlyListed = 'true')
    BEGIN

        IF (@StrCount = 0)
            SET @Prefix = N'[All Strengths] ';

        SELECT @StrengthList = COALESCE(@StrengthList + ', ', '') + s.[Name]
        FROM pm.PatentLinkStrength AS slp
            LEFT JOIN dbo.tblStrength AS s
                ON s.StrengthID = slp.StrengthID
        WHERE s.[FormID] = @FormID
              AND s.[IsUndefined] = 'false'
              AND slp.[PatentID] = @PatentID
              AND slp.[IsListed] = 'true'
        ORDER BY s.[Name];
    END;
    ELSE
    BEGIN
        SELECT @CountryID = CountryID
        FROM pm.Patent
        WHERE PatentID = @PatentID;

        SELECT @StrengthList = COALESCE(@StrengthList + ', ', '') + CASE
                                                                        WHEN vms.Category = 'Visible'
                                                                             AND vms.Name = 'Is Marketed' THEN
                                                                            s.[Name]
                                                                        WHEN vms.Name IS NOT NULL THEN
                                                                            s.[Name] + ' (' + vms.Name + ')'
                                                                        ELSE
                                                                            s.[Name] + ' (TBD)'
                                                                    END
        FROM dbo.tblStrength s
            LEFT JOIN dbo.tblBrandStrengthMarketing bsm
                ON bsm.StrengthID = s.StrengthID
                   AND EXISTS
    (
        SELECT 1
        FROM dbo.tblBrand b
        WHERE b.BrandID = bsm.BrandID
              AND b.FormID = @FormID
              AND b.CountryID = @CountryID
    )
            LEFT OUTER JOIN dbo.tblValidMarketingStatus vms
                ON vms.ValidMarketingStatusID = bsm.ValidMarketingStatusID
        WHERE s.FormID = @FormID
              AND s.[IsUndefined] = 'false'
        ORDER BY s.[Name];
    END;

    RETURN (@Prefix + @StrengthList);
END;
GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListByFormIDPatentID] TO [mp_db_execute]
GO
