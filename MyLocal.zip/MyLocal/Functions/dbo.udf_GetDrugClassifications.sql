SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetDrugClassifications] ( @ProductID INT )
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
    BEGIN
        DECLARE @gt NVARCHAR(2) = ''
        DECLARE @count INT
        SELECT  @count = COUNT(DISTINCT vki.Name)
        FROM    dbo.tblForm f2
                JOIN dbo.tblProductLinkKPI plk ON f2.productID = plk.ProductID
                JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                JOIN dbo.tblValidKeyIngredient vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                --JOIN dbo.ValidKeyIngredientLinkValidDrugClassification vkivdc ON vkivdc.ValidKeyIngredientID = vki.ValidKeyIngredientID
                --JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
        WHERE   plk.ProductID = @ProductID   
                     
        IF ( @count > 1 )
            SET @gt = '> ' 
            
        RETURN
	LTRIM(STUFF(( SELECT   '|' + @gt + vki.Name + ' - '
                                        + COALESCE(STUFF(( SELECT  DISTINCT
                                                            ', ' + vdc.Name
                                                  FROM      dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc
                                                            JOIN dbo.tblValidDrugClassification vdc ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
                                                  WHERE     vki.ValidKeyIngredientID = vkilvdc.ValidKeyIngredientID
                                                FOR
                                                  XML PATH('')
                                                ), 1, 2, ''), '[None]')
                              FROM      dbo.tblForm f2
                                        JOIN dbo.tblProductLinkKPI plk ON f2.productID = plk.ProductID
                                        JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                                        JOIN dbo.tblValidKeyIngredient vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                                        LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                              WHERE     plk.ProductID = @ProductID 
                              GROUP BY vki.Name, vki.ValidKeyIngredientID, pec.Name
                              ORDER BY pec.Name DESC                           
                            FOR
                              XML PATH('')
                            ), 1, 1, ''));
                            
    END
GO
