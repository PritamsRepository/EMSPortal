SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_GetPackagingList] (@MALicenseID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

DECLARE @List AS NVARCHAR(1000);
SELECT
  @List = (COALESCE((@List + ', '), '') + COALESCE((vpt.Name + ' ' + masp.PackageSize), ''))
FROM
  dbo.tblMALicense mal
	JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
	LEFT JOIN dbo.tblMaStrengthPackage masp ON mals.MaStrengthPackageID = masp.MAStrengthPackageID
	LEFT JOIN dbo.tblValidMAPackType vpt ON masp.ValidPackagingTypeID = vpt.ValidMAPackTypeID
WHERE
  mal.MALicenseID = @MALicenseID;

  RETURN @List;
END


GO
GRANT EXECUTE ON  [dbo].[udf_GetPackagingList] TO [mp_db_execute]
GO
