SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


--SELECT [dbo].[udf_SalesForecastVolumeByProductProposalID](42738)
CREATE FUNCTION [dbo].[udf_SalesForecastVolumeByProductProposalID] ( @ProductProposalID INT )
RETURNS DECIMAL(20, 5)
AS
    BEGIN
        DECLARE @SalesForecastVolumeByProductProposalID DECIMAL(20, 5);

		DECLARE @temp TABLE (TotalVolume DECIMAL(20, 5))

		INSERT INTO @temp(TotalVolume)
		(SELECT   SUM(psf.[ForecastVolume] * ptd.[PackSize]) AS TotalVolume
                       FROM     pm.ProductProposalSalesForecast psf
                                INNER JOIN pm.ProductProposalTradeDress ptd ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
                       WHERE    ptd.ProductProposalID = @ProductProposalID
                       GROUP BY psf.ForecastYear)

        --WITH    SalesForecastVolume ( TotalVolume )
        --          AS ( SELECT   SUM(psf.[ForecastVolume] * ptd.[PackSize]) AS TotalVolume
        --               FROM     pm.ProductProposalSalesForecast psf
        --                        INNER JOIN pm.ProductProposalTradeDress ptd ON psf.ProductProposalTradeDressID = ptd.ProductProposalTradeDressID
        --               WHERE    ptd.ProductProposalID = @ProductProposalID
        --               GROUP BY psf.ForecastYear
        --             )
            SELECT  @SalesForecastVolumeByProductProposalID = CAST(MAX(TotalVolume) AS DECIMAL(19,2)) 
                                                              
            FROM    @Temp --SalesForecastVolume

        RETURN(@SalesForecastVolumeByProductProposalID)
    END
GO
