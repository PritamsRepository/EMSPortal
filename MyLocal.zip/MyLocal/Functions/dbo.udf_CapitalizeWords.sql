SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_CapitalizeWords]
(
    @InputString NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @Result NVARCHAR(MAX) = N'';
    DECLARE @Index INT = 1;
    DECLARE @Char NVARCHAR(1);
    DECLARE @IsPrevSpace BIT = 1;

    WHILE @Index <= LEN(@InputString)
    BEGIN
        SET @Char = SUBSTRING(@InputString, @Index, 1);
        SET @Result += IIF(@IsPrevSpace = 1, UPPER(@Char), LOWER(@Char));
        SET @IsPrevSpace = IIF(@Char LIKE '[ -]', 1, 0);
        SET @Index += 1;
    END;

    RETURN @Result;
END;
GO
