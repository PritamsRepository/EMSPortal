SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

create FUNCTION [dbo].[udf_GetMAApplicationCountries] (@MAApplicationID INT)
RETURNS NVARCHAR(500)

AS
BEGIN

  DECLARE @Result NVARCHAR(500) = NULL;

  SELECT
	 @Result = (COALESCE(@Result + ', ', '') + c.Code)
  FROM
  (
	SELECT DISTINCT
	  c.Code
	FROM
	  dbo.tblMAApplication maa
		JOIN dbo.tblMALicense mal ON maa.MAApplicationID = mal.MAApplicationID
		JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID	
		JOIN dbo.tblCountry c ON mals.CountryID = c.CountryID
	WHERE	
	  maa.MAApplicationID = @MAApplicationID
	  AND	c.Code IS NOT NULL
  ) AS c

  RETURN @Result;
   
END

GO
GRANT EXECUTE ON  [dbo].[udf_GetMAApplicationCountries] TO [mp_db_execute]
GO
