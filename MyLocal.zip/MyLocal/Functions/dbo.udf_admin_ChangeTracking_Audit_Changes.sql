SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_admin_ChangeTracking_Audit_Changes]
    (
      @Date DATETIME ,
      @UpdateUserID INT ,
      @BBOID INT ,
      @ObjectID INT ,
	  @Identifier NVARCHAR(MAX),
      @Field NVARCHAR(MAX) ,
      @OldValue NVARCHAR(MAX) ,
      @NewValue NVARCHAR(MAX)
    )
RETURNS XML
AS
    BEGIN
        DECLARE @FormattedDate NVARCHAR(MAX)
        SET @FormattedDate = LEFT(DATENAME(dw, @Date), 3) + ', '
            + CONVERT(VARCHAR(15), @Date, 106) + ' '
            + CONVERT(VARCHAR(8), @Date, 108) + ' GMT'

        DECLARE @UpdateUser NVARCHAR(MAX) = ( SELECT    FullName
                                              FROM      admin_secuser
                                              WHERE     UserID = @UpdateUserID
                                            )
        DECLARE @BBOName NVARCHAR(MAX) = ( SELECT   BBOName
                                           FROM     dbo.tblBusinessBaseObject
                                           WHERE    BBOID = @BBOID
                                         )
        DECLARE @Change XML;
        WITH XMLNAMESPACES ('http://www.w3.org/2001/XMLSchema' AS xsd, 'http://www.w3.org/2001/XMLSchema-instance' AS xsi)
	SELECT @Change = (SELECT @FormattedDate AS 'DateChanges',
									@UpdateUserID AS 'User/@id',
									@UpdateUser AS 'User',
									'' AS 'Url',
									@ObjectID AS 'BusinessObject/@id',
									@Identifier AS 'BusinessObject/@identifier',
									@BBOName AS 'BusinessObject',
									@Field AS 'Changes/Property/@name' ,
                                    @OldValue AS 'Changes/Property/Old' ,
                                    @NewValue AS 'Changes/Property/New'
                          FOR
                            XML PATH('AuditTrail'), TYPE)
        RETURN @Change
    END
GO
