SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_InnovatorBrandListByCountryGroupID] (@CountryGroupID INT, @FormID INT, @Case INT)
RETURNS NVARCHAR(3000)
AS
/*====================================================================================================
CREATED BY:								SCOTT DEXTER				DATA ARCHITECT
CREATED ON:								DEC 2, 2009
PURPOSE:									The purpose of this function is to return a comma delimited list of the 
													innovator name and brand name seperated by a dash.
MODIFIED DATE:						11 FEB 2010
MODIFIED PURPOSE:				To ensure we capture each case where this is used. 
======================================================================================================							
EXAMPLE:					SELECT [udf_InnovatorBrandListByCountryGroupID] @CountryGroupID, @FormID, @Case
====================================================================================================*/

BEGIN
		DECLARE @KeyBrandGroupID INT 
		DECLARE @InnovatorBrand NVARCHAR(3000)
		SET @KeyBrandGroupID = (SELECT CountryGroupID FROM tblCountryGroup Where CountryGroupType = 'KeyBrd')

			IF @Case NOT IN (0, -1, -2)
						BEGIN
							SET @InnovatorBrand = NULL
						END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------						
			IF @Case = -2
						BEGIN
									SELECT @InnovatorBrand = IsNull(@InnovatorBrand +  ', ','') +  InnovatorBrand
									FROM
									(
									SELECT 
										DISTINCT CASE WHEN cp.Name IS NULL AND b.Name IS NULL THEN 'TBD - ' + '(' + c.Name + ')' 
										ELSE IsNull(cp.Name + ' - ', 'TBD - ') + IsNull(b.Name, 'N/A') + ISNULL(' (' + c.Name + ')', 'N/A') END as InnovatorBrand
										
									from tblCountry c 
										INNER JOIN tblCountryLinkCountryGroup clg on clg.CountryID = c.CountryID
										INNER JOIN tblCountryGroup cg on cg.CountryGroupID = clg.CountryGroupID
										INNER JOIN tblBrand b on b.CountryID = c.CountryID
										LEFT OUTER JOIN tblCompany cp on cp.CompanyID = b.BrandCompanyID
									WHERE
										c.CountryID IN (
										SELECT c.CountryID
										FROM tblCountry c
											INNER JOIN tblCountryLinkCountryGroup clcg ON clcg.CountryID = c.CountryID
											INNER JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
										WHERE cg.CountryGroupType = 'KeyBrd'
										INTERSECT
										SELECT c.CountryID
										FROM tblCountry c
											INNER JOIN tblCountryLinkCountryGroup clcg ON clcg.CountryID = c.CountryID
											INNER JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
										WHERE cg.CountryGroupID = @CountryGroupID
											)
									and 
										b.FormID = @FormID) as BrandInnovator
						END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
		IF @Case = -1
						BEGIN
							SELECT 
								@InnovatorBrand = CASE WHEN cp.Name IS NULL and b.Name IS NULL THEN IsNull(@InnovatorBrand + ', ','') + 'TBD - ' + '(' + cp.Name + ')'
								ELSE IsNull(@InnovatorBrand +  ', ','') + IsNull(cp.Name + ' - ', 'TBD - ') + IsNull(b.Name, 'N/A') + ISNULL(' (' + c.Name + ')', 'N/A') END 
							from tblCountry c 
								inner join tblCountryLinkCountryGroup clg on clg.CountryID = c.CountryID
								inner join tblCountryGroup cg on cg.CountryGroupID = clg.CountryGroupID
								inner join tblBrand b on b.CountryID = c.CountryID
								left outer join tblCompany cp on cp.CompanyID = b.BrandCompanyID
							WHERE
								cg.CountryGroupType = 'KeyBrd'
								and b.FormID = @FormID
						END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
		IF @Case = 0
						BEGIN
									SELECT 
										@InnovatorBrand = CASE WHEN cp.Name IS NULL and b.Name IS NULL THEN IsNull(@InnovatorBrand + ', ','') + 'TBD - ' + '(' + cp.Name + ')'
										ELSE IsNull(@InnovatorBrand +  ', ','') + IsNull(cp.Name + ' - ', 'TBD - ') + IsNull(b.Name, 'N/A') + ISNULL(' (' + c.Name + ')', 'N/A') END 
									from tblCountry c 
										inner join tblCountryLinkCountryGroup clg on clg.CountryID = c.CountryID
										inner join tblCountryGroup cg on cg.CountryGroupID = clg.CountryGroupID
										inner join tblBrand b on b.CountryID = c.CountryID
										left outer join tblCompany cp on cp.CompanyID = b.BrandCompanyID
									WHERE
										cg.CountryGroupID = @CountryGroupID and 
										b.FormID = @FormID
							END
							
		IF @Case = -3
						BEGIN
									SELECT @InnovatorBrand = IsNull(@InnovatorBrand +  ', ','') +  InnovatorBrand
									FROM
									(
									SELECT 
										DISTINCT CASE WHEN cp.Name IS NULL AND b.Name IS NULL THEN 'TBD - ' + '(' + c.Code + ')' 
										ELSE IsNull(cp.Name + ' - ', 'TBD - ') + IsNull(b.Name, 'N/A') + ISNULL(' (' + c.Code + ')', 'N/A') END as InnovatorBrand
										
									from tblCountry c 
										INNER JOIN tblCountryLinkCountryGroup clg on clg.CountryID = c.CountryID
										INNER JOIN tblCountryGroup cg on cg.CountryGroupID = clg.CountryGroupID
										INNER JOIN tblBrand b on b.CountryID = c.CountryID
										LEFT OUTER JOIN tblCompany cp on cp.CompanyID = b.BrandCompanyID
									WHERE
										c.CountryID IN (
										SELECT c.CountryID
										FROM tblCountry c
											INNER JOIN tblCountryLinkCountryGroup clcg ON clcg.CountryID = c.CountryID
											INNER JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
										WHERE cg.CountryGroupType = 'KeyBrd'
										INTERSECT
										SELECT c.CountryID
										FROM tblCountry c
											INNER JOIN tblCountryLinkCountryGroup clcg ON clcg.CountryID = c.CountryID
											INNER JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
										WHERE cg.CountryGroupID = @CountryGroupID
											)
									and 
										b.FormID = @FormID) as BrandInnovator
						END							
							
	RETURN(@InnovatorBrand)

END
							


GO
GRANT EXECUTE ON  [dbo].[udf_InnovatorBrandListByCountryGroupID] TO [mp_db_execute]
GO
