SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udft_PeakSalesForecastByProductProposalID]
    (
      @ProductProposalID INT ,
      @ToValidCurrencyID INT
    )
RETURNS TABLE
AS
-- SELECT * FROM DBO.udft_PeakSalesForecastByProposalID(@ProposalID, @ToValidCurrencyID)
RETURN
    ( SELECT    p.ProductProposalID ,
                p.ValidCurrencyID ,
                sf.[ForecastYear] ,
                SUM([dbo].[udf_ConvertCurrencyLatestFx](sf.[ForecastTurnover],
                                                        sf.[ValidCurrencyID],
                                                        @ToValidCurrencyID)) [TotalAmt]
      FROM      [pm].[ProductProposalSalesForecast] AS sf
                JOIN [pm].[ProductProposalCountryInterest] AS ci ON ci.[ProductProposalCountryInterestID] = sf.[ProductProposalCountryInterestID]
                JOIN [dbo].[tblCountryLinkCountryGroup] AS clcg ON clcg.[CountryID] = ci.[CountryID]
                JOIN [pm].[ProductProposal] AS p ON p.[ProductProposalID] = ci.[ProductProposalID]
                JOIN [dbo].[tblCountryGroup] AS cg ON cg.[CountryGroupID] = clcg.[CountryGroupID]
                                                      AND p.CountryGroupID = cg.CountryGroupID
      WHERE     p.[ProductProposalID] = @ProductProposalID
      GROUP BY  p.ProductProposalID ,
                p.ValidCurrencyID ,
                sf.[ForecastYear]
    )
GO
