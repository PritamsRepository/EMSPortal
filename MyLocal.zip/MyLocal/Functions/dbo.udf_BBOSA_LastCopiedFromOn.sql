SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_BBOSA_LastCopiedFromOn]
    (
      @CountryInterestID INT
    )
RETURNS DATETIME
    WITH SCHEMABINDING
AS /*==================================================================================
CREATED BY:				SCOTT DEXTER				Data Architect
CREATED ON:				01 FEB 2010				
PURPOSE:					To Get the Max Date when the item was copied.
EXAMPLE:					SELECT dbo.udf_BBOSA_LastCopiedFromOn(@CountryInterestID)
==================================================================================*/

    BEGIN
        DECLARE @LastCopiedFromOn DATETIME
	
        SELECT  @LastCopiedFromOn = MAX(Date)
        FROM    dbo.tblBusinessBaseObject bbo
                JOIN dbo.tblBusinessBaseObjectStateActions bbosa ON bbo.BBOID = bbosa.BBOID
        WHERE   bbosa.ObjectID = @CountryInterestID
                AND bbo.BBOCode = 'CI'
                AND bbosa.ActionType = 'C'
        RETURN (@LastCopiedFromOn)
    END
GO
GRANT EXECUTE ON  [dbo].[udf_BBOSA_LastCopiedFromOn] TO [mp_db_execute]
GO
