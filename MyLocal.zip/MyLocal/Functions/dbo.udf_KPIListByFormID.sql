SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_KPIListByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @KPIList NVARCHAR(2000)

SELECT
		@KPIList = COALESCE(@KPIList + ', ', '') + vki.[Name] + IsNull(' ' + vs.[Name], '')
	FROM
		tblForm f
		JOIN [dbo].[tblProductLinkKPI] AS plm ON f.[ProductID] = plm.[ProductID]
		JOIN [dbo].[tblKPI] AS m ON plm.[KPIID] = m.[KPIID]
		JOIN tblValidKeyIngredient vki on vki.ValidKeyIngredientID = m.ValidKeyIngredientID
		LEFT OUTER JOIN tblValidSalt vs on vs.ValidSaltID = m.ValidSaltID
	WHERE
		f.[FormID] = @FormID
	ORDER BY
		vki.[Name]

RETURN(@KPIList)

END



GO
GRANT EXECUTE ON  [dbo].[udf_KPIListByFormID] TO [mp_db_execute]
GO
