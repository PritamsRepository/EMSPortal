SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_GetUpdateStringByBBOCode] (
	@BBOCode nvarchar(10),
	@ObjectID int,
	@AuditTree nvarchar(50),
	@Format int = 1 )
	RETURNS NVARCHAR(256)
AS

BEGIN

DECLARE @Date datetime
DECLARE @UserID int
DECLARE @UpdateString nvarchar(256)



SELECT
	@UpdateString = 
	CASE
		WHEN @Format = 1 THEN
				'Update by '
				+ '<a href="mailto:' + u.[EmailAddress] + '">' 
				+ u.[FullName] + '</a> on '
				+ CONVERT( nvarchar(150), l.[UpdateDate], 106)
		WHEN @Format = 2 THEN
				'Update by ' + u.[FullName] + ' on '
				+ CONVERT( nvarchar(150), l.[UpdateDate], 106)
		WHEN @Format = 3 THEN 
				u.[FullName] + ' ('
				+ CONVERT( nvarchar(150), l.[UpdateDate], 106) + ')'
		WHEN @Format = 4 THEN
				u.[FullName]
		WHEN @Format = 5 THEN
			CONVERT( nvarchar(150), l.[UpdateDate], 126)
		ELSE
				CONVERT( nvarchar(150), l.[UpdateDate], @Format)
	END
FROM
	[dbo].[tblBusinessBaseLastUpdated] AS l
	JOIN [dbo].[admin_SecUser] AS u ON u.[UserID] = l.[UserID]
	JOIN [dbo].[tblBusinessBaseObject] AS b ON b.[BBOID] = l.[BBOID]
WHERE
	b.[BBOCode] = @BBOCode
	AND l.[ObjectID] = @ObjectID
	AND l.[AuditTree] = @AuditTree


RETURN @UpdateString;

END


GO
GRANT EXECUTE ON  [dbo].[udf_GetUpdateStringByBBOCode] TO [mp_db_execute]
GO
