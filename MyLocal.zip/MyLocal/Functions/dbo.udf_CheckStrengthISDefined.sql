SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_CheckStrengthISDefined] ( @StrengthID INT )
RETURNS BIT
AS 
    BEGIN
        DECLARE @RetVal BIT 

        SET @RetVal = ( SELECT DISTINCT
                                0
                        FROM    dbo.tblStrength
                        WHERE   StrengthID = @StrengthID
                                AND IsUndefined = 1 )


        RETURN ISNULL(@RetVal, 1)

    END

GO
GRANT EXECUTE ON  [dbo].[udf_CheckStrengthISDefined] TO [mp_db_execute]
GO
