SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[udf_CountryGroupListByCountryID] (@CountryID int)
RETURNS NVARCHAR(4000)
AS

BEGIN

		DECLARE @List NVARCHAR(4000)

		SELECT
				@List = COALESCE(@List + ', ', '') + cg.Name
		FROM 
			tblCountry c
				INNER JOIN tblCountryLinkCountryGroup clcg ON clcg.CountryID = c.CountryID
				INNER JOIN tblCountryGroup cg ON cg.CountryGroupID = clcg.CountryGroupID
		WHERE	
			c.CountryID = @CountryID
		ORDER BY 
			cg.Name
			
		RETURN(@List)

END

GO
GRANT EXECUTE ON  [dbo].[udf_CountryGroupListByCountryID] TO [mp_db_execute]
GO
