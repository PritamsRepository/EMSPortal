SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------
CREATE FUNCTION [dbo].[udf_CompanyListByCompanyGroupID] (@CompanyGroupID int)
RETURNS NVARCHAR(4000)


AS

BEGIN

		DECLARE @List NVARCHAR(4000)

		SELECT
				@List = COALESCE(@List + ', ', '') + c.Name
		FROM 
			dbo.tblCompany c
		JOIN 
			dbo.tblCompanyLinkCompanyGroup clcg 
			ON 
				clcg.CompanyID = c.CompanyID
		JOIN 
			dbo.tblCompanyGroup cg 
			ON 
				cg.CompanyGroupID = clcg.CompanyGroupID
		WHERE	
			cg.CompanyGroupID = @CompanyGroupID
		ORDER BY 
			c.Name
			
		RETURN(@List)

END

GO
GRANT EXECUTE ON  [dbo].[udf_CompanyListByCompanyGroupID] TO [mp_db_execute]
GO
