SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_UserHasPrivForCountryGroup_TableValued]
    (
      @UserID INT,
      @PrivCode NVARCHAR(20)
    )
RETURNS @CountryGroupPrivs TABLE
    (
      CountryGroupID INT PRIMARY KEY
                         NOT NULL,
      Privs BIT
    )
    WITH SCHEMABINDING
 /*********************************************************
Function to return a table containing country and bit true or false
CREATED BY:	JRG
CREATE DATE:	8/25/2010

Sample USAGE: 
SELECT cg.CountryGroupID,cg.CountryGroupType,cg.Name,cg.CountryGroupTypeDescription
 FROM dbo.tblCountryGroup cg
join  dbo.utdf_UserHasPrivForCountryGroup(@UserID,@privcode) a ON a.countrygroupID=cg.CountryGroupID AND a.Privs=1

Modified By: RDA
Modified Date: 8/25
Modification Changed to only use tables and not the line by line code.



***********************************************************/
AS BEGIN
     
    INSERT  INTO @CountryGroupPrivs
            (
              [CountryGroupID],
              [Privs]
              
            )
            SELECT  cg2.CountryGroupID,
                    0
            FROM    dbo.[tblCountryGroup] AS cg2
          
    IF EXISTS ( SELECT  ur.[UserID]
                FROM    [dbo].[admin_SecPriv] AS p
                        JOIN [dbo].[admin_SecRolePriv] AS rp ON p.PrivID = rp.PrivID
                        JOIN [dbo].[admin_SecRole] AS r ON r.RoleID = rp.RoleID
                        JOIN [dbo].[admin_SecUserRole] AS ur ON ur.RoleID = r.RoleID
                WHERE   ur.[UserID] = @UserID
                        AND p.[PrivCode] = @PrivCode
                        AND ur.[IsUnrestricted] = 1 ) 
        BEGIN	
            UPDATE  @CountryGroupPrivs
            SET     [Privs] = 1
        END
             
    IF NOT EXISTS ( SELECT  ur.[UserID]
                    FROM    [dbo].[admin_SecPriv] AS p
                            JOIN [dbo].[admin_SecRolePriv] AS rp ON p.PrivID = rp.PrivID
                            JOIN [dbo].[admin_SecRole] AS r ON r.RoleID = rp.RoleID
                            JOIN [dbo].[admin_SecUserRole] AS ur ON ur.RoleID = r.RoleID
                    WHERE   ur.[UserID] = @UserID
                            AND p.[PrivCode] = @PrivCode
                            AND ur.[IsUnrestricted] = 1 ) 
        BEGIN
        
            UPDATE  @CountryGroupPrivs
            SET     [Privs] = 1
            FROM    @CountryGroupPrivs AS cgp
                    JOIN ( SELECT   lcg.[CountryGroupID],
                                    ur.UserRoleID,
                                    p.privcode
                           FROM     [dbo].[admin_SecPriv] AS p
                                    JOIN [dbo].[admin_SecRolePriv] AS rp ON p.PrivID = rp.PrivID
                                    JOIN [dbo].[admin_SecRole] AS r ON r.RoleID = rp.RoleID
                                    JOIN [dbo].[admin_SecUserRole] AS ur ON ur.RoleID = r.RoleID
                                    LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountryGroup]
                                    AS lcg ON lcg.UserRoleID = ur.UserRoleID
                           WHERE    ur.[UserID] = @UserID
                                    AND p.[PrivCode] = @PrivCode
                                    AND lcg.CountryGroupID IS NOT NULL
                         ) AS cgs ON cgs.[CountryGroupID] = cgp.[CountryGroupID]
        END
                         
                      
    RETURN ;

   END


GO
