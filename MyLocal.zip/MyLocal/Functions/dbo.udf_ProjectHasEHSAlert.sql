SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_ProjectHasEHSAlert] ( @ProjectID INT )
RETURNS BIT
AS
    BEGIN      
        IF EXISTS ( SELECT  1
                    FROM    tblForm f
                            JOIN pm.Project p ON p.FormID = f.FormID
                            JOIN dbo.tblProductLinkKPI plk ON plk.ProductID = f.ProductID
                            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                            JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                    WHERE   p.ProjectID = @ProjectID
                            AND pec.Category = 'EHS Alert' )
            RETURN 1
                                    
        IF EXISTS ( SELECT  1
                    FROM    tblForm f
                            JOIN pm.Project p ON p.FormID = f.FormID
                            JOIN dbo.tblProductLinkKPI plk ON plk.ProductID = f.ProductID
                            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                            JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            JOIN dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc ON vkilvdc.ValidKeyIngredientID = vki.ValidKeyIngredientID
                            JOIN dbo.tblValidDrugClassification vdc ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
                    WHERE   p.ProjectID = @ProjectID
                            AND vdc.Category = 'EHS Alert' )
            RETURN 1
            
        IF EXISTS ( SELECT  1
                    FROM    tblForm f
                            JOIN pm.Project p ON p.FormID = f.FormID
                            JOIN dbo.tblProductLinkKPI plk ON plk.ProductID = f.ProductID
                            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
                            JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            JOIN dbo.ValidKeyIngredientLinkValidDeaControlledSchedule vkilvdcs ON vkilvdcs.ValidKeyIngredientID = vki.ValidKeyIngredientID
                    WHERE   p.ProjectID = @ProjectID )
            RETURN 1
        -- Return 0 if no alert    
        RETURN 0
    END

GO
