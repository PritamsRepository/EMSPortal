SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetLaunchStrengths] ( @LaunchID INT )
RETURNS NVARCHAR(1000)
AS
    BEGIN
        DECLARE @Strengths NVARCHAR(1000) = '';
        SELECT  @Strengths = ( @Strengths + s.Name + ', ' )
        FROM    pm.LaunchWorkstreamStrengthInfo ls
                JOIN dbo.tblStrength s ON ls.StrengthID = s.StrengthID
        WHERE   ls.LaunchWorkstreamID = @LaunchID;

        IF ( LEN(@Strengths) > 0 )
            SET @Strengths = LEFT(@Strengths, LEN(@Strengths) - 1); --Trim trailing ','

        RETURN @Strengths;
    END
GO
GRANT EXECUTE ON  [dbo].[udf_GetLaunchStrengths] TO [mp_db_execute]
GO
