SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[RemoveWhitespace]
    (
      @InputString NVARCHAR(MAX)
    )
RETURNS NVARCHAR(MAX)
AS
    BEGIN
        IF @InputString IS NOT NULL
            BEGIN
                DECLARE @Counter INT
                DECLARE @TestString NVARCHAR(40)

                SET @TestString = '%[' + NCHAR(0) + NCHAR(1) + NCHAR(2)
                    + NCHAR(3) + NCHAR(4) + NCHAR(5) + NCHAR(6) + NCHAR(7)
                    + NCHAR(8) + NCHAR(10) + NCHAR(11) + NCHAR(12) + NCHAR(13) + NCHAR(14) + NCHAR(15)
                    + NCHAR(16) + NCHAR(17) + NCHAR(18) + NCHAR(19) + NCHAR(20)
                    + NCHAR(21) + NCHAR(22) + NCHAR(23) + NCHAR(24) + NCHAR(25)
                    + NCHAR(26) + NCHAR(27) + NCHAR(28) + NCHAR(29) + NCHAR(30)
                    + NCHAR(31) + NCHAR(160) + '().]%'

                SELECT  @Counter = PATINDEX(@TestString,
                                            @InputString)

                WHILE @Counter != 0
                    BEGIN
                        SELECT  @InputString = STUFF(@InputString, @Counter, 1,
                                                     ' ')
                        SELECT  @Counter = PATINDEX(@TestString,
                                                    @InputString)
                    END
            END
        RETURN(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@InputString, ' ', ''),CHAR(10),''),',',''),']',''),'[',''),'-',''))
    END

GO
