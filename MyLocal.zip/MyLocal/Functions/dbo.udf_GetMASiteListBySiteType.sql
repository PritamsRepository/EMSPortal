SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_GetMASiteListBySiteType] (@MALicenseID INT, @SiteTypeName NVARCHAR(256))
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @Result NVARCHAR(1000);

  SELECT
	@Result = (COALESCE((@Result + ', '), '') + c.Name)
  FROM
  (
	SELECT DISTINCT	
	  (
		CASE 
		  WHEN vst.Category LIKE '%Primary Packaging%' 
		  THEN ('Primary: ' + dbo.udf_FormatCompanyName(c.CompanyID, 1)) 
		  WHEN vst.Category LIKE '%Secondary Packaging%' 
		  THEN ('Secondary: ' + dbo.udf_FormatCompanyName(c.CompanyID, 1)) 
		ELSE dbo.udf_FormatCompanyName(c.CompanyID, 1) END
	  ) AS Name    
	FROM
	  dbo.tblMALicense mal
		INNER JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
		INNER JOIN dbo.tblMARegisteredSite rs ON mals.MALicenseScopeID = rs.MALicenseScopeID
		INNER JOIN dbo.tblMASite s ON rs.MASiteID = s.MASiteID
		INNER JOIN dbo.tblValidSiteType vst ON s.ValidSiteTypeID = vst.ValidSiteTypeID
		INNER JOIN dbo.tblCompany c ON s.CompanyID = c.CompanyID
	WHERE
	  mal.MALicenseID = @MALicenseID
	  AND vst.Name = @SiteTypeName
  ) AS c;
  	
  RETURN @Result;

END


--select * from tblValidSiteType

GO
GRANT EXECUTE ON  [dbo].[udf_GetMASiteListBySiteType] TO [mp_db_execute]
GO
