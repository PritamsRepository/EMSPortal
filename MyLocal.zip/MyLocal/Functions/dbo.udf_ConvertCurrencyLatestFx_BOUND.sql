SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*------------------------------------------------------------------------------------------------------------------------
-- Create function
Change Date: 5/19/2010
Changed By:  Robin Abramson
Modification: Added Schema Binding to UDF to check for performance increase.
------------------------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION [dbo].[udf_ConvertCurrencyLatestFx_BOUND] (
	@FromAmt DECIMAL(19,4), 
	@FromValidCurrencyID INT, 
	@ToValidCurrencyID INT)
RETURNS DECIMAL(19,4)
WITH SCHEMABINDING
AS

BEGIN
	DECLARE @ToEffectiveDate DATETIME
	DECLARE @ReturnAmt DECIMAL(19,4)
	SET @ReturnAmt = NULL

	SELECT TOP 1
		@ToEffectiveDate = erl.EffectiveDate
	FROM
		dbo.tblExchangeRate er
			INNER JOIN dbo.tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
	WHERE
		er.ValidCurrencyID = @FromValidCurrencyID
	ORDER BY
		erl.EffectiveDate DESC

	IF @@ROWCOUNT > 0
	BEGIN
		SET @ReturnAmt = [dbo].[udf_ConvertCurrency_BOUND]( @FromAmt, @FromValidCurrencyID, @ToValidCurrencyID, @ToEffectiveDate)
	END

	RETURN(@ReturnAmt)

END






GO
GRANT EXECUTE ON  [dbo].[udf_ConvertCurrencyLatestFx_BOUND] TO [mp_db_execute]
GO
