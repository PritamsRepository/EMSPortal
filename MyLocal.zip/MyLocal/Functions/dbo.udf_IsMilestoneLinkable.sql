SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_IsMilestoneLinkable] ( @MilestoneID INT )
RETURNS BIT
AS
    BEGIN
        DECLARE @ObjectID INT
        DECLARE @BBOID INT
        DECLARE @ReferenceMilestoneID INT
        DECLARE @GlobalMilestoneID INT
        DECLARE @MilestoneTemplateItemID INT
		
        SELECT  @ObjectID = ObjectID ,
                @BBOID = BBOID ,
                @ReferenceMilestoneID = ReferenceMilestoneID ,
                @MilestoneTemplateItemID = MilestoneTemplateItemID
        FROM    dbo.tblMilestone
        WHERE   MileStoneID = @MilestoneID
	
        IF @ReferenceMilestoneID IS NOT NULL
            RETURN 0
	
        SELECT  @GlobalMilestoneID = GlobalMilestoneID
        FROM    dbo.tblMilestoneTemplateItem
        WHERE   MilestoneTemplateItemID = @MilestoneTemplateItemID

        RETURN CASE WHEN EXISTS( SELECT  1
                    FROM    tblMilestone m
                            JOIN dbo.tblMilestoneTemplateItem mti ON m.MilestoneTemplateItemID = mti.MilestoneTemplateItemID
                            JOIN dbo.vwLinkObjectToProject vlop ON m.BBOID = vlop.BBOID
                                                              AND m.ObjectID = vlop.ObjectID
                    WHERE   mti.GlobalMilestoneID = @GlobalMilestoneID
                            AND m.ReferenceMilestoneID IS NULL
                            AND m.MileStoneID NOT IN (
                            SELECT  ReferenceMilestoneID
                            FROM    dbo.tblMilestone )
                            AND vlop.projectID IN (
                            SELECT DISTINCT
                                    ProjectID
                            FROM    dbo.vwLinkObjectToProject
                            WHERE   BBOID = @BBOID
                                    AND ObjectID = @ObjectID )
                            AND ( m.BBOID != @BBOID
                                  OR m.ObjectID != @ObjectID
                                ) )
          THEN 1
          ELSE 0
         END
    END
GO
