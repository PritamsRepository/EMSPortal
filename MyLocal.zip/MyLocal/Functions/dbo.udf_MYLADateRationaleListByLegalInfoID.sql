SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_MYLADateRationaleListByLegalInfoID]
(
    @LegalInfoID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @List NVARCHAR(2000);

    SELECT @List = COALESCE(@List + '<br />', '') + vmadr.[Name]
    FROM([dbo].[tblValidMYLADateRationale] AS vmadr
        JOIN [pm].[LegalInfoLinkValidMYLADateRationale] AS link
            ON vmadr.[ValidMYLADateRationaleID] = link.[ValidMYLADateRationaleID])
    WHERE link.[LegalInfoID] = @LegalInfoID
    ORDER BY vmadr.[Name];

    RETURN (@List);

END;
GO
GRANT EXECUTE ON  [dbo].[udf_MYLADateRationaleListByLegalInfoID] TO [mp_db_execute]
GO
