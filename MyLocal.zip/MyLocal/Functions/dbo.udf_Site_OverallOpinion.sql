SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_Site_OverallOpinion] ( @companyID INT )
RETURNS INT
AS
    BEGIN
        IF EXISTS ( SELECT  1
                    FROM    dbo.tblValidOpinion vop
                            JOIN GA.Opinion op ON op.ValidOpinionID = vop.ValidOpinionID
                    WHERE   op.SiteID = @CompanyID
                            AND vop.Name = 'Unfavorable' )
            RETURN (SELECT ValidOpinionID FROM tblValidOpinion WHERE Name = 'Unfavorable')
        IF EXISTS ( SELECT  1
                    FROM    dbo.tblValidOpinion vop
                            JOIN GA.Opinion op ON op.ValidOpinionID = vop.ValidOpinionID
                    WHERE   op.SiteID = @CompanyID )
            RETURN (SELECT ValidOpinionID FROM tblValidOpinion WHERE Name = 'Favorable')
        RETURN NULL
    END
GO
