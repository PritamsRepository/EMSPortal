SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_EHSAlert]
(
    @ProductID INT = NULL,
    @RMID INT = NULL
)
RETURNS NVARCHAR(80)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @alert NVARCHAR(80) = NULL;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblProductLinkKPI plk
            LEFT JOIN dbo.tblKPI kpi
                ON kpi.KPIID = plk.KPIID
            LEFT JOIN pm.RawMaterial rm
                ON rm.KPIID = kpi.KPIID
            LEFT JOIN dbo.tblValidKeyIngredient AS vki
                ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN dbo.tblValidPECCategory AS pec
                ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
        WHERE (
                  plk.ProductID = @ProductID
                  OR
                  (
                      rm.RawMaterialID = @RMID
                      AND @RMID IS NOT NULL
                  )
              )
              AND pec.Category = 'EHS Alert'
    )
        SET @alert = N'OEB';

    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblProductLinkKPI plk
            LEFT JOIN dbo.tblKPI kpi
                ON kpi.KPIID = plk.KPIID
            LEFT JOIN pm.RawMaterial rm
                ON rm.KPIID = kpi.KPIID
            LEFT JOIN dbo.tblValidKeyIngredient AS vki
                ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc
                ON vkilvdc.ValidKeyIngredientID = vki.ValidKeyIngredientID
            LEFT JOIN dbo.tblValidDrugClassification vdc
                ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
        WHERE (
                  plk.ProductID = @ProductID
                  OR
                  (
                      rm.RawMaterialID = @RMID
                      AND @RMID IS NOT NULL
                  )
              )
              AND vdc.Category = 'EHS Alert'
    )
        SET @alert = CASE
                         WHEN @alert IS NULL THEN
                             'Drug Class'
                         ELSE
                             @alert + ', Drug Class'
                     END;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.tblProductLinkKPI plk
            JOIN dbo.tblKPI kpi
                ON kpi.KPIID = plk.KPIID
            JOIN dbo.tblValidKeyIngredient AS vki
                ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            JOIN dbo.ValidKeyIngredientLinkValidDeaControlledSchedule vkilvdcs
                ON vkilvdcs.ValidKeyIngredientID = vki.ValidKeyIngredientID
            LEFT JOIN pm.RawMaterial rm
                ON rm.KPIID = kpi.KPIID
        WHERE (
                  plk.ProductID = @ProductID
                  OR
                  (
                      rm.RawMaterialID = @RMID
                      AND @RMID IS NOT NULL
                  )
              )
    )
        SET @alert = CASE
                         WHEN @alert IS NULL THEN
                             'API Controlled'
                         ELSE
                             @alert + ', API Controlled'
                     END;
    -- Return NULL if no alert    
    RETURN @alert;
END;

GO
