SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_StrengthListByExclusivityID]
(
    @ExclusivityID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @StrengthList NVARCHAR(2000);

    SELECT @StrengthList = COALESCE(@StrengthList + ', ', '') + s.[Name]
    FROM([dbo].[tblStrength] AS s
        JOIN [pm].[ExclusivityLinkStrength] AS link
            ON s.[StrengthID] = link.[StrengthID])
    WHERE link.[ExclusivityID] = @ExclusivityID
    ORDER BY s.[Name];

    RETURN (@StrengthList);

END;


GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListByExclusivityID] TO [mp_db_execute]
GO
