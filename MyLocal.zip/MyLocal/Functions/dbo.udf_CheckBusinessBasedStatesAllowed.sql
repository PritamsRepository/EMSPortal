SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_CheckBusinessBasedStatesAllowed]
    ( @StatusID INT ,
      @BBOCode NVARCHAR(20) )
RETURNS BIT
AS 
    BEGIN
        
        DECLARE @result BIT
        
        
        IF EXISTS ( SELECT  BBS.StateID
                    FROM    dbo.tblBusinessBaseStates BBS
                            JOIN dbo.tblBusinessBaseStateControl BBSC ON BBS.StateControlID = BBSC.StateControlID
                                                                         AND BBSC.BBOID = ( SELECT  bboid
                                                                                            FROM    dbo.tblBusinessBaseObject BBO
                                                                                            WHERE   BBO.BBOCode = @BBOCode )
                    WHERE   BBS.StateID = @StatusID ) 
            BEGIN
                SET @result = 1
            END
		
        ELSE 
            BEGIN
                SET @result = 0
            END
		 
        RETURN @result ;                                                                             
    END
GO
GRANT EXECUTE ON  [dbo].[udf_CheckBusinessBasedStatesAllowed] TO [mp_db_execute]
GO
