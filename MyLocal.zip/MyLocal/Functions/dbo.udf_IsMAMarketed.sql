SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_IsMAMarketed] (@MALicenseID INT)
RETURNS BIT

AS
BEGIN

  RETURN
  (
	SELECT
	  (CASE WHEN COUNT(mal.MALicenseID) >= 1 THEN 1 ELSE 0 END) AS IsMarketed
	FROM
	  dbo.tblMALicense mal
		INNER JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
		JOIN dbo.tblBusinessBaseStates bbs ON mals.MarketStatusID = bbs.StateID
	WHERE
	  bbs.StateName = 'Marketed'
	  AND mal.MALicenseID = @MALicenseID
  );
   
END


GO
GRANT EXECUTE ON  [dbo].[udf_IsMAMarketed] TO [mp_db_execute]
GO
