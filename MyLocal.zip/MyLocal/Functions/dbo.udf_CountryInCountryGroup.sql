SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_CountryInCountryGroup] (@CountryID int, @CountryGroupID int)
RETURNS bit

WITH SCHEMABINDING

AS

BEGIN

DECLARE @Exists bit

IF EXISTS (
	SELECT
		clcg.[CountryID]
	FROM
		[dbo].[tblCountryLinkCountryGroup] as clcg
	WHERE
		clcg.[CountryGroupID] = @CountryGroupID AND
		clcg.[CountryID] = @CountryID)
	SET @Exists = 1
ELSE
	SET @Exists = 0

RETURN(@Exists)

END


GO
GRANT EXECUTE ON  [dbo].[udf_CountryInCountryGroup] TO [mp_db_execute]
GO
