SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_CompanyIsInternalBD] 
(@CompanyID INT)
RETURNS NVARCHAR(12)
AS 
    BEGIN

        DECLARE @RetVal BIT

        SET @RetVal = (
        ISNULL((SELECT 1 FROM dbo.tblCompanyGroup CG
        JOIN dbo.tblCompanyLinkCompanyGroup Link ON CG.CompanyGroupID = Link.CompanyGroupID
        JOIN dbo.tblCompany C ON Link.CompanyID = C.CompanyID AND C.CompanyID=@CompanyID    
        WHERE CG.CompanyGroupID=(SELECT CompanyGroupID FROM dbo.tblCompanyGroup WHERE [Text]='Mylan')),0)       
        )
RETURN @RetVal
END
GO
GRANT EXECUTE ON  [dbo].[udf_CompanyIsInternalBD] TO [mp_db_execute]
GO
