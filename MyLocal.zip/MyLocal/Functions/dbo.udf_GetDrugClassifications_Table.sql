SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_GetDrugClassifications_Table] ( @ProductID INT )
RETURNS TABLE
    WITH SCHEMABINDING
AS
           
        RETURN
    SELECT  vki.Name AS keyIngredient ,
            COALESCE(STUFF(( SELECT  DISTINCT
                                    ', ' + vdc.NAME
                             FROM   dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc
                                    JOIN dbo.tblValidDrugClassification vdc ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
                             WHERE  vki.ValidKeyIngredientID = vkilvdc.ValidKeyIngredientID
                           FOR
                             XML PATH('')
                           ), 1, 2, ''), '[None]') AS drugClassification
    FROM    dbo.tblForm f2
            JOIN dbo.tblProductLinkKPI plk ON f2.ProductID = plk.ProductID
            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
            JOIN dbo.tblValidKeyIngredient vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
    WHERE   plk.ProductID = @ProductID
    GROUP BY vki.Name ,
            vki.ValidKeyIngredientID ,
            pec.Name

GO
