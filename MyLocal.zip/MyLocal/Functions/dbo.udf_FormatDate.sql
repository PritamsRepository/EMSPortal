SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_FormatDate] ( @Date DATETIME )
RETURNS NVARCHAR(30)
    WITH SCHEMABINDING

AS
    BEGIN
        IF ( @Date = '11/5/1955' )
            RETURN 'ASAP'
        IF ( @Date = '7/4/1776' )
            RETURN 'TBD'
        IF ( @Date = '12/7/1941' )
            RETURN 'No Impact'
        IF ( @Date = '12/31/2999' )
            RETURN 'Not Applicable'
        IF ( @Date = '7/1/1863' )
            RETURN 'On Approval'
        IF ( @Date = '9/17/1862' )
            RETURN 'Formed'
        IF ( @Date = '9/30/2888' )
            RETURN 'Unlimited'

        RETURN (SELECT REPLACE(CONVERT(VARCHAR(11), @Date, 106), ' ', '-') AS [DD-Mon-YYYY]);

    END
GO
GRANT EXECUTE ON  [dbo].[udf_FormatDate] TO [mp_db_execute]
GO
