SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_ConvertCurrencyByExRateLoad]
(
    @ExRateLoadID INT = NULL,
    @FromAmt DECIMAL(20, 5),
    @FromValidCurrencyID INT,
    @ToValidCurrencyID INT
)
RETURNS DECIMAL(20, 5)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @ToEffectiveDate DATETIME;
    DECLARE @ReturnAmt DECIMAL(20, 5);
    SET @ReturnAmt = NULL;

    IF @ExRateLoadID IS NULL
    BEGIN

        SELECT @ToEffectiveDate = MAX(EffectiveDate)
        FROM dbo.tblExchangeRateLoad;

    END;
    ELSE IF @ExRateLoadID IS NOT NULL
    BEGIN

        SELECT TOP 1
               @ToEffectiveDate = EffectiveDate
        FROM dbo.tblExchangeRateLoad
        WHERE ExRateLoadID = @ExRateLoadID;

    END;

    IF @@ROWCOUNT > 0
    BEGIN
        SET @ReturnAmt
            = [dbo].[udf_ConvertCurrency](@FromAmt, @FromValidCurrencyID, @ToValidCurrencyID, @ToEffectiveDate);
    END;

    RETURN (@ReturnAmt);

END;
GO
GRANT EXECUTE ON  [dbo].[udf_ConvertCurrencyByExRateLoad] TO [mp_db_execute]
GO
