SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [config].[GetAssigneeBySNCWorkstreamIDAndDepartmentID]
    (
      @SNCWorkstreamID INT ,
      @ValidDepartmentID INT
    )
RETURNS INT
AS
    BEGIN
        DECLARE @UserID INT
        DECLARE @Quality INT = ( SELECT ValidDepartmentID
                                 FROM   dbo.tblValidDepartment
                                 WHERE  Name = 'Quality'
                               )
        DECLARE @Europe INT = ( SELECT    CountryGroupID
                              FROM      dbo.tblCountryGroup
                              WHERE     Name = 'Europe'
                                        AND CountryGroupType = 'KeyMkt'
                            )
        DECLARE @ThirdParty INT = ( SELECT  ValidSNCApprovalGovernanceID
                                    FROM    dbo.tblValidSNCApprovalGovernance
                                    WHERE   Name = 'Third Party'
                                  )

        DECLARE @ValidSNCApprovalGovernanceID INT
        DECLARE @CountryGroupID INT
        DECLARE @ProductID INT = ( SELECT   ProductID
                                   FROM     dbo.tblForm f
                                            JOIN pm.SNCWorkstream snc ON snc.FormID = f.FormID
                                   WHERE    snc.SNCWorkstreamID = @SNCWorkstreamID
                                 )
        DECLARE @Alert BIT = 0
        IF EXISTS ( SELECT  1
                    FROM    dbo.tblProduct p
                            JOIN dbo.tblProductLinkKPI plk1 ON plk1.ProductID = p.ProductID
                            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk1.KPIID
                            JOIN dbo.tblValidKeyIngredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
                            JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                    WHERE   ( pec.Category = 'EHS Alert'
                              OR pec.Name = 'OEB 3'
                            )
                            AND p.ProductID = @ProductID )
            SET @Alert = 1

        DECLARE @Vertical NVARCHAR(MAX)
        SELECT  @ValidSNCApprovalGovernanceID = snc.ValidSNCApprovalGovernanceID ,
                @CountryGroupID = snc.CountryGroupID ,
                @Vertical = vv.Name
        FROM    pm.SNCWorkstream snc
                JOIN dbo.tblForm f ON f.FormID = snc.FormID
                JOIN dbo.tblValidVertical vv ON vv.ValidVerticalID = f.ValidVerticalID
        WHERE   snc.SNCWorkstreamID = @SNCWorkstreamID

        DECLARE @ValidSNCProcessID INT = ( SELECT   ValidSNCProcessID
                                           FROM     pm.SNCWorkstream snc
                                           WHERE    snc.SNCWorkstreamID = @SNCWorkstreamID
                                         )

        IF @ValidSNCProcessID = 1
            BEGIN
                IF @ValidDepartmentID != @Quality
                    SET @UserID = ( SELECT DISTINCT
                                            UserID
                                    FROM    [config].SNCGuidanceRequestAssignee
                                    WHERE   ( ValidSNCApprovalGovernanceID IS NULL
                                              OR ValidSNCApprovalGovernanceID = @ValidSNCApprovalGovernanceID
                                            )
                                            AND ( CountryGroupID IS NULL
                                                  OR CountryGroupID = @CountryGroupID
                                                )
                                            AND ( ValidSNCRequestID IS NULL
                                                  OR ValidSNCRequestID IN (
                                                  SELECT    ValidSNCRequestID
                                                  FROM      pm.SNCWorkstream
                                                  WHERE     SNCWorkstreamID = @SNCWorkstreamID )
                                                )
                                            AND ( HasSNCAlert IS NULL
                                                  OR HasSNCAlert = @Alert
                                                )
                                            AND ( ValidDepartmentID <> @Quality
                                                  OR @CountryGroupID <> @Europe
                                                )
                                            AND ValidDepartmentID = @ValidDepartmentID
                                  )

                ELSE
                    IF @ValidDepartmentID = @Quality
                        SET @UserID = ( SELECT DISTINCT
                                                gra.UserID
                                        FROM    [config].SNCGuidanceRequestAssignee gra
                                                JOIN dbo.tblForm f ON f.ProductID = @ProductID
                                                JOIN dbo.tblValidVertical vv ON vv.ValidVerticalID = f.ValidVerticalID
                                                JOIN dbo.tblValidSNCApprovalGovernance sag ON sag.ValidSNCApprovalGovernanceID = vv.ValidVerticalID
                                        WHERE   gra.ValidSNCApprovalGovernanceID = sag.ValidSNCApprovalGovernanceID
                                                AND sag.Name = @Vertical
                                                AND @CountryGroupID = @Europe
                                                AND gra.CountryGroupID = @Europe
                                                AND gra.ValidDepartmentID = @Quality
                                                AND ( gra.ValidSNCRequestID IS NULL
                                                      OR gra.ValidSNCRequestID IN (
                                                      SELECT  ValidSNCRequestID
                                                      FROM    pm.SNCWorkstream
                                                      WHERE   SNCWorkstreamID = @SNCWorkstreamID )
                                                    )
                                                AND ( gra.HasSNCAlert IS NULL
                                                      OR gra.HasSNCAlert = @Alert
                                                    )
                                                AND gra.ValidDepartmentID = @ValidDepartmentID
                                      )

            END
        ELSE
            IF @ValidSNCProcessID = 2 -- Change Catalog
                BEGIN
                    IF @ValidDepartmentID <> @Quality
                        SET @UserID = ( SELECT DISTINCT
                                                UserID
                                        FROM    [config].SNCGuidanceRequestAssignee
                                        WHERE   ( ValidSNCApprovalGovernanceID IS NULL
                                                  OR ValidSNCApprovalGovernanceID = @ValidSNCApprovalGovernanceID
                                                )
                                                AND ( CountryGroupID IS NULL
                                                      OR CountryGroupID = @CountryGroupID
                                                    )
                                                AND ( ValidSNCSiteTypeID IN (
                                                      SELECT  ValidSNCSiteTypeID
                                                      FROM    pm.SNCWorkstreamCatalog cat
                                                              JOIN dbo.tblValidSNCModType mt ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                                                      WHERE   SNCWorkstreamID = @SNCWorkstreamID
                                                              AND mt.Name <> 'No Change' ) )
                                                AND ( HasSNCAlert IS NULL
                                                      OR HasSNCAlert = @Alert
                                                    )
                                                AND ( ValidDepartmentID <> @Quality
                                                      OR @CountryGroupID <> @Europe
                                                    )
                                                AND ValidDepartmentID = @ValidDepartmentID
                                      )
                    ELSE
                        SET @UserID = ( SELECT DISTINCT
                                                UserID
                                        FROM    [config].SNCGuidanceRequestAssignee gra
                                                JOIN dbo.tblForm f ON f.ProductID = @ProductID
                                                JOIN dbo.tblValidVertical vv ON vv.ValidVerticalID = f.ValidVerticalID
                                                JOIN dbo.tblValidSNCApprovalGovernance sag ON sag.ValidSNCApprovalGovernanceID = vv.ValidVerticalID
                                        WHERE   gra.ValidSNCApprovalGovernanceID = sag.ValidSNCApprovalGovernanceID
                                                AND sag.Name = @Vertical
                                                AND @CountryGroupID = @Europe
                                                AND gra.CountryGroupID = @Europe
                                                AND gra.ValidDepartmentID = @Quality
                                                AND ( gra.ValidSNCSiteTypeID IN (
                                                      SELECT  cat.ValidSNCSiteTypeID
                                                      FROM    pm.SNCWorkstreamCatalog cat
                                                              JOIN dbo.tblValidSNCModType mt ON mt.ValidSNCModTypeID = cat.ValidSNCModTypeID
                                                      WHERE   cat.SNCWorkstreamID = @SNCWorkstreamID
                                                              AND mt.Name <> 'No Change' ) )
                                                AND ( HasSNCAlert IS NULL
                                                      OR HasSNCAlert = @Alert
                                                    )
                                                AND ValidDepartmentID = @ValidDepartmentID
                                      )
                END
        RETURN @UserID
    END
GO
