SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_CheckTeamBelongsToBBO]
    (
      @TeamID INT ,
      @BBOCode NVARCHAR(50) )
RETURNS BIT
AS 
    BEGIN

        DECLARE @RetVal BIT
        /* FK allows nulls so if it is null then allow*/
        
        IF ( @TeamID IS NULL ) 
            BEGIN
                SET @RetVal = 1
            END
		
		/* Teams must belong to the correct BBOCode */
        ELSE 
            BEGIN
                SET @RetVal = ( SELECT    DISTINCT
                                        1
                                FROM    tblBusinessBaseObject bbo
                                        INNER JOIN tblTeam t ON bbo.BBOID = t.BBOID
                                WHERE   bbo.BBOCode = @BBOCode
                                        AND t.TeamID = @TeamID )
            END
        

        RETURN ISNULL(@RetVal, 0)

    END

GO
GRANT EXECUTE ON  [dbo].[udf_CheckTeamBelongsToBBO] TO [mp_db_execute]
GO
