SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

create FUNCTION [dbo].[udf_MAApplication_GetStrengthList] (@MAApplicationID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @Data TABLE
  (
	ID INT IDENTITY(1, 1),
	Strength NVARCHAR(500)
  );

  INSERT INTO @Data
  (
	Strength
  )
  SELECT DISTINCT
	f.Name
  FROM
  dbo.tblMAApplication maa
	JOIN dbo.tblMALicense mal ON maa.MAApplicationID = mal.MAApplicationID
    
	JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
	JOIN dbo.tblMAStrength mast ON mals.MAStrengthID = mast.MAStrengthID
	JOIN tblStrength s ON mast.StrengthID = s.StrengthID
	JOIN tblForm f ON s.formid = f.FormID
  WHERE
	maa.MAApplicationID = @MAApplicationID;
    
  DECLARE @Counter INT = 1;
  WHILE (@Counter <= (SELECT MAX(ID) FROM @Data))
  BEGIN

	DECLARE
	  @StrengthList NVARCHAR(256) = NULL,
	  @Name NVARCHAR(256) = (SELECT Strength FROM @Data WHERE ID = @Counter);

	SELECT
	  @StrengthList = (COALESCE((@StrengthList + ', '), '') + s.Name)	
	FROM	
	(
	  SELECT DISTINCT
		s.Name
	  FROM
		dbo.tblMAApplication maa
		  JOIN dbo.tblMALicense mal ON maa.MAApplicationID = mal.MAApplicationID
          
		  JOIN dbo.tblMALicenseScope mals ON mal.MALicenseID = mals.MALicenseID
		  JOIN dbo.tblMAStrength mast ON mals.MAStrengthID = mast.MAStrengthID
		  JOIN tblStrength s ON mast.StrengthID = s.StrengthID
		  JOIN tblForm f ON s.formid = f.FormID
		WHERE
		  maa.MAApplicationID = @MAApplicationID
		  AND f.Name = @Name
	) s;

	UPDATE @Data
	SET
	  Strength = (Strength + ' [' + @StrengthList + ']')
	WHERE
	  ID = @Counter;
    
	SET @Counter = (@Counter + 1);
  END


  DECLARE @List NVARCHAR(256);
  	
  SELECT
	@List = (COALESCE((@List + ', '), '') + Strength)
  FROM 
	@Data;
    
  RETURN @List;  

END



GO
GRANT EXECUTE ON  [dbo].[udf_MAApplication_GetStrengthList] TO [mp_db_execute]
GO
