SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[workstreamURL]
    (
      @BBOID INT ,
      @ObjectID INT ,
      @MAApplcationID INT = NULL
    )
RETURNS NVARCHAR(MAX)
AS
    BEGIN
        DECLARE @url NVARCHAR(MAX) = ''
        SELECT  @url = CASE WHEN @BBOID = 40
                            THEN '/PM/Projects/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            WHEN @BBOID = 48
                            THEN '/PM/LaunchWorkstreams/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            WHEN @BBOID = 78
                            THEN '/PM/DevWorkstreams/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            WHEN @BBOID = 82
                            THEN '/PM/TradeDressWorkstreams/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            WHEN @BBOID = 83
                            THEN '/MyPortfolio/main/ApplicationDetail.aspx?maappid='
                                 + CAST(@MAApplcationID AS NVARCHAR(40))
                                 + '&tab=Submissions'
                            WHEN @BBOID = 84
                            THEN '/PM/PivotalWorkstreams/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            WHEN @BBOID = 119
                            THEN '/PM/SNCWorkstreams/'
                                 + CAST(@ObjectID AS NVARCHAR(40))
                            ELSE ''
                       END
        RETURN @url
    END
GO
