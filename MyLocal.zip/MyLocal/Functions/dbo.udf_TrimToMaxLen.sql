SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_TrimToMaxLen] (@Str nvarchar(256), @MaxLen int)
RETURNS nvarchar(256)
AS

BEGIN

	-- If the MaxLen parameter is = -1, do not trim. MaxLen of 0, 1, 2, or 3 is invalid.
	IF @MaxLen < 4 OR @MaxLen > 256
	BEGIN
		RETURN(@Str)
	END
	
	IF LEN(@Str) > @MaxLen
		SET @Str = SUBSTRING(@Str, 1, @MaxLen - 3) + '...'

	RETURN @Str
END




GO
GRANT EXECUTE ON  [dbo].[udf_TrimToMaxLen] TO [mp_db_execute]
GO
