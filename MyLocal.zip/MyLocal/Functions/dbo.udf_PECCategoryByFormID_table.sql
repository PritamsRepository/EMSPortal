SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_PECCategoryByFormID_table] ( )
RETURNS TABLE
AS
RETURN
    

 /*********************************************************
Function to return a table containing one PEC Category Per Form ID

CREATED BY:	Robin Abramson
CREATE DATE:	9/24/2010

USAGE: select * FROM dbo.[udf_PECCategoryByFormID_table] ()

***********************************************************/
(
            SELECT  f.FormID,
                    MAX(pec.Name) AS PECCategory
            FROM    dbo.tblForm AS f
LEFT JOIN dbo.tblProductLinkKPI as plk on f.productID = plk.ProductID
                    LEFT JOIN dbo.[tblKPI] AS kpi ON kpi.[KPIID] = plk.KPIID
                    LEFT JOIN dbo.tblvalidkeyingredient AS vki ON vki.[ValidKeyIngredientID] = kpi.[ValidKeyIngredientID]
                    LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.[ValidPECCategoryID] = vki.[ValidPECCategoryID]
            WHERE   pec.[ValidPECCategoryID] IS NOT NULL
            GROUP BY f.FormID
           
);   
   

GO
