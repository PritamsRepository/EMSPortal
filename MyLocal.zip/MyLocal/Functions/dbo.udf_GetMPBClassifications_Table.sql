SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_GetMPBClassifications_Table] ( @ProductID INT )
RETURNS TABLE WITH SCHEMABINDING
AS
        RETURN
    SELECT  COALESCE(pec.Name, '[None]') AS pec, vki.Name AS keyIngredient
    FROM    dbo.tblForm f1
            JOIN dbo.tblProductLinkKPI AS plk ON f1.productID = plk.ProductID
            JOIN dbo.tblKPI kpi ON kpi.KPIID = plk.KPIID
            JOIN dbo.tblvalidkeyingredient AS vki ON vki.ValidKeyIngredientID = kpi.ValidKeyIngredientID
            LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
    WHERE   plk.ProductID = @ProductID
    GROUP BY pec.Name ,
            vki.Name
GO
