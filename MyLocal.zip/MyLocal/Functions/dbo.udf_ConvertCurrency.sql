SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ConvertCurrency] (@FromAmt DECIMAL(19,4), @FromValidCurrencyID INT, @ToValidCurrencyID INT, @ToEffectiveDate DATETIME)
RETURNS DECIMAL(19,4)
WITH SCHEMABINDING


AS

BEGIN

	DECLARE @ConversionFactor2USD decimal(12,4)
	DECLARE @ToAmt decimal(19,4)
	DECLARE @ReturnAmt DECIMAL(19,4)
	SET @ConversionFactor2USD = 0.0
	SET @ToAmt = 0.0
	SET @ReturnAmt = 0.0

	IF @FromValidCurrencyID = @ToValidCurrencyID
	-- No need to convert, just send back the original amount.
	BEGIN
			SET @ReturnAmt = @FromAmt
			RETURN(@ReturnAmt)
	END

	SELECT TOP 1
		@ConversionFactor2USD = er.[ConversionFactor2USD]
	FROM
		dbo.tblExchangeRate er
			INNER JOIN dbo.tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
	WHERE
		er.ValidCurrencyID = @FromValidCurrencyID AND
		erl.EffectiveDate = @ToEffectiveDate

	IF @@ROWCOUNT > 0
	BEGIN
		SET @ToAmt = @FromAmt / @ConversionFactor2USD

		SELECT TOP 1
			@ConversionFactor2USD = er.ConversionFactor2USD
		FROM
			dbo.tblExchangeRate er
				INNER JOIN dbo.tblExchangeRateLoad erl ON erl.ExRateLoadID = er.ExRateLoadID
		WHERE
			er.ValidCurrencyID = @ToValidCurrencyID AND
			erl.EffectiveDate = @ToEffectiveDate

		IF @@ROWCOUNT > 0
		BEGIN
			SET @ReturnAmt = @ToAmt * @ConversionFactor2USD
		END
	END

	RETURN(@ReturnAmt)

END





GO
GRANT EXECUTE ON  [dbo].[udf_ConvertCurrency] TO [mp_db_execute]
GO
