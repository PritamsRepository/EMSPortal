SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_UserNameByUserID] (
	@UserID int)
RETURNS nvarchar(256)
AS

BEGIN

DECLARE @FullName as nvarchar(256)

SELECT
		@FullName= su.[FullName] 
	FROM
		[dbo].[admin_SecUser] as su
	WHERE
		su.[UserID] = @UserID


RETURN @FullName

END


GO
GRANT EXECUTE ON  [dbo].[udf_UserNameByUserID] TO [mp_db_execute]
GO
