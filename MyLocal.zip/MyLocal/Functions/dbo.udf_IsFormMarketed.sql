SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_IsFormMarketed] (@FormID INT)
RETURNS BIT

AS
BEGIN

  RETURN
  (
	SELECT
	  (CASE WHEN COUNT(F.FormID) >= 1 THEN 1 ELSE 0 END) AS IsMarketed
	FROM
	  dbo.tblForm F
		JOIN dbo.tblStrength S ON F.FormID = S.FormID
		JOIN dbo.tblMAStrength MS ON S.StrengthID = MS.StrengthID
		JOIN dbo.tblMALicenseScope MALS ON MS.MAStrengthID = MALS.MAStrengthID			
		JOIN dbo.tblBusinessBaseStates BBS ON MALS.MarketStatusID = BBS.StateID
	WHERE
	  BBS.StateName = 'Marketed'
	  AND F.FormID = @FormID
  );
   
END

GO
GRANT EXECUTE ON  [dbo].[udf_IsFormMarketed] TO [mp_db_execute]
GO
