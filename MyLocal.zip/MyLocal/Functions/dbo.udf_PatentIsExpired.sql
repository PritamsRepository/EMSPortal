SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_PatentIsExpired]
(
    @PatentID INT
)
RETURNS BIT
AS
BEGIN

    DECLARE @RetVal BIT;
    SET @RetVal = 0;

    DECLARE @ExpiredStatus INT;
    SELECT @ExpiredStatus = dbo.udf_ExpiredPatentStatusTypeID();

    SELECT @RetVal = 1
    WHERE EXISTS
    (
        SELECT 1
        FROM pm.PatentStatus ps
            JOIN pm.PatentStatusLinkValidGrantedStatus psg
                ON psg.PatentStatusID = ps.PatentStatusID
        WHERE ps.PatentID = @PatentID
              AND psg.ValidGrantedStatusID = @ExpiredStatus
    );

    RETURN (@RetVal);
END;



GO
GRANT EXECUTE ON  [dbo].[udf_PatentIsExpired] TO [mp_db_execute]
GO
