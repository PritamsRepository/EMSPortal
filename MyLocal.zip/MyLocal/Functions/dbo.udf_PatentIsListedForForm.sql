SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_PatentIsListedForForm]
(
    @FormID INT,
    @PatentID INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @IsListed BIT;

    SELECT @IsListed = CASE
                           WHEN
    (
        SELECT SUM(CAST(slp.IsListed AS INT))
        FROM pm.PatentLinkStrength slp
            JOIN dbo.tblStrength s
                ON s.FormID = @FormID
            JOIN pm.Patent p
                ON p.PatentID = slp.PatentID
        WHERE p.PatentID = @PatentID
        HAVING SUM(CAST(slp.IsListed AS INT)) > 0
    )   > 0 THEN
                               1
                           ELSE
                               0
                       END;

    RETURN @IsListed;
END;

GO
GRANT EXECUTE ON  [dbo].[udf_PatentIsListedForForm] TO [mp_db_execute]
GO
