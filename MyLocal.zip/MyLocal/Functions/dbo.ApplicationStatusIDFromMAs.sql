SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[ApplicationStatusIDFromMAs]
(
    @MAApplicationID INT
)
RETURNS INT
AS
BEGIN
    DECLARE @Status NVARCHAR(MAX) = NULL;
    DECLARE @StatusID INT = NULL;

    SET @Status
        = CASE
              WHEN NOT EXISTS
                       (
                           SELECT 1 FROM dbo.tblMALicense WHERE MAApplicationID = @MAApplicationID
                       ) THEN
                  N'In Planning'
    -- If any child MA is Approved then the Application is Approved
    -- If none of the above is true, and any child MA is Renewal in Progress, then the Application is Approved.
    -- If the MA is in Withdrawal in Progress and has an Approval date then it should be treated as Approved, otherwise Pending.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND
                             (
                                 vls.NAME IN ( N'Approved', N'Renewal in Progress' )
                                 OR
                                 (
                                     vls.NAME = 'Withdrawal in Progress'
                                     AND mal.LicenseApprovalDate IS NOT NULL
                                 )
                             )
                   ) THEN
                  N'Approved'
              -- If none of the above is true, and any child MA is Notified, the Application is Notified
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Notified'
                   ) THEN
                  N'Notified'
              -- If none of the above is true, and any child MA is Tentatively Approved, the Application is Tentatively Approved
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Tentatively Approved'
                   ) THEN
                  N'Tentatively Approved'
              -- If none of the above is true, and any child MA is Registration Exempt, the Application is Registration Exempt
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Registration Exempt'
                   ) THEN
                  N'Registration Exempt'
              -- If none of the above is true, and any child MA is Suspended, the Application is Suspended.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Suspended'
                   ) THEN
                  N'Suspended'
    -- If none of the above is true, and any child MA is Pending Approval, the Application is Pending Approval.
    -- If the MA is in Withdrawal in Progress and has an Approval date then it should be treated as Approved, otherwise Pending.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND
                             (
                                 (vls.NAME = N'Pending Approval')
                                 OR
                                 (
                                     vls.NAME = 'Withdrawal in Progress'
                                     AND mal.LicenseApprovalDate IS NULL
                                 )
                             )
                   ) THEN
                  N'Pending Approval'
    -- If none of the above is true, and all MAs are Withdrawn, the Application is Withdrawn.
    -- if there is a mix of Archived and non-Archived MAs for a given Application, disregard the Archived statuses. That way, the remaining records will govern the status.  
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Withdrawn'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Withdrawn', N'Archived', N'Rejected' )
                           ) THEN
                  N'Withdrawn'
              -- If none of the above is true, and all MAs are Divested, the Application is Divested.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Divested'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Divested', N'Archived', N'Rejected' )
                           ) THEN
                  N'Divested'
              -- If none of the above is true, and all MAs are Expired, the Application is Withdrawn.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Expired'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Expired', N'Archived', N'Rejected' )
                           ) THEN
                  N'Withdrawn'
              -- If none of the above is true, and all MAs are Rejected, the Application is Rejected.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Rejected'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Rejected', N'Archived' )
                           ) THEN
                  N'Rejected'
              -- If none of the above is true, and all MAs are Consolidated, the Application is Consolidated.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Consolidated'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Consolidated', N'Archived' )
                           ) THEN
                  N'Consolidated'
              -- If none of the above is true, and all MAs are Contract Terminated, the Application is Contract Terminated.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Contract Terminated'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Contract Terminated', 'Archived' )
                           ) THEN
                  N'Contract Terminated'
              -- If none of the above is true, and all MAs are Archived, the Application is Archived.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Archived'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( 'Archived' )
                           ) THEN
                  N'Archived'
    -- If none of the above is true, and there is a mix of only Withdrawn/Divested/Expired,
    -- the Application will correspond to the most recent date (Withdrawn Date/Transfer Date/Expiration Date).
    -- Changed part
    -- Withdrawn
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME IN ( N'Withdrawn' )
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Withdrawn', N'Divested', N'Expired', N'Archived',
                                                           N'Rejected'
                                                         )
                           )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseWithdrawalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Withdrawn'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseExpiryDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Expired'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseExpiryDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Expired'
                   )   IS NULL
                   )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseWithdrawalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Withdrawn'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseTransferApprovalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseTransferApprovalDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )   IS NULL
                   ) THEN
                  N'Withdrawn'
              -- Divested
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME IN ( N'Divested' )
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Withdrawn', N'Divested', N'Expired', N'Archived',
                                                           N'Rejected'
                                                         )
                           )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseTransferApprovalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Divested'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseExpiryDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Expired'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseExpiryDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Expired'
                   )   IS NULL
                   )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseTransferApprovalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseWithdrawalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Withdrawn'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseWithdrawalDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Withdrawn'
                   )   IS NULL
                   ) THEN
                  N'Divested'
              -- Expired
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME IN ( N'Expired' )
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Withdrawn', N'Divested', N'Expired', N'Archived',
                                                           N'Rejected'
                                                         )
                           )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseExpiryDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Expired'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseTransferApprovalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseTransferApprovalDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )   IS NULL
                   )
                   AND
                   (
                   (
                       SELECT COALESCE(MAX(mal.LicenseWithdrawalDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Withdrawn'
                   )   >=
                   (
                       SELECT COALESCE(MAX(mal.LicenseExpiryDate), 0)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Expired'
                   )
                   OR
                   (
                       SELECT MAX(mal.LicenseTransferApprovalDate)
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = 'Divested'
                   )   IS NULL
                   ) THEN
                  N'Expired'

              -- If none of the above is true, and all MAs are Planned Submission, the Application should be Planned Submission.
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME = N'Planned Submission'
                   )
                   AND NOT EXISTS
                           (
                               SELECT 1
                               FROM dbo.tblMALicense mal
                                   JOIN dbo.tblValidLicenseStatus vls
                                       ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                               WHERE mal.MAApplicationID = @MAApplicationID
                                     AND vls.NAME NOT IN ( N'Planned Submission', N'Archived' )
                           ) THEN
                  N'Planned Submission'
              WHEN EXISTS
                   (
                       SELECT 1
                       FROM dbo.tblMALicense mal
                           JOIN dbo.tblValidLicenseStatus vls
                               ON vls.ValidLicenseStatusID = mal.ValidLicenseStatusID
                       WHERE mal.MAApplicationID = @MAApplicationID
                             AND vls.NAME IN ( N'Withdrawn' )
                   ) THEN
                  N'Withdrawn'
              ELSE
                  N'Archived'
          END;

    SELECT @StatusID = ValidApplicationStatusID
    FROM dbo.tblValidApplicationStatus
    WHERE Name = @Status;
    RETURN @StatusID;
END;
GO
