SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--If Application Type is either 
-- 'CE Mark' 
-- or like 'Medical Device - Class %' 
-- or 'Medical Device' and in EU
-- or 'Surgical Medical Device' and in EU set the Procedure Type to CE Mark Procedure
--Else
--Field ""Submission Route""
-- If countries are only ""BE, LU"" > Force to EU National - Warning: only if the Veeva Application Lead Market is BE or LU (see Lead Market rules) 
-- If Submission Route = ""Registration Exempt"" and ""National"" > if Lead Market is in the EU = EU National else (in europe not in EU) = National
-- If Submission Route = ""Decentralised (DCP)"" --> EU Decentralised Procedure
-- If Submission Route = ""Mutual Recognition (MRP)"" --> EU Mutual Recognition Procedure
-- Else --> Centralised Procedure"

--SELECT [dbo].[VeevaApplicationType](21652)


CREATE FUNCTION [dbo].[VeevaApplicationType]
(
    @MAApplicationID INT
)
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @Value NVARCHAR(MAX);

    SET @Value = N'not calculated';

    DECLARE @ApplicationType NVARCHAR(MAX);
    DECLARE @SubmissionRoute NVARCHAR(MAX);
    DECLARE @ApplicationNumber NVARCHAR(MAX);
    DECLARE @Region NVARCHAR(MAX);

    SET @Region =
    (
        SELECT STUFF(
               (
                   SELECT DISTINCT
                          ', ' + cg.Name
                   FROM dbo.tblCountryGroup cg
                       JOIN dbo.tblCountryLinkCountryGroup clcg
                           ON clcg.CountryGroupID = cg.CountryGroupID
                       JOIN dbo.tblMALicenseScope mals
                           ON mals.CountryID = clcg.CountryID
                       JOIN dbo.tblMALicense mal
                           ON mal.MALicenseID = mals.MALicenseID
                   WHERE mal.MAApplicationID = @MAApplicationID
                         AND cg.CountryGroupType = 'KeyMkt'
                   ORDER BY ', ' + cg.Name
                   FOR XML PATH('')
               ),
               1,
               2,
               ''
                    )
    );

    SELECT @ApplicationType = vat.NAME,
           @SubmissionRoute = sr.NAME,
           @ApplicationNumber = ma.ProcedureNumber
    FROM dbo.tblMAApplication ma
        JOIN dbo.tblValidApplicationType vat
            ON ma.ValidApplicationTypeID = vat.ValidApplicationTypeID
        JOIN dbo.tblSubmissionRoute sr
            ON sr.SubmissionRouteID = ma.SubmissionRouteID
    WHERE ma.MAApplicationID = @MAApplicationID;

    IF (@ApplicationType = 'CE Mark')
       OR (@ApplicationType LIKE 'Medical Device - Class %')
       OR
       (
           @MAApplicationID IN
           (
               SELECT mal2.MAApplicationID
               FROM dbo.tblMALicense mal2
                   JOIN dbo.tblMALicenseScope mals2
                       ON mals2.MALicenseID = mal2.MALicenseID
                   JOIN dbo.tblCountry c2
                       ON c2.CountryID = mals2.CountryID
               WHERE c2.Code IN ( 'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE',
                                  'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE'
                                )
           )
           --@Region = 'Europe'
           AND
           (
               @ApplicationType = 'Medical Device'
               OR @ApplicationType = 'Surgical Medical Device'
           )
       )
        SET @Value = N'CE Mark Procedure';

    ELSE IF (
                @SubmissionRoute = 'National'
                OR @SubmissionRoute = 'Registration Exempt'
            )
        IF (@Region = 'Europe')
            SET @Value = N'EU National';
        ELSE
            SET @Value = N'National';

    ELSE IF (@SubmissionRoute = 'Decentralised (DCP)')
        SET @Value = N'EU Decentralised Procedure';

    ELSE IF (@SubmissionRoute = 'Mutual Recognition (MRP)')
        SET @Value = N'EU Mutual Recognition Procedure';

    ELSE
        SET @Value = N'Centralized Procedure';

    RETURN @Value;
END;
GO
