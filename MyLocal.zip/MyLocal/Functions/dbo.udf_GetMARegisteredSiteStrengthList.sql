SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_GetMARegisteredSiteStrengthList] (@MASiteID INT)
RETURNS NVARCHAR(1000)

AS
BEGIN

  DECLARE @List AS NVARCHAR(1000);
  
  SELECT
	@List = (COALESCE((@List + ', '), '') + s.Name)
  FROM
  (
	SELECT DISTINCT
	  s.Name
	FROM
	  dbo.tblMARegisteredSite mars
		JOIN dbo.tblMALicenseScope mals ON mars.MALicenseScopeID = mals.MALicenseScopeID
		JOIN dbo.tblMAStrength mast ON mals.MAStrengthID = mast.MAStrengthID
		JOIN dbo.tblStrength s ON mast.StrengthID = s.StrengthID	
	WHERE
	  mars.MASiteID = @MASiteID
  ) s

  RETURN @List;

END


GO
GRANT EXECUTE ON  [dbo].[udf_GetMARegisteredSiteStrengthList] TO [mp_db_execute]
GO
