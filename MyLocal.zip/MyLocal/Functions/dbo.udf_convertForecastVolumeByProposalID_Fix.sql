SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




CREATE FUNCTION [dbo].[udf_convertForecastVolumeByProposalID_Fix] ( )
RETURNS @ForecastVolumes TABLE
    (
      ProposalID INT PRIMARY KEY CLUSTERED ,
      TotalAmount DECIMAL(19, 4)
    )

 /*********************************************************
Function to return a table containing forecastvolumes for
proposallist.

CREATED BY:	Robin Abramson
CREATE DATE:	8/19/2010

USAGE: select * FROM dbo.udf_convertForecastVolumeByProposalID ()

***********************************************************/
AS BEGIN
 
 
    DECLARE @MaxDate DATETIME
    SET @MaxDate = ( SELECT MAX(EffectiveDate)
                     FROM   dbo.tblExchangeRateLoad
                   )
                   
    INSERT  @ForecastVolumes
            SELECT  ProposalID,
                    TotalAmt2 = MAX(sub1.[TotalAmt2])
            FROM    ( SELECT    sf.[ForecastYear],
                                p.ProposalID,
                                SUM(dbo.udf_ConvertCurrency(sf.ForecastTurnover,
                                                            sf.ValidCurrencyID,
                                                            p.ValidCurrencyID,
                                                            ISNULL(erl.EffectiveDate, @MaxDate))) AS TotalAmt2
                      FROM      [dbo].[tblProposalSalesForecast] AS sf
                                JOIN [dbo].[tblProposalCountryInterest] AS ci ON ci.[PCountryInterestID] = sf.[PCountryInterestID]
                                JOIN [dbo].[tblCountryLinkCountryGroup] AS clcg ON clcg.[CountryID] = ci.[CountryID]
                                JOIN [dbo].[tblProposal] AS p ON p.[ProposalID] = ci.[ProposalID]
                                JOIN [dbo].[tblCountryGroup] AS cg ON cg.[CountryGroupID] = clcg.[CountryGroupID]
                                LEFT JOIN tblCandidate can ON can.CandidateID = p.CandidateID
                                LEFT JOIN tblPRBSession prbs ON prbs.PRBSessionID = can.TargetPRBSessionID
                                LEFT JOIN dbo.tblExchangeRateLoad AS erl ON erl.ExrateLoadId = prbs.ExRateLoadID
                      WHERE     p.[MarketCountryGroupID] = cg.[CountryGroupID]
                                
                      GROUP BY  sf.[ForecastYear],
                                p.ProposalID
                    ) AS sub1
            GROUP BY ProposalID
            --ORDER BY ProposalID
    RETURN ;
                

   END


GO
