SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_BBOUpdatesByDateByObjectID_TableValued] ( 
	@BBOCode nvarchar(10),
	@ObjectID int)
RETURNS @BBOUpdatesByDate TABLE
    (
	  ID int identity(1,1) PRIMARY KEY NOT NULL,
      ObjectID INT  NULL,
      UpdatedOn datetime  NULL,
      UpdatedBy NVARCHAR(100) NULL
    )
    WITH SCHEMABINDING
AS

BEGIN


INSERT INTO @BBOUpdatesByDate (ObjectID,UpdatedOn,UpdatedBy)
        

SELECT 
	a.objectID,
	a.Date AS updatedOn,
	dbo.udf_GetUserNameByUserID(a.UserID) AS UpdatedBy
	
FROM
	[dbo].[tblBusinessBaseObjectStateActions] AS a
	JOIN [dbo].[tblBusinessBaseObject] AS bbo ON bbo.[BBOID] = a.[BBOID]
	JOIN [dbo].[admin_SecUser] AS u ON u.[UserID] = a.[UserID]
WHERE
	bbo.[BBOCode] = @BBOCode AND
	a.[ObjectID] = @ObjectID
ORDER BY
	a.[Date] ASC

	RETURN;


END



GO
