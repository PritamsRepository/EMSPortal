SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_AttachmentCount] (@BBOName NVARCHAR(256), @ObjectID INT)
RETURNS int


AS
BEGIN
	DECLARE @retVal int
	SET @retVal = 0
	
	SELECT @retVal = count(a.AttachmentID) 
	FROM 
		dbo.tblAttachment a 
	JOIN 
		dbo.tblBusinessBaseObject bbo 
	ON 
		bbo.BBOID = a.BBOID 
	WHERE 
		a.ObjectID = @ObjectID 
	AND 
		bbo.BBOName = @BBOName
	
	RETURN @retVal			
END



GO
GRANT EXECUTE ON  [dbo].[udf_AttachmentCount] TO [mp_db_execute]
GO
