SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


 /*********************************************************
Function to return a table containing country and bit true or false
CREATED BY:	RDA
CREATE DATE:	8/26/2010

Sample USAGE: 
SELECT cg.CountryGroupID,cg.CountryGroupType,cg.Name,cg.CountryGroupTypeDescription
 FROM dbo.tblCountryGroup cg
join  dbo.[udf_UserHasPrivForCountry_TableValued](@UserID,@privcode) a ON a.countryID=cg.CountryID AND a.Privs=1

SELECT * from [dbo].[udf_UserHasPrivForCountry_TableValued] (3,'IP01')
select [dbo].[udf_UserHasPrivForCountry](3,'IP01', 148) from dbo.sysobjects

Updated On:		2011-01-11
Modified By:	JRG
Desc:			Changs to inline and added addiitonal exists
***********************************************************/
CREATE FUNCTION [dbo].[udf_UserHasPrivForCountry_TableValued]
    (
      @UserID INT,
      @PrivCode NVARCHAR(20)
    )
RETURNS  TABLE AS 
RETURN
SELECT DISTINCT CountryID, 
ISNULL((
SELECT DISTINCT 1
	FROM
		[dbo].[admin_SecPriv] as p 
		JOIN [dbo].[admin_SecRolePriv] as rp on p.PrivID = rp.PrivID
		JOIN [dbo].[admin_SecRole] as r on r.RoleID = rp.RoleID
		JOIN [dbo].[admin_SecUserRole] as ur on ur.RoleID = r.RoleID
		LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountry] as lc on ur.UserRoleID = lc.UserRoleID 
		LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountryGroup] as lcg on ur.UserRoleID = lcg.UserRoleID 
	WHERE
		ur.[UserID] = @UserID and
		p.[PrivCode] = @PrivCode and
		( ur.isUnrestricted = 'true' or
		  lc.CountryID = C.CountryID OR 
		  EXISTS (SELECT
		clcg.[CountryID]
	FROM
		[dbo].[tblCountryLinkCountryGroup] as clcg
	WHERE
		clcg.[CountryGroupID] = lcg.CountryGroupID AND
		clcg.[CountryID] = C.CountryID))  
),0) AS Privs		
		
		FROM dbo.tblCountry C



GO
