SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_REPORT_MAApplication_FormatXML] (@XML XML, @ReportType NVARCHAR(25))
RETURNS XML

AS
BEGIN

/* Remove unecessary columns. */
SET @XML.modify('delete (/report/item/MAApplicationID)');
SET @XML.modify('delete (/report/item/MALicenseID)');
SET @XML.modify('delete (/report/item/ValidSiteTypeID)');
SET @XML.modify('delete (/report/item/MASiteID)');
SET @XML.modify('delete (/report/item/MAApplicationCountries)');

/* Application */
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Name"}) into (/report/item/ApplicationName)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Type"}) into (/report/item/ApplicationType)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Product Group Name"}) into (/report/item/ProductGroupName)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Submission Route"}) into (/report/item/SubmissionRoute)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Development Route"}) into (/report/item/DevelopmentRoute)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Development Site"}) into (/report/item/DevelopmentSite)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Health Authority"}) into (/report/item/HealthAuthority)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Legal Category"}) into (/report/item/LegalCategory)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"MA Application Countries"}) into (/report/item/MAApplicationCountries)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"General Comment"}) into (/report/item/GeneralComment)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Regulatory Team"}) into (/report/item/RegulatoryTeam)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Regulatory Lead"}) into (/report/item/RegulatoryLead)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Global CC RA Lead"}) into (/report/item/GlobalCCRALead)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"SPP CF Reference Number"}) into (/report/item/SppCFReferenceNumber)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"SPP CF Approval Date"}, attribute isDate {"true"}) into (/report/item/SppCFApprovalDate)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Dossier Location"}) into (/report/item/PhysicalDossierLocation)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"MA Application Status"}) into (/report/item/MAApplicationStatus)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Submitter"}) into (/report/item/ApplicationSubmitter)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Common Renewal Date"}, attribute isDate {"true"}) into (/report/item/CommonRenewalDate)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"HA Decision Comment"}) into (/report/item/HADecisionComment)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Last Renewal Submission Date"}, attribute isDate {"true"}) into (/report/item/LastRenewalSubmissionDate)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Last Renewal Approval Date"}, attribute isDate {"true"}) into (/report/item/LastRenewalApprovalDate)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Estimated Renewal Submission Date"}, attribute isDate {"true"}) into (/report/item/EstimatedRenewalSubmissionDate)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Reviewed By"}) into (/report/item/ApplicationReviewedBy)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Reviewed On"}, attribute isDate {"true"}) into (/report/item/ApplicationReviewedOn)[1]');
SET @XML.modify('insert (attribute group {"Application" }, attribute header {"Application Reviewed Comment"}) into (/report/item/ApplicationReviewedComment)[1]');

/* License */
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA #"}) into (/report/item/LicenseNumber)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Country"}) into (/report/item/LicenseCountryOrHA)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Full Procedure Number"}) into (/report/item/FullProcedureNumber)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Holder Is Mylan?"}) into (/report/item/HolderIsMylan)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Is Marketed?"}) into (/report/item/IsMarketed)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"PV Responsibility"}) into (/report/item/PVResponsibility)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }) into (/report/item/Holder)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Product [Strength]"}) into (/report/item/ProductStrength)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Registered Product Name"}) into (/report/item/RegisteredProductName)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Responsible Agent"}) into (/report/item/ResponsibleAgent)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Mylan Ownership Date"}, attribute isDate {"true"}) into (/report/item/MylOwnershipDate)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Approval Date"}, attribute isDate {"true"}) into (/report/item/LicenseApprovalDate)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Expiry Date"}, attribute isDate {"true"}) into (/report/item/LicenseExpiryDate)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Withdrawal Date"}, attribute isDate {"true"}) into (/report/item/LicenseWithdrawalDate)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Withdrawal Reason"}) into (/report/item/WithdrawalReason)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Previous MA Holder"}) into (/report/item/PreviousLicenseHolder)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Transfer Approval Date"}, attribute isDate {"true"}) into (/report/item/LicenseTransferApprovalDate)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Status"}) into (/report/item/LicenseStatus)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Reference MA Holder"}) into (/report/item/ReferenceLicenseHolder)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"Reference MA #"}) into (/report/item/ReferenceLicenseNumber)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"BD Partner"}) into (/report/item/BDPartner)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Reviewed By"}) into (/report/item/LicenseReviewedBy)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Reviewed On"}, attribute isDate {"true"}) into (/report/item/LicenseReviewedOn)[1]');
SET @XML.modify('insert (attribute group {"Market Authorization" }, attribute header {"MA Reviewed Comment"}) into (/report/item/LicenseReviewedComment)[1]');

/* API */
IF (@ReportType = 'API' OR @ReportType IS NULL)
BEGIN
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"API Name"}) into (/report/item/APIName)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"API Manufacturer"}) into (/report/item/APIManufacturer)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"Is API Manufacturer Mylan?"}) into (/report/item/IsAPIManufacturerMylan)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"KPI Retest Period"}) into (/report/item/KPIRetestPeriod)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"Monograph Reference"}) into (/report/item/MonographReference)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"CEP DMF Reference"}) into (/report/item/CEPDMFReference)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"CEP DMF Reference Date"}, attribute isDate {"true"}) into (/report/item/CEPDMFRefDate)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"MA Reg Site KPI Comments"}) into (/report/item/MARegSiteKPIComments)[1]');
  SET @XML.modify('insert (attribute group {"API" }, attribute header {"MPB Classification"}) into (/report/item/MPBClassification)[1]');
END  

/* Marketing */
IF (@ReportType = 'Marketing' OR @ReportType IS NULL)
BEGIN
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Country"}) into (/report/item/ScopeCountry)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }) into (/report/item/Product)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }) into (/report/item/Strength)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"MA #"}) into (/report/item/LicenseNumberForMarketing)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Shelf Life"}) into (/report/item/ShelfLife)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Storage Condition"}) into (/report/item/StorageCondition)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Package Comment"}) into (/report/item/PackageComment)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }) into (/report/item/Packaging)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Marketing Status"}) into (/report/item/MarketingStatus)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Marketing Name"}) into (/report/item/MarketingName)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Marketing Company"}) into (/report/item/MarketingCompany)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Marketing Cessation Date"}, attribute isDate {"true"}) into (/report/item/MarketingCessationDate)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Product Launch Date"}, attribute isDate {"true"}) into (/report/item/ProductLaunchDate)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Transfer Schedule"}) into (/report/item/TransferSchedule)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Transfer Receiving Site"}) into (/report/item/TransferReceivingSite)[1]');
  SET @XML.modify('insert (attribute group {"Marketing" }, attribute header {"Actual Supply Chain Comments"}) into (/report/item/ActualSupplyChainComments)[1]');
END

/* Sites */
IF (@ReportType = 'Sites' OR @ReportType IS NULL)
BEGIN
  SET @XML.modify('insert (attribute group {"Sites" }, attribute header {"Site Type"}) into (/report/item/SiteType)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }, attribute header {"Site Name"}) into (/report/item/SiteName)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }) into (/report/item/Address)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }, attribute header {"Registered Name &amp; Address"}) into (/report/item/RegisteredAddress)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }) into (/report/item/Product)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }) into (/report/item/Strength)[1]');
  SET @XML.modify('insert (attribute group {"Sites" }) into (/report/item/Comment)[1]');
END

RETURN @XML;

END



GO
GRANT EXECUTE ON  [dbo].[udf_REPORT_MAApplication_FormatXML] TO [mp_db_execute]
GO
