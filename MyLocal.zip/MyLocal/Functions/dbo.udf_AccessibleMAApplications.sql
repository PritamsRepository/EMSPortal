SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE FUNCTION [dbo].[udf_AccessibleMAApplications]
(
    @UserID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
           maa.*
    FROM dbo.tblMAApplication maa
        JOIN dbo.tblSubmissionRoute sr
            ON maa.SubmissionRouteID = sr.SubmissionRouteID
        JOIN dbo.tblSubmissionRouteConfig src
            ON sr.SubmissionRouteID = src.SubmissionRouteID
        JOIN dbo.udf_UserHasPrivForCountry_TableValued(@UserID, 'MA01') p
            ON src.CountryID = p.CountryID
               AND p.Privs = 1
        JOIN dbo.udf_UserHasPrivForCountry_TableValued(@UserID, 'MA38') p2
            ON src.CountryID = p2.CountryID
    WHERE (
              sr.IsHADependent = 0
              OR
              (
                  sr.IsHADependent = 1
                  AND maa.HealthAuthorityID = src.HealthAuthorityID
              )
          )
          AND
          (
              p2.Privs = 1
              OR NOT EXISTS
    (
        SELECT 1
        FROM dbo.MAApplicationTag t
            JOIN dbo.tblValidBBOTag b
                ON b.ValidBBOTagID = t.ValidBBOTagID
        WHERE b.Tag = 'Migrated to Veeva'
              AND t.MAApplicationID = maa.MAApplicationID
    )
          )
);
GO
