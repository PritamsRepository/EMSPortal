SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_StrengthListByPatentID]
(
    @PatentID INT,
    @FormID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @StrengthList NVARCHAR(2000);

    SELECT @StrengthList = COALESCE(@StrengthList + ', ', '') + s.[Name]
    FROM([dbo].[tblStrength] AS s
        JOIN [pm].[PatentLinkStrength] AS link
            ON s.[StrengthID] = link.[StrengthID])
    WHERE link.[PatentID] = @PatentID
          AND s.[IsUndefined] = 'false'
          AND s.FormID = @FormID
    ORDER BY s.[Name];

    RETURN (@StrengthList);
END;



GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListByPatentID] TO [mp_db_execute]
GO
