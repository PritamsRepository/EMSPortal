SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[udf_StrengthListByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @StrengthList NVARCHAR(2000)

SELECT
		@StrengthList = COALESCE(@StrengthList + ', ', '') + [Name]
	FROM
		[dbo].[tblStrength] AS s
	WHERE
		s.[FormID] = @FormID AND
		s.[IsUndefined] = 'false'
	ORDER BY
		s.[Name]

RETURN(@StrengthList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_StrengthListByFormID] TO [mp_db_execute]
GO
