SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_DefaultCurrency] ()
RETURNS INT

AS

BEGIN

DECLARE @ValidCurrencyID int


set @ValidCurrencyID =(SELECT ValidCurrencyID FROM dbo.tblValidCurrency WHERE Name='USD')

RETURN (@ValidCurrencyID)


END
GO
GRANT EXECUTE ON  [dbo].[udf_DefaultCurrency] TO [mp_db_execute]
GO
