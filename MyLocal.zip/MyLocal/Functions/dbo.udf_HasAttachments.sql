SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_HasAttachments] (@BBOName NVARCHAR(256), @ObjectID INT)
RETURNS bit
AS
BEGIN
	DECLARE @retVal bit
	SET @retVal = 0
	
	IF EXISTS (SELECT a.AttachmentID FROM tblAttachment a INNER JOIN tblBusinessBaseObject bbo ON bbo.BBOID = a.BBOID WHERE a.ObjectID = @ObjectID AND bbo.BBOName = @BBOName )
		SET @retVal = 1
	
	RETURN @retVal			
END



GO
GRANT EXECUTE ON  [dbo].[udf_HasAttachments] TO [mp_db_execute]
GO
