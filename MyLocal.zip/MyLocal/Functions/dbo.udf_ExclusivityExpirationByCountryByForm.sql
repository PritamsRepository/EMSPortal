SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_ExclusivityExpirationByCountryByForm]
			(@CountryID INT, @FormID Int)
RETURNS NVARCHAR(256)
AS			
/*=============================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS
CREATED ON:				DEC 3, 2009
MODIFIED BY:
MODIFIED ON:	
PURPOSE:					To get the Exclusivity Expiration (formatted date) by country id by formid. 
								Intended to come from LegalInfo or other table that has this information.
===============================================================================
EXAMPLE:					dbo.udf_ExclusivityExpirationByCountryByForm (l.CountryID, l.FormID)
=============================================================================*/

BEGIN 
	DECLARE @ExclusivityExpiration NVARCHAR(256)
	
	SELECT 
		@ExclusivityExpiration = ISNULL(Min(replace(convert(nvarchar(11), ex.ExpiryDate, 106), ' ', '-')), 'None Noted') 
	FROM 
		pm.Exclusivity ex 
	WHERE 
		ex.CountryID = @CountryID AND 
		ex.Formid = @FormID
		
	RETURN(@ExclusivityExpiration)
END


GO
GRANT EXECUTE ON  [dbo].[udf_ExclusivityExpirationByCountryByForm] TO [mp_db_execute]
GO
