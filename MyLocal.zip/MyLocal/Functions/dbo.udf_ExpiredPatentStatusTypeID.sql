SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_ExpiredPatentStatusTypeID] ()
RETURNS int
AS

BEGIN
	DECLARE @ReturnValue int
	SET @ReturnValue = NULL

	SELECT
		@ReturnValue = ValidGrantedStatusID
	FROM
		tblValidGrantedStatus
	WHERE
		Name = 'Expired'

	Return( @ReturnValue)
		
END



GO
GRANT EXECUTE ON  [dbo].[udf_ExpiredPatentStatusTypeID] TO [mp_db_execute]
GO
