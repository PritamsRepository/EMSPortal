SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_ProposalRDCostByProductProposalID] ( @ProposalID INT )
RETURNS DECIMAL(20, 5)
    WITH SCHEMABINDING
AS
    BEGIN 
	
        DECLARE @sum DECIMAL(20, 5)
        DECLARE @apisum DECIMAL(20, 5)
		
        SELECT  @sum = SUM(ISNULL(prop.RDBiostudyCost, 0)
                           + ISNULL(prop.RDOverheadCost, 0)
                           + ISNULL(prop.RDRegulatoryCost, 0)
                           + ISNULL(prop.ClinicalCost, 0)
                           + ISNULL(prop.ZoneIVCosts, 0)
                           + ISNULL(prop.RDOtherCost, 0))
        FROM    pm.ProductProposal prop
        WHERE   prop.ProductProposalID = @ProposalID

        SELECT  @apisum = SUM(( ISNULL(CostPerUnit / 1000000, 0)
                                * ISNULL(NumOfUnits, 0) ))
        FROM    pm.ProductProposalAPI api
        WHERE   ProductProposalID = @ProposalID

        RETURN ISNULL(@sum, 0) + ISNULL(@apisum, 0)
END
GO
