SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_CountryListByUserRoleID] (@UserRoleID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

DECLARE @countryList NVARCHAR(2000)

SELECT
		@CountryList = COALESCE(@CountryList + ', ', '') + c.Name
	FROM
		[dbo].[admin_SecUserRoleLinkCountry] AS lc
		JOIN [dbo].[tblCountry] AS c ON c.[CountryID] = lc.[CountryID]
	WHERE
		lc.[UserRoleID] = @UserRoleID
	ORDER BY
		c.Name

RETURN(@countryList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_CountryListByUserRoleID] TO [mp_db_execute]
GO
