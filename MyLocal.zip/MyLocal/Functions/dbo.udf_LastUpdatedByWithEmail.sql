SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_LastUpdatedByWithEmail] ( 
	@BBOCode nvarchar(10),
	@ObjectID int)
RETURNS nvarchar(256)
AS

BEGIN

DECLARE @FullName as nvarchar(256)

SELECT TOP 1
	@FullName= [dbo].[udf_UserNameWithEmailByUserID]( a.[UserID])
FROM
	[dbo].[tblBusinessBaseObjectStateActions] AS a
	JOIN [dbo].[tblBusinessBaseObject] AS bbo ON bbo.[BBOID] = a.[BBOID]
WHERE
	bbo.[BBOCode] = @BBOCode AND
	a.[ObjectID] = @ObjectID
ORDER BY
	a.[Date] DESC

RETURN @FullName

END



GO
GRANT EXECUTE ON  [dbo].[udf_LastUpdatedByWithEmail] TO [mp_db_execute]
GO
