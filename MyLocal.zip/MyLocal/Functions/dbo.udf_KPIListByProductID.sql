SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_KPIListByProductID] (@ProductID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

	DECLARE @KPIList NVARCHAR(2000)

	SELECT
		@KPIList = COALESCE(@KPIList + ', ', '') + vki.[Name]  + IsNull(' ' + vs.[Name], '')
	FROM
		[dbo].[tblProductLinkKPI] AS plm 
		JOIN [dbo].[tblKPI] AS m ON plm.[KPIID] = m.[KPIID]
		JOIN tblValidKeyIngredient vki on vki.ValidKeyIngredientID = m.ValidKeyIngredientID
		LEFT OUTER JOIN tblValidSalt vs on vs.ValidSaltID = m.ValidSaltID
	WHERE
		plm.[ProductID] = @ProductID
	ORDER BY
		vki.[Name]

RETURN(@KPIList)

END


GO
GRANT EXECUTE ON  [dbo].[udf_KPIListByProductID] TO [mp_db_execute]
GO
