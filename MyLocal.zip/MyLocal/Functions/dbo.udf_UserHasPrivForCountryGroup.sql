SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_UserHasPrivForCountryGroup] (
	@UserID int, 
	@PrivCode nvarchar(20),
	@CountryGroupID int )
RETURNS bit
AS

BEGIN

DECLARE @Exists bit

	IF EXISTS (
		SELECT
			p.[PrivID]
		FROM
			[dbo].[admin_SecPriv] as p 
			JOIN [dbo].[admin_SecRolePriv] as rp on p.PrivID = rp.PrivID
			JOIN [dbo].[admin_SecRole] as r on r.RoleID = rp.RoleID
			JOIN [dbo].[admin_SecUserRole] as ur on ur.RoleID = r.RoleID
			LEFT OUTER JOIN [dbo].[admin_SecUserRoleLinkCountryGroup] as lcg on lcg.UserRoleID = ur.UserRoleID 
		WHERE
			ur.[UserID] = @UserID AND
			p.[PrivCode] = @PrivCode AND
			( ur.[IsUnrestricted] = 'true' OR
			  lcg.CountryGroupID = @CountryGroupID ) )
		SET @Exists = 1	
	ELSE
		SET @Exists = 0


RETURN(@Exists)

END


GO
GRANT EXECUTE ON  [dbo].[udf_UserHasPrivForCountryGroup] TO [mp_db_execute]
GO
