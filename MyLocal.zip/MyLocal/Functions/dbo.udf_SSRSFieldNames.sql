SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_SSRSFieldNames] (@ColumnList NVarchar(256))
-- Declares the table that is to be returned.
RETURNS @tmpSSRSFieldNames TABLE
(
	ColumnNames NVARCHAR(256),
	SSRSFieldName NVARCHAR(256)
)

AS
/*========================================================================================
CREATED BY:				SCOTT DEXTER				DATA ARCHITECT					SOFTWARE SPECIALISTS CONSULTANT
CREATED ON:				NOV 30, 2009			
MODIFIED BY:
MODIFIED ON:
PURPOSE:					The purpose of this function is to replace the temp table that was being used with the output
								from this function. This will lead to faster development as the temp table will not have  to be 
								put into every query. 
-------------------------------------------------------------------------------------------------------------------
EXAMPLE:					SELECT * FROM DBO.UDF_SSRSFIELDNAMES(@COLUMNLIST)
========================================================================================*/

BEGIN
		DECLARE @SSRSFieldNameList NVARCHAR(2000)
		DECLARE @SSRSFieldName NVARCHAR(256)
		DECLARE @tmpColumnList NVARCHAR(2000)
		DECLARE @ColumnNames NVARCHAR(256)
		DECLARE @Pos int
		DECLARE @ColNum int
		DECLARE @CommaValue VARCHAR(1)

		-- Use @tmpColumnList in order to not change the value stored in @ColumnList.
		SET @tmpColumnList = LTRIM(RTRIM(@ColumnList))+ ','
		SET @Pos = CHARINDEX(',', @tmpColumnList, 1)
		SET @ColNum = 0
		SET @CommaValue = ''
		SET @SSRSFieldName = ''
		SET @SSRSFieldNameList = ''

		IF REPLACE(@tmpColumnList, ',', '') <> ''
		BEGIN
			WHILE @Pos > 0
			BEGIN
				SET @ColumnNames = LTRIM(RTRIM(LEFT(@tmpColumnList, @Pos - 1)))
				IF @ColumnNames <> ''
				BEGIN
					-- Strip the brackets from @ColumnNames
					SET @ColumnNames = REPLACE(@ColumnNames, '[', '')
					SET @ColumnNames = REPLACE(@ColumnNames, ']', '')
					SET @SSRSFieldName = 'Column' + CAST(@ColNum AS NVARCHAR(2))
					INSERT INTO @tmpSSRSFieldNames (ColumnNames, SSRSFieldName) VALUES (@ColumnNames, @SSRSFieldName)
					-- Build the list of SSRS field names that will be used in the "IN" clause of the pivot query below.
					IF @ColNum > 0
					BEGIN
						SET @CommaValue = ','
					END
					SET @SSRSFieldNameList = @SSRSFieldNameList + @CommaValue + '[' + @SSRSFieldName + ']'
					-- increment the column counter.
					SET @ColNum = @ColNum + 1
				END
				SET @tmpColumnList = RIGHT(@tmpColumnList, LEN(@tmpColumnList) - @Pos)
				SET @Pos = CHARINDEX(',', @tmpColumnList, 1)
			END
		END
RETURN;
END



GO
GRANT SELECT ON  [dbo].[udf_SSRSFieldNames] TO [mp_db_execute]
GO
