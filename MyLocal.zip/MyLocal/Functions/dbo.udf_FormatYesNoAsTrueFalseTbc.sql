SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

Create FUNCTION [dbo].[udf_FormatYesNoAsTrueFalseTbc] 
(   
    @v int
)

RETURNS varchar(3)
AS
begin
	return 
	case
		when @v = 1 then 'Yes'
		when @v = 0 then 'No'
		else 'TBC'
	end
end
GO
