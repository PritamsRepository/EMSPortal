SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_MarketedStrengthListByBrandID]
(
    @CountryID INT,
    @BrandCompanyID INT,
    @FormID INT
)
RETURNS NVARCHAR(2000)
AS
BEGIN

    DECLARE @List NVARCHAR(2000);

    SELECT @List = COALESCE(@List + ', ', '') + cl.[Name]
    FROM
    (
        SELECT DISTINCT TOP 100 PERCENT
               CASE
                   WHEN vms.Category = 'Visible'
                        AND vms.Name = 'Is Marketed' THEN
                       s.[Name]
                   WHEN vms.Category = 'Visible' THEN
                       s.[Name] + ' (' + vms.Name + ')'
               END AS Name
        FROM dbo.tblBrandStrengthMarketing bsm
            JOIN dbo.tblBrand b
                ON b.BrandID = bsm.BrandID
            JOIN dbo.tblStrength s
                ON s.StrengthID = bsm.StrengthID
            JOIN dbo.tblForm f
                ON f.FormID = s.FormID
            LEFT JOIN dbo.tblValidMarketingStatus vms
                ON vms.ValidMarketingStatusID = bsm.ValidMarketingStatusID
        WHERE b.CountryID = @CountryID
              AND b.BrandCompanyID = @BrandCompanyID
              AND f.FormID = @FormID
        ORDER BY Name
    ) cl;

    RETURN (@List);
END;
GO
GRANT EXECUTE ON  [dbo].[udf_MarketedStrengthListByBrandID] TO [mp_db_execute]
GO
