SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[expandDigits]
(
    @src VARCHAR(1024),
    @plen INT,
    @letter CHAR(1)
)
RETURNS DECIMAL(20, 10)-- VARCHAR(MAX)
AS
BEGIN
    IF @plen >= 100
        RETURN @src;
    DECLARE @p INT,
            @p2 INT,
            @num VARCHAR(100);
    DECLARE @ret_val VARCHAR(MAX) = '';
    IF (PATINDEX('%[0-9.]%', @src) = 0)
        SET @ret_val = @src;
    ELSE
    BEGIN
        SET @p = PATINDEX('%[0-9.]%', @src);

        WHILE (@p > 0)
        BEGIN
            SET @p2 = PATINDEX('%[^0-9.]%', SUBSTRING(@src, @p, 1000));
            IF (@p2 > 0)
            BEGIN
                SET @num = SUBSTRING(@src, @p, @p2 - 1);
                SET @ret_val += LEFT(@src, @p - 1) + CASE
                                                         WHEN LEN(@num) < @plen THEN
                                                             RIGHT(REPLICATE(@letter, @plen) + @num, @plen)
                                                         ELSE
                                                             @num
                                                     END;;
                SET @src = SUBSTRING(@src, @p + @p2 - 1, LEN(@src));
                SET @p = PATINDEX('%[0-9.]%', @src);
            END;
            ELSE
            BEGIN
                SET @num = SUBSTRING(@src, @p, LEN(@src));
                SET @ret_val += LEFT(@src, @p - 1) + CASE
                                                         WHEN LEN(@num) < @plen THEN
                                                             RIGHT(REPLICATE(@letter, @plen) + @num, @plen)
                                                         ELSE
                                                             @num
                                                     END;
                SET @src = '';
                BREAK;
            END;

        END;
        IF LEN(@src) > 0
            SET @ret_val += @src;
    END;
    RETURN CONVERT(DECIMAL(20,10), @num) --@ret_val;
END;
GO
