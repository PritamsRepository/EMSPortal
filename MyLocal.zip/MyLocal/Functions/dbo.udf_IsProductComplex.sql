SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_IsProductComplex]
(
    @ProductID INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @count INT;

    SELECT @count = COUNT(*)
    FROM dbo.tblProductLinkKPI
    WHERE ProductID = @ProductID;

    IF (@count > 1)
        RETURN 1;

    RETURN 0;
END;
GO
