SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




------------------------------------------------------------------------------------------------------------------------
-- Create function
------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION [dbo].[udf_CountryListByFormID] (@FormID int)
RETURNS NVARCHAR(2000)
AS

BEGIN

	DECLARE @countryList NVARCHAR(2000);
	
	with cnWithSales (Country)
	as
	(
		select distinct c.Name
		from tblCountry c
			inner join tblsales s on s.CountryID = c.CountryID
			inner join tblSalesLoad sl on sl.SalesLoadID = s.SalesLoadID
		where sl.formid = @FormID
	)
	select @CountryList = COALESCE(@CountryList + ', ', '') + c.Country FROM cnWithSales c ORDER BY c.Country


	RETURN(@countryList)

END




GO
GRANT EXECUTE ON  [dbo].[udf_CountryListByFormID] TO [mp_db_execute]
GO
