SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [pm].[SNCWorkstreamCatalog_UnregisteredCountries]
(
    @SNCWorkstreamCatalogID INT
)
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @Countries NVARCHAR(MAX);

    IF NOT EXISTS
    (
        SELECT 1
        FROM pm.SNCWorkstreamCatalog sncwc
            JOIN dbo.tblValidSNCSiteType vscst
                ON vscst.ValidSNCSiteTypeID = sncwc.ValidSNCSiteTypeID
            JOIN dbo.tblValidSiteType vst
                ON vst.Name = vscst.Category
        WHERE sncwc.SNCWorkstreamCatalogID = @SNCWorkstreamCatalogID
    )
        SET @Countries = N'N/A';
    ELSE
    BEGIN
        DECLARE @count1 INT =
                (
                    SELECT COUNT(*)
                    FROM dbo.tblCountry c
                        JOIN pm.SNCWorkstreamLinkCountry sncc
                            ON sncc.CountryID = c.CountryID
                        JOIN pm.SNCWorkstreamCatalog sncwc
                            ON sncwc.SNCWorkstreamID = sncc.SNCWorkstreamID
                        JOIN pm.SNCWorkstream snc
                            ON snc.SNCWorkstreamID = sncc.SNCWorkstreamID
                        JOIN dbo.tblValidSNCSiteType vscst
                            ON vscst.ValidSNCSiteTypeID = sncwc.ValidSNCSiteTypeID
                        JOIN dbo.tblCompany cmp
                            ON sncwc.SiteID = cmp.CompanyID
                    WHERE sncwc.SNCWorkstreamCatalogID = @SNCWorkstreamCatalogID
                          AND sncwc.SiteID NOT IN
                              (
                                  SELECT rs.SiteID
                                  FROM pm.SNCWorkstreamLinkRimApplication link
                                      JOIN rim.RimRegisteredSite rs
                                          ON rs.ApplicationID = link.MAApplicationID
                                      JOIN rim.ApplicationLinkCountry alc
                                          ON alc.MAApplicationID = link.MAApplicationID
                                      JOIN dbo.tblValidSiteType vst2
                                          ON vst2.Category = rs.SiteType
                                      LEFT JOIN config.RIM_MyP_SiteTypeMap stm
                                          ON LTRIM(RTRIM(rs.SiteType)) = stm.RIMSiteType
                                      LEFT JOIN dbo.tblCompany c1
                                          ON rs.SiteID = c1.CompanyID
                                  WHERE link.SNCWorkstreamID = snc.SNCWorkstreamID
                                        AND alc.CountryID = c.CountryID
                                        AND
                                        (
                                            (
                                                rs.SiteID = cmp.CompanyID
                                                AND vst2.Category = vscst.Name-- vst2.Name
                                            )
                                            OR
                                            (
                                                c1.CompanyID = cmp.CompanyID
                                                AND stm.MyPSiteType = vst2.Name
                                            )
                                        )
                              )
                );
        --);
        DECLARE @count2 INT =
                (
                    SELECT COUNT(*)
                    FROM pm.SNCWorkstreamLinkCountry sncwlc
                        JOIN pm.SNCWorkstreamCatalog snccat
                            ON snccat.SNCWorkstreamID = sncwlc.SNCWorkstreamID
                    WHERE snccat.SNCWorkstreamCatalogID = @SNCWorkstreamCatalogID
                );
        IF (@count1 = @count2)
            SET @Countries = N'All';
        ELSE
            SELECT @Countries = STUFF(
                                (
                                    SELECT DISTINCT
                                           ', ' + c.Code
                                    FROM dbo.tblCountry c
                                        JOIN pm.SNCWorkstreamLinkCountry sncc
                                            ON sncc.CountryID = c.CountryID
                                        JOIN pm.SNCWorkstreamCatalog sncwc
                                            ON sncwc.SNCWorkstreamID = sncc.SNCWorkstreamID
                                        JOIN pm.SNCWorkstream snc
                                            ON snc.SNCWorkstreamID = sncc.SNCWorkstreamID
                                        JOIN dbo.tblValidSNCSiteType vscst
                                            ON vscst.ValidSNCSiteTypeID = sncwc.ValidSNCSiteTypeID
                                        JOIN dbo.tblCompany cmp
                                            ON sncwc.SiteID = cmp.CompanyID
                                    WHERE sncwc.SNCWorkstreamCatalogID = @SNCWorkstreamCatalogID
                                          AND sncwc.SiteID NOT IN
            (
                SELECT rs.SiteID
                FROM pm.SNCWorkstreamLinkRimApplication link
                    JOIN rim.RimRegisteredSite rs
                        ON rs.ApplicationID = link.MAApplicationID
                    JOIN rim.ApplicationLinkCountry alc
                        ON alc.MAApplicationID = link.MAApplicationID
                    JOIN dbo.tblValidSiteType vst2
                        ON vst2.Category = rs.SiteType
                    LEFT JOIN config.RIM_MyP_SiteTypeMap stm
                        ON LTRIM(RTRIM(rs.SiteType)) = stm.RIMSiteType
                    LEFT JOIN dbo.tblCompany c1
                        ON rs.SiteID = c1.CompanyID
                WHERE link.SNCWorkstreamID = snc.SNCWorkstreamID
                      AND alc.CountryID = c.CountryID
                      AND
                      (
                          (
                              rs.SiteID = cmp.CompanyID
                              AND vst2.Category = vscst.Name--vst2.Name
                          )
                          OR
                          (
                              c1.CompanyID = cmp.CompanyID
                              AND stm.MyPSiteType = vst2.Name
                          )
                      )
            )
                                    --(
                                    --    SELECT mas.CompanyID
                                    --    FROM dbo.tblMALicenseScope mals
                                    --        JOIN dbo.tblMARegisteredSite mars
                                    --            ON mars.MALicenseScopeID = mals.MALicenseScopeID
                                    --        JOIN dbo.tblMASite mas
                                    --            ON mas.MASiteID = mars.MASiteID
                                    --        JOIN dbo.tblValidSiteType vst
                                    --            ON vst.ValidSiteTypeID = mas.ValidSiteTypeID
                                    --        JOIN pm.SNCWorkstreamLinkMAApplication sncmaa
                                    --            ON sncmaa.MAApplicationID = mas.MAApplicationID
                                    --    WHERE sncmaa.SNCWorkstreamID = snc.SNCWorkstreamID
                                    --          AND mals.CountryID = c.CountryID
                                    --          AND vst.Category = vscst.Name
                                    --)
                                    ORDER BY ', ' + c.Code
                                    FOR XML PATH('')
                                ),
                                1,
                                2,
                                ''
                                     );
    END;
    RETURN @Countries;
END;
GO
