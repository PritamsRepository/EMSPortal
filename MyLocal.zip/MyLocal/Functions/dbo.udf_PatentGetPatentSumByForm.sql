SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_PatentGetPatentSumByForm]
(
    @FormID INT
)
RETURNS INT
AS
BEGIN
    DECLARE @PatentSum INT;

    SELECT @PatentSum = ISNULL(SUM(PatentCount), 0)
    FROM
    (
        SELECT COUNT(pat.PatentFamilyID) AS PatentCount
        FROM pm.Patent pat
            JOIN pm.PatentFamilyLinkForm pflf
                ON pflf.PatentFamilyID = pat.PatentFamilyID
        WHERE pflf.formid = @FormID
        GROUP BY pat.PatentFamilyID
    ) AS sub;

    RETURN @PatentSum;
END;


GO
GRANT EXECUTE ON  [dbo].[udf_PatentGetPatentSumByForm] TO [mp_db_execute]
GO
