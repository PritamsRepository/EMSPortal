SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO





/**************************************************************

CREATED BY:		Robin Abramson
CREATE DATE:	6/22/2010
PURPOSE:		Takes a comma delimited list of numbers and
				returns a table - eliminating the need for 
				dynamic SQL.
****************************************************************/

CREATE FUNCTION [dbo].[udf_inline_split_list_numeric]( @param nvarchar(MAX) )
RETURNS TABLE
    WITH SCHEMABINDING
AS
RETURN
    ( SELECT    Value = substring(@param, Number,
                                  charindex(',', @param + ',', Number)
                                  - Number)
      FROM      dbo.utility_Numbers
      WHERE     Number <= len(@param)
                AND substring(',' + @param, Number, 1) = ','
    ) 




GO
GRANT SELECT ON  [dbo].[udf_inline_split_list_numeric] TO [mp_db_execute]
GO
