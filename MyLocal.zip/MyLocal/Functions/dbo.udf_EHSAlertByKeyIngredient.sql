SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[udf_EHSAlertByKeyIngredient]
    (
      @ValidKeyIngredientID INT = NULL      
    )
RETURNS NVARCHAR(80) WITH SCHEMABINDING
AS
    BEGIN
        DECLARE @alert NVARCHAR(80) = NULL
        IF EXISTS ( SELECT  1
                    FROM    dbo.tblValidKeyIngredient AS vki
                            LEFT JOIN dbo.tblValidPECCategory AS pec ON pec.ValidPECCategoryID = vki.ValidPECCategoryID
                    WHERE   ( vki.ValidKeyIngredientID = @ValidKeyIngredientID
                              AND pec.Category = 'EHS Alert'
                            ) )
            SET @alert = 'OEB'
                                    
        IF EXISTS ( SELECT  1
                    FROM    dbo.ValidKeyIngredientLinkValidDrugClassification vkilvdc
                            LEFT JOIN dbo.tblValidDrugClassification vdc ON vdc.ValidDrugClassificationID = vkilvdc.ValidDrugClassificationID
                    WHERE   ( vkilvdc.ValidKeyIngredientID = @ValidKeyIngredientID
                              AND vdc.Category = 'EHS Alert'
                            ) )
            SET @alert = CASE WHEN @alert IS NULL THEN 'Drug Class'
                              ELSE @alert + ', Drug Class'
                         END
 
        IF EXISTS ( SELECT  1
                    FROM    dbo.ValidKeyIngredientLinkValidDeaControlledSchedule
                    WHERE   ValidKeyIngredientID = @ValidKeyIngredientID )
            SET @alert = CASE WHEN @alert IS NULL THEN 'API Controlled'
                              ELSE @alert + ', API Controlled'
                         END
        RETURN @alert
    END

GO
