SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[udf_AccessibleSubmissions] ( @UserID INT )
RETURNS TABLE
AS
     RETURN
    SELECT    DISTINCT
            MASubmissionWorkstreamID AS ID
    FROM    dbo.MASubmissionWorkstream masw
            JOIN dbo.tblMAApplication maa ON maa.MAApplicationID = masw.MAApplicationID
            JOIN dbo.tblSubmissionRoute sr ON maa.SubmissionRouteID = sr.SubmissionRouteID
            JOIN dbo.tblSubmissionRouteConfig src ON sr.SubmissionRouteID = src.SubmissionRouteID
            JOIN dbo.udf_UserHasPrivForCountry_TableValued(@UserID, 'MA01') p ON src.CountryID = p.CountryID
                                                              AND p.Privs = 1
    WHERE   sr.ISHADependent = 0
            OR ( sr.ISHADependent = 1
                 AND maa.HealthAuthorityID = src.HealthAuthorityID
               )
GO
