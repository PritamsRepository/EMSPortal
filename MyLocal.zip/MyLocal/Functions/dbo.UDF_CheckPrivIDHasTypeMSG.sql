SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[UDF_CheckPrivIDHasTypeMSG] ( @PrivID INT )
RETURNS BIT
AS 
    BEGIN

        DECLARE @RetVal BIT

        SET @RetVal = ( SELECT DISTINCT
                                1
                        FROM    dbo.admin_SecPriv
                        WHERE   PrivType = 'MSG'
                                AND PrivID = @PrivID
                      )

        RETURN ISNULL(@RetVal, 0)

    END
GO
GRANT EXECUTE ON  [dbo].[UDF_CheckPrivIDHasTypeMSG] TO [mp_db_execute]
GO
