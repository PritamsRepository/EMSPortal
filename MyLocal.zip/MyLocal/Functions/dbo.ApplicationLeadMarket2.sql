SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE FUNCTION [dbo].[ApplicationLeadMarket2]
(
    @MAApplicationID INT
)
RETURNS NVARCHAR(MAX)
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @Value NVARCHAR(MAX);

    SET @Value = N'not calculated';

    DECLARE @ApplicationType NVARCHAR(MAX);
    DECLARE @SubmissionRoute NVARCHAR(MAX);
    DECLARE @ApplicationNumber NVARCHAR(MAX);
--	DECLARE @VeevaApplicationType NVARCHAR(MAX)

    SELECT @ApplicationType = vat.NAME,
           @SubmissionRoute = sr.NAME,
           @ApplicationNumber = ma.ProcedureNumber --,
--		   @VeevaApplicationType = [dbo].[VeevaApplicationType](ma.MAApplicationID)
    FROM dbo.tblMAApplication ma
        JOIN dbo.tblValidApplicationType vat
            ON ma.ValidApplicationTypeID = vat.ValidApplicationTypeID
        JOIN dbo.tblSubmissionRoute sr
            ON sr.SubmissionRouteID = ma.SubmissionRouteID
    WHERE ma.MAApplicationID = @MAApplicationID;

    -- If Veeva Procedure Type = CE Mark Procedure > European Union
    -- If Submssion Route is Centralised (CP) > European Union
    -- PS: other cases (Countries = GHC + non EU countries) should be out of scope of wave 2 

    IF --(
         --  (@VeevaApplicationType = 'CE Mark Procedure')
           --OR
		   (@SubmissionRoute = 'Centralised (CP)')
       --)
        SET @Value = N'European Union';
    ELSE IF (
                @SubmissionRoute = 'Mutual Recognition (MRP)'
                OR @SubmissionRoute = 'Decentralised (DCP)'
            )
    BEGIN
        IF (@ApplicationNumber LIKE 'NAT%')
            SET @Value = N'Belgium';
        ELSE
        BEGIN
            SELECT @Value = c.Name
            FROM dbo.tblCountry c
                JOIN dbo.tblCountryLinkCountryGroup clcg
                    ON clcg.CountryID = c.CountryID
                JOIN dbo.tblCountryGroup cg
                    ON cg.CountryGroupID = clcg.CountryGroupID
                       AND cg.CountryGroupType = 'KeyMkt'
            WHERE SUBSTRING(@ApplicationNumber, 3, 1) = '/'
                  AND c.Code = LEFT(@ApplicationNumber, 2)
                  AND cg.Name = 'Europe';

            IF (LEFT(@ApplicationNumber, 2) = 'EL')
                SET @Value = N'Greece';
        END;
    END;
    -- If Subm Type = National > pick the country / if multiple Countries, pick the 1st one 
    ELSE IF (@SubmissionRoute = 'National')
        SELECT @Value = c.Name
        FROM dbo.tblCountry c
            JOIN dbo.tblMALicenseScope mals
                ON mals.CountryID = c.CountryID
            JOIN dbo.tblMALicense mal
                ON mal.MALicenseID = mals.MALicenseID
        WHERE mal.MAApplicationID = @MAApplicationID;

    IF (@Value = N'not calculated')
        SET @Value =
    (
        SELECT TOP (1)
               c.Name
        FROM dbo.tblCountry c
            JOIN dbo.tblMALicenseScope mals
                ON mals.CountryID = c.CountryID
            JOIN dbo.tblMALicense mal
                ON mal.MALicenseID = mals.MALicenseID
        WHERE mal.MAApplicationID = @MAApplicationID
        ORDER BY c.Name
    )   ;

    -- + special rule for UK - amongst the MAs under that Application:
    -- If 1 MA Comment contains ""MHRA Category 2 Product"" > pick ""United Kingdom - Category 2"" (country code = XI in Veeva)
    -- Else: pick United Kingdom - Category 1"
    IF (@Value = 'United Kingdom' OR @Value = 'Great Britain')
    BEGIN
        IF (@MAApplicationID IN
            (
                SELECT MAApplicationID
                FROM dbo.tblMALicense
                WHERE LicenseComment LIKE '%MHRA Category 2 Product%'
            )
           )
            SET @Value = N'United Kingdom - Category 2';
        ELSE
            SET @Value = N'United Kingdom - Category 1';
    END;
    IF (@Value = 'Netherlands')
        SET @Value = N'Netherlands (the)';
    IF (@Value = 'Kosovo')
        SET @Value = N'Republic of Kosovo';

    RETURN @Value;
END;
GO
