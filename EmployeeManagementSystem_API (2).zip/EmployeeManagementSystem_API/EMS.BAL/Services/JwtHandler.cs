﻿
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime.CompilerServices;
using System.Text;
using EMS_BAL.Interface;
using EMS_BAL.Model;
using System.Security.Claims;

namespace EMS_BAL.Services
{
    public class JwtHandler : IJwtHandler
    {
        private readonly JwtOptions _jwtOptions;
        private readonly JwtSecurityTokenHandler _jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
        private readonly SecurityKey _securityKey;
        private readonly SigningCredentials _signingCredentials;
        private readonly JwtHeader _jwtHeader;
        public JwtHandler (IOptions<JwtOptions> jwtOptions)
        {
            _jwtOptions = jwtOptions.Value;
            _securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.SecretKey));
            _signingCredentials = new SigningCredentials(_securityKey, SecurityAlgorithms.HmacSha256);
            _jwtHeader = new JwtHeader(_signingCredentials);
        }
        public JsonWebToken Create (string username, List<Role> roles)
        {
            var userClaims = new List<Claim>();
            foreach (var role in roles)
            {
                userClaims.Add(new Claim(ClaimTypes.Role, role.RoleName));
            }
            var nowUtc = DateTime.Now;
            var expires = nowUtc.AddMinutes(_jwtOptions.ExpiryMinutes);
            var centuryBegin = new DateTime(1970, 1, 1).ToUniversalTime();
            var exp = (long)(new TimeSpan(expires.Ticks - centuryBegin.Ticks).TotalSeconds);
            var iat = (long)(new TimeSpan(nowUtc.Ticks - centuryBegin.Ticks).TotalSeconds);

            var claims = new[]
            {
            new Claim(JwtRegisteredClaimNames.Sub,username),
            // this guarantees the token is unique
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            if (userClaims is object)
            {
                var claimList = new List<Claim>(claims);
                claimList.AddRange(userClaims);
                claims = claimList.ToArray();
            }

            //var payload = new JwtPayload
            //{

            //    {"sub", username},
            //    {"iss", _jwtOptions.Issuer},
            //    {"iat", iat},
            //    {"claims",claims},
            //    {"exp", exp},
            //    {"unique_name", username},

            //};
            var jwt = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
           audience: _jwtOptions.Audience,
           expires: DateTime.Now.AddMinutes(45),
           claims: claims,
           signingCredentials: _signingCredentials
       );
            // var jwt = new JwtSecurityToken(_jwtHeader, payload);
            var token = _jwtSecurityTokenHandler.WriteToken(jwt);
            return new JsonWebToken
            {
                AccessToken = token,
                Expires = exp
            };
        }
    }
}