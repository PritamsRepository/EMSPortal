﻿using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_BAL.Model;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static EMS.BAL.Model.MasterDetailCollections;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EMS.BAL.Services
{
    public class MastersServices : IMastersService
    {
        private IMastersRepository _MastersRepository;
        public MastersServices (IMastersRepository mastersRepository)
        {
            _MastersRepository = mastersRepository;

        }

        public List<DropdownKeyValue> GetRoleTypeData ()
        {
            var result = _MastersRepository.GetRoleTypeData(Convert.ToInt32( SessionManager.CurrentUser.Role_ID),SessionManager.CurrentUser.MID);

            var roledata = result
                 .Select(c => new DropdownKeyValue
                 {
                     ID = c.RoleTypeId.ToString(),
                     Name = c.RoleType,

                 }).ToList();
            //var role = new DropdownKeyValue()
            //{
            //    ID = "0",
            //    Name = "Select Role Type",
            //};
            //roledata.Insert(0, role);

            return roledata;
        }
        public List<DropdownKeyValue> GetLocationData ()
        {

            var locResult = _MastersRepository.loactionDetails();
            var locationData = locResult
                .Select(c => new DropdownKeyValue
                {
                    ID = c.LocationId.ToString(),
                    Name = c.LocationName,

                }).ToList();
            //var location = new DropdownKeyValue()
            //{
            //    ID = "0",
            //    Name = "Select Location",
            //};
            //locationData.Insert(0, location);

            return locationData;
        }
        public List<DropdownKeyValue> GetLocationDataByMID(string Username)
        {

            var locResult = _MastersRepository.GetLocationDataByID(Username);
            var locationData = locResult
                .Select(c => new DropdownKeyValue
                {
                    ID = c.LocationId.ToString(),
                    Name = c.LocationName,

                }).ToList();
            //var location = new DropdownKeyValue()
            //{
            //    ID = "0",
            //    Name = "Select Location",
            //};
            //locationData.Insert(0, location);

            return locationData;
        }
       
        public string GetLocationName(int locID)
        {
            return _MastersRepository.GetLocationName(locID);
        }

        public UserProfile GetEmployeeSearchDetails (string UserName)
        {
            UserProfile userprofile = null;
            try
            {
                string email = string.Empty;
                DirectorySearcher ds = new DirectorySearcher();
                SearchResult userProperty = ds.FindOne();
                SearchResult sresult;
                DirectoryEntry dsresult;

                if (!(string.IsNullOrEmpty(UserName.Trim())))
                {
                    ds.Filter = "(SAMAccountName=" + UserName.Trim() + ")";
                    sresult = ds.FindOne();
                    if (sresult != null)
                    {
                        userprofile = new UserProfile();
                        dsresult = sresult.GetDirectoryEntry();
                        userprofile.MID = dsresult.Properties["SAMAccountName"][0].ToString();
                        userprofile.Email = dsresult.Properties["mail"][0].ToString();
                        userprofile.DisplayName = dsresult.Properties["displayName"][0].ToString();
                    }
                    else
                    {
                        ds.Filter = "(mail=" + UserName.Trim() + ")";
                        sresult = ds.FindOne();
                        if (sresult != null)
                        {
                            userprofile = new UserProfile();
                            dsresult = sresult.GetDirectoryEntry();
                            userprofile.MID = dsresult.Properties["SAMAccountName"][0].ToString();
                            userprofile.Email = dsresult.Properties["mail"][0].ToString();
                            userprofile.DisplayName = dsresult.Properties["displayName"][0].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return userprofile;

        }
        public List<RoleTypeMaster> GetEmpRoleMappingData (string UserName,int LocationId)
        {
            var empdetails = new List<RoleTypeMaster>();
            var result = _MastersRepository.GetEmpRoleMappingData(UserName);

            if (result != null)
            {
                foreach (var data in result)
                {
                    var item = new RoleTypeMaster();
                    item.RoleTypeID = data.RoleTypeID;
                    item.RoleTypeName = data.RoleTypeName;
                    item.LocationName = data.LocationName;
                    item.MID = data.MID;  // Assuming Mid is the correct property name
                    item.Name = data.Name;
                    item.EmailID = data.EmailID;  // Correcting property name
                    item.IsPrimary =Convert.ToBoolean( data.IsPrimary);  // Correcting property name
                    item.IsActive = Convert.ToBoolean(data.IsActive);
                    empdetails.Add(item);
                }
            }
            return empdetails;
        }
        public void SaveEmployeeMappingDetails (string RoleType, string MID, string Name, string EmailID,List<string> SelectedLocation, bool IsPrimary, bool isactive)
        {
            _MastersRepository.SaveEmployeeMappingDetails(RoleType, MID, Name, EmailID, SelectedLocation, IsPrimary, isactive,SessionManager.CurrentUser.MID);
        }
        public bool DeactivateRoleMappingDetailsByID(int roleTypeID)
        {
           return _MastersRepository.DeactivateRoleMappingDetailsByID(roleTypeID);
        }
        
        public bool PrimaryRoleMappingDetailsByID(int roleTypeID)
        {
           var data= _MastersRepository.PrimaryRoleMappingDetailsByID(roleTypeID);
            return data;
        }
  
        public List<VendorMaster> Getvendormaster ()
        {
            var result = _MastersRepository.GetVendorMasterList();
            return result;
        }
        public List<ResourceModel> GetResourceByMID(string MID)
        {
            var resource = _MastersRepository.GetResourceByMID(MID);
            var resourcelist = new List<ResourceModel>();
            foreach (var contract in resource)
            {
                if (contract != null)
                {
                    var item = new ResourceModel();
                    item.RMID = contract.Rmid;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOJ = contract.Dojviatris;
                    item.DOB = contract.Dob;
                    item.MobileNumber = contract.MobileNo.ToString();
                    item.ManagerMid = contract.ManagerMid;

                    item.CostCenter = contract.CostCenterNo;
                    //  item.VendorID = contract.VendorId;
                    item.UploadedBy = contract.UploadedBy;
                    item.UploadedDate = contract.UploadDate;
                    resourcelist.Add(item);
                }
            }
            return resourcelist;

        }

        public MasterDetailCollections GetAllEMSMasterDetails()
        {

            var vendorMaster = _MastersRepository.GetVendorMasterList();
            var sowTypeMaster = _MastersRepository.GetSowTypeMasterList();
            var contractTypeMaster = _MastersRepository.GetContractMasterList();
            var billingTypeMaster = _MastersRepository.GetBillingMasterList();
            var verticalMaster = _MastersRepository.GetVerticalMasterList();
            var towerMaster = _MastersRepository.GetTowerMasterList();
            var projOrRunMaster = _MastersRepository.GetprojectOrRunMasterList();
            var skillSetMaster = _MastersRepository.GetSkillMasterList();
            var locationMaster = _MastersRepository.GetLocationData();
            var ObsMaster = _MastersRepository.GetOBSMasterList();

            var MasterDetails = new MasterDetailCollections
            {
                VendorMastersDetails = vendorMaster,
                SowTypeMastersDetails = sowTypeMaster,
                ContractTypeMastersDetails= contractTypeMaster,
                BillingTypeMastersDetails= billingTypeMaster,
                VerticalMastersDetails= verticalMaster,
                TowerMastersDetails= towerMaster,
                ProjOrRunMastersDetails = projOrRunMaster,
                SkillSetMastersDetails = skillSetMaster,
                LocationMastersDetails =    locationMaster,
                ObsMastersDetails   =   ObsMaster,
            };


            return MasterDetails;
        }

        public List<DropdownKeyValue> GetProjectorRunMaster ()
        {
            var projectRunMaster = _MastersRepository.GetprojectOrRunMasterList();
           
            var result = projectRunMaster
                .Select(c => new DropdownKeyValue
                {
                    ID = c.ProjectOrRunId.ToString(),
                    Name = c.ProjectOrRun,

                }).ToList();
            result.Insert(0, new DropdownKeyValue { ID = "0", Name = "All" });
            return result;
        }
    }
}
