﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Office2016.Presentation.Command;
using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Interface;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.Extensions.Configuration;
using NetTopologySuite.Mathematics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static EMS_BAL.Helper.Constants;

namespace EMS.BAL.Services
{
    public class ReportService : IReportService
    {
        private readonly IReportsRepository _reportsRepository;
        private readonly IConfiguration _configuration;
        private MailMessageTemplate _mailtemp;

        public ReportService ( IReportsRepository reportsRepository, IConfiguration configuration)
        {
            _reportsRepository = reportsRepository;
            _configuration = configuration;
            _mailtemp = new MailMessageTemplate(this._configuration);
        }
        public List<sp_EMS_ReportOpenPositionResult> GetOpenPositionReport (string reportType)
        {
            var result = _reportsRepository.GetOpenPositionReport(reportType);
            return result;
        }
        public async Task<List<sp_EMS_ContractDetailReportResult>> GetContractDetailReport (string reportType,int prId)
        {
            var result = await _reportsRepository.GetContractDetailReport(reportType, prId);
            return result;
        }

        public async Task<List<sp_EMS_ContractSummaryReportResult>> GetContractSummaryReport (string reportType, int prId)
        {
            var result = await _reportsRepository.GetContractSummaryReport(reportType, prId);
            return result;
        }
        public List<sp_EMS_ContractSummaryWithTowerHeadAndDomainReportResult> GetContractReportByToweHeadAndDomain(string TowerHead,string PrjOrRun)
        {
            var result =  _reportsRepository.GetContractReportByToweHeadAndDomain( TowerHead, PrjOrRun);
            return result;
        }
        public List<PublishedContractReport> SaveContractPublishedData(List<PublishedContractReport> result)
        {
            var tblList = new List<EmsTblPublishedContractReport>();
            foreach (var contract in result)
            {
                var item = new EmsTblPublishedContractReport();
                item.Domain = contract.DomainName;
                item.Towerlead = contract.TowerHead;
                item.TotalRequiredPositions = contract.TotalRequiredPositions;
                item.L1 = contract.L1Position;
                item.L1onboarded = contract.L1OnBoarder;
                item.L1openPostions = contract.L1Openposition;
                item.L1openedDate = contract.L1PositionOpenDate;
                item.L1selected = contract.L1Selected;
                item.L1backup = contract.L1BackUp;
                item.L1resourceDoj = contract.L1ResourceDOJ;
                item.L1ageingDays = contract.L1AgingDays;
                item.L2 = contract.L2Position;
                item.L2onboarded = contract.L2OnBoarder;
                item.L2openPositions = contract.L2Openposition;
                item.L2openDate = contract.L2PositionOpenDate;
                item.L2selected = contract.L2Selected;
                item.L2backup = contract.L2BackUp;
                item.L2resourceDoj = contract.L2ResourceDOJ;
                item.L2ageingDays = contract.L2AgingDays;
                item.L3 = contract.L3Position;
                item.L3onboarded = contract.L3OnBoarder;
                item.L3openPostions = contract.L3Openposition;
                item.L3openDate = contract.L3PositionOpenDate;
                item.L3selected = contract.L3Selected;
                item.L3backup = contract.L3BackUp;
                item.L3resourceDoj = contract.L3ResourceDOJ;
                item.L3ageingDays = contract.L3AgingDays;
                item.OverallOnboarded = contract.OverallOnboarded;
                item.OverallOpenPostion = contract.OverallOpenPostion;
                item.Overallselected = contract.Overallselected;
                item.Unfullfilled = contract.Unfullfilled==null?((contract.OverallOpenPostion==null?0: contract.OverallOpenPostion) - (contract.Overallselected==null?0: contract.Overallselected)) :contract.Unfullfilled;
                item.PublishedBy = SessionManager.CurrentUser.MID;
                item.PublishedDate = DateTime.Now;
                item.ProjOrRun = contract.projOrRun;
                item.CustomDomainName = contract.CustomDomainName;
                 tblList.Add(item);

            }
            _reportsRepository.SaveContractPublishedData(tblList, SessionManager.CurrentUser.MID);

           
            return null;
        }

        public List<EmsTblPublishedContractReport> GetpublishedContractDetails(string TowerHead, string PrjOrRun)
        {
            var result = _reportsRepository.GetpublishedContractDetails( TowerHead,  PrjOrRun);
            
            return result;
        }
        


       public List<PublishedContractReport> SaveContractPublishedDataWithMail(List<PublishedContractReport> result)
        {
            var tblList = new List<EmsTblPublishedContractReport>();
            foreach (var contract in result)
            {
                var item = new EmsTblPublishedContractReport();
                item.Domain = contract.DomainName;
                item.Towerlead = contract.TowerHead;
                item.TotalRequiredPositions = contract.TotalRequiredPositions;
                item.L1 = contract.L1Position;
                item.L1onboarded = contract.L1OnBoarder;
                item.L1openPostions = contract.L1Openposition;
                item.L1openedDate = contract.L1PositionOpenDate;
                item.L1selected = contract.L1Selected;
                item.L1backup = contract.L1BackUp;
                item.L1resourceDoj = contract.L1ResourceDOJ;
                item.L1ageingDays = contract.L1AgingDays;
                item.L2 = contract.L2Position;
                item.L2onboarded = contract.L2OnBoarder;
                item.L2openPositions = contract.L2Openposition;
                item.L2openDate = contract.L2PositionOpenDate;
                item.L2selected = contract.L2Selected;
                item.L2backup = contract.L2BackUp;
                item.L2resourceDoj = contract.L2ResourceDOJ;
                item.L2ageingDays = contract.L2AgingDays;
                item.L3 = contract.L3Position;
                item.L3onboarded = contract.L3OnBoarder;
                item.L3openPostions = contract.L3Openposition;
                item.L3openDate = contract.L3PositionOpenDate;
                item.L3selected = contract.L3Selected;
                item.L3backup = contract.L3BackUp;
                item.L3resourceDoj = contract.L3ResourceDOJ;
                item.L3ageingDays = contract.L3AgingDays;
                item.OverallOnboarded = contract.OverallOnboarded;
                item.OverallOpenPostion = contract.OverallOpenPostion;
                item.Overallselected = contract.Overallselected;
                item.Unfullfilled = contract.Unfullfilled;
                item.PublishedBy = SessionManager.CurrentUser.MID;
                item.PublishedDate = DateTime.Now;
                tblList.Add(item);

            }
            _reportsRepository.SaveContractPublishedData(tblList, SessionManager.CurrentUser.MID);

            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
            var vendorEmail = _reportsRepository.getvendorEmailIdForRun();
            using (var workbook = new XLWorkbook())
            {
                IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                worksheet.Columns(1, 29).Style.Font.FontColor = XLColor.Black;
                worksheet.Columns(1, 29).AdjustToContents();
                // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;
                worksheet.Cell(1, 1).Value = "Domain Name";
                worksheet.Cell(1, 2).Value = "Tower Head";
                worksheet.Cell(1, 3).Value = "Total Required positions";
                worksheet.Cell(1, 4).Value = "L1";
                worksheet.Cell(1, 5).Value = "L1 Onboarded";
                worksheet.Cell(1, 6).Value = "L1 OpenPositions";
                worksheet.Cell(1, 7).Value = "L1 PositionOpenDate";
                worksheet.Cell(1, 8).Value = "L1 Selected";
                worksheet.Cell(1, 9).Value = "L1 BackUp";
                worksheet.Cell(1, 10).Value = "L1 ResourceDOJ";
                worksheet.Cell(1, 11).Value = "L1 AgingDays";
                worksheet.Cell(1, 12).Value = "L2";
                worksheet.Cell(1, 13).Value = "L2 Onboarded";
                worksheet.Cell(1, 14).Value = "L2 OpenPositions";
                worksheet.Cell(1, 15).Value = "L2 PositionOpenDate";
                worksheet.Cell(1, 16).Value = "L2 Selected";
                worksheet.Cell(1, 17).Value = "L2 BackUp";
                worksheet.Cell(1, 18).Value = "L2 ResourceDOJ";
                worksheet.Cell(1, 19).Value = "L2 AgingDays";
                worksheet.Cell(1, 20).Value = "L3";
                worksheet.Cell(1, 21).Value = "L3 Onboarded";
                worksheet.Cell(1, 22).Value = "L3 OpenPositions";
                worksheet.Cell(1, 23).Value = "L3 PositionOpenDate";
                worksheet.Cell(1, 24).Value = "L3 Selected";
                worksheet.Cell(1, 25).Value = "L3 BackUp";
                worksheet.Cell(1, 26).Value = "L3 ResourceDOJ";
                worksheet.Cell(1, 27).Value = "L3 AgingDays";
                worksheet.Cell(1, 28).Value = "Overall Onboarded";
                worksheet.Cell(1, 29).Value = "Overall OpenPostion";
                worksheet.Cell(1, 30).Value = "Overall selected";
                worksheet.Cell(1, 31).Value = "Unfulfilled";


                for (int index = 1; index <= result.Count; index++)
                {
                    worksheet.Cell(index + 1, 1).Value = result[index - 1].DomainName;
                    worksheet.Cell(index + 1, 2).Value = result[index - 1].TowerHead;
                    worksheet.Cell(index + 1, 3).Value = result[index - 1].TotalRequiredPositions;
                    worksheet.Cell(index + 1, 4).Value = result[index - 1].L1Position;
                    worksheet.Cell(index + 1, 5).Value = result[index - 1].L1OnBoarder;
                    worksheet.Cell(index + 1, 6).Value = result[index - 1].L1Openposition;
                    worksheet.Cell(index + 1, 7).Value = result[index - 1].L1PositionOpenDate;
                    worksheet.Cell(index + 1, 8).Value = result[index - 1].L1Selected;
                    worksheet.Cell(index + 1, 9).Value = result[index - 1].L1BackUp;
                    worksheet.Cell(index + 1, 10).Value = result[index - 1].L1ResourceDOJ;
                    worksheet.Cell(index + 1, 11).Value = result[index - 1].L1AgingDays;
                    worksheet.Cell(index + 1, 12).Value = result[index - 1].L2Position;
                    worksheet.Cell(index + 1, 13).Value = result[index - 1].L2OnBoarder;
                    worksheet.Cell(index + 1, 14).Value = result[index - 1].L2Openposition;
                    worksheet.Cell(index + 1, 15).Value = result[index - 1].L2PositionOpenDate;
                    worksheet.Cell(index + 1, 16).Value = result[index - 1].L2Selected;
                    worksheet.Cell(index + 1, 17).Value = result[index - 1].L2BackUp;
                    worksheet.Cell(index + 1, 18).Value = result[index - 1].L2ResourceDOJ;
                    worksheet.Cell(index + 1, 19).Value = result[index - 1].L2AgingDays;
                    worksheet.Cell(index + 1, 20).Value = result[index - 1].L3Position;
                    worksheet.Cell(index + 1, 21).Value = result[index - 1].L3OnBoarder;
                    worksheet.Cell(index + 1, 22).Value = result[index - 1].L3Openposition;
                    worksheet.Cell(index + 1, 23).Value = result[index - 1].L3PositionOpenDate;
                    worksheet.Cell(index + 1, 24).Value = result[index - 1].L3Selected;
                    worksheet.Cell(index + 1, 25).Value = result[index - 1].L3BackUp;
                    worksheet.Cell(index + 1, 26).Value = result[index - 1].L3ResourceDOJ;
                    worksheet.Cell(index + 1, 27).Value = result[index - 1].L3AgingDays;
                    worksheet.Cell(index + 1, 28).Value = result[index - 1].OverallOnboarded;
                    worksheet.Cell(index + 1, 29).Value = result[index - 1].OverallOpenPostion;
                    worksheet.Cell(index + 1, 30).Value = result[index - 1].Overallselected;
                    worksheet.Cell(index + 1, 31).Value = result[index - 1].Unfullfilled;

                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();

                    objmails.Attachment = content;
                    objmails.To = vendorEmail ?? "";
                    objmails.Cc = "gidc.businessfinanceops@viatris.com";
                    objmails.From = "gidc.businessfinanceops@viatris.com";
                    objmails.Subject = "Other Requirements - Open Positions as on " + DateTime.Now;
                }
            }
            _mailtemp.SendTMContractApproval(objmails, "send run report to vendors ");



            return null;
        }


        public List<string> getTowerHeadMasterData()
        {
            var result = _reportsRepository.getTowerHeadMasterData();

            return result;
        }
        public async Task<List<SP_EMS_GetAllVendorContractsByDateResult>> GetAllVendorContractsByDate(string contractType)
        {
            var result = await _reportsRepository.GetAllVendorContractsByDate(contractType);
            return result;
        }

    }
}
