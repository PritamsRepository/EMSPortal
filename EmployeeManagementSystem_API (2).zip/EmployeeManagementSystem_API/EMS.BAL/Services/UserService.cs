﻿
using System.DirectoryServices;
using EMS_BAL.Interface;
using EMS_BAL.Model;
using EMS_BAL.Helper;
using System.Net;
using System;
using System.Reflection.Metadata.Ecma335;
using Microsoft.Extensions.Configuration;

namespace EMS_BAL.Services
{
    public class UserService : IUserService
    {
        private readonly IConfiguration _configuration;
        public UserService(IConfiguration _configuration)
        {
            this._configuration = _configuration;
        }
        private static string RUNNING_MODE = "Production";//_configuration.GetValue<string>("AppSettings:Mode");
       
        public UserProfile GetUserInfo (string userName, string password)
        {
            UserProfile userprofile = null;
            String domainAndUsername = userName + "@" + Constants.DOMAIN;
            string _path = Constants.AD_PATH;

            RUNNING_MODE = _configuration.GetValue<string>("AppSettings:Mode");

            switch (RUNNING_MODE)
            {
                case "Development":

                    try
                    {
                        DirectorySearcher ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(samAccountName=" + userName + "))" };
                        SearchResult userProperty = ds.FindOne();
                        if (userProperty is not null)
                        {
                            userprofile = new UserProfile();
                            userprofile.DisplayName = userProperty.Properties["displayName"][0].ToString();
                            userprofile.MID = userName;
                            userprofile.Email = userProperty.Properties["mail"][0].ToString();
                            userprofile.LastLogin = "First time";
                            userprofile.UnsuccessfulLogin = 0;
                            userprofile.UserId = Convert.ToInt32((userProperty.Properties["employeeID"][0].ToString()));
                        }
                    }
                    catch (Exception ex)
                    {
                        return null;
                    }

                    break;
                case "Production":
                    DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, password);
                    try
                    {
                        Object obj = entry.NativeObject;
                        DirectorySearcher search = new DirectorySearcher(entry)
                        {
                            Filter = "(SAMAccountName=" + userName + ")"
                        };
                        search.PropertiesToLoad.Add("cn");
                        SearchResult result = search.FindOne();

                        if (result is null)
                        {
                            return null;
                        }
                        //  _path = result.Path;

                        DirectoryEntry adObj = new DirectoryEntry(result.Path);
                         
                        if (adObj is not null)
                        {
                            try
                            {
                                userprofile = new UserProfile();
                                userprofile.UserId = Convert.ToInt32((adObj.Properties["employeeID"][0].ToString()));
                                userprofile.MID = userName;
                                userprofile.Email = adObj.Properties["mail"][0].ToString();
                                userprofile.FName = adObj.Properties["givenName"][0].ToString();
                                userprofile.LName = adObj.Properties["sn"][0].ToString();
                                userprofile.DisplayName = adObj.Properties["displayName"][0].ToString();
                                userprofile.Location = adObj.Properties["l"][0].ToString();

                            }
                            catch (Exception ex)
                            {


                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        return null;
                    }
                    break;
            }

            return userprofile;

        }

        public UserProfile GetUserInfoForWindowAuth(string userName) {
            UserProfile userprofile = null;
            String domainAndUsername = userName + "@" + Constants.DOMAIN;
            string _path = Constants.AD_PATH;
            try
            {
                DirectorySearcher ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(samAccountName=" + userName + "))" };
                SearchResult userProperty = ds.FindOne();
                if (userProperty is not null)
                {
                    userprofile = new UserProfile();
                    userprofile.DisplayName = userProperty.Properties["displayName"][0].ToString();
                    userprofile.MID = userName;
                    userprofile.Email = userProperty.Properties["mail"][0].ToString();
                    userprofile.LastLogin = "First time";
                    userprofile.UnsuccessfulLogin = 0;
                    userprofile.UserId = Convert.ToInt32((userProperty.Properties["employeeID"][0].ToString()));
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return userprofile;
        }


        public List<Tuple<string, string>> GetUserListByKey (string key)
        {
            var userList = new List<Tuple<string, string>>();
            DirectorySearcher ds;
            if (!string.IsNullOrEmpty(key))
            {


                switch (key.ToLower())
                {
                    case var s when key.Contains("viatris.com"):
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(mail=" + key + "))" };
                        break;
                    case var s when key.ToLower().StartsWith("m"):
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(samAccountName=" + key + "))" };
                        break;
                    default:
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(givenname=" + key + "))" };
                        break;
                }

                //DirectoryEntry searchRoot = new DirectoryEntry(Constants.AD_PATH);
                //DirectorySearcher search = new DirectorySearcher(searchRoot);
                //search.Filter = "(&(objectClass=user)(objectCategory=person))";
                //search.PropertiesToLoad.Add("samaccountname");
                //search.PropertiesToLoad.Add("mail");
                //search.PropertiesToLoad.Add("usergroup");
                //search.PropertiesToLoad.Add("displayname");//first name
                SearchResultCollection userProperty = ds.FindAll();

                SearchResult result;
                if (userProperty != null)
                {

                    for (int i = 0; i < userProperty.Count; i++)
                    {
                        result = userProperty[i];

                        var mid = result.Properties["samAccountName"][0].ToString() ?? "";
                        var name = result.Properties["displayName"][0].ToString() ?? "";
                        var user = new Tuple<string, string>(mid, name);
                        userList.Add(user);

                    }
                }

            }
            return userList;

        }
        public string GetUserNameByKey (string key)
        {

            DirectorySearcher ds;
            string UserName = string.Empty;

            if (!string.IsNullOrEmpty(key))
            {


                switch (key.ToLower())
                {
                    case var s when key.Contains("viatris.com"):
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(mail=" + key + "))" };
                        break;
                    case var s when key.ToLower().StartsWith("m"):
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(samAccountName=" + key + "))" };
                        break;
                    default:
                        ds = new DirectorySearcher { Filter = "(&(objectClass=user)(objectcategory=person)(givenname=" + key + "))" };
                        break;
                }
                SearchResult result = ds.FindOne();
                DirectoryEntry adObj = new DirectoryEntry(result.Path);
                if (adObj != null)
                {
                    var mid = adObj.Properties["samAccountName"][0].ToString() ?? "";
                    var name = adObj.Properties["displayName"][0].ToString() ?? "";
                    var email = adObj.Properties["mail"][0].ToString()??"";
                    UserName = string.Format("{0}: {1}: {2}", mid, name, email);


                }
            }
            return UserName;
        }
    }
}