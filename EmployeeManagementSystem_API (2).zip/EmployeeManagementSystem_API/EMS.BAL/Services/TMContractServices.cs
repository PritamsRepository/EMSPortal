﻿using AutoMapper.Execution;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Office2016.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.EntityFrameworkCore.Query.Internal;
using NetTopologySuite.Geometries;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics.Contracts;
using DocumentFormat.OpenXml.Office2010.Excel;
using System.Numerics;
using EMS_BAL.Services;
using EMS_BAL.Interface;
using NetTopologySuite.Operation.Overlay.Validate;
using DocumentFormat.OpenXml.Drawing.Spreadsheet;
using DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;
using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
using Microsoft.EntityFrameworkCore.Storage;

namespace EMS.BAL.Services
{
    public class TMContractServices : ITMContract
    {
        private ITMContractRepository _tMContractRepository;
        private IMastersRepository _masterRepository;
        private readonly IConfiguration _configuration;
        private MailMessageTemplate _mailtemp;
        private IUserService _UserService;
       

        public TMContractServices (ITMContractRepository tMContractRepository, IMastersRepository masterRepository, IConfiguration configuration, IUserService UserService)
        {
            _tMContractRepository = tMContractRepository;
             _masterRepository = masterRepository;
            this._configuration = configuration;
            _mailtemp = new MailMessageTemplate(this._configuration);
            _UserService = UserService;
            //_UserService = new UserService(this._configuration);

        }

        #region "T&M Uplaod Flow"
        public bool UploadTMContractData (List<EmsTblTmvendorContractIntermediateMaster> contracts, string mid,string location)
        {
            
            var tblList = new List<EmsTblTmvendorContractIntermediateMaster>();

            if (contracts != null)
            {

                foreach (var contract in contracts)
                {
                    var item = new EmsTblTmvendorContractIntermediateMaster();
                    item.Etwid = contract.Etwid;
                    item.Sownumber = contract.Sownumber.Trim();
                    item.Sowname = contract.Sowname.Trim();
                    item.VendorName = contract.VendorName.Trim();
                    item.PositionCode = contract.PositionCode.Trim();
                    item.PositionLocation = contract.PositionLocation.Trim();
                    item.OldSownumber = contract.OldSownumber.Trim();
                    item.Sowtype = contract.Sowtype.Trim();
                    item.SowstartDate = contract.SowstartDate;
                    item.SowendDate = contract.SowendDate;
                    item.Ponumber = contract.Ponumber.Trim();
                    item.PostartDate = contract.PostartDate;
                    item.PoendDate = contract.PoendDate;
                    item.PpmprojectId = contract.PpmprojectId.Trim();
                    item.PpmprojectName = contract.PpmprojectName.Trim();
                    item.Wbsdetail = contract.Wbsdetail.Trim();
                    item.Vertical = contract.Vertical.Trim();
                    item.DomainLeadEmail = contract.DomainLeadEmail.Trim();
                    item.CostCenter = contract.CostCenter.Trim();
                    item.Obs = contract.Obs.Trim();
                    item.DomainName = contract.DomainName.Trim();
                    item.SkillSet = contract.SkillSet.Trim();
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.ProjectOrRun = contract.ProjectOrRun.Trim();
                    item.ContractType = contract.ContractType.Trim();
                    item.BillingType = contract.BillingType.Trim();
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.BillingRateYear2 = contract.BillingRateYear2;
                    item.BillingRateYear3 = contract.BillingRateYear3;
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.Currency =contract.Currency.Trim();
                    item.RemappedMid = contract.RemappedMid.Trim();
                    item.Sapcode = contract.Sapcode.Trim();
                    item.NoticePeriod = contract.NoticePeriod;
                    //item.PositionLocation = contract.PositionLocation;
                    item.Tower = contract.Tower.Trim();
                    item.UploadDate = DateTime.Now;
                    item.UploadedBy = mid.Trim();
                    item.CustomDomainName = contract.CustomDomainName.Trim();
                    tblList.Add(item);
                }

                 _tMContractRepository.AddTMContractIntermediateAsync(tblList, mid,location);

            }

            return true;
        }

        public List<TMContract> GetTMContractIntermediateList (string mid)
        {
            var tmContractInt = new List<TMContract>();
            var result=_tMContractRepository.GetTMContractIntermediateList(mid);
            if(result != null)
            {
                foreach (var contract in result)
                {
                    var item= new TMContract();

                    item.TMCID=contract.TmcintId;
                    item.ETWID=contract.Etwid;
                    item.SOWNumber = contract.Sownumber;
                    item.SOWName=contract.Sowname;
                    item.SOWStartDate = contract.SowstartDate;
                    item.SOWEndDate = contract.SowendDate;
                    item.PONumber= contract.Ponumber;
                    item.POStartDate = contract.PostartDate;
                    item.POEndDate = contract.PoendDate;
                    item.SOWType=contract.Sowtype;
                    item.PPMProjectID=contract.PpmprojectId;
                    item.PPMProjectName=contract.PpmprojectName;    
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.BillingRateYear2 = contract.BillingRateYear2;  
                    item.BillingRateYear3= contract.BillingRateYear3;   
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.BillingType =   contract.BillingType;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate=contract.DomainSkillEndDate;
                    item.NoticePeriod=contract.NoticePeriod;
                    item.PositionCode=contract.PositionCode;  
                    item.PositionLocation=contract.PositionLocation;
                    item.SAPCode = contract.Sapcode;
                    item.WBSDetail = contract.Wbsdetail;
                    item.OBS = contract.Obs;
                    item.DomainSkillName = contract.DomainName;
                    item.VendorName = contract.VendorName;
                    item.Tower = contract.Tower;
                    item.ContractType = contract.ContractType;
                    item.SkillSet = contract.SkillSet;
                    item.RemappedMID = contract.RemappedMid;
                    item.ValidationRemarks= contract.ValidationRemarks;
                    item.OldSowNumber = contract.OldSownumber;
                    item.CostCenter=contract.CostCenter;
                    item.DomainLeadEmail = contract.DomainLeadEmail; 
                    item.Currency = contract.Currency;
                    item.Vertical = contract.Vertical;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.CustomDomainName = contract.CustomDomainName;
                 
                    
                    tmContractInt.Add(item);
                }
            }
            return tmContractInt;



        }

        public List<TmContractMain> GetTMContractMainList(string RecordType, int locId)
        {
            var tmContractMainList = new List<TmContractMain>();

            var result = _tMContractRepository.GetTMContractMainList(RecordType, locId);

            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new TmContractMain();
                    item.TMVCMID = contract.TMVCMID;
                    item.TMCMID = contract.TMCMID;
                    item.ETWID = contract.ETWID;
                    item.VendorName = contract.VendorName;
                    item.SowTypeName = contract.SowTypeName;
                    item.ContractTypeName = contract.ContractTypeName;
                    item.BillingTypeName = contract.BillingTypeName;
                    item.VerticalName = contract.VerticalName;
                    item.TowerName = contract.TowerName;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.SkillSet = contract.SkillSet;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.WBSDetail = contract.WBSDetail;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.Currency = contract.Currency;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.BillingRateYear2 = contract.BillingRateYear2;
                    item.BillingRateYear3 = contract.BillingRateYear3;
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.LocationName = contract.LocationName;
                    item.NoticePeriod = contract.NoticePeriod;
                    item.PositionCode = contract.PositionCode;
                    item.OldSOWNumber = contract.OldSOWNumber;
                    item.RemappedMID = contract.RemappedMID;
                    item.SAPCode = contract.SAPCode;
                    item.CostCenter = contract.CostCenter;
                    item.OBS = contract.OBS;
                    item.Status = contract.Status;
                    item.PendingWithWhom = contract.PendingWithWhom;
                    item.WFOrder = contract.WFOrder;
                    item.IsActive = contract.IsActive;
                    item.UploadedBy = contract.UploadedBy;
                    item.UploadedDate = contract.UploadedDate;
                    item.CustomDomainName = contract.CustomDomainName;


                    tmContractMainList.Add(item);
                }
            }



            //if (result != null)
            //{
            //    tmContractMainList = (from contract in result
            //                          select new TmContractMain
            //                          {
            //                              TMVCMID = contract.TMVCMID,
            //                              TMCMID = contract.TMCMID,
            //                              ETWID = contract.ETWID,
            //                              VendorName = contract.VendorName,
            //                              SowTypeName = contract.SowTypeName,
            //                              ContractTypeName = contract.ContractTypeName,
            //                              BillingTypeName = contract.BillingTypeName,
            //                              VerticalName = contract.VerticalName,
            //                              TowerName = contract.TowerName,
            //                              ProjectOrRun = contract.ProjectOrRun,
            //                              SkillSet = contract.SkillSet,
            //                              SOWNumber = contract.SOWNumber,
            //                              SOWName = contract.SOWName,
            //                              SOWStartDate = contract.SOWStartDate,
            //                              SOWEndDate = contract.SOWEndDate,
            //                              PONumber = contract.PONumber,
            //                              POStartDate = contract.POStartDate,
            //                              POEndDate = contract.POEndDate,
            //                              PPMProjectID = contract.PPMProjectID,
            //                              PPMProjectName = contract.PPMProjectName,
            //                              WBSDetail = contract.WBSDetail,
            //                              DomainLeadEmail = contract.DomainLeadEmail,
            //                              DomainName = contract.DomainName,
            //                              DomainSkillStartDate = contract.DomainSkillStartDate,
            //                              DomainSkillEndDate = contract.DomainSkillEndDate,
            //                              Currency = contract.Currency,
            //                              BillingRateYear1 = contract.BillingRateYear1,
            //                              BillingRateYear2 = contract.BillingRateYear2,
            //                              BillingRateYear3 = contract.BillingRateYear3,
            //                              BillingRateYear4 = contract.BillingRateYear4,
            //                              BillingRateYear5 = contract.BillingRateYear5,
            //                              LocationName = contract.LocationName,
            //                              NoticePeriod = contract.NoticePeriod,
            //                              PositionCode = contract.PositionCode,
            //                              OldSOWNumber = contract.OldSOWNumber,
            //                              RemappedMID = contract.RemappedMID,
            //                              SAPCode = contract.SAPCode,
            //                              CostCenter = contract.CostCenter,
            //                              OBS = contract.OBS,
            //                              Status = contract.Status,
            //                              PendingWithWhom = contract.PendingWithWhom,
            //                              WFOrder = contract.WFOrder,
            //                              IsActive = contract.IsActive,
            //                              UploadedBy = contract.UploadedBy,
            //                              UploadedDate = contract.UploadedDate
            //                          }).ToList();
            //}

            return tmContractMainList;
        }

        private string alterContractStatus(string status)
        {
            if(status != null) 
            { 
                return status == "Open" ? "Position Open" : status == "Closed" ? "Position Onboarded" : "Pending";
            }
            return status;
        }

        public bool SaveTMIntDataToMain(List<int> tmIntID, string mid, string name, bool isProcLead, int locId)
        {

            //Validate the Intermediate table with main table before saving the T&M Records.
            //var valResult = _tMContractRepository.validateTmIntermediateTable(1);

            //Saving TM Intermediate Records to main table after validation and sending mail.
            //if (valResult.Result == true)
            //{
                 _tMContractRepository.SaveTMIntermediateDataToMain(tmIntID, mid, name, isProcLead, locId);

                //if(res == true)
                //{
                    MailMessageDetails objmails = new MailMessageDetails();

                    var IT_Finacnce_Manager = _masterRepository.GetrolesbyRoleType("IT Finance Manager", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
                    var PMO_Contract_Mgm = _masterRepository.GetrolesbyRoleType("PMO-Contract-Mgm", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
                    objmails.To = string.Join(", ", IT_Finacnce_Manager);
                    objmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                    objmails.Subject = "Time & Material Contracts For Approval.";
                    objmails.Cc = string.Join(", ", PMO_Contract_Mgm);
                    _mailtemp.GenerateAndSendMail(objmails);
                //}

            //}


            return true;
        }

        public bool DeleteTMIntData(List<int> tmIntID)
        {
            var result = _tMContractRepository.DeleteTMIntermediateData(tmIntID);
            return result;
        }

        public bool DeleteTMSBData(int tmIntID, string mid, string name, string remarks)
        {
            var result = _tMContractRepository.DeleteTMSendbackData(tmIntID, mid, name,remarks);
            return result;
        }

        public string UpdateApprovedTmContractDetails(TMContractMaster tmDetails, string mid, int locId)
        {
            TimeZoneInfo istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            //var update =  _tMContractRepository.UpdateTmContractDetails(tmDetails, mid);
            var timeMatDetails = new EmsTblTmvendorContractMaster()
            {
                Tmcmid = tmDetails.Tmcmid,
                Tmvcmid = tmDetails.Tmvcmid,
                Etwid = tmDetails.Etwid,
                Sownumber = tmDetails.Sownumber,
                Sowname = tmDetails.Sowname,
                VendorId = tmDetails.VendorId,
                PositionCode = tmDetails.PositionCode,
                PositionLocationId = tmDetails.PositionLocationId,
                OldSownumber = tmDetails.OldSownumber,
                SowtypeId = tmDetails.SowtypeId,
                SowstartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowstartDate, istTimeZone),
                SowendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowendDate, istTimeZone),
                Ponumber = tmDetails.Ponumber,
                PostartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PostartDate, istTimeZone),
                PoendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PoendDate, istTimeZone),
                PpmprojectId = tmDetails.PpmprojectId,
                PpmprojectName = tmDetails.PpmprojectName,
                Wbsdetail = tmDetails.Wbsdetail,
                VerticalId = tmDetails.VerticalId,
                DomainLeadEmail = tmDetails.DomainLeadEmail,
                CostCenter = tmDetails.CostCenter,
                Obs = tmDetails.Obs,
                DomainName = tmDetails.DomainName,
                SkillSetId = tmDetails.SkillSetId,
                DomainSkillStartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillStartDate, istTimeZone),
                DomainSkillEndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillEndDate, istTimeZone),
                ProjectOrRunId = tmDetails.ProjectOrRunId,
                ContractTypeId = tmDetails.ContractTypeId,
                BillingTypeId = tmDetails.BillingTypeId,
                BillingRateYear1 = tmDetails.BillingRateYear1,
                BillingRateYear2 = tmDetails.BillingRateYear2,
                BillingRateYear3 = tmDetails.BillingRateYear3,
                BillingRateYear4 = tmDetails.BillingRateYear4,
                BillingRateYear5 = tmDetails.BillingRateYear5,
                Currency = tmDetails.Currency,
                RemappedMid = tmDetails.RemappedMid,
                Sapcode = tmDetails.Sapcode,
                NoticePeriod = tmDetails.NoticePeriod,
                TowerId = tmDetails.TowerId,
                UpdatedBy = mid,
                CustomDomainName = tmDetails.customDomainName
            };
            var update = _tMContractRepository.ValidateAndSaveApprovedContract(timeMatDetails, mid,locId, tmDetails.remarks);

            return string.Join(", ", update);
        }

        public string UpdateTmContractDetails(TMContractMaster tmDetails, string mid,string name,bool isProcLead,int locId)
        {
            TimeZoneInfo istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            //var update =  _tMContractRepository.UpdateTmContractDetails(tmDetails, mid);
            var timeMatDetails = new EmsTblTmvendorContractMaster()
            {
                Tmcmid = tmDetails.Tmcmid,
                Tmvcmid = tmDetails.Tmvcmid,
                Etwid = tmDetails.Etwid,
                Sownumber = tmDetails.Sownumber,
                Sowname = tmDetails.Sowname,
                VendorId = tmDetails.VendorId,
                PositionCode = tmDetails.PositionCode,
                PositionLocationId = tmDetails.PositionLocationId,
                OldSownumber = tmDetails.OldSownumber,
                SowtypeId = tmDetails.SowtypeId,
                SowstartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowstartDate, istTimeZone),
                SowendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowendDate, istTimeZone),
                Ponumber = tmDetails.Ponumber,
                PostartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PostartDate, istTimeZone),
                PoendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PoendDate, istTimeZone),
                PpmprojectId = tmDetails.PpmprojectId,
                PpmprojectName = tmDetails.PpmprojectName,
                Wbsdetail = tmDetails.Wbsdetail,
                VerticalId = tmDetails.VerticalId,
                DomainLeadEmail = tmDetails.DomainLeadEmail,
                CostCenter = tmDetails.CostCenter,
                Obs = tmDetails.Obs,
                DomainName = tmDetails.DomainName,
                SkillSetId = tmDetails.SkillSetId,
                DomainSkillStartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillStartDate, istTimeZone),
                DomainSkillEndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillEndDate, istTimeZone),
                ProjectOrRunId = tmDetails.ProjectOrRunId,
                ContractTypeId = tmDetails.ContractTypeId,
                BillingTypeId = tmDetails.BillingTypeId,
                BillingRateYear1 = tmDetails.BillingRateYear1,
                BillingRateYear2 = tmDetails.BillingRateYear2,
                BillingRateYear3 = tmDetails.BillingRateYear3,
                BillingRateYear4 = tmDetails.BillingRateYear4,
                BillingRateYear5 = tmDetails.BillingRateYear5,
                Currency = tmDetails.Currency,
                RemappedMid = tmDetails.RemappedMid,
                Sapcode = tmDetails.Sapcode,
                NoticePeriod = tmDetails.NoticePeriod,
                TowerId = tmDetails.TowerId,
                //UpdatedDate = DateTime.Now,
                UpdatedBy = mid,
                CustomDomainName = tmDetails.customDomainName
            };
            var update =  _tMContractRepository.ValidateAndSaveContract(timeMatDetails, mid,name,isProcLead,locId,tmDetails.remarks);
            if(update.Contains("Contract saved successfully"))
            {
                // var updateNext = _tMContractRepository.NextProcessOfSaveTMDataAfterSendback(mid, name, isProcLead, locId,tmDetails.Tmvcmid);

                //if(updateNext.Result == true)
                //{
                MailMessageDetails objmails = new MailMessageDetails();

                var IT_Finacnce_Manager = _masterRepository.GetrolesbyRoleType("IT Finance Manager", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
                var PMO_Contract_Mgm = _masterRepository.GetrolesbyRoleType("PMO-Contract-Mgm", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
                objmails.To = string.Join(", ", IT_Finacnce_Manager);
                objmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                objmails.Subject = "Time & Material Contracts For Approval.";
                objmails.Cc = string.Join(", ", PMO_Contract_Mgm);
                _mailtemp.GenerateAndSendMail(objmails);
                //}
            }

            return string.Join(", ", update);
        }

        public List<TmContractMain> GetTMSendbackDetails (string mid, string RecordType ,int locId)
        {
            var tmSendbackContractMainList = new List<TmContractMain>();
            // var tmList = GetTMContractMainList().Where(x => x.WFOrder == 0 && x.IsActive == true).ToList();
            var tmList = _tMContractRepository.GetTMContractMainList(RecordType, locId).Where(x => x.IsActive == true && x.WFOrder == 0).ToList();

            var userName = _UserService.GetUserNameByKey(mid);
            if (tmList != null)
            {
                List<int?> TMVCMID = new List<int?>();
                TMVCMID = tmList.Select(x => (int?)x.TMVCMID).ToList();

                var sendBackList = _tMContractRepository.GetTmSendbackedListFromWorkFlow(TMVCMID);

                var sendBackListFiltered = sendBackList.Where(cwf => cwf.Action == "Sentback").GroupBy(cwf => cwf.Tmcid).Select(group => group.OrderByDescending(cwf => cwf.Tmwfid).First()).ToList();


                tmSendbackContractMainList = (from vc in tmList.AsEnumerable()
                                              join sl in sendBackListFiltered.AsEnumerable() on vc.TMVCMID equals sl.Tmcid
                                              select new TmContractMain
                                              {
                                                  TMVCMID = vc.TMVCMID,
                                                  TMCMID = vc.TMCMID,
                                                  ETWID = vc.ETWID,
                                                  VendorName = vc.VendorName,
                                                  SowTypeName = vc.SowTypeName,
                                                  ContractTypeName = vc.ContractTypeName,
                                                  BillingTypeName = vc.BillingTypeName,
                                                  VerticalName = vc.VerticalName,
                                                  TowerName = vc.TowerName,
                                                  ProjectOrRun = vc.ProjectOrRun,
                                                  SkillSet = vc.SkillSet,
                                                  SOWNumber = vc.SOWNumber,
                                                  SOWName = vc.SOWName,
                                                  SOWStartDate = vc.SOWStartDate,
                                                  SOWEndDate = vc.SOWEndDate,
                                                  PONumber = vc.PONumber,
                                                  POStartDate = vc.POStartDate,
                                                  POEndDate = vc.POEndDate,
                                                  PPMProjectID = vc.PPMProjectID,
                                                  PPMProjectName = vc.PPMProjectName,
                                                  WBSDetail = vc.WBSDetail,
                                                  DomainLeadEmail = vc.DomainLeadEmail,
                                                  DomainName = vc.DomainName,
                                                  DomainSkillStartDate = vc.DomainSkillStartDate,
                                                  DomainSkillEndDate = vc.DomainSkillEndDate,
                                                  Currency = vc.Currency,
                                                  BillingRateYear1 = vc.BillingRateYear1,
                                                  BillingRateYear2 = vc.BillingRateYear2,
                                                  BillingRateYear3 = vc.BillingRateYear3,
                                                  BillingRateYear4 = vc.BillingRateYear4,
                                                  BillingRateYear5 = vc.BillingRateYear5,
                                                  LocationName = vc.LocationName,
                                                  NoticePeriod = vc.NoticePeriod,
                                                  PositionCode = vc.PositionCode,
                                                  OldSOWNumber = vc.OldSOWNumber,
                                                  RemappedMID = vc.RemappedMID,
                                                  SAPCode = vc.SAPCode,
                                                  CostCenter = vc.CostCenter,
                                                  OBS = vc.OBS,
                                                  Status = vc.Status,
                                                  //PendingWithWhom = _UserService.GetUserNameByKey(vc.PendingWithWhom),
                                                  PendingWithWhom = vc.PendingWithWhom,
                                                  WFOrder = vc.WFOrder,
                                                  IsActive = vc.IsActive,
                                                  //UploadedBy = _UserService.GetUserNameByKey(vc.UploadedBy),
                                                  UploadedBy = vc.UploadedBy,
                                                  UploadedDate = vc.UploadedDate,
                                                  //SendBackReason = sendBackList.Where(x => x.Tmcid == contract.TMVCMID && x.Action == "Sentback").Select(x => x.Remarks).FirstOrDefault().ToString()
                                                  SendBackReason = sl.Remarks,
                                                  CustomDomainName=vc.CustomDomainName
                                              }).ToList();


                return tmSendbackContractMainList;


                //if (tmListResult != null)
                //{
                //    foreach (var contract in tmListResult)
                //    {
                //        var item = new TmContractMain
                //        {
                //            TMVCMID = contract.TMVCMID,
                //            TMCMID = contract.TMCMID,
                //            ETWID = contract.ETWID,
                //            VendorName = contract.VendorName,
                //            SowTypeName = contract.SowTypeName,
                //            ContractTypeName = contract.ContractTypeName,
                //            BillingTypeName = contract.BillingTypeName,
                //            VerticalName = contract.VerticalName,
                //            TowerName = contract.TowerName,
                //            ProjectOrRun = contract.ProjectOrRun,
                //            SkillSet = contract.SkillSet,
                //            SOWNumber = contract.SOWNumber,
                //            SOWName = contract.SOWName,
                //            SOWStartDate = contract.SOWStartDate,
                //            SOWEndDate = contract.SOWEndDate,
                //            PONumber = contract.PONumber,
                //            POStartDate = contract.POStartDate,
                //            POEndDate = contract.POEndDate,
                //            PPMProjectID = contract.PPMProjectID,
                //            PPMProjectName = contract.PPMProjectName,
                //            WBSDetail = contract.WBSDetail,
                //            DomainLeadEmail = contract.DomainLeadEmail,
                //            DomainName = contract.DomainName,
                //            DomainSkillStartDate = contract.DomainSkillStartDate,
                //            DomainSkillEndDate = contract.DomainSkillEndDate,
                //            Currency = contract.Currency,
                //            BillingRateYear1 = contract.BillingRateYear1,
                //            BillingRateYear2 = contract.BillingRateYear2,
                //            BillingRateYear3 = contract.BillingRateYear3,
                //            BillingRateYear4 = contract.BillingRateYear4,
                //            BillingRateYear5 = contract.BillingRateYear5,
                //            LocationName = contract.LocationName,
                //            NoticePeriod = contract.NoticePeriod,
                //            PositionCode = contract.PositionCode,
                //            OldSOWNumber = contract.OldSOWNumber,
                //            RemappedMID = contract.RemappedMID,
                //            SAPCode = contract.SAPCode,
                //            CostCenter = contract.CostCenter,
                //            OBS = contract.OBS,
                //            Status = contract.Status,
                //            PendingWithWhom = _UserService.GetUserListByKey(contract.PendingWithWhom).FirstOrDefault().Item2,
                //            WFOrder = contract.WFOrder,
                //            IsActive = contract.IsActive,
                //            UploadedBy = _UserService.GetUserListByKey(contract.UploadedBy).FirstOrDefault().Item2,
                //            UploadedDate = contract.UploadedDate,
                //            SendBackReason = sendBackList.Where(x => x.Tmcid == contract.TMVCMID && x.Action == "Sentback").Select(x => x.Remarks).FirstOrDefault().ToString()

                //        };

                //        tmSendbackContractMainList.Add(item);
                //    }
                //}

            }

            return tmSendbackContractMainList;
        }

        public List<EmsTblTmcontractWorkFlow> GetWorkFlowsOfContract(int tmcid)
        {
            return _tMContractRepository.GetWorkFlowsOfContract(tmcid);
        }

        #endregion


        #region "T&M Approval"
        public List<TMContract> GetTMContractPendingList (int WFOrder, int Location)
        {
            var tmContractInt = new List<TMContract>();
            var result = _tMContractRepository.GetTMContractPendingList(WFOrder, Location);
            
            // var vendorDetails = _masterRepository.Getvendormaster();
            if (result != null)
            {
                foreach (var contract in result)
                {
                   

                    var item = new TMContract();
                    item.TMCMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;

                    item.SOWType = contract.SOWTypeName;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;
                    item.PositionCode = contract.PositionCode;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;

                    item.Currency = contract.Currency;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.BillingRateYear2 = contract.BillingRateYear2;
                    item.BillingRateYear3 = contract.BillingRateYear3;
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.PositionLocation=contract.LocationName;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.NoticePeriod = contract.NoticePeriod;
                   item.SkillSet = contract.SkillSet;
                    item.SAPCode = contract.SAPCode;
                   item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UploadedBy = contract.UploadedBy;
                    item.remarks = "";
                    item.OBS = contract.OBS;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                     item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.vendoreMail = contract.EmailIDs;
                    item.CustomDomainName = contract.CustomDomainName;
                    tmContractInt.Add(item);
                }
            }
            return tmContractInt;
        }
        public string PostTMContractList (List<TMContract> contracts)
        {
            string? nxtPendingWith = "", prvPendingWith = "", postres="Failure";
            var tmContractInt = new List<TMContract>();
            var _objTMVendorContractMasters = new List<EmsTblTmvendorContractMaster>();
            var _objTMVendorContractWFHistory = new List<EmsTblTmcontractWorkFlow>();
            var _objTMVendorContract = new List<EmsTblContractMaster>();

            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objmailsPMOAdmin = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
          
           var nextWFOrder = new EmsTblWorkFlowMaster();
           var  prevWFOrder = new EmsTblWorkFlowMaster();

            var result = _tMContractRepository.GetTMContractWFOrder();
            int wfOrder = 1;
            var loginlocationId = SessionManager.CurrentUser.Location_ID??0;
            if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
            {
              
                //When Finance Manager approve
                //If Approved
                nextWFOrder = result.Where(x => x.Wforder > Constants.ProcurementWFOrder.FinanceManager).OrderBy(x => x.Wforder).FirstOrDefault();
                //If Sendback
                 prevWFOrder = (from wf in result
                                   join prewf in result on wf.SendBackWforder equals prewf.Wforder
                                   where wf.Wforder == Constants.ProcurementWFOrder.FinanceManager
                                   select prewf).FirstOrDefault();
            }

            //Should trigger to Resource Manager                   
              if (nextWFOrder != null)
                {
                    var nxtroleaster = _masterRepository.GetrolesbyRoleType(nextWFOrder.Wfrole, loginlocationId);
                    nxtPendingWith = nxtroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();
                }
                //Should trigger to Procurtment lead               
                if (prevWFOrder != null)
                {
                    var preroleaster = _masterRepository.GetrolesbyRoleType(prevWFOrder.Wfrole, loginlocationId);
                    prvPendingWith = preroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();

                }
                //This condition is not applicable for last approval, need to add one more section
                if (nextWFOrder != null && prevWFOrder != null)
                {
               
                foreach (var con in contracts)
                    {


                        _objTMVendorContractMasters.Add(new EmsTblTmvendorContractMaster()
                        {
                            Tmcmid = con.TMCMID,
                            Tmvcmid = con.TMVCMID ?? 0,
                            // PendingWithWhom = (con.isSelectedApproval == true) ? nxtPendingWith : prvPendingWith,
                            PendingWithWhom = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ?null: nxtPendingWith : prvPendingWith,
                            Wforder = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? null : nextWFOrder.Wforder : prevWFOrder.Wforder,
                            Status = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? "Closed" : "Open" : "Pending",
                            PositionCode =con.PositionCode,
                            RemappedMid=con.RemappedMID,
                            SowstartDate=con.SOWStartDate,
                            SowendDate=con.SOWEndDate,
                            Sownumber = con.SOWNumber,
                            DomainSkillEndDate = con.DomainSkillEndDate
                        });
                        _objTMVendorContractWFHistory.Add(new EmsTblTmcontractWorkFlow()
                        {
                            Tmcid = con.TMVCMID,
                            Role = Constants.ProcurementWFRoles.FinanceManager,//Need to change this 
                            ActionByMid = SessionManager.CurrentUser.MID,
                            ActionByName = SessionManager.CurrentUser.DisplayName,
                            ActionDate = DateTime.Now,
                            // Action = (con.isSelectedApproval == true) ? "Approved" : "Sentback",
                            Action = (con.isSelectedApproval == true) ?
                                        (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate <= DateTime.Now.Date) ? "Approved and Resource Mapped"
                                            : (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate > DateTime.Now.Date) ? "Approved and Scheduled For Resource Mapping" : "Approved"
                                        : "Sentback",
                            Remarks = (con.isSelectedApproval == true) ? con.RemappedMID != null && con.RemappedMID != "" ? 
                                                (con.remarks != null && con.remarks != "") ? con.remarks + ", RemappedMID:" + con.RemappedMID
                                                :"RemappedMID : " + con.RemappedMID
                                      : con.remarks: con.remarks,
                            NextWfrole = (con.isSelectedApproval == true) ?
                            (con.RemappedMID != null && con.RemappedMID != "")?null:
                            nextWFOrder.Wfrole : prevWFOrder.Wfrole
                       
                        });
                    }
               
                // Update status as Open in Contract table

                _objTMVendorContract = (from cm in contracts
                                         where cm.isSelectedApproval == true
                                         select new EmsTblContractMaster()
                                         {

                                             Status = (cm.RemappedMID != null && cm.RemappedMID != "") ? "Closed" : "Open",
                                             PositionCode = cm.PositionCode,
                                             Cmid = cm.TMCMID ?? 0,
                                             // IsActive = cm.IsActive,
                                             //SkillSetId = cm.SkillSet,
                                             Sowname = cm.SOWName,
                                             SowStartDate = cm.SOWStartDate
                                           

                                         }).OrderBy(x=>x.Status).DistinctBy(x => x.PositionCode).ToList();
            }
                //Push Data to Database
                 postres = _tMContractRepository.PostTMContractApproval(_objTMVendorContractMasters, _objTMVendorContractWFHistory, _objTMVendorContract);
            //If Data update is success send mail
            if (postres == "success")
            {

                if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
                {

                    var vendorGroup = contracts.DistinctBy(x => x.VendorName).ToList();
                    foreach (var vendor in vendorGroup)
                    {
                        //Fetch only Approved list
                        var vContract = contracts.Where(x => x.VendorName == vendor.VendorName && x.isSelectedApproval == true && ( x.RemappedMID==null || x.RemappedMID=="")).ToList();
                        if (vContract.Count > 0)
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                               
                                worksheet.Columns(1, 27).Style.Font.FontColor = XLColor.Black;
                                worksheet.Columns(1, 27).AdjustToContents();
                                // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                                worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                                worksheet.Cell(1, 1).Value = "ETWID";
                                worksheet.Cell(1, 2).Value = "PositionCode";
                                worksheet.Cell(1, 3).Value = "VendorName";
                                worksheet.Cell(1, 4).Value = "SOWNumber";
                                worksheet.Cell(1, 5).Value = "SOWName";

                                worksheet.Cell(1, 6).Value = "SOWStartDate";
                                worksheet.Cell(1, 7).Value = "SOWEndDate";
                                worksheet.Cell(1, 8).Value = "PONumber";
                                worksheet.Cell(1, 9).Value = "POStartDate";
                                worksheet.Cell(1, 10).Value = "POEndDate";
                                worksheet.Cell(1, 11).Value = "ContractType";

                                worksheet.Cell(1, 12).Value = "PPMProjectID";
                                worksheet.Cell(1, 13).Value = "ProjectName";
                                worksheet.Cell(1, 14).Value = "Tower";
                                worksheet.Cell(1, 15).Value = "DomainSkillName";
                                worksheet.Cell(1, 16).Value = "Skillset";

                                worksheet.Cell(1, 17).Value = "DomainSkillStartDate";
                                worksheet.Cell(1, 18).Value = "DomainSkillEndDate";
                                worksheet.Cell(1, 19).Value = "BillingType";
                                worksheet.Cell(1, 20).Value = "RemappedMID";
                               // worksheet.Cell(1, 21).Value = "CostCenter";
                                worksheet.Cell(1, 21).Value = "FirstName";

                                worksheet.Cell(1, 22).Value = "LastName";
                                worksheet.Cell(1, 23).Value = "Gender";
                                worksheet.Cell(1, 24).Value = "DOB";
                                worksheet.Cell(1, 25).Value = "DOJViatris";
                                worksheet.Cell(1, 26).Value = "ManagerName";

                                worksheet.Cell(1, 27).Value = "ManagerEmail";
                                worksheet.Cell(1, 28).Value = "MobileNumber";

                                for (int index = 1; index <= vContract.Count; index++)
                                {
                                    worksheet.Cell(index + 1, 1).Value = vContract[index - 1].ETWID;
                                    worksheet.Cell(index + 1, 2).Value = vContract[index - 1].PositionCode;
                                    worksheet.Cell(index + 1, 3).Value = vContract[index - 1].VendorName;
                                    worksheet.Cell(index + 1, 4).Value = vContract[index - 1].SOWNumber;
                                    worksheet.Cell(index + 1, 5).Value = vContract[index - 1].SOWName;

                                    worksheet.Cell(index + 1, 6).Value = vContract[index - 1].SOWStartDate;
                                    worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 7).Value = vContract[index - 1].SOWEndDate;
                                    worksheet.Cell(index + 1, 7).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 8).Value = vContract[index - 1].PONumber;
                                    worksheet.Cell(index + 1, 9).Value = vContract[index - 1].POStartDate;
                                    worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 10).Value = vContract[index - 1].POEndDate;
                                    worksheet.Cell(index + 1, 10).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 11).Value = vContract[index - 1].ContractType;

                                    worksheet.Cell(index + 1, 12).Value = vContract[index - 1].PPMProjectID;
                                    worksheet.Cell(index + 1, 13).Value = vContract[index - 1].PPMProjectName;
                                    worksheet.Cell(index + 1, 14).Value = vContract[index - 1].Tower;
                                    worksheet.Cell(index + 1, 15).Value = vContract[index - 1].DomainName;
                                    worksheet.Cell(index + 1, 16).Value = vContract[index - 1].SkillSet;

                                    worksheet.Cell(index + 1, 17).Value = vContract[index - 1].DomainSkillStartDate;
                                    worksheet.Cell(index + 1, 17).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 18).Value = vContract[index - 1].DomainSkillEndDate;
                                    worksheet.Cell(index + 1, 18).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 19).Value = vContract[index - 1].BillingType;
                                    worksheet.Cell(index + 1, 20).Value = vContract[index - 1].RemappedMID;
                                   // worksheet.Cell(index + 1, 21).Value = vContract[index - 1].CostCenter;

                                }
                                using (var stream = new MemoryStream())
                                {
                                    workbook.SaveAs(stream);
                                    var content = stream.ToArray();
                                    //MemoryStream attachmentStream = new MemoryStream(content);
                                    //Attachment attachment = new Attachment(stream, filename, contentType);

                                    objmails.Attachment = content;
                                    objmails.To = vendor.vendoreMail ?? "";
                                    objmails.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com"; 
                                    objmails.From = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                                    objmails.Subject = "Require Onboarding Resource Data";

                                }
                            }
                            //int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                            //var PMOAdmin = _masterRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ResourceManager, locId).Select(x => x.EmailId);
                            StringBuilder mailBody = new StringBuilder();
                            //objmailsPMOAdmin.To = string.Join(";", PMOAdmin);
                            //objmailsPMOAdmin.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                            //objmailsPMOAdmin.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                            //objmailsPMOAdmin.Subject = "Contracts Approved";
                            //objmailsPMOAdmin.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";

                            //_mailtemp.SendTMContractApproval(_objTMVendorContractMasters, objmails, "Approve");
                            _mailtemp.SendTMContractApproval(objmails, "Approve");
                            //_mailtemp.SendTMContractApproval(objmailsPMOAdmin, "ApproveToPMO");
                        }
                    }

                    var toPMOAdmin = contracts.Where(x=> x.isSelectedApproval == true).ToList();
                    if(toPMOAdmin!=null && toPMOAdmin.Count>0)
                    {
                        int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                        var PMOAdmin = _masterRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ResourceManager, locId).Select(x => x.EmailId);
                        StringBuilder mailBody = new StringBuilder();
                        objmailsPMOAdmin.To = string.Join(";", PMOAdmin);
                        objmailsPMOAdmin.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                        objmailsPMOAdmin.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                        objmailsPMOAdmin.Subject = "Contracts Approved";
                        objmailsPMOAdmin.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";

                        _mailtemp.SendTMContractApproval(objmailsPMOAdmin, "ApproveToPMO");
                    }

                    //Send Mail send back to procurtment lead 
                    var uploadedby = contracts.Where(x => x.isSelectedApproval == false).DistinctBy(x => x.UploadedBy).ToList();

                    if (uploadedby != null && uploadedby.Count != 0)
                    {
                        int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                       
                            var procurtmentGroup= _masterRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ProcurementLead,locId).Select(x=>x.EmailId);
                            var financeGroup = _masterRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.FinanceManager, locId).Select(x => x.EmailId);

                            StringBuilder mailBody = new StringBuilder();
                            objsendbackmails.To = string.Join(";", procurtmentGroup);
                            objsendbackmails.Cc = string.Join(",", financeGroup);
                            objsendbackmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                        objsendbackmails.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";
                        objsendbackmails.Subject = "Contracts Sent back by IT Finance Manager";

                        //var sentBacklist = contracts.Where(x => x.isSelectedApproval == false && x.UploadedBy == entity.UploadedBy).ToList();
                        //mailBody.Append("<table border=1>");
                        //mailBody.Append("<tr cellpadding=5px><th bgcolor=\"#800080\">ETWID</th><th bgcolor=\"#800080\">Vendor</th><th bgcolor=\"#800080\">SOW Number</th><th bgcolor=\"#800080\">SOW Name</th><th bgcolor=\"#800080\">Position Code</th><th bgcolor=\"#800080\">Remarks</th></tr>");

                        //foreach (var sb in sentBacklist)
                        //{
                        //    mailBody.Append("<tr cellpadding=5px><td>" + sb.ETWID + "</td><td>" + sb.VendorName + "</td><td>" + sb.SOWNumber + "</td><td>" + sb.SOWName + "</td><td>" + sb.PositionCode + "</td><td>" + sb.remarks + "</td></tr>");

                        //}
                        //mailBody.Append("</table><br><br> Regards,<br> Admin Team - Viatris");

                        // objsendbackmails.Body = mailBody.ToString();
                        //_mailtemp.SendTMContractApproval(_objTMVendorContractMasters, objsendbackmails, "sendback");
                        _mailtemp.SendTMContractApproval(objsendbackmails, "sendback");
                        

                    }


                }


            }
            return postres;
        }
        #endregion
        #region "TMContract Track List"
        public List<TMContract> GetTMContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter)
        {
            var tmContractInt = new List<TMContract>();
            var result = _tMContractRepository.GetTMContractTrackList(WFOrder, Location, filter, ActiveFilter);

            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new TMContract();
                    item.TMCMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;

                    item.SOWType = contract.SOWTypeName;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;
                    item.PositionCode = contract.PositionCode;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;

                    item.Currency = contract.Currency;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.BillingRateYear2 = contract.BillingRateYear2;
                    item.BillingRateYear3 = contract.BillingRateYear3;
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.PositionLocation = contract.LocationName;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.NoticePeriod = contract.NoticePeriod;
                    item.SkillSet = contract.SkillSet;
                    item.SAPCode = contract.SAPCode;
                    item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UploadedBy = contract.UploadedBy;
                    item.UploadDate = contract.UploadedDate;
                    item.remarks = "";
                    item.OBS = contract.OBS;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.wfOrder = contract.WFOrder;
                    // item.Status = alterContractStatus(contract.Status);
                    item.Status = contract.Status;
                    item.Pendingwithwhom = contract.PendingWithWhom;
                   item.isActive = contract.IsActive;
                    item.CustomDomainName = contract.CustomDomainName;
                    tmContractInt.Add(item);
                }
            }
            return tmContractInt;
        }

        List<SP_EMS_FetchSowNumberByContractTypeResult> ITMContract.GetSowListByContractType(string contractType, string searchSowNumber)
        {
            var result = _tMContractRepository.GetSowListByContractType(contractType, searchSowNumber);
            return result;
        }

        List<SP_EMS_FetchContractListBySOW_NoResult> ITMContract.GetAllSowListByContractType(string contractType, string sowNumber)
        {
            var result = _tMContractRepository.GetAllSowListByContractType(contractType, sowNumber);
            return result;
        }

        List<SP_EMS_FetchColumnValueByTblAndSowNumberResult> ITMContract.GetContractValueByContractSowType(string contractType, string sowNumber, string fieldType)
        {
            var result = _tMContractRepository.GetContractValueByContractSowType(contractType, sowNumber, fieldType);
            return result;
        }

        List<SP_EMS_ValidateColumnBySowNumberResult> ITMContract.GetColumnValidationStatusBySowNumber(string contractType, string sowNumber, string fieldType, string newValue)
        {
            var result = _tMContractRepository.GetColumnValidationStatusBySowNumber(contractType, sowNumber, fieldType, newValue);
            return result;
        }

        int ITMContract.UpdateContractColumnBySowNumber(string contractType, string sowNumber, string fieldType, string oldValue, string newValue, string mid)
        {
            var result = _tMContractRepository.UpdateContractColumnBySowNumber(contractType, sowNumber, fieldType, oldValue, newValue, mid);
            return result;
        }
        #endregion

    }
}
