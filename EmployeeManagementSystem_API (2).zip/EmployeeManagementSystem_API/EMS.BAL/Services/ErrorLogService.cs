﻿using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using NetTopologySuite.Operation.OverlayNG;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Services
{
    public class ErrorLogService : IErrorLog
    {
        private readonly IErrorLogRepository _errorLogRepo;
        public ErrorLogService (IErrorLogRepository repository)
        {
            _errorLogRepo = repository;

        }
        public bool logError (ErrorLog error)
        {
            if (error is not null)
            {
                var errorLog = new EmsTblErrorLog();
                errorLog.ErrorCode = Convert.ToInt32(error.ErrorCode);
                errorLog.ErrorMessage = error.ErrorMessage;
                errorLog.ErrorUrl = error.ErrorUrl;
                errorLog.ErrorType = error.ErrorType;
                errorLog.LoggedMid = error.UserId;
                errorLog.LoggedDate = DateTime.Now;
                return _errorLogRepo.SaveError(errorLog);
            }
            return false;

        }
    }
}
