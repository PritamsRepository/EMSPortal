﻿
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using EMS_BAL.Interface;
using EMS_BAL.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Policy;
using System.Text;
using EMS_BAL.Helper;
using EMS.BAL.Helper;
using DocumentFormat.OpenXml.Wordprocessing;

namespace EMS_BAL.Services
{
    public class TokenManager : ITokenManager
    {

        private readonly IDistributedCache _cache;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly JwtOptions _jwtOptions;
        private readonly IUserService _userService;

        public TokenManager (IDistributedCache cache,
                IHttpContextAccessor httpContextAccessor,
                IOptions<JwtOptions> jwtOptions,
                IUserService userService
            )
        {
            _cache = cache;
            _httpContextAccessor = httpContextAccessor;
            _jwtOptions = jwtOptions.Value;
            _userService = userService;
        }

        public async Task<bool> IsCurrentActiveToken ()
            => await IsActiveAsync(GetCurrentAsync());

        public async Task DeactivateCurrentAsync ()
            => await DeactivateAsync(GetCurrentAsync());

        public async Task<bool> IsActiveAsync (string token)
            => await _cache.GetStringAsync(GetKey(token)) == null;

        public Task DeactivateAsync (string token)
            => _cache.RemoveAsync(GetKey(token));
                //, new DistributedCacheEntryOptions
                //{
                //    //AbsoluteExpirationRelativeToNow =
                //    //    TimeSpan.FromMinutes(_jwtOptions.Value.ExpiryMinutes)
                //    AbsoluteExpirationRelativeToNow = TimeSpan.Zero
                   
                   
                //});
        

        private string GetCurrentAsync()
        {

            //  var claims = User.Claims.Where(x => x.Type == Constants.ClaimType).Select(x => x.Value).ToList();
            var authorizationHeader = _httpContextAccessor.HttpContext.Request.Headers["authorization"];
            if (authorizationHeader.Count() > 0)
            {
                var jwt = authorizationHeader.FirstOrDefault().ToString().Replace("Bearer ", string.Empty).Trim();
                ValidateToken(jwt);

            }
            return authorizationHeader == StringValues.Empty
                ? string.Empty
                : authorizationHeader.Single().Split(" ").Last();
        }
        public  ClaimsPrincipal ValidateToken(string jwtToken)
        {
            IdentityModelEventSource.ShowPII = true;

            SecurityToken validatedToken;
            TokenValidationParameters validationParameters = new TokenValidationParameters();

            validationParameters.ValidateLifetime = true;

            validationParameters.ValidAudience = _jwtOptions.Audience;
            validationParameters.ValidIssuer = _jwtOptions.Issuer;
            validationParameters.IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(Constants.JWT.secretKey));
            ClaimsPrincipal principal = new JwtSecurityTokenHandler().ValidateToken(jwtToken, validationParameters, out validatedToken);
            var claims = principal.Claims.ToList();
            MaintainClaims(claims);

            return principal;
        }
        private void ClearStaticSessionValue ()
        {
            SessionManager.CurrentUser.MID = null;
            SessionManager.CurrentUser.DisplayName = null;
            SessionManager.CurrentUser.EmailID = null;
            SessionManager.CurrentUser.IsProcurementLead = true;
            SessionManager.CurrentUser.IsLocalIT = false;
            SessionManager.CurrentUser.IsFinanceManager = false;
            SessionManager.CurrentUser.IsResourceManager = false;
            SessionManager.CurrentUser.IsEmployee = false;
            SessionManager.CurrentUser.IsAdmin = false;
        }

        public void MaintainClaims (List<Claim> claimPrincipals)
        {
            ClearStaticSessionValue();
            SessionManager.CurrentUser.IsEmployee = true;
            var name = SessionManager.CurrentUser.DisplayName;
            var subclaim = claimPrincipals.Where(x => x.Type == Constants.ClaimType.ClaimTypeSub).Select(x => x.Value).ToList();
            var userInfo = _userService.GetUserNameByKey(subclaim.FirstOrDefault());
            if (subclaim.Any())
            {
                SessionManager.CurrentUser.MID = subclaim.FirstOrDefault();
                SessionManager.CurrentUser.DisplayName = userInfo.Split(":")[1].Trim();
                SessionManager.CurrentUser.EmailID = userInfo.Split(":")[2].Trim();

            }
            var rolesclaim = claimPrincipals.Where(x => x.Type == Constants.ClaimType.ClaimTypeRole).Select(x => x.Value).ToList();

            if (rolesclaim.Any())
            {
                foreach (var claim in rolesclaim)
                {
                    if (claim == Constants.ProcurementWFRoles.ProcurementLead)
                    {
                        SessionManager.CurrentUser.IsProcurementLead = true;
                    }
                    if (claim == Constants.ProcurementWFRoles.LocalIT)
                    {
                        SessionManager.CurrentUser.IsLocalIT = true;
                    }
                    if (claim == Constants.ProcurementWFRoles.FinanceManager)
                    {
                        SessionManager.CurrentUser.IsFinanceManager = true;
                    }
                    if (claim == Constants.ProcurementWFRoles.ResourceManager)
                    {
                        SessionManager.CurrentUser.IsResourceManager = true;
                    }
                    if (claim == Constants.ProcurementWFRoles.Admin)
                    {
                        SessionManager.CurrentUser.IsAdmin = true;
                    }
                }
            }
        }

        private static string GetKey(string token)
            => $"tokens:{token}:deactivated";
    }
}