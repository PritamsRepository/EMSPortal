﻿using DocumentFormat.OpenXml.Office2010.Excel;
using DocumentFormat.OpenXml.Office2010.PowerPoint;
using ClosedXML.Excel;
using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using Azure.Core;
using System.Net;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Text.RegularExpressions;
using System.Drawing;
using EMS_BAL.Services;
using DocumentFormat.OpenXml.Office2013.Drawing.ChartStyle;
using System.ComponentModel;
using EMS_BAL.Interface;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System.Web;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Drawing.Spreadsheet;

namespace EMS.BAL.Services
{
    public class ApiResponse
    {
        [JsonProperty("Request Number")]
        public string RequestNumber { get; set; }
    }

    public class FPContractServices : IFPContract
    {

        private IFPContractRepository _fPContractRepository;
        private IMastersRepository _MastersRepository;
        private readonly IConfiguration _configuration;
        private MailMessageTemplate _mailtemp;
        //private IUserService _UserService;
        private IUserService _UserService;
        public FPContractServices(IFPContractRepository fPContractRepository, IMastersRepository mastersRepository, IConfiguration configuration, IUserService UserService)
        {
            _fPContractRepository = fPContractRepository;
            _MastersRepository = mastersRepository;
            _configuration = configuration;
            _mailtemp = new MailMessageTemplate(this._configuration);
            _UserService = UserService;
            // _UserService = new UserService(this._configuration);
        }
        public async Task UploadFPContractDate(List<FPContract> contracts, string MID, string locationid)
        {
            var tblList = new List<EmsTblFbvendorContractIntermediateMaster>();

            if (contracts != null)
            {
                foreach (var contract in contracts)
                {
                    var item = new EmsTblFbvendorContractIntermediateMaster();
                     
                    //item.FbcintId = contract.FBCIntID;
                    item.Etwid = contract.ETWID;
                    item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    item.AmortizationStartMonth =  contract.AmortizationStartMonth;
                    item.ContractType = contract.ContractType;
                    item.CostCenter = contract.CostCenter;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.Obs = contract.OBS;
                    item.OldSowNumber = contract.OldSowNumber;
                    item.PoendDate = contract.POEndDate;
                    item.Ponumber = contract.PONumber;
                    item.PositionLocation = contract.PositionLocation;
                    item.PostartDate = contract.POStartDate;
                    item.PpmprojectId = contract.PPMProjectID;
                    item.PpmprojectName = contract.PPMProjectName;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMid = contract.RemappedMID;
                    item.SkillSet = contract.SkillSet;
                    item.SowendDate = contract.SOWEndDate;
                    item.Sowname = contract.SOWName;
                    item.Sownumber = contract.SOWNumber;
                    item.SowstartDate = contract.SOWStartDate;
                    item.Tower = contract.Tower;
                    item.VendorName = contract.VendorName;
                    item.Vertical = contract.Vertical;
                    item.Wbsdetail = contract.WBSDetail;
                    item.BillingType = contract.BillingType;
                    item.ValidationRemarks = contract.ValidationRemarks;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.UpdatedOn = contract.UpdatedOn;

                    tblList.Add(item);
                }
                await _fPContractRepository.AddFPContractIntermediate(tblList, MID, locationid);
            }
        }


        public List<EmsVwFpvendorContractWorkFlow> GetWorkFlowsOfFPContract(int fbcIntID, string Btype, string Ctype)
        {
            return _fPContractRepository.GetWorkFlowsOfFPContract(fbcIntID, Btype, Ctype);
        }
        public bool UploadFPMOContractDate(List<FPContractMo> contracts, string MID)
        {
            var tblList = new List<EmsTblFbvendorContractMonthlyInt>();

            if (contracts != null)
            {
                foreach (var contract in contracts)
                {
                    var item = new EmsTblFbvendorContractMonthlyInt();

                    item.FbmonthlyIntId = contract.FBMonthlyIntID;
                    item.Sownumber = contract.SOWNumber;
                    item.AmortizationStartDate = contract.AmortizationStartDate;
                    item.AmortizationEndDate = contract.AmortizationEndDate;
                    item.MilestoneAmount = contract.MilestoneAmount;
                    item.DurationOfMonth = contract.DurationOfMonth;
                    item.Currency = contract.Currency;
                    item.ValidationRemarks = contract.ValidationRemarks;
                    item.UploadBy = MID;
                    item.UploadOn = DateTime.Now;

                    tblList.Add(item);
                }
                _fPContractRepository.AddFPContractMoIntermediate(tblList, MID);
            }
            return true;
        }


        public bool UploadFPMlContractDate(List<FPContractMl> contracts, string MID)
        {
            var tblList = new List<EmsTblFbvendorContractMilestoneInt>();

            if (contracts != null)
            {
                List<EmsTblFbvendorContractMilestoneInt> fpmlintlist = (from fplist in contracts
                                                                        select new EmsTblFbvendorContractMilestoneInt
                                                                        {
                                                                            FbcmilestoneIntId = fplist.FBCMilestoneIntID,
                                                                            Sownumber = fplist.SOWNumber,
                                                                            Milestone = fplist.Milestone,
                                                                            MilstoneDescription = fplist.MilstoneDescription,
                                                                            MilestoneAmount = fplist.MilestoneAmount,
                                                                            Currency = fplist.Currency,
                                                                            ValidationRemarks = fplist.ValidationRemarks,
                                                                            UploadBy = fplist.UpdatedBy,
                                                                            UploadOn = fplist.UpdateDate

                                                                        }).ToList();

                _fPContractRepository.AddFPMlContractIntermediate(fpmlintlist, MID);
            }
            return true;

        }

        public async Task<List<FPContract>>  GetFPContractIntermediateList()
        {
            
            var fPContractList = await _fPContractRepository.GetFPContractIntermediateList(SessionManager.CurrentUser.MID);

            var fpclist = (from fplist in fPContractList
                           select new FPContract
                           {
                               
                               FBCIntID = fplist.FbcintId,
                               ETWID = fplist.Etwid,
                               AmortizationEndMonth = fplist.AmortizationEndMonth,
                               AmortizationStartMonth = fplist.AmortizationStartMonth,
                               BillingType = fplist.BillingType,
                               ContractType = fplist.ContractType,
                               CostCenter = fplist.CostCenter,
                               DomainLeadEmail = fplist.DomainLeadEmail,
                               DomainSkillEndDate = fplist.DomainSkillEndDate,
                               DomainSkillName = fplist.DomainSkillName,
                               DomainSkillStartDate = fplist.DomainSkillStartDate,
                               OBS = fplist.Obs,
                               OldSowNumber = fplist.OldSowNumber,
                               POEndDate = fplist.PoendDate,
                               PONumber = fplist.Ponumber,
                               PositionLocation = fplist.PositionLocation,
                               POStartDate = fplist.PostartDate,
                               PPMProjectID = fplist.PpmprojectId,
                               PPMProjectName = fplist.PpmprojectName,
                               ProjectOrRun = fplist.ProjectOrRun,
                               RemappedMID = fplist.RemappedMid,
                               SkillSet = fplist.SkillSet,
                               SOWEndDate = fplist.SowendDate,
                               SOWName = fplist.Sowname,
                               SOWNumber = fplist.Sownumber,
                               SOWStartDate = fplist.SowstartDate,
                               Tower = fplist.Tower,
                               VendorName = fplist.VendorName,
                               Vertical = fplist.Vertical,
                               WBSDetail = fplist.Wbsdetail,
                               ValidationRemarks = fplist.ValidationRemarks
                           }).ToList();

            return fpclist;
        }

        public List<FPContractMo> GetFPMOContractIntermediateList()
        {
            var fPContractList = _fPContractRepository.GetFPMOContractIntermediateList(SessionManager.CurrentUser.MID);

            var fpclist = (from fplist in fPContractList
                           select new FPContractMo
                           {
                               FBMonthlyIntID = fplist.FbmonthlyIntId,
                               SOWNumber = fplist.Sownumber,
                               AmortizationStartDate = fplist.AmortizationStartDate,
                               AmortizationEndDate = fplist.AmortizationEndDate,
                               MilestoneAmount = Convert.ToDecimal(fplist.MilestoneAmount??0),
                               DurationOfMonth = Convert.ToInt16(fplist.DurationOfMonth??0),
                               Currency = fplist.Currency,
                               ValidationRemarks = fplist.ValidationRemarks
                           }).ToList();

            return fpclist;
        }

        public async Task<List<FPContractMl>> GetFPContractMlIntermediateList()
        {
            var fPContractList = await _fPContractRepository.GetFPContractMlIntermediateList(SessionManager.CurrentUser.MID);

            var fpclist = (from fplist in fPContractList
                           select new FPContractMl
                           {
                               FBCMilestoneIntID = fplist.FbcmilestoneIntId,
                               SOWNumber = fplist.Sownumber,
                               Milestone = fplist.Milestone,
                               MilstoneDescription = fplist.MilstoneDescription,
                               MilestoneAmount = Convert.ToDecimal(fplist.MilestoneAmount ?? 0),
                               Currency = fplist.Currency,
                               ValidationRemarks = fplist.ValidationRemarks
                           }).ToList();

            return fpclist;
        }

        public bool deleteFbFromIntByIDs(List<int> ids)
        {

            var result =  _fPContractRepository.deleteFbFromIntByIDs(ids);
            return result;
        }

        public bool deleteFbAllOrByID(string ID)
        {
            //var fpclist = selectedRows.Select(x => x.FBCIntID).ToList();
            //var fpclist = (from fplist in selectedRows
            //               select new EmsTblFbvendorContractIntermediateMaster
            //               {
            //                   //FbcintId = fplist.,
            //                   Etwid = fplist.ETWID,
            //                   VendorName = fplist.VendorName,
            //                   Sownumber = fplist.SOWNumber,
            //                   OldSowNumber = fplist.OldSowNumber,
            //                   RemappedMid = fplist.RemappedMID,
            //                   Sowname = fplist.SOWName,
            //                   SowstartDate = Convert.ToDateTime(fplist.SOWStartDate),
            //                   SowendDate = Convert.ToDateTime(fplist.SOWEndDate),
            //                   Ponumber = fplist.PONumber,
            //                   PostartDate = Convert.ToDateTime(fplist.POStartDate),
            //                   PoendDate = Convert.ToDateTime(fplist.POEndDate),
            //                   PpmprojectId = fplist.PPMProjectID,
            //                   PpmprojectName = fplist.PPMProjectName,
            //                   Tower = fplist.Tower,
            //                   DomainSkillName = fplist.DomainSkillName,
            //                   SkillSet = fplist.SkillSet,
            //                   Vertical = fplist.Vertical,
            //                   Wbsdetail = fplist.WBSDetail,
            //                   DomainLeadEmail = fplist.DomainLeadEmail,
            //                   CostCenter = fplist.CostCenter,
            //                   DomainSkillStartDate = Convert.ToDateTime(fplist.DomainSkillStartDate),
            //                   DomainSkillEndDate = Convert.ToDateTime(fplist.DomainSkillEndDate),
            //                   ProjectOrRun = fplist.ProjectOrRun,
            //                   ContractType = fplist.ContractType,
            //                   AmortizationStartMonth = Convert.ToDateTime(fplist.AmortizationStartMonth),
            //                   AmortizationEndMonth = Convert.ToDateTime(fplist.AmortizationEndMonth),
            //                   BillingType = fplist.BillingType,
            //                   ValidationRemarks = fplist.ValidationRemarks
            //               }).ToList();
  


            var result = _fPContractRepository.deleteFbAllOrByID(ID);
            return result;
        }

        public async Task<bool> deleteFbmlFromIntAllOrByID(string id)
        {
            var result = await   _fPContractRepository.deleteFbmlFromIntAllOrByID(id);
            return result;
        }
         
        public bool deleteFbmlFromIntByIDs(List<int> ids)
        {
            var result = _fPContractRepository.deleteFbmlFromIntByIDs(ids);
            return result;
        }

        public async Task<bool> deleteFbMoFromIntAllOrByID(string id)
        {
            var result = await _fPContractRepository.deleteFbMoFromIntAllOrByID(id);
            return result;
        }

        public bool deleteFbMoFromIntByIDs(List<int> ids)
        {
            var result = _fPContractRepository.deleteFbMoFromIntByIDs(ids);
            return result;
        }

        public bool DeleteFBSendbackData(int IntID, string mid, string name, string remarks, string Btype)
        {
            var result = _fPContractRepository.DeleteFBSendbackData(IntID,mid,name,remarks, Btype);
            return result;
        }



        //public bool saveSelectedFpRows(List<int> ids)
        //{
        //    var fpclist = (from fplist in selectedRows
        //                   select new EmsTblFbvendorContractIntermediateMaster
        //                   {
        //                       //FbcintId = fplist.,
        //                       Etwid = fplist.ETWID,
        //                       VendorName = fplist.VendorName,
        //                       Sownumber = fplist.SOWNumber,
        //                       OldSowNumber = fplist.OldSowNumber,
        //                       RemappedMid = fplist.RemappedMID,
        //                       Sowname = fplist.SOWName,
        //                       SowstartDate = Convert.ToDateTime(fplist.SOWStartDate),
        //                       SowendDate = Convert.ToDateTime(fplist.SOWEndDate),
        //                       Ponumber = fplist.PONumber,
        //                       PostartDate = Convert.ToDateTime(fplist.POStartDate),
        //                       PoendDate = Convert.ToDateTime(fplist.POEndDate),
        //                       PpmprojectId = fplist.PPMProjectID,
        //                       PpmprojectName = fplist.PPMProjectName,
        //                       Tower = fplist.Tower,
        //                       DomainSkillName = fplist.DomainSkillName,
        //                       SkillSet = fplist.SkillSet,
        //                       Vertical = fplist.Vertical,
        //                       Wbsdetail = fplist.WBSDetail,
        //                       DomainLeadEmail = fplist.DomainLeadEmail,
        //                       CostCenter = fplist.CostCenter,
        //                       DomainSkillStartDate = Convert.ToDateTime(fplist.DomainSkillStartDate),
        //                       DomainSkillEndDate = Convert.ToDateTime(fplist.DomainSkillEndDate),
        //                       ProjectOrRun = fplist.ProjectOrRun,
        //                       ContractType = fplist.ContractType,
        //                       AmortizationStartMonth = Convert.ToDateTime(fplist.AmortizationStartMonth),
        //                       AmortizationEndMonth = Convert.ToDateTime(fplist.AmortizationEndMonth),
        //                       BillingType = fplist.BillingType,
        //                       ValidationRemarks = fplist.ValidationRemarks
        //                   }).ToList();
        //    var result =  _fPContractRepository.saveSelectedFpRows(fpclist);
        //    return result;
        //}

        public bool saveSelectedFpMoRows(List<FPContractMo> selectedRows)
        {
            var fpclist = (from fplist in selectedRows
                           select new EmsTblFbvendorContractMonthlyInt
                           {
                               FbmonthlyIntId = fplist.FBMonthlyIntID,
                               Sownumber = fplist.SOWNumber,
                               AmortizationStartDate = fplist.AmortizationStartDate,
                               AmortizationEndDate = fplist.AmortizationEndDate,
                               MilestoneAmount = fplist.MilestoneAmount,
                               DurationOfMonth = fplist.DurationOfMonth,
                               Currency = fplist.Currency,
                               ValidationRemarks = fplist.ValidationRemarks
                           }).ToList();
            //var result =  _fPContractRepository.saveSelectedFpRows(fpclist);
            return true;
        }

        public bool saveSelectedFpMlRows(List<int> ids)
        {
            //var fpclist = (from fplist in selectedRows
            //               select new EmsTblFbvendorContractMilestoneInt
            //               {

            //                   FbcmilestoneIntId = fplist.FBCMilestoneIntID,

            //                   Sownumber = fplist.SOWNumber,

            //                   Milestone = fplist.Milestone,

            //                   MilstoneDescription = fplist.MilstoneDescription,

            //                   MilestoneAmount = fplist.MilestoneAmount,

            //                   Currency = fplist.Currency,

            //                   ValidationRemarks = fplist.ValidationRemarks
            //               }).ToList();
            var result =  _fPContractRepository.saveSelectedFpMlRows(ids);
            return result;
        }

        public bool saveSelectedFpContract(FPContract selectedContract)
        {
            var fpcontract = new EmsTblFbvendorContractIntermediateMaster
            {
                FbcintId = selectedContract.FBCIntID,
                Etwid = selectedContract.ETWID,
                VendorName = selectedContract.VendorName,
                Sownumber = selectedContract.SOWNumber,
                OldSowNumber = selectedContract.OldSowNumber,
                RemappedMid = selectedContract.RemappedMID,
                Sowname = selectedContract.SOWName,
                SowstartDate = Convert.ToDateTime(selectedContract.SOWStartDate),
                SowendDate = Convert.ToDateTime(selectedContract.SOWEndDate),
                Ponumber = selectedContract.PONumber,
                PostartDate = Convert.ToDateTime(selectedContract.POStartDate),
                PoendDate = Convert.ToDateTime(selectedContract.POEndDate),
                PpmprojectId = selectedContract.PPMProjectID,
                PpmprojectName = selectedContract.PPMProjectName,
                Tower = selectedContract.Tower,
                DomainSkillName = selectedContract.DomainSkillName,
                SkillSet = selectedContract.SkillSet,
                Vertical = selectedContract.Vertical,
                Wbsdetail = selectedContract.WBSDetail,
                DomainLeadEmail = selectedContract.DomainLeadEmail,
                CostCenter = selectedContract.CostCenter,
                DomainSkillStartDate = Convert.ToDateTime(selectedContract.DomainSkillStartDate),
                DomainSkillEndDate = Convert.ToDateTime(selectedContract.DomainSkillEndDate),
                ProjectOrRun = selectedContract.ProjectOrRun,
                ContractType = selectedContract.ContractType,
                AmortizationStartMonth = Convert.ToDateTime(selectedContract.AmortizationStartMonth),
                AmortizationEndMonth = Convert.ToDateTime(selectedContract.AmortizationEndMonth),
                BillingType = selectedContract.BillingType,
                ValidationRemarks = selectedContract.ValidationRemarks
            };

            var result =  _fPContractRepository.saveSelectedFpContract(fpcontract);

            return result;
        }



        public bool saveSelectedFpMlContract(FPContractMl selectedContract)
        {
            var fpcontract = new EmsTblFbvendorContractMilestoneInt
            {
                FbcmilestoneIntId = selectedContract.FBCMilestoneIntID,

                Sownumber = selectedContract.SOWNumber,

                Milestone = selectedContract.Milestone,

                MilstoneDescription = selectedContract.MilstoneDescription,

                MilestoneAmount = selectedContract.MilestoneAmount,

                Currency = selectedContract.Currency,

                ValidationRemarks = selectedContract.ValidationRemarks


            };

            var result =  _fPContractRepository.saveSelectedFMlContract(fpcontract);

            return result;
        }
         
        public List<FPContractMain> GetFPSendbackDetails(string mid)
        {
            var fpSendbackContractMainList = new List<FPContractMain>();
            var ActiveFilter = "Active";
           // var fpList = _fPContractRepository.GetFPContractMainList(mid,0,DateTime.Now,DateTime.Now).Result.Where(x => x.IsActive == true && x.WFOrder == 0).ToList();
            var fpList = _fPContractRepository.GetFPContractMainList("Pending", Convert.ToInt32(SessionManager.CurrentUser.Location_ID), null,null, ActiveFilter);
            //var userName = _UserService.GetUserNameByKey(mid);
            if (fpList != null)
            {
                List<int?> fpVCMID = new List<int?>();
                fpVCMID = fpList.Select(x => (int?)x.FBCID).ToList();
                var sendBackList = _fPContractRepository.GetFPSendbackedListFromWorkFlow(fpVCMID);

                var sendBackListFiltered = sendBackList.Where(cwf => cwf.Action == "Sentback").GroupBy(cwf => cwf.Cmid).Select(group => group.OrderByDescending(cwf => cwf.Wfid).First()).ToList();

                fpSendbackContractMainList = (from vc in fpList.AsEnumerable()
                                              join sl in sendBackListFiltered.AsEnumerable() on vc.FBCID equals sl.Cmid
                                              select new FPContractMain
                                              {
                                                  FBCID = vc.FBCID,
                                                  CMID = vc.CMID,
                                                  ETWID = vc.ETWID,
                                                  VendorName = vc.VendorName,
                                                  LocationName = vc.LocationName,
                                                  OldSowNumber = vc.OldSowNumber,
                                                  SOWNumber = vc.SOWNumber,
                                                  SOWName = vc.SOWName,
                                                  SOWStartDate = vc.SOWStartDate,
                                                  SOWEndDate = vc.SOWEndDate,
                                                  AmortizationStartMonth = vc.AmortizationStartMonth,
                                                  AmortizationEndMonth = vc.AmortizationEndMonth,
                                                  PONumber = vc.PONumber,
                                                  POStartDate = vc.POStartDate,
                                                  POEndDate = vc.POEndDate,
                                                  PPMProjectID = vc.PPMProjectID,
                                                  PPMProjectName = vc.PPMProjectName,
                                                  VerticalName = vc.VerticalName,
                                                  TowerName = vc.TowerName,
                                                  DomainLeadEmail = vc.DomainLeadEmail,
                                                  CostCenter = vc.CostCenter,
                                                  OBSMasterName = vc.OBSMasterName,
                                                  DomainSkillName = vc.DomainSkillName,
                                                  SkillSet = vc.SkillSet,
                                                  DomainSkillStartDate = vc.DomainSkillStartDate,
                                                  DomainSkillEndDate = vc.DomainSkillEndDate,
                                                  WBSDetail = vc.WBSDetail,
                                                  ProjectOrRun = vc.ProjectOrRun,
                                                  BillingTypeName = vc.BillingTypeName,
                                                  RemappedMID = vc.RemappedMID,
                                                  WFOrder = vc.WFOrder,
                                                  ContractTypeName = vc.ContractTypeName,
                                                  Status = vc.Status,
                                                  PendingWithWhom = vc.PendingWithWhom,
                                                  UpdateDate = vc.UpdateDate,
                                                  UpdatedBy = vc.UpdatedBy,
                                                  IsActive = vc.IsActive,
                                                  SendBackReason = sl.Remarks
                                              }).ToList();

                return fpSendbackContractMainList;
            }
            return null;
        }
        public bool saveSeltedFpRowsPerTbl(List<int> ids,string mid,string name,int locId)
        {
   

            //var FPMilestone = selectedRows.Where(x => x.ContractType.Trim().ToLower() == "fixed price milestone" ).ToList();
            //var FPMonthly = selectedRows.Where(x => x.ContractType.Trim().ToLower() == "fixed price monthly" ).ToList();

            //var vendorMasterList = _MastersRepository.GetVendorMasterList();
            //var verticalMasterList = _MastersRepository.GetVerticalMasterList();
            //var towerMasterList = _MastersRepository.GetTowerMasterList();
            //var projectOrRun = _MastersRepository.GetprojectOrRunMasterList();
            //var positionLocation = _MastersRepository.GetLocationData();
            //var obsMasterList = _MastersRepository.GetOBSMasterList();
            //var skillsetMasterList = _MastersRepository.GetSkillMasterList();
            //var contractMasterList = _MastersRepository.GetContractMasterList();
            //var billingMasterlist = _MastersRepository.GetBillingMasterList();

            //var FPMilestoneList = (from fplist in FPMilestone
            //                       select new EmsTblFbvendorContractMilestoneMaster
            //                       { 
            //                           FbcmilestoneMasterId = 0,
            //                           Etwid = fplist.ETWID,
            //                           VendorId = vendorMasterList.Where(x => x.VendorName.Trim().ToLower() == fplist.VendorName.Trim().ToLower()).Select(x => x.VendorId).FirstOrDefault(),
            //                           PositionLocation = positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault().ToString(),
            //                           OldSowNumber = fplist.OldSowNumber,
            //                           Sownumber = fplist.SOWNumber,
            //                           Sowname = fplist.SOWName,
            //                           SowstartDate = fplist.SOWStartDate,
            //                           SowendDate = fplist.SOWEndDate,
            //                           Ponumber = fplist.PONumber,
            //                           PostartDate = fplist.POStartDate,
            //                           PoendDate = fplist.POEndDate,
            //                           PpmprojectId = fplist.PPMProjectID,
            //                           PpmprojectName = fplist.PPMProjectName,
            //                           VerticalId = verticalMasterList.Where(x => x.VerticalName.Trim().ToLower() == fplist.Vertical.Trim().ToLower()).Select(x => x.VerticalId).FirstOrDefault(),
            //                           TowerId = towerMasterList.Where(x => x.TowerName.Trim().ToLower() == fplist.Tower.Trim().ToLower()).Select(x => x.TowerNameId).FirstOrDefault(),
            //                           DomainLeadEmail = fplist.DomainLeadEmail,
            //                           CostCenter = fplist.CostCenter,
            //                           Obs = obsMasterList.Where(x => x.ObsmasterName.Trim().ToLower() == fplist.OBS.Trim().ToLower()).Select(x => x.ObsmasterId).FirstOrDefault().ToString(),
            //                           //DomainSkillName = skillsetMasterList.Where(x => x.SkillSet == fplist.DomainSkillName).Select(x => x.SkillId).FirstOrDefault().ToString(),
            //                           //SkillSet = fplist.SkillSet,
            //                           DomainSkillName = fplist.DomainSkillName,
            //                           SkillSet = skillsetMasterList.Where(x => x.SkillSet.Trim().ToLower() == fplist.SkillSet.Trim().ToLower()).Select(x => x.SkillId).FirstOrDefault().ToString(),
            //                           DomainSkillStartDate = fplist.DomainSkillStartDate,
            //                           DomainSkillEndDate = fplist.DomainSkillEndDate,
            //                           Wbsdetail = fplist.WBSDetail,
            //                           ProjectOrRunId = projectOrRun.Where(x => x.ProjectOrRun.Trim().ToLower() == fplist.ProjectOrRun.Trim().ToLower()).Select(x => x.ProjectOrRunId).FirstOrDefault(),
            //                           BillingTypeId = billingMasterlist.Where(x => x.BillingTypeName.Trim().ToLower() == "milestone based").Select(x => x.BillingTypeId).FirstOrDefault(),
            //                           RemappedMid = fplist.RemappedMID,
            //                           UpdateDate = DateTime.Now,
            //                           UpdatedBy = "",
            //                           ContractType= contractMasterList.Where(x => x.ContractTypeName.Trim().ToLower() == fplist.ContractType.Trim().ToLower()).Select(x => x.ContractTypeId).FirstOrDefault().ToString(),
            //                       }).ToList();

            //var FPMonthlyList = (from fplist in FPMonthly
            //                     select new EmsTblFbvendorContractMonthlyMaster
            //                     {
            //                         FbcmontlyId = 0,
            //                         Etwid = fplist.ETWID,
            //                         VendorId = vendorMasterList.Where(x => x.VendorName.Trim().ToLower() == fplist.VendorName.Trim().ToLower()).Select(x => x.VendorId).FirstOrDefault(),
            //                         PositionLocation = positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault().ToString(),
            //                         OldSowNumber = fplist.OldSowNumber,
            //                         Sownumber = fplist.SOWNumber,
            //                         Sowname = fplist.SOWName,
            //                         SowstartDate = fplist.SOWStartDate,
            //                         SowendDate = fplist.SOWEndDate,
            //                         AmortizationStartMonth = Convert.ToDateTime(fplist.AmortizationStartMonth),
            //                         AmortizationEndMonth = fplist.AmortizationEndMonth,
            //                         Ponumber = fplist.PONumber,
            //                         PostartDate = fplist.POStartDate,
            //                         PoendDate = fplist.POEndDate,
            //                         PpmprojectId = fplist.PPMProjectID,
            //                         PpmprojectName = fplist.PPMProjectName,
            //                         VerticalId = verticalMasterList.Where(x => x.VerticalName.Trim().ToLower() == fplist.Vertical.Trim().ToLower()).Select(x => x.VerticalId).FirstOrDefault(),
            //                         TowerId = towerMasterList.Where(x => x.TowerName.Trim().ToLower() == fplist.Tower.Trim().ToLower()).Select(x => x.TowerNameId).FirstOrDefault(),
            //                         DomainLeadEmail = fplist.DomainLeadEmail,
            //                         CostCenter = fplist.CostCenter,
            //                         Obs = obsMasterList.Where(x => x.ObsmasterName.Trim().ToLower() == fplist.OBS.Trim().ToLower()).Select(x => x.ObsmasterId).FirstOrDefault().ToString(),
            //                         //DomainSkillName = skillsetMasterList.Where(x => x.SkillSet == fplist.DomainSkillName).Select(x => x.SkillId).FirstOrDefault().ToString(),
            //                         //SkillSet = fplist.SkillSet,

            //                         DomainSkillName = fplist.DomainSkillName,
            //                         SkillSet = skillsetMasterList.Where(x => x.SkillSet.Trim().ToLower() == fplist.SkillSet.Trim().ToLower()).Select(x => x.SkillId).FirstOrDefault().ToString(),

            //                         DomainSkillStartDate = fplist.DomainSkillStartDate,
            //                         DomainSkillEndDate = fplist.DomainSkillEndDate,
            //                         Wbsdetail = fplist.WBSDetail,
            //                         ProjectOrRunId = projectOrRun.Where(x => x.ProjectOrRun.Trim().ToLower() == fplist.ProjectOrRun.Trim().ToLower()).Select(x => x.ProjectOrRunId).FirstOrDefault(),
            //                         ContractType = contractMasterList.Where(x => x.ContractTypeName.Trim().ToLower() == fplist.ContractType.Trim().ToLower()).Select(x => x.ContractTypeId).FirstOrDefault().ToString(),
            //                         //BillingType = fplist.BillingType,
            //                         BillingType = billingMasterlist.Where(x => x.BillingTypeName.Trim().ToLower() == fplist.BillingType.Trim().ToLower()).Select(x => x.BillingTypeId).FirstOrDefault().ToString(),
            //                         RemappedMid = fplist.RemappedMID,
            //                         UpdateDate = DateTime.Now,
            //                         UpdatedBy = ""
            //                     }).ToList();

            //var distinctlist1 = FPMilestoneList.GroupBy(x => x.Sowname).Select(g => g.First());
            //var ContractMasterData = new List<EmsTblContractMaster>();
            //if (distinctlist1 != null && distinctlist1.Count() > 0)
            //{
            //    foreach (var item in distinctlist1)
            //    {
            //        if (item != null)
            //        {
            //            var i = new EmsTblContractMaster();
            //            i.Sowname = item.Sowname;
            //            i.Status = "Pending";
            //            i.SowStartDate = item.SowstartDate;
            //            //i.PositionCode = "";
            //            i.SkillSetId = int.TryParse(item.SkillSet, out int skillresult) ? (int?)skillresult : null;
            //            i.IsActive = true;

            //            ContractMasterData.Add(i);
            //        }
            //    }
            //}
            //var distinctlist2 = FPMonthlyList.GroupBy(x => x.Sowname).Select(g => g.First());
            //if (distinctlist2 != null && distinctlist2.Count() > 0)
            //{
            //    foreach (var item in distinctlist2)
            //    {
            //        if (item != null)
            //        {
            //            var i = new EmsTblContractMaster();
            //            i.Sowname = item.Sowname;
            //            i.Status = "Pending";
            //            i.SowStartDate = item.SowstartDate;
            //            //i.PositionCode = "";
            //            i.SkillSetId = int.TryParse(item.SkillSet, out int skillresult) ? (int?)skillresult : null;
            //            i.IsActive = true;

            //            ContractMasterData.Add(i);
            //        }
            //    }
            //} 

            //var result = _fPContractRepository.saveSeltedFpRowsPerTbl(FPMilestoneList, FPMonthlyList, ContractMasterData);

            var FinanceMgrList = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.FinanceManager, locId)
                                  .Where(x => x.IsPrimaryPerson == true).ToList();
            if (FinanceMgrList.Count == 0)
            {
                return false;
            }

            var result = _fPContractRepository.saveSeltedFpRowsPerTbl(ids, Constants.ProcurementWFOrder.ProcurementLead, FinanceMgrList, mid, name, locId);


            MailMessageDetails objmails = new MailMessageDetails();

            var IT_Finacnce_Manager = _MastersRepository.GetrolesbyRoleType("IT Finance Manager", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
            objmails.To = string.Join(", ", IT_Finacnce_Manager);
            objmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
            objmails.Subject = "Fixed price contracts for approval";
            objmails.Cc = "";
            _mailtemp.GenerateAndSendMail(objmails);


            return result;
        }


        public bool saveSeltedFpMlRowsPerTbl(List<int> ids)
        {

            var result =  _fPContractRepository.saveSeltedFpMlRowsPerTbl(ids);
            return true;
        }


        public bool saveSeltedFpMoRowsPerTbl(List<int> ids)
        {
            var result1 = _fPContractRepository.saveSeltedFpMoRowsPerTbl(ids);
            return true; 
        }
        
        public async Task<string> CallAPI(string requestedItemName, string requestedItemDescription)
        {
            HttpMessageHandler handler = new HttpClientHandler();
            var apiUrl = _configuration.GetValue<string>("hrServiceCenterAPI:apiUrl");
            using var httpClient = new HttpClient(handler)
            {
                BaseAddress = new Uri(apiUrl),  
                Timeout = new TimeSpan(0, 2, 0)  
            };

            httpClient.DefaultRequestHeaders.Add("ContentType", "application/json");

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes($"{_configuration.GetValue<string>("hrServiceCenterAPI:hrServiceCenterName")}:{_configuration.GetValue<string>("hrServiceCenterAPI:hrServiceCenterPassword")}");
            string val = System.Convert.ToBase64String(plainTextBytes);
            httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + val);

            var requestData = new
            {
                requestedItemName,
                requestedItemDescription
            };

            var jsonPayload = Newtonsoft.Json.JsonConvert.SerializeObject(requestData);

            using var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            var response = await httpClient.PostAsync(apiUrl, content);

            if (response.IsSuccessStatusCode)
            {
                var settings = new JsonSerializerSettings(); settings.CheckAdditionalContent = false;
                //dynamic responseObject = Newtonsoft.Json.JsonConvert.DeserializeObject(await );
 
                var extract = await response.Content.ReadAsStringAsync();

                string requestString = extract;
                Match match = Regex.Match(requestString, @"RITM\d+");

                if (match.Success)
                {
                    string requestNumber = match.Value;
                    return requestNumber;  
                }
                else
                {
                    return "Request number not found";
                } 
            }
            else
            {
                throw new HttpRequestException($"API request failed with status code {response.StatusCode}");
            }
        }

        private string alterContractStatus(string status)
        {
            if (status != null)
            {
                return status == "Open" ? "Position Open" : status == "Closed" ? "Position Onboarded" : "Pending";


            }
            return status;
        }

        #region "FP Approval"
        public List<FPContract> GetFPMContractPendingList(int WFOrder, int Location)
        {
            var fpmContractInt = new List<FPContract>();
            var result = _fPContractRepository.GetFPMilestoneContractPendingList(WFOrder, Location);

            if (result != null)
            {
                foreach (var contract in result)
                {


                    var item = new FPContract();
                    item.CMID = contract.CMID;
                    item.FBCIntID = contract.FBCMilestoneMasterID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;


                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;

                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;


                    item.PositionLocation = contract.LocationName;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;

                    item.SkillSet = contract.SkillSet;

                    item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.UpdatedOn = contract.UpdateDate;
                    item.remarks = "";
                    item.OBS = contract.OBSMasterName;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.vendoreMail = contract.EmailIDs;
                    item.IsActive = contract.IsActive;

                    fpmContractInt.Add(item);
                }
            }
            return fpmContractInt;
        }
        public List<FPContractMl> GetFPMContractDetail(string sowNumber)
        {
            var fpmContractMil = new List<FPContractMl>();
            var result = _fPContractRepository.GetFPMilestoneContractDetail(sowNumber);
            var currencies = _MastersRepository.GetCurrenctMasterList();
            if (result != null)
            {
                foreach (var contract in result)
                {


                    var item = new FPContractMl();
                    item.FBCMilestoneIntID = contract.FbcmilestoneDetailId;
                    item.Milestone = contract.Milestone;
                    item.MilestoneAmount = contract.MilestoneAmount ?? 0;
                    item.MilstoneDescription = contract.MilstoneDescription;
                    item.SOWNumber = contract.Sownumber;
                    item.Currency = currencies.Where(x => x.CurrencyId == contract.CurrencyId).Select(x => x.Description).FirstOrDefault() ?? "";

                    fpmContractMil.Add(item);
                }
            }
            return fpmContractMil;
        }


        public List<FPContractMain> GetFPContractMainList(string filter, DateTime fromdate,DateTime todate, string ActiveFilter)
        {
            var fpContractMainList = new List<FPContractMain>();
            var result = _fPContractRepository.GetFPContractMainList(filter,Convert.ToInt32(SessionManager.CurrentUser.Location_ID),fromdate,todate,ActiveFilter);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new FPContractMain();
                    item.FBCID = contract.FBCID;
                    item.CMID = contract.CMID;
                    item.ETWID = contract.ETWID;
                    item.VendorName = contract.VendorName;
                    item.LocationName = contract.LocationName;
                    item.OldSowNumber = contract.OldSowNumber;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.AmortizationStartMonth = contract.AmortizationStartMonth;
                    item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.VerticalName = contract.VerticalName;
                    item.TowerName = contract.TowerName;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.CostCenter = contract.CostCenter;
                    item.OBSMasterName = contract.OBSMasterName;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.WBSDetail = contract.WBSDetail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.BillingTypeName = contract.BillingTypeName;
                    item.RemappedMID = contract.RemappedMID;
                    item.WFOrder = contract.WFOrder;
                    item.ContractTypeName = contract.ContractTypeName;
                    item.Status = contract.Status;
                    item.PendingWithWhom = contract.PendingWithWhom;
                    item.UpdateDate = contract.UpdateDate;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.IsActive = contract.IsActive;


                    fpContractMainList.Add(item);
                }
            }
            return fpContractMainList;
        }


        public string UpdateFpContractDetails(EmsVwFpvendorContractMasterWithId fpDetails, string mid, string name, bool isProcLead, int locId)
        {
            var update = _fPContractRepository.ValidateAndSaveContract(fpDetails, mid, name, isProcLead, locId);
            if ( update.Contains("Contract saved successfully"))
            {
                MailMessageDetails objmails = new MailMessageDetails();

                var IT_Finacnce_Manager = _MastersRepository.GetrolesbyRoleType("IT Finance Manager", locId).Where(x => x.IsActive == true).Select(x => x.EmailId).ToList();
                objmails.To = string.Join(";", IT_Finacnce_Manager);
                objmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                objmails.Subject = "Fixed price contracts for approval";
                //objmails.Cc = "chethan@gmail.com";
                _mailtemp.GenerateAndSendMail(objmails);

            }

            //return update.Result;
            return string.Join(", ", update);
        }

        public string PostFPMContractList(List<FPContract> contracts)
        {
            string? nxtPendingWith = "", prvPendingWith = "", postres = "Failure";
            var fpmContractInt = new List<FPContract>();
            var _objFPMVendorContractMasters = new List<EmsTblFbvendorContractMilestoneMaster>();
            var _objFPMVendorContractWFHistory = new List<EmsTblFpcontractWorkFlowMilestone>();
            var _objFPMVendorContract = new List<EmsTblContractMaster>();

            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
            MailMessageDetails objmailsPMOAdmin = new MailMessageDetails();
            

            var nextWFOrder = new EmsTblWorkFlowMaster();
            var prevWFOrder = new EmsTblWorkFlowMaster();

            var result = _fPContractRepository.GetFPContractWFOrder();
            int wfOrder = 1;
            var loginlocationId = SessionManager.CurrentUser.Location_ID ?? 0;
            if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
            {

                //When Finance Manager approve
                //If Approved
                nextWFOrder = result.Where(x => x.Wforder > Constants.ProcurementWFOrder.FinanceManager).OrderBy(x => x.Wforder).FirstOrDefault();
                //If Sendback
                prevWFOrder = (from wf in result
                               join prewf in result on wf.SendBackWforder equals prewf.Wforder
                               where wf.Wforder == Constants.ProcurementWFOrder.FinanceManager
                               select prewf).FirstOrDefault();
            }

            //Should trigger to Resource Manager                   
            if (nextWFOrder != null)
            {
                var nxtroleaster = _MastersRepository.GetrolesbyRoleType(nextWFOrder.Wfrole, loginlocationId);
                nxtPendingWith = nxtroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();
            }
            //Should trigger to Procurtment lead               
            if (prevWFOrder != null)
            {
                var preroleaster = _MastersRepository.GetrolesbyRoleType(prevWFOrder.Wfrole, loginlocationId);
                prvPendingWith = preroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();

            }
            //This condition is not applicable for last approval, need to add one more section
            if (nextWFOrder != null && prevWFOrder != null)
            {
                foreach (var con in contracts)
                {
                    _objFPMVendorContractMasters.Add(new EmsTblFbvendorContractMilestoneMaster()
                    {

                        Cmid = con.CMID,
                        FbcmilestoneMasterId = con.FBCIntID,
                        PendingWithWhom = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? null : nxtPendingWith : prvPendingWith,
                        Wforder = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? null : nextWFOrder.Wforder : prevWFOrder.Wforder,
                        Status =(con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? "Closed":"Open" : "Pending",
                        Etwid = con.ETWID,
                        RemappedMid=con.RemappedMID,
                        SowstartDate=con.SOWStartDate,
                        SowendDate=con.SOWEndDate,
                        Sownumber = con.SOWNumber,
                        DomainSkillEndDate = con.DomainSkillEndDate

                    });
                    _objFPMVendorContractWFHistory.Add(new EmsTblFpcontractWorkFlowMilestone()
                    {
                        Cmid = con.FBCIntID,
                        Role = Constants.ProcurementWFRoles.FinanceManager,//Need to change this 
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        // Action = (con.isSelectedApproval == true) ? "Approved" : "Sentback",
                        Action = (con.isSelectedApproval == true) ?
                                        (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate <= DateTime.Now.Date) ? "Approve and Resource Mapped"
                                            : (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate > DateTime.Now.Date) ? " Approve and Scheduled For Resource Mapping" : "Approved"
                                        : "Sentback",
                       Remarks = (con.isSelectedApproval == true) ? con.RemappedMID != null && con.RemappedMID != "" ?
                                                (con.remarks != null && con.remarks != "") ? con.remarks + ", RemappedMID:" + con.RemappedMID
                                                : "RemappedMID : " + con.RemappedMID
                                      : con.remarks : con.remarks,
                        NextWfrole = (con.isSelectedApproval == true) ?
                            (con.RemappedMID != null && con.RemappedMID != "") ? null :
                            nextWFOrder.Wfrole : prevWFOrder.Wfrole
                    });
                   

                }
                // Update status as Open in Contract table

                _objFPMVendorContract = (from cm in contracts
                                         where cm.isSelectedApproval == true
                                         select new EmsTblContractMaster()
                                         {

                                             Status = (cm.RemappedMID != null && cm.RemappedMID != "")?"Closed": "Open",
                                             PositionCode = cm.ETWID,
                                             Cmid = cm.CMID ?? 0,
                                             // IsActive = cm.IsActive,
                                             //SkillSetId = cm.SkillSet,
                                             Sowname = cm.SOWName,
                                             SowStartDate = cm.SOWStartDate

                                         }).OrderBy(x => x.Status).DistinctBy(x => x.PositionCode).ToList();
            }

            //Push Data to Database
            postres = _fPContractRepository.PostFPMilestoneContractApproval(_objFPMVendorContractMasters, _objFPMVendorContractWFHistory, _objFPMVendorContract);
            //If Data update is success send mail
            if (postres == "success")
            {

                if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
                {

                    var vendorGroup = contracts.DistinctBy(x => x.VendorName).ToList();
                    foreach (var vendor in vendorGroup)
                    {
                        //Fetch only Approved list
                        var vContract = contracts.Where(x => x.VendorName == vendor.VendorName && x.isSelectedApproval == true && (x.RemappedMID==null || x.RemappedMID =="")).ToList();
                        if (vContract.Any())
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                                worksheet.Columns(1, 27).Style.Font.FontColor = XLColor.Black;
                                worksheet.Columns(1, 27).AdjustToContents();
                                // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                                worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                                worksheet.Cell(1, 1).Value = "ETWID";
                                worksheet.Cell(1, 2).Value = "VendorName";
                                worksheet.Cell(1, 3).Value = "SOWNumber";
                                worksheet.Cell(1, 4).Value = "SOWName";

                                worksheet.Cell(1, 5).Value = "SOWStartDate";
                                worksheet.Cell(1, 6).Value = "SOWEndDate";
                                worksheet.Cell(1, 7).Value = "PONumber";
                                worksheet.Cell(1, 8).Value = "POStartDate";
                                worksheet.Cell(1, 9).Value = "POEndDate";
                                worksheet.Cell(1, 10).Value = "DomainSkillName";
                                worksheet.Cell(1, 11).Value = "Skillset";

                                worksheet.Cell(1, 12).Value = "DomainSkillStartDate";
                                worksheet.Cell(1, 13).Value = "DomainSkillEndDate";
                                worksheet.Cell(1, 14).Value = "ContractType";

                                worksheet.Cell(1, 15).Value = "PPMProjectID";
                                worksheet.Cell(1, 16).Value = "ProjectName";
                                worksheet.Cell(1, 17).Value = "Tower";

                                worksheet.Cell(1, 18).Value = "BillingType";
                              //  worksheet.Cell(1, 19).Value = "CostCenter";
                                worksheet.Cell(1, 19).Value = "RemappedMID";

                                worksheet.Cell(1, 20).Value = "FirstName";
                                worksheet.Cell(1, 21).Value = "LastName";
                                worksheet.Cell(1, 22).Value = "Gender";
                                worksheet.Cell(1, 23).Value = "DOB";
                                worksheet.Cell(1, 24).Value = "DOJViatris";
                                worksheet.Cell(1, 25).Value = "ManagerName";

                                worksheet.Cell(1, 26).Value = "ManagerEmail";
                                worksheet.Cell(1, 27).Value = "MobileNumber";

                                for (int index = 1; index <= vContract.Count; index++)
                                {
                                    worksheet.Cell(index + 1, 1).Value = vContract[index - 1].ETWID;
                                    worksheet.Cell(index + 1, 2).Value = vContract[index - 1].VendorName;
                                    worksheet.Cell(index + 1, 3).Value = vContract[index - 1].SOWNumber;
                                    worksheet.Cell(index + 1, 4).Value = vContract[index - 1].SOWName;

                                    worksheet.Cell(index + 1, 5).Value = vContract[index - 1].SOWStartDate;
                                    worksheet.Cell(index + 1, 5).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 6).Value = vContract[index - 1].SOWEndDate;
                                    worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 7).Value = vContract[index - 1].PONumber;
                                    worksheet.Cell(index + 1, 8).Value = vContract[index - 1].POStartDate;
                                    worksheet.Cell(index + 1, 8).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 9).Value = vContract[index - 1].POEndDate;
                                    worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";

                                    worksheet.Cell(index + 1, 10).Value = vContract[index - 1].DomainSkillName;
                                    worksheet.Cell(index + 1, 11).Value = vContract[index - 1].SkillSet;

                                    worksheet.Cell(index + 1, 12).Value = vContract[index - 1].DomainSkillStartDate;
                                    worksheet.Cell(index + 1, 12).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 13).Value = vContract[index - 1].DomainSkillEndDate;
                                    worksheet.Cell(index + 1, 13).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 14).Value = vContract[index - 1].ContractType;

                                    worksheet.Cell(index + 1, 15).Value = vContract[index - 1].PPMProjectID;
                                    worksheet.Cell(index + 1, 16).Value = vContract[index - 1].PPMProjectName;
                                    worksheet.Cell(index + 1, 17).Value = vContract[index - 1].Tower;

                                    worksheet.Cell(index + 1, 18).Value = vContract[index - 1].BillingType;
                                   // worksheet.Cell(index + 1, 19).Value = vContract[index - 1].CostCenter;


                                }
                                using (var stream = new MemoryStream())
                                {
                                    workbook.SaveAs(stream);
                                    var content = stream.ToArray();
                                    //MemoryStream attachmentStream = new MemoryStream(content);
                                    //Attachment attachment = new Attachment(stream, filename, contentType);

                                    objmails.Attachment = content;
                                    objmails.To = vendor.vendoreMail ?? "";
                                    objmails.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                                    objmails.From = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                                    objmails.Subject = "Require Onboarding Resource Data";
                                }
                            }
                            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                            var PMOAdmin = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ResourceManager, locId).Select(x => x.EmailId);
                            StringBuilder mailBody = new StringBuilder();
                            objmailsPMOAdmin.To = string.Join(";", PMOAdmin);
                            objmailsPMOAdmin.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                            objmailsPMOAdmin.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                            objmailsPMOAdmin.Subject = "Contracts Approved";
                            objmailsPMOAdmin.applicationLink= _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";

                            _mailtemp.SendFPMContractApproval(objmails, "Approve");
                            _mailtemp.SendTMContractApproval(objmailsPMOAdmin, "ApproveToPMO");
                        }
                    }
                    //Send Mail send back to procurtment lead 
                    var uploadedby = contracts.Where(x => x.isSelectedApproval == false).DistinctBy(x => x.UpdatedBy).ToList();

                    if (uploadedby != null && uploadedby.Count != 0)
                    {

                        int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

                        var procurtmentGroup = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ProcurementLead, locId).Select(x => x.EmailId);
                        var financeGroup = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.FinanceManager, locId).Select(x => x.EmailId);

                        StringBuilder mailBody = new StringBuilder();
                    
                        objsendbackmails.To = string.Join(";", procurtmentGroup);
                        objsendbackmails.Cc = string.Join(",", financeGroup);
                        objsendbackmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                        objsendbackmails.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";
                        objsendbackmails.Subject = "Contracts Sent back by IT Finance Manager";


                        //var sentBacklist = contracts.Where(x => x.isSelectedApproval == false && x.UpdatedBy == entity.UpdatedBy).ToList();
                        //    mailBody.Append("<table border=1>");
                        //    mailBody.Append("<tr cellpadding=5px><th bgcolor=\"#800080\">ETWID</th><th bgcolor=\"#800080\">Vendor</th><th bgcolor=\"#800080\">SOW Number</th><th bgcolor=\"#800080\">SOW Name</th>><th bgcolor=\"#800080\">Remarks</th></tr>");

                        //    foreach (var sb in sentBacklist)
                        //    {
                        //        mailBody.Append("<tr cellpadding=5px><td>" + sb.ETWID + "</td><td>" + sb.VendorName + "</td><td>" + sb.SOWNumber + "</td><td>" + sb.SOWName + "</td><td>" + sb.remarks + "</td></tr>");

                        //    }
                        //    mailBody.Append("</table><br><br> Regards,<br>Admin Team - Viatris");

                        //    objsendbackmails.Body = mailBody.ToString();
                            _mailtemp.SendFPMContractApproval( objsendbackmails, "sendback");
                        

                    }


                }


            }
            return postres;
        }
        public List<FPContract> GetFPMONContractPendingList(int WFOrder, int Location)
        {
            var fpmContractInt = new List<FPContract>();
            var result = _fPContractRepository.GetFPMonthlyContractPendingList(WFOrder, Location);

            if (result != null)
            {
                foreach (var contract in result)
                {


                    var item = new FPContract();
                    item.CMID = contract.CMID;
                    item.FBCIntID = contract.FBCMONTLYID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;


                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;

                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;


                    item.PositionLocation = contract.LocationName;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;

                    item.SkillSet = contract.SkillSet;

                    item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.remarks = "";
                    item.OBS = contract.OBSMasterName;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.vendoreMail = contract.EmailIDs;

                    item.AmortizationStartMonth=contract.AmortizationStartMonth;
                    item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    item.UpdatedOn = contract.UpdateDate;
                    item.IsActive = contract.IsActive;
                    fpmContractInt.Add(item);
                }
            }
            return fpmContractInt;
        }
        public List<FPContractMo> GetFPMONContractDetail(string sowNumber)
        {
            var fpmContractMon = new List<FPContractMo>();
            var result = _fPContractRepository.GetFPMonthlyContractDetail(sowNumber);
            var currencies = _MastersRepository.GetCurrenctMasterList();
            if (result != null)
            {
                foreach (var contract in result)
                {


                    var item = new FPContractMo();
                    item.FBMonthlyIntID = contract.FbmonthlyDetailId;
                    item.DurationOfMonth= contract.DurationOfMonth??0;
                    item.MilestoneAmount = contract.MilestoneAmount ?? 0;
                    item.AmortizationStartDate = contract.AmortizationStartDate;
                    item.AmortizationEndDate = contract.AmortizationEndDate;
                    item.SOWNumber = contract.Sownumber;
                    item.Currency = currencies.Where(x => x.CurrencyId == contract.CurrencyId).Select(x => x.Description).FirstOrDefault() ?? "";

                    fpmContractMon.Add(item);
                }
            }
            return fpmContractMon;
        }
        public string PostFPMONContractList(List<FPContract> contracts)
        {
            string? nxtPendingWith = "", prvPendingWith = "", postres = "Failure";
            var fpmContractInt = new List<FPContract>();
            var _objFPMonVendorContractMasters = new List<EmsTblFbvendorContractMonthlyMaster>();
            var _objFPMVendorContractWFHistory = new List<EmsTblFpcontractWorkFlowMonthly>();
            var _objFPMVendorContract = new List<EmsTblContractMaster>();

            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objmailsPMOAdmin = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
            


            var nextWFOrder = new EmsTblWorkFlowMaster();
            var prevWFOrder = new EmsTblWorkFlowMaster();

            var result = _fPContractRepository.GetFPContractWFOrder();
            int wfOrder = 1;
            var loginlocationId = SessionManager.CurrentUser.Location_ID ?? 0;
            if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
            {

                //When Finance Manager approve
                //If Approved
                nextWFOrder = result.Where(x => x.Wforder > Constants.ProcurementWFOrder.FinanceManager).OrderBy(x => x.Wforder).FirstOrDefault();
                //If Sendback
                prevWFOrder = (from wf in result
                               join prewf in result on wf.SendBackWforder equals prewf.Wforder
                               where wf.Wforder == Constants.ProcurementWFOrder.FinanceManager
                               select prewf).FirstOrDefault();
            }

            //Should trigger to Resource Manager                   
            if (nextWFOrder != null)
            {
                var nxtroleaster = _MastersRepository.GetrolesbyRoleType(nextWFOrder.Wfrole, loginlocationId);
                nxtPendingWith = nxtroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();
            }
            //Should trigger to Procurtment lead               
            if (prevWFOrder != null)
            {
                var preroleaster = _MastersRepository.GetrolesbyRoleType(prevWFOrder.Wfrole, loginlocationId);
                prvPendingWith = preroleaster.Where(x => x.IsPrimaryPerson == true).Select(x => x.Mid).FirstOrDefault();

            }
            //This condition is not applicable for last approval, need to add one more section
            if (nextWFOrder != null && prevWFOrder != null)
            {
                foreach (var con in contracts)
                {
                    _objFPMonVendorContractMasters.Add(new EmsTblFbvendorContractMonthlyMaster()
                    {

                        Cmid = con.CMID,
                        FbcmontlyId = con.FBCIntID,
                        PendingWithWhom = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? null : nxtPendingWith : prvPendingWith,
                        Wforder = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? null : nextWFOrder.Wforder : prevWFOrder.Wforder,
                        Status = (con.isSelectedApproval == true) ? (con.RemappedMID != null && con.RemappedMID != "") ? "Closed" : "Open" : "Pending",
                        Etwid = con.ETWID,
                        RemappedMid=con.RemappedMID,
                        SowstartDate = con.SOWStartDate,
                        SowendDate = con.SOWEndDate,
                        Sownumber = con.SOWNumber,
                        DomainSkillEndDate = con.DomainSkillEndDate
                    });
                    _objFPMVendorContractWFHistory.Add(new EmsTblFpcontractWorkFlowMonthly()
                    {
                        Cmid = con.FBCIntID,
                        Role = Constants.ProcurementWFRoles.FinanceManager,//Need to change this 
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        // Action = (con.isSelectedApproval == true) ? "Approved" : "Sentback",
                        Action = (con.isSelectedApproval == true) ?
                                        (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate <= DateTime.Now.Date) ? "Approved and Resource Mapped"
                                            : (con.RemappedMID != null && con.RemappedMID != "" && con.SOWStartDate > DateTime.Now.Date) ? "Approved and Scheduled For Resource Mapping" : "Approved"
                                        : "Sentback",
                       Remarks = (con.isSelectedApproval == true) ? con.RemappedMID != null && con.RemappedMID != "" ?
                                                (con.remarks != null && con.remarks != "") ? con.remarks + ", RemappedMID:" + con.RemappedMID
                                                : "RemappedMID : " + con.RemappedMID
                                      : con.remarks : con.remarks,
                        NextWfrole = (con.isSelectedApproval == true) ? nextWFOrder.Wfrole : prevWFOrder.Wfrole
                    });

                }
                // Update status as Open in Contract table

                _objFPMVendorContract = (from cm in contracts
                                         where cm.isSelectedApproval == true
                                         select new EmsTblContractMaster()
                                         {

                                             Status = (cm.RemappedMID != null && cm.RemappedMID != "") ? "Closed" : "Open",
                                             PositionCode = cm.ETWID,
                                             Cmid = cm.CMID ?? 0,
                                             // IsActive = cm.IsActive,
                                             //SkillSetId = cm.SkillSet,
                                             Sowname = cm.SOWName,
                                             SowStartDate = cm.SOWStartDate

                                         }).OrderBy(x => x.Status).DistinctBy(x => x.PositionCode).ToList();
            }

            //Push Data to Database
            postres = _fPContractRepository.PostFPMonthlyContractApproval(_objFPMonVendorContractMasters, _objFPMVendorContractWFHistory, _objFPMVendorContract);
            //If Data update is success send mail
            if (postres == "success")
            {

                if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
                {

                    var vendorGroup = contracts.DistinctBy(x => x.VendorName).ToList();
                    foreach (var vendor in vendorGroup)
                    {
                        //Fetch only Approved list
                        var vContract = contracts.Where(x => x.VendorName == vendor.VendorName && x.isSelectedApproval == true && (x.RemappedMID == null || x.RemappedMID=="")).ToList();
                        if (vContract.Count > 0)
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                                worksheet.Columns(1, 27).Style.Font.FontColor = XLColor.Black;
                                worksheet.Columns(1, 27).AdjustToContents();
                                // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                                worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                                worksheet.Cell(1, 1).Value = "ETWID";
                                worksheet.Cell(1, 2).Value = "VendorName";
                                worksheet.Cell(1, 3).Value = "SOWNumber";
                                worksheet.Cell(1, 4).Value = "SOWName";

                                worksheet.Cell(1, 5).Value = "SOWStartDate";
                                worksheet.Cell(1, 6).Value = "SOWEndDate";
                                worksheet.Cell(1, 7).Value = "PONumber";
                                worksheet.Cell(1, 8).Value = "POStartDate";
                                worksheet.Cell(1, 9).Value = "POEndDate";
                                worksheet.Cell(1, 10).Value = "DomainSkillName";
                                worksheet.Cell(1, 11).Value = "Skillset";

                                worksheet.Cell(1, 12).Value = "DomainSkillStartDate";
                                worksheet.Cell(1, 13).Value = "DomainSkillEndDate";
                                worksheet.Cell(1, 14).Value = "ContractType";

                                worksheet.Cell(1, 15).Value = "PPMProjectID";
                                worksheet.Cell(1, 16).Value = "ProjectName";
                                worksheet.Cell(1, 17).Value = "Tower";

                                worksheet.Cell(1, 18).Value = "BillingType";
                               // worksheet.Cell(1, 19).Value = "CostCenter";
                                worksheet.Cell(1, 19).Value = "RemappedMID";

                                worksheet.Cell(1, 20).Value = "FirstName";
                                worksheet.Cell(1, 21).Value = "LastName";
                                worksheet.Cell(1, 22).Value = "Gender";
                                worksheet.Cell(1, 23).Value = "DOB";
                                worksheet.Cell(1, 24).Value = "DOJViatris";
                                worksheet.Cell(1, 25).Value = "ManagerName";
                                worksheet.Cell(1, 26).Value = "ManagerEmail";
                                worksheet.Cell(1, 27).Value = "MobileNumber";

                                for (int index = 1; index <= vContract.Count; index++)
                                {
                                    worksheet.Cell(index + 1, 1).Value = vContract[index - 1].ETWID;
                                    worksheet.Cell(index + 1, 2).Value = vContract[index - 1].VendorName;
                                    worksheet.Cell(index + 1, 3).Value = vContract[index - 1].SOWNumber;
                                    worksheet.Cell(index + 1, 4).Value = vContract[index - 1].SOWName;

                                    worksheet.Cell(index + 1, 5).Value = vContract[index - 1].SOWStartDate;
                                    worksheet.Cell(index + 1, 5).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 6).Value = vContract[index - 1].SOWEndDate;
                                    worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 7).Value = vContract[index - 1].PONumber;
                                    worksheet.Cell(index + 1, 8).Value = vContract[index - 1].POStartDate;
                                    worksheet.Cell(index + 1, 8).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 9).Value = vContract[index - 1].POEndDate;
                                    worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 10).Value = vContract[index - 1].DomainSkillName;
                                    worksheet.Cell(index + 1, 11).Value = vContract[index - 1].SkillSet;

                                    worksheet.Cell(index + 1, 12).Value = vContract[index - 1].DomainSkillStartDate;
                                    worksheet.Cell(index + 1, 12).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 13).Value = vContract[index - 1].DomainSkillEndDate;
                                    worksheet.Cell(index + 1, 13).Style.DateFormat.Format = "dd-MMM-yyyy";
                                    worksheet.Cell(index + 1, 14).Value = vContract[index - 1].ContractType;

                                    worksheet.Cell(index + 1, 15).Value = vContract[index - 1].PPMProjectID;
                                    worksheet.Cell(index + 1, 16).Value = vContract[index - 1].PPMProjectName;
                                    worksheet.Cell(index + 1, 17).Value = vContract[index - 1].Tower;

                                    worksheet.Cell(index + 1, 18).Value = vContract[index - 1].BillingType;
                                  //  worksheet.Cell(index + 1, 19).Value = vContract[index - 1].CostCenter;


                                }
                                using (var stream = new MemoryStream())
                                {
                                    workbook.SaveAs(stream);
                                    var content = stream.ToArray();
                                    //MemoryStream attachmentStream = new MemoryStream(content);
                                    //Attachment attachment = new Attachment(stream, filename, contentType);

                                    objmails.Attachment = content;
                                    objmails.To = vendor.vendoreMail ?? "";
                                    objmails.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                                    objmails.From = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                                    objmails.Subject = "Require Onboarding Resource Data";
                                }
                            }
                            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                            var PMOAdmin = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ResourceManager, locId).Select(x => x.EmailId);
                            StringBuilder mailBody = new StringBuilder();
                            objmailsPMOAdmin.To = string.Join(";", PMOAdmin);
                            objmailsPMOAdmin.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                            objmailsPMOAdmin.Cc = _configuration.GetValue<string>("MailSettings:GIDCFinance") ?? "donotreply-EMS@viatris.com";
                            objmailsPMOAdmin.Subject = "Contracts Approved";
                            objmailsPMOAdmin.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";

                            _mailtemp.SendFPMContractApproval(objmails, "Approve");
                            _mailtemp.SendTMContractApproval(objmailsPMOAdmin, "ApproveToPMO");
                        }
                    }
                    //Send Mail send back to procurtment lead 
                    var uploadedby = contracts.Where(x => x.isSelectedApproval == false).DistinctBy(x => x.UpdatedBy).ToList();

                    if (uploadedby != null && uploadedby.Count!=0)
                    {

                        int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

                        var procurtmentGroup = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.ProcurementLead, locId).Select(x => x.EmailId);
                        var financeGroup = _MastersRepository.GetrolesbyRoleType(Constants.ProcurementWFRoles.FinanceManager, locId).Select(x => x.EmailId);

                        StringBuilder mailBody = new StringBuilder();

                         
                        objsendbackmails.To = string.Join(";", procurtmentGroup);
                        objsendbackmails.Cc = string.Join(",", financeGroup);
                        objsendbackmails.From = _configuration.GetValue<string>("MailSettings:fromemail") ?? "donotreply-EMS@viatris.com";
                        objsendbackmails.applicationLink = _configuration.GetValue<string>("AppSettings:ApplicationLink") ?? "";
                        objsendbackmails.Subject = "Contracts Sent back by IT Finance Manager";

                        //var sentBacklist = contracts.Where(x => x.isSelectedApproval == false && x.UpdatedBy == entity.UpdatedBy).ToList();
                        //    mailBody.Append("<table border=1>");
                        //    mailBody.Append("<tr cellpadding=5px><th bgcolor=\"#800080\">ETWID</th><th bgcolor=\"#800080\">Vendor</th><th bgcolor=\"#800080\">SOW Number</th><th bgcolor=\"#800080\">SOW Name</th>><th bgcolor=\"#800080\">Remarks</th></tr>");

                        //    foreach (var sb in sentBacklist)
                        //    {
                        //        mailBody.Append("<tr cellpadding=5px><td>" + sb.ETWID + "</td><td>" + sb.VendorName + "</td><td>" + sb.SOWNumber + "</td><td>" + sb.SOWName + "</td><td>" + sb.remarks + "</td></tr>");

                        //    }
                        //    mailBody.Append("</table><br><br> Regards,<br>Admin Team - Viatris");

                        //    objsendbackmails.Body = mailBody.ToString();
                            _mailtemp.SendFPMContractApproval( objsendbackmails, "sendback");
                        

                    }


                }


            }
            return postres;
        }
        #endregion
        #region "FP Contract Track List"
        public List<FPContract> GetFPContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter)
        {
            var fpContractInt = new List<FPContract>();
            var result = _fPContractRepository.GetFPContractTrackList(WFOrder, Location, filter,ActiveFilter);

            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new FPContract();
                    item.FBCIntID = contract.FBCMilestoneMasterID;
                    item.CMID = contract.CMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;

                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;
                   
                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;

                    item.PositionLocation = contract.LocationName;
                    item.DomainSkillName = contract.DomainskillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                   
                    item.SkillSet = contract.SkillSet;
                   
                    item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.UpdatedOn = contract.UpdateDate;
                    item.remarks = "";
                  
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.wfOrder = contract.WFOrder;
                    item.Status = contract.Status;
                    item.Pendingwithwhom = contract.PendingWithWhom;
                    item.OBS = contract.obsmastername;
                    item.IsActive = contract.isactive;
                    fpContractInt.Add(item);
                }
            }
            return fpContractInt;
        }
        public List<FPContract> GetFPContractMonthlyTrackList(int WFOrder, int Location, string filter,string ActiveFilter)
        {
            var fpContractInt = new List<FPContract>();
            var result = _fPContractRepository.GetFPContractMonthlyTrackList(WFOrder, Location, filter, ActiveFilter);

            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new FPContract();
                    item.FBCIntID = contract.FBCMontlyID;
                    item.CMID = contract.CMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                   // item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.OldSowNumber = contract.OldSOWNumber;

                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingType = contract.BillingTypeName;
                    item.Tower = contract.TowerName;
                    item.ContractType = contract.ContractTypeName;

                    item.PPMProjectID = contract.PPMProjectID;
                    item.VendorName = contract.vendorname;

                    item.AmortizationStartMonth = contract.AmortizationStartMonth;
                    item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    item.PONumber = contract.PONumber;
                   

                    item.PositionLocation = contract.LocationName;
                    item.DomainSkillName = contract.DomainskillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;

                    item.SkillSet = contract.SkillSet;

                    item.Vertical = contract.VerticalName;
                    item.WBSDetail = contract.WBSDetail;
                    item.CostCenter = contract.CostCenter;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.UpdatedOn = contract.UpdateDate;
                    item.remarks = "";

                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.RemappedMID = contract.RemappedMID;
                    item.wfOrder = contract.WFOrder;
                    item.Status = contract.Status;
                    item.Pendingwithwhom = contract.PendingWithWhom;
                    item.OBS = contract.obsmastername;
                    // item.OBS = contract;

                    item.IsActive = contract.IsActive;
                    fpContractInt.Add(item);
                }
            }
            return fpContractInt;
        }

       
        #endregion
    }



}
