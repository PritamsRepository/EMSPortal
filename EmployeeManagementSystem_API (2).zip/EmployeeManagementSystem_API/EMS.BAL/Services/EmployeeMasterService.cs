﻿using DocumentFormat.OpenXml.Wordprocessing;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_DAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Services
{
    public class EmployeeMasterService : IEmployeeMaster
    {
        private readonly IEmployeeMasterRepository _employeeMasterRepository;
        public EmployeeMasterService(IEmployeeMasterRepository employeeMasterRepository)
        {
            _employeeMasterRepository = employeeMasterRepository;
        }
        public List<EmployeeMaster> GetAllEmployee()
        {
            var dbResult = _employeeMasterRepository.GetAllEmployee();
            var employeeList = new List<EmployeeMaster>();
            if (dbResult is not null)
            {
                dbResult.ForEach(x => employeeList.Add(new EmployeeMaster
                {
                    Rmid = x.Rmid,

                    Cmid = x.Cmid,
                    ViatrisMid = x.ViatrisMid,
                    EmpName = x.EmpName,
                    ManagerMid = x.ManagerMid,
                    ViatrisEmailId = x.ViatrisEmailId,
                    VendorName = x.VendorName,
                    Dojviatris = x.Dojviatris,
                    MobileNo = x.MobileNo,
                    Dob = x.Dob,
                    PositionCode = x.PositionCode,
                    ResourceStatus = x.ResourceStatus,
                    Tmcmid = x.Tmcmid,
                    SkillSet = x.SkillSet,
                    LocationName = x.LocationName,
                    ContractTypeName = x.ContractTypeName,
                    SowTypeName = x.SowTypeName,
                    Sowname = x.Sowname,
                    Sownumber = x.Sownumber,
                    SowstartDate = x.SowstartDate,
                    SowendDate = x.SowendDate,
                    Ponumber = x.Ponumber,
                    PostartDate = x.PostartDate,
                    PoendDate = x.PoendDate,
                    BillingTypeName = x.BillingTypeName,
                    VerticalName = x.VerticalName,
                    ProjectOrRun = x.ProjectOrRun,
                    DomainName = x.DomainName,
                    DomainLeadEmail = x.DomainLeadEmail,
                    DomainSkillStartDate = x.DomainSkillStartDate,
                    DomainSkillEndDate = x.DomainSkillEndDate,
                    Sapcode = x.Sapcode,
                    CostCenter = x.CostCenter,
                    PpmprojectId = x.PpmprojectId,
                    PpmprojectName = x.PpmprojectName,
                    TowerName = x.TowerName,

                    Etwid = x.Etwid,
                    CustomDomainName = x.CustomDomainName,
                    ManagerName = x.ManagerName,
                    ManagerEmail = x.ManagerEmail,
                    ContractStatus = x.ContractStatus,
                    AmortizationStartMonth = x.AmortizationStartMonth,
                    AmortizationEndMonth = x.AmortizationEndMonth,
                    Wbsdetail = x.Wbsdetail,
                    Obs = x.Obs,
                    Lwd = x.Lwd,
                    NoticePeriod = x.NoticePeriod,
                    OldSownumber = x.OldSownumber,
                    Currency = x.Currency,
                    BillingRateYear1 = x.BillingRateYear1,
                    BillingRateYear2 = x.BillingRateYear2,
                    BillingRateYear3 = x.BillingRateYear3,
                    BillingRateYear4 = x.BillingRateYear4,
                    BillingRateYear5 = x.BillingRateYear5,
                    Milestones = x.Milestones,
                    MilestoneDescription = x.MilestoneDescription,
                    MilestonesAmount = x.MilestonesAmount,
                    MonthlyContractAmount = x.MonthlyContractAmount,
                    DurationOfMonths = x.DurationOfMonths,
                }));
            }
            return employeeList;

        }
    }
}
