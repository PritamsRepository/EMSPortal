﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EMS_BAL.Model;
using EMS_BAL.Interface;
using System.Threading;
using EMS_BAL.Helper;
using Microsoft.AspNetCore.Identity;
using EMS_DAL.Interface;
using System.Security.Policy;
using EMS_DAL.Entities;
using EMS.BAL.Model;
using DocumentFormat.OpenXml.Drawing.Spreadsheet;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Extensions.Configuration;

namespace EMS_BAL.Services
{
    public class AuthenticationServices : IAuthenticateServices
    {
        private readonly AppSettings _appSettings;
        private IUserService _userService;
        private readonly Security _security;
        private readonly ISet<RefreshToken> _refreshTokens = new HashSet<RefreshToken>();
        private readonly IJwtHandler _jwtHandler;
        private readonly ISet<Login> _users = new HashSet<Login>();
        private readonly IPasswordHasher<Login> _passwordHasher;
        private readonly IMastersRepository _masterRepository;
        private readonly IConfiguration _configuration;

        public AuthenticationServices (IJwtHandler jwtHandler, IPasswordHasher<Login> passwordHasher, IMastersRepository mastersRepository, IConfiguration configuration)
        {

            _jwtHandler = jwtHandler;
            _passwordHasher = passwordHasher;
            _masterRepository = mastersRepository;
            this._configuration = configuration;
        }


        public JsonWebToken SignIn (string username, string password)
        {
            _userService = new UserService(this._configuration);

            var userInfo = _userService.GetUserInfo(username, password);
            if (userInfo == null)
            {
                throw new Exception("Invalid credentials.");
            }

            var roleMaster = _masterRepository.GetRolesByMID(username);
            var roles = new List<Role>();
            if (roleMaster.Any())
            {
                roleMaster.ForEach(r => roles.Add(new Role
                {
                    RoleId = r.RoleMasterId,
                    RoleName = r.RoleType

                }));
                var jwt = _jwtHandler.Create(username, roles);
                var refreshToken = _passwordHasher.HashPassword(new Login { UserName = username, Password = password }, Guid.NewGuid().ToString())
                    .Replace("+", string.Empty)
                    .Replace("=", string.Empty)
                    .Replace("/", string.Empty);
                jwt.RefreshToken = refreshToken;
                _refreshTokens.Add(new RefreshToken { Username = username, Token = refreshToken });
                jwt.UserProfile = userInfo;
                return jwt;
            }
            else
            {
                return null;
            }
         

        }

        public JsonWebToken SignInViaWinAuth(string username) {
            _userService = new UserService(this._configuration);

            var userInfo = _userService.GetUserInfoForWindowAuth(username);
            if (userInfo == null)
            {
                throw new Exception("Invalid credentials.");
            }

            var roleMaster = _masterRepository.GetRolesByMID(username);
            var roles = new List<Role>();
            if (roleMaster.Any())
            {
                roleMaster.ForEach(r => roles.Add(new Role
                {
                    RoleId = r.RoleMasterId,
                    RoleName = r.RoleType

                }));
            }
            var jwt = _jwtHandler.Create(username, roles);
            var refreshToken = _passwordHasher.HashPassword(new Login { UserName = username, Password = string.Empty }, Guid.NewGuid().ToString())
                .Replace("+", string.Empty)
                .Replace("=", string.Empty)
                .Replace("/", string.Empty);
            jwt.RefreshToken = refreshToken;
            _refreshTokens.Add(new RefreshToken { Username = username, Token = refreshToken });
            jwt.UserProfile = userInfo;
            return jwt;

        }

        public JsonWebToken RefreshAccessToken (string token)
        {
            var refreshToken = GetRefreshToken(token);
            if (refreshToken == null)
            {
                throw new Exception("Refresh token was not found.");
            }
            if (refreshToken.Revoked)
            {
                throw new Exception("Refresh token was revoked");
            }
            var jwt = _jwtHandler.Create(refreshToken.Username, null); ;
            jwt.RefreshToken = refreshToken.Token;

            return jwt;
        }

        public void RevokeRefreshToken (string token)
        {
            var refreshToken = GetRefreshToken(token);
            if (refreshToken == null)
            {
                throw new Exception("Refresh token was not found.");
            }
            if (refreshToken.Revoked)
            {
                throw new Exception("Refresh token was already revoked.");
            }
            refreshToken.Revoked = true;
        }
        private RefreshToken GetRefreshToken (string token) => _refreshTokens.SingleOrDefault(x => x.Token == token);



        public string GenerateToken (string userName)
        {

            var timeOutValue = Convert.ToDouble(45);
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Constants.JWT.Secret));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256Signature);
            var tokeOptions = new JwtSecurityToken(
                issuer: Constants.JWT.ValidIssuer,
                audience: Constants.JWT.ValidAudience,
                claims: new List<Claim>(),
                expires: DateTime.Now.AddMinutes(timeOutValue),
                signingCredentials: signinCredentials
            );
            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
            return tokenString;
        }

        public void SignUp (string username, string password)
        {
            throw new NotImplementedException();
        }
        public LocationWithRoles GetLocationAndRolesByMid(string mid)
        {

            var locationWithRole = new LocationWithRoles();

            locationWithRole.UserRoles =  _masterRepository.GetRolesByMID(mid);
            var locations = _masterRepository.loactionDetails();

            locationWithRole.UserLocation = (from rm in locationWithRole.UserRoles
                                             join lm in locations on rm.LocationId equals lm.LocationId
                                             where rm.IsActive == true && lm.IsActive == true
                                             group new LocationRole()
                                             {
                                                 LocationId = rm.LocationId,
                                                 LocationName = lm.LocationName
                                             } by new { rm.LocationId, lm.LocationName } into g
                                             select g.First()
                                        ).ToList();
            return locationWithRole;
        }

        public UserRolePreference GetUserRolePrefernce (string mid)
        {
            var result = _masterRepository.GetRolePreferenceByName(mid);
            var rolePreference = new UserRolePreference();
            if (result !=null)
            {
                rolePreference = new UserRolePreference
                {
                    RoleMasterId = result.RoleMasterId,
                    LocationId = result.LocationId,
                    UserId = result.UserId,
                };
            }
            else
            {
                //Create fake pref based on role
                var role = _masterRepository.GetRolesByMID(mid).FirstOrDefault();
                if (role != null)
                {
                    rolePreference = new UserRolePreference
                    {
                        RoleMasterId = role.RoleMasterId,
                        LocationId = role.LocationId,
                        UserId = mid,
                    };

                    // Insert new user preference
                    rolePreference = UserPreference(rolePreference);
                }

            }
            return rolePreference;


        }

        public UserRolePreference UserPreference(UserRolePreference pref)
        {

            var prefData = _masterRepository.UserRolePreference(pref.UserId, Convert.ToInt32(pref.LocationId),Convert.ToInt32(pref.RoleMasterId));
            var userPreference = new UserRolePreference
            {
                LocationId = prefData.LocationId,
                RoleMasterId = prefData.RoleMasterId,
                UserId = prefData.UserId
            };
            return userPreference;
        }
    }
}