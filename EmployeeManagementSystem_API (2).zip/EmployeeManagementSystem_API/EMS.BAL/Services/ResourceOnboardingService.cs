﻿using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetTopologySuite.Triangulate.Tri;
using EMS_BAL.Model;
using System.DirectoryServices;
using System.Security.Cryptography;
using System.IO;
using System.Reflection;
using ClosedXML.Excel;
using Microsoft.Extensions.Configuration;
using EMS.BAL.Helper;
using System.Drawing;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Presentation;
using System.Numerics;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Security.Policy;
using static System.Runtime.InteropServices.JavaScript.JSType;
using DocumentFormat.OpenXml.Drawing.Charts;

namespace EMS.BAL.Services
{
    public class ResourceOnboardingService : IResourceOnboardingService
    {

        private IResourceMappingRepository _ResourceMappingRepository;
        private IMastersRepository _MastersRepository;
        private readonly IConfiguration _configuration;
        private MailMessageTemplate _mailtemp;
        public ResourceOnboardingService(IResourceMappingRepository resourceMappingRepository, IConfiguration configuration,IMastersRepository mastersRepository)
        {
            _ResourceMappingRepository = resourceMappingRepository;
            _MastersRepository = mastersRepository;
            this._configuration = configuration;
            _mailtemp = new MailMessageTemplate(this._configuration);

        }
        public List<ResourceOnboardingModel> GetResourceMappingPendingList(string UserName, int LocationId)
        {
            var empdetails = new List<ResourceOnboardingModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceMappingPendingList(UserName, workfloworder, LocationId);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceOnboardingModel();
                    item.TMCMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.PositionCode = contract.PositionCode;
                    item.RemappedMID = contract.RemappedMID;
                    //item.BillingRateYear2 = contract.BillingRateYear2;
                    //item.BillingRateYear3 = contract.BillingRateYear3;
                    //item.BillingRateYear4 = contract.BillingRateYear4;
                    //item.BillingRateYear5 = contract.BillingRateYear5;
                    //item.NoticePeriod = contract.NoticePeriod;
                    //item.PositionLocation = contract.LocationName;
                    //item.SAPCode = contract.SAPCode;
                    //item.WBSDetail = contract.WBSDetail;
                    item.UploadedBy=contract.UploadedBy;
                    item.VendorName = contract.VendorName;

                    //item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    item.ValidationRemarks = contract.ValidationRemarks;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    //item.Vertical = contract.VerticalName;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    item.ManagerName = contract.ManagerName;
                    item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.TMRMID = contract.TMRMIntID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.ProjectOrRun=contract.ProjectOrRun;
                    item.CustomDomainName = contract.CustomDomainName;
                    empdetails.Add(item);
                }
            }
            return empdetails;
        }


        public List<ResourceOnboardingModel> GetTMOnboardingApprovalPendingList(string UserName)
        {
            var empdetails = new List<ResourceOnboardingModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetTMOnboardingApprovalPendingList(UserName, workfloworder);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceOnboardingModel();
                    item.TMCMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.PositionCode = contract.PositionCode;
                    //item.BillingRateYear2 = contract.BillingRateYear2;
                    //item.BillingRateYear3 = contract.BillingRateYear3;
                    //item.BillingRateYear4 = contract.BillingRateYear4;
                    //item.BillingRateYear5 = contract.BillingRateYear5;
                    //item.NoticePeriod = contract.NoticePeriod;
                    //item.PositionLocation = contract.LocationName;
                    //item.SAPCode = contract.SAPCode;
                    //item.WBSDetail = contract.WBSDetail;
                    item.UploadedBy = contract.UploadedBy;
                    item.VendorName = contract.VendorName;

                    //item.RemappedMID = contract.RemappedMID;
                    //item.OldSowNumber = contract.OldSOWNumber;
                    //item.CostCenter = contract.CostCenter;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    //item.Vertical = contract.VerticalName;
                    empdetails.Add(item);

                }
            }
            return empdetails;
        }

        public List<ResourceOnboardingModel> SaveOnBoardingResourceMappingPendingList(List<ResourceOnboardingModel> result)
        {
            var tblList = new List<EmsTblTmresourceMappingIntermediate>();
            var MID = "";
            var MailError = "";
            var VendorMaster = _MastersRepository.GetVendorMasterList();
            foreach (var contract in result)
            {
                var item = new EmsTblTmresourceMappingIntermediate();
                item.PositionCode = contract.PositionCode;
                item.PositionStatus = "New";
                item.RemappedMid = contract.RemappedMID;
                item.VendorName = contract.VendorName;
                item.Sownumber = contract.SOWNumber;
                item.Etwid = contract.ETWID;
                item.FirstName = contract.FirstName;
                item.LastName = contract.LastName;
                item.Gender = contract.Gender;
                item.Dojviatris = contract.DOJViatris;
                item.Dob = contract.DOB;
                item.MobileNo = contract.MobileNumber==null?null: contract.MobileNumber.ToString();
                item.ManagerMid = contract.ManagerEmail == null || contract.ManagerEmail == "" ? null : GetUserInfo(contract.ManagerEmail.Trim());

                item.PositionLocationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                item.ManagerName = contract.ManagerName;
                item.ManagerEmailId = contract.ManagerEmail;
                item.CostCenterNo = contract.CostCenter;
                item.VendorId = VendorMaster.Where(x=>x.VendorName==contract.VendorName).Select(x=>x.VendorId).FirstOrDefault();
                item.UploadedBy = SessionManager.CurrentUser.MID;
                item.UploadDate = DateTime.Now;
              
                    tblList.Add(item);
                
            }
            _ResourceMappingRepository.AddTMContractResourceMappingIntermediate(tblList, SessionManager.CurrentUser.MID,Convert.ToInt32( SessionManager.CurrentUser.Location_ID));
            return null;
        }

        public string GetUserInfo(string EmailID)
        {
            if (EmailID != null)
            {
                UserProfile userprofile = null;
                EmailID = EmailID.Trim();
                DirectorySearcher ds = new DirectorySearcher
                {
                    Filter = "(mail=" + EmailID + ")"
                };
                SearchResult userProperty = ds.FindOne();
               
                var MID =userProperty==null?null: userProperty.Properties["SAMAccountName"][0].ToString();

                return MID;
            }
            else return null;
        }


        public List<ResourceOnboardingModel> SaveTMOnBoardingResourceApprovalData(List<ResourceOnboardingModel> result)
        {
            var tblList = new List<EmsTblResourceMaster>();
            var _objTMVendorContractMasters = new List<EmsTblTmvendorContractMaster>();
            var _objTMVendorContractWFHistory = new List<EmsTblContractMaster>();
            var _objTmcontractWorkFlow = new List<EmsTblTmcontractWorkFlow>();
            var approvedlist = result.Where(x => x.IsSelectedApproval == true).ToList();
            var rejectedlist = result.Where(x => x.IsSelectedApproval == false).ToList();
            var vendorID = 0;
            if (approvedlist.Count > 0)
            {
                foreach (var contract in approvedlist)
                {
                    if (contract.RemappedMID == null || contract.RemappedMID == "")
                    {
                        vendorID = Convert.ToInt16(contract.VendorID);
                        // _ResourceMappingRepository.UpdateResourceMasterstatus(contract.ETWID, contract.PositionCode);
                        var item = new EmsTblResourceMaster();
                        item.VendorId = contract.VendorID;
                        item.FirstName = contract.FirstName;
                        item.LastName = contract.LastName;
                        item.Gender = contract.Gender;
                        item.Dob = contract.DOB;
                        item.Dojviatris = contract.DOJViatris;
                        item.MobileNo = contract.MobileNumber;
                        item.ManagerMid = contract.ManagerMid;
                        item.CostCenterNo = contract.CostCenter;
                        item.Ritm = null;
                        item.ViatrisMid = null;
                        item.ViatrisEmailId = null;
                        item.ResourceStatus = "Active";
                        item.UploadedBy = SessionManager.CurrentUser.MID;
                        item.UploadDate = DateTime.Now;
                        item.PositionCode = contract.PositionCode;
                        tblList.Add(item);
                    }
                    _objTMVendorContractMasters.Add(new EmsTblTmvendorContractMaster()
                    {
                        Tmvcmid = Convert.ToInt32(contract.TMVCMID),
                        Etwid = contract.ETWID,
                        Status = "Closed",
                        //Wforder = (contract.RemappedMID != null && contract.RemappedMID != "") ?null: 3,
                        Wforder=null,
                        //  Added to make Pending with whom empty when the position is closed. Need to add PendingWithWhom in the model and assign approperiate value
                        PendingWithWhom = (contract.RemappedMID != null && contract.RemappedMID != "") ? null :null ,
                        //Status= contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now?"Approved":"Closed",
                         RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "") ? contract.RemappedMID : null,
                        // RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date) ? null : (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date) ? contract.RemappedMID : null,
                        SowstartDate = contract.SOWStartDate,
                        PositionCode=contract.PositionCode,
                        Tmcmid= contract.TMCMID,
                        Sownumber = contract.SOWNumber,
                        DomainSkillEndDate = contract.DomainSkillEndDate

                    });
                    _objTMVendorContractWFHistory.Add(new EmsTblContractMaster()
                    {
                        Cmid = Convert.ToInt32(contract.TMCMID),
                        PositionCode = contract.PositionCode,
                        //Status = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date ? "Approved" : "Closed",
                        Status="Closed"
                    });
                    _objTmcontractWorkFlow.Add(new EmsTblTmcontractWorkFlow()
                    {
                        Tmcid = Convert.ToInt32(contract.TMVCMID),
                        Role = "PMO-Admin ",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        //Action = "Forwarded For MID Creation",
                        Action = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date ? "Resource Mapped": contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date  ? "Scheduled For Resource Mapping" : contract.RemappedMID == null||contract.RemappedMID==""  ? "Forwarded For MID Creation" : null,
                        Remarks = contract.RemappedMID != null && contract.RemappedMID != "" ? (contract.Remarks != null && contract.Remarks != "") ? contract.Remarks + ", Remapped MID : " + contract.RemappedMID : " Remapped MID : " + contract.RemappedMID : contract.Remarks,
                        NextWfrole = (contract.RemappedMID != null && contract.RemappedMID != "")?null: "PMO-Admin"
                    });

                }
                _ResourceMappingRepository.AddTMDataToResourcemaster(tblList, _objTMVendorContractMasters, _objTMVendorContractWFHistory, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlow, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));
            }
            if (rejectedlist.Count > 0)
            {
                var _objTmcontractWorkFlowRejected = new List<EmsTblTmcontractWorkFlow>();
                foreach (var rejected in rejectedlist)
                {
                    _objTmcontractWorkFlowRejected.Add(new EmsTblTmcontractWorkFlow()
                    {
                        Tmcid = Convert.ToInt32(rejected.TMVCMID),
                        Role = "PMO-Admin",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        Action = "Rejected",
                        //Remarks = "Rejected",
                        Remarks= rejected.Remarks,
                        NextWfrole = "PMO-Admin"
                    });
                }
                _ResourceMappingRepository.AddTMRejectedResourceDataWorkflow(SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlowRejected, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));

                MailMessageDetails objmails = new MailMessageDetails();
                MailMessageDetails objsendbackmails = new MailMessageDetails();
                var vendorGroup = result.DistinctBy(x => x.VendorName).ToList();
                foreach (var vendor in vendorGroup)
                {
                    //Fetch only Approved list
                    var rejectedrecords = result.Where(x => x.VendorName == vendor.VendorName && x.IsSelectedApproval == false).ToList();
                    using (var workbook = new XLWorkbook())
                    {
                        IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                        worksheet.Columns(1, 30).Style.Font.FontColor = XLColor.Black;
                        worksheet.Columns(1, 30).AdjustToContents();
                        // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                        worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                        worksheet.Cell(1, 1).Value = "ETWID";
                        worksheet.Cell(1, 2).Value = "PositionCode";
                        worksheet.Cell(1, 3).Value = "VendorName";
                        worksheet.Cell(1, 4).Value = "SOWNumber";
                        worksheet.Cell(1, 5).Value = "SOWName";

                        worksheet.Cell(1, 6).Value = "SOWStartDate";
                        worksheet.Cell(1, 7).Value = "SOWEndDate";
                        worksheet.Cell(1, 8).Value = "PONumber";
                        worksheet.Cell(1, 9).Value = "POStartDate";
                        worksheet.Cell(1, 10).Value = "POEndDate";
                        worksheet.Cell(1, 11).Value = "ContractType";

                        worksheet.Cell(1, 12).Value = "PPMProjectID";
                        worksheet.Cell(1, 13).Value = "ProjectName";
                        worksheet.Cell(1, 14).Value = "Tower";
                        worksheet.Cell(1, 15).Value = "DomainSkillName";
                        worksheet.Cell(1, 16).Value = "Skillset";

                        worksheet.Cell(1, 17).Value = "DomainSkillStartDate";
                        worksheet.Cell(1, 18).Value = "DomainSkillEndDate";
                        worksheet.Cell(1, 19).Value = "BillingType";
                        worksheet.Cell(1, 20).Value = "RemappedMID";
                        //worksheet.Cell(1, 21).Value = "CostCenter";
                        worksheet.Cell(1, 21).Value = "FirstName";

                        worksheet.Cell(1, 22).Value = "LastName";
                        worksheet.Cell(1, 23).Value = "Gender";
                        worksheet.Cell(1, 24).Value = "DOB";
                        worksheet.Cell(1, 25).Value = "DOJViatris";
                        worksheet.Cell(1, 26).Value = "ManagerName";

                        worksheet.Cell(1, 27).Value = "ManagerEmail";
                        worksheet.Cell(1, 28).Value = "MobileNumber";
                        worksheet.Cell(1, 29).Value = "Reason For SendBack";

                        for (int index = 1; index <= rejectedrecords.Count; index++)
                        {
                            worksheet.Cell(index + 1, 1).Value = rejectedrecords[index - 1].ETWID;
                            worksheet.Cell(index + 1, 2).Value = rejectedrecords[index - 1].PositionCode;
                            worksheet.Cell(index + 1, 3).Value = rejectedrecords[index - 1].VendorName;
                            worksheet.Cell(index + 1, 4).Value = rejectedrecords[index - 1].SOWNumber;
                            worksheet.Cell(index + 1, 5).Value = rejectedrecords[index - 1].SOWName;

                            worksheet.Cell(index + 1, 6).Value = rejectedrecords[index - 1].SOWStartDate;
                            worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 7).Value = rejectedrecords[index - 1].SOWEndDate;
                            worksheet.Cell(index + 1, 7).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 8).Value = rejectedrecords[index - 1].PONumber;
                            worksheet.Cell(index + 1, 9).Value = rejectedrecords[index - 1].POStartDate;
                            worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 10).Value = rejectedrecords[index - 1].POEndDate;
                            worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 11).Value = rejectedrecords[index - 1].ContractType;

                            worksheet.Cell(index + 1, 12).Value = rejectedrecords[index - 1].PPMProjectID;
                            worksheet.Cell(index + 1, 13).Value = rejectedrecords[index - 1].PPMProjectName;
                            worksheet.Cell(index + 1, 14).Value = rejectedrecords[index - 1].Tower;
                            worksheet.Cell(index + 1, 15).Value = rejectedrecords[index - 1].DomainName;
                            worksheet.Cell(index + 1, 16).Value = rejectedrecords[index - 1].SkillSet;

                            worksheet.Cell(index + 1, 17).Value = rejectedrecords[index - 1].DomainSkillStartDate;
                            worksheet.Cell(index + 1, 17).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 18).Value = rejectedrecords[index - 1].DomainSkillEndDate;
                            worksheet.Cell(index + 1, 18).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 19).Value = rejectedrecords[index - 1].BillingType;
                            worksheet.Cell(index + 1, 20).Value = rejectedrecords[index - 1].RemappedMID;
                            //worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].CostCenter;

                            worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].FirstName;
                            worksheet.Cell(index + 1, 22).Value = rejectedrecords[index - 1].LastName;
                            worksheet.Cell(index + 1, 23).Value = rejectedrecords[index - 1].Gender;
                            worksheet.Cell(index + 1, 24).Value = rejectedrecords[index - 1].DOB;
                            worksheet.Cell(index + 1, 24).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 25).Value = rejectedrecords[index - 1].DOJViatris;
                            worksheet.Cell(index + 1, 25).Style.DateFormat.Format = "dd-MMM-yyyy";

                            worksheet.Cell(index + 1, 26).Value = rejectedrecords[index - 1].ManagerName;
                            worksheet.Cell(index + 1, 27).Value = rejectedrecords[index - 1].ManagerEmail;
                            worksheet.Cell(index + 1, 28).Value = rejectedrecords[index - 1].MobileNumber;
                            worksheet.Cell(index + 1, 29).Value = rejectedrecords[index - 1].Remarks;


                        }
                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            objmails.Attachment = content;
                            objmails.To = vendor.VendorEmails ?? "";
                            objmails.Cc = "gidc.businessfinanceops@viatris.com";
                            objmails.From = "gidc.businessfinanceops@viatris.com";
                            objmails.Subject = "Resource Onboarding Data – Send Back for Correction";
                        }
                    }
                    _mailtemp.SendTMContractApproval(objmails, "ResourceManagerRejected");
                }

            }
            return null;
        }



        public bool sendOpenPositionsToVendor(List<ResourceOnboardingModel> result)
        {
            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
            var vendorGroup = result.DistinctBy(x => x.VendorName).ToList();
            foreach (var vendor in vendorGroup)
            {
                //Fetch only Approved list
                var rejectedrecords = result.Where(x => x.VendorName == vendor.VendorName && x.FirstName==null &&x.LastName==null).ToList();
                using (var workbook = new XLWorkbook())
                {
                    IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                    worksheet.Columns(1, 29).Style.Font.FontColor = XLColor.Black;
                    worksheet.Columns(1, 29).AdjustToContents();
                    // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                    worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;
                    worksheet.Cell(1, 1).Value = "ETWID";
                    worksheet.Cell(1, 2).Value = "PositionCode";
                    worksheet.Cell(1, 3).Value = "VendorName";
                    worksheet.Cell(1, 4).Value = "SOWNumber";
                    worksheet.Cell(1, 5).Value = "SOWName";

                    worksheet.Cell(1, 6).Value = "SOWStartDate";
                    worksheet.Cell(1, 7).Value = "SOWEndDate";
                    worksheet.Cell(1, 8).Value = "PONumber";
                    worksheet.Cell(1, 9).Value = "POStartDate";
                    worksheet.Cell(1, 10).Value = "POEndDate";
                    worksheet.Cell(1, 11).Value = "ContractType";

                    worksheet.Cell(1, 12).Value = "PPMProjectID";
                    worksheet.Cell(1, 13).Value = "ProjectName";
                    worksheet.Cell(1, 14).Value = "Tower";
                    worksheet.Cell(1, 15).Value = "DomainSkillName";
                    worksheet.Cell(1, 16).Value = "Skillset";

                    worksheet.Cell(1, 17).Value = "DomainSkillStartDate";
                    worksheet.Cell(1, 18).Value = "DomainSkillEndDate";
                    worksheet.Cell(1, 19).Value = "BillingType";
                    worksheet.Cell(1, 20).Value = "RemappedMID";
                    worksheet.Cell(1, 21).Value = "FirstName";

                    worksheet.Cell(1, 22).Value = "LastName";
                    worksheet.Cell(1, 23).Value = "Gender";
                    worksheet.Cell(1, 24).Value = "DOB";
                    worksheet.Cell(1, 25).Value = "DOJViatris";
                    worksheet.Cell(1, 26).Value = "ManagerName";

                    worksheet.Cell(1, 27).Value = "ManagerEmail";
                    worksheet.Cell(1, 28).Value = "MobileNumber";
               
                    for (int index = 1; index <= rejectedrecords.Count; index++)
                    {
                        worksheet.Cell(index + 1, 1).Value = rejectedrecords[index - 1].ETWID;
                        worksheet.Cell(index + 1, 2).Value = rejectedrecords[index - 1].PositionCode;
                        worksheet.Cell(index + 1, 3).Value = rejectedrecords[index - 1].VendorName;
                        worksheet.Cell(index + 1, 4).Value = rejectedrecords[index - 1].SOWNumber;
                        worksheet.Cell(index + 1, 5).Value = rejectedrecords[index - 1].SOWName;

                        worksheet.Cell(index + 1, 6).Value = rejectedrecords[index - 1].SOWStartDate;
                        worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 7).Value = rejectedrecords[index - 1].SOWEndDate;
                        worksheet.Cell(index + 1, 7).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 8).Value = rejectedrecords[index - 1].PONumber;
                        worksheet.Cell(index + 1, 9).Value = rejectedrecords[index - 1].POStartDate;
                        worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 10).Value = rejectedrecords[index - 1].POEndDate;
                        worksheet.Cell(index + 1, 10).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 11).Value = rejectedrecords[index - 1].ContractType;

                        worksheet.Cell(index + 1, 12).Value = rejectedrecords[index - 1].PPMProjectID;
                        worksheet.Cell(index + 1, 13).Value = rejectedrecords[index - 1].PPMProjectName;
                        worksheet.Cell(index + 1, 14).Value = rejectedrecords[index - 1].Tower;
                        worksheet.Cell(index + 1, 15).Value = rejectedrecords[index - 1].DomainName;
                        worksheet.Cell(index + 1, 16).Value = rejectedrecords[index - 1].SkillSet;

                        worksheet.Cell(index + 1, 17).Value = rejectedrecords[index - 1].DomainSkillStartDate;
                        worksheet.Cell(index + 1, 17).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 18).Value = rejectedrecords[index - 1].DomainSkillEndDate;
                        worksheet.Cell(index + 1, 18).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 19).Value = rejectedrecords[index - 1].BillingType;
                        worksheet.Cell(index + 1, 20).Value = rejectedrecords[index - 1].RemappedMID;
                    

                        worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].FirstName;
                        worksheet.Cell(index + 1, 22).Value = rejectedrecords[index - 1].LastName;
                        worksheet.Cell(index + 1, 23).Value = rejectedrecords[index - 1].Gender;
                        worksheet.Cell(index + 1, 24).Value = rejectedrecords[index - 1].DOB;
                        worksheet.Cell(index + 1, 24).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 25).Value = rejectedrecords[index - 1].DOJViatris;
                        worksheet.Cell(index + 1, 25).Style.DateFormat.Format = "dd-MMM-yyyy";

                        worksheet.Cell(index + 1, 26).Value = rejectedrecords[index - 1].ManagerName;
                        worksheet.Cell(index + 1, 27).Value = rejectedrecords[index - 1].ManagerEmail;
                        worksheet.Cell(index + 1, 28).Value = rejectedrecords[index - 1].MobileNumber;


                    }
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        objmails.Attachment = content;
                        objmails.To = vendor.VendorEmails ?? "";
                        objmails.Cc = "gidc.businessfinanceops@viatris.com";
                        objmails.From = "gidc.businessfinanceops@viatris.com";
                        objmails.Subject = "Require Onboarding Resource Data";
                    }
                }
                _mailtemp.SendTMContractApproval(objmails, "SendDataToVendor");
            }
            return true;
        }


        public List<ResourceTrackModel> GetResourceMappingTrackDetails(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceMappingTrackDetails(UseName, workflowOrder, locationID, Filter, ActiveFilter, FromDate, Todate);
            if (result.Count>0)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.SowType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.PositionCode = contract.PositionCode;
                    item.BillingRateYear2 = contract.BillingRateYear2;
                    item.BillingRateYear3 = contract.BillingRateYear3;
                    item.BillingRateYear4 = contract.BillingRateYear4;
                    item.BillingRateYear5 = contract.BillingRateYear5;
                    item.NoticePeriod = contract.NoticePeriod;
                    item.PositionLocation = contract.LocationName;
                    item.SapCode = contract.SAPCode;
                    item.WbsDetail = contract.WBSDetail;
                    item.OBS = contract.OBS;
                    item.Currency = contract.Currency;
                    item.Vertical = contract.VerticalName;
                    item.PendingWithWhom = contract.PendingWithWhom;
                    item.UploadedBY = contract.UploadedBy;
                    item.uploadedDate = contract.UploadedDate;
                    item.OldSowNumber = contract.OldSOWNumber;
                    item.IsActive = contract.IsActive==true? "Active" :"In Active";
                    item.VendorName = contract.VendorName;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.CostCenter = contract.CostCenter;
                    //item.ValidationRemarks = contract.ValidationRemarks;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                 
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    //item.ManagerName = contract.ManagerName;
                    //item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.RemappedMID = contract.RemappedMID;
                    item.ManagerMid = contract.ManagerMID;
                    item.ViatrisMID = contract.ViatrisMID;
                    item.ViatrisEmailID = contract.ViatrisEmailId;
                    item.RITM = contract.RITM;
                    item.ContractStatus = contract.ContractStatus;
                    item.CustomDomainName = contract.CustomDomainName;
                    //item.Status =( contract.Status=="Open" && contract.ContractStatus=="Open")?"Position Open":(contract.Status == "Open" && contract.ContractStatus == "Closed")?"Filled By Other":"Position Onboarded";

                    //item.IsActive = contract.IsActive == true ? "Active" : "InActive";
                    item.Status = contract.IsActive != true ? "Contract InActive" : (contract.Status == "Open" && contract.ContractStatus == "Open") ? "Position Open" : (contract.Status == "Open" && contract.ContractStatus == "Closed") ? "Filled By Other" : "Position Onboarded";

                    item.PositionLocationId = contract.PositionLocationID;
                    empdetails.Add(item);
                }
            }
            return empdetails;

         
        }

        

        public List<WorkFlowModel> GetTMResourceWorkFlow(int tmvcmid)
        {
            var empdetails = new List<WorkFlowModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetTMResourceWorkFlow(tmvcmid);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new WorkFlowModel();
                    item.CMID = contract.Tmcid;
                    //item.TMVCMID = contract.TMVCMID;
                    item.Role = contract.Role;
                    item.ActionByMid = contract.ActionByMid;
                    item.ActionByName = contract.ActionByName;
                    item.ActionDate = contract.ActionDate;
                    item.Action = contract.Action;
                    item.Remarks = contract.Remarks;
                    item.NextWfrole = contract.NextWfrole;
                    
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }
        
          public List<ResourceTrackModel> GetResourceMIDcreationPendingList(string UseName,int locationID)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceMIDcreationPendingList(UseName,locationID);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.TMCMID;
                    item.TMVCMID = contract.TMVCMID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.PositionCode = contract.PositionCode;
                    //item.BillingRateYear2 = contract.BillingRateYear2;
                    //item.BillingRateYear3 = contract.BillingRateYear3;
                    //item.BillingRateYear4 = contract.BillingRateYear4;
                    //item.BillingRateYear5 = contract.BillingRateYear5;
                    //item.NoticePeriod = contract.NoticePeriod;
                    //item.PositionLocation = contract.LocationName;
                    //item.SAPCode = contract.SAPCode;
                    //item.WBSDetail = contract.WBSDetail;
                    //item.OBS = contract.OBS;
                    item.VendorName = contract.VendorName;

                    //item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    //item.ValidationRemarks = contract.ValidationRemarks;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    //item.Vertical = contract.VerticalName;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    //item.ManagerName = contract.ManagerName;
                    //item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                     item.RITM = contract.RITM;
                    item.RMID = contract.RMID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.CustomDomainName = contract.CustomDomainName;
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }

       public string SaveResourceAssetDetails(string MID, string Email,int Rmid,int Cmid)
        {
            var data = "";
            var vaildation = SearchDataFromAd(MID);
            if (vaildation != null)
            {
                 data = _ResourceMappingRepository.SaveResourceAssetDetails(MID, Email, Rmid, Cmid, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName);
            }
            else
            {
                data = "Note : MID does't exist, you can still save the data.";
            }

            return data;
        }

        public string SearchDataFromAd(string MID)
        {
            var Email = "";
          
            if (!string.IsNullOrEmpty(MID))
            {
                DirectorySearcher ds = new DirectorySearcher
                {
                    Filter = "(&(objectClass=user)(objectcategory=person)(samAccountName=" + MID + "))"
                };

                SearchResult userProperty = ds.FindOne();
                if (userProperty != null)
                {
                    //managerDetails.Name = userProperty.Properties["displayname"][0].ToString();
                    //managerDetails.MID = mid;
                    Email = userProperty.Properties["mail"][0].ToString();
                }
            }

            return Email==""?null:Email;
        }

        public List<FpResourceMappingModel> GetResourceMappingMilestonePendingList(string UserName, int LocationId)
        {
            var empdetails = new List<FpResourceMappingModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceMappingMilestonePendingList(UserName, workfloworder, LocationId);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new FpResourceMappingModel();
                    item.CMID = contract.CMID;
                    item.FBCIntID = contract.FBCMilestoneMasterID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    item.RemappedMID = contract.RemappedMID;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    //item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.WBSDetail = contract.WBSDetail;
                    item.OBS = contract.OBSMasterName;
                    //item.VendorName = contract.VendorName;
                    item.Vertical = contract.VerticalName;

                    item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    item.ValidationRemarks = contract.ValidationRemarks;
                    item.VendorID = contract.VendorId;
                    item.VendorName = contract.VendorName;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    item.ManagerName = contract.ManagerName;
                    item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.FPINTID = contract.FPMSRMintID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.UpdatedBy = contract.UploadedBy;
                   
                    empdetails.Add(item);
                }
            }
            return empdetails;
        }

        public List<FpResourceMappingModel> SaveFPOnBoardingMilestoneResourceApprovalData(List<FpResourceMappingModel> result)
        {
            var tblList = new List<EmsTblResourceMaster>();
            var _objTMVendorContractMasters = new List<EmsTblFbvendorContractMilestoneMaster>();
            var _objTMVendorContractWFHistory = new List<EmsTblContractMaster>();
            var _objTmcontractWorkFlow = new List<EmsTblFpcontractWorkFlowMilestone>();
            var approvedlist = result.Where(x => x.isSelectedApproval == true).ToList();
            var rejectedlist = result.Where(x => x.isSelectedApproval == false).ToList();
            var vendorID = 0;
            if (approvedlist.Count > 0)
            {
                foreach (var contract in approvedlist)
                {
                    if (contract.RemappedMID == null || contract.RemappedMID == "")
                    {
                        vendorID = Convert.ToInt16(contract.VendorID);
                        // _ResourceMappingRepository.UpdateResourceMasterstatus(contract.ETWID, contract.PositionCode);
                        var item = new EmsTblResourceMaster();
                        item.VendorId = contract.VendorID;
                        item.FirstName = contract.FirstName;
                        item.LastName = contract.LastName;
                        item.Gender = contract.Gender;
                        item.Dob = contract.DOB;
                        item.Dojviatris = contract.DOJViatris;
                        item.MobileNo = contract.MobileNumber;
                        item.ManagerMid = contract.ManagerMid;
                        item.CostCenterNo = contract.CostCenter;
                        item.Ritm = null;
                        item.ViatrisMid = null;
                        item.ViatrisEmailId = null;
                        item.ResourceStatus = "Active";
                        item.UploadedBy = SessionManager.CurrentUser.MID;
                        item.UploadDate = DateTime.Now;
                        item.PositionCode = contract.ETWID;
                        tblList.Add(item);
                    }
                    _objTMVendorContractMasters.Add(new EmsTblFbvendorContractMilestoneMaster()
                    {
                        FbcmilestoneMasterId = Convert.ToInt32(contract.FBCIntID),
                        Cmid = Convert.ToInt32(contract.CMID),
                        Etwid = contract.ETWID,
                        Status= "Closed",
                        //  Added to make Pending with whom empty when the position is closed. Need to add PendingWithWhom in the model and assign approperiate value
                        PendingWithWhom = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : null,
                        //Status = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now ? "Approved" : "Closed",
                        RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "") ? contract.RemappedMID : null,
                        //RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date) ? null : (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date) ? contract.RemappedMID : null,
                        SowstartDate = contract.SOWStartDate,
                        Wforder = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : 3,
                        Sownumber=contract.SOWNumber,
                        DomainSkillEndDate=contract.DomainSkillEndDate
                    });
                    _objTMVendorContractWFHistory.Add(new EmsTblContractMaster()
                    {
                        Cmid = Convert.ToInt32(contract.CMID),
                        PositionCode = contract.ETWID,
                        Status = "Closed",
                        //Status = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date ? "Approved" : "Closed",
                    });
                    _objTmcontractWorkFlow.Add(new EmsTblFpcontractWorkFlowMilestone()
                    {
                        Cmid = Convert.ToInt32(contract.FBCIntID),
                        Role = "PMO-Admin ",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        Action = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date ? "Resource Mapped" : contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date ? "Scheduled For Resource Mapping" : contract.RemappedMID == null || contract.RemappedMID == "" ? "Forwarded For MID Creation" : null,
                        //Remarks = contract.remarks,
                        //Remarks = contract.RemappedMID != null && contract.RemappedMID != "" ? "(" + contract.RemappedMID + ") " + contract.remarks : contract.remarks,
                        Remarks = contract.RemappedMID != null && contract.RemappedMID != "" ? (contract.remarks != null && contract.remarks != "") ? contract.remarks + ", Remapped MID : " + contract.RemappedMID : " Remapped MID : " + contract.RemappedMID : contract.remarks,
                        NextWfrole = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : "PMO-Admin"
                    });
                }
                _ResourceMappingRepository.AddFPmilestoneDataToResourcemaster(tblList, _objTMVendorContractMasters, _objTMVendorContractWFHistory, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlow, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));
            }
            if (rejectedlist.Count > 0)
            {
                var _objTmcontractWorkFlowRejected = new List<EmsTblFpcontractWorkFlowMilestone>();
                foreach (var rejected in rejectedlist)
                {
                    _objTmcontractWorkFlowRejected.Add(new EmsTblFpcontractWorkFlowMilestone()
                    {
                        Cmid = Convert.ToInt32(rejected.FBCIntID),
                        Role = "PMO-Admin",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        Action = "Rejected",
                        Remarks =rejected.remarks,
                        NextWfrole = "PMO-Admin"
                    });
                }
                _ResourceMappingRepository.AddFPRejectedMlStnResrcWrkFloDts(SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlowRejected, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));

                MailMessageDetails objmails = new MailMessageDetails();
                MailMessageDetails objsendbackmails = new MailMessageDetails();
                var vendorGroup = result.DistinctBy(x => x.VendorName).ToList();
                foreach (var vendor in vendorGroup)
                {
                    //Fetch only Approved list
                    var rejectedrecords = result.Where(x => x.VendorName == vendor.VendorName && x.isSelectedApproval == false).ToList();
                    using (var workbook = new XLWorkbook())
                    {
                        IXLWorksheet worksheet = workbook.Worksheets.Add("OnboardingTemplate");
                        worksheet.Columns(1, 28).Style.Font.FontColor = XLColor.Black;
                        worksheet.Columns(1, 28).AdjustToContents();
                        // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                        worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                        worksheet.Cell(1, 1).Value = "ETWID";
                        worksheet.Cell(1, 2).Value = "VendorName";
                        worksheet.Cell(1, 3).Value = "SOWNumber";
                        worksheet.Cell(1, 4).Value = "SOWName";

                        worksheet.Cell(1, 5).Value = "SOWStartDate";
                        worksheet.Cell(1, 6).Value = "SOWEndDate";
                        worksheet.Cell(1, 7).Value = "PONumber";
                        worksheet.Cell(1, 8).Value = "POStartDate";
                        worksheet.Cell(1, 9).Value = "POEndDate";

                        worksheet.Cell(1, 10).Value = "DomainSkillName";
                        worksheet.Cell(1, 11).Value = "Skillset";
                        worksheet.Cell(1, 12).Value = "DomainSkillStartDate";
                        worksheet.Cell(1, 13).Value = "DomainSkillEndDate";


                        worksheet.Cell(1, 14).Value = "ContractType";

                        worksheet.Cell(1, 15).Value = "PPMProjectID";
                        worksheet.Cell(1, 16).Value = "ProjectName";
                        worksheet.Cell(1, 17).Value = "Tower";
                        worksheet.Cell(1, 18).Value = "BillingType";
                        worksheet.Cell(1, 19).Value = "RemappedMID";
                        worksheet.Cell(1, 20).Value = "FirstName";

                        worksheet.Cell(1, 21).Value = "LastName";
                        worksheet.Cell(1, 22).Value = "Gender";
                        worksheet.Cell(1, 23).Value = "DOB";
                        worksheet.Cell(1, 24).Value = "DOJViatris";
                        worksheet.Cell(1, 25).Value = "ManagerName";
                        worksheet.Cell(1, 26).Value = "ManagerEmail";
                        worksheet.Cell(1, 27).Value = "MobileNumber";
                        worksheet.Cell(1, 28).Value = "Remarks";

                        for (int index = 1; index <= rejectedrecords.Count; index++)
                        {
                            worksheet.Cell(index + 1, 1).Value = rejectedrecords[index - 1].ETWID;
                            worksheet.Cell(index + 1, 2).Value = rejectedrecords[index - 1].VendorName;
                            worksheet.Cell(index + 1, 3).Value = rejectedrecords[index - 1].SOWNumber;
                            worksheet.Cell(index + 1, 4).Value = rejectedrecords[index - 1].SOWName;

                            worksheet.Cell(index + 1, 5).Value = rejectedrecords[index - 1].SOWStartDate;
                            worksheet.Cell(index + 1, 5).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 6).Value = rejectedrecords[index - 1].SOWEndDate;
                            worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 7).Value = rejectedrecords[index - 1].PONumber;
                            worksheet.Cell(index + 1, 8).Value = rejectedrecords[index - 1].POStartDate;
                            worksheet.Cell(index + 1, 8).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 9).Value = rejectedrecords[index - 1].POEndDate;
                            worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";

                            worksheet.Cell(index + 1, 10).Value = rejectedrecords[index - 1].DomainSkillName;
                            worksheet.Cell(index + 1, 11).Value = rejectedrecords[index - 1].SkillSet;

                            worksheet.Cell(index + 1, 12).Value = rejectedrecords[index - 1].DomainSkillStartDate;
                            worksheet.Cell(index + 1, 12).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 13).Value = rejectedrecords[index - 1].DomainSkillEndDate;
                            worksheet.Cell(index + 1, 13).Style.DateFormat.Format = "dd-MMM-yyyy";

                            worksheet.Cell(index + 1, 14).Value = rejectedrecords[index - 1].ContractType;

                            worksheet.Cell(index + 1, 15).Value = rejectedrecords[index - 1].PPMProjectID;
                            worksheet.Cell(index + 1, 16).Value = rejectedrecords[index - 1].PPMProjectName;
                            worksheet.Cell(index + 1, 17).Value = rejectedrecords[index - 1].Tower;


                            worksheet.Cell(index + 1, 18).Value = rejectedrecords[index - 1].BillingType;
                            worksheet.Cell(index + 1, 19).Value = rejectedrecords[index - 1].RemappedMID;
                            worksheet.Cell(index + 1, 20).Value = rejectedrecords[index - 1].FirstName;
                            worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].LastName;
                            worksheet.Cell(index + 1, 22).Value = rejectedrecords[index - 1].Gender;
                            worksheet.Cell(index + 1, 23).Value = rejectedrecords[index - 1].DOB;
                            worksheet.Cell(index + 1, 24).Value = rejectedrecords[index - 1].DOJViatris;
                            worksheet.Cell(index + 1, 25).Value = rejectedrecords[index - 1].ManagerName;
                            worksheet.Cell(index + 1, 26).Value = rejectedrecords[index - 1].ManagerEmail;
                            worksheet.Cell(index + 1, 27).Value = rejectedrecords[index - 1].MobileNumber;
                            worksheet.Cell(index + 1, 28).Value = rejectedrecords[index - 1].remarks;


                        }
                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            objmails.Attachment = content;
                            objmails.To = vendor.VendorEmails ?? "";
                            objmails.Cc = "gidc.businessfinanceops@viatris.com";
                            objmails.From = "gidc.businessfinanceops@viatris.com";
                            objmails.Subject = "Resource Onboarding Data – Send Back for Correction";
                        }
                    }
                    _mailtemp.SendTMContractApproval(objmails, "ResourceManagerRejected");
                }
            }
                return null;
        }

        
       public List<FpResourceMappingModel> SaveOnBoardingMilestoneResourceMapping(List<FpResourceMappingModel> result)
        {
            var tblList = new List<EmsTblFpmileStoneResourceMappingIntermediate>();
            var MID = "";
            var VendorMaster = _MastersRepository.GetVendorMasterList();
            foreach (var contract in result)
            {
                var item = new EmsTblFpmileStoneResourceMappingIntermediate();
                item.Etwid = contract.ETWID;
                item.PositionStatus = "New";
                item.RemappedMid = contract.RemappedMID;
                item.VendorName = contract.VendorName;
                item.Sownumber = contract.SOWNumber;
                item.FirstName = contract.FirstName;
                item.LastName = contract.LastName;
                item.Gender = contract.Gender;
                item.Dojviatris = contract.DOJViatris;
                item.Dob = contract.DOB;
                item.MobileNo = contract.MobileNumber == null ? null : contract.MobileNumber.ToString();
                item.ManagerMid = contract.ManagerEmail == null || contract.ManagerEmail == "" ? null : GetUserInfo(contract.ManagerEmail.Trim());
                item.PositionLocationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

                item.ManagerName = contract.ManagerName;
                item.ManagerEmailId = contract.ManagerEmail;
                item.CostCenterNo = contract.CostCenter;
                item.VendorId = VendorMaster.Where(x => x.VendorName == contract.VendorName).Select(x => x.VendorId).FirstOrDefault();
                item.UploadedBy = SessionManager.CurrentUser.MID;
                item.UploadDate = DateTime.Now;
                tblList.Add(item);
            }
            _ResourceMappingRepository.AddFPContractMSResourceMappingIntr(tblList, SessionManager.CurrentUser.MID, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));
            return null;
        }

        public List<FpResourceMappingModel> GetResourceMappingMonthlyPendingList(string UserName, int LocationId)
        {
            var empdetails = new List<FpResourceMappingModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceMappingMonthlyPendingList(UserName, workfloworder, LocationId);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new FpResourceMappingModel();
                    item.CMID = contract.CMID;
                    item.AmortizationStartMonth = contract.AmortizationStartMonth;
                    item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    item.FBCIntID = contract.FBCMontlyID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    //item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainSkillName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.BillingType = contract.BillingTypeName;
                    item.VendorName = contract.VendorName;
                    item.OBS = contract.OBSMasterName;
                    item.RemappedMID = contract.RemappedMID;
                    //item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    item.ValidationRemarks = contract.ValidationRemarks;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    item.Vertical = contract.VerticalName;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    item.ManagerName = contract.ManagerName;
                    item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.FPINTID = contract.FPMlyRMintID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.UpdatedBy = contract.UploadedBy;
                    empdetails.Add(item);
                }
            }
            return empdetails;
        }

        public List<FpResourceMappingModel> SaveFPOnBoardingMonthlyResourceApprovalData(List<FpResourceMappingModel> result)
        {
            var tblList = new List<EmsTblResourceMaster>();
            var _objTMVendorContractMasters = new List<EmsTblFbvendorContractMonthlyMaster>();
            var _objTMVendorContractWFHistory = new List<EmsTblContractMaster>();
            var _objTmcontractWorkFlow = new List<EmsTblFpcontractWorkFlowMonthly>();
            var approvedlist = result.Where(x => x.isSelectedApproval == true).ToList();
            var rejectedlist = result.Where(x => x.isSelectedApproval == false).ToList();
            var vendorID = 0;
            if (approvedlist.Count > 0)
            {
                foreach (var contract in approvedlist)
                {
                    if (contract.RemappedMID == null || contract.RemappedMID == "")
                    {
                        vendorID = Convert.ToInt16(contract.VendorID);
                        // _ResourceMappingRepository.UpdateResourceMasterstatus(contract.ETWID, contract.PositionCode);
                        var item = new EmsTblResourceMaster();
                        item.VendorId = contract.VendorID;
                        item.FirstName = contract.FirstName;
                        item.LastName = contract.LastName;
                        item.Gender = contract.Gender;
                        item.Dob = contract.DOB;
                        item.Dojviatris = contract.DOJViatris;
                        item.MobileNo = contract.MobileNumber;
                        item.ManagerMid = contract.ManagerMid;
                        item.CostCenterNo = contract.CostCenter;
                        item.Ritm = null;
                        item.ViatrisMid = null;
                        item.ViatrisEmailId = null;
                        item.ResourceStatus = "Active";
                        item.UploadedBy = SessionManager.CurrentUser.MID;
                        item.UploadDate = DateTime.Now;
                        item.PositionCode = contract.ETWID;
                        tblList.Add(item);
                    }
                    _objTMVendorContractMasters.Add(new EmsTblFbvendorContractMonthlyMaster()
                    {
                        FbcmontlyId = Convert.ToInt32(contract.FBCIntID),
                        Cmid = Convert.ToInt32(contract.CMID),
                        Etwid = contract.ETWID,
                        Status = "Closed",
                        //  Added to make Pending with whom empty when the position is closed. Need to add PendingWithWhom in the model and assign approperiate value
                        PendingWithWhom = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : null,
                        //Status = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now ? "Approved" : "Closed",
                        RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "") ? contract.RemappedMID : null,
                        //RemappedMid = (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date) ? null : (contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date) ? contract.RemappedMID : null,
                        SowstartDate = contract.SOWStartDate,
                        Wforder = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : 3,
                        Sownumber=contract.SOWNumber,
                        DomainSkillEndDate=contract.DomainSkillEndDate
                    });
                    _objTMVendorContractWFHistory.Add(new EmsTblContractMaster()
                    {
                        Cmid = Convert.ToInt32(contract.CMID),
                        PositionCode = contract.ETWID,
                        Status = "Closed",
                        //Status = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date ? "Approved" : "Closed",
                    });
                    _objTmcontractWorkFlow.Add(new EmsTblFpcontractWorkFlowMonthly()
                    {
                        Cmid = Convert.ToInt32(contract.FBCIntID),
                        Role = "PMO-Admin ",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        Action = contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date <= DateTime.Now.Date ? "Resource Mapped" : contract.RemappedMID != null && contract.RemappedMID != "" && contract.SOWStartDate.Value.Date > DateTime.Now.Date ? "Scheduled For Resource Mapping" : contract.RemappedMID == null || contract.RemappedMID == "" ? "Forwarded For MID Creation" : null,
                        //Remarks = contract.remarks,
                        //Remarks = contract.RemappedMID != null && contract.RemappedMID != "" ? "(" + contract.RemappedMID + ") " + contract.remarks : contract.remarks,
                        Remarks = contract.RemappedMID != null && contract.RemappedMID != "" ? (contract.remarks != null && contract.remarks != "") ? contract.remarks + ", Remapped MID : " + contract.RemappedMID : " Remapped MID : "+ contract.RemappedMID : contract.remarks,
                        NextWfrole = (contract.RemappedMID != null && contract.RemappedMID != "") ? null : "PMO-Admin"

                    }) ;
                }
                _ResourceMappingRepository.AddFPmonthlyDataToResourcemaster(tblList, _objTMVendorContractMasters, _objTMVendorContractWFHistory, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlow, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));
            }
            if (rejectedlist.Count > 0)
            {
                var _objTmcontractWorkFlowRejected = new List<EmsTblFpcontractWorkFlowMonthly>();
                foreach (var rejected in rejectedlist)
                {
                    _objTmcontractWorkFlowRejected.Add(new EmsTblFpcontractWorkFlowMonthly()
                    {
                        Cmid = Convert.ToInt32(rejected.FBCIntID),
                        Role = "PMO-Admin",
                        ActionByMid = SessionManager.CurrentUser.MID,
                        ActionByName = SessionManager.CurrentUser.DisplayName,
                        ActionDate = DateTime.Now,
                        Action = "Rejected",
                        Remarks = rejected.remarks,
                        NextWfrole = "PMO-Admin"
                    });
                }
                _ResourceMappingRepository.AddFPRejectedMnthlyResrcWrkFloDts(SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName, _objTmcontractWorkFlowRejected, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));


                MailMessageDetails objmails = new MailMessageDetails();
                MailMessageDetails objsendbackmails = new MailMessageDetails();
                var vendorGroup = result.DistinctBy(x => x.VendorName).ToList();
                foreach (var vendor in vendorGroup)
                {
                    //Fetch only Approved list
                    var rejectedrecords = result.Where(x => x.VendorName == vendor.VendorName && x.isSelectedApproval == false).ToList();
                    using (var workbook = new XLWorkbook())
                    {
                        IXLWorksheet worksheet = workbook.Worksheets.Add("OnboardingTemplate");
                        worksheet.Columns(1, 28).Style.Font.FontColor = XLColor.Black;
                        worksheet.Columns(1, 28).AdjustToContents();
                        // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                        worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;

                        worksheet.Cell(1, 1).Value = "ETWID";
                        worksheet.Cell(1, 2).Value = "VendorName";
                        worksheet.Cell(1, 3).Value = "SOWNumber";
                        worksheet.Cell(1, 4).Value = "SOWName";

                        worksheet.Cell(1, 5).Value = "SOWStartDate";
                        worksheet.Cell(1, 6).Value = "SOWEndDate";
                        worksheet.Cell(1, 7).Value = "PONumber";
                        worksheet.Cell(1, 8).Value = "POStartDate";
                        worksheet.Cell(1, 9).Value = "POEndDate";

                        worksheet.Cell(1, 10).Value = "DomainSkillName";
                        worksheet.Cell(1, 11).Value = "Skillset";
                        worksheet.Cell(1, 12).Value = "DomainSkillStartDate";
                        worksheet.Cell(1, 13).Value = "DomainSkillEndDate";


                        worksheet.Cell(1, 14).Value = "ContractType";

                        worksheet.Cell(1, 15).Value = "PPMProjectID";
                        worksheet.Cell(1, 16).Value = "ProjectName";
                        worksheet.Cell(1, 17).Value = "Tower";
                        worksheet.Cell(1, 18).Value = "BillingType";
                        worksheet.Cell(1, 19).Value = "RemappedMID";
                        worksheet.Cell(1, 20).Value = "FirstName";

                        worksheet.Cell(1, 21).Value = "LastName";
                        worksheet.Cell(1, 22).Value = "Gender";
                        worksheet.Cell(1, 23).Value = "DOB";
                        worksheet.Cell(1, 24).Value = "DOJViatris";
                        worksheet.Cell(1, 25).Value = "ManagerName";
                        worksheet.Cell(1, 26).Value = "ManagerEmail";
                        worksheet.Cell(1, 27).Value = "MobileNumber";
                        worksheet.Cell(1, 28).Value = "Remarks";

                        for (int index = 1; index <= rejectedrecords.Count; index++)
                        {
                            worksheet.Cell(index + 1, 1).Value = rejectedrecords[index - 1].ETWID;
                            worksheet.Cell(index + 1, 2).Value = rejectedrecords[index - 1].VendorName;
                            worksheet.Cell(index + 1, 3).Value = rejectedrecords[index - 1].SOWNumber;
                            worksheet.Cell(index + 1, 4).Value = rejectedrecords[index - 1].SOWName;

                            worksheet.Cell(index + 1, 5).Value = rejectedrecords[index - 1].SOWStartDate;
                            worksheet.Cell(index + 1, 5).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 6).Value = rejectedrecords[index - 1].SOWEndDate;
                            worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 7).Value = rejectedrecords[index - 1].PONumber;
                            worksheet.Cell(index + 1, 8).Value = rejectedrecords[index - 1].POStartDate;
                            worksheet.Cell(index + 1, 8).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 9).Value = rejectedrecords[index - 1].POEndDate;
                            worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";

                            worksheet.Cell(index + 1, 10).Value = rejectedrecords[index - 1].DomainSkillName;
                            worksheet.Cell(index + 1, 11).Value = rejectedrecords[index - 1].SkillSet;

                            worksheet.Cell(index + 1, 12).Value = rejectedrecords[index - 1].DomainSkillStartDate;
                            worksheet.Cell(index + 1, 12).Style.DateFormat.Format = "dd-MMM-yyyy";
                            worksheet.Cell(index + 1, 13).Value = rejectedrecords[index - 1].DomainSkillEndDate;
                            worksheet.Cell(index + 1, 13).Style.DateFormat.Format = "dd-MMM-yyyy";

                            worksheet.Cell(index + 1, 14).Value = rejectedrecords[index - 1].ContractType;

                            worksheet.Cell(index + 1, 15).Value = rejectedrecords[index - 1].PPMProjectID;
                            worksheet.Cell(index + 1, 16).Value = rejectedrecords[index - 1].PPMProjectName;
                            worksheet.Cell(index + 1, 17).Value = rejectedrecords[index - 1].Tower;
                          
                           
                            worksheet.Cell(index + 1, 18).Value = rejectedrecords[index - 1].BillingType;
                            worksheet.Cell(index + 1, 19).Value = rejectedrecords[index - 1].RemappedMID;
                            worksheet.Cell(index + 1, 20).Value = rejectedrecords[index - 1].FirstName;
                            worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].LastName;
                            worksheet.Cell(index + 1, 22).Value = rejectedrecords[index - 1].Gender;
                            worksheet.Cell(index + 1, 23).Value = rejectedrecords[index - 1].DOB;
                            worksheet.Cell(index + 1, 24).Value = rejectedrecords[index - 1].DOJViatris;
                            worksheet.Cell(index + 1, 25).Value = rejectedrecords[index - 1].ManagerName;
                            worksheet.Cell(index + 1, 26).Value = rejectedrecords[index - 1].ManagerEmail;
                            worksheet.Cell(index + 1, 27).Value = rejectedrecords[index - 1].MobileNumber;
                            worksheet.Cell(index + 1, 28).Value = rejectedrecords[index - 1].remarks;


                        }
                        using (var stream = new MemoryStream())
                        {
                            workbook.SaveAs(stream);
                            var content = stream.ToArray();

                            objmails.Attachment = content;
                            objmails.To = vendor.VendorEmails ?? "";
                            objmails.Cc = "gidc.businessfinanceops@viatris.com";
                            objmails.From = "gidc.businessfinanceops@viatris.com";
                            objmails.Subject = "Resource Onboarding Data – Send Back for Correction";
                        }
                    }
                    _mailtemp.SendTMContractApproval(objmails, "ResourceManagerRejected");
                }

            }
            return null;
        }

        public List<FpResourceMappingModel> SaveOnBoardingMonthlyResourceMapping(List<FpResourceMappingModel> result)
        {
            var tblList = new List<EmsTblFpmonthlyResourceMappingIntermediate>();
            var MID = "";
            var VendorMaster = _MastersRepository.GetVendorMasterList();
            foreach (var contract in result)
            {
                var item = new EmsTblFpmonthlyResourceMappingIntermediate();
                item.Etwid = contract.ETWID;
                item.PositionStatus = "New";
                item.RemappedMid = contract.RemappedMID;
                item.VendorName = contract.VendorName;
                item.Sownumber = contract.SOWNumber;
                item.FirstName = contract.FirstName;
                item.LastName = contract.LastName;
                item.Gender = contract.Gender;
                item.Dojviatris = contract.DOJViatris;
                item.Dob = contract.DOB;
                item.MobileNo = contract.MobileNumber == null ? null : contract.MobileNumber.ToString();
                item.ManagerMid =contract.ManagerEmail==null|| contract.ManagerEmail==""?null: GetUserInfo(contract.ManagerEmail.Trim());
                item.PositionLocationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
                item.VendorId = VendorMaster.Where(x => x.VendorName == contract.VendorName).Select(x => x.VendorId).FirstOrDefault();
                item.ManagerName = contract.ManagerName;
                item.ManagerEmailId = contract.ManagerEmail;
                item.CostCenterNo = contract.CostCenter;
                //item.VendorId = contract.VendorID;
                item.UploadedBy = SessionManager.CurrentUser.MID;
                item.UploadDate = DateTime.Now;
                tblList.Add(item);
            }
            _ResourceMappingRepository.AddFPContractMLYResourceMappingIntr(tblList, SessionManager.CurrentUser.MID, Convert.ToInt32(SessionManager.CurrentUser.Location_ID));
            return null;
        }
        
         public List<WorkFlowModel> GetFPmonthlyResourceWorkFlow(int fbcIntID)
        {
            var empdetails = new List<WorkFlowModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetFPmonthlyResourceWorkFlow(fbcIntID);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new WorkFlowModel();
                    item.CMID = contract.Cmid;
                    //item.TMVCMID = contract.TMVCMID;
                    item.Role = contract.Role;
                    item.ActionByMid = contract.ActionByMid;
                    item.ActionByName = contract.ActionByName;
                    item.ActionDate = contract.ActionDate;
                    item.Action = contract.Action;
                    item.Remarks = contract.Remarks;
                    item.NextWfrole = contract.NextWfrole;

                    empdetails.Add(item);
                }
            }
            return empdetails;


        }

        public List<WorkFlowModel> GetFPmilestoneResourceWorkFlow(int fbcIntID)
        {
            var empdetails = new List<WorkFlowModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetFPmilestoneResourceWorkFlow(fbcIntID);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new WorkFlowModel();
                    item.CMID = contract.Cmid;
                    //item.TMVCMID = contract.TMVCMID;
                    item.Role = contract.Role;
                    item.ActionByMid = contract.ActionByMid;
                    item.ActionByName = contract.ActionByName;
                    item.ActionDate = contract.ActionDate;
                    item.Action = contract.Action;
                    item.Remarks = contract.Remarks;
                    item.NextWfrole = contract.NextWfrole;

                    empdetails.Add(item);
                }
            }
            return empdetails;


        }
        
        public List<MilestoneDetails> GetMilestoneDetailsBySowNum(string SowNumber)
        {
            var empdetails = new List<MilestoneDetails>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetMilestoneDetailsBySowNum(SowNumber);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {

                    var item = new MilestoneDetails();
                    item.Milestone = contract.Milestone;
                    item.MilestoneAmount = contract.MilestoneAmount;
                    item.MilestoneDescription = contract.MilstoneDescription;
                    item.Currency = contract.CurrencyCode;
                    item.SowNumber = contract.SowNumber;
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }
        
        public List<MonthlyDetails> GetMonthlyDetailsBySowNum(string SowNumber)
        {
            var empdetails = new List<MonthlyDetails>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetMonthlyDetailsBySowNum(SowNumber);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new MonthlyDetails();
                    item.SowNumber = contract.SOWNumber;
                    item.AmortizationStartDate = contract.AmortizationStartDate;
                    item.AmortizationEndDate = contract.AmortizationEndDate;
                    item.Currency = contract.CurrencyCode;
                    item.Duration = contract.DurationOfMonth;
                    item.UpdatedBy = contract.UpdatedBy;
                    item.UpdateDate = contract.UpdateDate;
                    item.Amount = contract.MilestoneAmount;
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }

        public List<ResourceTrackModel> GetMonthlyMIDcreationPendingList(string UseName, int locationID)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetMonthlyMIDcreationPendingList(UseName, workfloworder, locationID);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.CMID;
                    item.RMID = contract.RMID;
                    item.FBCIntID = contract.FBCMontlyID;
                    //item.AmortizationStartMonth = contract.AmortizationStartMonth;
                    //item.AmortizationEndMonth = contract.AmortizationEndMonth;
                    //item.FBCIntID = contract.FBCMontlyID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    //item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.VendorName = contract.VendorName;

                    //item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    //item.ValidationRemarks = contract.ValidationRemarks;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    //item.Vertical = contract.VerticalName;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    //item.ManagerName = contract.ManagerName;
                    //item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.RITM = contract.RITM;
                    item.PositionLocationId = contract.PositionLocationID;
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }

        public List<ResourceTrackModel> GetMilestoneMIDcreationPendingList(string UseName, int locationID)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetMilestoneMIDcreationPendingList(UseName, workfloworder, locationID);
            if (result != null)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.CMID;
                    item.RMID = contract.RMID;
                    item.FBCIntID = contract.FBCMilestoneMasterID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    //item.BillingRateYear1 = contract.BillingRateYear1;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.VendorName = contract.VendorName;

                    //item.OldSowNumber = contract.OldSOWNumber;
                    item.CostCenter = contract.CostCenter;
                    //item.ValidationRemarks = contract.ValidationRemarks;
                    //item.DomainLeadEmail = contract.DomainLeadEmail;
                    //item.Currency = contract.Currency;
                    //item.Vertical = contract.VerticalName;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.DOJViatris = contract.DOJViatris;
                    //item.ManagerName = contract.ManagerName;
                    //item.ManagerEmail = contract.ManagerEmailId;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.RITM = contract.RITM;
                    item.PositionLocationId = contract.PositionLocationID;
                    empdetails.Add(item);
                }
            }
            return empdetails;


        }

        public string SaveMilestoneResourceAssetDetails(string MID, string Email, int Rmid, int Cmid)
        {
            var data = "";
            var vaildation = SearchDataFromAd(MID);
            if (vaildation != null)
            {
                data = _ResourceMappingRepository.SaveMilestoneResourceAssetDetails(MID, Email, Rmid, Cmid, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName);
            }
            else
            {
                data = "Note : MID does't exist, you can still save the data.";
            }

            return data;
        }

        public string SaveMonthlyResourceAssetDetails(string MID, string Email, int Rmid, int Cmid)
        {
            var data = "";
            var vaildation = SearchDataFromAd(MID);
            if (vaildation != null)
            {
                data = _ResourceMappingRepository.SaveMonthlyResourceAssetDetails(MID, Email, Rmid, Cmid, SessionManager.CurrentUser.MID, SessionManager.CurrentUser.DisplayName);
            }
            else
            {
                data = "Note : MID does't exist, you can still save the data.";
            }

            return data;
        }
        public bool sendFPOpenPositionsToVendor(List<FpResourceMappingModel> result)
        {
            MailMessageDetails objmails = new MailMessageDetails();
            MailMessageDetails objsendbackmails = new MailMessageDetails();
            var vendorGroup = result.DistinctBy(x => x.VendorName).ToList();
            foreach (var vendor in vendorGroup)
            {
                //Fetch only Approved list
                var rejectedrecords = result.Where(x => x.VendorName == vendor.VendorName && x.FirstName == null && x.LastName == null).ToList();

                using (var workbook = new XLWorkbook())
                {
                    IXLWorksheet worksheet = workbook.Worksheets.Add("Onboarding Resource Data");
                    worksheet.Columns(1, 29).Style.Font.FontColor = XLColor.Black;
                    worksheet.Columns(1, 29).AdjustToContents();
                    // worksheet.Columns(1, 27).Style.Border.OutsideBorder=XLBorderStyleValues.Medium;
                    worksheet.Row(1).Style.Fill.BackgroundColor = XLColor.BlueBell;
                    worksheet.Cell(1, 1).Value = "ETWID";
                    worksheet.Cell(1, 2).Value = "VendorName";
                    worksheet.Cell(1, 3).Value = "SOWNumber";
                    worksheet.Cell(1, 4).Value = "SOWName";

                    worksheet.Cell(1, 5).Value = "SOWStartDate";
                    worksheet.Cell(1, 6).Value = "SOWEndDate";
                    worksheet.Cell(1, 7).Value = "PONumber";
                    worksheet.Cell(1, 8).Value = "POStartDate";
                    worksheet.Cell(1, 9).Value = "POEndDate";
                    worksheet.Cell(1, 10).Value = "DomainSkillName";
                    worksheet.Cell(1, 11).Value = "Skillset";

                    worksheet.Cell(1, 12).Value = "DomainSkillStartDate";
                    worksheet.Cell(1, 13).Value = "DomainSkillEndDate";
                    worksheet.Cell(1, 14).Value = "ContractType";

                    worksheet.Cell(1, 15).Value = "PPMProjectID";
                    worksheet.Cell(1, 16).Value = "ProjectName";
                    worksheet.Cell(1, 17).Value = "Tower";
                   
                    worksheet.Cell(1, 18).Value = "BillingType";
                    worksheet.Cell(1, 19).Value = "RemappedMID";
                    worksheet.Cell(1, 20).Value = "FirstName";

                    worksheet.Cell(1, 21).Value = "LastName";
                    worksheet.Cell(1, 22).Value = "Gender";
                    worksheet.Cell(1, 23).Value = "DOB";
                    worksheet.Cell(1, 24).Value = "DOJViatris";
                    worksheet.Cell(1, 25).Value = "ManagerName";

                    worksheet.Cell(1, 26).Value = "ManagerEmail";
                    worksheet.Cell(1, 27).Value = "MobileNumber";

                    for (int index = 1; index <= rejectedrecords.Count; index++)
                    {
                        worksheet.Cell(index + 1, 1).Value = rejectedrecords[index - 1].ETWID;
                        worksheet.Cell(index + 1, 2).Value = rejectedrecords[index - 1].VendorName;
                        worksheet.Cell(index + 1, 3).Value = rejectedrecords[index - 1].SOWNumber;
                        worksheet.Cell(index + 1, 4).Value = rejectedrecords[index - 1].SOWName;

                        worksheet.Cell(index + 1, 5).Value = rejectedrecords[index - 1].SOWStartDate;
                        worksheet.Cell(index + 1, 5).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 6).Value = rejectedrecords[index - 1].SOWEndDate;
                        worksheet.Cell(index + 1, 6).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 7).Value = rejectedrecords[index - 1].PONumber;
                        worksheet.Cell(index + 1, 8).Value = rejectedrecords[index - 1].POStartDate;
                        worksheet.Cell(index + 1, 8).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 9).Value = rejectedrecords[index - 1].POEndDate;
                        worksheet.Cell(index + 1, 9).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 10).Value = rejectedrecords[index - 1].DomainSkillName;
                        worksheet.Cell(index + 1, 11).Value = rejectedrecords[index - 1].SkillSet;

                        worksheet.Cell(index + 1, 12).Value = rejectedrecords[index - 1].DomainSkillStartDate;
                        worksheet.Cell(index + 1, 12).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 13).Value = rejectedrecords[index - 1].DomainSkillEndDate;
                        worksheet.Cell(index + 1, 13).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 14).Value = rejectedrecords[index - 1].ContractType;

                        worksheet.Cell(index + 1, 15).Value = rejectedrecords[index - 1].PPMProjectID;
                        worksheet.Cell(index + 1, 16).Value = rejectedrecords[index - 1].PPMProjectName;
                        worksheet.Cell(index + 1, 17).Value = rejectedrecords[index - 1].Tower;
                       
                        worksheet.Cell(index + 1, 18).Value = rejectedrecords[index - 1].BillingType;
                        worksheet.Cell(index + 1, 19).Value = rejectedrecords[index - 1].RemappedMID;


                        worksheet.Cell(index + 1, 20).Value = rejectedrecords[index - 1].FirstName;
                        worksheet.Cell(index + 1, 21).Value = rejectedrecords[index - 1].LastName;
                        worksheet.Cell(index + 1, 22).Value = rejectedrecords[index - 1].Gender;
                        worksheet.Cell(index + 1, 23).Value = rejectedrecords[index - 1].DOB;
                        worksheet.Cell(index + 1, 23).Style.DateFormat.Format = "dd-MMM-yyyy";
                        worksheet.Cell(index + 1, 24).Value = rejectedrecords[index - 1].DOJViatris;
                        worksheet.Cell(index + 1, 24).Style.DateFormat.Format = "dd-MMM-yyyy";

                        worksheet.Cell(index + 1, 25).Value = rejectedrecords[index - 1].ManagerName;
                        worksheet.Cell(index + 1, 26).Value = rejectedrecords[index - 1].ManagerEmail;
                        worksheet.Cell(index + 1, 27).Value = rejectedrecords[index - 1].MobileNumber;


                    }
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        var content = stream.ToArray();

                        objmails.Attachment = content;
                        objmails.To = vendor.VendorEmails ?? "";
                        objmails.Cc = "gidc.businessfinanceops@viatris.com";
                        objmails.From = "gidc.businessfinanceops@viatris.com";
                        objmails.Subject = "Require Onboarding Resource Data";
                    }
                }
                _mailtemp.SendTMContractApproval(objmails, "SendDataToVendor");

            }
            return true;
        }


         public List<ResourceTrackModel> GetResourceFPmonthlyTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceFPmonthlyTrackDts(UseName, workflowOrder, locationID, Filter, ActiveFilter, FromDate, Todate);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.CMID;
                    item.FBCIntID = contract.FBCMontlyID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.OldSowNumber = contract.OldSOWNumber;
                    item.RemappedMID = contract.RemappedMID;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.ContractType = contract.ContractTypeName;
                    item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.DomainName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
                    item.WbsDetail = contract.WBSDetail;
                    item.VendorName = contract.VendorName;
                    item.CostCenter = contract.CostCenter;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.OBS = contract.OBSMasterName;
                    item.Vertical = contract.VerticalName;
                    item.Tower = contract.TowerName;
                    item.DOJViatris = contract.DOJViatris;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.PositionLocation = contract.LocationName;
                    item.RITM = contract.RITM;
                    item.amortizationStartMonth = contract.AmortizationStartMonth;
                    item.amortizationEndMonth = contract.AmortizationEndMonth;
                    item.RemappedMID = contract.RemappedMID;
                    item.ViatrisMID = contract.ViatrisMID;
                    item.ViatrisEmailID = contract.ViatrisEmailId;
                    item.ContractStatus = contract.ContractStatus;
                    item.BillingType = contract.BillingTypeName;
                    item.ContractType = contract.ContractTypeName;
                    item.PendingWithWhom = contract.PendingWithWhom;
                    item.UploadedBY = contract.UploadedBy;
                    item.uploadedDate = contract.UpdateDate;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.Vertical = contract.VendorName;
                    item.IsActive = contract.IsActive == true ? "Active" : "InActive";
                    item.Status = contract.IsActive != true ? "Contract InActive" : (contract.Status == "Open" && contract.ContractStatus == "Open") ? "Position Open" : (contract.Status == "Open" && contract.ContractStatus == "Closed") ? "Filled By Other" : "Position Onboarded";


                    empdetails.Add(item);
                }
            }
            return empdetails;

        }

        
          public List<ResourceTrackModel> GetResourceFPmilestoneTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate)
        {
            var empdetails = new List<ResourceTrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetResourceFPmilestoneTrackDts(UseName, workflowOrder, locationID, Filter, ActiveFilter, FromDate, Todate);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new ResourceTrackModel();
                    item.CMID = contract.CMID;
                    item.FBCIntID = contract.FBCMilestoneMasterID;
                    item.ETWID = contract.ETWID;
                    item.SOWNumber = contract.SOWNumber;
                    item.OldSowNumber = contract.OldSOWNumber;
                    item.RemappedMID = contract.RemappedMID;
                    item.SOWName = contract.SOWName;
                    item.SOWStartDate = contract.SOWStartDate;
                    item.SOWEndDate = contract.SOWEndDate;
                    item.PONumber = contract.PONumber;
                    item.POStartDate = contract.POStartDate;
                    item.POEndDate = contract.POEndDate;
                    //item.SOWType = contract.SowTypeName;
                    item.PPMProjectID = contract.PPMProjectID;
                    item.PPMProjectName = contract.PPMProjectName;
                    item.ContractType = contract.ContractTypeName;
                    //item.Tower = contract.TowerName;
                    item.SkillSet = contract.SkillSet;
                    item.DomainLeadEmail = contract.DomainLeadEmail;
                    item.DomainName = contract.DomainSkillName;
                    item.DomainSkillStartDate = contract.DomainSkillStartDate;
                    item.DomainSkillEndDate = contract.DomainSkillEndDate;
              
                    item.WbsDetail = contract.WBSDetail;
                    item.VendorName = contract.VendorName;
                    item.CostCenter = contract.CostCenter;
                    item.VendorID = contract.VendorId;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.Gender = contract.Gender;
                    item.DOB = contract.DOB;
                    item.OBS = contract.OBSMasterName;
                    item.Vertical = contract.VerticalName;
                    item.Tower = contract.TowerName;
                    item.DOJViatris = contract.DOJViatris;
                    item.MobileNumber = contract.MobileNo;
                    item.VendorEmails = contract.EmailIDs;
                    item.ManagerMid = contract.ManagerMID;
                    item.PositionLocationId = contract.PositionLocationID;
                    item.PositionLocation = contract.LocationName;
                    item.RITM = contract.RITM;
                    item.RemappedMID = contract.RemappedMID;
                    item.ViatrisMID = contract.ViatrisMID;
                    item.ViatrisEmailID = contract.ViatrisEmailId;
                    item.ContractStatus = contract.ContractStatus;
                    item.BillingType = contract.BillingTypeName;
                    item.ContractType = contract.ContractTypeName;
                    item.PendingWithWhom = contract.PendingWithWhom;
                    item.UploadedBY = contract.UploadedBy;
                    item.uploadedDate = contract.UpdateDate;
                    item.ProjectOrRun = contract.ProjectOrRun;
                    item.IsActive = contract.IsActive==true? "Active" : "InActive";
                    item.Status = contract.IsActive!=true?"Contract InActive":(contract.Status == "Open" && contract.ContractStatus == "Open") ? "Position Open" : (contract.Status == "Open" && contract.ContractStatus == "Closed") ? "Filled By Other" : "Position Onboarded";

                    empdetails.Add(item);
                }
            }
            return empdetails;


        }
        
         public List<PositiontrackModel> GetMultipleResourceByPositionCode(string PositionCode)
        {
            var empdetails = new List<PositiontrackModel>();
            var workfloworder = Constants.ProcurementWFOrder.ResourceManager;
            var result = _ResourceMappingRepository.GetMultipleResourceByPositionCode(PositionCode);
            if (result.Count > 0)
            {
                foreach (var contract in result)
                {
                    var item = new PositiontrackModel();
                    item.PositionCode = contract.PositionCode;
                    item.FirstName = contract.FirstName;
                    item.LastName = contract.LastName;
                    item.ViatrisMID = contract.ViatrisMID;
                    item.IsMappingActive = contract.IsMappingActive;
                    item.MappedDate = contract.MappedDate;
                    item.MappedBy = contract.MappedBy;
                    item.status = contract.ResourceStatus;
                    item.VendorName=contract.VendorName;
                    item.ViatrisMID = contract.ViatrisMID;
                    item.RITM = contract.RITM;
                    item.ViatrisEmailId = contract.ViatrisEmailId;

                    empdetails.Add(item);
                }
            }
            return empdetails;


        }
        
         public bool DeleteIntrResourceTMdataById(int TmIntrId)
        {
            var data = _ResourceMappingRepository.DeleteIntrResourceTMdataById(TmIntrId);

            return data;
        }
        
             public bool DeleteIntrResourceFPmyldataById(int fpintid)
        {
            var data = _ResourceMappingRepository.DeleteIntrResourceFPmyldataById(fpintid);

            return data;
        }
        public bool DeleteIntrResourceFPmlsdataById(int fpintid)
        {
            var data = _ResourceMappingRepository.DeleteIntrResourceFPmlsdataById(fpintid);

            return data;
        }
    }
}


