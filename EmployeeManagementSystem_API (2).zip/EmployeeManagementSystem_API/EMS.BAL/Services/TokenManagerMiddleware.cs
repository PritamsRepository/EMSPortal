﻿using System.Net;
using EMS_BAL.Interface;
using Microsoft.AspNetCore.Http;

namespace EMS_BAL.Services
{
    public class TokenManagerMiddleware : IMiddleware
    {
        private readonly ITokenManager _tokenManager;
        public TokenManagerMiddleware(ITokenManager tokenManager)
        {
            _tokenManager = tokenManager;
        }
        public async Task InvokeAsync (HttpContext context, RequestDelegate next)
        {
            if( await _tokenManager.IsCurrentActiveToken())
            {
                await next(context);
                return;
            }
            context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
        }
    }
}
