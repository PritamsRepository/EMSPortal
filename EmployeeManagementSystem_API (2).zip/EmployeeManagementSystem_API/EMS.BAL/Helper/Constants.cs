﻿

namespace EMS_BAL.Helper
{
    public static class Constants
    {
        public static readonly string DOMAIN = "MYL";
        public static readonly string AD_PATH = "LDAP://myl.com";
        //public static readonly string SECRET_KEY = "1203199320052021";
        public static readonly string SECRET_KEY = "MTIwMzE5OTMyMDA1MjAyMQ==";
        //public static readonly string SECRET_KEY_IV = "1203199320052021";
        public static readonly string SECRET_KEY_IV = "MTIwMzE5OTMyMDA1MjAyMQ==";
        public static class ClaimType
        {
            public static readonly string ClaimTypeRole = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            public static readonly string ClaimTypeSub = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
            public static readonly string ClaimTypeJti = "jti";
            public static readonly string ClaimTypeIss = "iss";
            public static readonly string ClaimTypeAud = "jti";

        }
        public static class AESKey
        {
            // public static readonly string SECRET_KEY = "1203199320052021";
            public static readonly string SECRET_KEY = "MTIwMzE5OTMyMDA1MjAyMQ==";
            // public static readonly string SECRET_KEY_IV = "1203199320052021";
            public static readonly string SECRET_KEY_IV = "MTIwMzE5OTMyMDA1MjAyMQ==";
        }

        public class JWT
        {
            public static readonly string ValidAudience = "http://w0bsnowappq001:8010/";
            public static readonly string ValidIssuer = "http://w0bsnowappq001:8010/";
            public static readonly string Secret = "EMSApp_APICore@2023_#";
            public static readonly string secretKey = "F7peYX7825YkwztCxgjzZGF4yExvu4TK4mN8DLUtsVHMpnGa3V5jabYjFhGf";
            public static readonly string expiryMinutes = "45";
            public static readonly string issuer = "http://w0bsnowappq001:8010/";
            public static readonly string audience = "http://w0bsnowappq001:8010/";
            public static readonly bool validateLifetime = true;
        }

        public class ProcurementWFOrder
        {
            public static readonly int ProcurementLead = 0;
            public static readonly int FinanceManager = 1;
            public static readonly int ResourceManager = 2;
            public static readonly int LocalIT = 3;
            public static readonly int Admin = 4;
        }
        public class ProcurementWFRoles
        {
            public static readonly string ProcurementLead = "PMO-Contract-Mgm";
            public static readonly string FinanceManager = "IT Finance Manager";
            public static readonly string ResourceManager = "PMO-Admin";
            public static readonly string LocalIT = "Local IT";
            public static readonly string Admin = "Admin";
            public static readonly string ReportAccess = "Report Access";
            public static readonly string SuperAdmin = "Super Admin";

        }
        public class ReportType
        {
            public static readonly string DetailReport = "DetailReport";
            public static readonly string SummaryReport = "SummaryReport";
        }
    }
}