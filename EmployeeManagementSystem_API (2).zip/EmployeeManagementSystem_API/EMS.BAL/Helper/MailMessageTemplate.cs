﻿using Azure;
using Azure.Core;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Math;
using DocumentFormat.OpenXml.Wordprocessing;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.Extensions.Configuration;
using NetTopologySuite.GeometriesGraph;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using System.Diagnostics.Contracts;
using System.Threading.Channels;

namespace EMS.BAL.Helper
{
    public class MailMessageTemplate
    {
        private readonly IConfiguration _configuration;
        public MailMessageTemplate(IConfiguration _configuration)
        {
            this._configuration = _configuration;
        }

        public void SendTMContractApproval( MailMessageDetails mailMessageDetails, string status)
        {
            
             StringBuilder mailBody = new StringBuilder();

             MailMessageDetails objmails = new MailMessageDetails();



            string baseUrl = "";

            int wfOrder = 1;
            if (status == "SendDataToVendor")
            {
                mailBody.Append("Dear Team,<br><br>");
                mailBody.Append("There are approved contracts, Please provide resource detail who needs to be boarded against these contract.<br> " +
                    " Required details are:-\r\n\r\nFirstName   LastName    Gender  DOB DOJViatris  ManagerName ManagerEmail  MobileNumber <br><br><b>If there is a renewal/extension of an existing contract and the working resource in expiring contract needs to continue, Please provide his MID in the “RemappedMID” Column to continue that resource in the renew/extension contract without recreation of his credentials.</b>" +
                    "<br><br><b><i><font color='red'>Note: -Please do no change any other contract details in the excel.</font></i></b><br>");
                mailBody.Append("<br>Regards,<br> Business Finance Operation Team – GIDC Viatris");

            }
            else if (status == "ResourceManagerRejected")
            {
                mailBody.Append("Dear Team,<br><br>");
                mailBody.Append("Please find attached file having the resource details given by you for the open positions. We found some issue in data and you can read the issue in the “Reason for Sendback” column.<br> <br> Please do the correction as per reason for send back and resubmit the resource data as early as possible.<br> " +
                    " Required details are:-\r\n\r\nFirstName   LastName    Gender  DOB DOJViatris  ManagerName ManagerEmail  MobileNumber <br><br><b>If there is a renewal/extension of an existing contract and the working resource in expiring contract needs to continue, Please provide his MID in the “RemappedMID” Column to continue that resource in the renew/extension contract without recreation of his credentials.</b>" +
                    "<br><br><b><i><font color='red'>Note: -Please do no change any other contract details in the excel.</font></i></b><br>");
                mailBody.Append("<br>Regards,<br> Business Finance Operation Team – GIDC Viatris");

            }
            else if(status == "send run report to vendors")
            {
                mailBody.Append("Hi Team,<br><br>");
                mailBody.Append("Here is the Other Requirements - Open Positions as on <b> "+DateTime.Now+ "</b> for your references. If any changes please let me know. <br> ");
                mailBody.Append("<br>Regards,<br> Business Finance Operation Team – GIDC Viatris");
            }
         
            
            else if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
            {
                if (status == "Approve")
                {

                    mailBody.Append("Dear Team,<br><br>There are approved contracts, Please provide resource detail who needs to be boarded against these contract.<br><br>Required details are:- <br><br>FirstName, LastName, Gender, DOB, DOJViatris, ManagerName, ManagerEmail, MobileNumber<br><br><b>If there is a renewal/extension of an existing contract and the working resource in expiring contract needs to continue, Please provide his MID in the “Remapped MID” Column to continue that resource in the renew/extension contract without recreation of his credentials.</b><br><br><p style=\"color:Tomato;\">Note:- Please do no change any other contract details in the excel.</p><br><br>Regards,<br>Business Finance Operation Team – GIDC Viatris<br>");
                }
                else if (status == "ApproveToPMO")
                {
                    mailBody.Append("Dear Team,<br><br>");
                    mailBody.Append("Few Contracts are approved, Please take care of resource mapping.<br><br> ");
                    mailBody.Append(mailMessageDetails.applicationLink);
                    mailBody.Append("<br><br>Regards,<br> IT Finance Manager");

                }
                else
                {

                    mailBody.Append("Dear PMO Contract Mgt Team,<br><br>");
                    mailBody.Append("Few Contracts are sent back by IT Finance Manager for rework. <br> ");
                    mailBody.Append("Please do the correction as per remarks and resubmit.<br><br>");
                    mailBody.Append(mailMessageDetails.applicationLink);
                    mailBody.Append("<br><br> Regards,");


                }
            }


            


            objmails.Body = mailBody.ToString();
            objmails.To = mailMessageDetails.To;
            objmails.Cc = mailMessageDetails.Cc;
            if (objmails.Cc == "," || objmails.Cc == null)
                objmails.Cc = "";
            objmails.Cc = mailMessageDetails.Cc;
            objmails.From = mailMessageDetails.From;
            objmails.Attachment = mailMessageDetails.Attachment;
            objmails.Subject = mailMessageDetails.Subject;
            new EmailManager(_configuration).SendEmail(objmails);

        }
    

        public void GenerateAndSendMail(MailMessageDetails mailMessageDetails)
        {
            MailMessageDetails objmails = new MailMessageDetails();

            StringBuilder mailBody = new StringBuilder();

            if(mailMessageDetails.Subject == "Time & Material Contracts For Approval." || mailMessageDetails.Subject == "Fixed price contracts for approval") 
            {
                var applicaton_link = _configuration.GetValue<string>("AppSettings:ApplicationLink");
                mailBody.Append("Dear IT Finance Team, <br><br>");

                mailBody.Append("Contracts have been uploaded, Please take the required actions. <br/><br/> Regards,<br/>Contract Management Team");
                mailBody.Append("<br/><br/> Click on the link <a style='color:blue' href='"+ applicaton_link + "'>E M S</a> for logging to ETW Employee Management System. <br /><br />");

                objmails.Subject = mailMessageDetails.Subject;
            }
             
            objmails.Body = mailBody.ToString();
           
            objmails.To = mailMessageDetails.To;
           
            objmails.Cc = mailMessageDetails.Cc;
            if (objmails.Cc == ",")
                objmails.Cc = "";
            objmails.Cc = mailMessageDetails.Cc;
            
            objmails.From = mailMessageDetails.From;

            new EmailManager(_configuration).SendEmail(objmails);

        }
        public void SendFPMContractApproval(MailMessageDetails mailMessageDetails, string status)
        {
            StringBuilder mailBody = new StringBuilder();
            MailMessageDetails objmails = new MailMessageDetails();

            string baseUrl = "";
            int wfOrder = 1;


            if (wfOrder == Constants.ProcurementWFOrder.FinanceManager)
            {
                if (status == "Approve")
                {

                    mailBody.Append("Dear Team,<br><br>There are approved contracts, Please provide resource detail who needs to be boarded against these contract.<br><br>Required details are:- <br><br>FirstName, LastName, Gender, DOB, DOJViatris, ManagerName, ManagerEmail, MobileNumber<br><br><b>If there is a renewal/extension of an existing contract and the working resource in expiring contract needs to continue, Please provide his MID in the “Remapped MID” Column to continue that resource in the renew/extension contract without recreation of his credentials.</b><br><br><p style=\"color:Tomato;\">Note:- Please do no change any other contract details in the excel.</p><br><br>Regards,<br>Business Finance Operation Team – GIDC Viatris<br>");
                }
                else
                {

                    mailBody.Append("Dear PMO Contract Mgt Team,<br><br>");
                    mailBody.Append("Few Contracts are sent back by IT Finance Manager for rework. <br> ");
                    mailBody.Append("Please do the correction as per remarks and resubmit.<br><br>");
                    mailBody.Append(mailMessageDetails.applicationLink);
                    mailBody.Append("<br><br> Regards,");


                }
            }

            objmails.Subject = mailMessageDetails.Subject;

            objmails.Body = mailBody.ToString();
            objmails.To = mailMessageDetails.To;
            objmails.Cc = mailMessageDetails.Cc;
            if (objmails.Cc == ",")
                objmails.Cc = "";
            objmails.Cc = mailMessageDetails.Cc;
            objmails.From = mailMessageDetails.From;
            objmails.Attachment = mailMessageDetails.Attachment;
            objmails.Subject=mailMessageDetails.Subject;

            new EmailManager(_configuration).SendEmail(objmails);


        }
    }
}
