﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Helper
{
    public static class SessionManager
    {
        public static class CurrentUser
        {
            public static string MID { get; set; }
            public static string DisplayName { get; set; }
            public static string EmailID { get; set; }
            public static int? Location_ID { get; set; }
            public static int? Role_ID { get; set; }
            public static bool IsManager { get; set; } = false;
            public static bool IsAdmin { get; set; } = false;
            public static bool IsVendor { get; set; } = false;
            public static bool IsProcurementLead { get; set; } = false;
            public static bool IsFinanceManager { get; set; } = false;
            public static bool IsResourceManager { get; set; } = false;
            public static bool IsLocalIT { get; set; } = false;
            public static bool IsEmployee { get; set; } = false;
        }
    }
}
