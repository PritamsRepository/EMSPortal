﻿using EMS.BAL.Model;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Spreadsheet;

namespace EMS.BAL.Helper
{
    public class EmailManager
    {
        private readonly IConfiguration _configuration;
        public EmailManager(IConfiguration _configuration)
        {
            this._configuration = _configuration;
        }
        public void SendEmail(MailMessageDetails emailMessageDetails)
        {
            MailMessage messageObject = new MailMessage();
            MailAddress Address;
            MailAddressCollection TO_addressList = new MailAddressCollection();
            MailAddressCollection CC_addressList = new MailAddressCollection();

           var mailMode= _configuration.GetValue<string>("MailSettings:mailmode");

          

            messageObject.Subject = emailMessageDetails.Subject;
            messageObject.Body = emailMessageDetails.Body;
            messageObject.IsBodyHtml = true;
            //messageObject.From = new MailAddress(emailMessageDetails.From);
            messageObject.From = new MailAddress(emailMessageDetails.From);
            if (emailMessageDetails.Cc != null  && emailMessageDetails.Cc!="")
                messageObject.CC.Add(emailMessageDetails.Cc.Replace(",,", ","));
            if (!string.IsNullOrEmpty(emailMessageDetails.To))
            {
                //messageObject.CC.Add(emailMessageDetails.Cc);
                foreach (var curr_address in emailMessageDetails.To.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    Address = new MailAddress(curr_address);
                    TO_addressList.Add(Address);
                }
                messageObject.To.Add(TO_addressList.ToString());
              
                SmtpClient client = new SmtpClient();
                if (mailMode == "Local")
                {

                    client.Host = _configuration.GetValue<string>("MailSettings:localExchange") ?? "";
                    client.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
                    client.PickupDirectoryLocation = _configuration.GetValue<string>("MailSettings:PickupDirectoryLocation");
                }
                else
                {
                    //ConfigurationManager.AppSettings.
                    client.Host = _configuration.GetValue<string>("MailSettings:serverExchange")??"";
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                }

                client.Port = 25;
                client.UseDefaultCredentials = true;
                client.EnableSsl = false;

                if (emailMessageDetails.Attachment != null)
                {
                    // string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                  //  string contentType = " application / vnd.ms - excel";
                    string filename = "Onboarding Resource Data.xlsx";

                    MemoryStream m = new MemoryStream(emailMessageDetails.Attachment);
                    messageObject.Attachments.Add(new System.Net.Mail.Attachment(m, filename));

                    //Attachment attachment = new Attachment(emailMessageDetails.Attachment, filename, contentType);
                    //messageObject.Attachments.Add(attachment);
                    client.Send(messageObject);
                    m.Dispose();
                }
                else
                {
                    client.Send(messageObject);
                }
            }
        }
    }
}
