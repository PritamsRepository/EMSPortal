﻿using DocumentFormat.OpenXml.Wordprocessing;
using EMS.BAL.Model;
using EMS_DAL.Entities;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public interface ITMContract
    {
        public bool UploadTMContractData(List<EmsTblTmvendorContractIntermediateMaster> contracts,string mid,string location);
        public List<TMContract> GetTMContractIntermediateList(string mid);
        //public List<TMContract> GetTMContractList();
        bool SaveTMIntDataToMain(List<int> tmIntID, string mid, string name,bool isProcLead, int locId);       
        public bool DeleteTMIntData(List<int> tmIntID);
        bool DeleteTMSBData(int tmIntID,string mid,string name, string remarks);
        public List<TMContract> GetTMContractPendingList (int WFOrder, int Location);
        public string PostTMContractList (List<TMContract> contracts);

        public List<TmContractMain> GetTMContractMainList(string RecordType, int locId);

        public List<TMContract> GetTMContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter);
        //string UpdateTmContractDetails(EmsTblTmvendorContractMaster tmDetails, string mid, string name, bool isProcLead, int locId);
        string UpdateTmContractDetails(TMContractMaster tmDetails, string mid, string name, bool isProcLead, int locId);
        List<TmContractMain> GetTMSendbackDetails(string mid, string RecordType, int locId);
        List<EmsTblTmcontractWorkFlow> GetWorkFlowsOfContract(int tmcid);

        string UpdateApprovedTmContractDetails(TMContractMaster tmDetails, string mid, int locId);

        public List<SP_EMS_FetchSowNumberByContractTypeResult> GetSowListByContractType(string contractType, string searchSowNumber);

        public List<SP_EMS_FetchContractListBySOW_NoResult> GetAllSowListByContractType(string contractType, string sowNumber);
        public List<SP_EMS_FetchColumnValueByTblAndSowNumberResult> GetContractValueByContractSowType(string contractType, string sowNumber, string fieldType);

        public List<SP_EMS_ValidateColumnBySowNumberResult> GetColumnValidationStatusBySowNumber(string contractType, string sowNumber, string fieldType, string newValue);
        public int UpdateContractColumnBySowNumber(string contractType, string sowNumber, string fieldType, string oldValue, string newValue, string mid);

    }
}
