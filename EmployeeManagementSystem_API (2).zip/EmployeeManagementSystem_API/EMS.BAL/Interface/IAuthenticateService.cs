﻿using EMS.BAL.Model;
using EMS_BAL.Model;
using EMS_DAL.Entities;

namespace EMS_BAL.Interface
{
    public interface IAuthenticateServices
    {
        string GenerateToken(string userName);
        void SignUp (string username, string password);
        LocationWithRoles GetLocationAndRolesByMid(string mid);
        JsonWebToken SignIn (string username, string password);
        JsonWebToken SignInViaWinAuth(string username);
        JsonWebToken RefreshAccessToken (string token);
        void RevokeRefreshToken (string token);
        UserRolePreference GetUserRolePrefernce (string mid);
        UserRolePreference UserPreference(UserRolePreference pref);
       
    }
}