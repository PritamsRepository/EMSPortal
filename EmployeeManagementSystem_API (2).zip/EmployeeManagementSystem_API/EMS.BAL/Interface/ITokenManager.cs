﻿namespace EMS_BAL.Interface
{
    public interface ITokenManager
    {
        Task<bool> IsCurrentActiveToken ();
        Task DeactivateCurrentAsync ();
        Task<bool> IsActiveAsync (string token);
        Task DeactivateAsync (string token);
    }
}
