﻿using EMS.BAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public interface IErrorLog
    {
         bool logError (ErrorLog error);
    }
}
