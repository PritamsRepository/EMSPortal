﻿
using EMS_BAL.Model;

namespace EMS_BAL.Interface
{
    public interface IRole
    {
        bool addRole(Role role);
        List<Role> getRoles();
        Role getRole(int id);
        bool deleteRole(int id);
    }
}
