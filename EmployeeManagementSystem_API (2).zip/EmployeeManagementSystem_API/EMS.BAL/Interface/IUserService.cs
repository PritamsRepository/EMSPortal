﻿using EMS_BAL.Model;

namespace EMS_BAL.Interface
{
    public interface IUserService
    {
        UserProfile GetUserInfo (string userName, string password);
        UserProfile GetUserInfoForWindowAuth(string userName);
        List<Tuple<string, string>> GetUserListByKey (string key);
        string GetUserNameByKey (string key);

    }
}
