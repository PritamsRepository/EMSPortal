﻿using EMS.BAL.Model;
using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public  interface IReportService
    {
        Task<List<sp_EMS_ContractSummaryReportResult>> GetContractSummaryReport (string reportType, int prId);
        List<sp_EMS_ReportOpenPositionResult> GetOpenPositionReport (string reportType);
        Task<List<sp_EMS_ContractDetailReportResult>> GetContractDetailReport(string reportType, int prId);
         List<PublishedContractReport> SaveContractPublishedData(List<PublishedContractReport> result);
         List<EmsTblPublishedContractReport> GetpublishedContractDetails(string TowerHead, string PrjOrRun);
         List<PublishedContractReport> SaveContractPublishedDataWithMail(List<PublishedContractReport> result);
         List<string> getTowerHeadMasterData();
         List<sp_EMS_ContractSummaryWithTowerHeadAndDomainReportResult> GetContractReportByToweHeadAndDomain(string TowerHead, string PrjOrRun);
         Task<List<SP_EMS_GetAllVendorContractsByDateResult>> GetAllVendorContractsByDate(string contractType);
    }
}
