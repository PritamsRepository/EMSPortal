﻿namespace EMS_BAL.Interface
{
    public interface IDropdown
    {
         string ID { get; set; }
        string Name { get; set; }
    }
}
