﻿using EMS.BAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public interface IResourceOnboardingService
    {

        List<ResourceOnboardingModel> SaveOnBoardingResourceMappingPendingList(List<ResourceOnboardingModel> result);
        List<ResourceOnboardingModel> GetTMOnboardingApprovalPendingList(string UserName);
        string GetUserInfo(string EmailID);
        List<ResourceOnboardingModel> GetResourceMappingPendingList(string UserName, int LocationId);
        List<ResourceOnboardingModel> SaveTMOnBoardingResourceApprovalData(List<ResourceOnboardingModel> result);
        bool sendOpenPositionsToVendor(List<ResourceOnboardingModel> result);
        List<ResourceTrackModel> GetResourceMappingTrackDetails(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);
 
        List<WorkFlowModel> GetTMResourceWorkFlow(int tmvcmid);
        List<ResourceTrackModel> GetResourceMIDcreationPendingList(string UseName, int locationID);
         //bool SaveResourceAssetDetails(string MID, string Email, int Rmid, int Cmid);
        List<FpResourceMappingModel> GetResourceMappingMilestonePendingList(string UserName, int LocationId);
        List<FpResourceMappingModel> SaveFPOnBoardingMilestoneResourceApprovalData(List<FpResourceMappingModel> result);
    
        List<FpResourceMappingModel> SaveOnBoardingMilestoneResourceMapping(List<FpResourceMappingModel> result);
        List<FpResourceMappingModel> GetResourceMappingMonthlyPendingList(string UserName, int LocationId);
        List<FpResourceMappingModel> SaveFPOnBoardingMonthlyResourceApprovalData(List<FpResourceMappingModel> result);

        List<FpResourceMappingModel> SaveOnBoardingMonthlyResourceMapping(List<FpResourceMappingModel> result);
         List<WorkFlowModel> GetFPmonthlyResourceWorkFlow(int fbcIntID);
        List<WorkFlowModel> GetFPmilestoneResourceWorkFlow(int fbcIntID);
         bool sendFPOpenPositionsToVendor(List<FpResourceMappingModel> result);

         List<ResourceTrackModel> GetMonthlyMIDcreationPendingList(string UseName, int locationID);
         //List<FpResourceMappingModel> GetResourceFPmonthlyTrackDts(string UseName, int workflowOrder, int locationID, string Filter, DateTime FromDate, DateTime Todate);
         //List<FpResourceMappingModel> GetResourceFPmilestoneTrackDts(string UseName, int workflowOrder, int locationID, string Filter, DateTime FromDate, DateTime Todate);
         List<PositiontrackModel> GetMultipleResourceByPositionCode(string PositionCode);
         bool DeleteIntrResourceTMdataById(int TmIntrId);
         bool DeleteIntrResourceFPmyldataById(int fpintid);
         bool DeleteIntrResourceFPmlsdataById(int fpintid);
         string SearchDataFromAd(string MID);
         string SaveResourceAssetDetails(string MID, string Email, int Rmid, int Cmid);
         string SaveMonthlyResourceAssetDetails(string MID, string Email, int Rmid, int Cmid);
         string SaveMilestoneResourceAssetDetails(string MID, string Email, int Rmid, int Cmid);
        List<ResourceTrackModel> GetMilestoneMIDcreationPendingList(string UseName, int locationID);
         List<MonthlyDetails> GetMonthlyDetailsBySowNum(string SowNumber);
         List<MilestoneDetails> GetMilestoneDetailsBySowNum(string SowNumber);
        List<ResourceTrackModel> GetResourceFPmilestoneTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);
         List<ResourceTrackModel> GetResourceFPmonthlyTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);


    }
}
