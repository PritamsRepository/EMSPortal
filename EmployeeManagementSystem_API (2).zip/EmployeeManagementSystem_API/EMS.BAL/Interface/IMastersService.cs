﻿using EMS.BAL.Model;
using EMS_BAL.Model;
using EMS_DAL.Entities;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public interface IMastersService
    {
        List<DropdownKeyValue> GetRoleTypeData ();
        List<DropdownKeyValue> GetLocationData ();
        UserProfile GetEmployeeSearchDetails (string UserName);
        bool DeactivateRoleMappingDetailsByID(int roleTypeID);
         List<DropdownKeyValue> GetLocationDataByMID(string Username);
        string GetLocationName(int locID);
        bool PrimaryRoleMappingDetailsByID(int roleTypeID);
        List<RoleTypeMaster> GetEmpRoleMappingData(string UserName, int LocationId);
        void SaveEmployeeMappingDetails(string RoleType, string MID, string Name, string EmailID, List<string> SelectedLocation, bool IsPrimary, bool isactive);

        MasterDetailCollections GetAllEMSMasterDetails();
        List<ResourceModel> GetResourceByMID(string MID);
        List<DropdownKeyValue> GetProjectorRunMaster ();


    }
}