﻿
using EMS_BAL.Model;

namespace EMS_BAL.Interface
{
    public interface IJwtHandler
    {
        JsonWebToken Create (string username, List<Role> roles);
    }
}
