﻿using EMS.BAL.Model;
using EMS_DAL.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Interface
{
    public interface IFPContract
    {
        string UpdateFpContractDetails(EmsVwFpvendorContractMasterWithId fpDetails, string mid, string name, bool isProcLead, int locId);
        List<FPContractMain> GetFPSendbackDetails(string mid);
        List<EmsVwFpvendorContractWorkFlow> GetWorkFlowsOfFPContract(int fbcIntID, string Btype, string Ctype);
        //List<FPContractMain> GetFPContractMainList(string mid);
        Task<string> CallAPI(string requestedItemName, string requestedItemDescription);

        //bool UploadFPContractDate(List<FPContract> contracts);
        Task UploadFPContractDate(List<FPContract> contracts, string MID, string locationid);
        //public List<FPContract> GetFPContractIntermediateList();
        //List<FPContract> GetFPContractIntermediateList();
        Task<List<FPContract>> GetFPContractIntermediateList();
        Task<List<FPContractMl>> GetFPContractMlIntermediateList();
        bool saveSelectedFpMlRows(List<int> selectedRows);
        Task<bool> deleteFbMoFromIntAllOrByID(string id);
        //bool deleteFbAllOrByID(string ID);
        bool deleteFbAllOrByID(string ID);
        bool deleteFbFromIntByIDs(List<int> ids);
        Task<bool> deleteFbmlFromIntAllOrByID(string id);
        //bool saveSelectedFpRows(List<FPContract> selectedRows);
        bool saveSelectedFpContract(FPContract selectedContract);
        //bool saveSeltedFpRowsPerTbl(List<FPContract> selectedRows);
        //bool saveSeltedFpRowsPerTbl(List<int> ids);
        bool saveSeltedFpRowsPerTbl(List<int> ids, string mid, string name, int locId);
        bool UploadFPMlContractDate(List<FPContractMl> contracts, string MID);
        bool saveSelectedFpMlContract(FPContractMl selectedContract);
        bool saveSeltedFpMoRowsPerTbl(List<int> ids);
        bool saveSelectedFpMoRows(List<FPContractMo> selectedRows);
        List<FPContractMo> GetFPMOContractIntermediateList();
        bool UploadFPMOContractDate(List<FPContractMo> contracts, string MID);
        bool saveSeltedFpMlRowsPerTbl(List<int> ids);
        bool deleteFbmlFromIntByIDs(List<int> ids);
        bool deleteFbMoFromIntByIDs(List<int> ids);
        bool DeleteFBSendbackData(int tmIntID, string mid, string name, string remarks, string Btype);
        string PostFPMContractList(List<FPContract> contracts);
        List<FPContract> GetFPMContractPendingList(int WFOrder, int Location);
        List<FPContractMl> GetFPMContractDetail(string sowNumber);

        List<FPContract> GetFPMONContractPendingList(int WFOrder, int Location);
        List<FPContractMo> GetFPMONContractDetail(string sowNumber);
        string PostFPMONContractList(List<FPContract> contracts);
        List<FPContract> GetFPContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter);
        List<FPContract> GetFPContractMonthlyTrackList(int WFOrder, int Location, string filter,string ActiveFilter);
        List<FPContractMain> GetFPContractMainList(string filter, DateTime fromdate, DateTime todate,string ActiveFilter);
    }
}
