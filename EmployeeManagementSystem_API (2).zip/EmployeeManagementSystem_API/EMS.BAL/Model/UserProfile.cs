﻿namespace EMS_BAL.Model
{
    public class UserProfile
    {
        public string? MID { get; set; }
        public string? Email { get; set; }
        public string? FName { get; set; }
        public string? LName { get; set; }
        public string? DisplayName { get; set; }
        public int[]? Roles { get; set; }
        public string? LastLogin { get; set; }
        public decimal UnsuccessfulLogin { get; set; }
        public string? Location { get; set; }
        public int? UserId { get; set; }
    }
}
