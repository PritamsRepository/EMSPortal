﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class FPContractMo
    { 
        public int FBMonthlyIntID { get; set; }
        public string SOWNumber { get; set; }
        public DateTime? AmortizationStartDate { get; set; }
        public DateTime? AmortizationEndDate { get; set; }
        public decimal MilestoneAmount { get; set; }
        public int DurationOfMonth { get; set; }
        public string Currency { get; set; }
        public string? ValidationRemarks { get; set; }

    }
}
