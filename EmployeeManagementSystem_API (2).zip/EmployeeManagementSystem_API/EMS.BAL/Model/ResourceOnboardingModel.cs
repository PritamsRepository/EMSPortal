﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ResourceOnboardingModel
    {
        public decimal? BillingRateYear1 { get; set; }
        public string BillingType { get; set; }
        public string? ContractType { get; set; }
        public string? CostCenter { get; set; }
        public DateTime? DOJViatris { get; set; }
        public string? DomainName { get; set; }
        public string? ETWID { get; set; }
        public string? VendorName { get; set; }
        public int? VendorID { get; set; }
        public string? SOWNumber { get; set; }
        public string? SOWName { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public string? PONumber { get; set; }
        public DateTime? POStartDate { get; set; }
        public DateTime? POEndDate { get; set; }
        public string? PPMProjectID { get; set; }
        public string? PPMProjectName { get; set; }
        public string? Tower { get; set; }

        public string? SkillSet { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string? ProjectOrRun { get; set; }



        public string? PositionCode { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Gender { get; set; }

        public string? ManagerName { get; set; }
        public string? ManagerEmail { get; set; }
        public string? ManagerMid { get; set; }
        public string? MobileNumber { get; set; }
        public string? ValidationRemarks { get; set; }
        public string? Remarks { get; set; }
        public DateTime? DOB { get; set; }
        public bool? IsSelectedApproval { get; set; }
        public string? VendorEmails { get; set; }
        public int? PositionLocationId { get; set; }
        public int? TMCMID { get; set; }
        public int? TMVCMID { get; set; }
        public int? TMRMID { get; set; }
        public string? RemappedMID { get; set; }
        public string? UploadedBy { get; set; }
        public string? CustomDomainName { get; set; }

    }

}
