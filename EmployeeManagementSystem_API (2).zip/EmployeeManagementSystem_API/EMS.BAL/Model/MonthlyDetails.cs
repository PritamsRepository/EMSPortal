﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class MonthlyDetails
    {
        public string? SowNumber { get; set; }
        public DateTime? AmortizationStartDate { get; set; }
        public DateTime? AmortizationEndDate { get; set; }
        public decimal? Amount { get; set; }
        public int? Duration { get; set; }
        public string? Currency { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string? UpdatedBy { get; set; }
    }
}
