﻿using DocumentFormat.OpenXml.Wordprocessing;
using NetTopologySuite.GeometriesGraph;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EMS.BAL.Model
{
    public class PublishedContractReport
    {
        public string? DomainName { get; set; }
        public string? TowerHead{ get; set; }
        public int? TotalRequiredPositions{ get; set; }
        public int? L1Position{ get; set; }
        public int? L1OnBoarder{ get; set; }
        public int? L1Openposition{ get; set; }
        public string? L1PositionOpenDate{ get; set; }
        public string? L1AgingDays{ get; set; }
        public int? L1Selected{ get; set; }
        public int? L1BackUp{ get; set; }
        public string? L1ResourceDOJ{ get; set; }
        public int? L2Position{ get; set; }
        public int? L2OnBoarder{ get; set; }
        public int? L2Openposition{ get; set; }
        public string? L2PositionOpenDate{ get; set; }
        public string? L2AgingDays{ get; set; }
        public int? L2Selected{ get; set; }
        public int? L2BackUp{ get; set; }
        public string? L2ResourceDOJ{ get; set; }
        public int? L3Position{ get; set; }
        public int? L3OnBoarder{ get; set; }
        public int? L3Openposition{ get; set; }
        public string? L3PositionOpenDate{ get; set; }
        public string? L3AgingDays{ get; set; }
        public int? L3Selected{ get; set; }
        public int? L3BackUp{ get; set; }
        public string? L3ResourceDOJ{ get; set; }
        public int? OverallOnboarded{ get; set; }
        public int? OverallOpenPostion{ get; set; }
        public int? Overallselected{ get; set; }
        public int? Unfullfilled{ get; set; }
        public string? projOrRun { get; set; }
        public string? PublishedBy { get; set; }
        public DateTime? PublishedOn { get; set; }
        public string ? CustomDomainName { get; set; }

    }
}
