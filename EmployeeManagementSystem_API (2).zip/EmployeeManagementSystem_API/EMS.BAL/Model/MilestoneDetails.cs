﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class MilestoneDetails
    {
        public string? Etwid { get; set; }
        public string? Milestone { get; set; }
        public string? SowNumber { get; set; }
        public string? MilestoneDescription { get; set; }
        public decimal? MilestoneAmount { get; set; }
        public string? Currency { get; set; }
    }
      
}
