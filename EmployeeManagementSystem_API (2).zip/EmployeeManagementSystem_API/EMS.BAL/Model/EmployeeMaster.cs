﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class EmployeeMaster
    {
        public int Rmid { get; set; }
        public int? Cmid { get; set; }
        public string ViatrisMid { get; set; }
        public string EmpName { get; set; }
        public string ManagerMid { get; set; }
        public string ViatrisEmailId { get; set; }
        public string VendorName { get; set; }
        public string Dojviatris { get; set; }
        public string MobileNo { get; set; }
        public string Dob { get; set; }
        public string PositionCode { get; set; }
        public string ResourceStatus { get; set; }
        public int? Tmcmid { get; set; }
        public string SkillSet { get; set; }
        public string LocationName { get; set; }
        public string ContractTypeName { get; set; }
        public string SowTypeName { get; set; }
        public string Sowname { get; set; }
        public string Sownumber { get; set; }
        public string SowstartDate { get; set; }
        public string SowendDate { get; set; }
        public string Ponumber { get; set; }
        public string PostartDate { get; set; }
        public string PoendDate { get; set; }
        public string BillingTypeName { get; set; }
        public string VerticalName { get; set; }
        public string ProjectOrRun { get; set; }
        public string DomainName { get; set; }
        public string DomainLeadEmail { get; set; }
        public string DomainSkillStartDate { get; set; }
        public string DomainSkillEndDate { get; set; }
        public string Sapcode { get; set; }
        public string CostCenter { get; set; }
        public string PpmprojectId { get; set; }
        public string PpmprojectName { get; set; }
        public string TowerName { get; set; }



        public string Etwid { get; set; }

        public string CustomDomainName { get; set; }

        public string ManagerName { get; set; }

        public string ManagerEmail { get; set; }

        public string ContractStatus { get; set; }

        public DateTime? AmortizationStartMonth { get; set; }

        public DateTime? AmortizationEndMonth { get; set; }

        public string Wbsdetail { get; set; }

        public string Obs { get; set; }

        public DateTime? Lwd { get; set; }

        public int? NoticePeriod { get; set; }

        public string OldSownumber { get; set; }

        public string Currency { get; set; }

        public decimal? BillingRateYear1 { get; set; }

        public decimal? BillingRateYear2 { get; set; }

        public decimal? BillingRateYear3 { get; set; }

        public decimal? BillingRateYear4 { get; set; }

        public decimal? BillingRateYear5 { get; set; }

        public string Milestones { get; set; }

        public string MilestoneDescription { get; set; }

        public decimal? MilestonesAmount { get; set; }

        public decimal? MonthlyContractAmount { get; set; }

        public int? DurationOfMonths { get; set; }



    }
}
