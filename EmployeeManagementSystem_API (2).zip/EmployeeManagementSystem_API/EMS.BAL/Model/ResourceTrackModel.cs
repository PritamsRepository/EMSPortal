﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ResourceTrackModel
    {
        public decimal? BillingRateYear1 { get; set; }
        public string BillingType { get; set; }
        public string? ContractType { get; set; }
        public string? CostCenter { get; set; }
        public DateTime? DOJViatris { get; set; }
        public string? DomainName { get; set; }
        public string? ETWID { get; set; }
        public string? VendorName { get; set; }
        public int? VendorID { get; set; }
        public string? SOWNumber { get; set; }
        public string? SOWName { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public string PONumber { get; set; }
        public DateTime? POStartDate { get; set; }
        public DateTime? POEndDate { get; set; }
        public string? PPMProjectID { get; set; }
        public string? PPMProjectName { get; set; }
        public string? Tower { get; set; }

        public string? SkillSet { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string? ProjectOrRun { get; set; }



        public string? PositionCode { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Gender { get; set; }

        public string? ManagerName { get; set; }
        public string? ManagerEmail { get; set; }
        public string? MobileNumber { get; set; }
        public string? ValidationRemarks { get; set; }
        public string? Remarks { get; set; }
        public DateTime? DOB { get; set; }
        public bool? IsSelectedApproval { get; set; }
        public string? VendorEmails { get; set; }
        public int? PositionLocationId { get; set; }
        public int? CMID { get; set; }
        public int? TMVCMID { get; set; }
        public string? RITM { get; set; }
        public int? RMID { get; set; }
        public string? RemappedMID { get; set; }
        public string? ManagerMid { get; set; }

        public string? ViatrisMID { get; set; }
        public string? ViatrisEmailID { get; set; }
        public int? FBCIntID { get; set; }
        public string? Status { get; set; }
        public string? ContractStatus { get; set; }
        public decimal? BillingRateYear2 { get; set; }
        public decimal? BillingRateYear3 { get; set; }
        public decimal? BillingRateYear4 { get; set; }
        public decimal? BillingRateYear5 { get; set; }
        public int? NoticePeriod { get; set; }
        public string? PositionLocation { get; set; }
        public string? SapCode { get; set; }
        public string? WbsDetail { get; set; }
        public string? OBS { get; set; }
        public string? Currency { get; set; }
        public string? Vertical { get; set; }
        public string? PendingWithWhom { get; set; }
        public string? UploadedBY { get; set; }
        public DateTime? uploadedDate { get; set; }
        public string? OldSowNumber { get; set; }
        public string? IsActive { get; set;}

        public string ? DomainLeadEmail { get; set; }
        public string? SowType { get; set; }
        public DateTime? amortizationStartMonth { get; set; }
        public DateTime? amortizationEndMonth { get; set; }
        public string CustomDomainName { get; set; }
    }
}
