﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class FPContractMain
    {
        public int FBCID { get; set; }
        public int? CMID { get; set; }
        public string ETWID { get; set; }
        public string VendorName { get; set; }
        public string LocationName { get; set; }
        public string OldSowNumber { get; set; }
        public string SOWNumber { get; set; }
        public string SOWName { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public DateTime? AmortizationStartMonth { get; set; }
        public DateTime? AmortizationEndMonth { get; set; }
        public string PONumber { get; set; }
        public DateTime? POStartDate { get; set; }
        public DateTime? POEndDate { get; set; }
        public string PPMProjectID { get; set; }
        public string PPMProjectName { get; set; }
        public string VerticalName { get; set; }
        public string TowerName { get; set; }
        public string DomainLeadEmail { get; set; }
        public string CostCenter { get; set; }
        public string OBSMasterName { get; set; }
        public string DomainSkillName { get; set; }
        public string SkillSet { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string WBSDetail { get; set; }
        public string ProjectOrRun { get; set; }
        public string BillingTypeName { get; set; }
        public string RemappedMID { get; set; }
        public int? WFOrder { get; set; }
        public string ContractTypeName { get; set; }
        public string Status { get; set; }
        public string PendingWithWhom { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool? IsActive { get; set; }
        public string SendBackReason { get; set; }
        
    }
}
