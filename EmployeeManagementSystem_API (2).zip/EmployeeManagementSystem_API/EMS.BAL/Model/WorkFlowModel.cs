﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class WorkFlowModel
    {
        public int? CMID { get; set; }
        public string? Role { get; set; }
        public string? ActionByMid { get; set; }
        public string? ActionByName { get; set; }
        public DateTime? ActionDate { get; set; }
        public string? Action { get; set; }
        public string? Remarks { get; set; }
        public string? NextWfrole { get; set; }
    }
}
