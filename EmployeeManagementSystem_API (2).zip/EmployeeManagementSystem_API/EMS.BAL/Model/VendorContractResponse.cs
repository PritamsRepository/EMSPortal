﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class VendorContractResponse
    {
        public string ETWID { get; set; }
        public string SOWNumber { get; set; }
        public string SOWName { get; set; }
        public string SOWStartDate { get; set; }
        public string SOWEndDate { get; set; }
        public string PONumber { get; set; }
        public string POStartDate { get; set; }
        public string POEndDate { get; set; }
        public string ProjectOrRunID { get; set; }
        public string PPMProjectID { get; set; }
        public string PPMProjectName { get; set; }
        public string WBSDetail { get; set; }
        public string DomainLeadEmail { get; set; }
        public string DomainName { get; set; }
        public string DomainSkillStartDate { get; set; }
        public string DomainSkillEndDate { get; set; }
        public int? NoticePeriod { get; set; }
        public string PositionCode { get; set; }
        public string OldSOWNumber { get; set; }
        public string RemappedMID { get; set; }
        public string SAPCode { get; set; }
        public string CostCenter { get; set; }
        public string OBS { get; set; }
        public string Status { get; set; }
        public string BillingTypeName { get; set; }
        public string ContractTypeName { get; set; }
        public string VendorName { get; set; }
        public string SowTypeName { get; set; }
        public string VerticalName { get; set; }
        public string TowerName { get; set; }
        public string CustomDomainName {  get; set; }
        public string SkillSet { get; set; }
        public string ContractTypeIdentifier { get; set; }
    }

}
