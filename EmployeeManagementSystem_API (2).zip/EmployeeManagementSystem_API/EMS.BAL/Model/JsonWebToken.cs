﻿namespace EMS_BAL.Model
{
    public class JsonWebToken
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public long Expires { get; set; }
        public UserProfile UserProfile { get; set; }
    }
}