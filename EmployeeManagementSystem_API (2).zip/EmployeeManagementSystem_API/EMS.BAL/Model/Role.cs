﻿namespace EMS_BAL.Model
{
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleCode { get; set; }
        public bool IsActive { get; set; }
        public bool IsAdmin { get; set; }

    }
}
