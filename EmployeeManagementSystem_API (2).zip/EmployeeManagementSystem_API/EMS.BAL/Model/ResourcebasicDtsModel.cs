﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ResourcebasicDtsModel
    {
        public string? Mid  { get; set; }
        public string? Email { get; set; }
        public int? Rmid { get; set; }
        public int? Cmid { get; set; }
    }
}
