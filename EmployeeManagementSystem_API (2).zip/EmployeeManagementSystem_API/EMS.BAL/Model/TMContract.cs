﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class TMContract
    {
        public int TMCID { get; set; }
        public int? TMCMID { get; set; }
        public int? TMVCMID { get; set; }
        public string ETWID { get; set; }
        public string VendorName { get; set; }
        public int VendorID { get; set; }
        public string SOWNumber { get; set; }
        public string SOWName { get; set; }
        public string SOWType { get; set; }
        public string? RemappedMID { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public string PONumber { get; set; }
        public DateTime? POStartDate { get; set; }
        public DateTime? POEndDate { get; set; }
        public string PPMProjectID { get; set; }
        public string  PPMProjectName { get; set; }
        public string Tower { get; set; }
        public string? DomainSkillName { get; set; }
        public string Vertical { get; set; }
        public string WBSDetail { get; set; }
        public string DomainLeadEmail { get; set; }
        public string CostCenter { get; set; }
        public string? DomainName { get; set; }
        public string SkillSet { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string ProjectOrRun { get; set; }
        public string ContractType { get; set; }
        public string BillingType { get; set; }
        public decimal? BillingRateYear1 { get; set; }
        public decimal? BillingRateYear2 { get; set; }
        public decimal? BillingRateYear3 { get; set; }
        public decimal? BillingRateYear4 { get; set; }
        public decimal? BillingRateYear5 { get; set; }
        public string PositionCode { get; set; }
        public string? OldSowNumber { get; set; }
        public string SAPCode { get; set; }
        public string OBS { get; set; }
        public int? NoticePeriod { get; set; }
        public string UploadedBy { get; set; }
        public string PositionLocation { get; set; }

        public string Currency { get; set; }
        public DateTime? UploadDate { get; set; }
        public string? ValidationRemarks { get; set; }
        public Boolean? isSelectedApproval { get; set; }
        public string remarks { get; set; }
        public string? vendoreMail { get; set; }
        public int? wfOrder { get; set; }
        public string? Status { get; set; }

        public string? Pendingwithwhom { get; set; }
        public bool? isActive { get; set; }
        public string? CustomDomainName { get; set; }
    }
}
