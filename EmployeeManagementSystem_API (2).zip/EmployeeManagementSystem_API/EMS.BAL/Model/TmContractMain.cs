﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class TmContractMain
    {
        public int TMVCMID { get; set; }
        public int? TMCMID { get; set; }
        public string ETWID { get; set; }
        public string VendorName { get; set; }
        public string SowTypeName { get; set; }
        public string ContractTypeName { get; set; }
        public string BillingTypeName { get; set; }
        public string VerticalName { get; set; }
        public string TowerName { get; set; }
        public string ProjectOrRun { get; set; }
        public string SkillSet { get; set; }
        public string SOWNumber { get; set; }
        public string SOWName { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public string PONumber { get; set; }
        public DateTime? POStartDate { get; set; }
        public DateTime? POEndDate { get; set; }
        public string PPMProjectID { get; set; }
        public string PPMProjectName { get; set; }
        public string WBSDetail { get; set; }
        public string DomainLeadEmail { get; set; }
        public string DomainName { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string Currency { get; set; }
        [Column("BillingRateYear1", TypeName = "decimal(18,2)")]
        public decimal? BillingRateYear1 { get; set; }
        [Column("BillingRateYear2", TypeName = "decimal(18,2)")]
        public decimal? BillingRateYear2 { get; set; }
        [Column("BillingRateYear3", TypeName = "decimal(18,2)")]
        public decimal? BillingRateYear3 { get; set; }
        [Column("BillingRateYear4", TypeName = "decimal(18,2)")]
        public decimal? BillingRateYear4 { get; set; }
        [Column("BillingRateYear5", TypeName = "decimal(18,2)")]
        public decimal? BillingRateYear5 { get; set; }
        public string LocationName { get; set; }
        public int? NoticePeriod { get; set; }
        public string PositionCode { get; set; }
        public string OldSOWNumber { get; set; }
        public string RemappedMID { get; set; }
        public string SAPCode { get; set; }
        public string CostCenter { get; set; }
        public string OBS { get; set; }
        public string Status { get; set; }
        public string PendingWithWhom { get; set; }
        public int? WFOrder { get; set; }
        public bool? IsActive { get; set; }
        public string UploadedBy { get; set; }
        public DateTime? UploadedDate { get; set; }

        public string? SendBackReason { get; set; }

        public string? CustomDomainName { get; set; }
    }
}
