﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ResourseOnboardModel
    {
        public string? etwid { get; set; }
        public string? vendorName { get; set; }
        public int? vendorID { get; set; }
        public string? tower { get; set; }
        public string? sowNumber { get; set; }
        public string? sowName { get; set; }
        public DateTime? sowStartDate { get; set; }
        public DateTime? sowEndDate { get; set; }
        public string? skillSet { get; set; }
        public string? poNumber { get; set; }
        public DateTime? poStartDate { get; set; }
        public DateTime? poEndDate { get; set; }
        public string? ppmProjectID { get; set; }
        public string? ppmProjectName { get; set; }
        public string? costCenter { get; set; }


        public string? domainName { get; set; }
     
        public DateTime? domainSkillStartDate { get; set; }
        public DateTime? domainSkillEndDate { get; set; }
        public string? ProjectOrRun { get; set; }
        public string? contractType { get; set; }
        public string? billingType { get; set; }
        public decimal? billingRateYear1 { get; set; }
        public string? positionCode { get; set; }
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? gender { get; set; }
        public DateTime? dojViatris { get; set; }
        public string? managerName { get; set; }
        public string? managerEmail { get; set; }
        public string? mobileNumber { get; set; }
    }
}
