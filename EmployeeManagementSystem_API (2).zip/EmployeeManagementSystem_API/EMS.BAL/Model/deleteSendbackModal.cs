﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class deleteSendbackModal
    {
        public int tmIntId { get;set;}
        public string remarks { get; set; }
        public string? Btype { get; set; }
        
    }
}
