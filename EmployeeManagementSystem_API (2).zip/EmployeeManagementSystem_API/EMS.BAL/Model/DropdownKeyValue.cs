﻿using EMS_BAL.Interface;

namespace EMS_BAL.Model
{
    public partial class DropdownKeyValue : IDropdown
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
}
