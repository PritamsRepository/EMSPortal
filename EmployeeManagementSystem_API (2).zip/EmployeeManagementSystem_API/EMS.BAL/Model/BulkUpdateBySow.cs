﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class BulkUpdateBySow
    { 
        public string ContractType { get; set; }
        public string SearchSowText { get; set; }
        public string SOWNumber { get; set; }
        public string FieldType { get; set; }
        public string oldValue { get; set; }
        public string newValue { get; set; }
        public string dataType { get; set; }

    }
}
