﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class FPContractMl
    { 
        public int FBCMilestoneIntID { get; set; }
        public string SOWNumber { get; set; }
        public string Milestone { get; set; }
        public string MilstoneDescription { get; set; }
        public decimal MilestoneAmount { get; set; }
        public string Currency { get; set; }
        public string? ValidationRemarks { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDate { get; set; }
          
    }
}
