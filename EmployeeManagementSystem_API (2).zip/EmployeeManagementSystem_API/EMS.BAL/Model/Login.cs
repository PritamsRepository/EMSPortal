﻿namespace EMS_BAL.Model
{
    public class Login
    {
        /// <summary>
        /// UserName
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// UserName
        /// </summary>
        public string Password { get; set; }
    }
}
