﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
   public class MailMessageDetails
    {
      
            public string From { get; set; }
            public string To { get; set; }
            public string Cc { get; set; }
            public string Subject { get; set; }
        public string Body { get; set; }
        
        public string applicationLink { get; set; }
        public byte[] Attachment { get; set; }
        public string? ToName { get; set; }

    }
}
