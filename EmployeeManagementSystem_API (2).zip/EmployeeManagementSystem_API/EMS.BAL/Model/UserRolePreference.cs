﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public  class UserRolePreference
    {
        //public int RolePrefrenceId { get; set; }

        public string? UserId { get; set; }

        public int? LocationId { get; set; }

        public int? RoleMasterId { get; set; }
    }
}
