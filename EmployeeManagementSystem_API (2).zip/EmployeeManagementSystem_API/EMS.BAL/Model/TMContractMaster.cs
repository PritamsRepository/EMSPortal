﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class TMContractMaster
    {
        public int Tmvcmid { get; set; }

        public int? Tmcmid { get; set; }

        public string Etwid { get; set; }

        public int? VendorId { get; set; }

        public int? SowtypeId { get; set; }

        public int? ContractTypeId { get; set; }

        public int? BillingTypeId { get; set; }

        public int? VerticalId { get; set; }

        public int? TowerId { get; set; }

        public int? ProjectOrRunId { get; set; }

        public int? SkillSetId { get; set; }

        public string Sownumber { get; set; }

        public string Sowname { get; set; }

        public DateTime? SowstartDate { get; set; }

        public DateTime? SowendDate { get; set; }

        public string Ponumber { get; set; }

        public DateTime? PostartDate { get; set; }

        public DateTime? PoendDate { get; set; }

        public string PpmprojectId { get; set; }

        public string PpmprojectName { get; set; }

        public string Wbsdetail { get; set; }

        public string DomainLeadEmail { get; set; }

        public string DomainName { get; set; }

        public DateTime? DomainSkillStartDate { get; set; }

        public DateTime? DomainSkillEndDate { get; set; }

        public string Currency { get; set; }

        public decimal? BillingRateYear1 { get; set; }

        public decimal? BillingRateYear2 { get; set; }

        public decimal? BillingRateYear3 { get; set; }

        public decimal? BillingRateYear4 { get; set; }

        public decimal? BillingRateYear5 { get; set; }

        public int? PositionLocationId { get; set; }

        public int? NoticePeriod { get; set; }

        public string PositionCode { get; set; }

        public string OldSownumber { get; set; }

        public string RemappedMid { get; set; }

        public string Sapcode { get; set; }

        public string CostCenter { get; set; }

        public string Obs { get; set; }

        public string Status { get; set; }

        public string PendingWithWhom { get; set; }

        public int? Wforder { get; set; }

        public bool? IsActive { get; set; }

        public string UploadedBy { get; set; }

        public DateTime? UploadedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string remarks {  get; set; }
        public string? customDomainName { get; set; }
    }
}
