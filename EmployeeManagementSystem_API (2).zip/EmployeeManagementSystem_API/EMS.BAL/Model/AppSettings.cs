﻿namespace EMS_BAL.Model
{
    public class AppSettings
    { 
        public string Key { get; set; }
    }
}
