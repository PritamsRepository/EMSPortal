﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ErrorLog
    {
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorUrl { get; set; }
        public string ErrorType { get; set; }
        public string UserId { get; set; }
      
      
    }
}
