﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class LocationRole
    {
        public int? LocationId { get; set; }
        public string? LocationName { get; set; }
    }
}
