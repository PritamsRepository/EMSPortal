﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class PositiontrackModel
    {
        public string? PositionCode { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? ViatrisMID { get; set; }
        public DateTime? MappedDate { get; set; }
        public string? MappedBy { get; set; }
        public Boolean? IsMappingActive { get; set; }
        public string? status { get; set; }
        public string? VendorName { get; set; }
        public string? RITM { get; set; }
        public string? ViatrisEmailId { get; set; }


    }
}
