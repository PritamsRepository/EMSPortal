﻿using DocumentFormat.OpenXml.Wordprocessing;

namespace EMS_BAL.Model
{
    public class LoginResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public LoginResponse()
        {
            this.Token = string.Empty;
            this.RefreshToken = string.Empty;
            this.httpResponse = new HttpResponseMessage() { StatusCode = System.Net.HttpStatusCode.Unauthorized };

        }
        public string? DisplayName { get; set; }
        public string? MID { get; set; }
        public string? EmailId { get; set; }
        public string? LastLogin { get; set; }
        public string? UnsuccessfulLogins { get; set; }
        public string? EmployeeLocation { get; set; }
        public int? UserId { get; set; }
        public string? Name { get; set; }
        public string? Token { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime IssuedTime { get; set; }
        public DateTime ExpiryTime { get; set; }
        public HttpResponseMessage httpResponse { get; set; }
        public int? LocationId { get; set; }
        public int? RoleMasterId { get; set; }




    }
}