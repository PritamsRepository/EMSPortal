﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class ResourceModel
    {
       
        public int RMID { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Gender { get; set; }
        public DateTime? DOJ { get; set; }
        public string? ManagerName { get; set; }
        public string? ManagerEmail { get; set; }
        public string? ManagerMid { get; set; }
        public string? MobileNumber { get; set; }
        public string? CostCenter { get; set; }
        public string? RITM { get; set; }
        public DateTime? DOB { get; set; }
        public string? MID { get; set; }
        public string? EmailID { get; set;}
        public string? ResourceStatus { get; set; }
        public string? UploadedBy { get; set; }
        public DateTime? UploadedDate { get; set; }

    }

}
