﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class FpResourceMappingModel
    {
        public int? FBCIntID { get; set; }
        public string? ETWID { get; set; }
        public int? CMID { get; set; }
        public DateTime? AmortizationEndMonth { get; set; }
        public DateTime? AmortizationStartMonth { get; set; }
        public string? BillingType { get; set; }
        public string? ContractType { get; set; }
        public string? CostCenter { get; set; }
        public string? DomainLeadEmail { get; set; }
        public DateTime? DomainSkillEndDate { get; set; }
        public string? DomainSkillName { get; set; }
        public DateTime? DomainSkillStartDate { get; set; }
        public string? OBS { get; set; }
        public string? OldSowNumber { get; set; }
        public DateTime? POEndDate { get; set; }
        public string? PONumber { get; set; }
        public string? PositionLocation { get; set; }
        public DateTime? POStartDate { get; set; }
        public string? PPMProjectID { get; set; }
        public string? PPMProjectName { get; set; }
        public string? ProjectOrRun { get; set; }
        public string? RemappedMID { get; set; }
        public string? SkillSet { get; set; }
        public DateTime? SOWEndDate { get; set; }
        public string? SOWName { get; set; }
        public string? SOWNumber { get; set; }
        public DateTime? SOWStartDate { get; set; }
        public string? Tower { get; set; }
        public string? VendorName { get; set; }
        public string? Vertical { get; set; }
        public string? WBSDetail { get; set; }
        public string? ValidationRemarks { get; set; }
        public Boolean? isSelectedApproval { get; set; }
        public string? remarks { get; set; }
        public string? vendoreMail { get; set; }
        public int? wfOrder { get; set; }
        public string? Status { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string? Pendingwithwhom { get; set; }
        public int? VendorID { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Gender { get; set; }
        public DateTime? DOB { get; set; }
        public DateTime? DOJViatris { get; set; }
        public string? ManagerName { get; set; }
        public string? ManagerEmail { get; set; }

        public string? MobileNumber { get; set; }
        public string? VendorEmails { get; set; }
        public string? ManagerMid { get; set; }
        public int? PositionLocationId { get; set; }
        public string ? RITM { get; set; }
        public int? FPINTID { get; set; }
        public string? ViatrisMID { get; set; }
        public string? ViatrisEmailID { get; set; }
        
        public string? ContractStatus { get; set; }
        public string? IsActive { get; set; }


    }
}
