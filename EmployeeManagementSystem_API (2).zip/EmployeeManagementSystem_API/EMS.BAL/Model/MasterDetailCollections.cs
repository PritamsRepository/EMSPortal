﻿using EMS_DAL.Entities;
using System.Collections.Generic;

namespace EMS.BAL.Model
{
    public class MasterDetailCollections
    {
        public List<VendorMaster> VendorMastersDetails { get; set; } = new List<VendorMaster>();
        public List<EmsTblSowTypeMaster> SowTypeMastersDetails { get; set; } = new List<EmsTblSowTypeMaster>();
        public List<EmsTblContractTypeMaster> ContractTypeMastersDetails { get; set; } = new List<EmsTblContractTypeMaster>();
        public List<EmsTblBillingTypeMaster> BillingTypeMastersDetails { get; set; } = new List<EmsTblBillingTypeMaster>();
        public List<EmsTblVerticalMaster> VerticalMastersDetails { get; set; } = new List<EmsTblVerticalMaster>();
        public List<TowerNameMaster> TowerMastersDetails { get; set; } = new List<TowerNameMaster>();
        public List<ProjectOrRunMaster> ProjOrRunMastersDetails { get; set; } = new List<ProjectOrRunMaster>();
        public List<EmployeeSkill> SkillSetMastersDetails { get; set; } = new List<EmployeeSkill>();
        public List<LocationMaster> LocationMastersDetails { get; set; } = new List<LocationMaster>();
        public List<EmsTblObsmaster> ObsMastersDetails { get; set; } = new List<EmsTblObsmaster>();
    }

}
