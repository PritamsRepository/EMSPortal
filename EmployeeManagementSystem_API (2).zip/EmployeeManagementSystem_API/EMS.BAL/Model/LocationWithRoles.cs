﻿using EMS_BAL.Model;
using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class LocationWithRoles
    {
        public List<EmsTblRoleMaster>? UserRoles { get; set; }
        public List<LocationRole>? UserLocation { get; set; }
    }
}
