﻿using EMS_BAL.Model;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BAL.Model
{
    public class RoleTypeMaster
    {
        public int? RoleTypeID { get; set; }
        public string? RoleTypeName { get; set; }
        public string? MID { get; set; }
        public string? Name { get; set; }
        public string? EmailID { get; set; }
        public string? LocationName { get; set; }
        public int? LocationID { get; set; }
        public bool? IsPrimary { get; set; }
        public bool? IsActive { get; set; }
        public List<DropdownKeyValue>? RoleType { get; set; }
        public List<DropdownKeyValue>? LocationMaster { get; set; }
        public List<string>? SelectedLocation { get; set; }

        //public string? RoleType 
        //public int? RoleTypeID 
        //public string? Location 
        //public int? LocationID 
        //public List<RoleTypeMaster> RoletypeMasterData 
        //public List<RoleTypeMaster> LocationMasterData 
    }
}