﻿using EMS.BAL.Helper;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_BAL.Interface;
using EMS_BAL.Model;
using EMS_BAL.Services;
using EMS_DAL.Entities;
using ExcelDataReader.Log;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IIS;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Principal;

namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    //[Authorize(AuthenticationSchemes = IISServerDefaults.AuthenticationScheme)]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthenticateServices _authenticateService;
        private readonly ITokenManager _tokenManager;
        private IUserService _userService;
        private Security _security;
        private readonly IConfiguration _configuration;
        public AuthenticationController (IAuthenticateServices authenticateServices, ITokenManager tokenManager
            , IConfiguration configuration )
        {
            _authenticateService = authenticateServices;
            _tokenManager = tokenManager;
            this._configuration = configuration;
        }


        [AllowAnonymous]
        [HttpPost("Login")]
        public IActionResult Login (Login login)
        {
            ClearStaticSessionValue();
            _security = new Security();
            _userService = new UserService(this._configuration);
            var loginResponse = new LoginResponse();

            if (login is null)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                //  var loggedInUser = _authenticateService.SignIn(_security.DecryptString(login.UserName), _security.DecryptString(login.Password));
                var loggedInUser = _authenticateService.SignIn(login.UserName, login.Password);
                //   var userProfile = _userService.GetUserInfo(_security.DecryptString(login.UserName), _security.DecryptString(login.Password));
                if (loggedInUser is not null)
                {
                    var userPrefernce = _authenticateService.GetUserRolePrefernce(login.UserName);

                    if (userPrefernce.UserId is not null && userPrefernce.LocationId is not null && userPrefernce.RoleMasterId is not null)
                    {
                        //loginResponse.Token = _authenticateService.GenerateToken(login.UserName);
                        loginResponse.Token = loggedInUser.AccessToken;
                        loginResponse.RefreshToken = loggedInUser.RefreshToken;
                        loginResponse.IssuedTime = DateTime.Now;
                        double timeOut = Convert.ToDouble(45);
                        loginResponse.ExpiryTime = DateTime.Now.AddMinutes(timeOut);
                        loginResponse.Name = login.UserName;
                        loginResponse.DisplayName = loggedInUser.UserProfile.DisplayName ?? "";
                        // SessionManager.CurrentUser.DisplayName = loginResponse.DisplayName;
                        loginResponse.MID = loggedInUser.UserProfile.MID ?? "";
                        loginResponse.EmailId = loggedInUser.UserProfile.Email ?? "";
                        loginResponse.LastLogin = loggedInUser.UserProfile.LastLogin != null ? loggedInUser.UserProfile.LastLogin : "First time";
                        loginResponse.UnsuccessfulLogins = loggedInUser.UserProfile.UnsuccessfulLogin != 0 ? Convert.ToString(loggedInUser.UserProfile.UnsuccessfulLogin) : "0";
                        loginResponse.EmployeeLocation = loggedInUser.UserProfile.Location != null ? loggedInUser.UserProfile.Location : "Bangalore Office";
                        loginResponse.httpResponse.StatusCode = HttpStatusCode.OK;
                        loginResponse.LocationId = userPrefernce.LocationId.HasValue != true ? 0 : userPrefernce.LocationId.Value;
                        loginResponse.RoleMasterId = userPrefernce.RoleMasterId.HasValue != true ? 0 : userPrefernce.RoleMasterId.Value;

                        SessionManager.CurrentUser.Location_ID = loginResponse.LocationId;
                        SessionManager.CurrentUser.Role_ID = loginResponse.RoleMasterId;
                        // loginResponse.UserRolesAssigned = userRoles;
                        //loginResponse.IsAuthorizedRequestor = Isrequester;
                        loginResponse.UserId = loggedInUser.UserProfile.UserId;
                        return Ok(loginResponse);
                    }
                    else
                    {
                        return Unauthorized("User UnAuthorized.");
                    }
                }
            }
            catch (Exception ex)
            {
                loginResponse.httpResponse.StatusCode = HttpStatusCode.Unauthorized;
                return Unauthorized(ex.Message.ToString());
            }
            return Unauthorized("User UnAuthorized.");
        }



        [HttpPost("SignOut")]
        public IActionResult SignOut ([FromQuery] string id)
        {

            _tokenManager.DeactivateCurrentAsync();
            ClearStaticSessionValue();
            return Ok();
        }
        private void ClearStaticSessionValue ()
        {
            SessionManager.CurrentUser.MID = null;
            SessionManager.CurrentUser.Location_ID = null;
            SessionManager.CurrentUser.DisplayName = null;
            SessionManager.CurrentUser.EmailID = null;
            SessionManager.CurrentUser.Role_ID = null;
            SessionManager.CurrentUser.IsProcurementLead = true;
            SessionManager.CurrentUser.IsLocalIT = false;
            SessionManager.CurrentUser.IsFinanceManager = false;
            SessionManager.CurrentUser.IsResourceManager = false;
            SessionManager.CurrentUser.IsEmployee = false;
            SessionManager.CurrentUser.IsAdmin = false;
        }



        [HttpPost("tokens/{token}/refresh")]
        // [AllowAnonymous]
        public IActionResult RefreshAccessToken (string token)
            => Ok(_authenticateService.RefreshAccessToken(token));


        [HttpPost("tokens/{token}/revoke")]
        public IActionResult RevokeRefreshToken (string token)
        {
            _authenticateService.RevokeRefreshToken(token);

            return NoContent();
        }

        [HttpPost("tokens/cancel")]
        public async Task<IActionResult> CancelAccessToken ()
        {
            await _tokenManager.DeactivateCurrentAsync();

            return NoContent();
        }


        //[HttpGet()]
        //[Route("GetLocationsWithRoles")]
        ////[AllowAnonymous]
        //public LocationWithRoles GetLocationsWithRoles (string id)
        //{
        //    var RoleDetails = _authenticateService.GetLocationAndRolesByMid(id);
        //    return RoleDetails;
        //}


        [HttpGet()]
        [Route("GetLocationsWithRoles")]
        //[AllowAnonymous]
        public IActionResult GetLocationsWithRoles (string id)
        {
            var RoleDetails = _authenticateService.GetLocationAndRolesByMid(id);
            return Ok (RoleDetails);
        }



        //[HttpPost]
        //[Route("UpdateRolePreference")]
        ////[AllowAnonymous]
        //public UserRolePreference UpdateRolePreference (UserRolePreference pref)
        //{
        //    var preferences = _authenticateService.UserPreference(pref);

        //    SessionManager.CurrentUser.Location_ID = null;
        //    SessionManager.CurrentUser.Role_ID = null;

        //    SessionManager.CurrentUser.Location_ID = preferences.LocationId;
        //    SessionManager.CurrentUser.Role_ID = preferences.RoleMasterId;

        //    return preferences;
        //}

        [HttpPost]
        [Route("UpdateRolePreference")]
        //[AllowAnonymous]
        public IActionResult UpdateRolePreference (UserRolePreference pref)
        {
            var preferences = _authenticateService.UserPreference(pref);

            SessionManager.CurrentUser.Location_ID = null;
            SessionManager.CurrentUser.Role_ID = null;

            SessionManager.CurrentUser.Location_ID = preferences.LocationId;
            SessionManager.CurrentUser.Role_ID = preferences.RoleMasterId;

            return Ok(preferences);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("AuthByWindows")]
        public IActionResult AuthByWindows()
        {
            var loginResponse = new LoginResponse();

            /*var UserName = AccountHelper.GetWinAuthAccount(HttpContext); ;*/ 

            var UserName = HttpContext.User?.Identity?.Name;
            try
            {
                if (UserName is not null && UserName.Contains('\\'))
                {
                    //UserName = UserName.Split('\\')[1];
                    UserName = UserName.Split('\\')[1]; 
                }
                else
                {
                    UserName = UserName;
                }
                
                if (UserName is not null && UserName.Length > 0)
                {
                    var loggedInUser = _authenticateService.SignInViaWinAuth(UserName);

                    if (loggedInUser is not null)
                    {
                        var userPrefernce = _authenticateService.GetUserRolePrefernce(UserName);

                        //loginResponse.Token = _authenticateService.GenerateToken(login.UserName);
                        loginResponse.Token = loggedInUser.AccessToken;
                        loginResponse.RefreshToken = loggedInUser.RefreshToken;
                        loginResponse.IssuedTime = DateTime.Now;
                        double timeOut = Convert.ToDouble(5);
                        loginResponse.ExpiryTime = DateTime.Now.AddMinutes(timeOut);
                        loginResponse.Name = UserName;
                        loginResponse.DisplayName = loggedInUser.UserProfile.DisplayName ?? "";
                        SessionManager.CurrentUser.DisplayName = loginResponse.DisplayName;
                        loginResponse.MID = loggedInUser.UserProfile.MID ?? "";
                        loginResponse.EmailId = loggedInUser.UserProfile.Email ?? "";
                        loginResponse.LastLogin = loggedInUser.UserProfile.LastLogin != null ? loggedInUser.UserProfile.LastLogin : "First time";
                        loginResponse.UnsuccessfulLogins = loggedInUser.UserProfile.UnsuccessfulLogin != 0 ? Convert.ToString(loggedInUser.UserProfile.UnsuccessfulLogin) : "0";
                        loginResponse.EmployeeLocation = loggedInUser.UserProfile.Location != null ? loggedInUser.UserProfile.Location : "Bangalore Office";
                        loginResponse.httpResponse.StatusCode = HttpStatusCode.OK;
                        loginResponse.LocationId = userPrefernce.LocationId.HasValue != true ? 0 : userPrefernce.LocationId.Value;
                        loginResponse.RoleMasterId = userPrefernce.RoleMasterId.HasValue != true ? 0 : userPrefernce.RoleMasterId.Value;

                        SessionManager.CurrentUser.Location_ID = loginResponse.LocationId;
                        SessionManager.CurrentUser.Role_ID = loginResponse.RoleMasterId;
                        // loginResponse.UserRolesAssigned = userRoles;
                        //loginResponse.IsAuthorizedRequestor = Isrequester;
                        loginResponse.UserId = loggedInUser.UserProfile.UserId;
                        return Ok(loginResponse);
                    }
                    else
                    {
                        return BadRequest("You are not authorized to access this application");
                    }
                }
                else
                {
                    return BadRequest("SSO Failed!, UserName not found. ");
                }
            }
            catch (Exception ex)
            {
                //_errorService.LogException(ex, "", "AuthenticationController: GetWindowsAuth");
                return BadRequest("SSO Failed! ex.message: " + ex.Message);
            }
        }


    }
}