﻿using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_DAL.Entities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ErrorController : ControllerBase
    {
        private readonly IErrorLog _errorLog;
        public ErrorController( IErrorLog errorLog)
        {    
            _errorLog = errorLog;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("SaveLoggedError")]
        public IActionResult SaveLoggedError ([FromBody]ErrorLog  errorLog)
        {
            var result=_errorLog.logError(errorLog);
            return Ok(result);
        }
    }
}
