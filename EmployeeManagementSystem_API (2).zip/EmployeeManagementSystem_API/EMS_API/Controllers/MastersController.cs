﻿using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Model;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using NetTopologySuite.Geometries;
using System.Security.Cryptography;
using System.Security.Policy;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class MastersController : ControllerBase
    {
        private readonly IMastersService _mastersService;
        private readonly IEmployeeMaster _employeeMaster;
        public MastersController(IMastersService MasterService,IEmployeeMaster employeeMaster)
        {
            _mastersService = MasterService;
            _employeeMaster = employeeMaster;
        }
        [HttpGet]
        [Route("GetLocationAndRoleType")]
        public async Task<ActionResult<RoleTypeMaster>> GetLocationAndRoleType ()
        {
            var model = new RoleTypeMaster();
            //model.LocationMaster = _mastersService.GetLocationData();
          //  model.RoleType = _mastersService.GetRoleTypeData();
            return model;

        }
        [HttpGet]
        [Route("GetEmployeeSearchDetails")]
        public IActionResult GetEmployeeSearchDetails(string UserName)
        {
            var data = _mastersService.GetEmployeeSearchDetails(UserName);
            return Ok(data);
        }
        [HttpGet]
        [Route("GetEmpRoleMappingData")]
        public async Task<ActionResult> GetEmpRoleMappingData([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationId")] int LocationId)
        {
            var data = _mastersService.GetEmpRoleMappingData(UserName,LocationId);

            return Ok(data);
        }
        [HttpPost]
        [Route("SaveEmployeeMappingDetails")]
        public async Task<ActionResult> SaveEmployeeMappingDetails(RoleTypeMaster roleType)
        {
            _mastersService.SaveEmployeeMappingDetails(roleType.RoleTypeName, roleType.MID, roleType.Name, roleType.EmailID, roleType.SelectedLocation, roleType.IsPrimary==null?false:true, roleType.IsActive.Value);
            return Ok();
        }
        [HttpPost]
        [Route("DeactivateRoleMappingDetailsByID")]
        public async Task<ActionResult> DeactivateRoleMappingDetailsByID([FromBody] int roleTypeID)
        {
           var data= _mastersService.DeactivateRoleMappingDetailsByID(Convert.ToInt32(roleTypeID));
            return Ok(data);
        }
        [HttpPost]
        [Route("PrimaryRoleMappingDetailsByID")]
        public async Task<ActionResult> PrimaryRoleMappingDetailsByID([FromBody] int roleTypeID)
        {
           var data= _mastersService.PrimaryRoleMappingDetailsByID(roleTypeID);
            return Ok(data);
        }
        [HttpGet]
        [Route("GetLocationAndRoleTypeByMid")]
        public async Task<ActionResult<RoleTypeMaster>> GetLocationAndRoleTypeByMID(string UserName)
        {
            var model = new RoleTypeMaster();
            model.LocationMaster = _mastersService.GetLocationDataByMID(UserName);
            model.RoleType = _mastersService.GetRoleTypeData();
            return model;

        }


        [HttpGet()]
        [Route("GetAllEMSMasterDetails")]
        //[AllowAnonymous]
        public MasterDetailCollections GetMasterDetailCollections()
        {
            return _mastersService.GetAllEMSMasterDetails();
        }

        [HttpGet()]
        [Route("GetAllProjectOrRunMaster")]
        
        public ActionResult<List<DropdownKeyValue>> GetAllProjectOrRunMaster ()
        {
            var result= _mastersService.GetProjectorRunMaster();
            return result;
        }

        [HttpGet()]
        [Route("GetAllEmployee")]
        public ActionResult<List<EmployeeMaster>> GetAllEmployee ()
        {
            var result = _employeeMaster.GetAllEmployee();
            return result;
        }


    }
}
