﻿using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS.BAL.Services;
using EMS_DAL.Entities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Drawing;
using System.Net;

namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ReportsController : ControllerBase
    {
        private readonly IReportService _reportService;
        public ReportsController (IReportService reportService)
        {
            _reportService = reportService;

        }
        [HttpGet]
        [Route("GetContractDetailedReport")]
        public async Task<ActionResult<IEnumerable<sp_EMS_ContractDetailReportResult>>> GetContractDetailedReport ([FromQuery] string reportType, [FromQuery] int prId)
        {

            var result = await _reportService.GetContractDetailReport(reportType, prId);
            return Ok(result == null ? HttpStatusCode.InternalServerError : result);

        }
        [HttpGet]
        [Route("GetContractSummaryReport")]
        public async Task<ActionResult<IEnumerable<sp_EMS_ContractSummaryReportResult>>> GetContractSummaryReport ([FromQuery] string reportType, [FromQuery] int prId)
        {
            var result = await _reportService.GetContractSummaryReport(reportType, prId);
            if (result != null)
            {
                result=result.Where(x=>x.SummaryType.ToLower()==reportType.ToLower()).OrderByDescending(x=>x.TotalPosition).ToList();
            }
            return Ok(result == null ? HttpStatusCode.InternalServerError : result);

        }

        [HttpGet]
        [Route("GeOpenPositionReport")]
        public ActionResult<IEnumerable<sp_EMS_ReportOpenPositionResult>> GeOpenPositionReport (string reportType)
        {
            var result = _reportService.GetOpenPositionReport(reportType);
            return Ok(result == null ? HttpStatusCode.InternalServerError : result);

        }
        [HttpGet]
        [Route("GetContractReportByToweHeadAndDomain")]
        public async Task<IActionResult> GetContractReportByToweHeadAndDomain([FromQuery(Name = "TowerHead")] string TowerHead, [FromQuery(Name = "PrjOrRun")] string PrjOrRun)
        {
            var result = _reportService.GetContractReportByToweHeadAndDomain(TowerHead, PrjOrRun);
            return Ok(result);

        }
        [HttpPost]
        [Route("SaveContractPublishedData")]
        public async Task<IActionResult> SaveContractPublishedData([FromBody] List<PublishedContractReport> result)
        {
            var data = _reportService.SaveContractPublishedData(result);

            return Ok();
        }

        [HttpGet]
        [Route("GetpublishedContractDetails")]
        public async Task<IActionResult> GetpublishedContractDetails([FromQuery(Name = "TowerHead")] string TowerHead, [FromQuery(Name = "PrjOrRun")] string PrjOrRun)
        {
            var result = _reportService.GetpublishedContractDetails(TowerHead, PrjOrRun);
            return Ok(result);

        }


        [HttpPost]
        [Route("SaveContractPublishedDataWithMail")]
        public async Task<IActionResult> SaveContractPublishedDataWithMail([FromBody] List<PublishedContractReport> result)
        {
            var data = _reportService.SaveContractPublishedDataWithMail(result);

            return Ok();
        }

        [HttpGet]
        [Route("getTowerHeadMasterData")]
        public async Task<IActionResult> getTowerHeadMasterData()
        {
            var result = _reportService.getTowerHeadMasterData();
            return Ok(result);

        }

        [HttpGet]
        [Route("GetAllVendorContractsByDate")]
        public async Task<IActionResult> GetAllVendorContractsByDate([FromQuery] string ContractType)
        {
            var results = await _reportService.GetAllVendorContractsByDate(ContractType);
            return Ok(results);
        }

    }
}