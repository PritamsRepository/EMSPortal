﻿using DocumentFormat.OpenXml.Wordprocessing;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS.BAL.Services;
using EMS_BAL.Helper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Any;
using System.ComponentModel.Design;

namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ResourceOnboardingController : ControllerBase
    {
        private readonly IResourceOnboardingService _resourceOnboardingService;

        public ResourceOnboardingController(IResourceOnboardingService resourceOnboardingService)
        {
            _resourceOnboardingService = resourceOnboardingService;
        }

        [HttpGet]
        [Route("GetResourceMappingPendingList")]
        [HttpGet("GetAllMediaWithTag")]
        public ActionResult GetResourceMappingPendingList( [FromQuery(Name="UserName")]string UserName, [FromQuery(Name="LocationId")]int LocationId)
        {
            var data = _resourceOnboardingService.GetResourceMappingPendingList(UserName, LocationId);
            return Ok(data);
        }

        [HttpPost]
        [Route("SaveOnBoardingResourceMappingPendingList")]
        public async Task<IActionResult> SaveOnBoardingResourceMappingPendingList([FromBody] List<ResourceOnboardingModel> result)
        {
           var data = _resourceOnboardingService.SaveOnBoardingResourceMappingPendingList(result);

            return Ok();
        }
       
        [HttpGet]
        [Route("GetTMOnboardingApprovalPendingList")]
        public ActionResult GetTMOnboardingApprovalPendingList(string UserName)
        {
            var data = _resourceOnboardingService.GetTMOnboardingApprovalPendingList(UserName);

            return Ok(data);
        }
        
        [HttpPost]
        [Route("SaveTMresourceApprovals")]
        public async Task<IActionResult> SaveTMresourceApprovals([FromBody] List<ResourceOnboardingModel> result)
        {
            var data = _resourceOnboardingService.SaveTMOnBoardingResourceApprovalData(result);

            return Ok();
        }
        
        [HttpPost]
        [Route("sendOpenPositionsToVendor")]
        public async Task<IActionResult> sendOpenPositionsToVendor([FromBody] List<ResourceOnboardingModel> result)
        {
            var data = _resourceOnboardingService.sendOpenPositionsToVendor(result);

            return Ok();
        }

        
        [HttpGet]
        [Route("GetResourceMappingTrackDetails")]

        public async Task<ActionResult> GetResourceMappingTrackDetails([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "workflowOrder")] int workflowOrder, [FromQuery(Name = "LocationID")] int LocationID, [FromQuery(Name = "Filter")] string Filter, [FromQuery(Name = "ActiveFilter")] string ActiveFilter, [FromQuery(Name = "FromDate")] string FromDate, [FromQuery(Name = "ToDate")] string ToDate)
        {
            var data = _resourceOnboardingService.GetResourceMappingTrackDetails(UserName, workflowOrder, LocationID, Filter, ActiveFilter, Convert.ToDateTime(FromDate), Convert.ToDateTime(ToDate));

            return Ok(data);
        }
        [HttpGet]
        [Route("GetTMResourceWorkFlow")]

        public async Task<ActionResult> GetTMResourceWorkFlow([FromQuery(Name = "tmvcmid")] int tmvcmid)
        {
            var data = _resourceOnboardingService.GetTMResourceWorkFlow(tmvcmid);

            return Ok(data);
        }
        
        [HttpGet]
        [Route("GetResourceMIDcreationPendingList")]
        public async Task<ActionResult> GetResourceMIDcreationPendingList([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationID")] int LocationID)
        {
            var data = _resourceOnboardingService.GetResourceMIDcreationPendingList(UserName, LocationID);

            return Ok(data);
        }

        [HttpPost]
        [Route("SaveResourceAssetDetails")]
        public async Task<IActionResult> SaveResourceAssetDetails(ResourcebasicDtsModel rcrs)
        {
            var data = _resourceOnboardingService.SaveResourceAssetDetails(rcrs.Mid, rcrs.Email, (int)rcrs.Rmid, (int)rcrs.Cmid);

            return Ok(data);
        }


        [HttpGet]
        [Route("SearchDataFromAd")]
        public ActionResult SearchDataFromAd([FromQuery(Name = "MID")] string MID)
        {
            var data = _resourceOnboardingService.SearchDataFromAd(MID);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetResourceMappingMilestonePendingList")]

        public async Task<ActionResult> GetResourceMappingMilestonePendingList([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationId")] int LocationId)
        {
            var data = _resourceOnboardingService.GetResourceMappingMilestonePendingList(UserName, LocationId);
            return Ok(data);
        }
        
        [HttpPost]
        [Route("saveMilestoneApprovaldata")]
        public async Task<IActionResult> saveMilestoneApprovaldata([FromBody] List<FpResourceMappingModel> result)
        {
            var data = _resourceOnboardingService.SaveFPOnBoardingMilestoneResourceApprovalData(result);

            return Ok();
        }

        
         [HttpPost]
        [Route("SaveOnBoardingMilestoneResourceMapping")]
        public async Task<IActionResult> SaveOnBoardingMilestoneResourceMapping([FromBody] List<FpResourceMappingModel> result)
        {
            var data = _resourceOnboardingService.SaveOnBoardingMilestoneResourceMapping(result);

            return Ok();
        }

        
        [HttpGet]
        [Route("GetResourceMappingMonthlyPendingList")]

        public async Task<ActionResult> GetResourceMappingMonthlyPendingList([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationId")] int LocationId)
        {
            var data = _resourceOnboardingService.GetResourceMappingMonthlyPendingList(UserName, LocationId);

            return Ok(data);
        }

        [HttpPost]
        [Route("saveMonthlyApprovaldata")]
        public async Task<IActionResult> saveMonthlyApprovaldata([FromBody] List<FpResourceMappingModel> result)
        {
            var data = _resourceOnboardingService.SaveFPOnBoardingMonthlyResourceApprovalData(result);

            return Ok();
        }


        [HttpPost]
        [Route("SaveOnBoardingMonthlyResourceMapping")]
        public async Task<IActionResult> SaveOnBoardingMonthlyResourceMapping([FromBody] List<FpResourceMappingModel> result)
        {
            var data = _resourceOnboardingService.SaveOnBoardingMonthlyResourceMapping(result);

            return Ok();
        }
        
        [HttpGet]
        [Route("GetFPmonthlyResourceWorkFlow")]

        public async Task<ActionResult> GetFPmonthlyResourceWorkFlow([FromQuery(Name = "fbcIntID")] int fbcIntID)
        {
            var data = _resourceOnboardingService.GetFPmonthlyResourceWorkFlow(fbcIntID);

            return Ok(data);
        }
        [HttpGet]
        [Route("GetFPmilestoneResourceWorkFlow")]

        public async Task<ActionResult> GetFPmilestoneResourceWorkFlow([FromQuery(Name = "fbcIntID")] int fbcIntID)
        {
            var data = _resourceOnboardingService.GetFPmilestoneResourceWorkFlow(fbcIntID);

            return Ok(data);
        }
        
         [HttpGet]
        [Route("GetMilestoneDetailsBySowNum")]
        public async Task<ActionResult> GetMilestoneDetailsBySowNum([FromQuery(Name = "SowNumber")] string SowNumber)
        {
            var data = _resourceOnboardingService.GetMilestoneDetailsBySowNum(SowNumber);
            return Ok(data);
        }

        

        [HttpGet]
        [Route("GetMonthlyDetailsBySowNum")]
        public async Task<ActionResult> GetMonthlyDetailsBySowNum([FromQuery(Name = "SowNumber")] string SowNumber)
        {
            var data = _resourceOnboardingService.GetMonthlyDetailsBySowNum(SowNumber);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetMilestoneMIDcreationPendingList")]
        public async Task<ActionResult> GetMilestoneMIDcreationPendingList([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationID")] int LocationID)
        {
            var data = _resourceOnboardingService.GetMilestoneMIDcreationPendingList(UserName, LocationID);

            return Ok(data);
        }

        [HttpGet]
        [Route("GetMonthlyMIDcreationPendingList")]
        public async Task<ActionResult> GetMonthlyMIDcreationPendingList([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "LocationID")] int LocationID)
        {
            var data = _resourceOnboardingService.GetMonthlyMIDcreationPendingList(UserName, LocationID);

            return Ok(data);
        }

        [HttpPost]
        [Route("SaveMilestoneResourceAssetDetails")]
       // [AllowAnonymous]

        public async Task<IActionResult> SaveMilestoneResourceAssetDetails(ResourcebasicDtsModel rcrs)
        {
            var data = _resourceOnboardingService.SaveMilestoneResourceAssetDetails(rcrs.Mid, rcrs.Email, (int)rcrs.Rmid, (int)rcrs.Cmid);

            return Ok(data);
        }
        [HttpPost]
        [Route("SaveMonthlyResourceAssetDetails")]
        //[AllowAnonymous]
        public async Task<IActionResult> SaveMonthlyResourceAssetDetails(ResourcebasicDtsModel rcrs)
        {
            var data = _resourceOnboardingService.SaveMonthlyResourceAssetDetails(rcrs.Mid, rcrs.Email, (int)rcrs.Rmid, (int)rcrs.Cmid);

            return Ok(data);
        }

        [HttpPost]
        [Route("sendFPOpenPositionsToVendor")]
        //[AllowAnonymous]

        public IActionResult sendFPOpenPositionsToVendor([FromBody] List<FpResourceMappingModel> result)
        {
            var data = _resourceOnboardingService.sendFPOpenPositionsToVendor(result);

            return Ok();
        }

        
        [HttpGet]
        [Route("GetResourceFPmonthlyTrackDts")]

        public async Task<ActionResult> GetResourceFPmonthlyTrackDts([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "workflowOrder")] int workflowOrder, [FromQuery(Name = "LocationID")] int LocationID, [FromQuery(Name = "Filter")] string Filter, [FromQuery(Name = "ActiveFilter")] string ActiveFilter, [FromQuery(Name = "FromDate")] string FromDate, [FromQuery(Name = "ToDate")] string ToDate)
        {
            var data = _resourceOnboardingService.GetResourceFPmonthlyTrackDts(UserName, workflowOrder, LocationID, Filter, ActiveFilter, Convert.ToDateTime(FromDate), Convert.ToDateTime(ToDate));

            return Ok(data);
        }

        [HttpGet]
        [Route("GetResourceFPmilestoneTrackDts")]

        public async Task<ActionResult> GetResourceFPmilestoneTrackDts([FromQuery(Name = "UserName")] string UserName, [FromQuery(Name = "workflowOrder")] int workflowOrder, [FromQuery(Name = "LocationID")] int LocationID, [FromQuery(Name = "Filter")] string Filter, [FromQuery(Name = "ActiveFilter")] string ActiveFilter,[FromQuery(Name = "FromDate")] string FromDate, [FromQuery(Name = "ToDate")] string ToDate)
        {
            var data = _resourceOnboardingService.GetResourceFPmilestoneTrackDts(UserName, workflowOrder, LocationID, Filter, ActiveFilter, Convert.ToDateTime(FromDate), Convert.ToDateTime(ToDate));

            return Ok(data);
        }
        [HttpGet]
        [Route("GetMultipleResourceByPositionCode")]
        public async Task<ActionResult> GetMultipleResourceByPositionCode([FromQuery(Name = "PositionCode")] string PositionCode)
        {
            var data = _resourceOnboardingService.GetMultipleResourceByPositionCode(PositionCode);

            return Ok(data);
        }

        
       [HttpPost]
        [Route("DeleteIntrResourceTMdataById")]
        public async Task<ActionResult> DeleteIntrResourceTMdataById([FromBody] int tmrmid)
        {
            var data = _resourceOnboardingService.DeleteIntrResourceTMdataById(Convert.ToInt32(tmrmid));
            return Ok();
        }
        
        [HttpPost]
        [Route("DeleteIntrResourceFPmyldataById")]
        public async Task<ActionResult> DeleteIntrResourceFPmyldataById([FromBody] int fpintid)
        {
            var data = _resourceOnboardingService.DeleteIntrResourceFPmyldataById(Convert.ToInt32(fpintid));
            return Ok();
        }
        [HttpPost]
        [Route("DeleteIntrResourceFPmlsdataById")]
        public async Task<ActionResult> DeleteIntrResourceFPmlsdataById([FromBody] int fpintid)
        {
            var data = _resourceOnboardingService.DeleteIntrResourceFPmlsdataById(Convert.ToInt32(fpintid));
            return Ok();
        }
    }
}
