﻿using DocumentFormat.OpenXml.InkML;
using EFCore.BulkExtensions;
using EMS.BAL.Helper;
using EMS.BAL.Interface;
using EMS.BAL.Model;
using EMS_BAL.Helper;
using EMS_BAL.Model;
using EMS_DAL.Entities;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Net;
using System.Web;


namespace EMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]

    public class ContractsController : ControllerBase
    {

        private readonly ITMContract _tmContract;
        private readonly IFPContract _fpContract;
        private readonly IMastersService _mastersService;
        public ContractsController(ITMContract tMContract, IFPContract fPContract, IMastersService masters)
        {
            _tmContract = tMContract;
            _fpContract = fPContract;
            _mastersService = masters;

        }

        #region "T&M Contarct Upload Workflow"

        [HttpPost]
        [Route("TMContractUpload")]
        public IActionResult TMContractUpload(List<EmsTblTmvendorContractIntermediateMaster> tmContracts)
        {
            //return BadRequest();

            string message = "";
            string mid = SessionManager.CurrentUser.MID;
            int locationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            string location = _mastersService.GetLocationName(locationId);

            if (mid == null || location == null)
            {
                return BadRequest("Something went wrong!, Please Try loging again.");
            }

            if (tmContracts.Count > 0)
            {
                try
                {
                    //throw new Exception("Error Occured");

                    _tmContract.UploadTMContractData(tmContracts, mid, location);

                }
                catch (Exception ex)
                {
                    return StatusCode(500, ex.Message);
                    //return BadRequest("UploadTMContractData error please remove P1 ." );

                }
            }

            //else
            //{
            //    return BadRequest();
            //}

            return Ok();
        }

        //public IActionResult TMContractUpload(List<IFormFile> postedFiles)
        //{ 
        //test comment
        //    string message = "";
        //    string mid = SessionManager.CurrentUser.MID;
        //    int locationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
        //    string location = _mastersService.GetLocationName(locationId);

        //    if (mid == null || location == null)
        //    {
        //        return BadRequest();
        //    }

        //    var httpRequest = HttpContext.Request;
        //    if (httpRequest.Form.Files.Count > 0)
        //    {
        //        try
        //        {
        //            var file = httpRequest.Form.Files[0];

        //            Stream stream = file.OpenReadStream();
        //            var ms = new MemoryStream();
        //            var dtResult = ExcelToDataTable(stream);

        //            var finalRecords = dtResult[0];
        //            var tmContracts = new List<TMContract>();

        //            for (int i = 0; i < finalRecords.Rows.Count; i++)
        //            {
        //                var tmContract = new TMContract();
        //                tmContract.ETWID = finalRecords.Rows[i]["ETWID"]?.ToString();
        //                tmContract.VendorName = finalRecords.Rows[i]["VendorName"]?.ToString();
        //                tmContract.PositionCode = finalRecords.Rows[i]["PositionCode"]?.ToString();
        //                tmContract.PositionLocation = finalRecords.Rows[i]["PositionLocation"]?.ToString();
        //                tmContract.OldSowNumber = finalRecords.Rows[i]["OldSowNumber"]?.ToString();
        //                tmContract.SOWNumber = finalRecords.Rows[i]["SOWNumber"]?.ToString();
        //                tmContract.SOWName = finalRecords.Rows[i]["SOWName"]?.ToString();
        //                tmContract.SOWType = finalRecords.Rows[i]["SOWType"]?.ToString();
        //                tmContract.SOWStartDate = DateTime.TryParse(finalRecords.Rows[i]["SOWStartDate"]?.ToString(), out var sowStartDate) ? sowStartDate : (DateTime?)null;
        //                tmContract.SOWEndDate = DateTime.TryParse(finalRecords.Rows[i]["SOWEndDate"]?.ToString(), out var sowEndDate) ? sowEndDate : (DateTime?)null;
        //                tmContract.PONumber = finalRecords.Rows[i]["PONumber"]?.ToString();
        //                tmContract.POStartDate = DateTime.TryParse(finalRecords.Rows[i]["POStartDate"]?.ToString(), out var poStartDate) ? poStartDate : (DateTime?)null;
        //                tmContract.POEndDate = DateTime.TryParse(finalRecords.Rows[i]["POEndDate"]?.ToString(), out var poEndDate) ? poEndDate : (DateTime?)null;
        //                tmContract.PPMProjectID = finalRecords.Rows[i]["PPMProjectID"]?.ToString();
        //                tmContract.PPMProjectName = finalRecords.Rows[i]["PPMProjectName"]?.ToString();
        //                tmContract.WBSDetail = finalRecords.Rows[i]["WBSDetail"]?.ToString();
        //                tmContract.Vertical = finalRecords.Rows[i]["Vertical"]?.ToString();
        //                tmContract.DomainLeadEmail = finalRecords.Rows[i]["DomainLeadEmail"]?.ToString();
        //                tmContract.CostCenter = finalRecords.Rows[i]["CostCenterCode"]?.ToString();
        //                tmContract.OBS = finalRecords.Rows[i]["OBS"]?.ToString();
        //                tmContract.DomainSkillName = finalRecords.Rows[i]["DomainSkillName"]?.ToString();
        //                tmContract.SkillSet = finalRecords.Rows[i]["SkillSet"]?.ToString();
        //                tmContract.DomainSkillStartDate = DateTime.TryParse(finalRecords.Rows[i]["DomainSkillStartDate"]?.ToString(), out var skillStartDate) ? skillStartDate : (DateTime?)null;
        //                tmContract.DomainSkillEndDate = DateTime.TryParse(finalRecords.Rows[i]["DomainSkillEndDate"]?.ToString(), out var skillEndDate) ? skillEndDate : (DateTime?)null;
        //                tmContract.ProjectOrRun = finalRecords.Rows[i]["ProjectOrRun"]?.ToString();
        //                tmContract.ContractType = finalRecords.Rows[i]["ContractType"]?.ToString();
        //                tmContract.BillingType = finalRecords.Rows[i]["BillingType"]?.ToString();
        //                tmContract.BillingRateYear1 = decimal.TryParse(finalRecords.Rows[i]["BillingRateYear1"]?.ToString(), out var rateYear1) ? rateYear1 : 0;
        //                tmContract.BillingRateYear2 = decimal.TryParse(finalRecords.Rows[i]["BillingRateYear2"]?.ToString(), out var rateYear2) ? rateYear2 : 0;
        //                tmContract.BillingRateYear3 = decimal.TryParse(finalRecords.Rows[i]["BillingRateYear3"]?.ToString(), out var rateYear3) ? rateYear3 : 0;
        //                tmContract.BillingRateYear4 = decimal.TryParse(finalRecords.Rows[i]["BillingRateYear4"]?.ToString(), out var rateYear4) ? rateYear4 : 0;
        //                tmContract.BillingRateYear5 = decimal.TryParse(finalRecords.Rows[i]["BillingRateYear5"]?.ToString(), out var rateYear5) ? rateYear5 : 0;
        //                tmContract.Currency = finalRecords.Rows[i]["Currency"]?.ToString();
        //                tmContract.RemappedMID = finalRecords.Rows[i]["RemappedMID"]?.ToString();
        //                tmContract.SAPCode = finalRecords.Rows[i]["SAPCode"]?.ToString();
        //                tmContract.NoticePeriod = int.TryParse(finalRecords.Rows[i]["NoticePeriodDays"]?.ToString(), out var noticePeriod) ? noticePeriod : 0;
        //                tmContract.Tower = finalRecords.Rows[i]["Tower"]?.ToString();

        //                tmContracts.Add(tmContract);

        //            }

        //             _tmContract.UploadTMContractData(tmContracts, mid, location);

        //        }
        //        catch (Exception ex)
        //        {
        //            return BadRequest();
        //        }
        //    }

        //    else
        //    {
        //        return BadRequest();
        //    }

        //    return Ok();
        //}

        private static DataTableCollection ExcelToDataTable(Stream stream)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                {
                    ConfigureDataTable = (data) => new ExcelDataTableConfiguration()
                    {
                        UseHeaderRow = true
                    }
                });

                return result.Tables;
            }
        }


        [HttpGet]
        [Route("GetTMContractInt")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public ActionResult<IEnumerable<TMContract>> GetTMContractInt()
        {
            string mid = SessionManager.CurrentUser.MID;

            var tmContract = _tmContract.GetTMContractIntermediateList(mid).OrderByDescending(x => x.ValidationRemarks).ToList();
            return tmContract;
        }

        [HttpPost]
        [Route("SaveTMIntermediateDataToMain")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public IActionResult SaveTMIntermediateDataToMain(List<int> tmIntId)
        {
            string mid = SessionManager.CurrentUser.MID;
            string name = SessionManager.CurrentUser.DisplayName;
            bool isProcLead = true;
            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            if (locId > 0 && mid is not null && name is not null)
            {
                _tmContract.SaveTMIntDataToMain(tmIntId, mid, name, isProcLead, locId);

                return Ok();
            }

            return BadRequest("Something went wrong!, Please Try loging again.");
        }

        [HttpPost]
        [Route("DeleteTMIntermediateData")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public IActionResult DeleteTMIntermediateData(List<int> tmIntId)
        {

            var result = _tmContract.DeleteTMIntData(tmIntId);
            if (result)
            {
                return Ok();
            }

            return BadRequest("Failed to Delete TM Uploaded Data from Intermediate Table.");
        }

        [HttpPost]
        [Route("DeleteTMSendbackData")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public IActionResult DeleteTMSendbackData(deleteSendbackModal data)
        {
            string mid = SessionManager.CurrentUser.MID;
            string name = SessionManager.CurrentUser.DisplayName;
            if (mid is not null && name is not null)
            {
                var result = _tmContract.DeleteTMSBData(data.tmIntId, mid, name, data.remarks);
                if (result)
                {
                    return Ok();
                }
            }
            return BadRequest("Failed to Delete TM Sendback record");
        }

        [HttpGet]
        [Route("GetTMVendorContractMasterDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public List<TmContractMain> GetTMVendorContractMasterDetails(string Filter, string FromDate, string ToDate)
        {
            var contractList = new List<TmContractMain>();
            if (SessionManager.CurrentUser.MID != null)
            {
                var locId = SessionManager.CurrentUser.Location_ID;
                var role = SessionManager.CurrentUser.Role_ID;

                //string displayName = SessionManager.CurrentUser.DisplayName;
                contractList = _tmContract.GetTMContractMainList(Filter, Convert.ToInt32(locId));

            }
            return contractList;
        }


        [HttpGet]
        [Route("GetTMVendorContractSendbackDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public List<TmContractMain> GetTMVendorContractSendbackDetails()
        {
            var sendBackList = new List<TmContractMain>();
            if (SessionManager.CurrentUser.MID != null)
            {
                var recordType = "Active";
                sendBackList = _tmContract.GetTMSendbackDetails(SessionManager.CurrentUser.MID, recordType, Convert.ToInt32(SessionManager.CurrentUser.Location_ID)).ToList();
            }
            return sendBackList;

        }

        [HttpPost]
        [Route("UpdateApprovedTMContractDetails")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        //below function will allow PMO admin to mo
        public string UpdateApprovedTMContractDetails(TMContractMaster tmDetails)
        {
            string mid = SessionManager.CurrentUser.MID;
            //string name = SessionManager.CurrentUser.DisplayName;
            //bool isProcLead = true;
            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            var result = "";
            if (mid == null || locId == null || locId == 0)
            {
                result = "Failed to save Contract Details, Please try again!";
                return result;
            }
            if (locId > 0)
            {
                result = _tmContract.UpdateApprovedTmContractDetails(tmDetails, mid, locId);
            }

            return result;

        }

        [HttpPost]
        [Route("updateTMContractDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public string updateTMContractDetails(TMContractMaster tmDetails)
        {
            string mid = SessionManager.CurrentUser.MID;
            string name = SessionManager.CurrentUser.DisplayName;
            bool isProcLead = true;
            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

            ////// Specify UTC and IST time zones
            ////TimeZoneInfo utcTimeZone = TimeZoneInfo.Utc;
            //TimeZoneInfo istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            ////// Convert to IST
            ////DateTime istDateTime = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowstartDate, istTimeZone);

            //tmDetails = new TMContractMaster()
            //{
            //    Tmcmid = tmDetails.Tmcmid,
            //    Tmvcmid = tmDetails.Tmvcmid,
            //    Etwid = tmDetails.Etwid,
            //    Sownumber = tmDetails.Sownumber,
            //    Sowname = tmDetails.Sowname,
            //    VendorId = tmDetails.VendorId,
            //    PositionCode = tmDetails.PositionCode,
            //    PositionLocationId = tmDetails.PositionLocationId,
            //    OldSownumber = tmDetails.OldSownumber,
            //    SowtypeId = tmDetails.SowtypeId,
            //    SowstartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowstartDate, istTimeZone),
            //    SowendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.SowendDate, istTimeZone),
            //    Ponumber = tmDetails.Ponumber,
            //    PostartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PostartDate, istTimeZone),
            //    PoendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.PoendDate, istTimeZone),
            //    PpmprojectId = tmDetails.PpmprojectId,
            //    PpmprojectName = tmDetails.PpmprojectName,
            //    Wbsdetail = tmDetails.Wbsdetail,
            //    VerticalId = tmDetails.VerticalId,
            //    DomainLeadEmail = tmDetails.DomainLeadEmail,
            //    CostCenter = tmDetails.CostCenter,
            //    Obs = tmDetails.Obs,
            //    DomainName = tmDetails.DomainName,
            //    SkillSetId = tmDetails.SkillSetId,
            //    DomainSkillStartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillStartDate, istTimeZone),
            //    DomainSkillEndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)tmDetails.DomainSkillEndDate, istTimeZone),
            //    ProjectOrRunId = tmDetails.ProjectOrRunId,
            //    ContractTypeId = tmDetails.ContractTypeId,
            //    BillingTypeId = tmDetails.BillingTypeId,
            //    BillingRateYear1 = tmDetails.BillingRateYear1,
            //    BillingRateYear2 = tmDetails.BillingRateYear2,
            //    BillingRateYear3 = tmDetails.BillingRateYear3,
            //    BillingRateYear4 = tmDetails.BillingRateYear4,
            //    BillingRateYear5 = tmDetails.BillingRateYear5,
            //    Currency = tmDetails.Currency,
            //    RemappedMid = tmDetails.RemappedMid,
            //    Sapcode = tmDetails.Sapcode,
            //    NoticePeriod = tmDetails.NoticePeriod,
            //    TowerId = tmDetails.TowerId,
            //    UpdatedDate = tmDetails.UpdatedDate,
            //    UpdatedBy = mid,
            //    remarks = tmDetails.remarks,
            //};

            var result = "";
            if (mid == null || locId == null || locId == 0)
            {
                result = "Failed to save Contract Details, Please try again!";
                return result;
            }
            if (locId > 0)
            {
                result = _tmContract.UpdateTmContractDetails(tmDetails, mid, name, isProcLead, locId);
            }

            return result;
        }

        [HttpGet]
        [Route("GetWorkFlowsOfContract")]
        public List<EmsTblTmcontractWorkFlow> GetWorkFlowsOfContract(int tmcid)
        {
            return _tmContract.GetWorkFlowsOfContract(tmcid);
        }


        #endregion

        #region "T&M Approval"
        [HttpGet]
        [Route("GetTMContractList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<TMContract>>> GetTMContractList()
        {
            //Get pending list for Finance Manager- Procurtment
            var tmContract = _tmContract.GetTMContractPendingList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0);
            return tmContract;
        }
        [HttpPost]
        [Route("PostTMContractList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public ActionResult PostTMContractList(IEnumerable<TMContract> postedData)
        {
            var tmContract = _tmContract.PostTMContractList(postedData.ToList());
            return Ok("success");
        }
        #endregion

        #region "T&M Track List"
        [HttpGet]
        [Route("GetTMContractTrackList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<TMContract>>> GetTMContractTrackList([FromQuery] string selectedFilter, [FromQuery] string selectedActiveFilter)
        {
            //Get pending list for IT Finance Manager- Procurtment
            var tmContract = _tmContract.GetTMContractTrackList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0, selectedFilter, selectedActiveFilter);

            return tmContract;
        }
        #endregion

        #region "FPUpload Contract"

        [HttpGet]
        [Route("GetWorkFlowsOfFPContract")]
        //[AllowAnonymous]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin,IT Finance Manager")]
        public List<EmsVwFpvendorContractWorkFlow> GetWorkFlowsOfFPContract([FromQuery(Name = "fbcIntID")] int fbcIntID, [FromQuery(Name = "Btype")] string Btype, [FromQuery(Name = "Ctype")] string Ctype)
        {
            return _fpContract.GetWorkFlowsOfFPContract(fbcIntID, Btype, Ctype);
        }

        [HttpPost("FPContractUpload")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]


        public async Task<IActionResult> FPContractUpload()
        {
            //string locn = "C:\\Users\\m540100\\source\\repos\\Angular\\EMS_HRITServices_App\\EMS_HRITServices_App\\bin\\Release\\net7.0\\"; //ConfigurationManager.AppSettings["EXELOC"];
            //Process myProcess = new Process();

            ////try
            ////{
            ////myProcess.StartInfo.RedirectStandardOutput = true;
            ////myProcess.StartInfo.UseShellExecute = false;
            ////myProcess.StartInfo.CreateNoWindow = true;

            //    myProcess.StartInfo.UseShellExecute = true;
            //    myProcess.StartInfo.FileName = locn + "EMS_HRITServices_App.exe";
            //    myProcess.StartInfo.CreateNoWindow = true;
            //    myProcess.StartInfo.WorkingDirectory = locn;
            //    myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            //    myProcess.Start();
            //    myProcess.WaitForExit();

            ////}
            ////catch (Exception ex)
            ////{
            ////    return StatusCode(500, ex.Message);
            ////}


            //string message = "";
            string mid = SessionManager.CurrentUser.MID;
            //int locationId = SessionManager.CurrentUser.Location_ID == null ? 0 : Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            //string? location = _mastersService.GetLocationDataByMID(mid).Where(x => x.ID == locationId.ToString()).Select(x => x.Name)?.FirstOrDefault();

            int locationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            string location = _mastersService.GetLocationName(locationId);

            if (mid == null || location == null)
            {
                return BadRequest("Something went wrong!, Please Try loging again.");
            }

            //string message = "false";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Request;
            if (httpRequest.Form.Files.Count > 0)
            {
                var file = httpRequest.Form.Files[0];

                Stream stream = file.OpenReadStream();
                var ms = new MemoryStream();
                var dtResult = ExcelToDataTable(stream);

                var finalRecords = dtResult[0];
                var fpContracts = new List<FPContract>();
                foreach (DataRow row in finalRecords.Rows)
                {
                    var fpContract = new FPContract();
                    fpContract.FBCIntID = 0;
                    fpContract.ETWID = row["ETWID"]?.ToString().Trim();
                    fpContract.VendorName = row["VendorName"]?.ToString().Trim();
                    fpContract.PositionLocation = row["PositionLocation"]?.ToString().Trim();
                    fpContract.OldSowNumber = row["OldSowNumber"]?.ToString().Trim();
                    fpContract.SOWNumber = row["SOWNumber"]?.ToString().Trim();
                    fpContract.SOWName = row["SOWName"]?.ToString().Trim();
                    fpContract.SOWStartDate = row["SOWStartDate"] == null ? null :
                                            row["SOWStartDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["SOWStartDate"]);
                    fpContract.SOWEndDate = row["SOWEndDate"] == null ? null :
                                            row["SOWEndDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["SOWEndDate"]);
                    fpContract.AmortizationStartMonth = row["AmortizationStartingFrom"] == null ? null :
                                            row["AmortizationStartingFrom"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["AmortizationStartingFrom"]);
                    fpContract.AmortizationEndMonth =
                                            row["AmortizationEndingOn"] == null ? null :
                                            row["AmortizationEndingOn"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["AmortizationEndingOn"]);
                    fpContract.PONumber = row["PONumber"].ToString().Trim();
                    fpContract.POStartDate =
                                            row["POStartDate"] == null ? null :
                                            row["POStartDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["POStartDate"]);
                    fpContract.POEndDate =
                                            row["POEndDate"] == null ? null :
                                            row["POEndDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["POEndDate"]);
                    fpContract.PPMProjectID = row["PPMProjectID"].ToString().Trim();
                    fpContract.PPMProjectName = row["PPMProjectName"].ToString().Trim();
                    fpContract.WBSDetail = row["WBSDetail"].ToString().Trim();
                    fpContract.Vertical = row["Vertical"].ToString().Trim();
                    fpContract.Tower = row["Tower"].ToString().Trim();
                    fpContract.DomainLeadEmail = row["DomainLeadEmail"].ToString().Trim();
                    fpContract.CostCenter = row["CostCenter"].ToString().Trim();
                    fpContract.OBS = row["OBS"].ToString().Trim();
                    fpContract.DomainSkillName = row["DomainSkillName"].ToString().Trim();
                    fpContract.SkillSet = row["SkillSet"].ToString().Trim();
                    fpContract.DomainSkillStartDate =
                                        row["DomainSkillStartDate"] == null ? null :
                                        row["DomainSkillStartDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["DomainSkillStartDate"]);
                    fpContract.DomainSkillEndDate =
                                        row["DomainSkillEndDate"] == null ? null :
                                        row["DomainSkillEndDate"].ToString().Trim() == "" ? null : Convert.ToDateTime(row["DomainSkillEndDate"]);
                    fpContract.ProjectOrRun = row["ProjectOrRun"].ToString().Trim();
                    fpContract.ContractType = row["ContractType"].ToString().Trim();
                    fpContract.BillingType = row["BillingType"].ToString().Trim();
                    fpContract.RemappedMID = row["RemappedMID"].ToString().Trim();
                    fpContract.ValidationRemarks = "";
                    fpContract.UpdatedBy = mid.Trim();
                    fpContract.UpdatedOn = DateTime.Now;


                    fpContracts.Add(fpContract);
                }
                //for (int i = 0; i < finalRecords.Rows.Count; i++)
                //{
                //    var fpContract = new FPContract();
                //    fpContract.FBCIntID = 0;// Convert.ToInt32(finalRecords.Rows[i][0]);

                //    fpContract.ETWID = finalRecords.Rows[i][0]?.ToString().Trim();
                //    fpContract.VendorName = finalRecords.Rows[i][1]?.ToString().Trim();
                //    fpContract.PositionLocation = finalRecords.Rows[i][2]?.ToString().Trim();
                //    fpContract.OldSowNumber = finalRecords.Rows[i][3]?.ToString().Trim();
                //    fpContract.SOWNumber = finalRecords.Rows[i][4]?.ToString().Trim();
                //    fpContract.SOWName = finalRecords.Rows[i][5]?.ToString().Trim();
                //    fpContract.SOWStartDate = finalRecords.Rows[i][6] == null ? null :
                //    finalRecords.Rows[i][6].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][6]);
                //    fpContract.SOWEndDate = finalRecords.Rows[i][7] == null ? null :
                //    finalRecords.Rows[i][7].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][7]);
                //    fpContract.AmortizationStartMonth = finalRecords.Rows[i][8] == null ? null :
                //    finalRecords.Rows[i][8].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][8]);
                //    fpContract.AmortizationEndMonth =
                //    finalRecords.Rows[i][9] == null ? null :
                //    finalRecords.Rows[i][9].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][9]);
                //    fpContract.PONumber = finalRecords.Rows[i][10].ToString().Trim();
                //    fpContract.POStartDate =
                //    finalRecords.Rows[i][11] == null ? null :
                //    finalRecords.Rows[i][11].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][11]);
                //    fpContract.POEndDate =
                //    finalRecords.Rows[i][12] == null ? null :
                //    finalRecords.Rows[i][12].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][12]);
                //    fpContract.PPMProjectID = finalRecords.Rows[i][13].ToString().Trim();
                //    fpContract.PPMProjectName = finalRecords.Rows[i][14].ToString().Trim();
                //    fpContract.WBSDetail = finalRecords.Rows[i][15].ToString().Trim();
                //    fpContract.Vertical = finalRecords.Rows[i][16].ToString().Trim();
                //    fpContract.Tower = finalRecords.Rows[i][17].ToString().Trim();
                //    fpContract.DomainLeadEmail = finalRecords.Rows[i][18].ToString().Trim();
                //    fpContract.CostCenter = finalRecords.Rows[i][19].ToString().Trim();
                //    fpContract.OBS = finalRecords.Rows[i][20].ToString().Trim();
                //    fpContract.DomainSkillName = finalRecords.Rows[i][21].ToString().Trim();
                //    fpContract.SkillSet = finalRecords.Rows[i][22].ToString().Trim();
                //    fpContract.DomainSkillStartDate =
                //    finalRecords.Rows[i][23] == null ? null :
                //    finalRecords.Rows[i][23].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][23]);
                //    fpContract.DomainSkillEndDate =
                //    finalRecords.Rows[i][24] == null ? null :
                //    finalRecords.Rows[i][24].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][24]);
                //    fpContract.ProjectOrRun = finalRecords.Rows[i][25].ToString().Trim();
                //    fpContract.ContractType = finalRecords.Rows[i][26].ToString().Trim();
                //    fpContract.BillingType = finalRecords.Rows[i][27].ToString().Trim();
                //    fpContract.RemappedMID = finalRecords.Rows[i][28].ToString().Trim();
                //    fpContract.ValidationRemarks = "";
                //    fpContract.UpdatedBy = mid.Trim();
                //    fpContract.UpdatedOn = DateTime.Now;


                //    fpContracts.Add(fpContract);
                //}

                await _fpContract.UploadFPContractDate(fpContracts, mid, location);

            }
            else
            {
                //result = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            return Ok();
        }
 

        [HttpGet("GetFbContractsFromInt")]

        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public async Task<IActionResult> GetFbContractsFromInt()
        {

            //var RITMResult = CreateRITM("requestedItemName1", "requestedItemDescription2");
            var fpcontractlist = await _fpContract.GetFPContractIntermediateList();

            return Ok(fpcontractlist);


        }

        [HttpPost("deleteFbFromIntByIDs")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool deleteFbFromIntByIDs([FromBody] List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.deleteFbFromIntByIDs(ids);
            }

            return _message;
        }

        [HttpPost]
        [Route("deleteFbAllOrByID")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public IActionResult deleteFbAllOrByID(List<string> ids)
        {
            bool _message = false;
            string id = ids[0];

            if (!string.IsNullOrEmpty(id))
            {
                _message = _fpContract.deleteFbAllOrByID(id);
            }
            return Ok(_message);
        }

        //[HttpPost("saveSelectedFpRows")]
        //
        //public bool saveSelectedFpRows([FromBody] List<int> ids)
        //{
        //    bool _message = false;
        //    if (ids.Count > 0)
        //    { 
        //        _message =  _fpContract.saveSelectedFpRows(ids);
        //    }
        //    return _message;
        //}

        [HttpPost("saveSelectedFpContract")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSelectedFpContract([FromBody] FPContract contract)
        {
            bool _message = false;
            _message = _fpContract.saveSelectedFpContract(contract);
            return _message;

        }

        [HttpPost("saveSeltedFpRowsPerTbl")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSeltedFpRowsPerTbl([FromBody] List<int> ids)
        {
            bool _message = false;

            if (ids.Count > 0)
            {
                string mid = SessionManager.CurrentUser.MID;
                string name = SessionManager.CurrentUser.DisplayName;
                bool isProcLead = true;
                int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

                _message = _fpContract.saveSeltedFpRowsPerTbl(ids, mid, name, locId);
            }
            return _message;
        }


        [HttpGet]
        [Route("GetFPVendorContractSendbackDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public List<FPContractMain> GetFPVendorContractSendbackDetails()
        {
            var sendBackList = new List<FPContractMain>();
            if (SessionManager.CurrentUser.MID != null)
            {
                sendBackList = _fpContract.GetFPSendbackDetails(SessionManager.CurrentUser.MID).ToList();
            }
            return sendBackList;

        }

        //[HttpPost("FPMilestoneUpload")]

        //[Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        //public string FPMilestoneUpload(List<IFormFile> postedFiles)
        //{
        //    string message = "false";
        //    HttpResponseMessage result = null;
        //    var httpRequest = HttpContext.Request;
        //    if (httpRequest.Form.Files.Count > 0)
        //    {
        //        var file = httpRequest.Form.Files[0];

        //        Stream stream = file.OpenReadStream();
        //        var ms = new MemoryStream();
        //        var dtResult = ExcelToDataTable(stream);

        //        var finalRecords = dtResult[0];
        //        var fpContracts = new List<FPContract>();
        //        for (int i = 0; i < finalRecords.Rows.Count; i++)
        //        {
        //            var fpContract = new FPContract();
        //            fpContract.FBCIntID = 0;// Convert.ToInt32(finalRecords.Rows[i][0]);
        //            fpContract.ETWID = finalRecords.Rows[i][0].ToString();
        //            fpContract.VendorName = finalRecords.Rows[i][1]?.ToString();
        //            fpContract.SOWNumber = finalRecords.Rows[i][2]?.ToString();
        //            fpContract.OldSowNumber = finalRecords.Rows[i][3]?.ToString();
        //            fpContract.RemappedMID = finalRecords.Rows[i][4]?.ToString();
        //            fpContract.SOWName = finalRecords.Rows[i][5].ToString();
        //            fpContract.SOWStartDate = finalRecords.Rows[i][6].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][6]);
        //            fpContract.SOWEndDate = finalRecords.Rows[i][7].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][7]);
        //            fpContract.PONumber = finalRecords.Rows[i][8].ToString();
        //            fpContract.POStartDate = finalRecords.Rows[i][9].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][9]);
        //            fpContract.POEndDate = finalRecords.Rows[i][10].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][10]);
        //            fpContract.PPMProjectID = finalRecords.Rows[i][11].ToString();
        //            fpContract.PPMProjectName = finalRecords.Rows[i][12].ToString();
        //            fpContract.Tower = finalRecords.Rows[i][13].ToString();
        //            fpContract.DomainSkillName = finalRecords.Rows[i][14].ToString();
        //            fpContract.SkillSet = finalRecords.Rows[i][15].ToString();
        //            fpContract.Vertical = finalRecords.Rows[i][16].ToString();
        //            fpContract.WBSDetail = finalRecords.Rows[i][17].ToString();
        //            fpContract.DomainLeadEmail = finalRecords.Rows[i][18].ToString();
        //            fpContract.CostCenter = finalRecords.Rows[i][19].ToString();
        //            fpContract.DomainSkillStartDate = finalRecords.Rows[i][20].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][20]);
        //            fpContract.DomainSkillEndDate = finalRecords.Rows[i][21].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][21]);
        //            fpContract.ProjectOrRun = finalRecords.Rows[i][22].ToString();
        //            fpContract.ContractType = finalRecords.Rows[i][23].ToString();
        //            fpContract.AmortizationStartMonth = finalRecords.Rows[i][24].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][24]);
        //            fpContract.AmortizationEndMonth = finalRecords.Rows[i][25].ToString() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][25]);
        //            fpContract.BillingType = finalRecords.Rows[i][26].ToString();
        //            fpContract.ValidationRemarks = "";

        //            fpContracts.Add(fpContract);
        //        }

        //        var resultdata = _fpContract.UploadFPMlContractDate(fpContracts);

        //    }
        //    else
        //    {
        //        //result = Request.CreateResponse(HttpStatusCode.BadRequest);
        //    }

        //    return message;
        //}


        [HttpGet]
        [Route("GetFPVendorContractMasterDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public List<FPContractMain> GetFPVendorContractMasterDetails([FromQuery(Name = "Filter")] string Filter, [FromQuery(Name = "FromDate")] DateTime FromDate, [FromQuery(Name = "ToDate")] DateTime ToDate, [FromQuery(Name = "ActiveFilter")] string ActiveFilter)
        {
            var contractList = new List<FPContractMain>();
            if (SessionManager.CurrentUser.MID != null)
            {
                contractList = _fpContract.GetFPContractMainList(Filter, FromDate, ToDate, ActiveFilter);
            }
            return contractList;
        }

        [HttpPost]
        [Route("updateFPContractDetails")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public string updateFPContractDetails(EmsVwFpvendorContractMasterWithId fpDetails)
        {
            string mid = SessionManager.CurrentUser.MID;
            string name = SessionManager.CurrentUser.DisplayName;
            bool isProcLead = true;
            int locId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);

            var result = "";
            if (locId > 0)
            {
                result = _fpContract.UpdateFpContractDetails(fpDetails, mid, name, isProcLead, locId);
            }

            return result;
        }

        #endregion

        #region "FPUpload Milestone"

        [HttpPost("FPContractUploadMl")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        //public string FPContractUploadMl(List<IFormFile> postedFiles)
        public async Task<IActionResult> FPContractUploadMl()
        {
            string mid = SessionManager.CurrentUser.MID;
            //int locationId = SessionManager.CurrentUser.Location_ID == null ? 0 : Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            //string? location = _mastersService.GetLocationDataByMID(mid).Where(x => x.ID == locationId.ToString()).Select(x => x.Name)?.FirstOrDefault();

            int locationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            string location = _mastersService.GetLocationName(locationId);

            if (mid == null || location == null)
            {
                return BadRequest("Something went wrong!, Please Try loging again.");
            }

            string message = "false";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Request;
            if (httpRequest.Form.Files.Count > 0)
            {
                var file = httpRequest.Form.Files[0];

                Stream stream = file.OpenReadStream();
                var ms = new MemoryStream();
                var dtResult = ExcelToDataTable(stream);

                var finalRecords = dtResult[0];
                var fpContractsml = new List<FPContractMl>();
                for (int i = 0; i < finalRecords.Rows.Count; i++)
                {
                    var fpContractml = new FPContractMl();

                    fpContractml.FBCMilestoneIntID = 0;
                    fpContractml.SOWNumber = finalRecords.Rows[i][0]?.ToString().Trim();
                    fpContractml.Milestone = finalRecords.Rows[i][1]?.ToString().Trim();
                    fpContractml.MilstoneDescription = finalRecords.Rows[i][2]?.ToString().Trim();
                    //fpContractml.MilestoneAmount = Convert.ToDecimal(finalRecords.Rows[i][3]??0.0m);
                    fpContractml.MilestoneAmount = finalRecords.Rows[i][3] != null && Decimal.TryParse(finalRecords.Rows[i][3].ToString(), out decimal temp) ? Convert.ToDecimal(finalRecords.Rows[i][3]) : 0;
                    fpContractml.Currency = finalRecords.Rows[i][4]?.ToString().Trim();
                    fpContractml.ValidationRemarks = "";
                    fpContractml.UpdatedBy = mid;
                    fpContractml.UpdateDate = DateTime.Now;

                    fpContractsml.Add(fpContractml);
                }

                var resultdata = _fpContract.UploadFPMlContractDate(fpContractsml, mid);

            }
            else
            {
                //result = Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            return Ok();
        }

        [HttpGet("GetFbContractsMlFromInt")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        //public List<FPContractMl> GetFbContractsMlFromInt()
        public async Task<IActionResult> GetFbContractsMlFromInt()
        {

            var fpcontractlist = await _fpContract.GetFPContractMlIntermediateList();

            return Ok(fpcontractlist);

        }

        [HttpPost("deleteFbmlFromIntAllOrByID")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public async Task<IActionResult> deleteFbmlFromIntAllOrByID(List<string> ids)
        {
            bool _message = false;
            string id = ids[0];
            if (!string.IsNullOrEmpty(id))
            {
                _message = await _fpContract.deleteFbmlFromIntAllOrByID(id);
            }
            return Ok(_message);

        }

        [HttpPost("deleteFbmlFromIntByIDs")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool deleteFbmlFromIntByIDs([FromBody] List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.deleteFbmlFromIntByIDs(ids);
            }

            return _message;
        }

        [HttpPost("deleteFbmoFromIntAllOrByID")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public async Task<IActionResult> deleteFbMoFromIntAllOrByID([FromBody] List<string> ids)
        {
            bool _message = false;
            string id = ids[0];
            if (!string.IsNullOrEmpty(id))
            {
                _message = await _fpContract.deleteFbMoFromIntAllOrByID(id);
            }
            return Ok(_message);


        }

        [HttpPost("deleteFbMoFromIntByIDs")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool deleteFbMoFromIntByIDs(List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.deleteFbMoFromIntByIDs(ids);
            }

            return _message;
        }


        [HttpPost("DeleteFPSendbackData")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool DeleteFPSendbackData(deleteSendbackModal data)
        {
            bool _message = false;
            string mid = SessionManager.CurrentUser.MID;
            string name = SessionManager.CurrentUser.DisplayName;
            if (mid is not null && name is not null)
            {
                _message = _fpContract.DeleteFBSendbackData(data.tmIntId, mid, name, data.remarks, data.Btype);
            }

            return _message;
        }

        [HttpPost("saveSelectedFpMlRows")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSelectedFpMlRows([FromBody] List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.saveSelectedFpMlRows(ids);
            }
            return _message;
        }

        [HttpPost("saveSelectedFpMlContract")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSelectedFpMlContract([FromBody] FPContractMl contract)
        {
            bool _message = false;
            _message = _fpContract.saveSelectedFpMlContract(contract);
            return _message;

        }
        //[HttpPost("saveSelectedFpMlContract")]
        //public bool saveSelectedFpMlContract([FromBody] FPContractMl contract)
        //{
        //    bool _message = false;
        //    _message =  _fpContract.saveSelectedFpMlContract(contract);
        //    return Ok(new { Message = _message });

        //}

        [HttpPost("saveSeltedFpMlRowsPerTbl")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSeltedFpMlRowsPerTbl([FromBody] List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.saveSeltedFpMlRowsPerTbl(ids);
            }
            return _message;
        }

        #endregion

        #region "FPUpload Monthly"

        [HttpPost("FPContractUploadMo")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public async Task<IActionResult> FPContractUploadMo()
        {
            string mid = SessionManager.CurrentUser.MID;
            //int locationId = SessionManager.CurrentUser.Location_ID == null ? 0 : Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            //string? location = _mastersService.GetLocationDataByMID(mid).Where(x => x.ID == locationId.ToString()).Select(x => x.Name)?.FirstOrDefault();

            int locationId = Convert.ToInt32(SessionManager.CurrentUser.Location_ID);
            string location = _mastersService.GetLocationName(locationId);

            if (mid == null || location == null)
            {
                return BadRequest("Something went wrong!, Please Try loging again.");
            }

            string message = "false";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Request;
            if (httpRequest.Form.Files.Count > 0)
            {
                var file = httpRequest.Form.Files[0];

                Stream stream = file.OpenReadStream();
                var ms = new MemoryStream();
                var dtResult = ExcelToDataTable(stream);

                var finalRecords = dtResult[0];
                var fpContracts = new List<FPContractMo>();
                for (int i = 0; i < finalRecords.Rows.Count; i++)
                {
                    var fpContract = new FPContractMo();

                    fpContract.FBMonthlyIntID = 0;
                    fpContract.SOWNumber = finalRecords.Rows[i][0]?.ToString().Trim();
                    fpContract.AmortizationStartDate = finalRecords.Rows[i][1] == null ? null :
                        finalRecords.Rows[i][1].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][1]);
                    fpContract.AmortizationEndDate = finalRecords.Rows[i][2] == null ? null :
                        finalRecords.Rows[i][2].ToString().Trim() == "" ? null : Convert.ToDateTime(finalRecords.Rows[i][2]);
                    //fpContract.MilestoneAmount = Convert.ToDecimal(finalRecords.Rows[i][3]);
                    fpContract.MilestoneAmount = finalRecords.Rows[i][3] != null && Decimal.TryParse(finalRecords.Rows[i][3].ToString(), out decimal temp) ? Convert.ToDecimal(finalRecords.Rows[i][3]) : 0;
                    //fpContract.DurationOfMonth = Convert.ToInt16(finalRecords.Rows[i][4]);
                    fpContract.DurationOfMonth = finalRecords.Rows[i][4] != null && Int32.TryParse(finalRecords.Rows[i][4].ToString(), out int temp1) ? Convert.ToInt32(finalRecords.Rows[i][4]) : 0;
                    fpContract.Currency = finalRecords.Rows[i][5]?.ToString().Trim();
                    fpContract.ValidationRemarks = "";

                    fpContracts.Add(fpContract);
                }

                var resultdata = _fpContract.UploadFPMOContractDate(fpContracts, mid);

            }
            else
            {
                //result = Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            return Ok();
        }

        [HttpGet("GetFbMoContractsFromInt")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public List<FPContractMo> GetFbMoContractsFromInt()
        {
            var fpcontractlist = _fpContract.GetFPMOContractIntermediateList();

            return fpcontractlist;

        }



        [HttpPost("saveSelectedFpMoRows")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSelectedFpMoRows([FromBody] List<FPContractMo> selectedRows)
        {
            bool _message = false;
            if (selectedRows.Count > 0)
            {
                _message = _fpContract.saveSelectedFpMoRows(selectedRows);
            }
            return _message;
        }

        [HttpPost("saveSelectedFpMoContract")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSelectedFpMoContract([FromBody] FPContract contract)
        {
            bool _message = false;
            _message = _fpContract.saveSelectedFpContract(contract);
            return _message;

        }

        [HttpPost("saveSeltedFpMoRowsPerTbl")]
        [Authorize(Roles = "PMO-Contract-Mgm,Admin")]
        public bool saveSeltedFpMoRowsPerTbl([FromBody] List<int> ids)
        {
            bool _message = false;
            if (ids.Count > 0)
            {
                _message = _fpContract.saveSeltedFpMoRowsPerTbl(ids);
            }
            return _message;
        }
        [HttpPost]
        public async Task<string> CreateRITM(string requestedItemName, string requestedItemDescription)
        {
            var apiresponse = await _fpContract.CallAPI(requestedItemName, requestedItemDescription);
            return apiresponse;
        }
        #endregion

        #region "FP Approval"
        [HttpGet]
        [Route("GetFPContractList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContract>>> GetFPContractList()
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPMContractPendingList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0);
            return fpContract;
        }
        [HttpGet]
        [Route("GetFPContractMilList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContractMl>>> GetFPContractMilList(string sowNumber)
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPMContractDetail(sowNumber);
            return fpContract;
        }
        [HttpPost]
        [Route("PostFPMContractList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public ActionResult PostFPMContractList(IEnumerable<FPContract> postedData)
        {
            var fpContract = _fpContract.PostFPMContractList(postedData.ToList());
            return Ok("success");
        }

        [HttpGet]
        [Route("GetFPMONContractPendingList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContract>>> GetFPMONContractPendingList()
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPMONContractPendingList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0);
            return fpContract;
        }
        [HttpGet]
        [Route("GetFPContractMONList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContractMo>>> GetFPContractMONList(string sowNumber)
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPMONContractDetail(sowNumber);
            return fpContract;
        }
        [HttpPost]
        [Route("PostFPMONContractList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public ActionResult PostFPMONContractList(IEnumerable<FPContract> postedData)
        {
            var fpContract = _fpContract.PostFPMONContractList(postedData.ToList());
            return Ok("success");
        }
        #endregion

        #region "FP Track List"
        [HttpGet]
        [Route("GetFPContractTrackList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContract>>> GetFPContractTrackList([FromQuery] string selectedFilter, [FromQuery] string selectedActiveFilter)
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPContractTrackList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0, selectedFilter, selectedActiveFilter);

            return fpContract;
        }
        [HttpGet]
        [Route("GetFPContractMonthlyTrackList")]
        [Authorize(Roles = "IT Finance Manager,Admin")]
        public async Task<ActionResult<IEnumerable<FPContract>>> GetFPContractMonthlyTrackList([FromQuery] string selectedFilter, [FromQuery] string selectedActiveFilter)
        {
            //Get pending list for Finance Manager- Procurtment
            var fpContract = _fpContract.GetFPContractMonthlyTrackList(Constants.ProcurementWFOrder.FinanceManager, SessionManager.CurrentUser.Location_ID ?? 0, selectedFilter, selectedActiveFilter);

            return fpContract;
        }
        #endregion

        #region Bulk update used API

        [HttpGet]
        [Route("GetSowListByContractType")]
        [Authorize(Roles = "IT Finance Manager")]
        public ActionResult<IEnumerable<SP_EMS_FetchSowNumberByContractTypeResult>> GetSowListByContractType([FromQuery] string ContractType, [FromQuery] string SearchSowText)
        {
            try
            {
                var result = _tmContract.GetSowListByContractType(ContractType, SearchSowText);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetAllSowListByContractType")]
        [Authorize(Roles = "IT Finance Manager")]
        public ActionResult<IEnumerable<SP_EMS_FetchContractListBySOW_NoResult>> GetAllSowListByContractType([FromQuery] string ContractType, [FromQuery] string sowNo)
        {
            try
            {
                var result = _tmContract.GetAllSowListByContractType(ContractType, sowNo);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetOldValueByContractSowType")]
        [Authorize(Roles = "IT Finance Manager")]
        public ActionResult<IEnumerable<SP_EMS_FetchColumnValueByTblAndSowNumberResult>> GetOldValueByContractSowType([FromQuery] string ContractType, [FromQuery] string sowNumber, [FromQuery] string fieldType)
        {
            try
            {
                var result = _tmContract.GetContractValueByContractSowType(ContractType, sowNumber, fieldType);
                if (IsDateFieldType(fieldType))
                {
                    var distinctResults = result
                        .Select(item =>
                        {
                            if (DateTime.TryParse(item.FieldValue, out DateTime date))
                            {
                                // Normalize date to 00:00 time
                                item.FieldValue = date.ToString("yyyy-MM-dd 00:00:00");
                            }
                            return item;
                        })
                        .GroupBy(item => item.FieldValue)
                        .Select(group => group.First())
                        .ToList();
                    return Ok(distinctResults);
                }
                else
                {
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpGet]
        [Route("GetValidationStatusForColumn")]
        [Authorize(Roles = "IT Finance Manager")]
        public ActionResult<IEnumerable<SP_EMS_ValidateColumnBySowNumberResult>> GetValidationStatusForColumn([FromQuery] string ContractType, [FromQuery] string sowNumber, [FromQuery] string fieldType, [FromQuery] string newValue)
        {
            try
            {
                var result = _tmContract.GetColumnValidationStatusBySowNumber(ContractType, sowNumber, fieldType, newValue);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("UpdateContractColumnBySowNumber")]
        [Authorize(Roles = "IT Finance Manager")]
        public IActionResult UpdateContractColumnBySowNumber(BulkUpdateBySow bulk)
        {
            try
            {
                string mid = SessionManager.CurrentUser.MID;
                var result = _tmContract.UpdateContractColumnBySowNumber(bulk.ContractType, bulk.SOWNumber, bulk.FieldType, bulk.oldValue, bulk.newValue, mid);
                return Ok(new { Message = "Contract column updated successfully.", AffectedRows = result });
            }
            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);
            }

        }

        private bool IsDateFieldType(string fieldType)
        {
            var dateFieldTypes = new[] { "SOWStartDate", "SOWEndDate", "POStartDate", "POEndDate" };
            return dateFieldTypes.Contains(fieldType);
        }

        #endregion
    }
}
