using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
using EMS.BAL.Interface;
using EMS.BAL.Services;
using EMS_API;
using EMS_BAL.Interface;
using EMS_BAL.Model;
using EMS_BAL.Services;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddEntityFrameworkSqlServer();
var sqlContSection = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("SQLConnectionStrings");
var ds = sqlContSection.GetValue<string>("dataSource");
var catalog = sqlContSection.GetValue<string>("Catalog");
var userId = sqlContSection.GetValue<string>("UserID");
var pwd = sqlContSection.GetValue<string>("Password");

builder.Services.AddDbContext<EMS_Context>(options =>
{

    options.UseSqlServer((@"data source=" + ds + ";Initial Catalog=" + catalog + ";User ID=" + userId + ";Password=" + pwd + ";application name=EntityFramework&quot;encrypt=false;TrustServerCertificate=true"),

    sqlServerOptionsAction: sqlOptions =>
    {
        sqlOptions.EnableRetryOnFailure();
    });
}, ServiceLifetime.Transient);

builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Employee Management System",
        Description = "EMS API"
    });
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Description = "Bearer Authentication with JWT Token",
        Type = SecuritySchemeType.Http
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference=new OpenApiReference
                {
                    Id="Bearer",
                    Type=ReferenceType.SecurityScheme
                }
            }, new List<string>()
        }
    });
});
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddScoped<IAuthenticateServices, AuthenticationServices>();
//builder.Services.AddSingleton<IAuthenticateServices, AuthenticationServices>();
//builder.Services.AddSingleton<IJwtHandler, JwtHandler>();

//builder.Services.AddSingleton<IPasswordHasher<Login>, PasswordHasher<Login>>();
//builder.Services.AddSingleton<IPasswordHasher<Login>, PasswordHasher<Login>>();

builder.Services.AddTransient<IJwtHandler, JwtHandler>();

builder.Services.AddTransient<IPasswordHasher<Login>, PasswordHasher<Login>>();
builder.Services.AddTransient<IPasswordHasher<Login>, PasswordHasher<Login>>();

builder.Services.AddTransient<TokenManagerMiddleware>();
builder.Services.AddTransient<ITokenManager, EMS_BAL.Services.TokenManager>();
builder.Services.AddTransient<GlobalExceptionHandler>();
//builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddScoped<ITMContract, TMContractServices>();
builder.Services.AddScoped<ITMContractRepository, TMContractRepository>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IMastersRepository, MastersRepository>();
builder.Services.AddScoped<IMastersService, MastersServices>();
builder.Services.AddScoped<IFPContract, FPContractServices>();
builder.Services.AddScoped<IFPContractRepository, FPContractRepository>();
builder.Services.AddScoped<IResourceOnboardingService, ResourceOnboardingService>();
builder.Services.AddScoped<IResourceMappingRepository, ResourceMappingRepository>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<IReportsRepository, ReportsRepository>();
builder.Services.AddScoped<IEmployeeMaster, EmployeeMasterService>();
builder.Services.AddScoped<IEmployeeMasterRepository, EmployeeMasterRepository>();
builder.Services.AddScoped<IErrorLog, ErrorLogService>();
builder.Services.AddScoped<IErrorLogRepository, ErrorLogRepository>();


builder.Services.AddMemoryCache();

builder.Services.AddDistributedMemoryCache(r => { });
var jwtSection = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("JWT");
//To get Mail configuration
var MailSettingsConfig = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("MailSettings");
var mailconfigurations = MailSettingsConfig.GetValue<string>("MailSettings:fromemail");

//var jwtSection = Configuration.GetSection("jwt");

var jwtOptions = new JwtOptions();
jwtSection.Bind(jwtOptions);

//// Testing required throwing some error---
//enabling windows authentication -- step 1
//add Windows authentication for http options request
//builder.Services.AddAuthentication(IISDefaults.AuthenticationScheme);
//builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();

//builder.Services.AddHttpContextAccessor();


builder.Services.AddAuthentication(opt =>
{
    opt.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    opt.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(cfg =>
{
    cfg.TokenValidationParameters = new TokenValidationParameters
    {
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtOptions.SecretKey)),
        ValidIssuer = jwtOptions.Issuer,
        ValidAudience = jwtOptions.Audience,
        ValidateAudience = false,
        ValidateLifetime = true
    };
});
builder.Services.Configure<JwtOptions>(jwtSection);

var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var corsList = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("validOriginForCors:CorsUrl");
var allowOrigin1 = corsList.Get<List<string>>().ToArray();
//string[] allowOrigin = { "http://localhost:4200", "https://localhost:4200", "https://localhost:4200/", "http://w0bsnowappq001", "https://w0bsnowappq001/", "https://w0bsnowappq001" };
builder.Services.AddCors(options =>
{
    options.AddPolicy(MyAllowSpecificOrigins,
                          policy =>
                          {
                              policy.WithOrigins(allowOrigin1)
                              .AllowAnyHeader()
                              .AllowAnyMethod()
                              .AllowCredentials();

                          });
    options.AddPolicy("AllowHeaders", builder =>
    {
        builder.WithOrigins(allowOrigin1)
                .WithHeaders(HeaderNames.ContentType, HeaderNames.Server, HeaderNames.AccessControlAllowHeaders, HeaderNames.AccessControlExposeHeaders, "x-custom-header", "x-path", "x-record-in-use", HeaderNames.ContentDisposition);
    });
});
//builder.Services.Configure<JsonOptions>(options =>
//{
//    options.JsonSerializerOptions.PropertyNamingPolicy = null;
//});

var app = builder.Build();
// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "EMS API");
});
app.UseDeveloperExceptionPage();
//}

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors(MyAllowSpecificOrigins);

app.UseAuthorization();
//step 2 for windows authentication
//app.UseAuthentication();
app.MapControllers();
app.UseAuthentication();
app.UseMiddleware<TokenManagerMiddleware>();
app.UseMiddleware<GlobalExceptionHandler>();
app.Run();
