﻿namespace EMS_API
{
    internal class ExceptionDetails
    {
        public ExceptionDetails()
        {
            
        }
        public int StatusCode { get; set; }
        public string Error { get; set; }
    }
}