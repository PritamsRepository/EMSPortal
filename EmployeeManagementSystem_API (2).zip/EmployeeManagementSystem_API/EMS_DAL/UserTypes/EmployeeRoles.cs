﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.UserTypes
{
    public class EmployeeRoles
    {
         
        public int? RoleTypeID { get; set; }
        public string RoleTypeName { get; set; }
        public string MID { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string LocationName { get; set; }
        public int? LocationID { get; set; }
        public bool? IsPrimary { get; set; }
        public bool? IsActive { get; set; }
    }
}
