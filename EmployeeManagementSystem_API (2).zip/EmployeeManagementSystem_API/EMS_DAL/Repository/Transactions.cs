﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Repository
{
    public class Transactions
    {
        private Transactions() { }

        public static void Run(DbContext dbContext, Func<IDbContextTransaction, bool> act)
        {
            if (dbContext != null && act != null)
            {
                var executionStrategy = dbContext.Database.CreateExecutionStrategy();

                executionStrategy.Execute(() => {

                    using var ret = dbContext.Database.BeginTransaction();
                    if (ret != null)
                    {

                        try
                        {
                            if (act.Invoke(ret))
                            {
                                ret.Commit();
                            }
                        }
                        catch (Exception e)
                        {
                            ret.Rollback();
                            throw new Exception("Error during transaction, rolling back");
                        }

                    }
                    else
                    {
                        throw new Exception("Error while starting transaction");
                    }

                });
            }
        }
    }
}
