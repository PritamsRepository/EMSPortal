﻿using EFCore.BulkExtensions;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.VisualBasic;
using NetTopologySuite.Geometries;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace EMS_DAL.Repository
{
    public class ResourceMappingRepository : IResourceMappingRepository
    {
        private readonly EMS_Context _dataContext;
        private readonly IMemoryCache _memoryCache;
        public ResourceMappingRepository(EMS_Context eMS_Context, IMemoryCache memoryCach)
        {
            _dataContext = eMS_Context;
        }
        public List<SP_EMS_GetResourceMappingPendingDetailsResult> GetResourceMappingPendingList(string UserName, int workflowOrder, int LocationId)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetResourceMappingPendingDetailsAsync(UserName, workflowOrder, LocationId).Result.ToList();
            return result;
        }
        public   bool AddTMContractResourceMappingIntermediate(List<EmsTblTmresourceMappingIntermediate> TmresourceMappingIntermediate, string MID,int locationID)
        {
            //var query = _dataContext.Set<EmsTblTmresourceMappingIntermediate>().Where(x => x.UploadedBy == "M561683");
            //int rowsAffected = query.BatchDelete();
            //_dataContext.SaveChanges();
            var itemsToDelete = _dataContext.EmsTblTmresourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationID).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblTmresourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            _dataContext.BulkInsert(TmresourceMappingIntermediate);
            _dataContext.SaveChanges();
            //_dataContext.GetProcedures().sp_EMS_TM_ResourceOnboardingValidationAsync();
            _dataContext.GetProcedures().sp_EMS_TM_ResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;

        }
        public List<SP_EMS_GetOnboardingApprovalPendingDetailsResult> GetTMOnboardingApprovalPendingList(string UserName, int workflowOrder)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetOnboardingApprovalPendingDetailsAsync(UserName, workflowOrder).Result.ToList();
            return result;
        }

        public bool UpdateResourceMasterstatus(string ETWID, string PosCode)
        {
            var data = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Etwid == ETWID).FirstOrDefault();
            if (data != null)
            {
                data.Status = "Closed";
                data.Wforder = 3;
            }
            _dataContext.SaveChanges();
            var result = _dataContext.EmsTblContractMasters.Where(x => x.PositionCode == PosCode).FirstOrDefault();
            if (result != null)
            {
                result.Status = "Closed";
            }
            _dataContext.SaveChanges();

            return true;

        }

        public bool AddTMDataToResourcemaster(List<EmsTblResourceMaster> tmResourceMasterData ,List<EmsTblTmvendorContractMaster> tmvendorContractMasters,List<EmsTblContractMaster> emsContractMasters, string MID,string Name, List<EmsTblTmcontractWorkFlow> contractWorkFlow,int locationId)
        {
            var resourePositionUpdate = new List<EmsTblResourceMaster>();
            var itemsToDelete = _dataContext.EmsTblTmresourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationId).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblTmresourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            if (tmResourceMasterData.Count > 0)
            { //IF remapped MID is not there
                _dataContext.BulkInsert(tmResourceMasterData);
                _dataContext.SaveChanges();
            }
            //Update Pendingwithwhom as null for all the position codes which are approved
            var pednigWithWhomeUpdate = (from v in tmvendorContractMasters
                                        join r in _dataContext.EmsTblTmvendorContractMasters on v.PositionCode equals r.PositionCode
                                        where (r.Status == "Open" ||r.Status=="Closed")
                                        select new EmsTblTmvendorContractMaster()
                                        {
                                            Tmvcmid = r.Tmvcmid,
                                            PendingWithWhom = null,
                                            Wforder = null
                                        });

            var propToupdatePenWidWhom = new List<string> { nameof(EmsTblTmvendorContractMaster.PendingWithWhom), nameof(EmsTblTmvendorContractMaster.Wforder) };
            var penWith = new BulkConfig { PropertiesToInclude = propToupdatePenWidWhom };
            _dataContext.BulkUpdate(pednigWithWhomeUpdate, penWith);
            _dataContext.SaveChanges();

            //Update Pendingwith and WFOrdr ans status and remappedmid for both remapped and normal scenario
            var propToInclude = new List<string> { nameof(EmsTblTmvendorContractMaster.Status), nameof(EmsTblTmvendorContractMaster.Wforder) ,nameof(EmsTblTmvendorContractMaster.RemappedMid),  nameof(EmsTblTmvendorContractMaster.PendingWithWhom) };
            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
            _dataContext.BulkUpdate(tmvendorContractMasters, bulkConfig);
            _dataContext.SaveChanges();

            var recs = tmvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "").ToList();

            if (recs != null)
            { 
                //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
                List <EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();

                ress = (from v in recs
                        select new EmsTblRemappedResourceWdExtension
                        {
                            EmpMid = v.RemappedMid,
                            EmpName = null,
                            PositionCode = v.PositionCode,
                            Sownumber = v.Sownumber,
                            DomainSkillEndDate = v.DomainSkillEndDate,
                            Ritm = null
                        }).ToList();

                ress.Join(
                    _dataContext.EmployeeMasters,
                    r => r.EmpMid,
                    e => e.EmpMid,
                    (r, e) => { r.EmpName = e.EmpName; return r; }
                ).ToList();

                _dataContext.BulkInsert(ress);
            }


            //Only for remapped requests.

            if (tmvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date<= DateTime.Now.Date).Any())
            {
                //update position code for remapped resource
                 resourePositionUpdate = (from v in tmvendorContractMasters
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             where v.Status == "Closed" &&( r.ResourceStatus == "Active" ||r.ResourceStatus=="Resigned")
                                             &&  v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.PositionCode,
                                                 ViatrisMid = r.ViatrisMid

                                             }).ToList();



                if (resourePositionUpdate.Any())
                {
                    var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                    var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                    _dataContext.BulkUpdate(resourePositionUpdate, Position);
                    _dataContext.SaveChanges();
                }
                 
                //•	make the previous record with same mid in EmsTblTmvendorContractMasters IsActive = fasle
                var Vendorcontractupdate = (from v in tmvendorContractMasters
                                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                            join vmcon in _dataContext.EmsTblTmvendorContractMasters on m.Cmid equals vmcon.Tmcmid
                                            where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && v.RemappedMid != null && v.RemappedMid != ""
                                            select new EmsTblTmvendorContractMaster()
                                            {
                                                IsActive = false,
                                                Tmvcmid = vmcon.Tmvcmid,

                                            }).ToList().DistinctBy(x => x.Tmvcmid);

                if (Vendorcontractupdate.Any())
                {
                    var propVendorcontractupdate = new List<string> { nameof(EmsTblTmvendorContractMaster.IsActive) };
                    var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                    _dataContext.BulkUpdate(Vendorcontractupdate, activation);
                    _dataContext.SaveChanges();
                }

                //•	Make the previous record in EmsTblTmcontractResourceMapping IsMappingActive = fasle for same rmid
                var contractResourceupdate = (from v in tmvendorContractMasters
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                              join vmcon in _dataContext.EmsTblTmvendorContractMasters on m.Cmid equals vmcon.Tmcmid
                                              where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                               && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblTmcontractResourceMapping()
                                              {
                                                  Cmid = m.Cmid,
                                                  IsMappingActive = false,
                                                  TmcrmapId = m.TmcrmapId,
                                                  UnMappedDate=DateTime.Now,
                                                  UnMappedBy=MID
                                              }).ToList().DistinctBy(x=>x.TmcrmapId);

                if (contractResourceupdate.Any())
                {
                    var propToIncludeResource = new List<string> { nameof(EmsTblTmcontractResourceMapping.IsMappingActive), nameof(EmsTblTmcontractResourceMapping.UnMappedDate), nameof(EmsTblTmcontractResourceMapping.UnMappedBy) };
                    var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
                    _dataContext.BulkUpdate(contractResourceupdate, Resource);
                    _dataContext.SaveChanges();
                }

                //inser record into contract resource mapping
                var contractResourceInsert = (from v in tmvendorContractMasters
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              where v.Status == "Closed" && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblTmcontractResourceMapping()
                                              {
                                                  Cmid = v.Tmcmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = MID, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              });
                _dataContext.BulkInsert(contractResourceInsert);
                _dataContext.SaveChanges();

                ////•	make the previous record with same mid in EmsTblTmvendorContractMasters IsActive = fasle

                //var Vendorcontractupdate = (from v in tmvendorContractMasters
                //                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                //                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                //                            join vmcon in _dataContext.EmsTblTmvendorContractMasters on m.Cmid equals vmcon.Tmcmid
                //                            where v.Status == "Closed" && m.IsMappingActive == true && r.ResourceStatus == "Active"
                //                             && v.RemappedMid != null && v.RemappedMid != ""
                //                            select new EmsTblTmvendorContractMaster()
                //                            {
                //                                IsActive = false,
                //                                Tmvcmid = vmcon.Tmvcmid,

                //                            });
                //var propVendorcontractupdate = new List<string> { nameof(EmsTblTmvendorContractMaster.IsActive) };
                //var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                //_dataContext.BulkUpdate(Vendorcontractupdate, activation);
                //_dataContext.SaveChanges();

            }

            //Mapped date  should be date of joining for the invoices later on.
            var result = (
            from rm in _dataContext.EmsTblResourceMasters
            join vcm in _dataContext.EmsTblTmvendorContractMasters on rm.PositionCode equals vcm.PositionCode
            where vcm.IsActive == true && rm.VendorId == vcm.VendorId && (vcm.RemappedMid == null || vcm.RemappedMid == "") && (!_dataContext.EmsTblTmcontractResourceMappings.Any(sm => sm.Rmid == rm.Rmid))
            select new EmsTblTmcontractResourceMapping()
            {
                Cmid = vcm.Tmcmid,
                Rmid = rm.Rmid,
                IsMappingActive = true,
                MappedBy = MID,
                MappedDate = rm.Dojviatris
            }
            );
            _dataContext.BulkInsert(result);
            _dataContext.SaveChanges();
            

            //update tblcontractmaster for both remapped and normal scenarios
            var dataToInclude = new List<string> { nameof(EmsTblContractMaster.Status)};
            var bulkdata= new BulkConfig { PropertiesToInclude = dataToInclude };
            _dataContext.BulkUpdate(emsContractMasters, bulkdata);
            _dataContext.SaveChanges();

            //insert work flow for both remapped and normal scenario
            _dataContext.BulkInsert(contractWorkFlow);
            _dataContext.SaveChanges();

            if (resourePositionUpdate.Any())
            {
                //var mappedResource = (from r in resourePositionUpdate
                //                      join rl  in _dataContext.EmsTblResourceMasters on r.Rmid equals rl.Rmid
                //                      join tcm in _dataContext.EmsTblTmvendorContractMasters on rl.PositionCode equals  tcm.PositionCode
                //                      where tcm.RemappedMid == r.ViatrisMid
                //                      select new EmsTblTmvendorContractMaster()
                //                      {
                //                          Tmvcmid = tcm.Tmvcmid,
                //                          RemappedMid = null
                //                      }).ToList().DistinctBy(x => x.tmvcmid);

                var mappedResource = (from r in resourePositionUpdate
                                      join tcm  in tmvendorContractMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.PositionCode, mid = tcm.RemappedMid }
                                      select new EmsTblTmvendorContractMaster()
                                      {
                                          Tmvcmid = tcm.Tmvcmid,
                                          RemappedMid = null
                                      }).ToList().DistinctBy(x => x.Tmvcmid);

                if (mappedResource.Any())
                {
                    var propToInclude2 = new List<string> { nameof(EmsTblTmvendorContractMaster.RemappedMid) };
                    var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };
                    _dataContext.BulkUpdate(mappedResource, bulkConfig1);
                }
            }

            //Update position closed date for all the position codes which are approved
            var PositionTrackUpdate = (from v in tmvendorContractMasters
                                         join r in _dataContext.EmsTblPositionTrackings on v.PositionCode equals r.PositionCode 
                                         where r.PositionCloseDate==null
                                         select new EmsTblPositionTracking()
                                         {
                                             Ptid = r.Ptid,
                                             PositionCloseDate = v.RemappedMid != null && v.RemappedMid != "" && v.SowstartDate.Value.Date <= DateTime.Now.Date ? v.SowstartDate : v.RemappedMid != null && v.RemappedMid != "" && v.SowstartDate.Value.Date > DateTime.Now.Date ? null : (v.RemappedMid == null || v.RemappedMid == "") ? DateTime.Now : null,
                                             PositionFilledWithMid = v.RemappedMid != null && v.RemappedMid != "" && v.SowstartDate.Value.Date <= DateTime.Now.Date ? v.RemappedMid : v.RemappedMid != null && v.RemappedMid != "" && v.SowstartDate.Value.Date > DateTime.Now.Date ? null: (v.RemappedMid == null || v.RemappedMid == "") ? null : null,
                                         });

            var propToupdateclosedate = new List<string> { nameof(EmsTblPositionTracking.PositionCloseDate), nameof(EmsTblPositionTracking.PositionFilledWithMid) };
            var closing = new BulkConfig { PropertiesToInclude = propToupdateclosedate };
            _dataContext.BulkUpdate(PositionTrackUpdate, closing);
            _dataContext.SaveChanges();

            var updateAMS = tmvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date <= DateTime.Now.Date).ToList();
            if (updateAMS.Count>0)
            {
                foreach (var m in updateAMS)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("T&M", "Update", m.RemappedMid).Wait();
                  
                }
            }

            return true;

        }
        public bool AddTMRejectedResourceDataWorkflow( string MID, string Name, List<EmsTblTmcontractWorkFlow> contractWorkFlow,int locationId)
        {
            _dataContext.BulkInsert(contractWorkFlow);
            _dataContext.SaveChanges();

            var itemsToDelete = _dataContext.EmsTblTmresourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationId).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblTmresourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            return true;
        }

        public List<SP_EMS_GetResourceMappingTrackDetailsResult> GetResourceMappingTrackDetails(string UseName,int workflowOrder ,int locationID ,string  Filter,string ActiveFilter,DateTime FromDate , DateTime Todate)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetResourceMappingTrackDetailsAsync( UseName,  workflowOrder,  locationID,   Filter, ActiveFilter, FromDate,  Todate).Result.ToList();
           
            return result;
        }
        
         public List<EmsTblTmcontractWorkFlow> GetTMResourceWorkFlow(int tmvcmid)
        {
            var result = _dataContext.EmsTblTmcontractWorkFlows.Where(x => x.Tmcid == tmvcmid).ToList();
            return result;
        }
        
         public List<SP_EMS_GetTMresourceMIDPendingReqResult> GetResourceMIDcreationPendingList(string UseName, int locationID)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetTMresourceMIDPendingReqAsync(UseName,locationID).Result.ToList();
            return result;
        }
        public string  SaveResourceAssetDetails(string MID,string Email,int Rmid,int Cmid,string loggedInMID, string LoggedinName)
        {
            var dataexist = _dataContext.EmsTblResourceMasters.Where(x => (x.ViatrisMid.ToLower() == MID.ToLower() || x.ViatrisEmailId == Email) && x.ResourceStatus == "Active").FirstOrDefault();
            if (dataexist == null)
            {
                var data = _dataContext.EmsTblResourceMasters.Where(x => x.Rmid == Rmid).FirstOrDefault();
                if (data != null)
                {
                    data.ViatrisMid = MID;
                    data.ViatrisEmailId = Email;
                    _dataContext.SaveChanges();
                }
                var workflow = new EmsTblTmcontractWorkFlow()
                {
                    Tmcid = Cmid,
                    Role = "PMO-Admin",
                    ActionByMid = loggedInMID,
                    ActionByName = LoggedinName,
                    ActionDate = DateTime.Now,
                    //Action = "Forwarded for Asset Allocation",
                    //Remarks = "successfull",
                    //NextWfrole = "Local IT"
                    Action = "Credentials Updated",
                    Remarks = "successfull",
                    NextWfrole = null,
                };
                _dataContext.EmsTblTmcontractWorkFlows.Add(workflow);
                _dataContext.SaveChanges();
                var result = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Tmvcmid == Cmid).FirstOrDefault();
                if (result != null)
                {
                    result.Wforder = null;
                    result.Status = "Closed";
                    _dataContext.SaveChanges();
                }

                var position = _dataContext.EmsTblPositionTrackings.Where(x => x.PositionCode == data.PositionCode && x.PositionCloseDate != null && x.PositionFilledWithMid == null).FirstOrDefault();
                if (position != null)
                {
                    position.PositionFilledWithMid = MID;
                    _dataContext.SaveChanges();
                }
                _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("T&M", "Insert", MID).Wait();
                _dataContext.SaveChanges();

                return null;

            }
            else
            {
                return "Note : MID/Email ID already exist, Please provide correct MID/Email ID.";
            }
            
        }
        
         public List<SP_EMS_GetResourceMappingMilestonePendingDetailsResult> GetResourceMappingMilestonePendingList(string UserName, int workflowOrder, int LocationId)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetResourceMappingMilestonePendingDetailsAsync(UserName, workflowOrder, LocationId).Result.ToList();
            return result;
        }

        public bool AddFPmilestoneDataToResourcemaster(List<EmsTblResourceMaster> fpResourceMasterData, List<EmsTblFbvendorContractMilestoneMaster> fpvendorContractMasters, List<EmsTblContractMaster> emsContractMasters, string MID, string Name, List<EmsTblFpcontractWorkFlowMilestone> contractWorkFlow, int locationID)
        {
            var resourePositionUpdate = new List<EmsTblResourceMaster>();
            var itemsToDelete = _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationID).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            if (fpResourceMasterData.Count > 0)
            {
                _dataContext.BulkInsert(fpResourceMasterData);
                _dataContext.SaveChanges();
            }
            //Update Pendingwithwhom as null for all the position codes which are approved
            var pednigWithWhomeUpdate = (from v in fpvendorContractMasters
                                         join r in _dataContext.EmsTblFbvendorContractMilestoneMasters on v.Etwid equals r.Etwid
                                         where (r.Status == "Open" || r.Status == "Closed")
                                         select new EmsTblFbvendorContractMilestoneMaster()
                                         {
                                             FbcmilestoneMasterId = r.FbcmilestoneMasterId,
                                             PendingWithWhom = null,
                                             Wforder = null
                                         });

            var propToupdatePenWidWhom = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.PendingWithWhom), nameof(EmsTblFbvendorContractMilestoneMaster.Wforder) };
            var penWith = new BulkConfig { PropertiesToInclude = propToupdatePenWidWhom };
            _dataContext.BulkUpdate(pednigWithWhomeUpdate, penWith);
            _dataContext.SaveChanges();



            //Update Pendingwith and WFOrdr for both remapped and normal scenario
            var propToInclude = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.Status), nameof(EmsTblFbvendorContractMilestoneMaster.Wforder) , nameof(EmsTblFbvendorContractMilestoneMaster.RemappedMid), nameof(EmsTblFbvendorContractMilestoneMaster.PendingWithWhom) };
                var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
                _dataContext.BulkUpdate(fpvendorContractMasters, bulkConfig);
                _dataContext.SaveChanges();



            var recs = fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "").ToList();

            if (recs != null)
            {
                //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
                List<EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();

                ress = (from v in recs
                        select new EmsTblRemappedResourceWdExtension
                        {
                            EmpMid = v.RemappedMid,
                            EmpName = null,
                            PositionCode = v.Etwid,
                            Sownumber = v.Sownumber,
                            DomainSkillEndDate = v.DomainSkillEndDate,
                            Ritm = null
                        }).ToList();

                ress.Join(
                    _dataContext.EmployeeMasters,
                    r => r.EmpMid,
                    e => e.EmpMid,
                    (r, e) => { r.EmpName = e.EmpName; return r; }
                ).ToList();

                _dataContext.BulkInsert(ress);
            }


            //Only for remapped requests.
            if (fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date <= DateTime.Now.Date).Any())
                {
                    //update position code for remapped resource
                     resourePositionUpdate = (from v in fpvendorContractMasters
                                                 join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                                 where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                                 && v.RemappedMid != null && v.RemappedMid != ""
                                                 select new EmsTblResourceMaster()
                                                 {
                                                     Rmid = r.Rmid,
                                                     PositionCode = v.Etwid,
                                                     ViatrisMid=r.ViatrisMid

                                                 }).ToList();
                    if (resourePositionUpdate.Any())
                    {
                        var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                        var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                        _dataContext.BulkUpdate(resourePositionUpdate, Position);
                        _dataContext.SaveChanges();
                    }

                //•	make the previous record with same mid in EmsTblFbvendorContractMilestoneMasters IsActive = fasle

                var Vendorcontractupdate = (from v in fpvendorContractMasters
                                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                            join vmcon in _dataContext.EmsTblFbvendorContractMilestoneMasters on m.Cmid equals vmcon.Cmid
                                            where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && v.RemappedMid != null && v.RemappedMid != ""
                                            select new EmsTblFbvendorContractMilestoneMaster()
                                            {
                                                IsActive = false,
                                                FbcmilestoneMasterId = vmcon.FbcmilestoneMasterId,

                                            }).ToList().DistinctBy(x => x.FbcmilestoneMasterId);
                    if (Vendorcontractupdate.Any())
                    {
                        var propVendorcontractupdate = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.IsActive) };
                        var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                        _dataContext.BulkUpdate(Vendorcontractupdate, activation);
                        _dataContext.SaveChanges();
                    }


                //•	Make the previous record in EmsTblTmcontractResourceMapping IsMappingActive = fasle for same rmid

                var contractResourceupdate = (from v in fpvendorContractMasters
                                                  join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                                  join m in _dataContext.EmsTblFpcontractResourceMappings on r.Rmid equals m.Rmid
                                                  join vmcon in _dataContext.EmsTblFbvendorContractMilestoneMasters on m.Cmid equals vmcon.Cmid
                                                  where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                                   && v.RemappedMid != null && v.RemappedMid != ""
                                                  select new EmsTblFpcontractResourceMapping()
                                                  {
                                                      Cmid = m.Cmid,
                                                      IsMappingActive = false,
                                                      FpcrmapId = m.FpcrmapId,
                                                      UnMappedDate = DateTime.Now,
                                                      UnMappedBy = MID
                                                  }).ToList().DistinctBy(x => x.FpcrmapId);
                    if (contractResourceupdate.Any())
                    {

                        var propToIncludeResource = new List<string> { nameof(EmsTblFpcontractResourceMapping.IsMappingActive) };
                        var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
                        _dataContext.BulkUpdate(contractResourceupdate, Resource);
                        _dataContext.SaveChanges();
                    }




                    //inser record into contract resource mapping
                    var contractResourceInsert = (from v in fpvendorContractMasters
                                                  join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                                  where v.Status == "Closed" && v.RemappedMid != null && v.RemappedMid != ""
                                                  select new EmsTblFpcontractResourceMapping()
                                                  {
                                                      Cmid = v.Cmid,
                                                      IsMappingActive = true,
                                                      Rmid = r.Rmid,
                                                      MappedBy = MID, //Taking lgged in MID
                                                      MappedDate = DateAndTime.Now,
                                                      IsAmsupdated = true
                                                  });
                    _dataContext.BulkInsert(contractResourceInsert);
                    _dataContext.SaveChanges();



                    ////•	make the previous record with same mid in EmsTblFbvendorContractMilestoneMasters IsActive = fasle

                    //var Vendorcontractupdate = (from v in fpvendorContractMasters
                    //                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                    //                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                    //                            join vmcon in _dataContext.EmsTblFbvendorContractMilestoneMasters on m.Cmid equals vmcon.Cmid
                    //                            where v.Status == "Closed" && m.IsMappingActive == true && r.ResourceStatus == "Active"
                    //                             && v.RemappedMid != null && v.RemappedMid != ""
                    //                            select new EmsTblFbvendorContractMilestoneMaster()
                    //                            {
                    //                                IsActive = false,
                    //                                FbcmilestoneMasterId = vmcon.FbcmilestoneMasterId,

                    //                            });
                    //var propVendorcontractupdate = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.IsActive) };
                    //var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                    //_dataContext.BulkUpdate(Vendorcontractupdate, activation);
                    //_dataContext.SaveChanges();

                }

            //Mapped date  should be date of joining for the invoices later on.
             var result = (
                  from rm in _dataContext.EmsTblResourceMasters
                  join vcm in _dataContext.EmsTblFbvendorContractMilestoneMasters on rm.PositionCode equals vcm.Etwid
                  where vcm.IsActive == true && rm.VendorId == vcm.VendorId && (vcm.RemappedMid == null || vcm.RemappedMid == "") && (!_dataContext.EmsTblFpcontractResourceMappings.Any(sm => sm.Rmid == rm.Rmid))
                  select new EmsTblFpcontractResourceMapping()
                  {
                      Cmid = vcm.Cmid,
                      Rmid = rm.Rmid,
                      IsMappingActive = true,
                      MappedBy = MID,
                      MappedDate = rm.Dojviatris
                  }
                 );

                _dataContext.BulkInsert(result);
                _dataContext.SaveChanges();


                //update tblcontractmaster for both remapped and normal scenarios
                var dataToInclude = new List<string> { nameof(EmsTblContractMaster.Status) };
                var bulkdata = new BulkConfig { PropertiesToInclude = dataToInclude };
                _dataContext.BulkUpdate(emsContractMasters, bulkdata);
                _dataContext.SaveChanges();
                //return true;

                //insert work flow for both remapped and normal scenario
                _dataContext.BulkInsert(contractWorkFlow);
                _dataContext.SaveChanges();

            //To make Remapped MID null after mapping done.
            if (resourePositionUpdate.Any())
            {
                var mappedResource = (from r in resourePositionUpdate
                                      join tcm in _dataContext.EmsTblFbvendorContractMilestoneMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.Etwid, mid = tcm.RemappedMid }
                                      select new EmsTblFbvendorContractMilestoneMaster()
                                      {
                                          FbcmilestoneMasterId = tcm.FbcmilestoneMasterId,
                                          RemappedMid = null
                                      });

                if (mappedResource.Any())
                {
                    var propToInclude2 = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.RemappedMid) };
                    var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };
                    _dataContext.BulkUpdate(mappedResource, bulkConfig1);
                }
            }

            var updateAMS = fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date <= DateTime.Now.Date).ToList();
            if (updateAMS.Count >0)
            {
                foreach (var m in updateAMS)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMilestone", "Update", m.RemappedMid).Wait();
                    _dataContext.SaveChanges();
                }
            }

            return true;

            
        }
        public bool AddFPContractMSResourceMappingIntr(List<EmsTblFpmileStoneResourceMappingIntermediate > FPresourceMappingIntermediate, string MID, int locationID)
        {
            //var query = _dataContext.Set<EmsTblTmresourceMappingIntermediate>().Where(x => x.UploadedBy == "M561683");
            //int rowsAffected = query.BatchDelete();
            //_dataContext.SaveChanges();
            var itemsToDelete = _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationID).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            _dataContext.BulkInsert(FPresourceMappingIntermediate);
            _dataContext.SaveChanges();
            _dataContext.GetProcedures().sp_EMS_FP_MilestoneResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;

        }

        
         public List<SP_EMS_GetResourceMappingMonthlyPendingDetailsResult > GetResourceMappingMonthlyPendingList(string UserName, int workflowOrder, int LocationId)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetResourceMappingMonthlyPendingDetailsAsync(UserName, workflowOrder, LocationId).Result.ToList();
            return result;
        }

        public bool AddFPmonthlyDataToResourcemaster(List<EmsTblResourceMaster> fpResourceMasterData, List<EmsTblFbvendorContractMonthlyMaster> fpvendorContractMasters, List<EmsTblContractMaster> emsContractMasters, string MID, string Name, List<EmsTblFpcontractWorkFlowMonthly> contractWorkFlow,int locationID)
        {
            var resourePositionUpdate = new List<EmsTblResourceMaster>();
            var itemsToDelete = _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationID).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            if (fpResourceMasterData.Count > 0)
            {
                _dataContext.BulkInsert(fpResourceMasterData);
                _dataContext.SaveChanges();
            }
            //Update Pendingwithwhom as null for all the position codes which are approved
            var pednigWithWhomeUpdate = (from v in fpvendorContractMasters
                                         join r in _dataContext.EmsTblFbvendorContractMonthlyMasters on v.Etwid equals r.Etwid
                                         where (r.Status == "Open" || r.Status == "Closed") 
                                         select new EmsTblFbvendorContractMonthlyMaster()
                                         {
                                             FbcmontlyId = r.FbcmontlyId,
                                             PendingWithWhom = null,
                                             Wforder = null
                                         });
           

            var propToupdatePenWidWhom = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.PendingWithWhom),nameof(EmsTblFbvendorContractMonthlyMaster.Wforder) };
            var penWith = new BulkConfig { PropertiesToInclude = propToupdatePenWidWhom };
            _dataContext.BulkUpdate(pednigWithWhomeUpdate, penWith);
            _dataContext.SaveChanges();

            //Update Pendingwith and WFOrdr for both remapped and normal scenario
            var propToInclude = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.Status), nameof(EmsTblFbvendorContractMonthlyMaster.Wforder), nameof(EmsTblFbvendorContractMonthlyMaster.RemappedMid), nameof(EmsTblFbvendorContractMonthlyMaster.PendingWithWhom) };
            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
            _dataContext.BulkUpdate(fpvendorContractMasters, bulkConfig);
            _dataContext.SaveChanges();

            var recs = fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "").ToList();

            if (recs != null)
            {
                //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
                List<EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();

                ress = (from v in recs
                        select new EmsTblRemappedResourceWdExtension
                        {
                            EmpMid = v.RemappedMid,
                            EmpName = null,
                            PositionCode = v.Etwid,
                            Sownumber = v.Sownumber,
                            DomainSkillEndDate = v.DomainSkillEndDate,
                            Ritm = null
                        }).ToList();

                ress.Join(
                    _dataContext.EmployeeMasters,
                    r => r.EmpMid,
                    e => e.EmpMid,
                    (r, e) => { r.EmpName = e.EmpName; return r; }
                ).ToList();

                _dataContext.BulkInsert(ress);
            }


            //Only for remapped requests.
            if (fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date <= DateTime.Now.Date).Any())
            {
                //update position code for remapped resource
                 resourePositionUpdate = (from v in fpvendorContractMasters
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.Etwid,
                                                 ViatrisMid=r.ViatrisMid

                                             }).ToList();
                if (resourePositionUpdate.Any())
                {
                    var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                    var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                    _dataContext.BulkUpdate(resourePositionUpdate, Position);
                    _dataContext.SaveChanges();
                }

                //•	make the previous record with same mid in EmsTblFbvendorContractMonthlyMaster IsActive = fasle

                var Vendorcontractupdate = (from v in fpvendorContractMasters
                                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                            join vmcon in _dataContext.EmsTblFbvendorContractMonthlyMasters on m.Cmid equals vmcon.Cmid
                                            where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && v.RemappedMid != null && v.RemappedMid != ""
                                            select new EmsTblFbvendorContractMonthlyMaster()
                                            {
                                                IsActive = false,
                                                FbcmontlyId = vmcon.FbcmontlyId,

                                            }).ToList().DistinctBy(x => x.FbcmontlyId);
                if (Vendorcontractupdate.Any())
                {
                    var propVendorcontractupdate = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.IsActive) };
                    var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                    _dataContext.BulkUpdate(Vendorcontractupdate, activation);
                    _dataContext.SaveChanges();
                }


                //•	Make the previous record in EmsTblTmcontractResourceMapping IsMappingActive = fasle for same rmid

                var contractResourceupdate = (from v in fpvendorContractMasters
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join m in _dataContext.EmsTblFpcontractResourceMappings on r.Rmid equals m.Rmid
                                              join vmcon in _dataContext.EmsTblFbvendorContractMonthlyMasters on m.Cmid equals vmcon.Cmid
                                              where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                               && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblFpcontractResourceMapping()
                                              {
                                                  Cmid = m.Cmid,
                                                  IsMappingActive = false,
                                                  FpcrmapId = m.FpcrmapId,
                                                  UnMappedDate = DateTime.Now,
                                                  UnMappedBy = MID
                                              }).ToList().DistinctBy(x => x.FpcrmapId);
                if (contractResourceupdate.Any())
                {
                    var propToIncludeResource = new List<string> { nameof(EmsTblFpcontractResourceMapping.IsMappingActive) };
                    var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
                    _dataContext.BulkUpdate(contractResourceupdate, Resource);
                    _dataContext.SaveChanges();
                }
                //inser record into contract resource mapping
                var contractResourceInsert = (from v in fpvendorContractMasters
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              where v.Status == "Closed" && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblFpcontractResourceMapping()
                                              {
                                                  Cmid = v.Cmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = MID, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              });
                _dataContext.BulkInsert(contractResourceInsert);
                _dataContext.SaveChanges();



                ////•	make the previous record with same mid in EmsTblFbvendorContractMonthlyMaster IsActive = fasle

                //var Vendorcontractupdate = (from v in fpvendorContractMasters
                //                            join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                //                            join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                //                            join vmcon in _dataContext.EmsTblFbvendorContractMonthlyMasters on m.Cmid equals vmcon.Cmid
                //                            where v.Status == "Closed" && m.IsMappingActive == true && r.ResourceStatus == "Active"
                //                             && v.RemappedMid != null && v.RemappedMid != ""
                //                            select new EmsTblFbvendorContractMonthlyMaster()
                //                            {
                //                                IsActive = false,
                //                                FbcmontlyId = vmcon.FbcmontlyId,

                //                            });
                //var propVendorcontractupdate = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.IsActive) };
                //var activation = new BulkConfig { PropertiesToInclude = propVendorcontractupdate };
                //_dataContext.BulkUpdate(Vendorcontractupdate, activation);
                //_dataContext.SaveChanges();

            }


            //Mapped date  should be date of joining for the invoices later on.
            var result = (
             from rm in _dataContext.EmsTblResourceMasters
             join vcm in _dataContext.EmsTblFbvendorContractMonthlyMasters on rm.PositionCode equals vcm.Etwid
             where vcm.IsActive == true && rm.VendorId == vcm.VendorId && (vcm.RemappedMid == null || vcm.RemappedMid == "") && (!_dataContext.EmsTblFpcontractResourceMappings.Any(sm => sm.Rmid == rm.Rmid))
             select new EmsTblFpcontractResourceMapping()
             {
                 Cmid = vcm.Cmid,
                 Rmid = rm.Rmid,
                 IsMappingActive = true,
                 MappedBy = MID,
                 MappedDate = rm.Dojviatris
             }
            );

            _dataContext.BulkInsert(result);
            _dataContext.SaveChanges();


            //update tblcontractmaster for both remapped and normal scenarios
            var dataToInclude = new List<string> { nameof(EmsTblContractMaster.Status) };
            var bulkdata = new BulkConfig { PropertiesToInclude = dataToInclude };
            _dataContext.BulkUpdate(emsContractMasters, bulkdata);
            _dataContext.SaveChanges();
     

            //insert work flow for both remapped and normal scenario
            _dataContext.BulkInsert(contractWorkFlow);
            _dataContext.SaveChanges();

            //To make Remapped MID null after mapping done.
            if (resourePositionUpdate.Any())
            {
                var mappedResource = (from r in resourePositionUpdate
                                      join tcm in _dataContext.EmsTblFbvendorContractMonthlyMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.Etwid, mid = tcm.RemappedMid }
                                      select new EmsTblFbvendorContractMonthlyMaster()
                                      {
                                          FbcmontlyId = tcm.FbcmontlyId,
                                          RemappedMid = null
                                      });

                if (mappedResource.Any())
                {
                    var propToInclude2 = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.RemappedMid) };
                    var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };
                    _dataContext.BulkUpdate(mappedResource, bulkConfig1);
                }
            }

            var updateAMS = fpvendorContractMasters.Where(x => x.RemappedMid != null && x.RemappedMid != "" && x.SowstartDate.Value.Date <= DateTime.Now.Date).ToList();
            if (updateAMS.Count >0)
            {
                foreach (var m in updateAMS)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMonthly", "Update", m.RemappedMid).Wait();
                    _dataContext.SaveChanges();
                }
            }

            return true;

        }
        public bool AddFPContractMLYResourceMappingIntr(List<EmsTblFpmonthlyResourceMappingIntermediate > FPresourceMappingIntermediate, string MID, int locationID)
        {
            //var query = _dataContext.Set<EmsTblTmresourceMappingIntermediate>().Where(x => x.UploadedBy == "M561683");
            //int rowsAffected = query.BatchDelete();
            //_dataContext.SaveChanges();
            var itemsToDelete = _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationID).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            _dataContext.BulkInsert(FPresourceMappingIntermediate);
            _dataContext.SaveChanges();
            _dataContext.GetProcedures().sp_EMS_FP_MonthlyResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;

        }

        public List<EmsTblFpcontractWorkFlowMonthly> GetFPmonthlyResourceWorkFlow(int fbcIntID)
        {
            var result = _dataContext.EmsTblFpcontractWorkFlowMonthlies.Where(x => x.Cmid == fbcIntID).ToList();
            return result;
        }
        
        public List<EmsTblFpcontractWorkFlowMilestone> GetFPmilestoneResourceWorkFlow(int fbcIntID)
        {
            var result = _dataContext.EmsTblFpcontractWorkFlowMilestones.Where(x => x.Cmid == fbcIntID).ToList();
            return result;
        }
        
         public List<SP_EMS_GetMiletoneDetailsBySowNumResult> GetMilestoneDetailsBySowNum(string SowNumber)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetMiletoneDetailsBySowNumAsync(SowNumber).Result.ToList();
            return result;
        }
        public List<SP_EMS_GetMonthlyDetailsBySowNumResult> GetMonthlyDetailsBySowNum(string SowNumber)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetMonthlyDetailsBySowNumAsync(SowNumber).Result.ToList();
            return result;
        }
        public List<SP_EMS_GetFPmilestoneResourceMIDPendingReqResult> GetMilestoneMIDcreationPendingList(string UserName,int workfloworder,int LocationId)
        {
            var result =  _dataContext.GetProcedures().SP_EMS_GetFPmilestoneResourceMIDPendingReqAsync(UserName, workfloworder, LocationId).Result.ToList();
            return result;
        }


        public List<SP_EMS_GetFPmonthlyResourceMIDPendingReqResult> GetMonthlyMIDcreationPendingList(string UserName, int workfloworder, int LocationId)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetFPmonthlyResourceMIDPendingReqAsync(UserName, workfloworder, LocationId).Result.ToList();
            return result;
        }

        
        public bool AddFPRejectedMlStnResrcWrkFloDts(string MID, string Name, List<EmsTblFpcontractWorkFlowMilestone> contractWorkFlow, int locationId)
        {
            _dataContext.BulkInsert(contractWorkFlow);
            _dataContext.SaveChanges();

            var itemsToDelete = _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationId).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            return true;
        }

        public bool AddFPRejectedMnthlyResrcWrkFloDts(string MID, string Name, List<EmsTblFpcontractWorkFlowMonthly> contractWorkFlow, int locationId)
        {
            _dataContext.BulkInsert(contractWorkFlow);
            _dataContext.SaveChanges();

            var itemsToDelete = _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.Where(x => x.UploadedBy == MID && x.PositionLocationId == locationId).ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            return true;
        }

        public string SaveMilestoneResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName)
        {
            var dataexist = _dataContext.EmsTblResourceMasters.Where(x => (x.ViatrisMid.ToLower() == MID.ToLower() || x.ViatrisEmailId == Email) && x.ResourceStatus == "Active").FirstOrDefault();
            if (dataexist == null)
            {
                var data = _dataContext.EmsTblResourceMasters.Where(x => x.Rmid == Rmid).FirstOrDefault();
                if (data != null)
                {
                    data.ViatrisMid = MID;
                    data.ViatrisEmailId = Email;
                    _dataContext.SaveChanges();
                }

                var workflow = new EmsTblFpcontractWorkFlowMilestone()
                {
                    Cmid = Cmid,
                    Role = "PMO-Admin",
                    ActionByMid = loggedInMID,
                    ActionByName = LoggedinName,
                    ActionDate = DateTime.Now,
                    Action = "Credentials Updated",
                    Remarks = "successfull",
                    NextWfrole = null,
                };
                _dataContext.EmsTblFpcontractWorkFlowMilestones.Add(workflow);
                _dataContext.SaveChanges();
                var result = _dataContext.EmsTblFbvendorContractMilestoneMasters.Where(x => x.FbcmilestoneMasterId == Cmid).FirstOrDefault();
                if (result != null)
                {
                    result.Wforder = null;
                    result.Status = "Closed";
                    _dataContext.SaveChanges();
                }
                _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMilestone", "Insert", MID).Wait();
                _dataContext.SaveChanges();
                return null;
            }
            else
            {
               return "Note : MID/Email ID already exist, Please provide correct MID/Email ID.";
              
            }
        
        }


        public string SaveMonthlyResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName)
        {
            var dataexist = _dataContext.EmsTblResourceMasters.Where(x => (x.ViatrisMid.ToLower() == MID.ToLower() || x.ViatrisEmailId == Email) && x.ResourceStatus == "Active").FirstOrDefault();
            if (dataexist == null)
            {
                var data = _dataContext.EmsTblResourceMasters.Where(x => x.Rmid == Rmid).FirstOrDefault();
                if (data != null)
                {
                    data.ViatrisMid = MID;
                    data.ViatrisEmailId = Email;
                    _dataContext.SaveChanges();
                }
                var workflow = new EmsTblFpcontractWorkFlowMonthly()
                {
                    Cmid = Cmid,
                    Role = "PMO-Admin",
                    ActionByMid = loggedInMID,
                    ActionByName = LoggedinName,
                    ActionDate = DateTime.Now,
                    Action = "Credentials Updated",
                    Remarks = "successfull",
                    NextWfrole = null,
                };
                _dataContext.EmsTblFpcontractWorkFlowMonthlies.Add(workflow);
                _dataContext.SaveChanges();
                var result = _dataContext.EmsTblFbvendorContractMonthlyMasters.Where(x => x.FbcmontlyId == Cmid).FirstOrDefault();
                if (result != null)
                {
                    result.Wforder = null;
                    result.Status = "Closed";
                    _dataContext.SaveChanges();
                }
                _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMonthly", "Insert", MID).Wait();
                _dataContext.SaveChanges();
                return null;
            }
            else
            {
                return "Note : MID/Email ID already exist, Please provide correct MID/Email ID.";

            }
        }


        public List<SP_EMS_GetFPMonthlyResourceTrackDetailsResult> GetResourceFPmonthlyTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetFPMonthlyResourceTrackDetailsAsync(UseName, workflowOrder, locationID, Filter, ActiveFilter, FromDate, Todate).Result.ToList();
            return result;
        }
        
         public List<SP_EMS_GetFPMilestoneResourceTrackDetailsResult> GetResourceFPmilestoneTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate)
        {
            var result = _dataContext.GetProcedures().SP_EMS_GetFPMilestoneResourceTrackDetailsAsync(UseName, workflowOrder, locationID, Filter,ActiveFilter, FromDate, Todate).Result.ToList();
            return result;
        }
        public string PostResourcemapping(List<EmsTblTmvendorContractMaster> vContract, string loggedIN = "")
        {
            //Update Resource Master table for Remapped MID,
            //if current contract end date of remapped person is less than current date then update EmsTblTmcontractResourceMapping with false and insert as well as overwrite position code in resourcemaster if it is active
            //.. else scheduler will update EmsTblTmcontractResourceMapping and resource master if Current SOW end date is less than current date

            string dateString = DateTime.Now.Date.ToString("yyyy-MM-dd");

            // Parse the yyyy-MM-dd string back to DateTime
            DateTime parsedDate = DateTime.ParseExact(dateString, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            //var vContract = _dataContext.EmsTblTmvendorContractMasters.ToList();

            var contractResourceupdate = (from v in vContract
                                          join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                          join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                          join vmcon in _dataContext.EmsTblTmvendorContractMasters on m.Cmid equals vmcon.Tmcmid
                                          where v.Status == "Closed" && m.IsMappingActive == true && r.ResourceStatus == "Active"
                                        && vmcon.SowendDate < parsedDate

                                          && v.RemappedMid != null && v.RemappedMid != ""
                                          select new EmsTblTmcontractResourceMapping()
                                          {
                                              Cmid = m.Cmid,
                                              IsMappingActive = false,
                                              TmcrmapId = m.TmcrmapId,
                                          }).ToList();


            var propToIncludeResource = new List<string> { nameof(EmsTblTmcontractResourceMapping.IsMappingActive) };
            var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
            _dataContext.BulkUpdate(contractResourceupdate, Resource);

            //If above condition is true then proceed to next updates
            if (contractResourceupdate.Any())
            {
                //Insert resource mapping table for remapped mid if Current SOW completed
                var contractResourceInsert = (from v in vContract
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join vm in _dataContext.EmsTblTmvendorContractMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.PositionCode }
                                              where v.Status == "Closed" && r.ResourceStatus == "Active"
                                              && vm.SowendDate < parsedDate && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblTmcontractResourceMapping()
                                              {
                                                  Cmid = v.Tmcmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = loggedIN, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              });
                _dataContext.BulkInsert(contractResourceInsert);

                //Overwrite the position code of resource if SOW end date is less than current date

                var resourePositionUpdate = (from v in vContract
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             join vm in _dataContext.EmsTblTmvendorContractMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.PositionCode }
                                             where v.Status == "Closed" && r.ResourceStatus == "Active"
                                             && vm.SowendDate < parsedDate && v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.PositionCode

                                             });
                var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                _dataContext.BulkUpdate(resourePositionUpdate, Position);

            }
            return "success";
        }
        
          public List<SP_EMS_GetTMPositionWithMultipleResourceDtsResult> GetMultipleResourceByPositionCode(string Positioncode)
        {
            // THis SP fetching data for FP also.
            var result = _dataContext.GetProcedures().SP_EMS_GetTMPositionWithMultipleResourceDtsAsync(Positioncode).Result.ToList();
            return result;
        }
        public bool DeleteIntrResourceTMdataById(int TmIntrId)
        {
            var result = _dataContext.EmsTblTmresourceMappingIntermediates.Where(x=>x.TmrmintId==TmIntrId).FirstOrDefault();
            if(result!=null)
            {
                _dataContext.EmsTblTmresourceMappingIntermediates.Remove(result);
                _dataContext.SaveChanges();
            }
            _dataContext.GetProcedures().sp_EMS_TM_ResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;
        }
        
        public bool DeleteIntrResourceFPmyldataById(int fpintid)
        {
            var result = _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.Where(x => x.FpmlyRmintId == fpintid).FirstOrDefault();
            if (result != null)
            {
                _dataContext.EmsTblFpmonthlyResourceMappingIntermediates.Remove(result);
                _dataContext.SaveChanges();
            }
            _dataContext.GetProcedures().sp_EMS_FP_MonthlyResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;
        }
        
         public bool DeleteIntrResourceFPmlsdataById(int fpintid)
        {
            var result = _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.Where(x => x.FpmsrmintId == fpintid).FirstOrDefault();
            if (result != null)
            {
                _dataContext.EmsTblFpmileStoneResourceMappingIntermediates.Remove(result);
                _dataContext.SaveChanges();
            }
            _dataContext.GetProcedures().sp_EMS_FP_MilestoneResourceOnboardingValidationAsync().Wait();
            _dataContext.SaveChanges();
            return true;
        }

    }
}
