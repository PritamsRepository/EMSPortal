﻿using EMS_DAL.Entities;
using EMS_DAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Repository
{
    public class ErrorLogRepository : IErrorLogRepository
    {
        private readonly EMS_Context _dbContext;
        public ErrorLogRepository (EMS_Context context)
        {
            _dbContext = context;

        }
        public bool SaveError (EmsTblErrorLog error)
        {
            if (error is not null)
            {
                _dbContext.EmsTblErrorLogs.Add(error);
                _dbContext.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
