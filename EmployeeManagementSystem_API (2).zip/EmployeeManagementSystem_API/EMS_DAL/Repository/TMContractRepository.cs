﻿using AutoMapper;
using EFCore.BulkExtensions;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Identity.Client;
using Microsoft.VisualBasic;
using NetTopologySuite.Geometries;
using NetTopologySuite.Index.HPRtree;
using NetTopologySuite.Operation.Valid;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EMS_DAL.Repository
{
    public class TMContractRepository : ITMContractRepository
    {
        private readonly EMS_Context _dataContext;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;
        /// <summary>
        /// dataContext Injection.
        /// </summary>
        /// <param name="eMS_Context"></param>
        /// <param name="memoryCach"></param>
        public TMContractRepository(EMS_Context eMS_Context, IMemoryCache memoryCach, IMapper mapper)
        {
            _dataContext = eMS_Context;
            _mapper = mapper;
        }

        #region "T&M Contarct Upload Workflow"

        //public async Task<bool> AddTMContractIntermediate(List<EmsTblTmvendorContractIntermediateMaster> tmvendorContractIntermediateMasters, string mid)
        //{
        //        // Delete the Records before uploading based on Uploaded MID.
        //        var recordsToDelete = _dataContext.EmsTblTmvendorContractIntermediateMasters.Where(x => x.UploadedBy == mid).ToList();

        //        if (recordsToDelete.Any())
        //        {
        //              _dataContext.BulkDelete(recordsToDelete);
        //            //await _dataContext.SaveChangesAsync(); // Wait for deletion to complete
        //        }

        //           _dataContext.BulkInsert(tmvendorContractIntermediateMasters);
        //        //await _dataContext.SaveChangesAsync(); // Wait for insertion to complete

        //    return true;
        //}



        public bool AddTMContractIntermediateAsync(List<EmsTblTmvendorContractIntermediateMaster> tmvendorContractIntermediateMasters, string mid, string location)
        {
            var result = false;
            // Check if data exists based on the uploadedBy column
            var existingData = _dataContext.EmsTblTmvendorContractIntermediateMasters
                .Where(x => x.UploadedBy == mid /*&& x.PositionLocation == location*/)
                .ToList();


            if (existingData.Any())
            {
                // Bulk delete existing records
                //_dataContext.EmsTblTmvendorContractIntermediateMasters.RemoveRange(existingData);
                //await _dataContext.SaveChangesAsync();

                _dataContext.BulkDelete(existingData);

            }

            // Bulk insert new records
            //_dataContext.EmsTblTmvendorContractIntermediateMasters.AddRange(tmvendorContractIntermediateMasters);
            //await _dataContext.SaveChangesAsync();

            _dataContext.BulkInsert(tmvendorContractIntermediateMasters);

            // transaction.Commit();
            result = true;

            // Execute stored procedure
            result = validateTmIntermediateTable(0, location);
            return result;
        }


        public List<EmsTblTmvendorContractIntermediateMaster> GetTMContractIntermediateList(string mid)
        {

            var result = _dataContext.EmsTblTmvendorContractIntermediateMasters.Where(x => x.UploadedBy.ToLower() == mid.ToLower()).ToList();
            return result;
        }

        public bool SaveTMIntermediateDataToMain(List<int> Id, string mid, string name, bool isProcLead, int locId)
        {

            if (Id.Count > 0)
            {

                // Execute stored procedure
                var locdata = GetLocationName(locId);
                validateTmIntermediateTable(1, locdata);

                var tmIntermediateData = _dataContext.EmsTblTmvendorContractIntermediateMasters.Where(x => Id.Contains(x.TmcintId) && (x.ValidationRemarks == null || x.ValidationRemarks == "")).ToList();

                var tmContractMaster = new List<EmsTblTmvendorContractMaster>();

                var vendorMaster = _dataContext.VendorMasters.ToList();
                var sowTypeMaster = _dataContext.EmsTblSowTypeMasters.ToList();
                var contractTypeMaster = _dataContext.EmsTblContractTypeMasters.ToList();
                var billingTypeMaster = _dataContext.EmsTblBillingTypeMasters.ToList();
                var verticalMaster = _dataContext.EmsTblVerticalMasters.ToList();
                var towerMaster = _dataContext.TowerNameMasters.ToList();
                var projOrRunMaster = _dataContext.ProjectOrRunMasters.ToList();
                var skillSetMaster = _dataContext.EmployeeSkills.ToList();
                var locationMaster = _dataContext.LocationMasters.ToList();

                //Prepare a TM data set to insert for main table.
                foreach (var contract in tmIntermediateData)
                {
                    if (contract != null)
                    {
                        var item = new EmsTblTmvendorContractMaster();

                        item.Etwid = contract.Etwid;
                        item.Sownumber = contract.Sownumber;
                        item.Sowname = contract.Sowname;
                        item.SowstartDate = contract.SowstartDate;
                        item.SowendDate = contract.SowendDate;
                        item.Ponumber = contract.Ponumber;
                        item.PostartDate = contract.PostartDate;
                        item.PoendDate = contract.PoendDate;
                        item.OldSownumber = contract.OldSownumber;
                        item.PositionCode = contract.PositionCode;
                        item.Currency = contract.Currency;
                        item.PositionCode = contract.PositionCode;
                        item.PpmprojectId = contract.PpmprojectId;
                        item.PpmprojectName = contract.PpmprojectName;
                        item.BillingRateYear1 = contract.BillingRateYear1;
                        item.BillingRateYear2 = contract.BillingRateYear2;
                        item.BillingRateYear3 = contract.BillingRateYear3;
                        item.BillingRateYear4 = contract.BillingRateYear4;
                        item.BillingRateYear5 = contract.BillingRateYear5;
                        item.DomainName = contract.DomainName;
                        item.DomainLeadEmail = contract.DomainLeadEmail;
                        item.DomainSkillStartDate = contract.DomainSkillStartDate;
                        item.DomainSkillEndDate = contract.DomainSkillEndDate;
                        item.NoticePeriod = contract.NoticePeriod;
                        item.CostCenter = contract.CostCenter;
                        item.Sapcode = contract.Sapcode;
                        item.Obs = contract.Obs;
                        item.RemappedMid = contract.RemappedMid;
                        item.Wbsdetail = contract.Wbsdetail;
                        item.CustomDomainName = contract.CustomDomainName;

                        item.VendorId = vendorMaster.Where(x => x.VendorName.ToLower().Trim() == contract.VendorName.ToLower().Trim() && x.IsActive == true).Select(x => x.VendorId).FirstOrDefault();
                        item.SowtypeId = sowTypeMaster.Where(x => x.SowTypeName.ToLower().Trim() == contract.Sowtype.ToLower().Trim() && x.IsActive == true).Select(x => x.SowTypeId).FirstOrDefault();
                        item.ContractTypeId = contractTypeMaster.Where(x => x.ContractTypeName.ToLower().Trim() == contract.ContractType.ToLower().Trim() && x.IsActive == true).Select(x => x.ContractTypeId).FirstOrDefault();
                        item.BillingTypeId = billingTypeMaster.Where(x => x.BillingTypeName.ToLower().Trim() == contract.BillingType.ToLower().Trim() && x.IsActive == true).Select(x => x.BillingTypeId).FirstOrDefault();
                        item.VerticalId = verticalMaster.Where(x => x.VerticalName.ToLower().Trim() == contract.Vertical.ToLower().Trim() && x.IsActive == true).Select(x => x.VerticalId).FirstOrDefault();
                        item.TowerId = towerMaster.Where(x => x.TowerName.ToLower().Trim() == contract.Tower.ToLower().Trim() && x.IsActive == true).Select(x => x.TowerNameId).FirstOrDefault();
                        item.ProjectOrRunId = projOrRunMaster.Where(x => x.ProjectOrRun.ToLower().Trim() == contract.ProjectOrRun.ToLower().Trim() && x.IsActive == true).Select(x => x.ProjectOrRunId).FirstOrDefault();
                        item.SkillSetId = skillSetMaster.Where(x => x.SkillSet.ToLower().Trim() == contract.SkillSet.ToLower().Trim() && x.IsActive == true).Select(x => x.SkillId).FirstOrDefault();
                        item.PositionLocationId = locationMaster.Where(x => x.LocationName.ToLower().Trim() == contract.PositionLocation.ToLower().Trim() && x.IsActive == true).Select(x => x.LocationId).FirstOrDefault();


                        item.UploadedBy = contract.UploadedBy;
                        item.Status = "Pending";
                        item.IsActive = true;

                        tmContractMaster.Add(item);

                    }
                }

                // save to main table from intermediate table
                if (tmContractMaster.Count > 0)
                {

                    _dataContext.BulkInsert(tmContractMaster);


                    //add data to contract master
                    var distinct = tmContractMaster.GroupBy(x => x.PositionCode).Select(g => g.FirstOrDefault());
                    //var distinct = tmContractMaster.GroupBy(x => new { x.PositionCode, x.Sowname, x.SkillSetId }).Select(g => g.FirstOrDefault());

                    var ContractMasterData = new List<EmsTblContractMaster>();

                    foreach (var item in distinct)
                    {
                        if (item != null)
                        {
                            var i = new EmsTblContractMaster();
                            i.Sowname = item.Sowname;
                            i.Status = item.Status;
                            //i.SowStartDate = item.SowstartDate; //removed as business confirmed that sowstrtdate can be diff for multi contracts.
                            i.SowStartDate = null;
                            i.PositionCode = item.PositionCode;
                            i.SkillSetId = item.SkillSetId;
                            i.ContractTypeId = 1; //use the constant value instead hardcoding 
                            i.IsActive = true;

                            ContractMasterData.Add(i);
                        }
                    }

                    if (ContractMasterData.Count > 0)
                    {
                        var existingPositionCodes = _dataContext.EmsTblContractMasters
                                                            .Select(e => e.PositionCode)
                                                            .ToList();

                        ContractMasterData.RemoveAll(c => existingPositionCodes.Contains(c.PositionCode));

                        if (ContractMasterData.Count > 0)
                        {
                            _dataContext.BulkInsert(ContractMasterData);
                        }
                    }

                }

                List<string> etwids = tmContractMaster.Select(x => x.Etwid).ToList();

                //start of next process of saving T&M data 
                var nextProcess = NextProcessOfSaveTMIntermediateDataToMain(mid, name, isProcLead, locId, etwids);


                //Delete the saved records after inserting into main table.
                if (tmIntermediateData.Count > 0 && nextProcess == true)
                {
                    _dataContext.BulkDelete(tmIntermediateData);

                }

                // _dataContext.SaveChanges();

                //mail notification

                return true;

            }
            return true;
        }

        public bool NextProcessOfSaveTMIntermediateDataToMain(string mid, string name, bool isProcLead, int locId, List<string> etwids)
        {
            var VendorContractMasterDetails = _dataContext.EmsTblTmvendorContractMasters
                .Where(x => x.UploadedBy.ToLower() == mid.ToLower() && x.Wforder == null && etwids.Contains(x.Etwid))
                .ToList();

            if (VendorContractMasterDetails.Count > 0 && isProcLead)
            {
                var currentWFOrderDetails = _dataContext.EmsTblWorkFlowMasters
                    .FirstOrDefault(x => x.Wfrole == "PMO-Contract-Mgm");

                if (currentWFOrderDetails != null)
                {
                    var nextWFOrder = currentWFOrderDetails.Wforder + 1;
                    var nextWFRole = _dataContext.EmsTblWorkFlowMasters
                        .FirstOrDefault(x => x.Wforder == nextWFOrder && x.Wfmodule == currentWFOrderDetails.Wfmodule).Wfrole;

                    var pendingWith = _dataContext.EmsTblRoleMasters
                        .Where(x => x.IsPrimaryPerson == true && x.RoleType == nextWFRole && x.LocationId == locId)
                        .Select(x => x.Mid)
                        .FirstOrDefault();

                    if (nextWFRole != null)
                    {

                        try
                        {
                            // update tmcmid and other required details in TM Main table.
                            var contractMasterDetails = _dataContext.EmsTblContractMasters.ToList();

                            foreach (var data in VendorContractMasterDetails)
                            {
                                data.Tmcmid = contractMasterDetails.FirstOrDefault(x => x.Sowname == data.Sowname && x.PositionCode == data.PositionCode && x.SkillSetId == data.SkillSetId).Cmid;
                                data.Wforder = nextWFOrder;
                                data.PendingWithWhom = pendingWith;
                                //data.UploadedBy = mid;
                                data.UploadedDate = DateTime.Now;
                            }

                            // Save changes to the VendorContractMasterDetails
                            _dataContext.SaveChanges();

                            // Insert data into EMS_tblTMContractWorkFlow
                            foreach (var data in VendorContractMasterDetails)
                            {
                                var contractWorkFlow = new EmsTblTmcontractWorkFlow
                                {
                                    Tmcid = data.Tmvcmid, // Replace with the actual property name for TMCID
                                    Role = "PMO-Contract-Mgm",
                                    ActionByMid = mid,
                                    ActionByName = name, // Replace with the actual property name for ActionByName
                                    ActionDate = DateTime.Now,
                                    Action = "Upload", // Replace with the actual action
                                    Remarks = "Successfully uploaded T&M Contracts.", // Replace with the actual remarks
                                    NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                                };

                                _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                            }

                            _dataContext.SaveChanges();

                        }
                        catch (Exception ex)
                        {
                            // Handle the exception, log, or rethrow as needed.
                            return false;
                        }

                    }
                }
            }

            return true;
        }


        private bool validateTmIntermediateTable(int sp, string location)
        {   // 1 : validateMainSp 
            // 0/Other : validateIntrSp

            //await Task.Delay(2000); // Delay for 2 seconds

            //if (sp == 1)
            //{
            //    await _dataContext.GetProcedures().sp_EMS_TM_MstrContractDataValidationAsync();
            //}
            //else
            //{
            //    await _dataContext.GetProcedures().sp_EMS_TM_IntrContractDataValidationAsync();
            //}
            _dataContext.GetProcedures().sp_EMS_TM_IntrContractDataValidationAsync(location).Wait();

            return true;
        }


        public bool DeleteTMIntermediateData(List<int> ids)
        {
            if (ids.Count > 0)
            {
                var entitiesToDelete = _dataContext.EmsTblTmvendorContractIntermediateMasters
                    .Where(e => ids.Contains(e.TmcintId))
                    .ToList();

                if (entitiesToDelete.Any())
                {
                    _dataContext.BulkDelete(entitiesToDelete);
                    _dataContext.SaveChanges();
                    return true; // Deletion successful
                }
            }

            return true; // No entities to delete or deletion failed
        }

        public bool DeleteTMSendbackData(int ids, string mid, string name, string remarks)
        {
            if (ids != null)
            {
                var idsDetail = _dataContext.EmsTblTmvendorContractMasters
                    .Where(e => ids == e.Tmvcmid).ToList();

                if (idsDetail.Any())
                {
                    var TMcontractMasters = _dataContext.EmsTblTmvendorContractMasters.AsEnumerable()
                        .Where(x => x.IsActive == true &&
                                    idsDetail.Any(d => d.PositionCode == x.PositionCode && d.Sowname == x.Sowname))
                        .ToList();

                    if (TMcontractMasters.Count == 1)
                    {
                        //Case is single
                        foreach (var i in idsDetail)
                        {
                            //i.IsActive = false;
                            //i.PendingWithWhom = null;
                            //i.Status = "Revoked";
                            //i.Wforder = null;

                            //_dataContext.SaveChanges();

                            var contractWorkFlow = new EmsTblTmcontractWorkFlow
                            {
                                Tmcid = i.Tmvcmid, // Replace with the actual property name for TMCID
                                Role = "PMO-Contract-Mgm",
                                ActionByMid = mid,
                                ActionByName = name, // Replace with the actual property name for ActionByName
                                ActionDate = DateTime.Now,
                                Action = "Deleted", // Replace with the actual action
                                Remarks = remarks, // Replace with the actual remarks
                                NextWfrole = null // Replace with the actual property name for NextWFRole
                            };

                            _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                            _dataContext.SaveChanges();

                            _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Tmvcmid == i.Tmvcmid).ExecuteDelete();
                        }

                        var removeFromContractMasters = _dataContext.EmsTblContractMasters.AsEnumerable()
                            .Where(x => idsDetail.Any(a => a.Tmcmid == x.Cmid))
                            .ToList();

                        foreach (var i in removeFromContractMasters)
                        {
                            //i.IsActive = false;
                            //i.Status = "Revoked";
                            _dataContext.EmsTblContractMasters.Where(x => x.Cmid == i.Cmid).ExecuteDelete();

                            //_dataContext.SaveChanges();
                        }
                    }
                    else
                    {
                        //Case is Multi
                        foreach (var i in idsDetail)
                        {
                            i.IsActive = false;
                            i.PendingWithWhom = null;
                            i.Status = "Revoked";
                            i.Wforder = null;
                            _dataContext.SaveChanges();

                            var contractWorkFlow = new EmsTblTmcontractWorkFlow
                            {
                                Tmcid = i.Tmvcmid, // Replace with the actual property name for TMCID
                                Role = "PMO-Contract-Mgm",
                                ActionByMid = mid,
                                ActionByName = name, // Replace with the actual property name for ActionByName
                                ActionDate = DateTime.Now,
                                Action = "Sentback TM Contract Deleted", // Replace with the actual action
                                Remarks = remarks, // Replace with the actual remarks
                                NextWfrole = null // Replace with the actual property name for NextWFRole
                            };

                            _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                            _dataContext.SaveChanges();
                        }
                    }

                }
            }

            return true;
        }


        public List<sp_EMS_GetTMVendorContractMainMasterDetailsResult> GetTMContractMainList(string RecordType, int locId)
        {
            var result = _dataContext.GetProcedures().sp_EMS_GetTMVendorContractMainMasterDetailsAsync(RecordType, locId).Result.ToList();

            return result;
        }


        public bool UpdateApprovedTmContractDetails(EmsTblTmvendorContractMaster tmDetails, string mid, string remarks)
        {
            if (tmDetails != null)
            {
                var detail = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Etwid == tmDetails.Etwid && x.IsActive == true).FirstOrDefault();
                if (detail != null)
                {
                    //green color columns
                    //detail.Sowname = tmDetails.Sowname;
                    //detail.SowstartDate = tmDetails.SowstartDate;
                    //detail.SowendDate = tmDetails.SowendDate;
                    //detail.Ponumber = tmDetails.Ponumber;
                    //detail.PostartDate = tmDetails.PostartDate;
                    //detail.PoendDate = tmDetails.PoendDate;
                    //detail.PpmprojectId = tmDetails.PpmprojectId;
                    //detail.PpmprojectName = tmDetails.PpmprojectName;
                    //detail.Wbsdetail = tmDetails.Wbsdetail;
                    //detail.CostCenter = tmDetails.CostCenter;
                    //detail.Obs = tmDetails.Obs;
                    //detail.ProjectOrRunId = tmDetails.ProjectOrRunId;
                    //detail.BillingTypeId = tmDetails.BillingTypeId;
                    //detail.Sapcode = tmDetails.Sapcode;
                    //detail.NoticePeriod = tmDetails.NoticePeriod;
                    //below are orange color columns
                    detail.OldSownumber = tmDetails.OldSownumber;
                    detail.VerticalId = tmDetails.VerticalId;
                    detail.TowerId = tmDetails.TowerId;
                    detail.DomainLeadEmail = tmDetails.DomainLeadEmail;
                    detail.DomainName = tmDetails.DomainName;
                    detail.CustomDomainName = tmDetails.CustomDomainName;
                    detail.SkillSetId = tmDetails.SkillSetId;
                    detail.DomainSkillStartDate = tmDetails.DomainSkillStartDate;
                    detail.DomainSkillEndDate = tmDetails.DomainSkillEndDate;
                    detail.Currency = tmDetails.Currency;
                    detail.BillingRateYear1 = tmDetails.BillingRateYear1;
                    detail.BillingRateYear2 = tmDetails.BillingRateYear2;
                    detail.BillingRateYear3 = tmDetails.BillingRateYear3;
                    detail.BillingRateYear4 = tmDetails.BillingRateYear4;
                    detail.BillingRateYear5 = tmDetails.BillingRateYear5;

                    detail.UpdatedBy = mid;
                    detail.UpdatedDate = DateTime.Now;

                    _dataContext.SaveChanges();

                    //The below code will update records only when any resource is mapped to selected contract
                    EmsTblTmcontractResourceMapping? contractMapping = _dataContext.EmsTblTmcontractResourceMappings.Where(x => x.Cmid == detail.Tmcmid && x.IsMappingActive == true && x.IsAmsupdated == true)?.FirstOrDefault();
                    if (contractMapping != null)
                    {
                        //r.Rmid 
                        string? rmmid = _dataContext.EmsTblResourceMasters.Where(x => x.Rmid == contractMapping.Rmid)?.Select(x => x.ViatrisMid).FirstOrDefault();
                        if (rmmid != null)
                        {
                            EmployeeMaster? em = _dataContext.EmployeeMasters.Where(x => x.EmpMid == rmmid)?.FirstOrDefault();
                            if (em != null)
                            {
                                em.TowerNameId = tmDetails.TowerId;
                                em.DomainSkillStDt = tmDetails.DomainSkillStartDate;
                                em.DomainSkillEdDt = tmDetails.DomainSkillEndDate;
                                em.SkillSet = tmDetails.SkillSetId.ToString();// _dataContext.EmployeeSkills.Where(x=>x.SkillId == tmDetails.SkillSetId).Select(x=>x.SkillSet).FirstOrDefault();
                                em.DomainSkillSet = tmDetails.DomainName;
                            }
                        }
                    }

                    var contractWorkFlow = new EmsTblTmcontractWorkFlow
                    {
                        Tmcid = detail.Tmvcmid, // Replace with the actual property name for TMCID
                        Role = "IT Finance Manager",// "PMO-Contract-Mgm",
                        ActionByMid = mid,
                        ActionByName = _dataContext.EmsTblRoleMasters.Where(x => x.Mid == mid)?.Select(x => x.Name).FirstOrDefault() ?? mid, // Replace with the actual property name for ActionByName
                        ActionDate = DateTime.Now,
                        Action = "Modified", // Replace with the actual action
                        Remarks = remarks, // Replace with the actual remarks
                        NextWfrole = null // Replace with the actual property name for NextWFRole
                    };
                    _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                    _dataContext.SaveChanges();
                    return true;
                }




                return false;

            }

            return false;

        }

        public bool UpdateTmContractDetails(EmsTblTmvendorContractMaster tmDetails, string mid)
        {
            if (tmDetails != null)
            {
                var detail = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Etwid == tmDetails.Etwid && x.IsActive == true).FirstOrDefault();
                if (detail != null)
                {
                    detail.Etwid = tmDetails.Etwid;
                    detail.Sownumber = tmDetails.Sownumber;
                    detail.Sowname = tmDetails.Sowname;
                    detail.VendorId = tmDetails.VendorId;
                    detail.PositionCode = tmDetails.PositionCode;
                    detail.PositionLocationId = tmDetails.PositionLocationId;
                    detail.SowtypeId = tmDetails.SowtypeId;
                    detail.SowstartDate = tmDetails.SowstartDate;
                    detail.SowendDate = tmDetails.SowendDate;
                    detail.Ponumber = tmDetails.Ponumber;
                    detail.PostartDate = tmDetails.PostartDate;
                    detail.PoendDate = tmDetails.PoendDate;
                    detail.PpmprojectId = tmDetails.PpmprojectId;
                    detail.PpmprojectName = tmDetails.PpmprojectName;
                    detail.Wbsdetail = tmDetails.Wbsdetail;
                    detail.VerticalId = tmDetails.VerticalId;
                    detail.DomainLeadEmail = tmDetails.DomainLeadEmail;
                    detail.CostCenter = tmDetails.CostCenter;
                    detail.Obs = tmDetails.Obs;
                    detail.DomainName = tmDetails.DomainName;
                    detail.SkillSetId = tmDetails.SkillSetId;
                    detail.DomainSkillStartDate = tmDetails.DomainSkillStartDate;
                    detail.DomainSkillEndDate = tmDetails.DomainSkillEndDate;
                    detail.ProjectOrRunId = tmDetails.ProjectOrRunId;
                    detail.ContractTypeId = tmDetails.ContractTypeId;
                    detail.BillingTypeId = tmDetails.BillingTypeId;
                    detail.BillingRateYear1 = tmDetails.BillingRateYear1;
                    detail.BillingRateYear2 = tmDetails.BillingRateYear2;
                    detail.BillingRateYear3 = tmDetails.BillingRateYear3;
                    detail.BillingRateYear4 = tmDetails.BillingRateYear4;
                    detail.BillingRateYear5 = tmDetails.BillingRateYear5;
                    detail.OldSownumber = tmDetails.OldSownumber;
                    detail.Currency = tmDetails.Currency;
                    detail.RemappedMid = tmDetails.RemappedMid;
                    detail.Sapcode = tmDetails.Sapcode;
                    detail.NoticePeriod = tmDetails.NoticePeriod;
                    detail.TowerId = tmDetails.TowerId;
                    //detail.UpdatedDate = DateTime.Now;
                    detail.UpdatedBy = mid;
                    detail.CustomDomainName = tmDetails.CustomDomainName;

                    // Save changes to the database
                    _dataContext.SaveChanges();

                    return true;

                }
                return false;

            }

            return false;
        }

        public bool NextProcessOfSaveTMDataAfterSendback(string mid, string name, bool isProcLead, int locId, int tmvcmid, string remarks)
        {

            var VendorContractMasterDetails = _dataContext.EmsTblTmvendorContractMasters
                .Where(x => (x.UploadedBy.ToLower() == mid.ToLower() || x.PendingWithWhom.ToLower() == mid.ToLower()) && x.Wforder == 0 && x.Tmvcmid == tmvcmid)
                .ToList();

            if (VendorContractMasterDetails.Count > 0 && isProcLead)
            {
                var currentWFOrderDetails = _dataContext.EmsTblWorkFlowMasters
                    .FirstOrDefault(x => x.Wfrole == "PMO-Contract-Mgm");

                if (currentWFOrderDetails != null)
                {
                    var nextWFOrder = currentWFOrderDetails.Wforder + 1;
                    var nextWFRole = _dataContext.EmsTblWorkFlowMasters
                        .FirstOrDefault(x => x.Wforder == nextWFOrder && x.Wfmodule == currentWFOrderDetails.Wfmodule).Wfrole;

                    var pendingWith = _dataContext.EmsTblRoleMasters
                        .Where(x => x.IsPrimaryPerson == true && x.RoleType == nextWFRole && x.LocationId == locId)
                        .Select(x => x.Mid)
                        .FirstOrDefault();

                    if (nextWFRole != null)
                    {
                        //try
                        //{
                        // update tmcmid and other required details in TM Main table.
                        //var contractMasterDetails = _dataContext.EmsTblContractMasters.ToList();
                        var cmidList = VendorContractMasterDetails.Select(x => x.Tmcmid).ToList();

                        var contractMasterDetails = _dataContext.EmsTblContractMasters
                                                    .Where(cm => cmidList.Contains(cm.Cmid))
                                                    .ToList();

                        foreach (var data in VendorContractMasterDetails)
                        {
                            //data.Tmcmid = contractMasterDetails.FirstOrDefault(x => x.Sowname == data.Sowname && x.PositionCode == data.PositionCode && x.SkillSetId == data.SkillSetId).Cmid;
                            data.Wforder = nextWFOrder;
                            data.PendingWithWhom = pendingWith;
                            //data.UploadedBy = mid;
                            data.UpdatedDate = DateTime.Now;

                            var cmd = contractMasterDetails.Where(x => x.Cmid == data.Tmcmid).FirstOrDefault();
                            if (cmd != null)
                            {
                                cmd.Sowname = data.Sowname;
                                cmd.SkillSetId = data.SkillSetId;
                                cmd.PositionCode = data.PositionCode;
                            }
                        }

                        // Save changes to the VendorContractMasterDetails
                        _dataContext.SaveChanges();

                        // Insert data into EMS_tblTMContractWorkFlow
                        foreach (var data in VendorContractMasterDetails)
                        {
                            var contractWorkFlow = new EmsTblTmcontractWorkFlow
                            {
                                Tmcid = data.Tmvcmid, // Replace with the actual property name for TMCID
                                Role = "PMO-Contract-Mgm",
                                ActionByMid = mid,
                                ActionByName = name, // Replace with the actual property name for ActionByName
                                ActionDate = DateTime.Now,
                                Action = "ReSubmitted", // Replace with the actual action
                                Remarks = remarks, // Replace with the actual remarks
                                NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                            };

                            _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                        }

                        _dataContext.SaveChanges();

                        //}
                        //catch (Exception ex)
                        //{
                        // Handle the exception, log, or rethrow as needed.
                        //return false;
                        //}

                    }
                }
            }

            return true;
        }

        public List<EmsTblTmcontractWorkFlow> GetTmSendbackedListFromWorkFlow(List<int?> MastertmcidList)
        {
            var sendbackDetails = _dataContext.EmsTblTmcontractWorkFlows.Where(x => MastertmcidList.Contains(x.Tmcid) && x.Action == "Sentback").ToList();
            return sendbackDetails;
        }

        public List<string> ValidateAndSaveApprovedContract(EmsTblTmvendorContractMaster contract, string mid, int locId, string remarks)
        {
            //get the Contract details excluding edited contract.
            var TmContractMasterDetails = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Tmvcmid != contract.Tmvcmid).ToList();

            //validate the edited contract before updating.
            var validationResult = ValidateEditedTmContractDetails(TmContractMasterDetails, contract, locId);
            if (validationResult.Contains("Contract Validation successfully"))
            {
                var IsSaved = UpdateApprovedTmContractDetails(contract, mid, remarks);
                //var IsSaved = true;
                if (IsSaved)
                {
                    validationResult.Remove("Contract Validation successfully");
                    validationResult.Add("Contract saved successfully");
                }
                else
                {
                    validationResult.Add("Contract saved Failed");

                }
            }
            return validationResult;

        }
        public List<string> ValidateAndSaveContract(EmsTblTmvendorContractMaster contract, string mid, string name, bool isProcLead, int locId, string remarks)
        {
            //get the Contract details excluding edited contract.
            var TmContractMasterDetails = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Tmvcmid != contract.Tmvcmid).ToList();

            //validate the edited contract before updating.
            var validationResult = ValidateEditedTmContractDetails(TmContractMasterDetails, contract, locId);
            if (validationResult.Contains("Contract Validation successfully"))
            {
                var IsSaved = UpdateTmContractDetails(contract, mid);
                //var IsSaved = true;
                if (IsSaved)
                {
                    NextProcessOfSaveTMDataAfterSendback(mid, name, isProcLead, locId, contract.Tmvcmid, remarks);

                    validationResult.Remove("Contract Validation successfully");
                    validationResult.Add("Contract saved successfully");
                }
                else
                {
                    validationResult.Add("Contract saved Failed");

                }
            }
            return validationResult;
        }
        private List<string> ValidateEditedTmContractDetails(List<EmsTblTmvendorContractMaster> Maincontract, EmsTblTmvendorContractMaster Editedcontract, int locId)
        {
            List<string> validationRemarks = new List<string>();

            if (Maincontract.Count() > 0 && Editedcontract != null)
            {
                // Perform validation checks

                //// Retrieve the type of the Editedcontract object
                //Type contractType = Editedcontract.GetType();

                //// Get all properties of the Editedcontract type
                //var properties = contractType.GetProperties();

                //// Iterate through each property
                //foreach (var property in properties)
                //{
                //    // Get the value of the property for the specific object instance
                //    var value = property.GetValue(Editedcontract);

                //    // Perform null or empty check based on the type of the property
                //    if (value == null || (value is string && string.IsNullOrWhiteSpace((string)value)) ||
                //        (value is DateTime && ((DateTime)value) == new DateTime(1900, 1, 1)))
                //    {
                //        // Add validation remark for empty field
                //        validationRemarks.Add($"{property.Name} is empty or null");
                //    }
                //}

                // Check if edited contract's ETW ID is unique
                var duplicateETWID = Maincontract
                    .Where(i => i.Etwid == Editedcontract.Etwid)
                    .Any();

                if (duplicateETWID)
                {
                    validationRemarks.Add("ETW ID should be unique");
                }

                // Check if Vendor Name and Position Code combination is unique
                var duplicateVendorPosition = Maincontract
                    .Where(i => i.VendorId == Editedcontract.VendorId && i.PositionCode == Editedcontract.PositionCode)
                    .Any();

                if (duplicateVendorPosition)
                {
                    validationRemarks.Add("Vendor Name and Position Code should be unique");
                }

                // Check if ETW ID, Vendor Name, Position Code, SOW Number, SOW Name, and SOW Type combination is unique
                var duplicateCombination = Maincontract
                    .Where(i => i.Etwid == Editedcontract.Etwid &&
                                i.VendorId == Editedcontract.VendorId &&
                                i.PositionCode == Editedcontract.PositionCode &&
                                i.Sownumber == Editedcontract.Sownumber &&
                                i.Sowname == Editedcontract.Sowname &&
                                i.SowtypeId == Editedcontract.SowtypeId)
                    .Any();

                if (duplicateCombination)
                {
                    validationRemarks.Add("ETW ID, Vendor Name, Position Code, SOW Number, SOW Name, and SOW Type should be unique");
                }

                // Check if Vendor Name exists in master table
                var validVendorName = _dataContext.VendorMasters.Any(vm => vm.VendorId == Editedcontract.VendorId && vm.IsActive);

                if (!validVendorName)
                {
                    validationRemarks.Add("Vendor Name does not exist in master");
                }

                // Check if SOW Type exists in master table
                var validSOWType = _dataContext.EmsTblSowTypeMasters.Any(s => s.SowTypeId == Editedcontract.SowtypeId && s.IsActive == true);

                if (!validSOWType)
                {
                    validationRemarks.Add("SOW Type does not exist in master");
                }

                // Check if Skill Set exists in master table
                var validSkillSet = _dataContext.EmployeeSkills.Any(s => s.SkillId == Editedcontract.SkillSetId && s.IsActive == true);

                if (!validSkillSet)
                {
                    validationRemarks.Add("Skill Set does not exist in master");
                }

                // Check if ProjectOrRun exists in master table
                var validProjectOrRun = _dataContext.ProjectOrRunMasters.Any(p => p.ProjectOrRunId == Editedcontract.ProjectOrRunId && p.IsActive == true);

                if (!validProjectOrRun)
                {
                    validationRemarks.Add("ProjectOrRun does not exist in master");
                }

                // Check if Contract Type exists in master table
                var validContractType = _dataContext.EmsTblContractTypeMasters.Any(c => c.ContractTypeId == Editedcontract.ContractTypeId && c.IsActive == true);

                if (!validContractType)
                {
                    validationRemarks.Add("Contract Type does not exist in master");
                }

                // Check if Billing Type exists in master table
                var validBillingType = _dataContext.EmsTblBillingTypeMasters.Any(b => b.BillingTypeId == Editedcontract.BillingTypeId && b.IsActive == true);

                if (!validBillingType)
                {
                    validationRemarks.Add("Billing Type does not exist in master");
                }

                // Check if Currency Code exists in master table
                var validCurrencyCode = _dataContext.EmsTblCurrencyMasters.Any(c => c.CurrencyCode == Editedcontract.Currency);

                if (!validCurrencyCode)
                {
                    validationRemarks.Add("Currency Code does not exist in master");
                }

                // Check if Location exists in master table
                var validLocation = _dataContext.LocationMasters.Any(l => l.LocationId == Editedcontract.PositionLocationId && l.IsActive == true);

                if (!validLocation)
                {
                    validationRemarks.Add("Location does not exist in master");
                }

                // Check if the logged in person is mapped with the location
                if (Editedcontract.PositionLocationId != locId)
                {
                    validationRemarks.Add("You are not mapped with the location");
                }

            }
            if (validationRemarks.Count > 0) { } else { validationRemarks.Add("Contract Validation successfully"); }
            return validationRemarks;
        }

        public List<EmsTblTmcontractWorkFlow> GetWorkFlowsOfContract(int tmcid)
        {
            return _dataContext.EmsTblTmcontractWorkFlows.Where(x => tmcid == x.Tmcid).ToList();
        }
        #endregion

        #region "T&M Contract Approval Workflow"
        public List<SP_EMS_GetTMContractPendingListResult> GetTMContractPendingList(int WFOrder, int Location)
        {
            //WFOrder = 1 for Finance Manager

            // var result = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Wforder == WFOrder).ToList();
            var result = _dataContext.GetProcedures().SP_EMS_GetTMContractPendingListAsync(WFOrder, Location).Result;
            return result;
        }

        public List<EmsTblWorkFlowMaster> GetTMContractWFOrder()
        {
            //Fetch all workflow details of procurement module and that flow is mandatory
            //WFOrder = 1 for Finance Manager
            var _objwfmaster = _dataContext.EmsTblWorkFlowMasters.Where(x => x.Wfmodule == "Procurement" && x.IsMandatory == true).ToList();
            return _objwfmaster;
        }

        public string PostTMContractApproval(List<EmsTblTmvendorContractMaster> vContract, List<EmsTblTmcontractWorkFlow> wf, List<EmsTblContractMaster> vmContract)
        {
            var result = "Fail";
            List<EmsTblTmvendorContractMaster> mappedResource = new List<EmsTblTmvendorContractMaster>();
            //Push into main table and workflow table
            if (vContract != null)
            {

                //To hit the master table to check the position already closed
                vContract.Join(_dataContext.EmsTblTmvendorContractMasters, u => u.PositionCode, uir => uir.PositionCode,
                         (u, uir) => new { u, uir }).Where(x => x.uir.Status == "Closed" && x.u.Status != "Pending").ToList().ForEach(x => { x.u.PendingWithWhom = null; x.u.Wforder = null; x.u.Status = "Open"; x.u.ContractTypeId = x.uir.ContractTypeId; });


                //Update Pendingwith and WFOrdr
                var propToInclude = new List<string> { nameof(EmsTblTmvendorContractMaster.PendingWithWhom), nameof(EmsTblTmvendorContractMaster.Wforder), nameof(EmsTblTmvendorContractMaster.Status) };
                var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
                _dataContext.BulkUpdate(vContract, bulkConfig);

                //Check if pendingwith whom is null, next role also empty.
                wf.Join(vContract, u => u.Tmcid, uir => uir.Tmvcmid,
                         (u, uir) => new { u, uir }).Where(x => x.uir.PendingWithWhom == null || x.uir.PendingWithWhom == "").ToList().ForEach(x => { x.u.NextWfrole = null; });

                //Insert into workflow history table
                _dataContext.BulkInsert(wf);
                // throw new InvalidOperationException("Logfile cannot be read-only");

                var _contract = (from c in vmContract
                                 join contract in _dataContext.EmsTblContractMasters
                                 on c.Cmid equals contract.Cmid
                                 where contract.Status != "Closed"
                                 select new EmsTblContractMaster()
                                 {
                                     ContractTypeId = contract.ContractTypeId,
                                     IsActive = c.IsActive,
                                     Cmid = c.Cmid,
                                     Status = c.Status,
                                     PositionCode = c.PositionCode,
                                     SkillSetId = c.SkillSetId,
                                     Sowname = c.Sowname,
                                     SowStartDate = c.SowStartDate,

                                 }).ToList();
                //Update in contract Master
                var propToIncludeContract = new List<string> { nameof(EmsTblContractMaster.Status) };
                var bulkConfigContract = new BulkConfig { PropertiesToInclude = propToIncludeContract };
                _dataContext.BulkUpdate(_contract, bulkConfigContract);

                if (vContract.Where(x => x.RemappedMid != null && x.RemappedMid != "").Any())
                {
                    var loggedby = wf.Select(x => x.ActionByMid).FirstOrDefault() ?? "";
                    mappedResource = PostResourcemapping(vContract, loggedby);

                }

                // Insert in position tracking table the Position Open date and closed date if resource remapped.
                var contractTypeId = _contract.FirstOrDefault();
                var approvedContract = vContract.Where(x => x.Status != "Pending").DistinctBy(x => x.PositionCode);

                var postionTracking = (from c in approvedContract
                                       join con in mappedResource
                                       on c.PositionCode equals con.PositionCode into mapped
                                       from m in mapped.DefaultIfEmpty()
                                       where c.Status != "Pending"// The contract is approved
                                       select new EmsTblPositionTracking()
                                       {
                                           PositionCode = c.PositionCode,
                                           PositionOpenDate = (c.SowstartDate > DateTime.Now.Date) ? c.SowstartDate : DateTime.Now.Date,
                                           // In permanenet table we are making remapped MID null if we are mapping the resource, so check if vContract (uploaded data) having remapped MID and permanent table having null, then consider the position is mapped.
                                           PositionCloseDate = (c.RemappedMid != null && c.RemappedMid != "" && m != null) ? DateTime.Now.Date : null,
                                           PositionFilledWithMid = c.RemappedMid,
                                           ContractTypeId = (contractTypeId != null) ? contractTypeId.ContractTypeId : 0
                                       });
                _dataContext.BulkInsert(postionTracking);

                result = "success";

            }
            return result;
        }

        public List<EmsTblTmvendorContractMaster> PostResourcemapping(List<EmsTblTmvendorContractMaster> vContract, string loggedIN = "")
        {
            //Update Resource Master table for Remapped MID,
            //if current contract end date of remapped person is less than current date then update EmsTblTmcontractResourceMapping with false and insert as well as overwrite position code in resourcemaster if it is active
            //.. else scheduler will update EmsTblTmcontractResourceMapping and resource master if Current SOW end date is less than current date

            List<EmsTblTmvendorContractMaster> mappedResource = new List<EmsTblTmvendorContractMaster>();


            string dateString = DateTime.Now.Date.ToString("yyyy-MM-dd");

            // Parse the yyyy-MM-dd string back to DateTime
            DateTime parsedDate = DateTime.ParseExact(dateString, "yyyy-MM-dd", CultureInfo.InvariantCulture);


            var otherContracts = (from v in vContract
                                  join m in _dataContext.EmsTblTmvendorContractMasters on v.PositionCode equals m.PositionCode
                                  where v.Status == "Closed"
                                  select new EmsTblTmvendorContractMaster()
                                  {
                                      Tmvcmid = m.Tmvcmid,
                                      PendingWithWhom = null,
                                      Wforder = null,
                                  });

            //Update Pendingwith and WFOrdr for other vendors
            var propToInclude1 = new List<string> { nameof(EmsTblTmvendorContractMaster.PendingWithWhom), nameof(EmsTblTmvendorContractMaster.Wforder) };
            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude1 };

            _dataContext.BulkUpdate(otherContracts, bulkConfig);

            //var vContract = _dataContext.EmsTblTmvendorContractMasters.ToList();
            var contractResourceupdate = (from v in vContract
                                          join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                          join m in _dataContext.EmsTblTmcontractResourceMappings on r.Rmid equals m.Rmid
                                          join vmcon in _dataContext.EmsTblTmvendorContractMasters on m.Cmid equals vmcon.Tmcmid
                                          where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                           && vmcon.SowendDate < parsedDate && v.SowstartDate <= parsedDate
                                          && v.RemappedMid != null && v.RemappedMid != ""
                                          select new EmsTblTmcontractResourceMapping()
                                          {
                                              Cmid = m.Cmid,
                                              IsMappingActive = false,
                                              UnMappedDate = DateAndTime.Now,
                                              UnMappedBy = loggedIN,
                                              TmcrmapId = m.TmcrmapId,
                                          }).DistinctBy(x => x.TmcrmapId).ToList();


            var propToIncludeResource = new List<string> { nameof(EmsTblTmcontractResourceMapping.IsMappingActive), nameof(EmsTblTmcontractResourceMapping.UnMappedBy), nameof(EmsTblTmcontractResourceMapping.UnMappedDate) };
            var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
            _dataContext.BulkUpdate(contractResourceupdate, Resource);

            //If above condition is true then proceed to next updates
            if (contractResourceupdate.Any())
            {
                //Insert resource mapping table for remapped mid if Current SOW completed
                var contractResourceInsert = (from v in vContract
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join vm in _dataContext.EmsTblTmvendorContractMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.PositionCode }
                                              where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                              && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblTmcontractResourceMapping()
                                              {
                                                  Cmid = v.Tmcmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = loggedIN, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              });
                _dataContext.BulkInsert(contractResourceInsert);



                //Overwrite the position code of resource if SOW end date is less than current date
                var resourePositionUpdate = (from v in vContract
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             join vm in _dataContext.EmsTblTmvendorContractMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.PositionCode }
                                             where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate && v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.PositionCode,
                                                 ViatrisMid = r.ViatrisMid
                                             });
                var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                _dataContext.BulkUpdate(resourePositionUpdate, Position);

                //To make Remapped MID null after mapping done.
                mappedResource = (from r in resourePositionUpdate
                                  join tcm in _dataContext.EmsTblTmvendorContractMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.PositionCode, mid = tcm.RemappedMid }
                                  select new EmsTblTmvendorContractMaster()
                                  {
                                      Tmvcmid = tcm.Tmvcmid,
                                      RemappedMid = null,
                                      ContractTypeId = tcm.ContractTypeId,
                                      PositionCode = tcm.PositionCode
                                  }).ToList();

                //Update Pendingwith and WFOrdr for other vendors
                var propToInclude2 = new List<string> { nameof(EmsTblTmvendorContractMaster.RemappedMid) };
                var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };

                _dataContext.BulkUpdate(mappedResource, bulkConfig1);


                // Call the SP to put reconcile in employeemaster of AMS
                var remappedContracts = vContract.Where(x => x.RemappedMid != "" && x.RemappedMid != null).ToList();
                foreach (var v in remappedContracts)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("T&M", "Update", v.RemappedMid).Wait();
                    _dataContext.SaveChanges();
                }

            }

            //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
            List<EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();
            ress = (from v in vContract
                    where v.RemappedMid != null && v.RemappedMid != ""
                    select new EmsTblRemappedResourceWdExtension
                    {
                        EmpMid = v.RemappedMid,
                        EmpName = null,
                        PositionCode = v.PositionCode,
                        Sownumber = v.Sownumber,
                        DomainSkillEndDate = v.DomainSkillEndDate,
                        Ritm = null
                    }).ToList();

            ress.Join(
                _dataContext.EmployeeMasters,
                r => r.EmpMid,
                e => e.EmpMid,
                (r, e) => { r.EmpName = e.EmpName; return r; }
            ).ToList();

            _dataContext.BulkInsert(ress);

            return mappedResource;
        }

        #endregion

        #region "T&M Contract Track Contracts"
        public List<SP_EMS_GetTMContractTrackListResult> GetTMContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter)
        {
            //WFOrder = 1 for Finance Manager
            var result = _dataContext.GetProcedures().SP_EMS_GetTMContractTrackListAsync(WFOrder, Location, filter, ActiveFilter).Result;
            return result;
        }
        #endregion

        public string GetLocationName(int locID)
        {
            var result = _dataContext.LocationMasters.Where(x => x.IsActive == true && x.LocationId == locID).Select(x => x.LocationName).FirstOrDefault();
            return result;
        }

        public List<SP_EMS_FetchSowNumberByContractTypeResult> GetSowListByContractType(string contractType, string searchSowNumber)
        {
            var result = _dataContext.GetProcedures().SP_EMS_FetchSowNumberByContractTypeAsync(contractType, searchSowNumber).Result;
            return result;
        }

        public List<SP_EMS_FetchContractListBySOW_NoResult> GetAllSowListByContractType(string contractType, string sowNumber)
        {
            var result = _dataContext.GetProcedures().SP_EMS_FetchContractListBySOW_NoAsync(contractType, sowNumber).Result;
            return result;
        }

        public List<SP_EMS_FetchColumnValueByTblAndSowNumberResult> GetContractValueByContractSowType(string contractType, string sowNumber, string fieldType)
        {
            var result = _dataContext.GetProcedures().SP_EMS_FetchColumnValueByTblAndSowNumberAsync(contractType, sowNumber, fieldType).Result;
            return result;
        }
        public  List<SP_EMS_ValidateColumnBySowNumberResult> GetColumnValidationStatusBySowNumber(string contractType, string sowNumber, string fieldType, string newValue)
        {
            var result = _dataContext.GetProcedures().SP_EMS_ValidateColumnBySowNumberAsync(contractType, sowNumber, fieldType, newValue).Result;
            return result;
        }

        public int UpdateContractColumnBySowNumber(string contractType, string sowNumber, string fieldType, string oldValue, string newValue, string mid)
        {
            var result = _dataContext.GetProcedures().SP_EMS_UpdateColumnBySowNumberAsync(contractType, sowNumber, fieldType, oldValue, newValue, mid).Result;
            return result.FirstOrDefault()?.total ?? 0;
        }
    }
}