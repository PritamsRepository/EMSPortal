﻿using EFCore.BulkExtensions;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using Microsoft.EntityFrameworkCore.Storage;
using System.Globalization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;

namespace EMS_DAL.Repository
{
    public class FPContractRepository : IFPContractRepository
    {
        private readonly EMS_Context _dataContext;
        private readonly IMemoryCache _memoryCache;
        private IMastersRepository _MastersRepository;
        private IDbContextTransaction _currentTransaction;
        private readonly IConfiguration _configuration;

        public FPContractRepository(EMS_Context eMS_Context, IMemoryCache memoryCach, IMastersRepository mastersRepository, IConfiguration configuration)
        {
            _dataContext = eMS_Context;
            _MastersRepository = mastersRepository;
            _configuration = configuration;
        }

        public async Task AddFPContractIntermediate(List<EmsTblFbvendorContractIntermediateMaster> fpvendorContractIntermediateMasters, string MID, string LocationID)
        {
 
                var existingrecs = await _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(x => (x.UpdatedBy == MID) || (x.UpdatedBy == MID && x.PositionLocation == LocationID)).ToListAsync();

                if (existingrecs.Count > 0)
                {
                    _dataContext.EmsTblFbvendorContractIntermediateMasters.RemoveRange(existingrecs);
                    await _dataContext.SaveChangesAsync();
                }

                await _dataContext.BulkInsertAsync(fpvendorContractIntermediateMasters);

                //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FP_IntrContractDataValidation");
                await _dataContext.GetProcedures().sp_EMS_FP_IntrContractDataValidationAsync();
 
        }

        public bool AddFPContractMoIntermediate(List<EmsTblFbvendorContractMonthlyInt> list, string MID)
        {
            var result1 = false;
          
                        var result = _dataContext.EmsTblFbvendorContractMonthlyInts.Where(x => x.UploadBy == MID).ToList();
                        if (result.Count > 0)
                        {
                            _dataContext.EmsTblFbvendorContractMonthlyInts.RemoveRange(result);
                            _dataContext.SaveChanges();
                        }

                        //EmsTblFPvendorContractIntermediateMaster
                        _dataContext.BulkInsert(list);
                        //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FPMo_IntrContractDataValidation");
                        _dataContext.GetProcedures().sp_EMS_FPMo_IntrContractDataValidationAsync().Wait();
                       
                        result1 = true;
                  
            return result1;
        }

        public bool AddFPMlContractIntermediate(List<EmsTblFbvendorContractMilestoneInt> fpmlvendorContractIntermediateMasters, string MID)
        {
            var result1 = false;
            //EmsTblFPvendorContractIntermediateMaster
           
                        var result = _dataContext.EmsTblFbvendorContractMilestoneInts.Where(x => x.UploadBy == MID).ToList();

                        if (result.Count > 0)
                        {
                            _dataContext.EmsTblFbvendorContractMilestoneInts.RemoveRange(result);
                            _dataContext.SaveChanges();
                        }

                        _dataContext.BulkInsert(fpmlvendorContractIntermediateMasters);
                        //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FPMl_IntrContractDataValidation");
                        _dataContext.GetProcedures().sp_EMS_FPMl_IntrContractDataValidationAsync().Wait();

            result1 = true;
                   
            return result1;
        }
        public List<EmsVwFpvendorContractWorkFlow> GetFPSendbackedListFromWorkFlow(List<int?> MastertmcidList)
        {
            //var sendbackDetails = _dataContext.EmsVwFpvendorContractWorkFlows.Where(x => MastertmcidList.Contains(x.Cmid) && x.Action == "Sentback")
            //                        .ToList();

            var sendbackDetails = _dataContext.EmsVwFpvendorContractWorkFlows.Where(x => MastertmcidList.Contains(x.Cmid) && x.Action == "Sentback").ToList();
            return sendbackDetails;

            //var sendbackDetails = _dataContext.EmsVwFpvendorContractWorkFlows.Where(x => MastertmcidList.Contains(x.Cmid) && x.Action == "Sentback")
            //                        .GroupBy(r => r.Cmid)
            //                        .Select(g => g.OrderByDescending(r => r.ActionDate).FirstOrDefault())
            //                        .ToList();
            //return sendbackDetails;
        }

        public List<string> ValidateAndSaveContract(EmsVwFpvendorContractMasterWithId contract, string mid, string name, bool isProcLead, int locId)
        {
            var validationRemarks = new List<string>();
            //This condition is not required
            //if (_dataContext.EmsVwFpvendorContractMasterWithIds.Count(fp => fp.Etwid.ToLower().Trim() == contract.Etwid.ToLower().Trim()) >= 1)
            //{
            //    validationRemarks.Add("ETW ID already exists");
            //}

            // Check for Vendor Name and Position duplicates
            // FOR FP THERE IS NOT POSITION CODE
            //if (_dataContext.EmsTblTmvendorContractMasters
            //    .Join(_dataContext.VendorMasters.Where(vm => vm.IsActive == true),
            //        tm => tm.VendorId,
            //        vm => vm.VendorId,
            //        (tm, vm) => new { tm, vm })
            //    .Any(join => join.tm.VendorId == contract.VendorId && join.tm.PositionCode == contract.PositionCode))
            //{
            //    validationRemarks.Add($"Vendor Name and Position already exist");
            //}

            // Check for duplicate fields
            //if (_dataContext.EmsVwFpvendorContractMasterWithIds
            //    .Join(_dataContext.VendorMasters.Where(vm => vm.IsActive == true),
            //        fp => fp.VendorId,
            //        vm => vm.VendorId,
            //        (fp, vm) => new { fp, vm })
            //    .Any(join =>
            //        join.fp.Etwid == contract.Etwid &&
            //        join.fp.VendorId == contract.VendorId &&
            //        //join.tm.PositionCode == contract.PositionCode &&
            //        join.fp.Sownumber == contract.Sownumber &&
            //        join.fp.Sowname == contract.Sowname))
            //{
            //    validationRemarks.Add("ETW ID, Vendor Name, SOW Number, SOW Name already exist");
            //}

            //if (validationRemarks.Any())
            //{
            //    // Combine and return validation messages if there are any issues
            //    return validationRemarks;
            //    //return string.Join(", ", validationRemarks);
            //}


            // Save the contract if validation passes
            //_dataContext.EmsTblTmvendorContractMasters.Add(contract);
            //_dataContext.SaveChanges();

            //var milestoneid = _dataContext.EmsTblBillingTypeMasters.Where(e => "milestone".Contains(e.BillingTypeName)).Select(x=>x.BillingTypeId).FirstOrDefault();

            //var FpContractMasterDetails = _dataContext.EmsVwFpvendorContractMasterWithIds
            //                                .Where(x => x.Fbcid != contract.Fbcid && x.BillingTypeId != contract.BillingTypeId).ToList();


            List<EmsVwFpvendorContractMasterWithId> FpContractMasterDetails = new List<EmsVwFpvendorContractMasterWithId>();

            int MilestoneBTypeID = _dataContext.EmsTblBillingTypeMasters.Where(x => x.BillingTypeName.ToLower().Contains("milestone")).Select(x => x.BillingTypeId).FirstOrDefault();

            if (MilestoneBTypeID == contract.BillingTypeId)
            {
                
                var mildata = (from ml in _dataContext.EmsTblFbvendorContractMilestoneMasters
                               where ml.FbcmilestoneMasterId != contract.Fbcid
                               select new EmsVwFpvendorContractMasterWithId {
                                    IsActive = ml.IsActive,
                                    DomainSkillEndDate = ml.DomainSkillEndDate,
                                    DomainSkillStartDate = ml.DomainSkillStartDate,
                                    PoendDate = ml.PoendDate,
                                    PostartDate = ml.PostartDate,
                                    SowendDate = ml.SowendDate,
                                    SowstartDate = ml.SowstartDate,
                                    UpdateDate = ml.UpdateDate,
                                    Fbcid = ml.FbcmilestoneMasterId,
                                    BillingTypeId = ml.BillingTypeId,
                                    Cmid = ml.Cmid,
                                    ContractTypeId = ml.ContractTypeId,
                                    ObsmasterId = ml.ObsmasterId,
                                    PositionLocationId = ml.PositionLocationId,
                                    ProjectOrRunId = ml.ProjectOrRunId,
                                    TowerId = ml.TowerId,
                                    VendorId = ml.VendorId,
                                    VerticalId = ml.VerticalId,
                                    Wforder = ml.Wforder,
                                    CostCenter = ml.CostCenter,
                                    DomainLeadEmail = ml.DomainLeadEmail,
                                    DomainSkillName = ml.DomainSkillName,
                                    Etwid = ml.Etwid,
                                    OldSowNumber = ml.OldSowNumber,
                                    PendingWithWhom = ml.PendingWithWhom,
                                    Ponumber = ml.Ponumber,
                                    PpmprojectId = ml.PpmprojectId,
                                    PpmprojectName = ml.PpmprojectName,
                                    RemappedMid = ml.RemappedMid,
                                    SkillSet = ml.SkillSetId,
                                    Sowname = ml.Sowname,
                                    Sownumber = ml.Sownumber,
                                    Status = ml.Status,
                                    UpdatedBy = ml.UpdatedBy,
                                    Wbsdetail = ml.Wbsdetail 
                               }).ToList();

                FpContractMasterDetails.AddRange(mildata);
                var modata = (from ml in _dataContext.EmsTblFbvendorContractMonthlyMasters
                               select new EmsVwFpvendorContractMasterWithId
                               {
                                   IsActive = ml.IsActive,
                                   AmortizationEndMonth=ml.AmortizationEndMonth,
                                   AmortizationStartMonth=ml.AmortizationStartMonth,
                                   DomainSkillEndDate = ml.DomainSkillEndDate,
                                   DomainSkillStartDate = ml.DomainSkillStartDate,
                                   PoendDate = ml.PoendDate,
                                   PostartDate = ml.PostartDate,
                                   SowendDate = ml.SowendDate,
                                   SowstartDate = ml.SowstartDate,
                                   UpdateDate = ml.UpdateDate,
                                   Fbcid = ml.FbcmontlyId,
                                   BillingTypeId = ml.BillingTypeId,
                                   Cmid = ml.Cmid,
                                   ContractTypeId = ml.ContractTypeId,
                                   ObsmasterId = ml.ObsmasterId,
                                   PositionLocationId = ml.PositionLocationId,
                                   ProjectOrRunId = ml.ProjectOrRunId,
                                   TowerId = ml.TowerId,
                                   VendorId = ml.VendorId,
                                   VerticalId = ml.VerticalId,
                                   Wforder = ml.Wforder,
                                   CostCenter = ml.CostCenter,
                                   DomainLeadEmail = ml.DomainLeadEmail,
                                   DomainSkillName = ml.DomainSkillName,
                                   Etwid = ml.Etwid,
                                   OldSowNumber = ml.OldSowNumber,
                                   PendingWithWhom = ml.PendingWithWhom,
                                   Ponumber = ml.Ponumber,
                                   PpmprojectId = ml.PpmprojectId,
                                   PpmprojectName = ml.PpmprojectName,
                                   RemappedMid = ml.RemappedMid,
                                   SkillSet = ml.SkillSet,
                                   Sowname = ml.Sowname,
                                   Sownumber = ml.Sownumber,
                                   Status = ml.Status,
                                   UpdatedBy = ml.UpdatedBy,
                                   Wbsdetail = ml.Wbsdetail
                               }).ToList();
                FpContractMasterDetails.AddRange(modata);
            }
            else
            {
                var mildata = (from ml in _dataContext.EmsTblFbvendorContractMilestoneMasters
                               select new EmsVwFpvendorContractMasterWithId
                               {
                                   IsActive = ml.IsActive,
                                   DomainSkillEndDate = ml.DomainSkillEndDate,
                                   DomainSkillStartDate = ml.DomainSkillStartDate,
                                   PoendDate = ml.PoendDate,
                                   PostartDate = ml.PostartDate,
                                   SowendDate = ml.SowendDate,
                                   SowstartDate = ml.SowstartDate,
                                   UpdateDate = ml.UpdateDate,
                                   Fbcid = ml.FbcmilestoneMasterId,
                                   BillingTypeId = ml.BillingTypeId,
                                   Cmid = ml.Cmid,
                                   ContractTypeId = ml.ContractTypeId,
                                   ObsmasterId = ml.ObsmasterId,
                                   PositionLocationId = ml.PositionLocationId,
                                   ProjectOrRunId = ml.ProjectOrRunId,
                                   TowerId = ml.TowerId,
                                   VendorId = ml.VendorId,
                                   VerticalId = ml.VerticalId,
                                   Wforder = ml.Wforder,
                                   CostCenter = ml.CostCenter,
                                   DomainLeadEmail = ml.DomainLeadEmail,
                                   DomainSkillName = ml.DomainSkillName,
                                   Etwid = ml.Etwid,
                                   OldSowNumber = ml.OldSowNumber,
                                   PendingWithWhom = ml.PendingWithWhom,
                                   Ponumber = ml.Ponumber,
                                   PpmprojectId = ml.PpmprojectId,
                                   PpmprojectName = ml.PpmprojectName,
                                   RemappedMid = ml.RemappedMid,
                                   SkillSet = ml.SkillSetId,
                                   Sowname = ml.Sowname,
                                   Sownumber = ml.Sownumber,
                                   Status = ml.Status,
                                   UpdatedBy = ml.UpdatedBy,
                                   Wbsdetail = ml.Wbsdetail
                               }).ToList();

                FpContractMasterDetails.AddRange(mildata);
                var modata = (from ml in _dataContext.EmsTblFbvendorContractMonthlyMasters
                              where ml.FbcmontlyId != contract.Fbcid
                              select new EmsVwFpvendorContractMasterWithId
                              {
                                  IsActive = ml.IsActive,
                                  AmortizationEndMonth = ml.AmortizationEndMonth,
                                  AmortizationStartMonth = ml.AmortizationStartMonth,
                                  DomainSkillEndDate = ml.DomainSkillEndDate,
                                  DomainSkillStartDate = ml.DomainSkillStartDate,
                                  PoendDate = ml.PoendDate,
                                  PostartDate = ml.PostartDate,
                                  SowendDate = ml.SowendDate,
                                  SowstartDate = ml.SowstartDate,
                                  UpdateDate = ml.UpdateDate,
                                  Fbcid = ml.FbcmontlyId,
                                  BillingTypeId = ml.BillingTypeId,
                                  Cmid = ml.Cmid,
                                  ContractTypeId = ml.ContractTypeId,
                                  ObsmasterId = ml.ObsmasterId,
                                  PositionLocationId = ml.PositionLocationId,
                                  ProjectOrRunId = ml.ProjectOrRunId,
                                  TowerId = ml.TowerId,
                                  VendorId = ml.VendorId,
                                  VerticalId = ml.VerticalId,
                                  Wforder = ml.Wforder,
                                  CostCenter = ml.CostCenter,
                                  DomainLeadEmail = ml.DomainLeadEmail,
                                  DomainSkillName = ml.DomainSkillName,
                                  Etwid = ml.Etwid,
                                  OldSowNumber = ml.OldSowNumber,
                                  PendingWithWhom = ml.PendingWithWhom,
                                  Ponumber = ml.Ponumber,
                                  PpmprojectId = ml.PpmprojectId,
                                  PpmprojectName = ml.PpmprojectName,
                                  RemappedMid = ml.RemappedMid,
                                  SkillSet = ml.SkillSet,
                                  Sowname = ml.Sowname,
                                  Sownumber = ml.Sownumber,
                                  Status = ml.Status,
                                  UpdatedBy = ml.UpdatedBy,
                                  Wbsdetail = ml.Wbsdetail
                              }).ToList();
                FpContractMasterDetails.AddRange(modata);
            }

            var validationResult = ValidateEditedFpContractDetails(FpContractMasterDetails, contract, locId);
            if (validationResult.Contains("Contract Validation successfully"))
            {
                var IsSaved = UpdateFpContractDetails(contract, mid);
                if (IsSaved)
                {
                    NextProcessOfSaveFPDataAfterSendback(mid, name, isProcLead, locId, contract.Remarks, contract);

                    validationResult.Remove("Contract Validation successfully");
                    validationResult.Add("Contract saved successfully");
                }
                else
                {
                    //return "Contract saved Incompletly";
                    validationResult.Add("Contract saved Failed");

                }
                //return "Contract saved successfully";
            }
            return validationResult;

        }
        private List<string> ValidateEditedFpContractDetails(List<EmsVwFpvendorContractMasterWithId> Maincontract, EmsVwFpvendorContractMasterWithId Editedcontract, int locId)
        {
            List<string> validationRemarks = new List<string>();
            int MilestoneBTypeID = _dataContext.EmsTblBillingTypeMasters.Where(x => x.BillingTypeName.ToLower().Contains("milestone")).Select(x => x.BillingTypeId).FirstOrDefault();
            //int MonthlyBTypeID = _dataContext.EmsTblBillingTypeMasters.Where(x => x.BillingTypeName.ToLower().Contains("monthly")).Select(x => x.BillingTypeId).FirstOrDefault();

            if (Maincontract.Count() > 0 && Editedcontract != null)
            { 
                // Check if edited contract's ETW ID is unique
                var duplicateETWID = Maincontract
                    .Where(i => i.Etwid == Editedcontract.Etwid)
                    .Any();

                if (duplicateETWID)
                {
                    validationRemarks.Add("ETW ID should be unique");
                }

                var   cExists = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Etwid == Editedcontract.Etwid).Any();
                if (cExists)
                {
                    validationRemarks.Add("ETW ID already exists in Time and Material contracts");
                }

                if (MilestoneBTypeID != Editedcontract.BillingTypeId &&  Editedcontract.AmortizationEndMonth.HasValue && Editedcontract.AmortizationStartMonth.HasValue && (Editedcontract.AmortizationEndMonth < Editedcontract.AmortizationStartMonth))
                {
                    validationRemarks.Add("Amortization end month should be greater then Amortization start month");
                }

                if (Editedcontract.PoendDate.HasValue && Editedcontract.PostartDate.HasValue && (Editedcontract.PoendDate < Editedcontract.PostartDate))
                {
                    validationRemarks.Add("PO end date should be greater then PO start date");
                }

                if (Editedcontract.DomainSkillStartDate.HasValue && Editedcontract.DomainSkillEndDate.HasValue && (Editedcontract.DomainSkillEndDate < Editedcontract.DomainSkillStartDate))
                {
                    validationRemarks.Add("DomainSkill end date should be greater then DomainSkill start date");
                }

                if (Editedcontract.SowendDate.HasValue && Editedcontract.SowstartDate.HasValue && (Editedcontract.SowendDate < Editedcontract.SowstartDate))
                {
                    validationRemarks.Add("SOW end date should be greater then SOW start date");
                }


                // Check if Vendor Name and Position Code combination is unique, 
                //var duplicateVendorPosition = Maincontract
                //    .Where(i => i.VendorId == Editedcontract.VendorId && i.Etwid == Editedcontract.Etwid)
                //    .Any();

                //if (duplicateVendorPosition)
                //{
                //    validationRemarks.Add("Vendor Name and ETWID should be unique");
                //}

                // Check if ETW ID, Vendor Name, Position Code, SOW Number, SOW Name, and SOW Type combination is unique
                var duplicateCombination = Maincontract
                    .Where(i => i.Etwid == Editedcontract.Etwid &&
                                i.VendorId == Editedcontract.VendorId &&
                                i.Sownumber == Editedcontract.Sownumber &&
                                i.Sowname == Editedcontract.Sowname )
                    .Any();

                if (duplicateCombination)
                {
                    validationRemarks.Add("ETW ID, Vendor Name, SOW Number and SOW Name should be unique");
                }

                // Check if Vendor Name exists in master table
                var validVendorName = _dataContext.VendorMasters.Any(vm => vm.VendorId == Editedcontract.VendorId && vm.IsActive);

                if (!validVendorName)
                {
                    validationRemarks.Add("Vendor Name does not exist in master");
                }
                 
 

                // Check if ProjectOrRun exists in master table
                var validProjectOrRun = _dataContext.ProjectOrRunMasters.Any(p => p.ProjectOrRunId == Editedcontract.ProjectOrRunId && p.IsActive == true);

                if (!validProjectOrRun)
                {
                    validationRemarks.Add("ProjectOrRun does not exist in master");
                }

 

                // Check if Billing Type exists in master table
                var validBillingType = _dataContext.EmsTblBillingTypeMasters.Any(b => b.BillingTypeId == Editedcontract.BillingTypeId && b.IsActive == true);

                if (!validBillingType)
                {
                    validationRemarks.Add("Billing Type does not exist in master");
                }

 

                // Check if Location exists in master table
                var validLocation = _dataContext.LocationMasters.Any(l => l.LocationId == Editedcontract.PositionLocationId && l.IsActive == true);

                if (!validLocation)
                {
                    validationRemarks.Add("Location does not exist in master");
                }

                // Check if the logged in person is mapped with the location
                if (Editedcontract.PositionLocationId != locId)
                {
                    validationRemarks.Add("You are not mapped with the location");
                }

                var lexists =_dataContext.LocationMasters.Where(x => x.LocationId == Editedcontract.PositionLocationId && x.IsActive == true).Any();

                if (lexists == false)
                {
                    validationRemarks.Add("Selected Location does not exist in Master");
                }

                int SSid = Convert.ToInt32(Editedcontract.SkillSet);
                 
                int ExistingSSid = _dataContext.EmployeeSkills.Where(x => x.SkillSet == "D1").Select(x => x.SkillId).FirstOrDefault();
                if (SSid != ExistingSSid)
                {
                    validationRemarks.Add("Skill set should be D1 for Fixed Price");
                }

                
                if (MilestoneBTypeID == Editedcontract.BillingTypeId && (Editedcontract.AmortizationEndMonth.HasValue || Editedcontract.AmortizationStartMonth.HasValue)) {
                    validationRemarks.Add("Amortization dates are not accepted for Milestone contracts");
                }
                if (MilestoneBTypeID != Editedcontract.BillingTypeId && (Editedcontract.AmortizationEndMonth.HasValue==false || Editedcontract.AmortizationStartMonth.HasValue==false))
                {
                    validationRemarks.Add("Amortization dates are mandatory for Monthly contracts");
                }


                var sownoVendor =_dataContext.EmsVwFpvendorContractMasterWithIds.Where(x => x.Sownumber == Editedcontract.Sownumber && x.VendorId != Editedcontract.VendorId).Any();
                if (sownoVendor)
                {
                    validationRemarks.Add("Same SOW number with more than one vendor");

                }
                 
                var towerexists = _dataContext.TowerNameMasters.Where(x=>x.TowerNameId == Editedcontract.TowerId && x.IsActive==true).Any();
                if (towerexists==false)
                {
                    validationRemarks.Add("Tower does not exist");

                }
                 

                if (string.IsNullOrEmpty(Editedcontract.RemappedMid) == false)
                {
                    var r = _dataContext.EmployeeMasters.Where(e => e.EmpMid == Editedcontract.RemappedMid && e.IsActive==true ).Any();
                    if (r == false)
                    {
                        validationRemarks.Add("Existing MID does not exist in employee master");
                    }

                    //var selectedR = _dataContext.EmsVwFpvendorContractMasterWithIds
                    //    .Where(x => x.Etwid == Editedcontract.Etwid && x.BillingTypeId == Editedcontract.BillingTypeId).ToList();
                    var EmpLeft = (from emp in _dataContext.EmployeeMasters
                                   join rm in _dataContext.EmsTblResourceMasters on emp.EmpMid equals rm.ViatrisMid
                                   where (Editedcontract.RemappedMid != null && Editedcontract.RemappedMid != "")
                                   && (emp.IsActive == false || rm.ResourceStatus == "Left")
                                   && Editedcontract.RemappedMid == emp.EmpMid
                                   select emp).Any();

                    if (EmpLeft)
                    {
                        validationRemarks.Add("Employee with MID mentioned in Existing MID has left organization");
                    }

                    var EmpCtrlValid = _dataContext.EmployeeMasters.Where(x => x.EmpMid == Editedcontract.RemappedMid && x.DomainSkillEdDt > Editedcontract.SowstartDate).Any();
                    if (EmpCtrlValid)
                    {
                        validationRemarks.Add("Existing MID mapped contract DomainSkill End Date should be less than the New Contract SOW Start Date");
                    }


                } 
            }
            if (validationRemarks.Count > 0) { } else { validationRemarks.Add("Contract Validation successfully"); }
            return validationRemarks;
        }

        public bool NextProcessOfSaveFPIntermediateDataToMain(string mid, string name, bool isProcLead, int locId, List<EmsTblFbvendorContractIntermediateMaster> mlMasters, List<EmsTblFbvendorContractIntermediateMaster> moMasters)
        {
            //var VendorContractMasterDetails = _dataContext.EmsVwFpvendorContractMasterWithIds
            //    .Where(x => x.UpdatedBy.ToLower() == mid.ToLower() && x.Wforder == 0)
            //    .ToList();

            if ((mlMasters.Count > 0 || moMasters.Count > 0) && isProcLead)
            {
                var currentWFOrderDetails = _dataContext.EmsTblWorkFlowMasters
                    .FirstOrDefault(x => x.Wfrole == "PMO-Contract-Mgm");

                if (currentWFOrderDetails != null)
                {
                    var nextWFOrder = currentWFOrderDetails.Wforder + 1;
                    var nextWFRole = _dataContext.EmsTblWorkFlowMasters
                        .FirstOrDefault(x => x.Wforder == nextWFOrder && x.Wfmodule == currentWFOrderDetails.Wfmodule).Wfrole;

                    var pendingWith = _dataContext.EmsTblRoleMasters
                        .Where(x => x.IsPrimaryPerson == true && x.RoleType == nextWFRole && x.LocationId == locId)
                        .Select(x => x.Mid)
                        .FirstOrDefault();

                    if (nextWFRole != null)
                    {


                        // update tmcmid and other required details in TM Main table.
                        //var contractMasterDetails = _dataContext.EmsVwFpvendorContractMasterWithIds
                        //                            .ToList();

                        //var MlcontractMasterDetails = _dataContext.EmsTblFbvendorContractMilestoneMasters
                        //                            .ToList();
                        //var MocontractMasterDetails = _dataContext.EmsTblFbvendorContractMonthlyMasters
                        //                            .ToList();
                        var skillsetlist = _dataContext.EmployeeSkills.ToList();
                        List<EmsTblFpcontractWorkFlowMilestone> mwflist = new List<EmsTblFpcontractWorkFlowMilestone>();
                        var listofuploadedmlMasters = _dataContext.EmsTblFbvendorContractMilestoneMasters
                         .Where(x => mlMasters.Select(c => c.Etwid).Contains(x.Etwid));
                        var mlcontractmts = _dataContext.EmsTblContractMasters.Where(x => mlMasters.Select(c => c.Etwid).Contains(x.PositionCode));

                        foreach (var data in mlMasters)
                        {
                            //data.Tmcmid = contractMasterDetails.FirstOrDefault(x => x.Sowname == data.Sowname && x.Etwid == data.Etwid && x.SkillSet == data.SkillSet).Cmid;
                            //data.Wforder = nextWFOrder;
                            //data.PendingWithWhom = pendingWith;
                            //data.UploadedDate = DateTime.Now; 
                            //milestone

                            if (data.BillingType.ToLower().Contains("milestone"))
                            {
                                var skillsetid = skillsetlist.Where(x => x.SkillSet == data.SkillSet).Select(x => x.SkillId)?.FirstOrDefault().ToString();
                                //var record = _dataContext.EmsTblFbvendorContractMilestoneMasters
                                //    .FirstOrDefault(x => x.Sowname == data.Sowname && x.Etwid == data.Etwid && x.SkillSetId == skillsetid);

                                var cmid = listofuploadedmlMasters
                                    .Where(x =>
                                     //c.FbcmilestoneMasterId == record.FbcmilestoneMasterId
                                     x.Sowname == data.Sowname && x.Etwid == data.Etwid && x.SkillSetId == skillsetid
                                    )
                                    .FirstOrDefault();
                                cmid.Cmid = mlcontractmts.Where(x => x.PositionCode == cmid.Etwid).Select(x => x.Cmid).FirstOrDefault();
                                cmid.Wforder = nextWFOrder;
                                cmid.PendingWithWhom = pendingWith;
                                cmid.UpdateDate = DateTime.Now;

                                var contractWorkFlow = new EmsTblFpcontractWorkFlowMilestone
                                {
                                    //Cmid = cmid.Cmid, // Replace with the actual property name for TMCID
                                    Cmid = cmid.FbcmilestoneMasterId,
                                    Role = "PMO-Contract-Mgm",
                                    ActionByMid = mid,
                                    ActionByName = name, // Replace with the actual property name for ActionByName
                                    ActionDate = DateTime.Now,
                                    Action = "Upload", // Replace with the actual action
                                    Remarks = "Successfully uploaded FP Contracts.", // Replace with the actual remarks
                                    NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                                };

                                mwflist.Add(contractWorkFlow);
                            }

                        }
                        if (mwflist.Count > 0)
                        {
                            _dataContext.EmsTblFpcontractWorkFlowMilestones.AddRange(mwflist);
                            _dataContext.SaveChanges();
                        }
                        List<EmsTblFpcontractWorkFlowMonthly> moWFlist = new List<EmsTblFpcontractWorkFlowMonthly>();
                        var listofuploadedmoMasters = _dataContext.EmsTblFbvendorContractMonthlyMasters
                            .Where(x => moMasters.Select(c => c.Etwid).Contains(x.Etwid));
                        var mocontractmts = _dataContext.EmsTblContractMasters.Where(x => moMasters.Select(c => c.Etwid).Contains(x.PositionCode));
                        foreach (var data in moMasters)
                        {
                            if (data.BillingType.ToLower().Contains("monthly") ||
                                data.BillingType.ToLower().Contains("quaterly") ||
                                data.BillingType.ToLower().Contains("yearly"))
                            {
                                var skillsetid = skillsetlist.Where(x => x.SkillSet == data.SkillSet).Select(x => x.SkillId)?.FirstOrDefault().ToString();
                                //var record = _dataContext.EmsTblFbvendorContractMonthlyMasters.FirstOrDefault(x => x.Sowname == data.Sowname && x.Etwid == data.Etwid && x.SkillSet == skillsetid);

                                var cmid = listofuploadedmoMasters.Where(x =>
                                //c.FbcmontlyId == record.FbcmontlyId
                                //&& x =>
                                x.Sowname == data.Sowname && x.Etwid == data.Etwid && x.SkillSet == skillsetid
                                ).FirstOrDefault();
                                cmid.Cmid = mocontractmts.Where(x => x.PositionCode == cmid.Etwid).Select(x => x.Cmid).FirstOrDefault();
                                cmid.Wforder = nextWFOrder;
                                cmid.PendingWithWhom = pendingWith;
                                cmid.UpdateDate = DateTime.Now;

                                var contractWorkFlow = new EmsTblFpcontractWorkFlowMonthly
                                {
                                    //Cmid = cmid.Cmid, // Replace with the actual property name for TMCID
                                    Cmid = cmid.FbcmontlyId, // Replace with the actual property name for TMCID
                                    Role = "PMO-Contract-Mgm",
                                    ActionByMid = mid,
                                    ActionByName = name, // Replace with the actual property name for ActionByName
                                    ActionDate = DateTime.Now,
                                    Action = "Upload", // Replace with the actual action
                                    Remarks = "Successfully uploaded FP Contracts.", // Replace with the actual remarks
                                    NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                                };
                                moWFlist.Add(contractWorkFlow);

                            }
                        }
                        if (moWFlist.Count > 0)
                        {
                            _dataContext.EmsTblFpcontractWorkFlowMonthlies.AddRange(moWFlist);
                            _dataContext.SaveChanges();
                        }

                        //// Save changes to the VendorContractMasterDetails
                        //_dataContext.SaveChanges();

                        //// Insert data into EMS_tblTMContractWorkFlow
                        //foreach (var data in VendorContractMasterDetails)
                        //{
                        //    var contractWorkFlow = new EmsTblTmcontractWorkFlow
                        //    {
                        //        Tmcid = data.Tmvcmid, // Replace with the actual property name for TMCID
                        //        Role = "PMO-Contract-Mgm",
                        //        ActionByMid = mid,
                        //        ActionByName = name, // Replace with the actual property name for ActionByName
                        //        ActionDate = DateTime.Now,
                        //        Action = "Upload", // Replace with the actual action
                        //        Remarks = "Successfully uploaded T&M Contracts.", // Replace with the actual remarks
                        //        NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                        //    };

                        //    _dataContext.EmsTblTmcontractWorkFlows.Add(contractWorkFlow);
                        //}

                        //_dataContext.SaveChanges();



                    }
                }
            }

            return true;
        }

        public bool NextProcessOfSaveFPDataAfterSendback(string mid, string name, bool isProcLead, int locId, string Remarks, EmsVwFpvendorContractMasterWithId Editedcontract)
        {
            var VendorContractMasterDetails = _dataContext.EmsVwFpvendorContractMasterWithIds
                .Where(x => (x.UpdatedBy.ToLower() == mid.ToLower() || x.PendingWithWhom.ToLower() == mid.ToLower()) && x.Wforder == 0 && x.Cmid == Editedcontract.Cmid
                && x.BillingTypeId == Editedcontract.BillingTypeId
                )
                .ToList();

            if (VendorContractMasterDetails.Count > 0 && isProcLead)
            {
                var currentWFOrderDetails = _dataContext.EmsTblWorkFlowMasters
                    .FirstOrDefault(x => x.Wfrole == "PMO-Contract-Mgm");

                if (currentWFOrderDetails != null)
                {
                    var nextWFOrder = currentWFOrderDetails.Wforder + 1;
                    var nextWFRole = _dataContext.EmsTblWorkFlowMasters
                        .FirstOrDefault(x => x.Wforder == nextWFOrder && x.Wfmodule == currentWFOrderDetails.Wfmodule)?.Wfrole;

                    var pendingWith = _dataContext.EmsTblRoleMasters
                        .Where(x => x.IsPrimaryPerson == true && x.RoleType == currentWFOrderDetails.Wfrole && x.LocationId == locId)
                        .Select(x => x.Mid)
                        .FirstOrDefault();

                    if (nextWFRole != null)
                    {

                        // update tmcmid and other required details in FP Main table.
                        var contractMasterDetails = _dataContext.EmsTblContractMasters.ToList();

                        var selectMaster = VendorContractMasterDetails.Select(x => x.ContractTypeId).FirstOrDefault();

                        //string billingtype = _MastersRepository.GetBillingMasterList().Where(x => x.BillingTypeId == selectMaster)
                        //                        .Select(c => c.BillingTypeName)
                        //                        ?.FirstOrDefault();

                        string ctype_ = _MastersRepository.GetContractMasterList()
                                        .Where(x => x.ContractTypeId == selectMaster).Select(c => c.ContractTypeName).FirstOrDefault();

                        if (ctype_.Contains("Monthly"))
                        {
                            var VendorContractMasterDetailsMo = _dataContext.EmsTblFbvendorContractMonthlyMasters
                                                                .Where(x => x.UpdatedBy.ToLower() == mid.ToLower() && x.Wforder == 0 && x.Cmid == Editedcontract.Cmid)
                                                                .ToList();

                            var cmidList = VendorContractMasterDetailsMo.Select(x => x.Cmid).ToList();
                            var contractMasterDetailsmo = _dataContext.EmsTblContractMasters
                                        .Where(cm => cmidList.Contains(cm.Cmid))
                                        .ToList();

                            if (VendorContractMasterDetailsMo.Count > 0 && isProcLead)
                            {
                                foreach (var data in VendorContractMasterDetailsMo)
                                {
                                    //data.Tmcmid = contractMasterDetails.FirstOrDefault(x => x.Sowname == data.Sowname && x.PositionCode == data.PositionCode && x.SkillSetId == data.SkillSetId).Cmid;
                                    data.Wforder = nextWFOrder;
                                    data.PendingWithWhom = pendingWith;
                                    //data.UploadedBy = mid;
                                    data.UpdateDate = DateTime.Now;

                                    var re = contractMasterDetailsmo.Where(x => x.Cmid == data.Cmid).FirstOrDefault();
                                    if (re!=null)
                                    {
                                        re.Sowname = data.Sowname;
                                        re.SkillSetId = Convert.ToInt32(data.SkillSet);
                                        re.PositionCode = data.Etwid;
                                    }
                                }

                                // Save changes to the VendorContractMasterDetails
                                _dataContext.SaveChanges();

                                // Insert data into EMS_tblTMContractWorkFlow
                                foreach (var data in VendorContractMasterDetailsMo)
                                {
                                    var contractWorkFlow = new EmsTblFpcontractWorkFlowMonthly
                                    {
                                        //Cmid = data.Cmid, // Replace with the actual property name for TMCID
                                        Cmid = data.FbcmontlyId, // Replace with the actual property name for TMCID
                                        Role = "PMO-Contract-Mgm",
                                        ActionByMid = mid,
                                        ActionByName = name, // Replace with the actual property name for ActionByName
                                        ActionDate = DateTime.Now,
                                        Action = "Resubmitted", // Replace with the actual action
                                        Remarks = Remarks,// "Updated Sendback Contract Successfully", // Replace with the actual remarks
                                        NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                                    };

                                    _dataContext.EmsTblFpcontractWorkFlowMonthlies.Add(contractWorkFlow);
                                }
                                _dataContext.SaveChanges();
                            }
                        }
                        else
                        {
                            var VendorContractMasterDetailsMl = _dataContext.EmsTblFbvendorContractMilestoneMasters
                                .Where(x => x.UpdatedBy.ToLower() == mid.ToLower() && x.Wforder == 0 && x.Cmid == Editedcontract.Cmid)
                                .ToList();
                            if (VendorContractMasterDetailsMl.Count > 0 && isProcLead)
                            {
                                var cmidList = VendorContractMasterDetailsMl.Select(x => x.Cmid).ToList();
                                var contractMasterDetailsml = _dataContext.EmsTblContractMasters
                                            .Where(cm => cmidList.Contains(cm.Cmid))
                                            .ToList();

                                foreach (var data in VendorContractMasterDetailsMl)
                                {
                                    //data.Tmcmid = contractMasterDetails.FirstOrDefault(x => x.Sowname == data.Sowname && x.PositionCode == data.PositionCode && x.SkillSetId == data.SkillSetId).Cmid;
                                    data.Wforder = nextWFOrder;
                                    data.PendingWithWhom = pendingWith;
                                    //data.UploadedBy = mid;
                                    data.UpdateDate = DateTime.Now;

                                    var re = contractMasterDetailsml.Where(x => x.Cmid == data.Cmid).FirstOrDefault();
                                    if (re != null)
                                    {
                                        re.Sowname = data.Sowname;
                                        re.SkillSetId = Convert.ToInt32(data.SkillSetId);
                                        re.PositionCode = data.Etwid;
                                    }
                                }

                                // Save changes to the VendorContractMasterDetails
                                _dataContext.SaveChanges();

                                // Insert data into EMS_tblTMContractWorkFlow
                                foreach (var data in VendorContractMasterDetailsMl)
                                {
                                    var contractWorkFlow = new EmsTblFpcontractWorkFlowMilestone
                                    {
                                        //Cmid = data.Cmid, // Replace with the actual property name for TMCID
                                        Cmid = data.FbcmilestoneMasterId,
                                        Role = "PMO-Contract-Mgm",
                                        ActionByMid = mid,
                                        ActionByName = name, // Replace with the actual property name for ActionByName
                                        ActionDate = DateTime.Now,
                                        Action = "Resubmitted", // Replace with the actual action
                                        Remarks = Remarks,// "Updated Sendback Contract Successfully", // Replace with the actual remarks
                                        NextWfrole = nextWFRole // Replace with the actual property name for NextWFRole
                                    };

                                    _dataContext.EmsTblFpcontractWorkFlowMilestones.Add(contractWorkFlow);
                                }
                                _dataContext.SaveChanges();
                            }
                        }


                    }
                }
            }

            return true;
        }

        public bool UpdateFpContractDetails(EmsVwFpvendorContractMasterWithId fpDetails, string mid)
        {
            if (fpDetails != null)
            {
                //var detail = _dataContext.EmsVwFpvendorContractMasterWithIds.Where(x => x.Etwid == fpDetails.Etwid && x.IsActive == true).FirstOrDefault();
                var detail = _dataContext.EmsVwFpvendorContractMasterWithIds.Where(x => x.Fbcid == fpDetails.Fbcid 
                && x.BillingTypeId == fpDetails.BillingTypeId
                && x.IsActive == true).FirstOrDefault();

                if (detail != null)
                {
                    TimeZoneInfo istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                    var ctype = _dataContext.EmsTblContractTypeMasters.Where(x => x.ContractTypeId == detail.ContractTypeId).FirstOrDefault();


                    //var bMaster = _dataContext.EmsTblBillingTypeMasters.Where(x => x.  == detail.ContractTypeId).FirstOrDefault();

                    if (ctype != null && ctype.ContractTypeName.Contains("Monthly"))
                    {
                        var fpmonthly = _dataContext.EmsTblFbvendorContractMonthlyMasters.Where(x => x.FbcmontlyId == fpDetails.Fbcid && x.IsActive == true).FirstOrDefault();
                        if (fpmonthly != null)
                        {
                            fpmonthly.AmortizationEndMonth = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.AmortizationEndMonth, istTimeZone);
                            fpmonthly.BillingTypeId = fpDetails.BillingTypeId;
                            fpmonthly.Cmid = fpDetails.Cmid;
                            //updation of contractype ID is not required
                            //fpmonthly.ContractTypeId = fpDetails.ContractTypeId;
                            fpmonthly.CostCenter = fpDetails.CostCenter;
                            fpmonthly.DomainLeadEmail = fpDetails.DomainLeadEmail;
                            fpmonthly.DomainSkillEndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.DomainSkillEndDate, istTimeZone);
                            fpmonthly.DomainSkillName = fpDetails.DomainSkillName;
                            fpmonthly.DomainSkillStartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.DomainSkillStartDate, istTimeZone);
                            fpmonthly.Etwid = fpDetails.Etwid;
                            //fpmonthly.FbcmontlyId = fpDetails.
                            fpmonthly.IsActive = fpDetails.IsActive;
                            fpmonthly.ObsmasterId = fpDetails.ObsmasterId;
                            fpmonthly.OldSowNumber = fpDetails.OldSowNumber;
                            fpmonthly.PendingWithWhom = fpDetails.PendingWithWhom.Split(':')[0].Trim();
                            fpmonthly.PoendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.PoendDate, istTimeZone);
                            fpmonthly.Ponumber = fpDetails.Ponumber;
                            fpmonthly.PositionLocationId = fpDetails.PositionLocationId;
                            fpmonthly.PostartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.PostartDate, istTimeZone);
                            fpmonthly.PpmprojectId = fpDetails.PpmprojectId;
                            fpmonthly.PpmprojectName = fpDetails.PpmprojectName;
                            fpmonthly.ProjectOrRunId = fpDetails.ProjectOrRunId;
                            fpmonthly.AmortizationStartMonth = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.AmortizationStartMonth, istTimeZone);
                            fpmonthly.RemappedMid = fpDetails.RemappedMid;
                            fpmonthly.SkillSet = fpDetails.SkillSet;
                            fpmonthly.SowendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.SowendDate, istTimeZone); 
                            fpmonthly.Sowname = fpDetails.Sowname;
                            fpmonthly.Sownumber = fpDetails.Sownumber;
                            fpmonthly.SowstartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.SowstartDate, istTimeZone); 
                            fpmonthly.Status = fpDetails.Status;
                            fpmonthly.TowerId = fpDetails.TowerId;
                            fpmonthly.UpdateDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.UpdateDate, istTimeZone); 
                            fpmonthly.UpdatedBy = fpDetails.UpdatedBy;
                            fpmonthly.VendorId = fpDetails.VendorId;
                            fpmonthly.VerticalId = fpDetails.VerticalId;
                            fpmonthly.Wbsdetail = fpDetails.Wbsdetail;
                            fpmonthly.Wforder = fpDetails.Wforder;
                        }
                    }
                    else if (ctype != null)
                    {
                        var fpmilstone = _dataContext.EmsTblFbvendorContractMilestoneMasters.Where(x => x.FbcmilestoneMasterId == fpDetails.Fbcid && x.IsActive == true).FirstOrDefault();

                        fpmilstone.BillingTypeId = fpDetails.BillingTypeId;
                        fpmilstone.Cmid = fpDetails.Cmid;
                        //fpmilstone.ContractTypeId = fpDetails.ContractTypeId;
                        fpmilstone.CostCenter = fpDetails.CostCenter;
                        fpmilstone.DomainLeadEmail = fpDetails.DomainLeadEmail;
                        fpmilstone.DomainSkillEndDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.DomainSkillEndDate, istTimeZone);
                        fpmilstone.DomainSkillName = fpDetails.DomainSkillName;
                        fpmilstone.DomainSkillStartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.DomainSkillStartDate, istTimeZone); 
                        fpmilstone.Etwid = fpDetails.Etwid;
                        fpmilstone.IsActive = fpDetails.IsActive;
                        fpmilstone.ObsmasterId = fpDetails.ObsmasterId;
                        fpmilstone.OldSowNumber = fpDetails.OldSowNumber;
                        fpmilstone.PendingWithWhom = fpDetails.PendingWithWhom.Split(':')[0].Trim();
                        fpmilstone.PoendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.PoendDate, istTimeZone); 
                        fpmilstone.Ponumber = fpDetails.Ponumber;
                        fpmilstone.PositionLocationId = fpDetails.PositionLocationId;
                        fpmilstone.PostartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.PostartDate, istTimeZone);
                        fpmilstone.PpmprojectId = fpDetails.PpmprojectId;
                        fpmilstone.PpmprojectName = fpDetails.PpmprojectName;
                        fpmilstone.ProjectOrRunId = fpDetails.ProjectOrRunId;
                        fpmilstone.RemappedMid = fpDetails.RemappedMid;
                        fpmilstone.SkillSetId = fpDetails.SkillSet;
                        fpmilstone.SowendDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.SowendDate, istTimeZone); 
                        fpmilstone.Sowname = fpDetails.Sowname;
                        fpmilstone.Sownumber = fpDetails.Sownumber;
                        fpmilstone.SowstartDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.SowstartDate, istTimeZone); 
                        fpmilstone.Status = fpDetails.Status;
                        fpmilstone.TowerId = fpDetails.TowerId;
                        fpmilstone.UpdateDate = TimeZoneInfo.ConvertTimeFromUtc((DateTime)fpDetails.UpdateDate, istTimeZone);
                        fpmilstone.UpdatedBy = fpDetails.UpdatedBy;
                        fpmilstone.VendorId = fpDetails.VendorId;
                        fpmilstone.VerticalId = fpDetails.VerticalId;
                        fpmilstone.Wbsdetail = fpDetails.Wbsdetail;
                        fpmilstone.Wforder = fpDetails.Wforder;
                    }
                    // Save changes to the database
                    _dataContext.SaveChanges();
                }

                return true;
            }

            return false;
        }



        public List<EmsVwFpvendorContractWorkFlow> GetWorkFlowsOfFPContract(int cmid, string Btype, string Ctype)
        {
            if (!Btype.ToLower().Contains("milestone"))
            {
                var result1 = (from fpmonth in _dataContext.EmsTblFpcontractWorkFlowMonthlies
                               where fpmonth.Cmid == cmid
                               select new EmsVwFpvendorContractWorkFlow
                               {
                                   Wfid = fpmonth.FpmonWfid,
                                   Cmid = fpmonth.Cmid,
                                   Role = fpmonth.Role,
                                   ActionByMid = fpmonth.ActionByMid,
                                   ActionByName = fpmonth.ActionByName,
                                   ActionDate = fpmonth.ActionDate,
                                   Action = fpmonth.Action,
                                   Remarks = fpmonth.Remarks,
                                   NextWfrole = fpmonth.NextWfrole,
                                   CType = "monthly"
                               }).ToList();
                return result1;
            }
            else
            {
                var result1 = (from fpml in _dataContext.EmsTblFpcontractWorkFlowMilestones
                               where fpml.Cmid == cmid
                               select new EmsVwFpvendorContractWorkFlow
                               {
                                   Wfid = fpml.Fpmwfid,
                                   Cmid = fpml.Cmid,
                                   Role = fpml.Role,
                                   ActionByMid = fpml.ActionByMid,
                                   ActionByName = fpml.ActionByName,
                                   ActionDate = fpml.ActionDate,
                                   Action = fpml.Action,
                                   Remarks = fpml.Remarks,
                                   NextWfrole = fpml.NextWfrole,
                                   CType = "milestone"
                               }).ToList();
                return result1;
            }
        }

        public async Task<List<EmsTblFbvendorContractIntermediateMaster>> GetFPContractIntermediateList(string EmpMID)
        {
            _dataContext.EmsTblErrorLogs.Add(new EmsTblErrorLog
            {
                ErrorMessage = "Test CICD piple line"
            });
            _dataContext.SaveChanges();

            var fbContractListFromInt = await _dataContext.EmsTblFbvendorContractIntermediateMasters.ToListAsync();
            return fbContractListFromInt;
        }


        public List<EmsTblFbvendorContractMonthlyInt> GetFPMOContractIntermediateList(string MID)
        {
            var fbContractListFromInt = _dataContext.EmsTblFbvendorContractMonthlyInts.Where(x => x.UploadBy.ToLower() == MID.ToLower()).ToList();
            return fbContractListFromInt;
        }

        public async Task<List<EmsTblFbvendorContractMilestoneInt>> GetFPContractMlIntermediateList(string MID)
        {
            var fbContractListFromInt = await _dataContext.EmsTblFbvendorContractMilestoneInts.Where(x => x.UploadBy.ToLower() == MID.ToLower()).ToListAsync();
            return fbContractListFromInt;
        }

        public bool deleteFbFromIntByIDs(List<int> ids)
        {
            var result = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(e => ids.Contains(e.FbcintId));

            if (result.Any())
            {
                _dataContext.EmsTblFbvendorContractIntermediateMasters.RemoveRange(result);
                _dataContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool deleteFbAllOrByID(string id)
        {
            int intStr;
            bool intResultTryParse = int.TryParse(id, out intStr);
            if (intResultTryParse)
            {
                var result = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(e => e.FbcintId == intStr).ToList();
                _dataContext.EmsTblFbvendorContractIntermediateMasters.RemoveRange(result);
                _dataContext.SaveChanges();
                return true;
            }
            else if (id.ToLower() == "all")
            {
                var result = _dataContext.EmsTblFbvendorContractIntermediateMasters.ToList();
                _dataContext.EmsTblFbvendorContractIntermediateMasters.RemoveRange(result);
                _dataContext.SaveChanges();
                return true;
            }
            return false;
             
            //var result =  _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(c => c.Etwid == id.ToString()).ExecuteDelete();
            //if (result == 0)
            //    return false;
            //return true;
        }

        public async Task<bool> deleteFbMoFromIntAllOrByID(string id)
        {
            int intStr;
            bool intResultTryParse = int.TryParse(id, out intStr);
            if (intResultTryParse)
            {
                //int id_ = Convert.ToInt32(id);
                var result = await _dataContext.EmsTblFbvendorContractMonthlyInts.Where(c => c.FbmonthlyIntId == intStr).ExecuteDeleteAsync();
                await _dataContext.SaveChangesAsync();
                return true;
            }
            else if (id.ToLower() == "all")
            {
                var result = await _dataContext.EmsTblFbvendorContractMonthlyInts.ExecuteDeleteAsync();
                await _dataContext.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public bool deleteFbMoFromIntByIDs(List<int> ids)
        {
            var result = _dataContext.EmsTblFbvendorContractMonthlyInts.Where(e => ids.Contains(e.FbmonthlyIntId)).ExecuteDelete();
            _dataContext.SaveChanges();
            if (result == 0)
                return false;
            return true;
        }

        public async Task<bool> deleteFbmlFromIntAllOrByID(string id)
        {

            int intStr;
            bool intResultTryParse = int.TryParse(id, out intStr);
            if (intResultTryParse)
            {
                var result = await _dataContext.EmsTblFbvendorContractMilestoneInts.Where(c => c.FbcmilestoneIntId == intStr).ExecuteDeleteAsync();
                await _dataContext.SaveChangesAsync();
                return true;
            }
            else if (id.ToLower() == "all")
            {
                var result = await _dataContext.EmsTblFbvendorContractMilestoneInts.ExecuteDeleteAsync();
                await _dataContext.SaveChangesAsync();
                return true;
            }

            return false;
        }


        public bool deleteFbmlFromIntByIDs(List<int> ids)
        {

            var result = _dataContext.EmsTblFbvendorContractMilestoneInts.Where(e => ids.Contains(e.FbcmilestoneIntId)).ExecuteDelete();
            _dataContext.SaveChanges();
            if (result == 0)
                return false;
            return true;
        }



        public bool DeleteFBSendbackData(int IntID, string mid, string name, string remarks, string Btype)
        {
            if (IntID != 0)
            {
                var idsMileDetail = _dataContext.EmsTblFbvendorContractMilestoneMasters
                    .Where(e => IntID == e.FbcmilestoneMasterId).ToList();

                var idsMonthDetail = _dataContext.EmsTblFbvendorContractMonthlyMasters
                    .Where(e => IntID == e.FbcmontlyId).ToList();

                if (idsMileDetail.Any() && Btype.ToLower().Contains("milestone"))
                {
                    var FBMilecontractMasters = _dataContext.EmsTblFbvendorContractMilestoneMasters.AsEnumerable()
                        .Where(x => x.IsActive == true &&
                                    idsMileDetail.Any(d => d.Etwid == x.Etwid && d.Sownumber == x.Sownumber))
                        .ToList();

                    if (FBMilecontractMasters.Count == 1)
                    {
                        foreach (var i in idsMileDetail)
                        {
                            //i.IsActive = false;
                            //i.PendingWithWhom = null;
                            //i.Status = "Revoked";
                            //i.Wforder = null;
                            //_dataContext.SaveChanges();

                            var contractWorkFlow = new EmsTblFpcontractWorkFlowMilestone
                            {
                                Cmid = i.FbcmilestoneMasterId, // Replace with the actual property name for TMCID
                                Role = "PMO-Contract-Mgm",
                                ActionByMid = mid,
                                ActionByName = name, // Replace with the actual property name for ActionByName
                                ActionDate = DateTime.Now,
                                Action = "Revoked", // Replace with the actual action
                                Remarks = remarks, // Replace with the actual remarks
                                NextWfrole = "PMO-Contract-Mgm" // Replace with the actual property name for NextWFRole
                            };

                            _dataContext.EmsTblFpcontractWorkFlowMilestones.Add(contractWorkFlow);
                            _dataContext.SaveChanges();

                            _dataContext.EmsTblFbvendorContractMilestoneMasters.Where(x => x.FbcmilestoneMasterId == i.FbcmilestoneMasterId).ExecuteDelete();

                        }

                        var removeFromContractMasters = _dataContext.EmsTblContractMasters.AsEnumerable()
                            .Where(x => idsMileDetail.Any(a => a.Cmid == x.Cmid))
                            .ToList();

                        foreach (var i in removeFromContractMasters)
                        {
                            //i.IsActive = false;
                            //i.Status = "Revoked";
                            //_dataContext.SaveChanges();
                            _dataContext.EmsTblContractMasters.Where(x => x.Cmid == i.Cmid).ExecuteDelete();

                        }


                    }
                    else
                    {
                        foreach (var i in idsMileDetail)
                        {
                            i.IsActive = false;
                            i.PendingWithWhom = null;
                            i.Status = "Revoked";
                            i.Wforder = null;
                            _dataContext.SaveChanges();

                            var contractWorkFlow = new EmsTblFpcontractWorkFlowMilestone
                            {
                                Cmid = i.FbcmilestoneMasterId, // Replace with the actual property name for TMCID
                                Role = "PMO-Contract-Mgm",
                                ActionByMid = mid,
                                ActionByName = name, // Replace with the actual property name for ActionByName
                                ActionDate = DateTime.Now,
                                Action = "Revoked", // Replace with the actual action
                                Remarks = remarks, // Replace with the actual remarks
                                NextWfrole = "PMO-Contract-Mgm" // Replace with the actual property name for NextWFRole
                            };

                            _dataContext.EmsTblFpcontractWorkFlowMilestones.Add(contractWorkFlow);
                            _dataContext.SaveChanges();
                        }
                    }
                }
                else
                {
                    if (idsMonthDetail.Any())
                    {
                        var FBMilecontractMasters = _dataContext.EmsTblFbvendorContractMonthlyMasters.AsEnumerable()
                            .Where(x => x.IsActive == true &&
                                        idsMonthDetail.Any(d => d.Etwid == x.Etwid && d.Sownumber == x.Sownumber))
                            .ToList();

                        if (FBMilecontractMasters.Count == 1)
                        {
                            foreach (var i in idsMonthDetail)
                            {
                                //i.IsActive = false;
                                //i.PendingWithWhom = null;
                                //i.Status = "Revoked";
                                //i.Wforder = null;
                                //_dataContext.SaveChanges();

                                var contractWorkFlow = new EmsTblFpcontractWorkFlowMonthly
                                {
                                    Cmid = i.FbcmontlyId, // Replace with the actual property name for TMCID
                                    Role = "PMO-Contract-Mgm",
                                    ActionByMid = mid,
                                    ActionByName = name, // Replace with the actual property name for ActionByName
                                    ActionDate = DateTime.Now,
                                    Action = "Revoked", // Replace with the actual action
                                    Remarks = remarks, // Replace with the actual remarks
                                    NextWfrole = "PMO-Contract-Mgm" // Replace with the actual property name for NextWFRole
                                };

                                _dataContext.EmsTblFpcontractWorkFlowMonthlies.Add(contractWorkFlow);
                                _dataContext.SaveChanges();

                                _dataContext.EmsTblFbvendorContractMonthlyMasters.Where(x => x.FbcmontlyId == i.FbcmontlyId).ExecuteDelete();

                            }

                            var removeFromContractMasters = _dataContext.EmsTblContractMasters.AsEnumerable()
                                .Where(x => idsMonthDetail.Any(a => a.Cmid == x.Cmid))
                                .ToList();

                            foreach (var i in removeFromContractMasters)
                            {
                                //i.IsActive = false;
                                //i.Status = "Revoked";
                                //_dataContext.SaveChanges();
                                _dataContext.EmsTblContractMasters.Where(x => x.Cmid == i.Cmid).ExecuteDelete();
                            }
                        }
                        else
                        {
                            foreach (var i in idsMonthDetail)
                            {
                                i.IsActive = false;
                                i.PendingWithWhom = null;
                                i.Status = "Revoked";
                                i.Wforder = null;
                                _dataContext.SaveChanges();

                                var contractWorkFlow = new EmsTblFpcontractWorkFlowMonthly
                                {
                                    Cmid = i.FbcmontlyId, // Replace with the actual property name for TMCID
                                    Role = "PMO-Contract-Mgm",
                                    ActionByMid = mid,
                                    ActionByName = name, // Replace with the actual property name for ActionByName
                                    ActionDate = DateTime.Now,
                                    Action = "Revoked", // Replace with the actual action
                                    Remarks = remarks, // Replace with the actual remarks
                                    NextWfrole = "PMO-Contract-Mgm" // Replace with the actual property name for NextWFRole
                                };

                                _dataContext.EmsTblFpcontractWorkFlowMonthlies.Add(contractWorkFlow);
                                _dataContext.SaveChanges();
                            }
                        }
                    }
                }
            }

            return true;
        }



        //public bool saveSelectedFpRows(List<EmsTblFbvendorContractIntermediateMaster> selectedRows)
        //{
        //     _dataContext.EmsTblFbvendorContractIntermediateMasters.AddRange(selectedRows);
        //    var result =  _dataContext.SaveChanges();
        //    if (result == 0)
        //        return false;
        //    return true;
        //}


        public bool saveSelectedFpMlRows(List<int> ids)
        {
            var result = _dataContext.EmsTblFbvendorContractMilestoneInts.Where(e => ids.Contains(e.FbcmilestoneIntId)).ToList();


            var selectedRows = (from fplist in result
                                select new EmsTblFbvendorContractMilestoneInt
                                {

                                    //FbcmilestoneIntId = fplist.FBCMilestoneIntID,

                                    Sownumber = fplist.Sownumber,

                                    Milestone = fplist.Milestone,

                                    MilstoneDescription = fplist.MilstoneDescription,

                                    MilestoneAmount = fplist.MilestoneAmount,

                                    Currency = fplist.Currency,

                                    ValidationRemarks = fplist.ValidationRemarks
                                }).ToList();

            _dataContext.EmsTblFbvendorContractMilestoneInts.AddRange(selectedRows);
            var result1 = _dataContext.SaveChanges();
            if (result1 == 0)
                return false;
            return true;

        }

        public bool saveSelectedFpContract(EmsTblFbvendorContractIntermediateMaster selectedContract)
        {
            _dataContext.EmsTblFbvendorContractIntermediateMasters.Update(selectedContract);
            var result = _dataContext.SaveChanges();
            if (result == 0)
                return false;
            return true;
        }

        public bool saveSelectedFMlContract(EmsTblFbvendorContractMilestoneInt selectedContract)
        {

            _dataContext.EmsTblFbvendorContractMilestoneInts.Update(selectedContract);
            var result = _dataContext.SaveChanges();
            if (result == 0)
                return false;
            return true;
        }

        public bool saveSeltedFpMlRowsPerTbl(List<int> ids)
        {
 

                var CurrenctMaster = _MastersRepository.GetCurrenctMasterList();
                //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FPMl_IntrContractDataValidation");
                _dataContext.GetProcedures().sp_EMS_FPMl_IntrContractDataValidationAsync().Wait();

                var selectedRows = _dataContext.EmsTblFbvendorContractMilestoneInts.Where(e => ids.Contains(e.FbcmilestoneIntId)
                && string.IsNullOrEmpty(e.ValidationRemarks)).ToList();

                var fpclist = (from fplist in selectedRows
                               select new EmsTblFbvendorContractMilestoneDetail
                               {
                                   //FbcmilestoneDetailId

                                   Sownumber = fplist.Sownumber,
                                   Milestone = fplist.Milestone,
                                   MilstoneDescription = fplist.MilstoneDescription,
                                   MilestoneAmount = fplist.MilestoneAmount,
                                   CurrencyId = CurrenctMaster.Where(x => x.CurrencyCode.Trim().ToLower() == fplist.Currency.Trim().ToLower()).Select(x => x.CurrencyId).FirstOrDefault(),
                                   UpdateDate = DateTime.Now,
                                   UpdatedBy = fplist.UploadBy
                               }).ToList();


                _dataContext.EmsTblFbvendorContractMilestoneDetails.AddRange(fpclist);

                _dataContext.EmsTblFbvendorContractMilestoneInts.Where(e => ids.Contains(e.FbcmilestoneIntId)).ExecuteDelete();
                var result1 = _dataContext.SaveChanges();

                var MLMasterlist = _dataContext.EmsTblFbvendorContractMilestoneMasters.Where(x => selectedRows.Select(c => c.Sownumber).Contains(x.Sownumber)).ToList();

                MLMasterlist.ForEach(item => item.IsMilestoneDataUploaded = true);
                _dataContext.SaveChanges();



                //var rowsToDelete = from r in _dataContext.EmsTblFbvendorContractMilestoneInts.AsEnumerable()
                //                   join c in list
                //                        on r.Sownumber equals c.Sownumber
                //                   select r;


                //_dataContext.EmsTblFbvendorContractMilestoneInts.RemoveRange(rowsToDelete);
                // _dataContext.SaveChanges();

                return true;
 
        }

        //public bool saveMothWiseActualls(List<EmsTblFbvendorContractMonthWiseActual> alist)
        //{

        //}

        public bool saveSeltedFpMoRowsPerTbl(List<int> ids)
        {
            var res = false;
           

                        var selectedRows = _dataContext.EmsTblFbvendorContractMonthlyInts.Where(e => ids.Contains(e.FbmonthlyIntId)).ToList();
                        var CurrenctMaster = _MastersRepository.GetCurrenctMasterList();
                        var fpclist = (from fplist in selectedRows
                                       select new EmsTblFbvendorContractMonthlyDetail
                                       {
                                           //FbmonthlyDetailId = fplist.FBMonthlyIntID,
                                           Sownumber = fplist.Sownumber,
                                           AmortizationStartDate = fplist.AmortizationStartDate,
                                           AmortizationEndDate = fplist.AmortizationEndDate,
                                           MilestoneAmount = fplist.MilestoneAmount,
                                           DurationOfMonth = fplist.DurationOfMonth,
                                           CurrencyId = CurrenctMaster.Where(x => x.CurrencyCode.Trim().ToLower() == fplist.Currency.Trim().ToLower()).Select(x => x.CurrencyId).FirstOrDefault(),
                                           UpdateDate = DateTime.Now,
                                           UpdatedBy = fplist.UploadBy
                                       }).ToList();

                        _dataContext.EmsTblFbvendorContractMonthlyDetails.AddRange(fpclist);
                        _dataContext.SaveChanges();
                        var monthwiseactuals = fpclist.SelectMany(fplist =>
                        {
                            decimal monthlyAmount = Convert.ToDecimal(fplist.MilestoneAmount) / Convert.ToInt16(fplist.DurationOfMonth);
                            int cnt = 1;
                            int yearCounter = 1;
                            int QtrNo = 1;

                            return Enumerable.Range(0, Convert.ToInt32(((fplist.AmortizationEndDate?.Year - fplist.AmortizationStartDate?.Year) * 12 + fplist.AmortizationEndDate?.Month - fplist.AmortizationStartDate?.Month)) + 1)
                                .Select(offset =>
                                {
                                    var currentDate = fplist.AmortizationStartDate?.AddMonths(offset);

                                    if (cnt == 13)
                                    {
                                        yearCounter++;
                                        cnt = 1;
                                        QtrNo = 1;
                                    }

                                    if (cnt == 4 || cnt == 7 || cnt == 10 || cnt == 13)
                                    {
                                        QtrNo++;
                                    }

                                    cnt++;


                                    return new EmsTblFbvendorContractMonthWiseActual
                                    {
                                        FbmonthlyDetailId = fplist.FbmonthlyDetailId,
                                        Year = currentDate?.Year.ToString(),
                                        Month = currentDate?.Month,
                                        YearMonth = currentDate?.ToString("yyyyMM"),
                                        //QtrNo = (((currentDate?.Month - 1) / 3) + 1).ToString(),
                                        //YearNo = yearCounter.ToString(),
                                        QtrNo = QtrNo.ToString(),//((currentDate?.Month - 1) / 3 + 1).ToString(),
                                        YearNo = yearCounter.ToString(),
                                        MonthlyAmount = monthlyAmount,
                                        UpdateDate = DateTime.Now,
                                        UpdatedBy = fplist.UpdatedBy,
                                        IsActive = true
                                    };
                                });
                        }).ToList();


                        //var result2 = saveMothWiseActualls(monthwiseactuals);
                        _dataContext.EmsTblFbvendorContractMonthWiseActuals.AddRange(monthwiseactuals);

                        int result1 = _dataContext.SaveChanges();
            //if (result1 == 0)
            //    return false;
            //return true;

            //var result1 =  _dataContext.SaveChanges();
            //if (result1 == 0)
            //    return false;

            //var rowsToDelete = from r in _dataContext.EmsTblFbvendorContractMonthlyInts.AsEnumerable()
            //                   join c in list
            //                        on r.Sownumber equals c.Sownumber
            //                   select r;

            //_dataContext.EmsTblFbvendorContractMonthlyInts.RemoveRange(rowsToDelete);

            var MoMasterlist = _dataContext.EmsTblFbvendorContractMonthlyMasters.Where(x => selectedRows.Select(c => c.Sownumber).Contains(x.Sownumber)).ToList();

            MoMasterlist.ForEach(item => item.IsMonthlyDataUploaded = true);
            _dataContext.SaveChanges();


            var introws = _dataContext.EmsTblFbvendorContractMonthlyInts.Where(e => ids.Contains(e.FbmonthlyIntId)).ExecuteDelete();
                        _dataContext.SaveChanges();

                       
                        res = true;
                   
            return res;
        }





        //public bool saveSeltedFpRowsPerTbl(List<EmsTblFbvendorContractMilestoneMaster> Milestonedt,
        //    List<EmsTblFbvendorContractMonthlyMaster> Monthlydt,
        //    List<EmsTblContractMaster> ContractMasterData)

        //public async void CallSp_sp_EMS_FP_IntrContractDataValidationAsync()
        //{
        //    await _dataContext.Procedures.sp_EMS_FP_IntrContractDataValidationAsync();
        //}

        public bool saveSeltedFpRowsPerTbl(List<int> ids, int WFOrder, List<EmsTblRoleMaster> FinanceMgrList, string mid, string name, int locId)
        {
            var InvProcessingConsidered = _configuration.GetSection("AppSettings").GetSection("InvoiceProcessingConsidered").Value;
            if (InvProcessingConsidered == null)
            {
                throw new InvalidOperationException($"Value for key InvoiceProcessingConsidered not found in appsettings.json");
            }

            //var strategy = _dataContext.Database.CreateExecutionStrategy();

            //strategy.Execute(() =>
            //{
            //    try {
            //    BeginTransaction();

            //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FP_IntrContractDataValidation");
            _dataContext.GetProcedures().sp_EMS_FP_IntrContractDataValidationAsync().Wait();

            //_dataContext.Procedures.sp_EMS_FP_IntrContractDataValidationAsync();
            //CallSp_sp_EMS_FP_IntrContractDataValidationAsync();

            var milestonelist = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(e => ids.Contains(e.FbcintId)
            && e.ContractType.Trim().ToLower() == "fixed price milestone"
            && string.IsNullOrEmpty(e.ValidationRemarks)).ToList();

            var monthlylist = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(e => ids.Contains(e.FbcintId)
            && e.ContractType.Trim().ToLower() == "fixed price monthly"
            && string.IsNullOrEmpty(e.ValidationRemarks)).ToList();

            var vendorMasterList = _MastersRepository.GetVendorMasterList();
            var verticalMasterList = _MastersRepository.GetVerticalMasterList();
            var towerMasterList = _MastersRepository.GetTowerMasterList();
            var projectOrRun = _MastersRepository.GetprojectOrRunMasterList();
            var positionLocation = _MastersRepository.GetLocationData();
            var obsMasterList = _MastersRepository.GetOBSMasterList();
            var skillsetMasterList = _MastersRepository.GetSkillMasterList();
            var contractMasterList = _MastersRepository.GetContractMasterList();
            var billingMasterlist = _MastersRepository.GetBillingMasterList();
            //var ContractMasterData = new List<EmsTblContractMaster>();
             
            var FPMilestoneList = new List<EmsTblFbvendorContractMilestoneMaster>();
            if (milestonelist.Count() > 0)
            {
                FPMilestoneList = (from fplist in milestonelist
                                   select new EmsTblFbvendorContractMilestoneMaster
                                   {
                                       FbcmilestoneMasterId = 0,
                                       Etwid = fplist.Etwid,
                                       Cmid = 0,
                                       VendorId = vendorMasterList.Where(x => x.VendorName.Trim().ToLower() == fplist.VendorName.Trim().ToLower()).Select(x => x.VendorId).FirstOrDefault(),
                                       PositionLocationId = positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault(),
                                       OldSowNumber = fplist.OldSowNumber,
                                       Sownumber = fplist.Sownumber,
                                       Sowname = fplist.Sowname,
                                       SowstartDate = fplist.SowstartDate,
                                       SowendDate = fplist.SowendDate,
                                       Ponumber = fplist.Ponumber,
                                       PostartDate = fplist.PostartDate,
                                       PoendDate = fplist.PoendDate,
                                       PpmprojectId = fplist.PpmprojectId,
                                       PpmprojectName = fplist.PpmprojectName,
                                       VerticalId = verticalMasterList.Where(x => x.VerticalName.Trim().ToLower() == fplist.Vertical.Trim().ToLower()).Select(x => x.VerticalId).FirstOrDefault(),
                                       TowerId = towerMasterList.Where(x => x.TowerName.Trim().ToLower() == fplist.Tower.Trim().ToLower()).Select(x => x.TowerNameId).FirstOrDefault(),
                                       DomainLeadEmail = fplist.DomainLeadEmail,
                                       CostCenter = fplist.CostCenter,
                                       ObsmasterId = obsMasterList.Where(x => x.ObsmasterName.Trim().ToLower() == fplist.Obs.Trim().ToLower()).Select(x => x.ObsmasterId).FirstOrDefault(),
                                       //DomainSkillName = skillsetMasterList.Where(x => x.SkillSet == fplist.DomainSkillName).Select(x => x.SkillId).FirstOrDefault().ToString(),
                                       //SkillSet = fplist.SkillSet,
                                       DomainSkillName = fplist.DomainSkillName,
                                       SkillSetId = skillsetMasterList.Where(x => x.SkillSet.Trim().ToLower() == fplist.SkillSet.Trim().ToLower()).Select(x => x.SkillId).FirstOrDefault().ToString(),
                                       DomainSkillStartDate = fplist.DomainSkillStartDate,
                                       DomainSkillEndDate = fplist.DomainSkillEndDate,
                                       Wbsdetail = fplist.Wbsdetail,
                                       ProjectOrRunId = projectOrRun.Where(x => x.ProjectOrRun.Trim().ToLower() == fplist.ProjectOrRun.Trim().ToLower()).Select(x => x.ProjectOrRunId).FirstOrDefault(),
                                       BillingTypeId = billingMasterlist.Where(x => x.BillingTypeName.Trim().ToLower() == "milestone based").Select(x => x.BillingTypeId).FirstOrDefault(),
                                       RemappedMid = fplist.RemappedMid,
                                       UpdateDate = DateTime.Now,
                                       UpdatedBy = fplist.UpdatedBy,
                                       ContractTypeId = contractMasterList.Where(x => x.ContractTypeName.Trim().ToLower() == fplist.ContractType.Trim().ToLower()).Select(x => x.ContractTypeId).FirstOrDefault(),
                                       Wforder = WFOrder,
                                       Status = "Pending",
                                       IsActive = true,

                                       IsMilestoneDataUploaded = InvProcessingConsidered.ToLower() == "no" ? true : false,
                                       //check apsetting and if InvoiceProcessingConsidered == "No" then
                                       //IsMonthlyDataUploaded = 1 
                                       //else
                                       //IsMonthlyDataUploaded = 0

                                       PendingWithWhom = FinanceMgrList.Where(x => x.LocationId ==
                                       positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault()
                                        ).Select(a => a.Mid).FirstOrDefault()
                                   }).ToList();

                var distinctlist1 = FPMilestoneList.GroupBy(x => x.Etwid).Select(g => g.First());

                if (distinctlist1 != null && distinctlist1.Count() > 0)
                {
                    foreach (var item in distinctlist1)
                    {
                        if (item != null)
                        {
                            var i = new EmsTblContractMaster();
                            i.Sowname = item.Sowname;
                            i.Status = "Pending";
                            //i.SowStartDate = item.SowstartDate;
                            i.PositionCode = item.Etwid;
                            i.SkillSetId = int.TryParse(item.SkillSetId, out int skillresult) ? (int?)skillresult : null;
                            i.IsActive = true;
                            i.ContractTypeId = item.ContractTypeId;
                            //ContractMasterData.Add(i);
                            _dataContext.EmsTblContractMasters.AddRange(i);
                            _dataContext.SaveChanges();

                            var templist = FPMilestoneList.Where(x => x.Etwid == item.Etwid)
                                .Select(item => { item.Cmid = i.Cmid; return item; }).ToList();

                            FPMilestoneList.RemoveAll(x => x.Etwid == item.Etwid);
                            FPMilestoneList.AddRange(templist);



                        }
                    }
                }

            }


            _dataContext.EmsTblFbvendorContractMilestoneMasters.AddRange(FPMilestoneList);
            _dataContext.SaveChanges();


            if (monthlylist.Count() > 0)
            {
                var FPMonthlyList = (from fplist in monthlylist
                                     select new EmsTblFbvendorContractMonthlyMaster
                                     {
                                         FbcmontlyId = 0,
                                         Etwid = fplist.Etwid,
                                         VendorId = vendorMasterList.Where(x => x.VendorName.Trim().ToLower() == fplist.VendorName.Trim().ToLower()).Select(x => x.VendorId).FirstOrDefault(),
                                         PositionLocationId = positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault(),
                                         OldSowNumber = fplist.OldSowNumber,
                                         Sownumber = fplist.Sownumber,
                                         Sowname = fplist.Sowname,
                                         SowstartDate = fplist.SowstartDate,
                                         SowendDate = fplist.SowendDate,
                                         AmortizationStartMonth = Convert.ToDateTime(fplist.AmortizationStartMonth),
                                         AmortizationEndMonth = fplist.AmortizationEndMonth,
                                         Ponumber = fplist.Ponumber,
                                         PostartDate = fplist.PostartDate,
                                         PoendDate = fplist.PoendDate,
                                         PpmprojectId = fplist.PpmprojectId,
                                         PpmprojectName = fplist.PpmprojectName,
                                         VerticalId = verticalMasterList.Where(x => x.VerticalName.Trim().ToLower() == fplist.Vertical.Trim().ToLower()).Select(x => x.VerticalId).FirstOrDefault(),
                                         TowerId = towerMasterList.Where(x => x.TowerName.Trim().ToLower() == fplist.Tower.Trim().ToLower()).Select(x => x.TowerNameId).FirstOrDefault(),
                                         DomainLeadEmail = fplist.DomainLeadEmail,
                                         CostCenter = fplist.CostCenter,
                                         ObsmasterId = obsMasterList.Where(x => x.ObsmasterName.Trim().ToLower() == fplist.Obs.Trim().ToLower()).Select(x => x.ObsmasterId).FirstOrDefault(),
                                         //DomainSkillName = skillsetMasterList.Where(x => x.SkillSet == fplist.DomainSkillName).Select(x => x.SkillId).FirstOrDefault().ToString(),
                                         //SkillSet = fplist.SkillSet,
                                         DomainSkillName = fplist.DomainSkillName,
                                         SkillSet = skillsetMasterList.Where(x => x.SkillSet.Trim().ToLower() == fplist.SkillSet.Trim().ToLower()).Select(x => x.SkillId).FirstOrDefault().ToString(),
                                         DomainSkillStartDate = fplist.DomainSkillStartDate,
                                         DomainSkillEndDate = fplist.DomainSkillEndDate,
                                         Wbsdetail = fplist.Wbsdetail,
                                         ProjectOrRunId = projectOrRun.Where(x => x.ProjectOrRun.Trim().ToLower() == fplist.ProjectOrRun.Trim().ToLower()).Select(x => x.ProjectOrRunId).FirstOrDefault(),
                                         ContractTypeId = contractMasterList.Where(x => x.ContractTypeName.Trim().ToLower() == fplist.ContractType.Trim().ToLower()).Select(x => x.ContractTypeId).FirstOrDefault(),
                                         //BillingType = fplist.BillingType,
                                         BillingTypeId = billingMasterlist.Where(x => x.BillingTypeName.Trim().ToLower() == fplist.BillingType.Trim().ToLower()).Select(x => x.BillingTypeId).FirstOrDefault(),
                                         RemappedMid = fplist.RemappedMid,
                                         UpdateDate = DateTime.Now,
                                         UpdatedBy = fplist.UpdatedBy,
                                         Wforder = WFOrder,
                                         Status = "Pending",
                                         IsActive = true,
                                         IsMonthlyDataUploaded = InvProcessingConsidered.ToLower()=="no"? true: false,
                                         //check apsetting and if InvoiceProcessingConsidered == "No" then
                                         //IsMonthlyDataUploaded = 1 
                                         //else
                                         //IsMonthlyDataUploaded = 0
                                         PendingWithWhom = FinanceMgrList.Where(x => x.LocationId ==
                                         positionLocation.Where(x => x.LocationName.Trim().ToLower() == fplist.PositionLocation.Trim().ToLower()).Select(x => x.LocationId).FirstOrDefault()
                                         ).Select(a => a.Mid).FirstOrDefault()
                                     }).ToList();

                var distinctlist2 = FPMonthlyList.GroupBy(x => x.Etwid).Select(g => g.First());
                if (distinctlist2 != null && distinctlist2.Count() > 0)
                {
                    foreach (var item in distinctlist2)
                    {
                        if (item != null)
                        {
                            var i = new EmsTblContractMaster();
                            i.Sowname = item.Sowname;
                            i.Status = "Pending";
                            //i.SowStartDate = item.SowstartDate;
                            i.PositionCode = item.Etwid;
                            i.SkillSetId = int.TryParse(item.SkillSet, out int skillresult) ? (int?)skillresult : null;
                            i.IsActive = true;
                            i.ContractTypeId = Convert.ToInt32(item.ContractTypeId);
                            //ContractMasterData.Add(i);
                            _dataContext.EmsTblContractMasters.AddRange(i);
                            _dataContext.SaveChanges();

                            var templist = FPMonthlyList.Where(x => x.Etwid == item.Etwid)
                            .Select(item => { item.Cmid = i.Cmid; return item; }).ToList();

                            FPMonthlyList.RemoveAll(x => x.Etwid == item.Etwid);
                            FPMonthlyList.AddRange(templist);
                        }
                    }
                }
                _dataContext.EmsTblFbvendorContractMonthlyMasters.AddRange(FPMonthlyList);

            }

            _dataContext.SaveChanges();
             
            NextProcessOfSaveFPIntermediateDataToMain(mid, name, true, locId, milestonelist, monthlylist);

            _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(e => ids.Contains(e.FbcintId)).ExecuteDelete();
            _dataContext.SaveChanges();

            //        CommitTransaction();
            //        return true;
            //    }
            //    catch{
            //        RollbackTransaction();
            //        throw;  
            //    }
            //});
            return true;
            //@################################################################################

            //_dataContext.Database.ExecuteSqlRaw("EXEC sp_EMS_FP_IntrContractDataValidation");
            //Milestonedt = Milestonedt
            //    .Where(milestone => !_dataContext.EmsTblFbvendorContractIntermediateMasters.Any(intermediate => 
            //    intermediate.Sownumber.Trim().ToLower() == milestone.Sownumber.Trim().ToLower() 
            //    && !string.IsNullOrEmpty(intermediate.ValidationRemarks))
            //    ).ToList();

            //_dataContext.EmsTblFbvendorContractMilestoneMasters.AddRange(Milestonedt);
            //var result1 = _dataContext.SaveChanges();
            //foreach (var record in Milestonedt)
            //{
            //    var result = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(x => x.Sownumber.Trim().ToLower() == record.Sownumber.Trim().ToLower()).FirstOrDefault();
            //    if (result != null)
            //    {
            //        _dataContext.EmsTblFbvendorContractIntermediateMasters.Remove(result);
            //        _dataContext.SaveChanges();
            //    }
            //}

            //_dataContext.EmsTblFbvendorContractMonthlyMasters.AddRange(Monthlydt);
            //var result2 = _dataContext.SaveChanges();
            //foreach (var record in Monthlydt)
            //{
            //    var result = _dataContext.EmsTblFbvendorContractIntermediateMasters.Where(x => x.Sownumber.Trim().ToLower() == record.Sownumber.Trim().ToLower()).FirstOrDefault();
            //    if (result != null)
            //    {
            //        _dataContext.EmsTblFbvendorContractIntermediateMasters.Remove(result);
            //        _dataContext.SaveChanges();
            //    }
            //}

            //_dataContext.EmsTblContractMasters.AddRange(ContractMasterData);
            //_dataContext.SaveChanges();

            //if (result1 == 0 || result2 == 0)
            //    return false;


        }

        //public bool saveSeltedFpMoRowsPerTbl(List<EmsTblFbvendorContractMonthlyMaster> list)
        //{
        //     _dataContext.EmsTblFbvendorContractMonthlyMasters.AddRange(list);
        //    var result =  _dataContext.SaveChanges();
        //    if (result == 0)
        //        return false;
        //    return true;
        //}


        //public Task<bool> deleteFbAllOrByID(string id)
        //{
        //    throw new NotImplementedException();
        //}
        #region "FP Contract Approval Workflow"
        public List<SP_EMS_GetFPMilestoneContractPendingListResult> GetFPMilestoneContractPendingList(int WFOrder, int Location)
        {
            //WFOrder = 1 for Finance Manager

            // var result = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Wforder == WFOrder).ToList();
            var result = _dataContext.GetProcedures().SP_EMS_GetFPMilestoneContractPendingListAsync(WFOrder, Location).Result;
            return result;
        }


        public List<sp_EMS_GetFPVendorContractMainMasterDetailsResult> GetFPContractMainList(string filter,int locationID,DateTime? fromdate,DateTime? todate, string ActiveFilter)
        {
            var result = _dataContext.GetProcedures().sp_EMS_GetFPVendorContractMainMasterDetailsAsync(filter, locationID, fromdate, todate, ActiveFilter).Result.ToList();
            return result;
        }

        public List<EmsTblFbvendorContractMilestoneDetail> GetFPMilestoneContractDetail(string sowNumber)
        {
            var result = _dataContext.EmsTblFbvendorContractMilestoneDetails.Where(x => x.Sownumber == sowNumber).ToList();

            return result;
        }
        public List<EmsTblWorkFlowMaster> GetFPContractWFOrder()
        {
            //Fetch all workflow details of procurement module and that flow is mandatory
            //WFOrder = 1 for Finance Manager
            var _objwfmaster = _dataContext.EmsTblWorkFlowMasters.Where(x => x.Wfmodule == "Procurement" && x.IsMandatory == true).ToList();
            return _objwfmaster;
        }

        public string PostFPMilestoneContractApproval(List<EmsTblFbvendorContractMilestoneMaster> vContract, List<EmsTblFpcontractWorkFlowMilestone> wf, List<EmsTblContractMaster> Contract)
        {
            var result = "Fail";
            //Push into main table and workflow table
            if (vContract != null)
            {
              
                            //Update Pendingwith and WFOrdr
                            var propToInclude = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.PendingWithWhom), nameof(EmsTblFbvendorContractMilestoneMaster.Wforder), nameof(EmsTblFbvendorContractMilestoneMaster.Status) };
                            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
                            _dataContext.BulkUpdate(vContract, bulkConfig);

                            //Insert into workflow history table
                            _dataContext.BulkInsert(wf);

                            //Update contract master as open if approved
                            var propToIncludeContract = new List<string> { nameof(EmsTblContractMaster.Status) };
                            var bulkConfigContract = new BulkConfig { PropertiesToInclude = propToIncludeContract };
                            _dataContext.BulkUpdate(Contract, bulkConfigContract);
                            // _dataContext.SaveChanges();


                            if (vContract.Where(x => x.RemappedMid != null && x.RemappedMid != "").Any())
                            {
                                var loggedby = wf.Select(x => x.ActionByMid).FirstOrDefault() ?? "";
                                 result = PostResourcemapping(vContract, loggedby);
                            }
                           
                            result = "success";
                       


            }
            return result;
        }
        public string PostResourcemapping(List<EmsTblFbvendorContractMilestoneMaster> vContract, string loggedIN = "")
        {
            //Update Resource Master table for Remapped MID,
            //if current contract end date of remapped person is less than current date then update EmsTblFPcontractResourceMapping with false and insert as well as overwrite position code in resourcemaster if it is active
            //.. else scheduler will update EmsTblFPcontractResourceMapping and resource master if Current SOW end date is less than current date

            string dateString = DateTime.Now.Date.ToString("yyyy-MM-dd");

            // Parse the yyyy-MM-dd string back to DateTime
            DateTime parsedDate = DateTime.ParseExact(dateString, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            //var vContract = _dataContext.EmsTblFbvendorContractMonthlyMasters.ToList();

            var otherContracts = (from v in vContract
                                  join m in _dataContext.EmsTblFbvendorContractMilestoneMasters on v.Etwid equals m.Etwid
                                  where v.Status == "Closed"
                                  select new EmsTblFbvendorContractMilestoneMaster()
                                  {
                                       FbcmilestoneMasterId  = m.FbcmilestoneMasterId,
                                      PendingWithWhom = null,
                                      Wforder = null,
                                  });
            //Update Pendingwith and WFOrdr for other vendors
            var propToInclude1 = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.PendingWithWhom), nameof(EmsTblFbvendorContractMilestoneMaster.Wforder) };
            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude1 };

            _dataContext.BulkUpdate(otherContracts, bulkConfig);

            

            var contractResourceupdate = (from v in vContract
                                          join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                          join m in _dataContext.EmsTblFpcontractResourceMappings on r.Rmid equals m.Rmid
                                          join vmcon in _dataContext.EmsTblFbvendorContractMilestoneMasters on m.Cmid equals vmcon.Cmid
                                          where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                      && vmcon.SowendDate < parsedDate && v.SowstartDate <= parsedDate
                                        && v.RemappedMid != null && v.RemappedMid != ""
                                          select new EmsTblFpcontractResourceMapping()
                                          {
                                              Cmid = m.Cmid,
                                              IsMappingActive = false,
                                              UnMappedDate = DateAndTime.Now,
                                              UnMappedBy = loggedIN,
                                              FpcrmapId = m.FpcrmapId,
                                          }).ToList();


            var propToIncludeResource = new List<string> { nameof(EmsTblFpcontractResourceMapping.IsMappingActive), nameof(EmsTblFpcontractResourceMapping.UnMappedBy), nameof(EmsTblFpcontractResourceMapping.UnMappedDate) };
            var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
            _dataContext.BulkUpdate(contractResourceupdate, Resource);


            //If above condition is true then proceed to next updates
            if (contractResourceupdate.Any())
            {
                //Insert resource mapping table for remapped mid if Current SOW completed
                var contractResourceInsert = (from v in vContract
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join vm in _dataContext.EmsTblFbvendorContractMilestoneMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.Etwid }
                                              where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                              && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate
                                              && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblFpcontractResourceMapping()
                                              {
                                                  Cmid = v.Cmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = loggedIN, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              }).ToList();
                _dataContext.BulkInsert(contractResourceInsert);

                //Overwrite the position code of resource if SOW end date is less than current date

                var resourePositionUpdate = (from v in vContract
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             join vm in _dataContext.EmsTblFbvendorContractMilestoneMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.Etwid }
                                             where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate && v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.Etwid,
                                                 ViatrisMid=r.ViatrisMid

                                             }).ToList();
                var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                _dataContext.BulkUpdate(resourePositionUpdate, Position);


                //To make Remapped MID null after mapping done.

                var mappedResource = (from r in resourePositionUpdate
                                      join tcm in _dataContext.EmsTblFbvendorContractMilestoneMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.Etwid, mid = tcm.RemappedMid }
                                      select new EmsTblFbvendorContractMilestoneMaster()
                                      {
                                           FbcmilestoneMasterId=tcm.FbcmilestoneMasterId,
                                          RemappedMid = null
                                      });
                
                var propToInclude2 = new List<string> { nameof(EmsTblFbvendorContractMilestoneMaster.RemappedMid) };
                var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };
                _dataContext.BulkUpdate(mappedResource, bulkConfig1);

                // Call the SP to put reconcile in employeemaster of AMS
                var remappedContracts = vContract.Where(x => x.RemappedMid != "" && x.RemappedMid != null).ToList();
                foreach (var v in remappedContracts)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMilestone", "Update", v.RemappedMid).Wait();
                    _dataContext.SaveChanges();
                }
                 // throw new InvalidOperationException("Logfile cannot be read-only");
            }
            //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
            List<EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();
            ress = (from v in vContract
                    where v.RemappedMid != null && v.RemappedMid != ""
                    select new EmsTblRemappedResourceWdExtension
                    {
                        EmpMid = v.RemappedMid,
                        EmpName = null,
                        PositionCode = v.Etwid,
                        Sownumber = v.Sownumber,
                        DomainSkillEndDate = v.DomainSkillEndDate,
                        Ritm = null
                    }).ToList();

            ress.Join(
                _dataContext.EmployeeMasters,
                r => r.EmpMid,
                e => e.EmpMid,
                (r, e) => { r.EmpName = e.EmpName; return r; }
            ).ToList();

            _dataContext.BulkInsert(ress);
            return "success";
        }

        public List<SP_EMS_GetFPMonthlyContractPendingListResult> GetFPMonthlyContractPendingList(int WFOrder, int Location)
        {
            //WFOrder = 1 for Finance Manager

            // var result = _dataContext.EmsTblTmvendorContractMasters.Where(x => x.Wforder == WFOrder).ToList();
            var result = _dataContext.GetProcedures().SP_EMS_GetFPMonthlyContractPendingListAsync(WFOrder, Location).Result;
            return result;
        }
        public List<EmsTblFbvendorContractMonthlyDetail> GetFPMonthlyContractDetail(string sowNumber)
        {
            var result = _dataContext.EmsTblFbvendorContractMonthlyDetails.Where(x => x.Sownumber == sowNumber).ToList();

            return result;
        }
        public string PostFPMonthlyContractApproval(List<EmsTblFbvendorContractMonthlyMaster> vContract, List<EmsTblFpcontractWorkFlowMonthly> wf, List<EmsTblContractMaster> Contract)
        {
            var result = "Fail";
            //Push into main table and workflow table
            if (vContract != null)
            {
              
                            //Update Pendingwith and WFOrdr
                            var propToInclude = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.PendingWithWhom), nameof(EmsTblFbvendorContractMonthlyMaster.Wforder), nameof(EmsTblFbvendorContractMonthlyMaster.Status) };
                            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude };
                            _dataContext.BulkUpdate(vContract, bulkConfig);

                            //Insert into workflow history table
                            _dataContext.BulkInsert(wf);

                    

                            //Update contract master as open if approved
                            var propToIncludeContract = new List<string> { nameof(EmsTblContractMaster.Status) };
                            var bulkConfigContract = new BulkConfig { PropertiesToInclude = propToIncludeContract };
                            _dataContext.BulkUpdate(Contract, bulkConfigContract);

                            if (vContract.Where(x => x.RemappedMid != null && x.RemappedMid != "").Any())
                            {
                                var loggedby = wf.Select(x => x.ActionByMid).FirstOrDefault() ?? "";
                                 result = PostResourcemappingForFbvendorContractMonthlyMaster(vContract, loggedby);
 
                            }
 

                result = "success";
                       
                
            }
            return result;
        }


        public string PostResourcemappingForFbvendorContractMonthlyMaster(List<EmsTblFbvendorContractMonthlyMaster> vContract, string loggedIN = "")
        {
            //Update Resource Master table for Remapped MID,
            //if current contract end date of remapped person is less than current date then update EmsTblFPcontractResourceMapping with false and insert as well as overwrite position code in resourcemaster if it is active
            //.. else scheduler will update EmsTblFPcontractResourceMapping and resource master if Current SOW end date is less than current date

            string dateString = DateTime.Now.Date.ToString("yyyy-MM-dd");

            // Parse the yyyy-MM-dd string back to DateTime
            DateTime parsedDate = DateTime.ParseExact(dateString, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            //var vContract = _dataContext.EmsTblFbvendorContractMonthlyMasters.ToList();

            var otherContracts = (from v in vContract
                                  join m in _dataContext.EmsTblFbvendorContractMonthlyMasters on v.Etwid equals m.Etwid
                                  where v.Status == "Closed"
                                  select new EmsTblFbvendorContractMonthlyMaster()
                                  {
                                      FbcmontlyId = m.FbcmontlyId,
                                      PendingWithWhom = null,
                                      Wforder = null,
                                  });
            //Update Pendingwith and WFOrdr for other vendors
            var propToInclude1 = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.PendingWithWhom), nameof(EmsTblFbvendorContractMonthlyMaster.Wforder) };
            var bulkConfig = new BulkConfig { PropertiesToInclude = propToInclude1 };

            _dataContext.BulkUpdate(otherContracts, bulkConfig);
             
            var contractResourceupdate = (from v in vContract
                                          join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                          join m in _dataContext.EmsTblFpcontractResourceMappings on r.Rmid equals m.Rmid
                                          join vmcon in _dataContext.EmsTblFbvendorContractMonthlyMasters on m.Cmid equals vmcon.Cmid
                                          where v.Status == "Closed" && m.IsMappingActive == true && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                      && vmcon.SowendDate < parsedDate && v.SowstartDate <= parsedDate
                                        && v.RemappedMid != null && v.RemappedMid != ""
                                          select new EmsTblFpcontractResourceMapping()
                                          {
                                              Cmid = m.Cmid,
                                              IsMappingActive = false,
                                              UnMappedDate = DateAndTime.Now,
                                              UnMappedBy = loggedIN,
                                              FpcrmapId = m.FpcrmapId,
                                          }).ToList();


            var propToIncludeResource = new List<string> { nameof(EmsTblFpcontractResourceMapping.IsMappingActive), nameof(EmsTblFpcontractResourceMapping.UnMappedBy), nameof(EmsTblFpcontractResourceMapping.UnMappedDate) };
            var Resource = new BulkConfig { PropertiesToInclude = propToIncludeResource };
            _dataContext.BulkUpdate(contractResourceupdate, Resource);


            //If above condition is true then proceed to next updates
            if (contractResourceupdate.Any())
            {
                //Insert resource mapping table for remapped mid if Current SOW completed
                var contractResourceInsert = (from v in vContract
                                              join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                              join vm in _dataContext.EmsTblFbvendorContractMonthlyMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.Etwid }
                                              where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                              && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate
                                              && v.RemappedMid != null && v.RemappedMid != ""
                                              select new EmsTblFpcontractResourceMapping()
                                              {
                                                  Cmid = v.Cmid,
                                                  IsMappingActive = true,
                                                  Rmid = r.Rmid,
                                                  MappedBy = loggedIN, //Taking lgged in MID
                                                  MappedDate = DateAndTime.Now,
                                                  IsAmsupdated = true
                                              }).ToList();
                _dataContext.BulkInsert(contractResourceInsert);

                //Overwrite the position code of resource if SOW end date is less than current date

                var resourePositionUpdate = (from v in vContract
                                             join r in _dataContext.EmsTblResourceMasters on v.RemappedMid equals r.ViatrisMid
                                             join vm in _dataContext.EmsTblFbvendorContractMonthlyMasters on new { vendorId = r.VendorId, positionCode = r.PositionCode } equals new { vendorId = vm.VendorId, positionCode = vm.Etwid }
                                             where v.Status == "Closed" && (r.ResourceStatus == "Active" || r.ResourceStatus == "Resigned")
                                             && vm.SowendDate < parsedDate && v.SowstartDate <= parsedDate  && v.RemappedMid != null && v.RemappedMid != ""
                                             select new EmsTblResourceMaster()
                                             {
                                                 Rmid = r.Rmid,
                                                 PositionCode = v.Etwid,
                                                 ViatrisMid = r.ViatrisMid

                                             }).ToList();
                var propToIncludepositionCode = new List<string> { nameof(EmsTblResourceMaster.PositionCode) };
                var Position = new BulkConfig { PropertiesToInclude = propToIncludepositionCode };
                _dataContext.BulkUpdate(resourePositionUpdate, Position);

                //To make Remapped MID null after mapping done.

                var mappedResource = (from r in resourePositionUpdate
                                      join tcm in _dataContext.EmsTblFbvendorContractMonthlyMasters on new { positioncode = r.PositionCode, mid = r.ViatrisMid } equals new { positioncode = tcm.Etwid, mid = tcm.RemappedMid }
                                      select new EmsTblFbvendorContractMonthlyMaster()
                                      {
                                          FbcmontlyId = tcm.FbcmontlyId,
                                          RemappedMid = null
                                      });

                var propToInclude2 = new List<string> { nameof(EmsTblFbvendorContractMonthlyMaster.RemappedMid) };
                var bulkConfig1 = new BulkConfig { PropertiesToInclude = propToInclude2 };
                _dataContext.BulkUpdate(mappedResource, bulkConfig1);

                // Call the SP to put reconcile in employeemaster of AMS
                var remappedContracts = vContract.Where(x => x.RemappedMid != "" && x.RemappedMid != null).ToList();
                foreach (var v in remappedContracts)
                {
                    _dataContext.GetProcedures().SP_EMS_UpdateInsertEmpFromEMSToAMSAsync("FPMonthly", "Update", v.RemappedMid).Wait();
                    _dataContext.SaveChanges();
                }
            }

            //add remapped resouces to table EmsTblRemappedResourceWdExtension for RITM generation for contract extension
            List<EmsTblRemappedResourceWdExtension> ress = new List<EmsTblRemappedResourceWdExtension>();
            ress = (from v in vContract
                    where v.RemappedMid != null && v.RemappedMid != ""
                    select new EmsTblRemappedResourceWdExtension
                    {
                        EmpMid = v.RemappedMid,
                        EmpName = null,
                        PositionCode = v.Etwid,
                        Sownumber = v.Sownumber,
                        DomainSkillEndDate = v.DomainSkillEndDate,
                        Ritm = null
                    }).ToList();

            ress.Join(
                _dataContext.EmployeeMasters,
                r => r.EmpMid,
                e => e.EmpMid,
                (r, e) => { r.EmpName = e.EmpName; return r; }
            ).ToList();

            _dataContext.BulkInsert(ress);
            return "success";
        }


        #endregion
        #region "FPContract Track Contracts"
        public List<SP_EMS_GetFPContractTrackListResult> GetFPContractTrackList(int WFOrder, int Location, string filter,string ActiveFilter)
        {
            //WFOrder = 1 for Finance Manager
            var result = _dataContext.GetProcedures().SP_EMS_GetFPContractTrackListAsync(WFOrder, Location, filter, ActiveFilter).Result;
            return result;
        }
        public List<SP_EMS_GetFPMonthlyContractTrackListResult> GetFPContractMonthlyTrackList(int WFOrder, int Location, string filter, string ActiveFilter)
        {
            //WFOrder = 1 for Finance Manager
            var result = _dataContext.GetProcedures().SP_EMS_GetFPMonthlyContractTrackListAsync(WFOrder, Location, filter, ActiveFilter).Result;
            return result;
        }
        #endregion


        public void BeginTransaction()
        {
            if (_currentTransaction == null)
            {
                _currentTransaction = _dataContext.Database.BeginTransaction();
            }
        }

        public void CommitTransaction()
        {
            try
            {
                _currentTransaction?.Commit();
            }
            finally
            {
                _currentTransaction = null;
            }
        }

        public void RollbackTransaction()
        {
            try
            {
                _currentTransaction?.Rollback();
            }
            finally
            {
                _currentTransaction = null;
            }
        }
    }
}
