﻿using EMS_DAL.Entities;
using EMS_DAL.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Repository
{
    public class EmployeeMasterRepository : IEmployeeMasterRepository
    {
        private readonly EMS_Context _dbcontext;
        public EmployeeMasterRepository( EMS_Context dbContext)
        {
            _dbcontext = dbContext;
        }

        public List<EmsVwTmemployeeMaster> GetAllEmployee ()
        {
            var result=_dbcontext.EmsVwTmemployeeMasters.ToList();
            return result;
          
        }
    }
}
