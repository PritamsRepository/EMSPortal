﻿using Azure.Core;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using EMS_DAL.UserTypes;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using NetTopologySuite.Algorithm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EMS_DAL.Repository
{
    public class MastersRepository : IMastersRepository
    {
        private readonly EMS_Context _dataContext;
        private readonly IMemoryCache _memoryCache;
        public MastersRepository(EMS_Context eMS_Context, IMemoryCache memoryCach)
        {
            _dataContext = eMS_Context;
        }


        public List<VendorMaster> Getvendormaster()
        {
            //To fetch user based on role type
            var result = _dataContext.VendorMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        //public List<EmsTblRoleMaster> GetrolesbyRoleType(string roletype,int locationId)
        //{
        //    //To fetch user based on role type
        //    var result = _dataContext.EmsTblRoleMasters.Where(x => x.IsActive == true && x.RoleType == roletype).ToList();
        //    return result;
        //}



        public List<EmsTblRoleTypeMaster> GetRoleTypeData(int RoleID,string MID)
        {
            var result = new List<EmsTblRoleTypeMaster>();
            //var admindata= _dataContext.EmsTblRoleMasters.Where(x => x.RoleMasterId == RoleID && x.RoleType == "Admin" && x.IsActive==true).ToList();
            var admindata= _dataContext.EmsTblRoleMasters.Where(x => x.RoleMasterId == RoleID && x.RoleType == "Admin" && x.IsActive==true).ToList();
            if (admindata.Count > 0)
            {
                 result = _dataContext.EmsTblRoleTypeMasters.Where(x => x.IsActive == true && x.RoleType != "Admin" && x.RoleType!="Super Admin").ToList();
             
            }
            else
            {
                var superadmin = _dataContext.EmsTblRoleMasters.Where(x => x.RoleMasterId == RoleID && x.RoleType == "Super Admin" && x.IsActive == true).ToList();
                if (superadmin.Count > 0)
                {
                     result = _dataContext.EmsTblRoleTypeMasters.Where(x => x.IsActive == true && x.RoleType != "SuperAdmin").ToList();
                  
                }
            }
            return result;

        }
        public List<LocationMaster> loactionDetails()
        {
            var result = _dataContext.LocationMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        public List<EmsTblObsmaster> GetOBSMasterList() {
            var result = _dataContext.EmsTblObsmasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        public List<EmployeeSkill> GetSkillMasterList() {
            var result = _dataContext.EmployeeSkills.Where(x => x.IsActive == true).ToList();
            return result;
        }
        
        public List<EmsTblBillingTypeMaster> GetBillingMasterList()
        {
            var result = _dataContext.EmsTblBillingTypeMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }

        public List<EmsTblContractTypeMaster> GetContractMasterList()
        {
            var result = _dataContext.EmsTblContractTypeMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
         
        public List<VendorMaster> GetVendorMasterList()
        {
            var result = _dataContext.VendorMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }

        public List<EmsTblSowTypeMaster> GetSowTypeMasterList()
        {
            var result = _dataContext.EmsTblSowTypeMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }

        public List<EmsTblVerticalMaster> GetVerticalMasterList()
        {
            var result = _dataContext.EmsTblVerticalMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }

        public List<TowerNameMaster> GetTowerMasterList()
        {
            var result = _dataContext.TowerNameMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        public List<LocationMaster> GetLocationData()
        {
            var result = _dataContext.LocationMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        public List<ProjectOrRunMaster> GetprojectOrRunMasterList()
        {
            var result = _dataContext.ProjectOrRunMasters.Where(x => x.IsActive == true).ToList();
            return result;
        }
        public List<EmsTblCurrencyMaster> GetCurrenctMasterList()
        {
            var result = _dataContext.EmsTblCurrencyMasters.ToList();
            return result;
        }
        public List<LocationMaster> GetLocationDataByID(string Username)
        {
            var result = (
                from rm in _dataContext.EmsTblRoleMasters
                join lm in _dataContext.LocationMasters on rm.LocationId equals lm.LocationId
                where rm.Mid == Username && rm.IsActive == true && lm.IsActive == true && rm.RoleType == "Admin"
                select lm
            ).Distinct().ToList();
            return result;
        }

        public string GetLocationName(int locID)
        {
            var result = _dataContext.LocationMasters.Where(x => x.IsActive == true && x.LocationId == locID).Select(x=>x.LocationName).FirstOrDefault();
            return result;
        }


        public List<EmployeeRoles> GetEmpRoleMappingData(string UserName)
        {
            var locationIds = (
                from rm in _dataContext.EmsTblRoleMasters
                join lm in _dataContext.LocationMasters on rm.LocationId equals lm.LocationId
                where rm.Mid == UserName && rm.IsActive == true && lm.IsActive == true && rm.RoleType == "Admin"/* && rm.LocationId==LocationId*/
                select rm.LocationId
            ).ToList();

            var result = (
                from rm in _dataContext.EmsTblRoleMasters
                join lm in _dataContext.LocationMasters on rm.LocationId equals lm.LocationId
                where locationIds.Contains(rm.LocationId)
                select new EmployeeRoles
                {
                    RoleTypeID = rm.RoleMasterId,
                    RoleTypeName = rm.RoleType,
                    LocationName = lm.LocationName,
                    MID = rm.Mid,
                    Name = rm.Name,
                    EmailID = rm.EmailId,
                    IsPrimary = rm.IsPrimaryPerson,
                    IsActive = rm.IsActive
                }
            ).ToList();
            return result;
        }

        public void SaveEmployeeMappingDetails(string RoleType, string MID, string Name, string EmailID, List<string> LocationID, bool IsPrimary, bool isactive,string LoggedinMID)
        {
            foreach (var i in LocationID)
            {
                var ActiveData = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == RoleType && x.Mid == MID && x.LocationId == Convert.ToInt32(i) &&x.IsActive==true).FirstOrDefault();

                var InactiveData = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == RoleType && x.Mid == MID && x.LocationId == Convert.ToInt32(i) && x.IsActive == false).FirstOrDefault();

                if(ActiveData!=null)
                {
                    if (IsPrimary == true)
                    {
                        var check = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == RoleType && x.LocationId == Convert.ToInt32(i) && x.IsPrimaryPerson == true && x.IsActive == true).FirstOrDefault();
                        if (check != null)
                        {
                            check.IsPrimaryPerson = false;
                            _dataContext.SaveChanges();
                        }
                        ActiveData.IsPrimaryPerson = IsPrimary;
                        _dataContext.SaveChanges();
                    }
                    else
                    {
                        ActiveData.IsPrimaryPerson = IsPrimary;
                        _dataContext.SaveChanges();
                    }



                }
                else if(InactiveData!=null)
                {
                    InactiveData.IsActive = true;
                    if (IsPrimary == true)
                    {
                        var check = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == RoleType && x.LocationId == Convert.ToInt32(i) && x.IsPrimaryPerson == true && x.IsActive == true).FirstOrDefault();
                        if (check != null)
                        {
                            check.IsPrimaryPerson = false;
                            _dataContext.SaveChanges();
                        }
                        InactiveData.IsPrimaryPerson = IsPrimary;
                        _dataContext.SaveChanges();
                    }
                    else
                    {
                        InactiveData.IsPrimaryPerson = IsPrimary;
                        _dataContext.SaveChanges();
                    }

                }
                else
                {
                  
                    var EMS_tblRoleMaster = new EmsTblRoleMaster();
                    if (IsPrimary == true)
                    {
                        var check = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == RoleType && x.LocationId == Convert.ToInt32(i) && x.IsPrimaryPerson == true && x.IsActive == true).FirstOrDefault();
                        if (check != null)
                        {
                            check.IsPrimaryPerson = false;
                            _dataContext.SaveChanges();
                        }
                        EMS_tblRoleMaster.IsPrimaryPerson = IsPrimary;

                    }
                    else
                    {
                        EMS_tblRoleMaster.IsPrimaryPerson = IsPrimary;
                    }
                    EMS_tblRoleMaster.RoleType = RoleType;
                    EMS_tblRoleMaster.Mid = MID;
                    EMS_tblRoleMaster.Name = Name;
                    EMS_tblRoleMaster.EmailId = EmailID;
                    EMS_tblRoleMaster.LocationId = Convert.ToInt32(i);
                 
                    EMS_tblRoleMaster.IsActive = true;
                    _dataContext.EmsTblRoleMasters.Add(EMS_tblRoleMaster);
                    _dataContext.SaveChanges();
                }
                var amsdata = _dataContext.RoleMasters.Where(x => x.Mid == MID && x.IsActive == true).FirstOrDefault();
                if (amsdata != null && RoleType == "Local IT")
                {
                    amsdata.IsHelpDesk = true;
                    amsdata.UpdatedBy = LoggedinMID;
                    amsdata.UpdatedOn = DateTime.Now;
                    _dataContext.SaveChanges();
                }
                else if(amsdata==null && RoleType=="Local IT")
                {
                    var newamsdata = new RoleMaster
                    {
                        Mid = MID,
                        Name = Name,
                        Email = EmailID,
                        IsActive = true,
                        CreatedBy = LoggedinMID,
                        CreatedOn = DateTime.Now,
                        IsHelpDesk = true,
                    };
                    _dataContext.RoleMasters.Add(newamsdata);
                    _dataContext.SaveChanges();
                }
                _dataContext.SaveChanges();

                var preference = GetRolePreferenceByName(MID);
                if(preference==null)
                {
                    var roleId = _dataContext.EmsTblRoleMasters.Where(x => x.Mid == MID && x.LocationId == Convert.ToInt32(i) && x.IsActive == true).Select(x => x.RoleMasterId).FirstOrDefault();
                    if (roleId != null)
                    {
                        var newPreference = new EmsTblRolePreference
                        {
                            LocationId = Convert.ToInt32(i),
                            RoleMasterId = Convert.ToInt32(roleId),
                            UserId = MID
                        };

                        // Insert new user preference
                        _dataContext.EmsTblRolePreferences.Add(newPreference);
                        _dataContext.SaveChanges();
                    }
                }
            }
        }

        public bool DeactivateRoleMappingDetailsByID(int roleTypeID)
        {
            var returndata = false;
            var data = _dataContext.EmsTblRoleMasters.Where(x => x.RoleMasterId == roleTypeID).FirstOrDefault();
            if (data != null)
            {
                var validatedata = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == data.RoleType && x.LocationId == data.LocationId && x.IsActive == true && x.RoleMasterId != roleTypeID).FirstOrDefault();
                if (data != null && data.IsActive == true)
                {
                    if (validatedata != null)
                    {
                        data.IsActive = false;
                        _dataContext.SaveChanges();

                    }

                }
                else if (data != null && data.IsActive == false)
                {
                    data.IsActive = true;
                    _dataContext.SaveChanges();
                    returndata = true;
                }



            }
            return returndata;

        }

        public bool PrimaryRoleMappingDetailsByID(int roleTypeID)
        {
            var data = _dataContext.EmsTblRoleMasters.Where(x => x.RoleMasterId == roleTypeID).FirstOrDefault();
            var returndata = false;
            if (data != null)
            {
                var validatedata = _dataContext.EmsTblRoleMasters.Where(x => x.RoleType == data.RoleType && x.LocationId == data.LocationId && x.IsPrimaryPerson == true && x.RoleMasterId != roleTypeID).FirstOrDefault();

                if (data != null && data.IsPrimaryPerson == true)
                {
                    if (validatedata != null)
                    {
                        data.IsPrimaryPerson = false;
                        _dataContext.SaveChanges();

                    }
                }
                else if (data != null && data.IsPrimaryPerson == false)
                {
                    data.IsPrimaryPerson = true;
                    if (validatedata != null)
                    {
                        validatedata.IsPrimaryPerson = false;

                    }
                    returndata = true;
                    _dataContext.SaveChanges();
                }

            }
            return returndata;
        }


        public List<EmsTblRoleMaster> GetrolesbyRoleType(string roletype, int locationId)
        {
            //To fetch user based on role type
            var result = _dataContext.EmsTblRoleMasters.Where(x => x.IsActive == true && x.RoleType == roletype && x.LocationId == locationId).ToList();
            return result;
        }
     
        public List<EmsTblRoleMaster> GetRolesByMID(string mid)
        {
            if (mid is not null)
            {
                var result = _dataContext.EmsTblRoleMasters.Where(x => x.Mid.ToUpper() == mid.ToUpper() && x.IsActive == true).ToList();
                return result;
            }
            return null;
        }

        public EmsTblRolePreference GetRolePreferenceByName (string userid)
        {
            if (userid is not null)
            {
                var result = _dataContext.EmsTblRolePreferences.Where(x => x.UserId.ToUpper() == userid.ToUpper()).FirstOrDefault();
                //var result = (
                //                from rm in _dataContext.EmsTblRoleMasters
                //                join lm in _dataContext.EmsTblRolePreferences on rm.Mid equals lm.UserId
                //                where rm.Mid == userid && rm.IsActive == true
                //                select lm
                //             ).FirstOrDefault();
                return result;
            }
            return null;
        }

        public EmsTblRolePreference UserRolePreference(string userId, int locId, int roleId)
        {
            if (userId != null)
            {
                // Check if user preference exists
                var userPreference = _dataContext.EmsTblRolePreferences
                    .FirstOrDefault(x => x.UserId.ToLower() == userId.ToLower());

                // Insert if userPreference is null else Update
                if (userPreference == null)
                {
                    var newPreference = new EmsTblRolePreference
                    {
                        LocationId = locId,
                        RoleMasterId = roleId,
                        UserId = userId
                    };

                    // Insert new user preference
                    _dataContext.EmsTblRolePreferences.Add(newPreference);
                }
                else
                {
                    // Update existing user preference
                    userPreference.LocationId = locId;
                    userPreference.RoleMasterId = roleId;
                    userPreference.UserId = userId;
                }

                // Save changes to the database
                _dataContext.SaveChanges();
            }
        
            return _dataContext.EmsTblRolePreferences.FirstOrDefault(x =>x.UserId.ToLower() == userId.ToLower());
        }
        public List<EmsTblResourceMaster> GetResourceByMID(string MID)
        {
            return _dataContext.EmsTblResourceMasters.Where(x => x.ViatrisMid.ToUpper() == MID.ToUpper()).ToList();

        }

    }
}