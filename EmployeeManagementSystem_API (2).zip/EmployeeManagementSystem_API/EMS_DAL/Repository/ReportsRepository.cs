﻿using AutoMapper;
using EFCore.BulkExtensions;
using EMS_DAL.Entities;
using EMS_DAL.Interface;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Repository
{
    public class ReportsRepository:IReportsRepository
    {
        private readonly EMS_Context _dataContext;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;
        public ReportsRepository(EMS_Context dataContext, IMemoryCache memoryCache, IMapper mapper)
        {
            _dataContext = dataContext;
            _memoryCache = memoryCache;
            _mapper = mapper;


        }

        public async Task<List<sp_EMS_ContractDetailReportResult>> GetContractDetailReport (string reportType,int prId)
        {
            var result = await _dataContext.GetProcedures().sp_EMS_ContractDetailReportAsync(reportType, prId);
            return result;
        }


        public async Task<List<sp_EMS_ContractSummaryReportResult>> GetContractSummaryReport (string reportType, int prId)
        {
           
            var result =  await _dataContext.GetProcedures().sp_EMS_ContractSummaryReportAsync(reportType, prId);
            return result.ToList(); ;
        }

        public List<sp_EMS_ReportOpenPositionResult> GetOpenPositionReport (string reportType)
        {
            var result = _dataContext.GetProcedures().sp_EMS_ReportOpenPositionAsync(reportType);
            return result.Result.ToList();
        }
        public List<sp_EMS_ContractSummaryWithTowerHeadAndDomainReportResult> GetContractReportByToweHeadAndDomain(string TowerHead, string PrjOrRun)
        {
            var result = _dataContext.GetProcedures().sp_EMS_ContractSummaryWithTowerHeadAndDomainReportAsync(TowerHead, PrjOrRun).Result.ToList();
            return result;
        }
        

         public bool SaveContractPublishedData(List<EmsTblPublishedContractReport> PublishedContractReport, string MID)
        {
            var itemsToDelete = _dataContext.EmsTblPublishedContractReports.ToList();
            if (itemsToDelete.Count > 0)
            {
                _dataContext.EmsTblPublishedContractReports.RemoveRange(itemsToDelete);
                _dataContext.SaveChanges();
            }
            _dataContext.BulkInsert(PublishedContractReport);
            _dataContext.SaveChanges();
            return true;

        }
        public List<EmsTblPublishedContractReport> GetpublishedContractDetails(string TowerHead, string PrjOrRun)
        {
            List<EmsTblPublishedContractReport> result = new List<EmsTblPublishedContractReport>();
            if (TowerHead== "ALL" && PrjOrRun=="ALL")
            {
                 result = _dataContext.EmsTblPublishedContractReports.ToList();
            }
            else if(TowerHead != "ALL" && PrjOrRun == "ALL")
            {
                result = _dataContext.EmsTblPublishedContractReports.Where(x=>x.Towerlead==TowerHead).ToList();
            }
            else if(TowerHead == "ALL" && PrjOrRun != "ALL")
            {
                result = _dataContext.EmsTblPublishedContractReports.Where(x => x.ProjOrRun == PrjOrRun).ToList();
            }
            else
            {
                result = _dataContext.EmsTblPublishedContractReports.Where(x=>x.Towerlead==TowerHead && x.ProjOrRun== PrjOrRun).ToList();
            }
            return result;
        }
        

          public string  getvendorEmailIdForRun()
        {
            var emailIds = (from vendor in _dataContext.VendorMasters
                            where (from emp in _dataContext.EmployeeMasters
                                   where emp.IsActive == true && emp.ProjectType == "T&M" && emp.ProjectOrRunId == 1
                                   select emp.VendorName).Distinct().Contains(vendor.VendorId)
                            select vendor.EmailIds).ToList();

            string concatenatedEmails = string.Join(";", emailIds);
            return concatenatedEmails;
        }

        public List<string> getTowerHeadMasterData()
        {
            var result = _dataContext.TowerNameMasters.Select(x => x.TowerHead).ToList();
            return result;
        }

        public async Task<List<SP_EMS_GetAllVendorContractsByDateResult>> GetAllVendorContractsByDate(string contractType)
        {
            var result = await _dataContext.GetProcedures().SP_EMS_GetAllVendorContractsByDateAsync(contractType);
            return result.ToList();
        }
    }
}
