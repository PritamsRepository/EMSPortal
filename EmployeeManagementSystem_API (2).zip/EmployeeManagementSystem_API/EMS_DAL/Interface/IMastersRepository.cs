﻿using EMS_DAL.Entities;
using EMS_DAL.UserTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface IMastersRepository
    {
        List<EmsTblContractTypeMaster> GetContractMasterList();
        List<EmployeeSkill> GetSkillMasterList();
        List<LocationMaster> loactionDetails();
        List<EmsTblObsmaster> GetOBSMasterList();
        
        bool DeactivateRoleMappingDetailsByID (int roleTypeID);
        List<LocationMaster> GetLocationDataByID (string Username);
        string GetLocationName(int locID);
        bool PrimaryRoleMappingDetailsByID (int roleTypeID);
        
        List<EmsTblRoleMaster> GetrolesbyRoleType(string roletype,int locationId);
        List<VendorMaster> GetVendorMasterList();
        List<EmsTblSowTypeMaster> GetSowTypeMasterList();
        List<EmsTblVerticalMaster> GetVerticalMasterList();
        List<TowerNameMaster> GetTowerMasterList();
        List<ProjectOrRunMaster> GetprojectOrRunMasterList();
        List<EmsTblCurrencyMaster> GetCurrenctMasterList();
        List<EmsTblBillingTypeMaster> GetBillingMasterList();
        //List<VendorMaster> Getvendormaster ();
        List<EmsTblRoleMaster> GetRolesByMID(string mid);
        EmsTblRolePreference GetRolePreferenceByName(string userid);

        EmsTblRolePreference UserRolePreference(string userId, int locId, int roleId);
        List<LocationMaster> GetLocationData();
        List<EmployeeRoles> GetEmpRoleMappingData(string UserName);
        List<EmsTblRoleTypeMaster> GetRoleTypeData(int RoleID, string MID);
        void SaveEmployeeMappingDetails(string RoleType, string MID, string Name, string EmailID, List<string> LocationID, bool IsPrimary, bool isactive, string LoggedinMID);
        List<EmsTblResourceMaster> GetResourceByMID(string MID);

     
    }
}