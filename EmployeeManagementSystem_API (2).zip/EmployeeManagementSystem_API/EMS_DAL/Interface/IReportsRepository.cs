﻿using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface IReportsRepository
    {
        Task<List<sp_EMS_ContractSummaryReportResult>> GetContractSummaryReport (string reportType, int prId);
        List<sp_EMS_ReportOpenPositionResult> GetOpenPositionReport (string reportType);
        Task<List<sp_EMS_ContractDetailReportResult>> GetContractDetailReport(string reportType, int prId);
        bool SaveContractPublishedData(List<EmsTblPublishedContractReport> PublishedContractReport, string MID);
         List<EmsTblPublishedContractReport> GetpublishedContractDetails(string TowerHead, string PrjOrRun);
         string getvendorEmailIdForRun();
        List<string> getTowerHeadMasterData();
        List<sp_EMS_ContractSummaryWithTowerHeadAndDomainReportResult> GetContractReportByToweHeadAndDomain(string TowerHead, string PrjOrRun);
        Task<List<SP_EMS_GetAllVendorContractsByDateResult>> GetAllVendorContractsByDate(string contractType);
    }
}
