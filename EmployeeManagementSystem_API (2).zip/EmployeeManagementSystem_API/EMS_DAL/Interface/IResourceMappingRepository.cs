﻿using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface IResourceMappingRepository
    {
         bool AddTMContractResourceMappingIntermediate(List<EmsTblTmresourceMappingIntermediate> TmresourceMappingIntermediate, string MID, int locationID);
         List<SP_EMS_GetOnboardingApprovalPendingDetailsResult> GetTMOnboardingApprovalPendingList(string UserName, int workflowOrder);
        bool UpdateResourceMasterstatus(string ETWID, string PosCode);
        List<SP_EMS_GetResourceMappingPendingDetailsResult> GetResourceMappingPendingList(string UserName, int workflowOrder, int LocationId);
         List<SP_EMS_GetResourceMappingTrackDetailsResult> GetResourceMappingTrackDetails(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);

         List<EmsTblTmcontractWorkFlow> GetTMResourceWorkFlow(int tmvcmid);

        bool AddTMDataToResourcemaster(List<EmsTblResourceMaster> tmResourceMasterData, List<EmsTblTmvendorContractMaster> tmvendorContractMasters, List<EmsTblContractMaster> emsContractMasters, string MID, string Name, List<EmsTblTmcontractWorkFlow> contractWorkFlow, int locationId);
         List<SP_EMS_GetTMresourceMIDPendingReqResult> GetResourceMIDcreationPendingList(string UseName, int locationID);
         //bool SaveResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName);
         List<SP_EMS_GetResourceMappingMilestonePendingDetailsResult> GetResourceMappingMilestonePendingList(string UserName, int workflowOrder, int LocationId);
        bool AddFPmilestoneDataToResourcemaster(List<EmsTblResourceMaster> fpResourceMasterData, List<EmsTblFbvendorContractMilestoneMaster> fpvendorContractMasters, List<EmsTblContractMaster> emsContractMasters, string MID, string Name, List<EmsTblFpcontractWorkFlowMilestone> contractWorkFlow, int locationID);
         bool AddFPContractMSResourceMappingIntr(List<EmsTblFpmileStoneResourceMappingIntermediate> FPresourceMappingIntermediate, string MID, int locationID);
        List<SP_EMS_GetResourceMappingMonthlyPendingDetailsResult> GetResourceMappingMonthlyPendingList(string UserName, int workflowOrder, int LocationId);
        bool AddFPmonthlyDataToResourcemaster(List<EmsTblResourceMaster> fpResourceMasterData, List<EmsTblFbvendorContractMonthlyMaster> fpvendorContractMasters, List<EmsTblContractMaster> emsContractMasters, string MID, string Name, List<EmsTblFpcontractWorkFlowMonthly> contractWorkFlow, int locationID);
        bool AddFPContractMLYResourceMappingIntr(List<EmsTblFpmonthlyResourceMappingIntermediate> FPresourceMappingIntermediate, string MID, int locationID);
         List<EmsTblFpcontractWorkFlowMonthly> GetFPmonthlyResourceWorkFlow(int fbcIntID);
         List<EmsTblFpcontractWorkFlowMilestone> GetFPmilestoneResourceWorkFlow(int fbcIntID);
         bool AddTMRejectedResourceDataWorkflow(string MID, string Name, List<EmsTblTmcontractWorkFlow> contractWorkFlow, int locationId);
         List<SP_EMS_GetFPmonthlyResourceMIDPendingReqResult> GetMonthlyMIDcreationPendingList(string UserName, int workfloworder, int LocationId);
         List<SP_EMS_GetFPmilestoneResourceMIDPendingReqResult> GetMilestoneMIDcreationPendingList(string UserName, int workfloworder, int LocationId);
         bool AddFPRejectedMnthlyResrcWrkFloDts(string MID, string Name, List<EmsTblFpcontractWorkFlowMonthly> contractWorkFlow, int locationId);
         bool AddFPRejectedMlStnResrcWrkFloDts(string MID, string Name, List<EmsTblFpcontractWorkFlowMilestone> contractWorkFlow, int locationId);

        string SaveMilestoneResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName);
        string SaveMonthlyResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName);
         List<SP_EMS_GetFPMonthlyResourceTrackDetailsResult> GetResourceFPmonthlyTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);
         List<SP_EMS_GetFPMilestoneResourceTrackDetailsResult> GetResourceFPmilestoneTrackDts(string UseName, int workflowOrder, int locationID, string Filter,string ActiveFilter, DateTime FromDate, DateTime Todate);
         string PostResourcemapping(List<EmsTblTmvendorContractMaster> vContract, string loggedIN = "");
         List<SP_EMS_GetTMPositionWithMultipleResourceDtsResult> GetMultipleResourceByPositionCode(string Positioncode);
         bool DeleteIntrResourceTMdataById(int TmIntrId);
         bool DeleteIntrResourceFPmyldataById(int fpintid);
         bool DeleteIntrResourceFPmlsdataById(int fpintid);
         string SaveResourceAssetDetails(string MID, string Email, int Rmid, int Cmid, string loggedInMID, string LoggedinName);
        List<SP_EMS_GetMiletoneDetailsBySowNumResult> GetMilestoneDetailsBySowNum(string SowNumber);
         List<SP_EMS_GetMonthlyDetailsBySowNumResult> GetMonthlyDetailsBySowNum(string SowNumber);
    
    }
}
