﻿using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface IEmployeeMasterRepository
    {
        List<EmsVwTmemployeeMaster> GetAllEmployee ();
    }
}
