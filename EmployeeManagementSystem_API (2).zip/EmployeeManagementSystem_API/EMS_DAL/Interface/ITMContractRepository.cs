﻿using EMS_DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface ITMContractRepository
    {
        //Task<bool> AddTMContractIntermediate (List<EmsTblTmvendorContractIntermediateMaster> tmvendorContractIntermediateMasters, string mid);
        bool AddTMContractIntermediateAsync(List<EmsTblTmvendorContractIntermediateMaster> tmvendorContractIntermediateMasters, string mid, string location);
        List<EmsTblTmvendorContractIntermediateMaster> GetTMContractIntermediateList (string mid);
        //List<EmsTblTmvendorContractMaster> GetTMContractList();
        bool SaveTMIntermediateDataToMain (List<int> Id, string mid, string name, bool isProcLead, int locId);
        bool NextProcessOfSaveTMIntermediateDataToMain(string mid, string name,bool isProcLead, int locId,List<string>etwids);
        bool DeleteTMIntermediateData (List<int> Id);
        bool DeleteTMSendbackData(int ids, string mid, string name,string remarks);
       // List<EmsTblTmvendorContractMaster> GetTMContractPendingList (int WFOrder, string Location);
        // List<EmsTblTmvendorContractMaster> GetTMContractPendingList (int WFOrder, string Location);
        List<SP_EMS_GetTMContractPendingListResult> GetTMContractPendingList(int WFOrder, int Location);
        List<SP_EMS_GetTMContractTrackListResult> GetTMContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter);
        List<EmsTblWorkFlowMaster> GetTMContractWFOrder ();
        string PostTMContractApproval (List<EmsTblTmvendorContractMaster> vContract, List<EmsTblTmcontractWorkFlow> wf, List<EmsTblContractMaster> vmContract);
        //Task<bool> validateTmIntermediateTable(int sp);

        List<sp_EMS_GetTMVendorContractMainMasterDetailsResult> GetTMContractMainList(string RecordType, int locId);

        bool UpdateTmContractDetails(EmsTblTmvendorContractMaster tmDetails, string mid);
        List<string> ValidateAndSaveContract(EmsTblTmvendorContractMaster contract, string mid, string name, bool isProcLead, int locId,string remarks);

        bool NextProcessOfSaveTMDataAfterSendback(string mid, string name, bool isProcLead, int locId,int tmvcmid,string remarks);
        List<EmsTblTmcontractWorkFlow> GetTmSendbackedListFromWorkFlow(List<int?> MastertmcidList);
        List<EmsTblTmcontractWorkFlow> GetWorkFlowsOfContract(int tmcid);
        string GetLocationName(int locID);
        List<string> ValidateAndSaveApprovedContract(EmsTblTmvendorContractMaster contract, string mid, int locId, string remarks);

        List<SP_EMS_FetchSowNumberByContractTypeResult> GetSowListByContractType(string contractType, string searchSowNumber);
        List<SP_EMS_FetchContractListBySOW_NoResult> GetAllSowListByContractType(string contractType, string sowNumber);
        List<SP_EMS_FetchColumnValueByTblAndSowNumberResult> GetContractValueByContractSowType(string contractType, string sowNumber, string fieldType);

        List<SP_EMS_ValidateColumnBySowNumberResult> GetColumnValidationStatusBySowNumber(string contractType, string sowNumber, string fieldType, string newValue);
        int UpdateContractColumnBySowNumber(string contractType, string sowNumber, string fieldType, string oldValue, string newValue, string mid);

    }
}
