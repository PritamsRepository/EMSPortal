﻿using EMS_DAL.Entities;
using EMS_DAL.UserTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_DAL.Interface
{
    public interface IFPContractRepository
    {
        List<string> ValidateAndSaveContract(EmsVwFpvendorContractMasterWithId contract, string mid, string name, bool isProcLead, int locId);
        List<EmsVwFpvendorContractWorkFlow> GetFPSendbackedListFromWorkFlow(List<int?> MastertmcidList);
        List<EmsVwFpvendorContractWorkFlow> GetWorkFlowsOfFPContract(int cmid, string Btype, string Ctype);

        //Task<List<sp_EMS_GetFPVendorContractMainMasterDetailsResult>> GetFPContractMainList(string mid);
        //bool AddFPContractIntermediate(List<EmsTblFbvendorContractIntermediateMaster> fpvendorContractIntermediateMasters);
        Task AddFPContractIntermediate(List<EmsTblFbvendorContractIntermediateMaster> fpvendorContractIntermediateMasters, string MID, string LocationID);
        // List<EmsTblTmvendorContractIntermediateMaster>GetTMVendo
        //List<EmsTblFbvendorContractIntermediateMaster> GetFPContractIntermediateList();
        Task<List<EmsTblFbvendorContractIntermediateMaster>> GetFPContractIntermediateList(string EmpMID);
        bool AddFPMlContractIntermediate(List<EmsTblFbvendorContractMilestoneInt> fpmlvendorContractIntermediateMasters, string MID);
        bool deleteFbFromIntByIDs(List<int> ids);
        Task<bool> deleteFbMoFromIntAllOrByID(string id);
        bool deleteFbAllOrByID(string id);
        Task<bool> deleteFbmlFromIntAllOrByID(string id);
        //Task<ActionResult<bool>> saveSelectedFpRows(List<FPContract> selectedRows);
        //saveSelectedFpRows
        //bool saveSelectedFpRows(List<EmsTblFbvendorContractIntermediateMaster> selectedRows);
        bool saveSelectedFpContract(EmsTblFbvendorContractIntermediateMaster selectedContract);
        Task<List<EmsTblFbvendorContractMilestoneInt>> GetFPContractMlIntermediateList(string MID);
        bool saveSelectedFpMlRows(List<int> ids);
        bool saveSelectedFMlContract(EmsTblFbvendorContractMilestoneInt selectedContract);
        List<EmsTblFbvendorContractMonthlyInt> GetFPMOContractIntermediateList(string MID);
        //bool saveSeltedFpRowsPerTbl(List<EmsTblFbvendorContractMilestoneMaster> Milestonedt, List<EmsTblFbvendorContractMonthlyMaster> Monthlydt);
        //bool saveSeltedFpRowsPerTbl(List<EmsTblFbvendorContractMilestoneMaster> Milestonedt, List<EmsTblFbvendorContractMonthlyMaster> Monthlydt, List<EmsTblContractMaster> ContractMasterData);
        //bool saveSeltedFpRowsPerTbl(List<int> ids, int WFOrder, List<EmsTblRoleMaster> FinanceMgrList);
        //bool saveSeltedFpRowsPerTbl(List<int> ids, int WFOrder, List<EmsTblRoleMaster> FinanceMgrList);

        bool saveSeltedFpRowsPerTbl(List<int> ids, int WFOrder, List<EmsTblRoleMaster> FinanceMgrList, string mid, string name, int locId);
        bool AddFPContractMoIntermediate(List<EmsTblFbvendorContractMonthlyInt> list, string MID);
        bool saveSeltedFpMoRowsPerTbl(List<int> ids);
        bool saveSeltedFpMlRowsPerTbl(List<int> ids);

        //bool saveMothWiseActualls(List<EmsTblFbvendorContractMonthWiseActual> alist);
        bool deleteFbmlFromIntByIDs(List<int> ids);
        bool deleteFbMoFromIntByIDs(List<int> ids);
        bool DeleteFBSendbackData(int tmIntID, string mid, string name, string remarks, string Btype);
        List<SP_EMS_GetFPMilestoneContractPendingListResult> GetFPMilestoneContractPendingList(int WFOrder, int Location);
        List<EmsTblWorkFlowMaster> GetFPContractWFOrder();
        string PostFPMilestoneContractApproval(List<EmsTblFbvendorContractMilestoneMaster> vContract, List<EmsTblFpcontractWorkFlowMilestone> wf, List<EmsTblContractMaster> Contract);
        List<EmsTblFbvendorContractMilestoneDetail> GetFPMilestoneContractDetail(string sowNumber);

        List<SP_EMS_GetFPMonthlyContractPendingListResult> GetFPMonthlyContractPendingList(int WFOrder, int Location);
        string PostFPMonthlyContractApproval(List<EmsTblFbvendorContractMonthlyMaster> vContract, List<EmsTblFpcontractWorkFlowMonthly> wf, List<EmsTblContractMaster> Contract);
        List<EmsTblFbvendorContractMonthlyDetail> GetFPMonthlyContractDetail(string sowNumber);
        List<SP_EMS_GetFPContractTrackListResult> GetFPContractTrackList(int WFOrder, int Location, string filter, string ActiveFilter);
        List<SP_EMS_GetFPMonthlyContractTrackListResult> GetFPContractMonthlyTrackList(int WFOrder, int Location, string filter, string ActiveFilter);
        List<sp_EMS_GetFPVendorContractMainMasterDetailsResult> GetFPContractMainList(string filter, int locationID, DateTime? fromdate, DateTime? todate, string ActiveFilter);
        void BeginTransaction();
        void CommitTransaction();
        void RollbackTransaction();
    }
}
