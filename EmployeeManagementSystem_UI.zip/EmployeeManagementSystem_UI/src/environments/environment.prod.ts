export const environment = {
  production: false,
 // API_URL: 'http://w0bsnowappq001:8010/api',
 API_URL: 'https://localhost:7141/api',
  SECRET_KEY: '1203199320052021',
  SECRET_KEY_IV: '1203199320052021'
}
