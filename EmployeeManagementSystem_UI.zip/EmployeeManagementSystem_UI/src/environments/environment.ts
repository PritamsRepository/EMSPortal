// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  windowAuth: true,
  production: false,

  // Local Url----

  // API_URL: 'https://localhost:7141/api',
  // AMS_URL: 'http://localhost:54230/LogOn.aspx',

  // Development Url---

 //API_URL: 'http://w0bsnowappq001:8010/api',
 //AMS_URL: 'https://devapps.myl.com/amsdev/',
 //ESep_URL: 'https://devapps.myl.com/EmsSeparationDev',

  // UAT Url-------

    API_URL: 'http://w0bivtdbq001:8010/api',
   AMS_URL: 'https://testapps.myl.com/amsuat/',
 ESep_URL: 'https://testapps.myl.com/EMSSeparationUAT',

  SECRET_KEY: '1203199320052021',
  SECRET_KEY_IV: '1203199320052021',

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
