import {
  HttpClient,
  HttpHandler,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class HttpclientService {
  constructor(
    private readonly _httpClient: HttpClient,
    public _router: Router
  ) {}

  // HttpClient API get() method => Fetch details
  get<T>(url: string) {
    return this._httpClient
      .get<T>(`${environment.API_URL}/${url}`)
      .pipe(retry(1), catchError(this.handleError));
  }

  //     let params = new URLSearchParams();
  // params.append("someParamKey", this.someParamValue)
  getById<T>(url: string, headers: HttpHeaders, params: HttpParams) {
    return this._httpClient
      .get<T>(`${environment.API_URL}/${url}`, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getListByIdWithHeaders<T>(
    url: string,
    headers: HttpHeaders,
    params: HttpParams
  ) {
    return this._httpClient
      .get<T[]>(`${environment.API_URL}/${url}`, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getData<T>(url: string, headers: HttpHeaders) {
    return this._httpClient
      .get<T>(`${environment.API_URL}/${url}`, { headers })
      .pipe(catchError(this.handleError));
  }

  // HttpClient API get() method => Fetch details
  getList<T>(url: string, headers: HttpHeaders) {
    return this._httpClient
      .get<T[]>(`${environment.API_URL}/${url}`, { headers })
      .pipe(retry(1), catchError(this.handleError));
  }

  // HttpClient API getLiostByID() method => Fetch details
  getListById<T>(url: string, params: HttpParams) {
    return this._httpClient
      .get<T>(`${environment.API_URL}/${url}`, { params })
      .pipe(catchError(this.handleError));
  }

  // HttpClient API post() method => Create new record
  // post(paylods: any) {
  //     return this._httpClient.post(environment.API_URL, paylods).pipe(
  //         retry(1),
  //         catchError(this.handleError)
  //     );
  // }
  postwithbody(url: string, body: any, headers: HttpHeaders) {
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, body, { headers })
      .pipe(catchError(this.handleError));
  }
  postwithbodyWithoutHeaders(url: string, body: any) {
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, body)
      .pipe(catchError(this.handleError));
  }

  postwithbodyWithId(
    url: string,
    body: any,
    headers: HttpHeaders,
    params: HttpParams
  ) {
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  postById(url: string, headers: HttpHeaders, params: HttpParams) {
    return this._httpClient
      .delete(`${environment.API_URL}/${url}`, { headers, params })
      .pipe(catchError(this.handleError));
  }

  post(url: string, paylods: any) {
    return this._httpClient.post(`${environment.API_URL}/${url}`, paylods);
    // .pipe(catchError(this.handleError));
  }

  postList(url: string, body: any, headers: HttpHeaders) {
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, body, { headers })
      .pipe(
        //retry(1),
        catchError(this.handleError)
      );
  }
  postListWithBody(url: string, body: any, headers: HttpHeaders) {
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, body, { headers })
      .pipe(
        //retry(1),
        catchError(this.handleError)
      );
  }
  postWithHeaders(url: string, headers: HttpHeaders) {
    //console.log('Serice Headers:', headers);
    return this._httpClient
      .post(`${environment.API_URL}/${url}`, null, { headers })
      .pipe(
        // retry(1),
        catchError(this.handleError)
      );
  }

  // HttpClient API get() method => Fetch details
  getTableData(api: any[]) {
    return forkJoin([api]);
  }

  // Error handling
  private handleError(error: any) {
    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      
    }
    return throwError(() => new error(errorMessage));
  }
}
