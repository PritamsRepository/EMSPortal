import { Injectable } from '@angular/core';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';
import { HttpHandler, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IContractSummaryReport } from '../../interfaces/icontract-summary-report';
import { IContractDetailReport } from '../../interfaces/icontract-detail-reports';
import { iContractTypeMaster } from '../../interfaces/imasterDetails';
import { IDropDownKeyValue } from '../../interfaces/idropdown-key-value';
import { ContractTowerDomainReport } from '../../interfaces/contract-tower-domain-report';
import { PublishedContractReport } from '../../interfaces/published-contract-report';
import { VendorContractDataByDate } from '../../interfaces/vendor-contract-data-by-date';

@Injectable({
  providedIn: 'root',
})
export class ReportsService {
  headers: any;
  errorMessage: any;
  emptyParams: any = new HttpParams();

  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.headers = new HttpHeaders(headerSettings);
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
    });
  }

  GetContractSummaryReport(reportType: string, prId: number): Observable<any> {
    const url = `Reports/GetContractSummaryReport?reportType=${reportType}&prId=${prId}`;
    return this._httpClientService.getData<IContractSummaryReport[]>(
      url,
      this.headers
    );
  }

  GetContractDetailReport(reportType: string, prId: number): Observable<any> {
    const url = `Reports/GetContractDetailedReport?reportType=${reportType}&prId=${prId}`;
    return this._httpClientService.getData<iContractTypeMaster[]>(
      url,
      this.headers
    );
  }

  GetEmployeeMasterDetailReport(): Observable<any> {
    const result = this._httpClientService
      .getList<any>('Masters/GetAllEmployee', this.headers)
      .pipe();
    return result;
  }

  GetProjectOrRunMaster(): Observable<any> {
    const url = `Masters/GetAllProjectOrRunMaster`;
    return this._httpClientService.getList<IDropDownKeyValue[]>(
      url,
      this.headers
    );
  }

  // GetContractSummaryReport(reportType: string): Observable<any> {
  //   const url = `Reports/GetContractSummaryReport?reportType=${reportType}`;
  //   return this._httpClientService.getData<ContractSummaryReport[]>( url,this.headers );
  // }

  GetContractReportByToweHeadAndDomain(TowerHead:string,PrjOrRun:string): Observable<any> {
    debugger;
    const url = `Reports/GetContractReportByToweHeadAndDomain?TowerHead=${TowerHead}&PrjOrRun=${PrjOrRun}`;
    return this._httpClientService.getData<ContractTowerDomainReport[]>(
      url,
      this.headers
    );
  }
  SaveContractPublishedData(result: any): Observable<any> {
    debugger;
    if (result != null && result.length > 0) {
      const url = 'Reports/SaveContractPublishedData';
      return this._httpClientService.postListWithBody(
        url,
        result,
        this.headers
      );
    }
    return new Observable();
  }
  
  SaveContractPublishedDataWithMail(result: any): Observable<any> {
    debugger;
    if (result != null && result.length > 0) {
      const url = 'Reports/SaveContractPublishedDataWithMail';
      return this._httpClientService.postListWithBody(
        url,
        result,
        this.headers
      );
    }
    return new Observable();
  }



  GetpublishedContractDetails(TowerHead:string,PrjOrRun:string): Observable<any> {
    debugger;
    const url = `Reports/GetpublishedContractDetails?TowerHead=${TowerHead}&PrjOrRun=${PrjOrRun}`;
    return this._httpClientService.getData<PublishedContractReport[]>(
      url,
      this.headers
    );
  }
  
  getTowerHeadMasterData(): Observable<any> {
    debugger;
    const url = `Reports/getTowerHeadMasterData`;
    return this._httpClientService.getData<string[]>(
      url,
      this.headers
    );
  }

  getAllVendorContractsByDate(ContractType: string = 'All'): Observable<any> {
    const params = new HttpParams()
      .set('ContractType', ContractType);
    const url = `Reports/GetAllVendorContractsByDate`;
    return this._httpClientService.getListByIdWithHeaders<VendorContractDataByDate[]>(
      url,
      this.headers,
      params
    );
  }
}
