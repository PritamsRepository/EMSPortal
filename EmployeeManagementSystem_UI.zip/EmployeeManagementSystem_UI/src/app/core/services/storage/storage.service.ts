import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service';
import { DefinedRoles } from '../../utiltz/DefinedRolesList';

const USER_KEY = 'currentUser';
const TOKEN_KEY = 'jwt_token';
const EXPIRYTIME = 'expiry_Time';
const USER_MID = 'MID';
const LOCATIONID = 'LocationID';
const ROLEMASTERID = 'RoleMasterID';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  showLoader: boolean = false;
  constructor(private readonly router: Router) {}

  clean(): void {
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.removeItem(EXPIRYTIME);
    window.sessionStorage.removeItem(USER_MID);
    window.sessionStorage.removeItem(LOCATIONID);
    window.sessionStorage.removeItem(ROLEMASTERID);
    window.sessionStorage.clear();
    sessionStorage.clear();
  }

  public saveUser(user: any, token: any): void {
    //this.isLoggedIn();
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.removeItem(EXPIRYTIME);
    window.sessionStorage.removeItem(USER_MID);
    window.sessionStorage.removeItem(LOCATIONID);
    window.sessionStorage.removeItem(ROLEMASTERID);

    window.sessionStorage.clear();

    window.sessionStorage.setItem(USER_KEY, JSON.stringify(user));
    window.sessionStorage.setItem(TOKEN_KEY, JSON.stringify(token));
    window.sessionStorage.setItem(EXPIRYTIME, user.expiryTime);
    window.sessionStorage.setItem(USER_MID, user.mid);
    window.sessionStorage.setItem(LOCATIONID, user.locationId);
    window.sessionStorage.setItem(ROLEMASTERID, user.roleMasterId);
  }

  public getUser(): any {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return JSON.parse(user);
    }

    return null;
  }

  public isLoggedIn(): boolean {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return true;
    }

    return false;
  }

  public getCurrentUserMID(): string | null {
    return window.sessionStorage.getItem(USER_MID)
      ? window.sessionStorage.getItem(USER_MID)
      : null;
  }
  public getCurrentUserRoleMasterID(): string | null {
    return window.sessionStorage.getItem(ROLEMASTERID)
      ? window.sessionStorage.getItem(ROLEMASTERID)
      : null;
  }
  public getCurrentUserLocationID(): string | null {
    return window.sessionStorage.getItem(LOCATIONID)
      ? window.sessionStorage.getItem(LOCATIONID)
      : null;
  }

  public getExpirtTime(): string | null {
    return window.sessionStorage.getItem('expiryTime')
      ? window.sessionStorage.getItem('expiryTime')
      : null;
  }

  public getCurrentToken(): any {
    const token = JSON.parse(window.sessionStorage.getItem(TOKEN_KEY)!);
    if (token) {
      return token;
    }
    return {};
  }

  navigateBasedOnRole() {
    // Navigate to the specified route after the loader is hidden
    const storedRoles: any[] = JSON.parse(
      sessionStorage.getItem('AssignedRoles')
    );
    //console.log(storedRoles);
    if (storedRoles != null) {
      // Get the role details based on the selectedRoleMasterId
      const selectedRole: DefinedRoles = storedRoles.find(
        (role) => role.roleMasterId == this.getCurrentUserRoleMasterID()
      ).roleType;
      ////console.log('NAVIGATE RoLE :', selectedRole);

      switch (selectedRole) {
        case DefinedRoles.PMO_Contract_Mgm:
          this.router.navigate(['/main/tmSendbackDetails']);
          break;
        case DefinedRoles.PMO_Admin:
          this.router.navigate(['/main/vendorContractList']);
          break;
        case DefinedRoles.IT_Finance_Manager:
          this.router.navigate(['/main/tmApproval']);
          break;
        case DefinedRoles.Admin:
          this.router.navigate(['/main/rolemapping']);
          break;
        case DefinedRoles.Super_Admin:
          this.router.navigate(['/main/home']);
          break;
        case DefinedRoles.Local_IT:
          this.router.navigate(['/main/home']);
          break;
        case DefinedRoles.Report_Access:
          this.router.navigate(['/main/contractSummaryReportTowerHead']);
          break;
        case DefinedRoles.HR:
          this.router.navigate(['/main/home']);
          break;
        case DefinedRoles.Vendor:
          this.router.navigate(['/main/home']);
          break;

        // Add more cases for other specific roles
        default:
          // Handle other roles or provide a default route if needed
          this.router.navigate(['/main/home']);
          break;
      }
    } else {
      this.router.navigate(['/main/home']);
    }
  }

  public updateLocationandRole(locationId: any, RoleMasterID: any): any {
    this.showLoader = true;
    window.sessionStorage.removeItem(LOCATIONID);
    window.sessionStorage.removeItem(ROLEMASTERID);

    window.sessionStorage.setItem(LOCATIONID, locationId);
    window.sessionStorage.setItem(ROLEMASTERID, RoleMasterID);

    // // Navigate to the specified route after the page reloads
    // this.router.navigate(['/main/home']);
    // // Reload the page
    // window.location.reload();

    // Simulate an asynchronous operation (e.g., API call) that takes 1 second
    setTimeout(() => {
      this.showLoader = false;
      this.navigateBasedOnRole();
      //this.router.navigate(['/main/home']);

      // Reload the page after a delay (e.g., 1 second)
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }, 500);
  }
}
