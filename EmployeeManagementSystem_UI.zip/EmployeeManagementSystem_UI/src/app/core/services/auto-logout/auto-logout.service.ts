import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { AuthenticationService } from '../auth/authentication.service';

const MINUTES_UNITL_AUTO_LOGOUT = 2; // in mins
const CHECK_INTERVAL = 20000; // in ms
const EXPIRY_TIME = 'expiry_Time';
@Injectable()
export class AutoLogoutService {
  public getExpiryTime(): any {
    const expiryTime = window.sessionStorage.getItem(EXPIRY_TIME);
    if (expiryTime !=null) {
      return new Date(expiryTime);
    }
    return new Date();
  }

  public setLastAction(lastAction: number) {
    window.sessionStorage.setItem(EXPIRY_TIME, this.getExpiryTime().toString());
  }

  constructor(
    private readonly authentication:AuthenticationService,
    private readonly router: Router,
    private readonly storageService: StorageService
  ) {
    //console.log('object created')

    this.check();
    this.initListener();
    this.initInterval();
  }

  initListener() {
    document.body.addEventListener('click', () => {
      this.reset();
    });
    document.body.addEventListener('mouseover', () => {
      this.reset();
    });
    document.body.addEventListener('mouseout', () => {
      this.reset();
    });
    document.body.addEventListener('keydown', () => {
      this.reset();
    });
    document.body.addEventListener('keyup', () => {
      this.reset();
    });
    document.body.addEventListener('keypress', () => {
      this.reset();
    });
  }

  reset() {
    this.getExpiryTime();
  }

  initInterval() {
    setInterval(() => {
      this.check();
    }, CHECK_INTERVAL);
  }

  check() {
    const now = Date.now();
    const timeleft = this.getExpiryTime();
    // const timeleft = this.getExpiryTime();

    const diff = timeleft - now;
    
    console.log('TimeLeft:',timeleft);
    console.log('Current Time',new Date());
    console.log('Auto Logout time diff', diff);

    const isTimeout = diff <= 0;

    if (isTimeout) {
    
      this.authentication.logout().subscribe({
        next: (res) => {
          this.storageService.clean();
          this.router.navigate(['/login']);
          window.location.reload();
        },
        error(err) {
          //window.location.reload();
          //console.log(err);
        },
      });
      // this.storageService.clean();
      // // localStorage.clear();
      // this.router.navigate(['/login']);
    }
  }
}
