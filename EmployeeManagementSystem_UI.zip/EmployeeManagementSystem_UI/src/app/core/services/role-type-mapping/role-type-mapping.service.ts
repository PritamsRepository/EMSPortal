import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { LocationAndRoleMaster } from 'src/app/core/interfaces/location-and-role-master';
import { Roletypemapping } from 'src/app/core/interfaces/roletypemapping';
import { JsonPipe } from '@angular/common';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root',
})
export class RoleTypeMappingService {
  header: any;
  errorMessage: any;

  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.header = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }
  getLocAndRoleDetails(UserName: string): Observable<LocationAndRoleMaster> {
    const url = `Masters/GetLocationAndRoleTypeByMid?UserName=${UserName}`;
    return this._httpClientService.getData<LocationAndRoleMaster>(
      url,
      this.header
    );
  }
  getEmployeeSearchdetails(
    UserName: string
  ): Observable<LocationAndRoleMaster> {
    const url = `Masters/GetEmployeeSearchDetails?UserName=${UserName}`;
    //console.log(url);
    return this._httpClientService.getData<LocationAndRoleMaster>(
      url,
      this.header
    );
  }

  SaveRoleMappingDetails(roleType: Roletypemapping): Observable<any> {
    // const obj = {RoleTypeName: RoleType, MID: MID,Name : Name,EmailID: EmailID,LocationID:LocationID,IsPrimary:IsPrimary,IsActive:isactive};
    const url = 'Masters/SaveEmployeeMappingDetails';
    return this._httpClientService.postwithbody(url, roleType, this.header);
  }

  GetEmpRoleMappingData(
    UserName: string,
    LocationId: number
  ): Observable<Roletypemapping[]> {
    const url = `Masters/GetEmpRoleMappingData?UserName=${UserName}&LocationId=${LocationId}`;
    return this._httpClientService.getData<Roletypemapping[]>(url, this.header);
  }

  DeactivateRoleMappingDetailsByID(roleTypeID: number): Observable<boolean> {
    const url = 'Masters/DeactivateRoleMappingDetailsByID';
    return this._httpClientService
      .postwithbody(url, roleTypeID, this.header)
      .pipe(
        map((data: any) => {
          const isActive: boolean = data as boolean;
          return isActive;
        })
      );
  }

  PrimaryRoleMappingDetailsByID(roleTypeID: number): Observable<boolean> {
    const url = 'Masters/PrimaryRoleMappingDetailsByID';
    return this._httpClientService
      .postwithbody(url, roleTypeID, this.header)
      .pipe(
        map((data: any) => {
          const isPrimary: boolean = data as boolean;
          return isPrimary;
        })
      );
  }
}
