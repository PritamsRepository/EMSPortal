import { TestBed } from '@angular/core/testing';

import { RoleTypeMappingService } from './role-type-mapping.service';

describe('RoleTypeMappingService', () => {
  let service: RoleTypeMappingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RoleTypeMappingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
