import { CSP_NONCE, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ifpapproval } from '../../interfaces/ifpapproval';
import { Observable } from 'rxjs';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';
import { tap, catchError } from 'rxjs/operators';
import { ifpmapproval } from '../../interfaces/ifpmlapproval';
import { ifpmonapproval } from '../../interfaces/ifpmonapproval';

@Injectable({
  providedIn: 'root',
})
export class FPApprovalService {
  header: any;
  headers: any;
  errorMessage: any;

  constructor(
    private readonly _httpclientservice: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }
  ngOnInit() {
    var user = this._storageService.getCurrentUserMID();
  }
  //Milestone tab
  getapprovaldata(): Observable<ifpapproval[]> {
    return this._httpclientservice
      .getList<ifpapproval>('Contracts/GetFPContractList', this.headers)
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.getapprovaldata)
      );
  }
  postApproval(fpmapprovaldetails: ifpapproval[]): Observable<any> {
    const body = JSON.stringify(fpmapprovaldetails);
    return this._httpclientservice
      .postwithbody(
        'Contracts/PostFPMContractList',
        fpmapprovaldetails,
        this.headers
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.postApproval)
      );
  }
  getmilestoneData(sowNumber: string): Observable<ifpmapproval[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.append('sowNumber', sowNumber);
    return this._httpclientservice
      .getById<ifpmapproval[]>(
        'Contracts/GetFPContractMilList',
        this.headers,
        queryParams
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.getmilestoneData)
      );
  }
  //Monthly tab Functions
  getmonapprovaldata(): Observable<ifpapproval[]> {
    return this._httpclientservice
      .getList<ifpapproval>(
        'Contracts/GetFPMONContractPendingList',
        this.headers
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.getmonapprovaldata)
      );
  }
  postmonApproval(fpmopprovaldetails: ifpapproval[]): Observable<any> {
    const body = JSON.stringify(fpmopprovaldetails);
    return this._httpclientservice
      .postwithbody(
        'Contracts/PostFPMONContractList',
        fpmopprovaldetails,
        this.headers
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.postApproval)
      );
  }
  getmonthlyData(sowNumber: string): Observable<ifpmonapproval[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.append('sowNumber', sowNumber);
    return this._httpclientservice
      .getById<ifpmonapproval[]>(
        'Contracts/GetFPContractMONList',
        this.headers,
        queryParams
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.getmonthlyData)
      );
  }
  getFPMilestoneContractTrackdata(
    selectedFilter: string,
    selectedActiveFilter: string
  ): Observable<ifpapproval[]> {
    //console.log('checking track');
    let queryParams = new HttpParams();
    queryParams = queryParams.append('selectedFilter', selectedFilter);
    queryParams = queryParams.append(
      'selectedActiveFilter',
      selectedActiveFilter
    );

    return this._httpclientservice
      .getById<ifpapproval[]>(
        'Contracts/GetFPContractTrackList',
        this.headers,
        queryParams
      )
      .pipe(
        tap((data) => console.log('getFPMilestoneContractTrackdata:', data))
        // catchError(this.getFPMilestoneContractTrackdata)
      );
  }
  getFPMonthlyContractTrackdata(
    selectedFilter: string,
    selectedActiveFilter: string
  ): Observable<ifpapproval[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.append('selectedFilter', selectedFilter);
    queryParams = queryParams.append(
      'selectedActiveFilter',
      selectedActiveFilter
    );
    return this._httpclientservice
      .getById<ifpapproval[]>(
        'Contracts/GetFPContractMonthlyTrackList',
        this.headers,
        queryParams
      )
      .pipe(
        tap((data) => console.log('GetFPContractMonthlyTrackList:', data))
        // catchError(this.getFPMonthlyContractTrackdata)
      );
  }
}
