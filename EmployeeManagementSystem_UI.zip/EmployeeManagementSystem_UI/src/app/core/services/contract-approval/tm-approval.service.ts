import { CSP_NONCE, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { tmApproval } from '../../interfaces/Itm-approval';
import { Observable } from 'rxjs';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class TmApprovalService {
  header: any;
  headers: any;
  errorMessage: any;

  constructor(
    private readonly _httpclientservice: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }
  ngOnInit() {
    var user = this._storageService.getCurrentUserMID();
  }
  getapprovaldata(): Observable<tmApproval[]> {
    // return  this._httpclientservice.get<tmApproval[]>('Contracts/GetTMContractList')
    return this._httpclientservice
      .getList<tmApproval>('Contracts/GetTMContractList', this.headers)
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.getapprovaldata)
      );
  }
  postApproval(tmapprovaldetails: tmApproval[]): Observable<any> {
    const body = JSON.stringify(tmapprovaldetails);
    return this._httpclientservice
      .postwithbody(
        'Contracts/PostTMContractList',
        tmapprovaldetails,
        this.headers
      )
      .pipe(
        tap((data) => console.log('Anlagenstatus Daten:', data)),
        catchError(this.postApproval)
      );
  }
  getTMContractTrackdata(
    selectedFilter: string,
    selectedActiveFilter: string
  ): Observable<tmApproval[]> {
    let queryParams = new HttpParams();
    queryParams = queryParams.append('selectedFilter', selectedFilter);
    queryParams = queryParams.append(
      'selectedActiveFilter',
      selectedActiveFilter
    );

    return this._httpclientservice
      .getById<tmApproval[]>(
        'Contracts/GetTMContractTrackList',
        this.headers,
        queryParams
      )
      .pipe(
        tap((data) => console.log('getTMContractTrackdata:', data))
        // catchError(this.getTMContractTrackdata)
      );
  }
}
