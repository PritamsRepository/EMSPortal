import { Injectable } from '@angular/core';
import { HttpclientService } from '../HttpClientServices';
import { IErrorLog } from '../../interfaces/ierror-log';
import { StorageService } from '../storage/storage.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable, catchError, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  headers: any;

  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.headers = new HttpHeaders(headerSettings);
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
    });
  }

  logGeneratedError(errorLog: IErrorLog): Observable<any> {
    const body = JSON.stringify(errorLog);
    // console.log('Error Body', body);
    return this._httpClientService
      .postwithbodyWithoutHeaders('Error/SaveLoggedError', errorLog)
      .pipe();
  }
}
