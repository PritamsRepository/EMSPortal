import { DatePipe, formatDate, getLocaleDateTimeFormat } from '@angular/common';
import { Injectable } from '@angular/core';
import { convertToParamMap } from '@angular/router';
import * as XLSX from 'xlsx';
import { iTmContractModal } from '../interfaces/itmupload';
@Injectable({
  providedIn: 'root',
})
export class excelFileValidation {
  private removeWhitespaceAndConvertToLowercase(inputString: string): string {
    return inputString.replace(/\s+/g, '').toLowerCase();
  }
  public readExcelFile(fileContent: string) {
    const workbook = XLSX.read(fileContent, { type: 'binary' });

    // Variable to store the index of 'Sheet1'
    var sheetIndex = -1;

    // Iterate over the array to find 'Sheet1'
    for (var i = 0; i < workbook.SheetNames.length; i++) {
      if (workbook.SheetNames[i] === 'Sheet1') {
        // 'Sheet1' found, store its index and exit the loop
        sheetIndex = i;
        break;
      }
    }

    const sheetName = workbook.SheetNames[sheetIndex];
    const worksheet = workbook.Sheets[sheetName];

    const data = {
      headers: XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0],
      body: XLSX.utils.sheet_to_json(worksheet),
    };
    // console.log('E-WorkBook : ', workbook.SheetNames);
    // console.log('E-SheetName : ', sheetName);
    // console.log('E-WorkSheet : ', worksheet);
    // console.log('E-Data : ', data);
    return data;
  }

  private hasDuplicateRecords(data: any[]): {
    hasDuplicateRecords: boolean;
    message: string;
  } {
    const result = { hasDuplicateRecords: false, message: '' };
    const uniqueSet = new Set();

    for (const record of data) {
      const etwidKey = `${record.ETWID}`;
      const pcodeKey = `${record.ETWID}-${record['PositionCode']}-${record['ContractType']}-${record['Tower']}-${record['ProjectOrRun']}-${record['SkillSet']}-${record['SOWName']}-${record['DomainSkillName']}`;
      //console.log('pcodeKey', pcodeKey);
      const etwidKeyProcessed =
        this.removeWhitespaceAndConvertToLowercase(etwidKey);
      const pcodeKeyProcessed =
        this.removeWhitespaceAndConvertToLowercase(pcodeKey);

      if (
        uniqueSet.has(etwidKeyProcessed) ||
        uniqueSet.has(pcodeKeyProcessed)
      ) {
        const errorMessage = uniqueSet.has(etwidKey)
          ? 'Duplicate Records Found in ETWID column from uploaded excel file.'
          : 'Invalid Dataset Found, Please Check the datatset of selected excel file.';
        result.hasDuplicateRecords = true;
        result.message = `${errorMessage}`;
        return result; // Duplicate record found
      }

      uniqueSet.add(etwidKeyProcessed);
      uniqueSet.add(pcodeKeyProcessed);
      //vendor + pcode should be unique.
    }

    // console.log('UNI-set :', uniqueSet);
    // console.log('Has Dup res :', result);
    return result; // No duplicate records
  }

  validateForDuplicatRecords(fileContent: string) {
    const data = this.readExcelFile(fileContent);
    return this.hasDuplicateRecords(data.body);
  }
  validateForDuplicatRecordsFpMo(fileContent: string) {
    const data = this.readExcelFile(fileContent);
    return this.hasDuplicateRecords(data.body);
  }

  validateForDuplicateRecordsInSpecifiCol(
    fileContent: any,
    columnName: string
  ): boolean {
    const workbook = XLSX.read(fileContent, { type: 'binary' });
    const worksheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[worksheetName];

    const excelData: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    const headerRow = excelData[0] as string[];

    const columnIndex = headerRow.findIndex(
      (column: string) =>
        column.trim().replace(/\s+/g, ' ') ===
        columnName.trim().replace(/\s+/g, ' ')
    );

    if (columnIndex === -1) {
      return false;
    }

    const encounteredValues = new Set<any>();

    for (const row of excelData.slice(1)) {
      const columnValue = row[columnIndex];
      if (encounteredValues.has(columnValue)) {
        return true;
      } else {
        encounteredValues.add(columnValue);
      }
    }

    // No duplicates found
    return false;
  }

  checkforValidTmTemplateFile(
    fileContent: string,
    contractType: string
  ): {
    isInvalidTemplate: boolean;
    message: string;
  } {
    const result = { isInvalidTemplate: false, message: '' };
    const data = this.readExcelFile(fileContent);

    var expectedHeaderCount = 39;

    //console.log('FILE-CONTENT : ', fileContent);
    //console.log('FILE-CONTENT data : ', data);

    if (contractType == 'FpMo') {
      expectedHeaderCount = 7;
    } else if (contractType == 'FpMl') {
      expectedHeaderCount = 6;
    } else if (contractType == 'Fp') {
      expectedHeaderCount = 30;
    }

    const hasValidationRemarks =
      Array.isArray(data.headers) &&
      data.headers.includes('Validation Remarks');
    const isValidHeaderCount = [
      expectedHeaderCount,
      expectedHeaderCount - 1,
    ].includes(Object.keys(data.headers!).length);

    if (
      data.body.length <= 0 ||
      !isValidHeaderCount ||
      (Object.keys(data.headers!).length === expectedHeaderCount &&
        !hasValidationRemarks)
    ) {
      result.isInvalidTemplate = true;
      result.message = 'Invalid file, please choose the correct file';
    }

    const missingColumns = this.validateMandatoryColumns(
      data.body,
      contractType
    );

    //alert(contractType);
    if (missingColumns && contractType == 'tm') {
      result.isInvalidTemplate = true;
      result.message =
        'The following mandatory columns are Empty/Missing : ' +
        missingColumns.join(', ');

      // console.error(
      //   'Validation failed. The following mandatory columns are missing:'
      // );
      // console.error(missingColumns.join(', '));
      // Optionally: Notify the user about the missing columns in your UI
    } else if (missingColumns) {
      // //console.log('Validation successful. Proceed with the import process.');
      // Proceed with the import process
      result.isInvalidTemplate = true;
      result.message =
        'The following mandatory columns are Empty/Missing : ' +
        missingColumns.join(', ');
    }

    return result;
  }

  validateMandatoryColumns(
    excelData: any[],
    contractType: string
  ): string[] | null {
    var mandatoryColumns: any[] = [];

    if (contractType == 'FpMo') {
      mandatoryColumns = [
        'SOW Number',
        'AmortizationStartDate',
        'AmortizationEndDate',
        'MilestonesAmount',
        'DurationOfMonths',
        'Currency',
      ];
    } else if (contractType == 'FpMl') {
      mandatoryColumns = [
        'SOWNumber',
        'Milestones',
        // 'MilestoneDescription',
        'MilestonesAmount',
        'Currency',
      ];
    } else if (contractType == 'Fp') {
      mandatoryColumns = [
        'ETWID',
        'VendorName',
        'PositionLocation',
        // 'OldSowNumber',
        'SOWNumber',
        'SOWName',
        'SOWStartDate',
        'SOWEndDate',
        // 'AmortizationStartMonth',
        // 'AmortizationEndMonth',
        'PONumber',
        'POStartDate',
        'POEndDate',
        'PPMProjectID',
        'PPMProjectName',
        // 'WBSDetail',
        'Vertical',
        'Tower',
        'DomainLeadEmail',
        'CostCenter',
        'OBS',
        'DomainSkillName',
        'SkillSet',
        // 'DomainSkillStartDate',
        // 'DomainSkillEndDate',
        'ProjectOrRun',
        'ContractType',
        'BillingType',
      ];
    } else if (contractType == 'tm') {
      mandatoryColumns = [
        'ETWID',
        'VendorName',
        'PositionCode',
        'SOWNumber',
        'SOWName',
        'SOWType',
        'Vertical',
        'Tower',
        'OBS',
        'SkillSet',
        'ProjectOrRun',
        'ContractType',
        'BillingType',
        'Currency',
      ];
    }

    const missingColumns: string[] = [];

    for (const row of excelData) {
      for (const column of mandatoryColumns) {
        const ActualColumn = column.trim();
        if ( !(typeof row[ActualColumn] === 'number' && row[ActualColumn]=== 0) && !row[ActualColumn] && !missingColumns.includes(ActualColumn)) {
          missingColumns.push(ActualColumn);
        }
      }
    }

    if (missingColumns.length > 0) {
      // Return an array of missing columns
      return missingColumns;
    } else {
      // Return null if there are no missing columns
      return null;
    }
  }

  validateForDuplicatRecordsFP(fileContent: string) {
    const workbook = XLSX.read(fileContent, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    return this.hasDuplicateRecordsFP(data);
  }
  hasDuplicateRecordsFP(data: any[]): {
    hasDuplicateRecords: boolean;
    message: string;
  } {
    const result = { hasDuplicateRecords: false, message: '' };
    const uniqueSet = new Set();

    for (const record of data) {
      const etwidKey = `${record.etwid}`;
      const pcodeKey = `${record['positionLocation']}`;

      if (uniqueSet.has(etwidKey) || uniqueSet.has(pcodeKey)) {
        const colName = uniqueSet.has(etwidKey) ? 'etwid' : 'Managing Team';
        result.hasDuplicateRecords = true;
        result.message = `Duplicate Records Found in "${colName}" column from uploaded excel file.`;
        return result; // Duplicate record found
      }

      uniqueSet.add(etwidKey);
      uniqueSet.add(pcodeKey);
    }

    return result; // No duplicate records
  }

  // public readExcelFileUpload(fileContent: string) {
  //   const workbook = XLSX.read(fileContent, { type: 'binary' });
  //   const sheetName = workbook.SheetNames[0];
  //   const worksheet = workbook.Sheets[sheetName];

  //   const data = {
  //     headers: XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0],
  //     body: XLSX.utils.sheet_to_json(worksheet),
  //   };
  //   return data.body;
  // }

  public ConvertToDesiredFormat(value: string): Date {
    var output = new Date();
    if (value != null) {
      output = new Date(value);
    }
    return output;
  }
  public readExcelFileUpload(fileContent: string) {
    const workbook = XLSX.read(fileContent, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];

    const data = {
      headers: XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0],
      body: XLSX.utils.sheet_to_json(worksheet, { raw: false }), // Include raw: false to preserve cell types
    };

    // Convert number cells to strings in the body
    data.body.forEach((row: { [key: string]: any }) => {
      Object.keys(row).forEach((cell) => {
        if (typeof row[cell] === 'number') {
          row[cell] = row[cell].toString();
        } else if (cell === 'SOWStartDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
          // row[cell] =this.ConvertToDesiredFormat(row[cell]);
        } else if (cell === 'SOWEndDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'SOWEndDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'POStartDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'POEndDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DomainSkillStartDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DomainSkillEndDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DOB' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (cell === 'DOJViatris' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (row[cell] === null || row[cell] === undefined) {
          // Handle null or undefined values (you can set them to an empty string or another default value)
          row[cell] = row[cell] !== '' ? row[cell] : null;
        }
      });
    });

    return data.body;
  }

  hasDuplicateRecordsTmPMO(
    data: any[],
    contractlist: any[]
  ): {
    hasDuplicateRecords: boolean;
    message: string;
  } {
    const result = { hasDuplicateRecords: false, message: '' };
    const uniqueSet = new Set();

    const positionCodesInContractList = new Set(
      contractlist.map((item) => item.positionCode)
    );
    const PositionCodesInExcel = new Set(data.map((item) => item.PositionCode));

    const missingPositionCodes = Array.from(PositionCodesInExcel).filter(
      (code) => !positionCodesInContractList.has(code)
    );

    if (missingPositionCodes.length > 0) {
      result.hasDuplicateRecords = true;
      result.message = `Position codes from uploaded Excel file :( ${missingPositionCodes.join(
        ', '
      )} ) not found in open positions.`;
    } else {
      for (const record of data) {
        const etwidKey = `${record.ETWID}`;
        const pcodeKey = `${record.PositionCode}`;
        if (uniqueSet.has(etwidKey) || uniqueSet.has(pcodeKey)) {
          const colName = uniqueSet.has(etwidKey) ? 'ETWID' : 'PositionCode';
          result.hasDuplicateRecords = true;
          result.message = `Duplicate Records Found in "${colName}" column from uploaded excel file.`;
          return result; // Duplicate record found
        }

        uniqueSet.add(etwidKey);
        uniqueSet.add(pcodeKey);
      }
    }

    return result; // No duplicate records
  }

  convertExcelFileToModal(fileContent: string, modalName: string) {
    const data = this.readExcelFile(fileContent);
    //console.log('Data of an excel', data);

    const excelBodyArray = data.body; // Assuming this is an array of rows
    const tmContracts: iTmContractModal[] = [];

    excelBodyArray.forEach((row: { [key: string]: any }) => {
      const tmContract: iTmContractModal = {
        ETWID: row['ETWID']?row['ETWID'].toString():'',
        VendorName:row['VendorName']?row['VendorName'].toString():'',
        PositionCode:row['PositionCode']?row['PositionCode'].toString():'',
        PositionLocation: row['PositionLocation']?row['PositionLocation'].toString():'',
        OldSowNumber:row['OldSOWNumber']?row['OldSOWNumber'].toString():'',
        SOWNumber:row['SOWNumber']?row['SOWNumber'].toString():'',
        SOWName: row['SOWName']?row['SOWName'].toString():'',
        SOWType: row['SOWType']?row['SOWType'].toString():'',
        SOWStartDate: this.convertExcelDate(row['SOWStartDate']),
        SOWEndDate: this.convertExcelDate(row['SOWEndDate']),
        PONumber:  row['PONumber']?row['PONumber'].toString():'',
        POStartDate: this.convertExcelDate(row['POStartDate']),
        POEndDate: this.convertExcelDate(row['POEndDate']),
        PPMProjectID: row['PPMProjectID']?row['PPMProjectID'].toString():'',
        PPMProjectName: row['PPMProjectName']?row['PPMProjectName'].toString():'',
        WBSDetail: row['WBSDetail']?row['WBSDetail'].toString():'',
        Vertical: row['Vertical']?row['Vertical'].toString():'',
        DomainLeadEmail: row['DomainLeadEmail']?row['DomainLeadEmail'].toString():'',
        CostCenter: row['CostCenterCode']?row['CostCenterCode'].toString():'', // Assuming CostCenterCode is the correct property name
        OBS: row['OBS']?row['OBS'].toString():'',
        DomainName: row['DomainSkillName']?row['DomainSkillName'].toString():'',
        SkillSet:row['SkillSet']?row['SkillSet'].toString():'',
        DomainSkillStartDate: this.convertExcelDate(
          row['DomainSkillStartDate']
        ),
        DomainSkillEndDate: this.convertExcelDate(row['DomainSkillEndDate']),
        ProjectOrRun: row['ProjectOrRun']?row['ProjectOrRun'].toString():'',
        ContractType: row['ContractType']?row['ContractType'].toString():'',
        BillingType:row['BillingType']?row['BillingType'].toString():'',
        BillingRateYear1: parseFloat(row['BillingRateYear1']) || 0.0,
        BillingRateYear2: parseFloat(row['BillingRateYear2']) || 0.0,
        BillingRateYear3: parseFloat(row['BillingRateYear3']) || 0.0,
        BillingRateYear4: parseFloat(row['BillingRateYear4']) || 0.0,
        BillingRateYear5: parseFloat(row['BillingRateYear5']) || 0.0,
        Currency: row['Currency'].toString()  || '',
        RemappedMID: row['RemappedMID']?row['RemappedMID'].toString():'',
        SAPCode: row['SAPCode']?row['SAPCode'].toString():'',
        NoticePeriod: row['NoticePeriodDays'] || 0,
        Tower: row['Tower']?row['Tower'].toString():'',
        CustomDomainName: row['DomainName']?row['DomainName'].toString():'',
      };
      tmContracts.push(tmContract);
    });

    //console.log('Excel tm-Contracts : ', tmContracts);
    return tmContracts;
  }
  convertExcelDate(excelDate: number | undefined): Date | null {
    if (excelDate !== undefined && excelDate !== null) {
      // Assuming the Excel date is represented as a serial number
      return new Date((excelDate - 25569) * 86400 * 1000);
    }
    return null;
  }

  hasDuplicateRecordsFpPMO(
    data: any[],
    contractlist: any[]
  ): {
    hasDuplicateRecords: boolean;
    message: string;
  } {
    debugger;
    const result = { hasDuplicateRecords: false, message: '' };
    const uniqueSet = new Set();

    const etwidInContractList = new Set(contractlist.map((item) => item.etwid));
    const etwidInExcel = new Set(data.map((item) => item.ETWID));

    const missingEtwid = Array.from(etwidInExcel).filter(
      (ETWID) => !etwidInContractList.has(ETWID)
    );

    if (missingEtwid.length > 0) {
      result.hasDuplicateRecords = true;
      result.message = `ETWID from uploaded Excel file :( ${missingEtwid.join(
        ', '
      )} ) not found in open positions.`;
    } else {
      for (const record of data) {
        const etwidKey = `${record.ETWID}`;
        if (uniqueSet.has(etwidKey)) {
          const colName = 'ETWID';
          result.hasDuplicateRecords = true;
          result.message = `Duplicate Records Found in "${colName}" column from uploaded excel file.`;
          return result; // Duplicate record found
        }

        uniqueSet.add(etwidKey);
      }
    }

    return result; // No duplicate records
  }
  public readExcelFileUploadfpMonthly(fileContent: string) {
    const workbook = XLSX.read(fileContent, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];

    const data = {
      headers: XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0],
      body: XLSX.utils.sheet_to_json(worksheet, { raw: false }), // Include raw: false to preserve cell types
    };

    // Convert number cells to strings in the body
    data.body.forEach((row: { [key: string]: any }) => {
      Object.keys(row).forEach((cell) => {
        if (typeof row[cell] === 'number') {
          row[cell] = row[cell].toString();
        } else if (cell === 'SOWStartDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
          // row[cell] =this.ConvertToDesiredFormat(row[cell]);
        } else if (cell === 'SOWEndDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'SOWEndDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'POStartDate' && row[cell].toString()) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'POEndDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DomainSkillStartDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DomainSkillEndDate' && row[cell]) {
          row[cell] = new Date(row[cell]);
        } else if (cell === 'DOB' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (cell === 'DOJViatris' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (cell === 'AmortizationStartMonth' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (cell === 'AmortizationEndMonth' && row[cell]) {
          row[cell] = row[cell] !== '' ? new Date(row[cell] + 'Z') : null;
          // row[cell] = row[cell] !== '' ? new Date(row[cell]) : null;
        } else if (row[cell] === null || row[cell] === undefined) {
          // Handle null or undefined values (you can set them to an empty string or another default value)
          row[cell] = row[cell] !== '' ? row[cell] : null;
        }
      });
    });

    return data.body;
  }
}
