import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap, catchError } from 'rxjs';
import { ReactiveFormsModule } from '@angular/forms';
import { ifpUpload } from '../../interfaces/ifpupload';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';
import { ifpEditedDetails } from '../../interfaces/ifpDetails';
import { MilestoneDetails } from '../../interfaces/milestone-details';

@Injectable({
  providedIn: 'root',
})
export class FpUploadService {
  header: any;
  headers: any;
  errorMessage: any;

  emptyParams: any = new HttpParams();
  // .set('id', '1');
  // readonly emptyParams = new HttpParams();

  // constructor(private readonly _httpClientService: HttpclientService) {
  //   const headerSettings: Record<string, string | string[]> = {};
  //   this.header = new HttpHeaders(headerSettings);
  // }

  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);

    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }

  GetMilestoneDetailsBySowNum(SowNumber: string) {
    const url = `ResourceOnboarding/GetMilestoneDetailsBySowNum?SowNumber=${SowNumber}`;
    return this._httpClientService.getData<MilestoneDetails[]>(
      url,
      this.headers
    );
  }
  GetMonthlyDetailsBySowNum(SowNumber: string) {
    const url = `ResourceOnboarding/GetMonthlyDetailsBySowNum?SowNumber=${SowNumber}`;
    return this._httpClientService.getData<MilestoneDetails[]>(
      url,
      this.headers
    );
  }
  // getFPContractMainDetails(): Observable<ifpUpload[]> {
  //   const result = this._httpClientService
  //     .getList<ifpUpload>(
  //      url,
  //       this.headers
  //     )
  //     .pipe(tap((data) => JSON.stringify(data)));
  //   return result;
  // }
  getFPContractMainDetails(
    Filter: string,
    FromDate: string,
    ToDate: string,
    ActiveFilter: string
  ): Observable<ifpUpload[]> {
    const url = `Contracts/GetFPVendorContractMasterDetails?Filter=${Filter}&FromDate=${FromDate}&ToDate=${ToDate}&ActiveFilter=${ActiveFilter}`;
    const result = this._httpClientService
      .getList<ifpUpload>(url, this.headers)
      .pipe(tap((data) => JSON.stringify(data)));
    return result;
  }

  updateFPContractDetails(fpDetails: ifpEditedDetails): Observable<any> {
    fpDetails.updatedBy = this._storageService.getCurrentUserMID();
    return this._httpClientService.postwithbody(
      'Contracts/UpdateFPContractDetails',
      fpDetails,
      this.headers
    );
  }

  getFPContractSendbackDetails(): Observable<ifpUpload[]> {
    const result = this._httpClientService
      .getList<ifpUpload>(
        'Contracts/GetFPVendorContractSendbackDetails',
        this.headers
      )
      .pipe(tap((data) => JSON.stringify(data)));
    return result;
  }

  UploadFpFiles(file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('filelist', file, file.name);

    this.headers = new HttpHeaders({
      // 'Content-Type': undefined,
      // Accept: 'multipart/form-data',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });

    return this._httpClientService.postwithbody(
      'Contracts/FPContractUpload',
      formData,
      this.headers
    );
    // return this.httpClient.post(`${this.apiUrl}/save-selected-rows`, { selectedRows });
  }
  UploadFpMlFiles(file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('filelist', file, file.name);

    this.headers = new HttpHeaders({
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
    });

    return this._httpClientService.postwithbody(
      'Contracts/FPContractUploadMl',
      formData,
      this.headers
    );
    // return this.httpClient.post(`${this.apiUrl}/save-selected-rows`, { selectedRows });
  }
  UploadFpMoFiles(file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('filelist', file, file.name);

    this.headers = new HttpHeaders({
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
    });

    return this._httpClientService.postwithbody(
      'Contracts/FPContractUploadMo',
      formData,
      this.headers
    );
    // return this.httpClient.post(`${this.apiUrl}/save-selected-rows`, { selectedRows });
  }
  getFPContractIntermediateDetails(): Observable<any> {
    var result = this._httpClientService.getList<any>(
      'Contracts/GetFbContractsFromInt',
      this.headers
    );
    return result;

    // const result = this._httpClientService
    //   .postWithHeaders ('Contracts/GetTMContractINt', this.headers)
    //   .pipe(tap((data) => JSON.stringify(data)));
    // return result;
  }
  getFPMOContractIntermediateDetails(): Observable<any> {
    var result = this._httpClientService.getList<any>(
      'Contracts/GetFbMoContractsFromInt',
      this.headers
    );
    return result;
  }

  getFPMlContractIntermediateDetails(): Observable<any> {
    var result = this._httpClientService.getList<any>(
      'Contracts/GetFbContractsMlFromInt',
      this.headers
    );

    return result;
  }
 
  // deleteFPAllOrByID(
  //   id: string
  //   ): Observable<any> {
  
  //   return this._httpClientService.postwithbody(
  //     'Contracts/deleteFbAllOrByID',
  //     JSON.stringify({ id }),
  //     this.headers
  //   );

  // }
  deleteFPAllOrByID(
    id: string
  ): Observable<any> {

    let selectedDetails: string[] = [id.toString()];
     
    var result2 = this._httpClientService.postwithbody(
      'Contracts/deleteFbAllOrByID',
      selectedDetails,
      this.headers
    );
 
    return result2;

  }

  deleteFPMlAllOrByID(id: string): Observable<any> {
    let selectedDetails: string[] = [id.toString()]; 
    return this._httpClientService.postwithbody(
      'Contracts/deleteFbmlFromIntAllOrByID',
      selectedDetails,
      this.headers
    ); 
  }




  deleteFPMOByID(id: any): Observable<any> {
    let selectedDetails: string[] = [id.toString()]; 
    return this._httpClientService.postwithbody(
      'Contracts/deleteFbmoFromIntAllOrByID',
      selectedDetails,
      this.headers 
    );
  }

  removeTFPContractSendBackDetails(
    tmIntId: number,
    remarks: string,
    Btype: string
  ): Observable<any> {
    interface deletedata {
      tmIntId: number;
      remarks: string;
      Btype: string;
    }

    const data: deletedata = {
      tmIntId: tmIntId,
      remarks: remarks,
      Btype: Btype,
    };

    return this._httpClientService.postwithbody(
      'Contracts/DeleteFPSendbackData',
      data,
      this.headers
    );
  }

 
  saveSelectedFpMoRows(selectedRows: any[]): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/saveSelectedFpMoRows',
      selectedRows,
      this.headers
    );
    // return this.httpClient.post(`${this.apiUrl}/save-selected-rows`, { selectedRows });
  }

  saveSelectedFpMlRows(selectedRows: any[]): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/saveSelectedFpMlRows',
      selectedRows,
      this.headers
    );
    // return this.httpClient.post(`${this.apiUrl}/save-selected-rows`, { selectedRows });
  }
  SaveFpContractToInt(FpContract: ifpUpload): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/saveSelectedFpContract',
      FpContract,
      this.headers
    );
  }
  SaveFpMlContractToInt(FpContract: ifpUpload): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/saveSelectedFpContract',
      FpContract,
      this.headers
    );
  }

  saveFPContractIntermediateDetails(selectedDetails: any[]): Observable<any> {
    var tmcidArray = selectedDetails.map((item: any) => item.fbcIntID);
    return this._httpClientService.postwithbody(
      'Contracts/saveSeltedFpRowsPerTbl',
      tmcidArray,
      this.headers
    );
  }
  saveFPMOContractIntermediateDetails(selectedDetails: any[]): Observable<any> {
    var tmcidArray = selectedDetails.map((item: any) => item.fbMonthlyIntID);
    return this._httpClientService.postwithbody(
      'Contracts/saveSeltedFpMoRowsPerTbl',
      tmcidArray,
      this.headers
    );
  }

  saveFPMLContractIntermediateDetails(selectedDetails: any[]): Observable<any> {
    var tmcidArray = selectedDetails.map((item: any) => item.fbcMilestoneIntID);
    return this._httpClientService.postwithbody(
      'Contracts/saveSeltedFpMlRowsPerTbl',
      tmcidArray,
      this.headers
    );
  }

  removeFPContractIntermediateDetails(selectedDetails: any[]): Observable<any> {
    var tmcidArray = selectedDetails.map((item: any) => item.fbcIntID);

    return this._httpClientService.postwithbody(
      'Contracts/deleteFbFromIntByIDs',
      // selectedDetails,
      tmcidArray,
      this.headers
    );
  }
  removeFPMOContractIntermediateDetails(selectedDetails: any): Observable<any> {
    // const emptyParams = new HttpParams().set('id', id.toString());
    var tmcidArray = selectedDetails.map((item: any) => item.fbMonthlyIntID);
    // this.emptyParams = new HttpParams().set('id', selectedDetails[0].fbMonthlyIntID );
    return this._httpClientService.postwithbody(
      'Contracts/deleteFbMoFromIntByIDs',
      tmcidArray,
      this.header //,
      // this.emptyParams
    );
  }

  getFPContractWorkFlow(
    fbcIntID: number,
    billingTypecontractType: string,
    contractType: string
  ): Observable<any[]> {
    const url = `Contracts/GetWorkFlowsOfFPContract?fbcIntID=${fbcIntID}&Btype=${billingTypecontractType}&Ctype=${contractType}`;
    // const result = this._httpClientService.get<any>(url);

    const result = this._httpClientService.getList<any>(url, this.headers);

    // return result;

    // const params = new HttpParams().set('cmid', cmid);
    // const result = this._httpClientService.getById<any>(
    //   'Contracts/GetWorkFlowsOfFPContract',
    //   this.headers,
    //   params
    // );
    return result;
  }

  // removeFPMLContractIntermediateDetails(selectedDetails: any): Observable<any> {
  //       var tmcidArray = selectedDetails.map((item: any) => item.fbcMilestoneIntID);
  //       // const emptyParams = new HttpParams().set('id', id.toString());
  //       // this.emptyParams = new HttpParams().set('id', selectedDetails[0].fbcMilestoneIntID);
  //       return this._httpClientService.postwithbody(
  //         'Contracts/deleteFbMlFromIntByIDs',
  //         tmcidArray,
  //         this.headers
  //       );

  // }
}
