import { Injectable } from '@angular/core';
import { HttpclientService } from '../HttpClientServices';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, catchError, map, tap } from 'rxjs';
import { ResourceMapping } from '../../interfaces/resource-mapping';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { Roletypemapping } from '../../interfaces/roletypemapping';
import { StorageService } from '../storage/storage.service';
import { ResourceWorkflow } from '../../interfaces/resource-workflow';
import { AssetDetails } from '../../interfaces/asset-details';
import { FpResourceMapping } from '../../interfaces/fp-resource-mapping';
import { TmPositionTrack } from '../../interfaces/tm-position-track';
import { ResourceBasicDts } from '../../interfaces/resource-basic-dts';
import { MilestoneDetails } from '../../interfaces/milestone-details';
import { MonthlyDetails } from '../../interfaces/monthly-details';
import { ResourceTrack } from '../../interfaces/resource-track';

@Injectable({
  providedIn: 'root',
})
export class ResourceOnboardingService {
  headers: any;
  errorMessage: any;
  emptyParams: any = new HttpParams();
  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.headers = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }

  GetResourceMappingPendingList(
    UserName: string,
    LocationId: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceMappingPendingList?UserName=${UserName}&LocationId=${LocationId}`;
    // const url = `ResourceOnboarding/GetResourceMappingPendingList`;
    return this._httpClientService.getData<ResourceMapping[]>(
      url,
      this.headers
    );
  }
  SaveOnboardingResourceMapping(result: any): Observable<any> {
    if (result != null && result.length > 0) {
      const url = 'ResourceOnboarding/SaveOnBoardingResourceMappingPendingList';
      return this._httpClientService.postListWithBody(
        url,
        result,
        this.headers
      );
    }
    return new Observable();
  }

  getTMapprovalOnboardingData(UserName: string): Observable<ResourceMapping[]> {
    this.emptyParams = new HttpParams().set('UserName', UserName);
    const url = `ResourceOnboarding/GetResourceMappingPendingList`;
    return this._httpClientService.getById<ResourceMapping[]>(
      url,
      this.headers,
      this.emptyParams
    );
  }

  submitApprovaldata(contractlist: ResourceMapping[]): Observable<any> {
    return this._httpClientService.postList(
      'ResourceOnboarding/SaveTMresourceApprovals',
      contractlist,
      this.headers
    );
  }
  sendOpenPositionsToVendor(contractlist: ResourceMapping[]): Observable<any> {
    return this._httpClientService.postList(
      'ResourceOnboarding/sendOpenPositionsToVendor',
      contractlist,
      this.headers
    );
  }

  GetResourceMappingTrackList(
    UserName: string,
    workflowOrder: number,
    LocationID: number,
    Filter: string,
    ActiveFilter:string,
    FromDate: string,
    ToDate: string
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceMappingTrackDetails?UserName=${UserName}&workflowOrder=${workflowOrder}&LocationID=${LocationID}&Filter=${Filter}&ActiveFilter=${ActiveFilter}&FromDate=${FromDate}&ToDate=${ToDate}`;
    return this._httpClientService.getData<ResourceMapping[]>(
      url,
      this.headers
    );
  }
  GetTMResourceWorkFlow(tmvcmid: number) {
    const url = `ResourceOnboarding/GetTMResourceWorkFlow?tmvcmid=${tmvcmid}`;
    return this._httpClientService.getData<ResourceWorkflow[]>(
      url,
      this.headers
    );
  }

  GetResourceMIDcreationPendingList(
    UserName: string,
    LocationID: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceMIDcreationPendingList?UserName=${UserName}&LocationID=${LocationID}`;
    return this._httpClientService.getData<ResourceMapping[]>(
      url,
      this.headers
    );
  }

  SaveResourceAssetDetails(roleType: ResourceBasicDts): Observable<any> {
    const url = `ResourceOnboarding/SaveResourceAssetDetails`;
    return this._httpClientService
      .postwithbody(url, roleType, this.headers)
      .pipe(
        map((data: any) => {
          const IsValide: string = (data==(null||"")?null:data) as string;
          return IsValide;
        })
      );
  }

  SearchDataFromAd(MID: string) {
    const url = `ResourceOnboarding/SearchDataFromAd?MID=${MID}`;
    return this._httpClientService
      .getData<ResourceWorkflow[]>(url, this.headers)
      .pipe(
        map((data: any) => {
          const IsValide: string = data as string;
          return IsValide;
        })
      );
  }

  GetResourceMappingMilestonePendingList(
    UserName: string,
    LocationID: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceMappingMilestonePendingList?UserName=${UserName}&LocationID=${LocationID}`;
    return this._httpClientService.getData<FpResourceMapping[]>(
      url,
      this.headers
    );
  }

  submitMilestoneApprovaldata(
    contractlist: FpResourceMapping[]
  ): Observable<any> {
    return this._httpClientService.postList(
      'ResourceOnboarding/saveMilestoneApprovaldata',
      contractlist,
      this.headers
    );
  }

  SaveOnboardingMilestoneResourceMapping(result: any): Observable<any> {
    if (result != null && result.length > 0) {
      const url = 'ResourceOnboarding/SaveOnBoardingMilestoneResourceMapping';
      return this._httpClientService.postListWithBody(
        url,
        result,
        this.headers
      );
    }
    return new Observable();
  }

  GetResourceMappingMonthlyPendingList(
    UserName: string,
    LocationID: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceMappingMonthlyPendingList?UserName=${UserName}&LocationID=${LocationID}`;
    return this._httpClientService.getData<FpResourceMapping[]>(
      url,
      this.headers
    );
  }
  submitMonthlyApprovaldata(
    contractlist: FpResourceMapping[]
  ): Observable<any> {
    return this._httpClientService.postList(
      'ResourceOnboarding/saveMonthlyApprovaldata',
      contractlist,
      this.headers
    );
  }

  SaveOnboardingMonthlyResourceMapping(result: any): Observable<any> {
    debugger;
    if (result != null && result.length > 0) {
      const url = 'ResourceOnboarding/SaveOnBoardingMonthlyResourceMapping';
      return this._httpClientService.postListWithBody(
        url,
        result,
        this.headers
      );
    }
    return new Observable();
  }

  GetFPmonthlyResourceWorkFlow(fbcIntID: number) {
    const url = `ResourceOnboarding/GetFPmonthlyResourceWorkFlow?fbcIntID=${fbcIntID}`;
    return this._httpClientService.getData<ResourceWorkflow[]>(
      url,
      this.headers
    );
  }

  GetFPmilestoneResourceWorkFlow(fbcIntID: number) {
    const url = `ResourceOnboarding/GetFPmilestoneResourceWorkFlow?fbcIntID=${fbcIntID}`;
    return this._httpClientService.getData<ResourceWorkflow[]>(
      url,
      this.headers
    );
  }
  GetMilestoneDetailsBySowNum(SowNumber: string)
  {
    const url = `ResourceOnboarding/GetMilestoneDetailsBySowNum?SowNumber=${SowNumber}`;
    return this._httpClientService.getData<MilestoneDetails[]>(
      url,
      this.headers
    );
  }
  
  GetMonthlyDetailsBySowNum(SowNumber: string)
  {
    const url = `ResourceOnboarding/GetMonthlyDetailsBySowNum?SowNumber=${SowNumber}`;
    return this._httpClientService.getData<MonthlyDetails[]>(
      url,
      this.headers
    );
  }

  GetMilestoneMIDcreationPendingList(
    UserName: string,
    LocationID: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetMilestoneMIDcreationPendingList?UserName=${UserName}&LocationID=${LocationID}`;
    return this._httpClientService.getData<FpResourceMapping[]>(
      url,
      this.headers
    );
  }
  GetMonthlyMIDcreationPendingList(
    UserName: string,
    LocationID: number
  ): Observable<any> {
    const url = `ResourceOnboarding/GetMonthlyMIDcreationPendingList?UserName=${UserName}&LocationID=${LocationID}`;
    return this._httpClientService.getData<FpResourceMapping[]>(
      url,
      this.headers
    );
  }
  SaveMonthlyResourceAssetDetails(roleType: ResourceBasicDts): Observable<any> {
    const url = `ResourceOnboarding/SaveMonthlyResourceAssetDetails`;
    return this._httpClientService
      .postwithbody(url, roleType, this.headers)
      .pipe(
        map((data: any) => {
          const IsValide: string = (data==(null||"")?null:data) as string;
          return IsValide;
        })
      );
  }
  SaveMilestoneResourceAssetDetails(
    roleType: ResourceBasicDts
  ): Observable<any> {

    const url = `ResourceOnboarding/SaveMilestoneResourceAssetDetails`;
    return this._httpClientService
      .postwithbody(url, roleType, this.headers)
      .pipe(
        map((data: any) => {
          const IsValide: string = (data==(null||"")?null:data) as string;
          return IsValide;
        })
      );
  }

  sendFPOpenPositionsToVendor(
    contractlist: FpResourceMapping[]
  ): Observable<any> {
  
    return this._httpClientService.postList(
      'ResourceOnboarding/sendFPOpenPositionsToVendor',
      contractlist,
      this.headers
    );
  }

  GetResourceFPmonthlyTrackList(
    UserName: string,
    workflowOrder: number,
    LocationID: number,
    Filter: string,
    ActiveFilter:string,
    FromDate: string,
    ToDate: string
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceFPmonthlyTrackDts?UserName=${UserName}&workflowOrder=${workflowOrder}&LocationID=${LocationID}&Filter=${Filter}&ActiveFilter=${ActiveFilter}&FromDate=${FromDate}&ToDate=${ToDate}`;
    return this._httpClientService.getData<ResourceTrack[]>(
      url,
      this.headers
    );
  }
  GetResourceFPmilestoneTrackList(
    UserName: string,
    workflowOrder: number,
    LocationID: number,
    Filter: string,
    ActiveFilter:string,
    FromDate: string,
    ToDate: string
  ): Observable<any> {
    const url = `ResourceOnboarding/GetResourceFPmilestoneTrackDts?UserName=${UserName}&workflowOrder=${workflowOrder}&LocationID=${LocationID}&Filter=${Filter}&ActiveFilter=${ActiveFilter}&FromDate=${FromDate}&ToDate=${ToDate}`;
    return this._httpClientService.getData<ResourceTrack[]>(
      url,
      this.headers
    );
  }

  GetTMmultiRcrsByPsCode(PositionCode: string): Observable<any> {
 
    const url = `ResourceOnboarding/GetMultipleResourceByPositionCode?PositionCode=${PositionCode}`;
    return this._httpClientService.getData<TmPositionTrack[]>(
      url,
      this.headers
    );
  }

  DeleteIntrResourceTMdata(tmrmid: number): Observable<any> {
    const url = 'ResourceOnboarding/DeleteIntrResourceTMdataById';
    return this._httpClientService.postwithbody(url, tmrmid, this.headers);
  }

  DeleteIntrResourceFPmyldataById(fpintid: number): Observable<any> {
    const url = 'ResourceOnboarding/DeleteIntrResourceFPmyldataById';
    return this._httpClientService.postwithbody(url, fpintid, this.headers);
  }

  DeleteIntrResourceFPmlsdataById(fpintid: number): Observable<any> {
    const url = 'ResourceOnboarding/DeleteIntrResourceFPmlsdataById';
    return this._httpClientService.postwithbody(url, fpintid, this.headers);
  }
}
