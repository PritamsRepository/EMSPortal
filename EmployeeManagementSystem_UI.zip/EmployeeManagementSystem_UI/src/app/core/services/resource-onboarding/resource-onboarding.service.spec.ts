import { TestBed } from '@angular/core/testing';

import { ResourceOnboardingService } from './resource-onboarding.service';

describe('ResourceOnboardingService', () => {
  let service: ResourceOnboardingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ResourceOnboardingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
