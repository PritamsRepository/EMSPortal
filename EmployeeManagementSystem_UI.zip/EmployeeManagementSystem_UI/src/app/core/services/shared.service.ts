import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, catchError, tap, throwError } from 'rxjs';
import { HttpclientService } from './HttpClientServices';
import { StorageService } from './storage/storage.service';
import { IUpdatePreference } from '../interfaces/irole-location-preferences';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root',
})
export class SharedService {
  headers: HttpHeaders;
  header: any;
  errorMessage: any;
  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _httpService: HttpclientService,
    private readonly _storageService: StorageService,
    private readonly router: Router
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
  }

  private sidebarVisibleSource = new Subject<boolean>();
  sidebarVisible$ = this.sidebarVisibleSource.asObservable();

  setSidebarVisible(value: boolean): void {
    this.sidebarVisibleSource.next(value);
  }

  public setupLocationAndRoles(mid: string): Observable<any> {
    // const url = `Authentication/GetLocationsWithRoles?id=${mid}`;
    // const result = this._httpClientService.get<any>(url);
    // return result;

    const params = new HttpParams().set('id', mid);
    const result = this._httpClientService.getById<any>(
      'Authentication/GetLocationsWithRoles',
      this.headers,
      params
    );
    return result;
  }

  UpdatePreferenceAndReload(pref: IUpdatePreference): Observable<any> {
    //return this._httpService.post('Authentication/UpdateRolePreference', pref);
    return this._httpClientService.postwithbody(
      'Authentication/UpdateRolePreference',
      pref,
      this.headers
    );
  }

  GetAllMasterDetails(): Observable<any> {
    //return this._httpService.get('Masters/GetAllEMSMasterDetails');
    const result = this._httpClientService.getList<any>(
      'Masters/GetAllEMSMasterDetails',
      this.headers
    );
    return result;
  }
  private handleError(err: any): Observable<never> {
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occurred: ${err}`;
    } else {
      errorMessage = `Backend returned code ${err.status}: ${err.errorMessage}`;
    }
    //console.error(errorMessage)
    return throwError(() => new Error(errorMessage));
  }
}
