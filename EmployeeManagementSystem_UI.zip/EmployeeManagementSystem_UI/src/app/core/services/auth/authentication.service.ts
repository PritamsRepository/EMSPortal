import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ILogin } from '../../interfaces/ilogin';
import { OnInit, Injectable } from '@angular/core';
import { catchError, map, Observable, throwError, tap } from 'rxjs';
import { HttpclientService } from 'src/app/core/services/HttpClientServices';
import { JsonPipe } from '@angular/common';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  isAuthenticated() {
    throw new Error('Method not implemented.');
  }
  header: any;
  headers: HttpHeaders;
  errorMessage: any;

  constructor(
    private readonly _httpService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
  }

  ngOnInit() {}

  //get the user's windows account from api
  AuthByWindows(): Observable<any> {
    // return this._httpService.get('Authentication/AuthByWindows');
    return this._httpService.post('Authentication/AuthByWindows',null).pipe(
      tap((user) => {
        if (user) {
        }
        return user;
      })
    );
  }

  login(login: ILogin): Observable<any> {
    const body = JSON.stringify(login);
    return this._httpService.post('Authentication/Login', login).pipe(
      tap((user) => {
        if (user) {
        }
        return user;
      })
    );
  }

  logout(): Observable<any> {
    var token = sessionStorage.getItem('jwt_token');
    this.header = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
    });

    // var result = this._storageService.clean();

    //console.log("userId",this._storageService.getCurrentUserMID());
    //console.log("header",this.header);
    const url = `Authentication/SignOut?id=${this._storageService.getCurrentUserMID()}`;
    return this._httpService.postWithHeaders(url, this.header).pipe(
      tap((data) => {
        return data;
      }),
      catchError(this.handleError)
    );
  }

  private handleError(err: any): Observable<never> {
    let error_Message: string;
    if (err.error instanceof ErrorEvent) {
      error_Message = `An error occurred: ${err}`;
    } else {
      error_Message = `Backend returned code ${err.status}: ${err.errorMessage}`;
    }
    //console.error(errorMessage)
    return throwError(() => new Error(error_Message));
  }

  hasRoles(expectedRole: string[]): boolean {
    // Retrieve roles from session storage
    const storedRolesJSON = sessionStorage.getItem('AssignedRoles');

    if (storedRolesJSON) {
      const storedRoles: any[] = JSON.parse(storedRolesJSON);
      const selectedRoleMasterId =
        this._storageService.getCurrentUserRoleMasterID();

      // Get the role details based on the selectedRoleMasterId
      const selectedRoleDetails = storedRoles.find(
        (role) => role.roleMasterId == selectedRoleMasterId
      );

      //console.log('assigned roles : ', storedRoles);
      //console.log('Selected role : ', selectedRoleDetails.roleType);
      //console.log('Excpected role : ', expectedRole);

      // Check if the user has any of the expected roles
      return expectedRole.includes(selectedRoleDetails.roleType);
    }

    return false;
  }

  createAuthorizationHeader(): HttpHeaders {
    // let tok = 'My token';
    // return new Headers({ 'X-Authorization': `Bearer ${tok}` })

    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });
    return this.headers;
  }
}
