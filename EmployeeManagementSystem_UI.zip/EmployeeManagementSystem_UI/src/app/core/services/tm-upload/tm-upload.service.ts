import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { iTmContractModal, itmUpload } from '../../interfaces/itmupload';
import { HttpclientService } from '../HttpClientServices';
import { StorageService } from '../storage/storage.service';
import { itmDetails, itmEditedDetails } from '../../interfaces/itmDetails';
import { BulkUpdateFilterType } from '../../interfaces/bulk-update-filter-type';
import { BulkUpdateValidation, FieldType } from '../../interfaces/field-type';
import { SowList } from '../../interfaces/sow-list';
import { EmsFetchContactListBySowNo } from '../../interfaces/ems-fetch-contact-list-by-sow-no';

@Injectable({
  providedIn: 'root',
})
export class TmUploadService implements OnInit {
  header: any;
  headers: any;
  errorMessage: any;

  constructor(
    private readonly _httpClientService: HttpclientService,
    private readonly _storageService: StorageService
  ) {
    const headerSettings: Record<string, string | string[]> = {};
    this.header = new HttpHeaders(headerSettings);
    // //console.log(this._storageService.getCurrentToken());
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${this._storageService.getCurrentToken()}`,
      // Authorization: `Bearer ${window.sessionStorage.getItem('token')}`
    });

    //console.log('tmHeader', this.headers);
  }
  ngOnInit() {
    var user = this._storageService.getCurrentUserMID();
  }

  getTMContractIntermediateDetails(): Observable<itmUpload[]> {
    const result = this._httpClientService
      .getList<itmUpload>('Contracts/GetTMContractINt', this.headers)
      .pipe();
    return result;
  }

  getTMContractMainDetails(Filter: string): Observable<itmUpload[]> {
    // below params are not being used may come into use in upcoming days based on requirement change on filters.
    const FromDate: string = '01-jan-1947';
    const ToDate: string = '01-jan-2500';

    const params = new HttpParams()
      .set('Filter', Filter)
      .set('FromDate', FromDate)
      .set('ToDate', ToDate);
    console.log(params);

    const result = this._httpClientService
      .getListByIdWithHeaders<itmUpload>(
        'Contracts/GetTMVendorContractMasterDetails',
        this.headers,
        params
      )
      .pipe();
    return result;
  }

  getTMContractSendbackDetails(): Observable<itmUpload[]> {
    const result = this._httpClientService
      .getList<itmUpload>(
        'Contracts/GetTMVendorContractSendbackDetails',
        this.headers
      )
      .pipe();
    return result;
  }

  saveTMContractIntermediateDetails(
    selectedDetails: number[]
  ): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/SaveTMIntermediateDataToMain',
      selectedDetails,
      this.headers
    );
  }

  updateTMApprovedSowDtsContractDetails(tmDetails: itmEditedDetails): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/UpdateApprovedSowDtsTMContractDetails',
      tmDetails,
      this.headers
    );
  }

  updateTMApprovedContractDetails(tmDetails: itmEditedDetails): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/UpdateApprovedTMContractDetails',
      tmDetails,
      this.headers
    );
  }

  updateTMContractDetails(tmDetails: itmEditedDetails): Observable<any> {
    //console.log('date type :', typeof tmDetails.sowstartDate);

    return this._httpClientService.postwithbody(
      'Contracts/UpdateTMContractDetails',
      tmDetails,
      this.headers
    );
  }

  removeTMContractIntermediateDetails(
    selectedDetails: number[]
  ): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/DeleteTMIntermediateData',
      selectedDetails,
      this.headers
    );
  }

  removeTMContractSendBackDetails(
    tmIntId: number,
    remarks: string
  ): Observable<any> {
    interface deletedata {
      tmIntId: number;
      remarks: string;
    }

    const data: deletedata = {
      tmIntId: tmIntId,
      remarks: remarks,
    };

    return this._httpClientService.postwithbody(
      'Contracts/DeleteTMSendbackData',
      data,
      this.headers
    );
  }

  getTMContractWorkFlow(tmcid: number): Observable<any[]> {
    //const url = `Contracts/GetWorkFlowsOfContract?tmcid=${tmcid}`;
    const params = new HttpParams().set('tmcid', tmcid);
    const result = this._httpClientService.getById<any>(
      'Contracts/GetWorkFlowsOfContract',
      this.headers,
      params
    );
    return result;
  }

  UploadTMDetails(tmContracts: iTmContractModal[]): Observable<any> {
    debugger;
    console.log(this.headers);
    return this._httpClientService.postwithbody(
      'Contracts/TMContractUpload',
      tmContracts,
      this.headers
    );
  }

  GetSowListByContractType(ContractType: string, SearchSowText: string): Observable<SowList[]> {
    const params = new HttpParams()
      .set('ContractType', ContractType)
      .set('SearchSowText', SearchSowText);

    const result = this._httpClientService
      .getListByIdWithHeaders<SowList>(
        'Contracts/GetSowListByContractType',
        this.headers,
        params
      )
      .pipe();
    return result;
  }

  GetAllSowListByContractType(ContractType: string, sowNO: string): Observable<EmsFetchContactListBySowNo[]> {
    const params = new HttpParams()
      .set('ContractType', ContractType)
      .set('sowNo', sowNO);

    const result = this._httpClientService
      .getListByIdWithHeaders<EmsFetchContactListBySowNo>(
        'Contracts/GetAllSowListByContractType',
        this.headers,
        params
      )
      .pipe();
    return result;
  }

  GetOldValueByContractSowType(ContractType: string, sowNumber: string, fieldType: string): Observable<FieldType[]> {
    const params = new HttpParams()
      .set('ContractType', ContractType)
      .set('sowNumber', sowNumber)
      .set('fieldType', fieldType);
    const result = this._httpClientService
      .getListByIdWithHeaders<FieldType>(
        'Contracts/GetOldValueByContractSowType',
        this.headers,
        params
      )
      .pipe();
    return result;
  }

  getValidationStatusForColumn(ContractType: string, sowNumber: string, fieldType: string, newValue: string): Observable<BulkUpdateValidation[]> {
    const params = new HttpParams()
      .set('ContractType', ContractType)
      .set('sowNumber', sowNumber)
      .set('fieldType', fieldType)
      .set('newValue', newValue);
    const result = this._httpClientService
      .getListByIdWithHeaders<BulkUpdateValidation>(
        'Contracts/GetValidationStatusForColumn',
        this.headers,
        params
      )
      .pipe();
    return result;
  }

  UpdateContractColumnBySowNumber(tmDetails: BulkUpdateFilterType): Observable<any> {
    return this._httpClientService.postwithbody(
      'Contracts/UpdateContractColumnBySowNumber',
      tmDetails,
      this.headers
    );
  }
}
