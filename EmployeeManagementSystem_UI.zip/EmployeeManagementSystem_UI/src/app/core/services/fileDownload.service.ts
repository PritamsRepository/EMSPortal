import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class fileDownload {
  downloadFile(path: string): Observable<Blob> {
    const url = path; // Assuming the file is in the root folder
    return new Observable((observer) => {
      const xhr = new XMLHttpRequest();
      xhr.responseType = 'blob';
      xhr.onload = () => {
        observer.next(xhr.response);
        observer.complete();
      };
      xhr.open('GET', url);
      xhr.send();
    });
  }
}
