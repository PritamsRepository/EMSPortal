export interface ILocation {
  locationId: number;
  locationName: string;
}

export interface IRole {
  locationId: string;
  roleMasterId: string;
  roleType: string;
}

export interface IUpdatePreference {
  locationId?: number;
  roleMasterId?: number;
  userId?: string;
}
