export interface ResourceBasicDts {
    mid: string;
    email?: string;
    rmid?: number;
    cmid?: number;
}
