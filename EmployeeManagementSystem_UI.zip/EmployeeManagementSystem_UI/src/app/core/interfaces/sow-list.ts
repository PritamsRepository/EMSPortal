export interface SowList {
    sownumber? :string;
}