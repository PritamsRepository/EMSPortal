import { IDropDownKeyValue } from "./idropdown-key-value";

export interface LocationAndRoleMaster {

    mid: string;
    displayName?: string;
    email?: string;
    locationName?: string;
    isPrimary?: boolean;
    isActive?: boolean;
    roleType: IDropDownKeyValue[];
  locationMaster: IDropDownKeyValue[];

} 