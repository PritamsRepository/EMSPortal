import { ifpmapproval } from "./ifpmlapproval";
import { ifpmonapproval } from "./ifpmonapproval";
export interface ifpapproval {
 
    FBCMilestoneIntID	:number,
    fbcIntID:number,
    CMID:number;
     etwid :string;
     vendorName :string;
     vendorID :number;
     sowNumber :string;
     sowName :string;
     sowType :string;
     remappedMID :string;
     sowStartDate? :Date;
     sowEndDate? :Date;
     poNumber :string;
     poStartDate? :Date;
     
     poEndDate? :Date;
     ppmProjectID :string;
     ppmProjectName :string;
     tower :string;
     vertical :string;
     wbsDetail :string;
     domainLeadEmail :string;
     costCenter :string;
     domainName:string;
     domainSkillName:string;
     skillSet :string;
     domainSkillStartDate :Date;
     domainSkillEndDate :Date;
     projectOrRun :string;
     contractType :string;
     billingType :string;
    
     positionLocation:string;
     oldSowNumber :string;
     pendingwithwhom?:string;
     obs :string;
     amortizationStartMonth: string;
     amortizationEndMonth: string;
     updatedBy :string;
     updatedDate :Date;
     validationRemarks :string;
     isSelectedApproval:boolean;
     remarks:string;
     wfOrder:number;
     status:string;
     milestones?:ifpmapproval[];
     monthly?:ifpmonapproval[];
}