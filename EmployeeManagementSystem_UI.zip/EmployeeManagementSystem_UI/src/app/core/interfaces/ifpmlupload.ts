export interface ifpmlUpload {
 
    fbcMilestoneIntID	:number
    sowNumber	: string;
    milestone	: string;
    milstoneDescription	: string;
    milestoneAmount	:number
    currency	: string;
    validationRemarks: string;

}