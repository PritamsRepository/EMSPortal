export interface MilestoneDetails {
    etwid? :string;
    milestone? :string;
    sowNumber? :string;
    milestoneDescription? :string;
    milestoneAmount? :number;
    currency? :string;
}
