import { IDropDownKeyValue } from "./idropdown-key-value";


export interface Roletypemapping {
  roleTypeId?: number;
  roleTypeName?: string;
  mid?: string;
  name?: string;
  emailId?: string;
  locationName?: string;
  locationId?: number;
  isPrimary?: boolean;
  isActive?: boolean;
  roleType?: IDropDownKeyValue[];
  locationMaster?:IDropDownKeyValue[];
  selectedLocation?:[];
}

// public int? RoleTypeID { get; set; }
// public string RoleTypeName { get; set; }
// public string MID { get; set; }
// public string Name { get; set; }
// public string EmailID { get; set; }
// public string LocationName { get; set; }
// public int LocationID { get; set; }
// public bool IsPrimary { get; set; }
// public bool IsActive { get; set; }
// public List<DropdownKeyValue> RoleType { get; set; }
// public List<DropdownKeyValue> LocationMaster { get; set; }