export interface IContractSummaryReport {
    srid:number,
    summaryName?:string,
    summaryType?: string,
    towerHead?: string,
    totalL1Position?: number,
    totalL2Position?: number,
    totalL3Position?: number,
    totalPosition?: number,
    l1ClosedPosition?: number,
    l2ClosedPosition?: number,
    l3ClosedPosition?: number,
    totalClosedPositions?: number,
    openL1Position?: number,
    openL2Position?: number,
    openL3Position?: number,
    totalOpenPosition?: number,
 


    
    l1Unfulfilled?: number,
    l2Unfulfilled?: number,
    l3Unfulfilled?: number,
    overallUnfullfilled?: number,
    l1Selected?: number, 
    l2Selected?: number,
    l3Selected?: number,
    totalSelected?: number,
    l1Backup?: number,
    l2Backup?: number,
    l3Backup?: number,
    totalBackup?: number,

}
