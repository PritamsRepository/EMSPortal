export interface iVendorMaster {
  vendorId: Number;
  vendorName: string;
}

export interface iSowTypeMaster {
  sowTypeId: Number;

  sowTypeName: string;
}

export interface iBillingTypeMaster {
  billingTypeId: Number;

  billingTypeName: string;
}

export interface iContractTypeMaster {
  contractTypeId: Number;

  contractTypeName: string;
}

export interface iVerticalMaster {
  verticalId: Number;

  verticalName: string;
}

export interface iLocationMaster {
  locationId: Number;

  locationName: string;
}

export interface iTowerNameMaster {
  towerNameId: Number;

  towerName: string;
}

export interface iSkillSetMaster {
  skillId: Number;

  skillSet: string;
}

export interface iProjectOrRunMaster {
  projectOrRunId: Number;

  projectOrRun: string;
}

export interface iObsMaster {
  obsmasterId: Number;

  obsmasterName: string;
}
