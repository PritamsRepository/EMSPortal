export interface MonthlyDetails {
    sowNumber?:string;
    amortizationStartDate?:Date;
    amortizationEndDate?:Date;
    amount?:number;
    duration?:number;
    currency?:string;
    updateDate?:Date;
    updatedBy?:string;

}
