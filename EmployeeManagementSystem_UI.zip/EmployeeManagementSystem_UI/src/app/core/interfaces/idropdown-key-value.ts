export interface IDropDownKeyValue {
    Id: number
    Name: string
  }
  