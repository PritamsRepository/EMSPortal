export interface BulkUpdateBySow {
    contractType: string;
    searchSowText: string;
    sowNumber: string;
    fieldType: string;
    oldValue: string;
    newValue: string;
    field: string
}