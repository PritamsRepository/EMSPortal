export interface FieldType {
    fieldValue? :string;
}
export interface BulkUpdateValidation {
    message? :string;
}