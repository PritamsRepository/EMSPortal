export interface AssetDetails {
    isAssetRequired? :boolean;
    assets?:string;
     mid? :string;
      email? :Date;
      rmid?:string;
}
