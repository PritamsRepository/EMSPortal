

export interface ResourceMapping {
    
    etwid? :string;
    vendorName? :string;
    vendorID? :number;
    sowNumber? :string;
    sowName? :string;
    sowStartDate? :Date;
    sowEndDate? :Date;
    poNumber? :string;
    poStartDate? :Date;
    poEndDate? :Date;
    ppmProjectID? :string;
    ppmProjectName? :string;
    tower? :string;
    domainName? :string;
    skillSet? :string;
    domainSkillStartDate? :Date;
    domainSkillEndDate? :Date;
    projectOrRun? :string;
    contractType? :string;
    billingType? :string;
    billingRateYear1? :number;
    positionCode? :string;
    firstName? :string;
    lastName? :string;
    gender? :string;
    dojViatris? :Date;
    managerName? :string;
    managerEmail? :string;
    managerMid? : string;
    mobileNumber? :string;
    costCenter? :string;
    isSelectedApproval? :boolean;
   validationRemarks?:string;
    remarks? :string;
     dob? :Date;
     vendorEmails?:string;
     positionLocationId?:number;
     tmcmid?:number;
     tmvcmid?:number;
     rmid?:number;
     tmrmid?:number;
     remappedMID? : string;
     uploadedBy?:string;
     customDomainName?:string;
}

