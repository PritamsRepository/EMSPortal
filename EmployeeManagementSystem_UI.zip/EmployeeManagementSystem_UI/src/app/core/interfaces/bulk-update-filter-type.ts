export interface BulkUpdateFilterType {
    ContractType: string;
    SearchSowText: string;
    SOWNumber: string;
    FieldType: string;
    oldValue: string;
    newValue: string;
    dataType: string;
}