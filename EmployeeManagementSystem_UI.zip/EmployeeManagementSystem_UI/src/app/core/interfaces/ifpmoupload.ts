export interface ifpmoUpload {
    fbMonthlyIntID:number
    sowNumber: string;
    amortizationStartDate: string;
    amortizationEndDate: string;
    milestoneAmount: string;
    durationOfMonth: string;
    currency: string;
    validationRemarks: string;
}