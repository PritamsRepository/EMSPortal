export interface TmPositionTrack {
   
    positionCode?: string;
    viatrisMID?: string;
    firstName?: string;
    lastName?: string;
    mappedBy?: string;
    isMappingActive?: boolean;
    mappedDate?: Date;
    status?: string;
    vendorName?:string;
}
