export interface IErrorLog {
  errorCode:string,
  errorMessage:string,
  errorUrl:string,
  errorType:string,
  userId:string
  
}
