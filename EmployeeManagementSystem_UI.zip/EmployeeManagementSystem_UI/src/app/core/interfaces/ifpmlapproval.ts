export interface ifpmapproval {
 
    FBCMilestoneIntID	:number
    SOWNumber	: string;
    Milestone	: string;
    MilstoneDescription	: string;
    MilestoneAmount	:number
    Currency	: string;
    ValidationRemarks: string;
    isSelectedApproval:boolean;
    remarks:string;
    wfOrder:number;
    status:string
}