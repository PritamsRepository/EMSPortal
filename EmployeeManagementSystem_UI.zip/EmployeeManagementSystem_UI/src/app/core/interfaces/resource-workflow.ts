export interface ResourceWorkflow {
    cmid? :number;
    role? :string;
    actionByMid? :string;
    actionByName? :string;
    actionDate? :Date;
    action? :string;
    remarks? : string;
    nextWfrole? :string;
}
