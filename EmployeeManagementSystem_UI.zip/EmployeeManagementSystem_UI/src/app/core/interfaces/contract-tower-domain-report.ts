export interface ContractTowerDomainReport {
    domainName ? :string;
    towerHead ? :string;
    totalRequiredPositions ? :number;
    l1Position ? :number;
    l1OnBoarder ? :number;
    l1Openposition ? :number;
    l1PositionOpenDate ? :string;
    l1AgingDays ? :string;
    l1Selected ? :number;
    l1BackUp ? :number;
    l1ResourceDOJ ? :string;
    l2Position ? :number;
    l2OnBoarder ? :number;
    l2Openposition ? :number;
    l2PositionOpenDate ? :string;
    l2AgingDays ? :string;
    l2Selected ? :number;
    l2BackUp ? :number;
    l2ResourceDOJ ? :string;
    l3Position ? :number;
    l3OnBoarder ? :number;
    l3Openposition ? :number;
    l3PositionOpenDate ? :string;
    l3AgingDays ? :string;
    l3Selected ? :number;
    l3BackUp ? :number;
    l3ResourceDOJ ? :string;
    overallOnboarded ? :number;
    overallOpenPostion ? :number;
    overallselected ? :number;
    unfullfilled ? :number;
    projOrRun?:string;
    customDomainName?:string;


}
