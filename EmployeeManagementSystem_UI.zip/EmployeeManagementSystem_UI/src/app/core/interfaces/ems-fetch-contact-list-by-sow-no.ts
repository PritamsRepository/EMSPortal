export interface EmsFetchContactListBySowNo {
    SOWNumber: string;
    SOWName: string;
    SOWStartDate?: Date;
    SOWEndDate?: Date;
    PONumber: string;
    POStartDate?: Date;
    POEndDate?: Date;
    PPMProjectID: string;
    PPMProjectName: string;
    WBSDetail: string;
    CostCenter: string;
    OBS?: string;
    ProjectOrRunID?: number;
    BillingTypeID?: string;
    SAPCode?: number;
    NoticePeriod?: string;
    IsActive?: boolean
  }
  