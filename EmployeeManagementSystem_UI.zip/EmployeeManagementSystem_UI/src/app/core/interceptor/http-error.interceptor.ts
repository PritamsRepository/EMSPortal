import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
  HttpHandler,
  HttpEvent,
} from '@angular/common/http';
import { Observable, of, EmptyError, EMPTY, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Router } from '@angular/router';
import { IErrorLog } from '../interfaces/ierror-log';
import { StorageService } from '../services/storage/storage.service';
import { ErrorService } from '../services/error/error.service';
@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  constructor(
    private _router: Router,
    private readonly _storageService: StorageService,
    private readonly _errorService: ErrorService
  ) { }
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {
        sessionStorage.removeItem('ErrorMessage');
        let errorMessage = '';
        var errorLog = {} as IErrorLog;

        if (err.error instanceof ErrorEvent) {
          errorMessage = err.error.message;
        } else {
          switch (err.status) {

            case 400:
              errorMessage =
                err.error.Error == undefined
                  ? err.error
                  : err.error['message'].toString() + err.message;
              break;

            case 401:
              errorMessage = 'UnAuthorized Access.';
              break;

            case 404:
              errorMessage = 'Resource Not Found';
              break;


            case 500:
              errorMessage =
                err.error.Error == undefined
                  ? err.error
                  : err.error['message'].toString() + err.message;
              break;

            case 501:
              errorMessage =
                err.error.Error == undefined
                  ? err.error
                  : err.error['message'].toString() + err.message;
              break;

            case 503:
              errorMessage =
                err.error.Error == undefined
                  ? err.error
                  : err.error['message'].toString() + err.message;
              break;

            case 504:
              errorMessage =
                err.error.Error == undefined
                  ? err.error
                  : err.error['message'].toString() + err.message;
              break;

            default:
              console.log('Unhandled Error:',err);
              errorMessage = 'System Error. Please contact IT Team.';
              break;
          }
        }
        // console.log(err);
        sessionStorage.setItem('ErrorMessage', errorMessage);
        if (err.url.includes('Login')) {
          throw new Error(err.error);
        }

        errorLog.errorCode = err.status.toString();
        errorLog.errorMessage = errorMessage;
        errorLog.errorType = err.name;
        errorLog.errorUrl = err.url;
        errorLog.userId = this._storageService.getCurrentUserMID();
        //console.log('rrorObj', errorLog);
        this._errorService.logGeneratedError(errorLog).subscribe();
        this._router.navigate(['/main/error']);

        return EMPTY;
      })
    );
  }
}
