export enum ReportType{
    Detail="DetailReport",
    Summary="SummaryReport",
    OpenPosition="OpenPositionReport"
}