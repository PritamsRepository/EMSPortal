export enum DefinedRoles {
  Super_Admin = 'Super Admin',
  Admin = 'Admin',
  PMO_Admin = 'PMO-Admin',
  PMO_Contract_Mgm = 'PMO-Contract-Mgm',
  IT_Finance_Manager = 'IT Finance Manager',
  Local_IT = 'Local IT',
  Report_Access = 'Report Access',
  HR = 'HR',
  Vendor = 'Vendor',
}
