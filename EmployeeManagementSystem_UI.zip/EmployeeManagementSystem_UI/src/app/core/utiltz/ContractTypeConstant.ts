export enum ContractTypeConstant {
    TM = 'T&M',
    FIXED_MILESTONE = 'Fixed Milestone',
    FIXED_MONTHLY = 'Fixed Monthly'
}

export const CT_NAMES = Object.values(ContractTypeConstant);