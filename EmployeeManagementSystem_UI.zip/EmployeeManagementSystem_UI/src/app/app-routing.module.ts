import { ContractsDomainTowerleadComponent } from './components/reports/contracts-domain-towerlead/contracts-domain-towerlead.component';
import { FpResourceMidMenuComponent } from './components/resource-onboarding/fp-resource-mid-menu/fp-resource-mid-menu.component';
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MainComponent } from './components/layout/main/main.component';
import { TmUploadComponent } from './components/tm-upload/tm-upload.component';
import { EmployeerolemappingComponent } from './components/admin/master/employeerolemapping/employeerolemapping.component';
import { TmApprovalComponent } from './components/tm-approval/tm-approval.component';
import { LogoutComponent } from './components/logout/logout.component';
import { FpuploadcontractComponent } from './components/fp-upload/fpuploadcontract/fpuploadcontract.component';
import { FpuploadmilestoneComponent } from './components/fp-upload/fpuploadmilestone/fpuploadmilestone.component';
import { FpuploadmonthlyComponent } from './components/fp-upload/fpuploadmonthly/fpuploadmonthly.component';
import { TmTrackComponent } from './components/tm-track/tm-track.component';
import { FpApprovalmenuComponent } from './components/fp-approval/fp-approvalmenu/fp-approvalmenu.component';
import { FpApprovalmilestoneComponent } from './components/fp-approval/fp-approvalmilestone/fp-approvalmilestone.component';
import { FpApprovalmonthlyComponent } from './components/fp-approval/fp-approvalmonthly/fp-approvalmonthly.component';
import { FpuploadmenuComponent } from './components/fp-upload/fpuploadmenu.component';
import { VendorContractlistComponent } from './components/resource-onboarding/vendor-contractlist/vendor-contractlist.component';
import { HeaderComponent } from './components/layout/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { TmViewComponent } from './components/tm-view/tm-view.component';
import { AuthenticationGuard } from './helper/guards/authentication.guard';
import { ErrorComponent } from './components/common/error/error.component';
import { TmSendbackComponent } from './components/tm-sendback/tm-sendback.component';
import { FpTrackmilestoneComponent } from './components/fp-track/fp-trackmilestone/fp-trackmilestone.component';
import { FpTrackmenuComponent } from './components/fp-track/fp-trackmenu/fp-trackmenu.component';
import { FpTrackmonthlyComponent } from './components/fp-track/fp-trackmonthly/fp-trackmonthly.component';
import { TmOnboardingTrackComponent } from './components/resource-onboarding/tm-onboarding-track/tm-onboarding-track.component';
import { AmsmasterComponent } from './components/amsmaster/amsmaster.component';
import { TmResourceMidComponent } from './components/resource-onboarding/tm-resource-mid/tm-resource-mid.component';
import { FpOnboardingApprovalMenuitemsComponent } from './components/resource-onboarding/fp-onboarding-approval-menuitems/fp-onboarding-approval-menuitems.component';
import { FpOnboardingMilestoneApprovalComponent } from './components/resource-onboarding/fp-onboarding-milestone-approval/fp-onboarding-milestone-approval.component';
import { FpOnboardingMonthlyApprovalComponent } from './components/resource-onboarding/fp-onboarding-monthly-approval/fp-onboarding-monthly-approval.component';
import { FpMilestoneMIDUpdateComponent } from './components/resource-onboarding/fp-milestone-midupdate/fp-milestone-midupdate.component';
import { FpMonthlyMIDUpdateComponent } from './components/resource-onboarding/fp-monthly-midupdate/fp-monthly-midupdate.component';
import { FpOnboardingTrackMenuComponent } from './components/resource-onboarding/fp-onboarding-track-menu/fp-onboarding-track-menu.component';
import { FpResourceMilestoneTrackComponent } from './components/resource-onboarding/fp-resource-milestone-track/fp-resource-milestone-track.component';
import { FpResourceMonthlyTrackComponent } from './components/resource-onboarding/fp-resource-monthly-track/fp-resource-monthly-track.component';
import { FpViewComponent } from './components/fp-view/fp-view.component';
import { RoleGuard } from './helper/guards/Role.guard';
import { DefinedRoles } from './core/utiltz/DefinedRolesList';
import { FpSendbackComponent } from './components/fp-sendback/fp-sendback.component';
import { ContractDetailComponent } from './components/reports/contract-detail/contract-detail.component';
import { ContractSummaryComponent } from './components/reports/contract-summary/contract-summary.component';
import { EmployeeMasterComponent } from './components/reports/employee-master/employee-master.component';
import { PublishedContractDetailsComponent } from './components/reports/published-contract-details/published-contract-details.component';
import { TmBulkUpdateComponent } from './components/tm-bulk-update/tm-bulk-update.component';
import { RenewalDashboardComponent } from './components/reports/renewal-dashboard/renewal-dashboard.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  // { path: '', component: LoginComponent, pathMatch: 'full' },

  { path: 'login', component: LoginComponent },
  {
    path: 'main',
    component: MainComponent,
    data: { title: 'Home', skipRoleCheck: true },
    canActivate: [AuthenticationGuard, RoleGuard],

    children: [
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full',
        data: { title: 'Home', skipRoleCheck: true },
      },

      {
        path: 'home',
        component: HomeComponent,
        data: { title: 'Home', skipRoleCheck: true },
      },
      {
        path: 'tmBulkUpdate',
        component: TmBulkUpdateComponent,
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
        canActivate: [RoleGuard],
      },
      {
        path: 'renewalDashboard',
        component: RenewalDashboardComponent,
        data: {
          expectedRoles: [
            DefinedRoles.PMO_Contract_Mgm,
            DefinedRoles.IT_Finance_Manager,
            DefinedRoles.Report_Access,
          ],
          skipRoleCheck: false,
        },
        canActivate: [RoleGuard],
      },
      //#region T & M  Route
      {
        path: 'tmupload',
        component: TmUploadComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'tmApproval',
        component: TmApprovalComponent,
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
        canActivate: [RoleGuard],
      },
      {
        path: 'tmTrack',
        component: TmTrackComponent,
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
        canActivate: [RoleGuard],
      },
      {
        path: 'tmContractDetails',
        component: TmViewComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
            DefinedRoles.PMO_Admin,
          ],
          skipRoleCheck: false,
        },
      },

      {
        path: 'tmSendbackDetails',
        component: TmSendbackComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      //#endregion
      //#region Fixed Bid Route

      {
        path: 'fpmenu',
        component: FpuploadmenuComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'fpcontract',
        component: FpuploadcontractComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'fpmilestone',
        component: FpuploadmilestoneComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'fpmonthly',
        component: FpuploadmonthlyComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'fpContractDetails',
        component: FpViewComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
            DefinedRoles.PMO_Admin,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'fpSendbackDetails',
        component: FpSendbackComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: false,
        },
      },
      {
        //resource manager approving resources
        path: 'vendorContractList',
        component: VendorContractlistComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resource manager to track the tm resources
        path: 'tmonboardingtrack',
        component: TmOnboardingTrackComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resource manager asssigning mid to tm resources.
        path: 'tmResourceMid',
        component: TmResourceMidComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //menus for fp approval --resource manager.
        path: 'fpOnboardApprovalMenu',
        component: FpOnboardingApprovalMenuitemsComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager to approve fp milestone .
        path: 'fpOnboardMilestoneApproval',
        component: FpOnboardingMilestoneApprovalComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager to approve fp monthly .
        path: 'fpOnboardMonthlyApproval',
        component: FpOnboardingMonthlyApprovalComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager --- menus of fp to update mid.
        path: 'fpResourceMidMenu',
        component: FpResourceMidMenuComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager --- menus of fp to update milestone mid.
        path: 'fpMilestoneMid',
        component: FpMilestoneMIDUpdateComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager --- menus of fp to update monthly mid.
        path: 'fpMonthlyMid',
        component: FpMonthlyMIDUpdateComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager --- menus of fp to track monthly resources.
        path: 'fpResourceTrackMenu',
        component: FpOnboardingTrackMenuComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager ---  to track  fp monthly resources.
        path: 'fpRsrcMonthlyTrk',
        component: FpResourceMonthlyTrackComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },
      {
        //resources manager --- to track fp milestone resources.
        path: 'fpRsrcMlstneTrk',
        component: FpResourceMilestoneTrackComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.PMO_Admin],
          skipRoleCheck: false,
        },
      },

      {
        //IT Finance manager --- fp approval menu items.
        path: 'fpapprovalmenu',
        component: FpApprovalmenuComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
      },
      {
        //IT Finance manager --- fp approval milestone data.
        path: 'fpapprovalmilestone',
        component: FpApprovalmilestoneComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
      },
      {
        //IT Finance manager --- fp approval monthly data.
        path: 'fpapprovalmonthly',
        component: FpApprovalmonthlyComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
      },
      //#endregion

      //#endregion Master Route
      {
        path: 'rolemapping',
        component: EmployeerolemappingComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.Admin],
          skipRoleCheck: false,
        },
      },
      {
        //IT Finance manager --- fp track milestone data.
        path: 'fptrackmilestone',
        component: FpTrackmilestoneComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
      },
      {
        //IT Finance manager --- fp track menus data.
        path: 'fptrackmenu',
        component: FpTrackmenuComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
            DefinedRoles.Admin,
          ],
          skipRoleCheck: false,
        },
      },
      {
        //IT Finance manager --- fp track monthly data.
        path: 'fptrackmonthly',
        component: FpTrackmonthlyComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Super_Admin,
            DefinedRoles.IT_Finance_Manager,
          ],
          skipRoleCheck: false,
        },
      },
      {
        path: 'amsmaster/:urlParameter',
        component: AmsmasterComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [DefinedRoles.Super_Admin, DefinedRoles.Admin],
          skipRoleCheck: true,
        },
      },

      //Reports Menu
      {
        path: 'contractDetailReport',
        component: ContractDetailComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
        },
      },

      {
        path: 'contractSummaryReportProject',
        component: ContractSummaryComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
          reportType: 'PPMProjectName',
        },
      },

      {
        path: 'contractSummaryReportTowerHead',
        component: ContractSummaryComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
          reportType: 'TowerHead',
        },
      },
      {
        path: 'employeeMasterDetailReport',
        component: EmployeeMasterComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
        },
      },
      {
        path: 'contractSummaryReportTowerHeadAndDomain',
        component: ContractsDomainTowerleadComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
          reportType: 'TowerHead',
        },
      },
      {
        path: 'PublishedcontractSummaryReportTowerHeadAndDomain',
        component: PublishedContractDetailsComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRoles: [
            DefinedRoles.Report_Access,
            DefinedRoles.PMO_Contract_Mgm,
          ],
          skipRoleCheck: true,
          reportType: 'TowerHead',
        },
      },
      

      { path: 'logout', component: LogoutComponent },
      { path: 'error', component: ErrorComponent },
      { path: '**', redirectTo: 'error' },
    ],
  },
  //#endregion

  //#region  Wildcard route
  { path: '**', redirectTo: 'login' },
  //#endregion
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
