import { HTTP_INTERCEPTORS } from '@angular/common/http'
import { LoadingInterceptor } from 'src/app/core/interceptor/loading.interceptor'
import { HttpRequestInterceptor } from 'src/app/core/interceptor/http-request.interceptor'
import { HttpErrorInterceptor } from './core/interceptor/http-error.interceptor';

export const interceptorProviders =
    [
      { provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true },
      { provide: HTTP_INTERCEPTORS, useClass: HttpRequestInterceptor, multi: true },
      { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true }

    ];
