import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { StorageService } from './core/services/storage/storage.service';
import { Subscription } from 'rxjs';
import {
  HttpHeaders,
  HttpClient,
  HttpResponse,
  HttpErrorResponse,
  HttpParams,
} from '@angular/common/http';
import { AuthenticationService } from './core/services/auth/authentication.service';
import { EventBusService } from './core/services/event-bus/event-bus.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Employee Management System';
  showHeader = false;

  private readonly roles: string[] = [];
  isLoggedIn = false;
  username?: string;
  eventBusSub?: Subscription;

  constructor(
    private readonly storageService: StorageService,
    private readonly authenticationService: AuthenticationService,
    private readonly eventBusService: EventBusService,
    private readonly router: Router
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.showHeader = !this.router.url.includes('login');
      }
    });
  }

  ngOnInit(): void {
    this.isLoggedIn = this.storageService.isLoggedIn();
    if (this.isLoggedIn) {
      const user = this.storageService.getUser();
      this.username = user.username;
    }

    this.eventBusSub = this.eventBusService.on('logout', () => {
      this.logout();
    });
  }

  logout(): void {
    this.authenticationService.logout().subscribe({
      complete: () => {
        this.storageService.clean();
        this.router.navigate(['/login']);
        window.location.reload();
      },
      error: () => {
        (err: HttpErrorResponse) => {
          //console.log(err);
        };
      },
    });
  }
}
