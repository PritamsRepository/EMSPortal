import { FpResourceMidMenuComponent } from './components/resource-onboarding/fp-resource-mid-menu/fp-resource-mid-menu.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { HeaderComponent } from './components/layout/header/header.component';
// import { MainComponent } from './components/layout/main/main.component';
// import { SideMenuComponent } from './components/layout/side-menu/side-menu.component';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';
import { TmUploadComponent } from './components/tm-upload/tm-upload.component';
import { EmployeerolemappingComponent } from './components/admin/master/employeerolemapping/employeerolemapping.component';
import { TmApprovalComponent } from './components/tm-approval/tm-approval.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { interceptorProviders } from './interceptorProviders';
import { LoaderComponent } from './components/common/loader/loader.component';
import { PrimengModule } from './primeng.module';
import { FpuploadcontractComponent } from './components/fp-upload/fpuploadcontract/fpuploadcontract.component';
import { FpuploadmenuComponent } from './components/fp-upload/fpuploadmenu.component';
import { FpuploadmilestoneComponent } from './components/fp-upload/fpuploadmilestone/fpuploadmilestone.component';
import { FpuploadmonthlyComponent } from './components/fp-upload/fpuploadmonthly/fpuploadmonthly.component';
import { TmTrackComponent } from './components/tm-track/tm-track.component';
import { FpApprovalmenuComponent } from './components/fp-approval/fp-approvalmenu/fp-approvalmenu.component';
import { FpApprovalmilestoneComponent } from './components/fp-approval/fp-approvalmilestone/fp-approvalmilestone.component';
import { FpApprovalmonthlyComponent } from './components/fp-approval/fp-approvalmonthly/fp-approvalmonthly.component';
import { VendorContractlistComponent } from './components/resource-onboarding/vendor-contractlist/vendor-contractlist.component';
import { HomeComponent } from './components/home/home.component';
import { TmViewComponent } from './components/tm-view/tm-view.component';
import { LayoutModule } from './components/layout/layout.module';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { ErrorComponent } from './components/common/error/error.component';
import { TmSendbackComponent } from './components/tm-sendback/tm-sendback.component';
import { TmContractEditComponent } from './components/tm-sendback/tm-contract-edit/tm-contract-edit.component';
import { TmWorkflowComponent } from './components/tm-view/tm-workflow/tm-workflow.component';
import { FpTrackmenuComponent } from './components/fp-track/fp-trackmenu/fp-trackmenu.component';
import { FpTrackmilestoneComponent } from './components/fp-track/fp-trackmilestone/fp-trackmilestone.component';
import { FpTrackmonthlyComponent } from './components/fp-track/fp-trackmonthly/fp-trackmonthly.component';
import { TmOnboardingTrackComponent } from './components/resource-onboarding/tm-onboarding-track/tm-onboarding-track.component';
import { AmsmasterComponent } from './components/amsmaster/amsmaster.component';
import { TmResourceMidComponent } from './components/resource-onboarding/tm-resource-mid/tm-resource-mid.component';
import { FpOnboardingApprovalMenuitemsComponent } from './components/resource-onboarding/fp-onboarding-approval-menuitems/fp-onboarding-approval-menuitems.component';
import { FpOnboardingMonthlyApprovalComponent } from './components/resource-onboarding/fp-onboarding-monthly-approval/fp-onboarding-monthly-approval.component';
import { FpOnboardingMilestoneApprovalComponent } from './components/resource-onboarding/fp-onboarding-milestone-approval/fp-onboarding-milestone-approval.component';
import { FpMilestoneMIDUpdateComponent } from './components/resource-onboarding/fp-milestone-midupdate/fp-milestone-midupdate.component';
import { FpMonthlyMIDUpdateComponent } from './components/resource-onboarding/fp-monthly-midupdate/fp-monthly-midupdate.component';
import { FpResourceMonthlyTrackComponent } from './components/resource-onboarding/fp-resource-monthly-track/fp-resource-monthly-track.component';
import { FpResourceMilestoneTrackComponent } from './components/resource-onboarding/fp-resource-milestone-track/fp-resource-milestone-track.component';
import { FpOnboardingTrackMenuComponent } from './components/resource-onboarding/fp-onboarding-track-menu/fp-onboarding-track-menu.component';
import { FpViewComponent } from './components/fp-view/fp-view.component';
import { FpWorkflowComponent } from './components/fp-view/fp-workflow/fp-workflow.component';
import { FpSendbackComponent } from './components/fp-sendback/fp-sendback.component';
import { FpContractEditComponent } from './components/fp-sendback/fp-contract-edit/fp-contract-edit.component';
import { ContractDetailComponent } from './components/reports/contract-detail/contract-detail.component';
import { ContractSummaryComponent } from './components/reports/contract-summary/contract-summary.component';
import { OpenPositionComponent } from './components/reports/open-position/open-position.component';
import { EmployeeMasterComponent } from './components/reports/employee-master/employee-master.component';
import { MonthlyDetailsDlgComponent } from './components/resource-onboarding/monthly-details-dlg/monthly-details-dlg.component';
import { MilestoneDetailsDlgComponent } from './components/resource-onboarding/milestone-details-dlg/milestone-details-dlg.component';
import { ContractsDomainTowerleadComponent } from './components/reports/contracts-domain-towerlead/contracts-domain-towerlead.component';
import { PublishedContractDetailsComponent } from './components/reports/published-contract-details/published-contract-details.component';
import { TmBulkUpdateComponent } from './components/tm-bulk-update/tm-bulk-update.component';
import { RenewalDashboardComponent } from './components/reports/renewal-dashboard/renewal-dashboard.component';
const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    //  HeaderComponent,
    // MainComponent,
    // SideMenuComponent,
    LoginComponent,
    LogoutComponent,
    TmBulkUpdateComponent,
    TmUploadComponent,
    EmployeerolemappingComponent,
    TmApprovalComponent,
    LoaderComponent,
    FpuploadmenuComponent,
    FpuploadcontractComponent,
    FpuploadmilestoneComponent,
    FpuploadmonthlyComponent,
    TmTrackComponent,
    FpApprovalmenuComponent,
    FpApprovalmilestoneComponent,
    FpApprovalmonthlyComponent,
    VendorContractlistComponent,
    HomeComponent,
    TmViewComponent,
    ErrorComponent,
    TmSendbackComponent,
    TmContractEditComponent,
    TmWorkflowComponent,
    FpTrackmenuComponent,
    FpTrackmilestoneComponent,
    FpTrackmonthlyComponent,
    TmOnboardingTrackComponent,
    AmsmasterComponent,
    TmResourceMidComponent,
    FpOnboardingApprovalMenuitemsComponent,
    FpOnboardingMonthlyApprovalComponent,
    FpOnboardingMilestoneApprovalComponent,
    FpResourceMidMenuComponent,
    FpMilestoneMIDUpdateComponent,
    FpMonthlyMIDUpdateComponent,
    FpResourceMonthlyTrackComponent,
    FpResourceMilestoneTrackComponent,
    FpOnboardingTrackMenuComponent,
    FpViewComponent,
    FpWorkflowComponent,
    FpSendbackComponent,
    FpContractEditComponent,
    ContractDetailComponent,
    ContractSummaryComponent,
    OpenPositionComponent,
    EmployeeMasterComponent,
    MonthlyDetailsDlgComponent,
    MilestoneDetailsDlgComponent,
    ContractsDomainTowerleadComponent,
    PublishedContractDetailsComponent,
    RenewalDashboardComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes, {
      useHash: true,
      onSameUrlNavigation: 'reload',
      preloadingStrategy: PreloadAllModules,
    }),
    ReactiveFormsModule,
    FormsModule,
    PrimengModule,
    LayoutModule,
  ],
  providers: [
    interceptorProviders,
    { provide: LocationStrategy, useClass: HashLocationStrategy },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
