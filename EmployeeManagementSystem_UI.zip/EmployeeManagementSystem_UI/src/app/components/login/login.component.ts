import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ILogin } from 'src/app/core/interfaces/ilogin';

import { throwError, of, catchError, map, Observable, tap } from 'rxjs';
// import {  StorageService } from 'src/app/core/services/storage.service'
// import {  EncryptDecryptService } from '../helper/encrypt-decrypt.service'
// import {  ToasterService } from '../core/services/toaster/toaster.service'
import { InputTextModule } from 'primeng/inputtext';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';
import { environment } from './../../../environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [MessageService],
})
export class LoginComponent implements OnInit, ILogin {
  loginForm: any = FormGroup;
  userName: any;
  password: any;
  submitted = false;
  error!: string;
  isLoggedIn = false;
  isLoginFailed = false;
  loading: boolean = false;

  roles: string[] = [];

  get f() {
    return this.loginForm.controls;
  }
  /**
   *
   */
  constructor(
    private readonly fb: FormBuilder,
    private readonly router: Router,
    private readonly authenticationService: AuthenticationService,
    private messageService: MessageService,
    private readonly _storageService: StorageService
  ) {
    // if (environment.windowAuth && this.router.url.endsWith('/login')) {
    //   authenticationService.AuthByWindows().subscribe({
    //     next: (data) => {
    //       this._storageService.saveUser(data, data.token);
    //       this.isLoginFailed = false;
    //       this.isLoggedIn = true;
    //       // sessionStorage.setItem('currentUser', JSON.stringify(data));
    //       // sessionStorage.setItem('token', data.token);
    //       // this.isLoggedIn = true;
    //       // this.isLoginFailed = false;
    //       this._storageService.navigateBasedOnRole();
    //       //this.router.navigate(['/main/home']);
    //     },
    //     error: (err) => {
    //       this._storageService.clean();
    //       this.loading = false;
    //       this.isLoggedIn = false;
    //       this.isLoginFailed = true;
    //       this.error = 'SSO Failed!, Please Enter UserName and Password.';
    //       // this.error = err;
    //       // this.toaster.showToasterMessage('error', 'Authentication Error', this.error, 3000)
    //       this.messageService.add({
    //         severity: 'error',
    //         summary: 'Login Failed!',
    //         detail: 'SSO Failed!, Please Enter UserName and Password.',
    //       });
    //       setTimeout(() => {
    //         this.messageService.clear();
    //       }, 3000);
    //     },
    //   });
    // }
  }

  formControl = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    return this.formControl.hasError('required')
      ? '*Required'
      : this.formControl.hasError('email')
      ? '*Invalid Email'
      : '';
  }

  ngOnInit(): void {
    //console.log('login component call');
    this._storageService.clean();
    this._storageService.clean();
    // window.location.reload();
    this.router.navigate(['/login']);
    // window.location.reload();
    this.loginForm = this.fb.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });

    //window.location.reload();
  }

  onLoginSubmit() {
    this.submitted = true;
    if (this.loginForm.valid && this.submitted) {
      this.loading = true;
      // this.userName = ((document.getElementById('txtUserName') as HTMLInputElement).value)
      // this.password = ((document.getElementById('txtPassword') as HTMLInputElement).value)
      // //console.log(this.security.encryptUsingAES256(this.username))
      // //console.log(this.security.encryptUsingAES256(this.password))

      const login = {} as ILogin;
      // login.username = this.username;
      // login.password = this.password;
      // login.username = this.security.encryptUsingAES256(this.username)
      // login.password = this.security.encryptUsingAES256(this.password)

      // login.username = this.username,
      // login.password = this.password,
      this.authenticationService.login(this.loginForm.value).subscribe({
        next: (data) => {
          this._storageService.saveUser(data, data.token);
          this.isLoginFailed = false;
          this.isLoggedIn = true;

          // sessionStorage.setItem('currentUser', JSON.stringify(data));
          // sessionStorage.setItem('token', data.token);
          // this.isLoggedIn = true;
          // this.isLoginFailed = false;
          // this._storageService.navigateBasedOnRole();
          this.router.navigate(['/main/home']);
        },
        error: (err) => {
          this._storageService.clean();
          this.loading = false;
          this.isLoggedIn = false;
          this.isLoginFailed = true;
          this.error = 'Invalid UserId and Password. Login Failed ';
          //console.log('err : ', err);
          // this.error = err;
          // this.toaster.showToasterMessage('error', 'Authentication Error', this.error, 3000)
          this.messageService.add({
            severity: 'error',
            summary: 'Unauthorized Error. Login Failed!. ',
            detail: err.error,
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });

      this.submitEM.emit(this.loginForm.value);
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Invalid Form!',
        detail: 'Please check your form.',
      });
      setTimeout(() => {
        this.messageService.clear();
      }, 3000);
    }
  }

  @Output() submitEM = new EventEmitter();
}
