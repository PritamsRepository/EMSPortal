import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { FPApprovalService } from 'src/app/core/services/contract-approval/fp-approval.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ifpapproval } from 'src/app/core/interfaces/ifpapproval';
import { ifpmapproval } from 'src/app/core/interfaces/ifpmlapproval';

import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { FpWorkflowComponent } from '../../fp-view/fp-workflow/fp-workflow.component';

@Component({
  selector: 'app-fp-trackmilestone',
  templateUrl: './fp-trackmilestone.component.html',
  styleUrls: ['./fp-trackmilestone.component.css'],
  providers: [MessageService, DialogService],
})
export class FpTrackmilestoneComponent implements OnInit {
  constructor(
    private fpapprovalService: FPApprovalService,
    private MessageService: MessageService,
    private DialogService: DialogService
  ) {}

  fpmilestonemasters!: ifpapproval[];
  fpmilestonedetails!: ifpmapproval[];
  selectedFilter?: any = { name: 'Approved List', code: 'AL' };
  selectedActiveFilter?: any = { name: 'Active Records', code: 'Active' };
  cols!: any[];
  ddFilter: any[] = [];
  ddActiveFilter: any[] = [];
  pageTitle = 'Track Fixed Price Milestone Contracts';
  ref: DynamicDialogRef | undefined;
  ngOnInit() {
    this.getFPMilestoneMaster(this.selectedFilter, this.selectedActiveFilter);
    this.ddFilter = [
      { name: 'All', code: 'ALL' },
      { name: 'Approved List', code: 'AL' },
      { name: 'Sentback List', code: 'SL' },
    ];

    this.ddActiveFilter = [
      { name: 'Both', code: 'Both' },
      { name: 'Active Records', code: 'Active' },
      { name: 'InActive Records', code: 'InActive' },
    ];

    this.cols = [
      { field: 'status', header: 'Status' },
      { field: 'pendingwithwhom', header: 'PendingWithWhom' },
      { field: 'etwid', header: 'ETWID' },
     // { field: 'cmid', header: 'CMID' },
     
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'positionLocation', header: 'Managing Team' },
      { field: 'remappedMID', header: 'Existing MID' },
      { field: 'oldSowNumber', header: 'Old SOW Number' },

      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },

      { field: 'sowStartDate', header: 'SOW Start Date', type: 'date' },
      { field: 'sowEndDate', header: 'SOW End Date', type: 'date' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'domainSkillName', header: 'Domain Name' },
      {
        field: 'domainSkillStartDate',
        header: 'Domain Skill Start Date',
        type: 'date',
      },
      {
        field: 'domainSkillEndDate',
        header: 'Domain Skill End Date',
        type: 'date',
      },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date', type: 'date' },
      { field: 'poEndDate', header: 'PO End Date', type: 'date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'tower', header: 'Tower' },
      { field: 'costCenter', header: 'Cost Center' },
      { field: 'vertical', header: 'Vertical' },

      { field: 'obs', header: 'OBS' },
      { field: 'wbsDetail', header: 'SAP Code' },
      { field: 'projectOrRun', header: 'ProjectOrRun' },

      { field: 'contractType', header: 'Contract Type' },
      { field: 'billingType', header: 'Billing Type' },
      { field: 'isActive', header: 'Is Active' },
      { field: 'updatedBy', header: 'Updated By' },

      {
        field: 'updatedOn',
        header: 'Updated On',
        type: 'date',
      },
    ];
  }
  getFPMilestoneMaster(selectedFilter: any, selectedActiveFilter: any) {
    this.fpapprovalService
      .getFPMilestoneContractTrackdata(
        selectedFilter.code,
        selectedActiveFilter.code
      )
      .subscribe((result) => {
        this.fpmilestonemasters = result;
        //console.log(this.fpmilestonemasters);
      });
  }
  expandClick(fpmilestonemaster: ifpapproval, isexpanded: boolean) {
    if (isexpanded == false && fpmilestonemaster.milestones == null) {
      this.fpapprovalService
        .getmilestoneData(fpmilestonemaster.sowNumber)
        .subscribe((result) => {
          this.fpmilestonedetails = result;
          this.fpmilestonemasters.map((x) =>
            x.sowNumber === fpmilestonemaster.sowNumber
              ? (x.milestones = this.fpmilestonedetails)
              : x
          );
        });
    }
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  // }

  getSeverity(data: ifpapproval) {
    switch (data.status) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }
  mExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    //console.log(this.fpmilestonemasters);
    const filteredContractList = this.fpmilestonemasters.map((contract) => {
      // Create a new object to hold the properties in the desired order
      //console.log(contract);
      return {
        etwid: contract.etwid,

        vendorName: contract.vendorName,
        sowNumber: contract.sowNumber,
        sowName: contract.sowName,
        // sowType :contract.sowType,
        sowStartDate: contract.sowStartDate
          ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
          : '',
        sowEndDate: contract.sowEndDate
          ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
          : '',
        poNumber: contract.poNumber,
        poStartDate: contract.poStartDate
          ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
          : '',
        poEndDate: contract.poEndDate
          ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
          : '',
        contractType: contract.contractType,
        ppmProjectID: contract.ppmProjectID,
        ppmProjectName: contract.ppmProjectName,
        tower: contract.tower,
        vertical: contract.vertical,
        wbsDetail: contract.wbsDetail,
        domainLeadEmail: contract.domainLeadEmail,
        domainSkillName: contract.domainSkillName,
        // currency:contract.currency,
        positionLocation: contract.positionLocation,
        oldSowNumber: contract.oldSowNumber,
        //sapCode :contract.sapCode,
        // obs :contract.obs,
        // noticePeriod:contract.noticePeriod,
        status: contract.status,
        Pendingwithwhom: contract.pendingwithwhom,

        skillSet: contract.skillSet,
        domainSkillStartDate: contract.domainSkillStartDate
          ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
          : '',
        domainSkillEndDate: contract.domainSkillEndDate
          ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
          : '',
        BillingType: contract.billingType,
        RemappedMID: contract.remappedMID,
      };
    });

    // Convert the filteredContractList to a worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'FP Milestone Contract Track List.xlsx');
  }
  viewTmWorkFlow(data: ifpapproval) {
    //console.log('Data : ', data);
    var fpDatatofetch = {
      fbcid: data.fbcIntID,
      billingTypeName: data.billingType,
      contractTypeName: data.contractType,
      positionCode: data.etwid,
    };
    this.ref = this.DialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      // header: 'Work Flow History-'+data.etwid,
      data: fpDatatofetch,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
}
