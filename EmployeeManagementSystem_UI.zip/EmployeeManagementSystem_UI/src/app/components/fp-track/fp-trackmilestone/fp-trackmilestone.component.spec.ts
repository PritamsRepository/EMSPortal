import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpTrackmilestoneComponent } from './fp-trackmilestone.component';

describe('FpTrackmilestoneComponent', () => {
  let component: FpTrackmilestoneComponent;
  let fixture: ComponentFixture<FpTrackmilestoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpTrackmilestoneComponent]
    });
    fixture = TestBed.createComponent(FpTrackmilestoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
