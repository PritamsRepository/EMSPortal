import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpTrackmenuComponent } from './fp-trackmenu.component';

describe('FpTrackmenuComponent', () => {
  let component: FpTrackmenuComponent;
  let fixture: ComponentFixture<FpTrackmenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpTrackmenuComponent]
    });
    fixture = TestBed.createComponent(FpTrackmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
