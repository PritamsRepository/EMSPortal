import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Menu } from 'primeng/menu';

@Component({
  selector: 'app-fp-trackmenu',
  templateUrl: './fp-trackmenu.component.html',
  styleUrls: ['./fp-trackmenu.component.css'],
})
export class FpTrackmenuComponent {
  activeItem!: MenuItem;

  items!: MenuItem[];
  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {
    this.createtab();
  }
  ngOnInit() {
    //console.log('test1');
    //console.log(this.items);
    //console.log(this.activeItem);
  }
  createtab() {
    this.items = [
      {
        label: 'Track FP Milestones Contracts',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['../fptrackmilestone'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Track FP Monthly Contracts',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['../fptrackmonthly'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
  }

  onTabChange(event: MenuItem) {
    this.activeItem = event;
  }
}
