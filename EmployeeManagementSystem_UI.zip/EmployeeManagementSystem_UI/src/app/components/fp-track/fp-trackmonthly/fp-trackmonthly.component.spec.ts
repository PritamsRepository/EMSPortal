import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpTrackmonthlyComponent } from './fp-trackmonthly.component';

describe('FpTrackmonthlyComponent', () => {
  let component: FpTrackmonthlyComponent;
  let fixture: ComponentFixture<FpTrackmonthlyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpTrackmonthlyComponent]
    });
    fixture = TestBed.createComponent(FpTrackmonthlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
