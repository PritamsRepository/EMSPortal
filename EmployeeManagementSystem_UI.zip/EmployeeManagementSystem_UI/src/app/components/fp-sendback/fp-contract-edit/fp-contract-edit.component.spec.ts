import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpContractEditComponent } from './fp-contract-edit.component';

describe('FpContractEditComponent', () => {
  let component: FpContractEditComponent;
  let fixture: ComponentFixture<FpContractEditComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpContractEditComponent]
    });
    fixture = TestBed.createComponent(FpContractEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
