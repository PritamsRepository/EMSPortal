import {
  AfterContentChecked,
  AfterViewChecked,
  AfterViewInit,
  Component,
  OnInit,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/dynamicdialog';
import {
  iVendorMaster,
  iSowTypeMaster,
  iContractTypeMaster,
  iBillingTypeMaster,
  iVerticalMaster,
  iTowerNameMaster,
  iProjectOrRunMaster,
  iObsMaster,
  iSkillSetMaster,
  iLocationMaster,
} from 'src/app/core/interfaces/imasterDetails';
import {
  ifpDetails,
  ifpEditedDetails,
} from 'src/app/core/interfaces/ifpDetails';
import { ifpUpload } from 'src/app/core/interfaces/ifpupload';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { Router } from '@angular/router';
import { ifpmoUpload } from 'src/app/core/interfaces/ifpmoupload';
import { ifpmlUpload } from 'src/app/core/interfaces/ifpmlupload';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';

@Component({
  selector: 'app-fp-contract-edit',
  templateUrl: './fp-contract-edit.component.html',
  styleUrls: ['./fp-contract-edit.component.css'],
  providers: [MessageService],
})
export class FpContractEditComponent implements OnInit, AfterViewInit {
  [x: string]: any;
  fpDetailsform: FormGroup<any>;

  // ############################
  fpmoupload!: ifpmoUpload[];

  // ############################
  constructor(
    private fb: FormBuilder,
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public fpUpload: FpUploadService,
    private router: Router,
    public messageService: MessageService,
    private readonly ResourceOnboardingService: ResourceOnboardingService
  ) {
    // Build your form controls using FormBuilder
    this.fpDetailsform = this.fb.group({
      // etwid: ['', [Validators.required]],
      etwid: ['', [Validators.required]],
      amortizationEndMonth: [''],
      amortizationStartMonth: [''],
      billingTypeId: ['', [Validators.required]], // Use this to bind to your dropdown value
      // contractTypeId: ['', [Validators.required]], // Use this to bind to your dropdown value
      costCenter: ['', [Validators.required]],
      domainLeadEmail: ['', [Validators.required]],
      domainSkillEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      domainName: ['', [Validators.required]],
      domainSkillStartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      obs: ['', [Validators.required]], // Use this to bind to your dropdown value
      oldSOWNumber: [''],
      poEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      poNumber: ['', [Validators.required]],
      positionLocationId: ['', [Validators.required]], // Use this to bind to your dropdown value
      poStartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      ppmProjectID: ['', [Validators.required]],
      ppmProjectName: ['', [Validators.required]],
      projectOrRunId: ['', [Validators.required]], // Use this to bind to your dropdown value
      remappedMID: [''],
      skillSetId: ['', [Validators.required]], // Use this to bind to your dropdown value
      sowEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      sowName: ['', [Validators.required]],
      sowNumber: ['', [Validators.required]],
      sowstartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      towerNameId: ['', [Validators.required]], // Use this to bind to your dropdown value
      vendorId: ['', [Validators.required]], // Use this to bind to your dropdown value
      verticalId: ['', [Validators.required]], // Use this to bind to your dropdown value
      wbsDetail: [''],
      pendingWithWhom: ['', [Validators.required]],
      Remarks: ['', [Validators.required]],
    });
  }

  fpDetails!: ifpDetails;

  vendorDetails!: iVendorMaster[];
  sowTypeDetails!: iSowTypeMaster[];
  contractTypeDetails!: iContractTypeMaster[];
  billingTypeDetails!: iBillingTypeMaster[];
  verticalDetails!: iVerticalMaster[];
  towerNameDetails!: iTowerNameMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  obsDetails!: iObsMaster[];
  skillSetDetails!: iSkillSetMaster[];
  locationDetails!: iLocationMaster[];
  validationRemarks!: string;
  ngOnInit(): void {
    //console.log('data for dialog : ', this.config.data);
    // Retrieve details from the config object {value:'Y'}
    this.fpDetails = this.config.data.fpdetails;

    //console.log(' editing this records - ngoninit '+ this.config.data);
    this.vendorDetails = this.config.data.vendor;
    this.sowTypeDetails = this.config.data.sowTypes;
    this.contractTypeDetails = this.config.data.contractTypes;
    this.billingTypeDetails = this.config.data.billingTypes;
    this.verticalDetails = this.config.data.verticals;
    this.towerNameDetails = this.config.data.towerNames;
    this.projectOrRunDetails = this.config.data.projectOrRuns;
    this.obsDetails = this.config.data.obs;
    this.skillSetDetails = this.config.data.skillSets;
    this.locationDetails = this.config.data.locations;
  }

  ngAfterViewInit() {
    // this.ResourceOnboardingService.GetMonthlyDetailsBySowNum(this.fpDetails.sowNumber).subscribe((result) => {
    //   // this.MonthlyDetails = result;
    // });

    //console.log('ngAfterViewInit '+this.fpDetails);
    // Patch the form with data from this.tmDetails
    this.fpDetailsform.patchValue({
      etwid: this.fpDetails.etwid,
      // positionCode: this.fpDetails.positionCode,

      vendorId: this.vendorDetails.find(
        (item) => item.vendorName === this.fpDetails.vendorName
      )?.vendorId,

      positionLocationId: this.locationDetails.find(
        (item) => item.locationName === this.fpDetails.locationName
      )?.locationId,

      oldSOWNumber: this.fpDetails.oldSowNumber,
      sowNumber: this.fpDetails.sowNumber,
      sowName: this.fpDetails.sowName,

      // sowtypeId: this.sowTypeDetails.find(
      //   (item) => item.sowTypeName === this.fpDetails.sowTypeName
      // )?.sowTypeId,

      sowstartDate: new Date(this.fpDetails.sowStartDate), // Assuming sowStartDate is a string
      sowEndDate: new Date(this.fpDetails.sowEndDate), // Assuming sowEndDate is a string
      domainName: this.fpDetails.domainSkillName,

      skillSetId: this.skillSetDetails.find(
        (item) => item.skillSet === this.fpDetails.skillSet
      )?.skillId,

      domainSkillStartDate: new Date(this.fpDetails.domainSkillStartDate), // Assuming domainSkillStartDate is a string
      domainSkillEndDate: new Date(this.fpDetails.domainSkillEndDate), // Assuming domainSkillEndDate is a string
      poNumber: this.fpDetails.poNumber,
      poStartDate: new Date(this.fpDetails.poStartDate), // Assuming poStartDate is a string
      poEndDate: new Date(this.fpDetails.poEndDate), // Assuming poEndDate is a string
      ppmProjectID: this.fpDetails.ppmProjectID,
      ppmProjectName: this.fpDetails.ppmProjectName,
      wbsDetail: this.fpDetails.wbsDetail,

      verticalId: this.verticalDetails.find(
        (item) => item.verticalName === this.fpDetails.verticalName
      )?.verticalId,

      towerNameId: this.towerNameDetails.find(
        (item) => item.towerName === this.fpDetails.towerName
      )?.towerNameId,

      domainLeadEmail: this.fpDetails.domainLeadEmail,
      costCenter: this.fpDetails.costCenter,

      obs: this.obsDetails.find(
        (item) => item.obsmasterName === this.fpDetails.obsMasterName
      )?.obsmasterId,

      projectOrRunId: this.projectOrRunDetails.find(
        (item) => item.projectOrRun === this.fpDetails.projectOrRun
      )?.projectOrRunId,

      // contractTypeId: this.contractTypeDetails.find(
      //   (item) => item.contractTypeName === this.fpDetails.contractType
      // )?.contractTypeId,

      billingTypeId: this.billingTypeDetails.find(
        (item) => item.billingTypeName === this.fpDetails.billingTypeName
      )?.billingTypeId,

      currency: this.fpDetails.currency,
      // billingRateYear1: this.tmDetails.billingRateYear1,
      // billingRateYear2: this.tmDetails.billingRateYear2,
      // billingRateYear3: this.tmDetails.billingRateYear3,
      // billingRateYear4: this.tmDetails.billingRateYear4,
      // billingRateYear5: this.tmDetails.billingRateYear5,
      remappedMID: this.fpDetails.remappedMID,
      // sapCode: this.fpDetails.sapCode,
      // noticePeriod: this.fpDetails.noticePeriod,
      pendingWithWhom: this.fpDetails.pendingWithWhom,

      amortizationEndMonth:
        this.fpDetails.amortizationEndMonth !== null
          ? new Date(this.fpDetails.amortizationEndMonth)
          : null,
      amortizationStartMonth:
        this.fpDetails.amortizationStartMonth !== null
          ? new Date(this.fpDetails.amortizationStartMonth)
          : null,
    });
    //console.log('this.fpDetailsform.value ' + this.fpDetailsform);
  }

  onFpDetailsSubmit() {
    // console.log('form values');
    // console.log(this.fpDetailsform.valid);
    // console.log(this.fpDetailsform.value);
    // console.log('this.fpDetails');
    // console.log(this.fpDetails);
    const Data = this.fpDetailsform.value;

    const fpData = {} as ifpEditedDetails;

    fpData.Fbcid = this.fpDetails.fbcid;

    fpData.etwid = Data.etwid;
    fpData.amortizationEndMonth = Data.amortizationEndMonth;
    fpData.amortizationStartMonth = Data.amortizationStartMonth;

    fpData.billingTypeId = Data.billingTypeId;

    // fpData.ContractTypeId = this.fpDetails.find(
    //   (item) => item.contractType === this.fpDetails.contractType
    // )?.contractTypeId,

    // fpData.ContractTypeId = 0//this.fpDetails.contractType; //Data.contractTypeId;
    fpData.costCenter = Data.costCenter;
    fpData.domainLeadEmail = Data.domainLeadEmail;
    fpData.domainSkillEndDate = Data.domainSkillEndDate;
    fpData.domainSkillName = Data.domainName;
    fpData.domainSkillStartDate = Data.domainSkillStartDate;

    fpData.ObsmasterId = Data.obs;

    fpData.oldSowNumber = Data.oldSOWNumber;
    fpData.poEndDate = Data.poEndDate;
    fpData.poNumber = Data.poNumber;

    fpData.PositionLocationId = Data.positionLocationId;
    // fpData.ContractTypeId = 0;
    fpData.poStartDate = Data.poStartDate;
    fpData.ppmProjectID = Data.ppmProjectID;
    fpData.ppmProjectName = Data.ppmProjectName;
    fpData.projectOrRunId = Data.projectOrRunId;
    fpData.remappedMID = Data.remappedMID;
    fpData.SkillSet = Data.skillSetId.toString();

    fpData.SowendDate = Data.sowEndDate;
    fpData.sowName = Data.sowName;
    fpData.sowNumber = Data.sowNumber;
    fpData.SowstartDate = Data.sowstartDate;
    fpData.TowerId = Data.towerNameId;
    fpData.vendorId = Data.vendorId;
    fpData.verticalId = Data.verticalId;
    fpData.wbsDetail = Data.wbsDetail;
    fpData.currency = Data.currency;
    fpData.Status = this.fpDetails.status;
    fpData.pendingWithWhom = Data.pendingWithWhom;

    fpData.Wforder = this.fpDetails.wfOrder;
    fpData.cmid = this.fpDetails.cmid;

    fpData.isActive = this.fpDetails.isActive;
    fpData.updatedBy = '';
    fpData.updateDate = new Date();
    fpData.Remarks = Data.Remarks;

    //console.log('fpData from form : ', Data);
    //console.log('fpData after submit : ', fpData);

    if (this.fpDetailsform.valid) {
      this.fpUpload.updateFPContractDetails(fpData).subscribe({
        next: (response) => {
          if (response != '' && response != 'Contract saved successfully') {
            this.validationRemarks = response;
          } else {
            this.ref.close(response);
            //  this.router.navigate(['/main/fpSendbackDetails']);
            //  window.location.reload(); // Add this line to reload the page
          }
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to save FP Details.',
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });
    } else {
      const invalid = [];
      const controls = this.fpDetailsform.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
      this.validationRemarks = invalid.toString() + ' should have valid value.';
    }
  }
}
