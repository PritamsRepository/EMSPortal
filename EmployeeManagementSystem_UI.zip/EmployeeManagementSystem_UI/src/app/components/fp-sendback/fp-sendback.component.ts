import {
  AfterContentInit,
  AfterViewInit,
  Component,
  OnInit,
} from '@angular/core';
import { ifpUpload } from 'src/app/core/interfaces/ifpupload';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FpContractEditComponent } from './fp-contract-edit/fp-contract-edit.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import {
  iBillingTypeMaster,
  iContractTypeMaster,
  iLocationMaster,
  iObsMaster,
  iProjectOrRunMaster,
  iSkillSetMaster,
  iSowTypeMaster,
  iTowerNameMaster,
  iVendorMaster,
  iVerticalMaster,
} from 'src/app/core/interfaces/imasterDetails';
import { SharedService } from 'src/app/core/services/shared.service';
import { ifpEditedDetails } from 'src/app/core/interfaces/ifpDetails';
import { FpWorkflowComponent } from '../fp-view/fp-workflow/fp-workflow.component';
import { itmUpload } from 'src/app/core/interfaces/itmupload';

@Component({
  selector: 'app-fp-sendback',
  templateUrl: './fp-sendback.component.html',
  styleUrls: ['./fp-sendback.component.css'],
  providers: [MessageService, DialogService, ConfirmationService],
})
export class FpSendbackComponent implements AfterContentInit {
  gridTitle: string = 'Fixed Price Contract Sendback List';
  ref: DynamicDialogRef | undefined;
  tableCols: any[];
  fpSendbackLists!: ifpUpload[];
  fpSendback!: ifpUpload;

  vendorDetails!: iVendorMaster[];
  sowTypeDetails!: iSowTypeMaster[];
  contractTypeDetails!: iContractTypeMaster[];
  billingTypeDetails!: iBillingTypeMaster[];
  verticalDetails!: iVerticalMaster[];
  towerNameDetails!: iTowerNameMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  obsDetails!: iObsMaster[];
  skillSetDetails!: iSkillSetMaster[];
  locationDetails!: iLocationMaster[];
  constructor(
    private fpUploadService: FpUploadService,
    private messageService: MessageService,
    public dialogService: DialogService,
    public sharedService: SharedService,
    private confirmationService: ConfirmationService
  ) {}

  sortField = 'status';
  sortOrder = -1;

  ngAfterContentInit() {
    this.getFpContractSendbackDetails();
    this.tableCols = [
      // { field: 'fbcIntID', header: 'fbcIntID' },
      { field: 'status', header: 'Status' , isFrozenColumn: true},
      { field: 'etwid', header: 'ETW ID', isFrozenColumn: true },
      { field: 'vendorName', header: 'Vendor Name' , isFrozenColumn: true},
      { field: 'locationName', header: 'Managing Team' , isFrozenColumn: true},
      { field: 'billingTypeName', header: 'Billing Type' , isFrozenColumn: true},
      { field: 'oldSowNumber', header: 'Old Sow Number' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      {
        field: 'sowStartDate',
        header: 'SOW Start Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      {
        field: 'sowEndDate',
        header: 'SOW End Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      {
        field: 'amortizationStartMonth',
        header: 'Amortization Starting From',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      {
        field: 'amortizationEndMonth',
        header: 'Amortization Ending On',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      { field: 'poNumber', header: 'PO Number' },
      {
        field: 'poStartDate',
        header: 'PO Start Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      {
        field: 'poEndDate',
        header: 'PO End Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'wbsDetail', header: 'SAP Code' },
      { field: 'verticalName', header: 'Vertical' },
      { field: 'towerName', header: 'Tower' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'costCenter', header: 'Cost Center' },
      { field: 'obsMasterName', header: 'OBS' },
      { field: 'domainSkillName', header: 'Domain Skill Name' },
      { field: 'skillSet', header: 'Skill Set' },
      {
        field: 'domainSkillStartDate',
        header: 'DomainSkill Start Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      {
        field: 'domainSkillEndDate',
        header: 'DomainSkill End Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      { field: 'projectOrRun', header: 'Project Or Run' },
      // { field: 'contractTypeName', header: 'Contract Type' },

      { field: 'remappedMID', header: 'Existing MID' },
      // { field: 'validationRemarks', header: 'Validation Remarks' },
      // { field: 'cmid', header: 'cmid' },
      { field: 'pendingWithWhom', header: 'Pending With Whom' },
      { field: 'isActive', header: 'Is Active', type: 'bool' },
      {
        field: 'updateDate',
        header: 'Uploaded Date',
        format: 'dd-MMM-yyyy',
        type: 'date',
      },
      { field: 'updatedBy', header: 'Uploaded By' },
      // { field: 'wfOrder', header: 'wfOrder' },
      // { field: 'FBCID', header: 'FBCID' },
    ];
  }

  viewFpWorkFlow(data: ifpUpload) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
  getFpContractSendbackDetails() {
    this.fpUploadService.getFPContractSendbackDetails().subscribe({
      next: (result: ifpUpload[]) => {
        this.fpSendbackLists = result;
        //console.log('Details : ', this.fpSendbackLists);
        if (this.fpSendbackLists.length > 0) {
          this.messageService.add({
            severity: 'info',
            summary: 'Fetched',
            detail: 'FP contract sendback details fetched successfully.',
          });
        } else {
          this.messageService.add({
            severity: 'warn',
            summary: 'No Records',
            detail: 'No FP contract sendback details found.',
          });
        }
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch FP contract sendback details.',
        });
      },
    });
  }

  editFpSendBackDetails(data: ifpUpload) {
    this.sharedService.GetAllMasterDetails().subscribe({
      next: (result) => {
        //console.log('Master Details : ', result);
        this.vendorDetails = result.vendorMastersDetails.map((item: any) => {
          const { vendorId, vendorName } = item;
          return { vendorId, vendorName };
        });

        this.sowTypeDetails = result.sowTypeMastersDetails.map((item: any) => {
          const { sowTypeId, sowTypeName } = item;
          return { sowTypeId, sowTypeName };
        });
        this.contractTypeDetails = result.contractTypeMastersDetails.map(
          (item: any) => {
            const { contractTypeId, contractTypeName } = item;
            return { contractTypeId, contractTypeName };
          }
        );
        this.billingTypeDetails = result.billingTypeMastersDetails.map(
          (item: any) => {
            const { billingTypeId, billingTypeName } = item;
            return { billingTypeId, billingTypeName };
          }
        );
        this.verticalDetails = result.verticalMastersDetails.map(
          (item: any) => {
            const { verticalId, verticalName } = item;
            return { verticalId, verticalName };
          }
        );
        //console.log(' vertical ');
        //console.log(this.verticalDetails);
        this.towerNameDetails = result.towerMastersDetails.map((item: any) => {
          const { towerNameId, towerName } = item;
          return { towerNameId, towerName };
        });
        this.projectOrRunDetails = result.projOrRunMastersDetails
        .filter((item: any) => item.isActive) // Filter only active records
        .map(
          (item: any) => {
            const { projectOrRunId, projectOrRun } = item;
            return { projectOrRunId, projectOrRun };
          }
        );
        this.obsDetails = result.obsMastersDetails.map((item: any) => {
          const { obsmasterId, obsmasterName } = item;
          return { obsmasterId, obsmasterName };
        });
        this.skillSetDetails = result.skillSetMastersDetails.map(
          (item: any) => {
            const { skillId, skillSet } = item;
            return { skillId, skillSet };
          }
        );
        this.locationDetails = result.locationMastersDetails.map(
          (item: any) => {
            const { locationId, locationName } = item;
            return { locationId, locationName };
          }
        );
        //console.log(' when i clicked edit : '+ data)

        this.ref = this.dialogService.open(FpContractEditComponent, {
          header: 'FP Sendback Details',
          data: {
            fpdetails: data,
            vendor: this.vendorDetails,
            sowTypes: this.sowTypeDetails,
            contractTypes: this.contractTypeDetails,
            billingTypes: this.billingTypeDetails,
            verticals: this.verticalDetails,
            towerNames: this.towerNameDetails,
            projectOrRuns: this.projectOrRunDetails,
            obs: this.obsDetails,
            skillSets: this.skillSetDetails,
            locations: this.locationDetails,
          },
          width: '80%',
          contentStyle: { overflow: 'auto' },
          baseZIndex: 2204,
          maximizable: true,
        });

        this.ref.onClose.subscribe((result: string) => {
          if (result) {
            this.messageService.add({
              severity: 'success',
              summary: 'Saved!',
              detail: result,
            });
            this.getFpContractSendbackDetails();
          }
        });

        // this.ref.onDestroy.subscribe((blah: any) => {
        //   //console.log('blah : ', blah);
        //   this.getTmContractSendbackDetails();
        //   this.messageService.add({
        //     severity: 'success',
        //     summary: 'Saved!',
        //   });
        // });
      },
      complete() {},
      error: (error) => {
        console.error('Error fetching master details:', error);
        // Handle error as needed
      },
    });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }

  removeTMContractSendBackDetails(selectedDetails: any) {
    var idArray: number;
    var remarks: string;
    var Btype: string;

    try {
      idArray = selectedDetails.map((item: any) => item.fbcid);
      remarks = selectedDetails.map((item: any) => item.delRemarks);
      Btype = selectedDetails.map((item: any) => item.billingTypeName);
    } catch {
      idArray = selectedDetails.fbcid;
      remarks = selectedDetails.delRemarks;
      Btype = selectedDetails.billingTypeName;
    }

    if (remarks != null && remarks != '' && typeof remarks != 'undefined') {
      this.fpUploadService
        .removeTFPContractSendBackDetails(idArray, remarks, Btype)
        .subscribe({
          next: (res) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Deleted',
              detail: 'FP contract details deleted successfully.',
            });
          },
          complete: () => {
            this.getFpContractSendbackDetails();
          },
          error: (err) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: 'Failed to delete FP contract details.',
            });
          },
        });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Required !',
        detail: 'Please enter delete remarks.',
      });
    }
  }

  confirm(event: Event, data: ifpUpload[]) {
    // console.log(data.length);
    // console.log(data);

    if (data) {
      this.confirmationService.confirm({
        target: event.target as EventTarget,
        message: 'Are you sure that you want to proceed?',
        icon: 'fa-solid fa-exclamation-triangle',
        accept: () => {
          this.removeTMContractSendBackDetails(data);
        },
        reject: () => {
          // this.messageService.add({
          //   severity: 'error',
          //   summary: 'Canceled!',
          //   detail: 'No Record Deleted',
          // });
        },
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'No Invalid Records Found!',
        detail: 'There are no invalid records to delete.',
      });
    }
  }
}
