import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpSendbackComponent } from './fp-sendback.component';

describe('FpSendbackComponent', () => {
  let component: FpSendbackComponent;
  let fixture: ComponentFixture<FpSendbackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpSendbackComponent]
    });
    fixture = TestBed.createComponent(FpSendbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
