import {
  AfterContentInit,
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  booleanAttribute,
} from '@angular/core';
import { MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ifpUpload } from 'src/app/core/interfaces/ifpupload';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { FpWorkflowComponent } from './fp-workflow/fp-workflow.component';
import { FpApprovalmenuComponent } from '../fp-approval/fp-approvalmenu/fp-approvalmenu.component';
import { FpApprovalmilestoneComponent } from '../fp-approval/fp-approvalmilestone/fp-approvalmilestone.component';
import { FpApprovalmonthlyComponent } from '../fp-approval/fp-approvalmonthly/fp-approvalmonthly.component';
import { MilestoneDetails } from 'src/app/core/interfaces/milestone-details';
import { MonthlyDetails } from 'src/app/core/interfaces/monthly-details';
import { MonthlyDetailsDlgComponent } from '../resource-onboarding/monthly-details-dlg/monthly-details-dlg.component';
@Component({
  selector: 'app-fp-view',
  templateUrl: './fp-view.component.html',
  styleUrls: ['./fp-view.component.css'],
  providers: [MessageService, DialogService],
})
export class FpViewComponent implements AfterContentInit {
 
  constructor(
    private fpUploadService: FpUploadService,
    private messageService: MessageService,
    public dialogService: DialogService
  ) {}
  MilestoneDialog: boolean = false;
  MilestoneDetails!: MilestoneDetails[];
  MonthlyDetails!: MonthlyDetails[];
  gridTitle: string = 'Track Fixed Price Contract List';
  cols!: any[];
  fpDetails!: ifpUpload[];
  ref!: DynamicDialogRef;
  sortField = 'status';
  sortOrder = -1;
  dialogHeader: string = '';
  ddFilter: any[] = [];
  ddActiveFilter: any[] = [];
  FromDate!: Date;
  ToDate!: Date;
 
  // selectedFilter?: any = { name: '-- Select Filter --', code: 'select' };
  selectedFilter?: any = { name: 'ALL', code: 'ALL' };
  
  selectedActiveFilter?: any = { name: 'Active Records', code: 'Active' };

  ngAfterContentInit() {
    this.ddFilter = [
      { name: '-- Select Filter --', code: 'select' },
      { name: 'Monthly', code: 'Monthly' },
      { name: 'Milestone', code: 'Milestone' },
      { name: 'ALL', code: 'ALL' },
    ];
    this.ddActiveFilter = [
      { name: 'Both', code: 'Both' },
      { name: 'Active Records', code: 'Active' },
      { name: 'InActive Records', code: 'InActive' },
    ];
    const today = new Date();
    // this.FromDate = new Date(today.setDate(1));
    this.FromDate = new Date(today.getFullYear() - 4, today.getMonth(), today.getDate());


    this.ToDate = new Date();
    const formattedFromDate = this.FromDate.toISOString().split('T')[0];
    const formattedToDate = new Date().toISOString().split('T')[0];
    this.getFpContractMainDetails(formattedFromDate, formattedToDate);
    this.cols = [
      // { field: 'fbcIntID', header: 'fbcIntID' },
      { field: 'status', header: 'Status', isFrozenColumn: true},
      { field: 'etwid', header: 'ETW ID', isFrozenColumn: true},
      { field: 'pendingWithWhom', header: 'Pending With Whom', isFrozenColumn: true},
      { field: 'vendorName', header: 'Vendor Name' , isFrozenColumn: true},
      { field: 'remappedMID', header: 'Existing MID' , isFrozenColumn: true},
      { field: 'locationName', header: 'Managing Team' , isFrozenColumn: true},
      { field: 'billingTypeName', header: 'Billing Type' , isFrozenColumn: true},
      { field: 'oldSowNumber', header: 'Old Sow Number' , isFrozenColumn: false},
      { field: 'sowNumber', header: 'SOW Number' , isFrozenColumn: false},
      { field: 'sowName', header: 'SOW Name' , isFrozenColumn: false},
      {
        field: 'sowStartDate',
        header: 'SOW Start Date',
        format: 'dd-MMM-yyyy'
        , isFrozenColumn: false},
      { field: 'sowEndDate', header: 'SOW End Date', format: 'dd-MMM-yyyy' , isFrozenColumn: false},
      {
        field: 'amortizationStartMonth',
        header: 'Amortization Starting From',
        format: 'dd-MMM-yyyy' , isFrozenColumn: false},
      {
        field: 'amortizationEndMonth',
        header: 'Amortization Ending On',
        format: 'dd-MMM-yyyy', isFrozenColumn: false},
      { field: 'poNumber', header: 'PO Number' , isFrozenColumn: false},
      { field: 'poStartDate', header: 'PO Start Date', format: 'dd-MMM-yyyy' , isFrozenColumn: false},
      { field: 'poEndDate', header: 'PO End Date', format: 'dd-MMM-yyyy' , isFrozenColumn: false},
      { field: 'ppmProjectID', header: 'PPM Project ID' , isFrozenColumn: false},
      { field: 'ppmProjectName', header: 'PPM Project Name' , isFrozenColumn: false},
      { field: 'obsMasterName', header: 'OBS' , isFrozenColumn: false},
      { field: 'wbsDetail', header: 'SAP Code' , isFrozenColumn: false},
      { field: 'verticalName', header: 'Vertical', isFrozenColumn: false},
      { field: 'towerName', header: 'Tower' , isFrozenColumn: false},
      { field: 'domainLeadEmail', header: 'Domain Lead Email' , isFrozenColumn: false},
      { field: 'costCenter', header: 'Cost Center' , isFrozenColumn: false},
      { field: 'domainSkillName', header: 'Domain Skill Name' , isFrozenColumn: false},
      { field: 'skillSet', header: 'Skill Set' , isFrozenColumn: false},
      {
        field: 'domainSkillStartDate',
        header: 'DomainSkill Start Date',
        format: 'dd-MMM-yyyy', isFrozenColumn: false},
      {
        field: 'domainSkillEndDate',
        header: 'DomainSkill End Date',
        format: 'dd-MMM-yyyy', isFrozenColumn: false},
      { field: 'projectOrRun', header: 'Project Or Run', isFrozenColumn: false},
      // { field: 'contractTypeName', header: 'Contract Type' },

      // { field: 'validationRemarks', header: 'Validation Remarks' },
      // { field: 'cmid', header: 'cmid' },
      { field: 'isActive', header: 'Is Active', type:Boolean , isFrozenColumn: false},
      { field: 'updateDate', header: 'Uploaded Date', format: 'dd-MMM-yyyy', isFrozenColumn: false},
      { field: 'updatedBy', header: 'Uploaded By' , isFrozenColumn: false},
      // { field: 'wfOrder', header: 'wfOrder' },
      // { field: 'FBCID', header: 'FBCID' },
    ];
 
  }
  viewMonthlyDetails(etwid: number, SowNumber: string) {
    this.ref = this.dialogService.open(MonthlyDetailsDlgComponent, {
      header: 'Monthly Details -' + etwid,
      data: SowNumber,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      maximizable: true,
    });
  }
  viewMilestoneDetails(etwid: number, SowNumber: string) {
    this.MilestoneDialog = true;
    this.dialogHeader = 'Milestone Details - ' + etwid;
    this.fpUploadService
      .GetMilestoneDetailsBySowNum(SowNumber)
      .subscribe((result) => {
        //console.log(result);
        this.MilestoneDetails = result;
      });
  }
  // GetMilestoneDetails(SowNumber:string)
  // {
  //    this.MilestoneDialog=true;
  //    this.ResourceOnboardingService.GetMilestoneDetailsBySowNum(
  //     SowNumber
  //   ).subscribe((result) => {
  //     //console.log(result);
  //     this.MilestoneDetails = result;
  //   });
  // }
  getFpContractMainDetails(FromDate: string, ToDate: string) {
    if (this.selectedFilter.code != 'select') {
      this.fpUploadService
        .getFPContractMainDetails(
          this.selectedFilter.code,
          FromDate,
          ToDate,
          this.selectedActiveFilter.code
        )
        .subscribe({
          next: (result: ifpUpload[]) => {
            this.fpDetails = result;
            if (this.fpDetails.length > 0) {
              this.messageService.add({
                severity: 'info',
                summary: 'Fetched',
                detail: 'FP contract details fetched successfully.',
              });
            } else {
              this.messageService.add({
                severity: 'warn',
                summary: 'No Records',
                detail: 'No FP contract details found.',
              });
            }
          },
          error: (err) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: 'Failed to fetch FP contract details.',
            });
          },
        });
    }
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  //}

  getSeverity(data: ifpUpload) {
    switch (data.status) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }

  viewFpWorkFlow(data: ifpUpload) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(FpWorkflowComponent, {
      // header: 'Work Flow History - ' + data.etwid,
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }
  SearchData() {
    if (this.selectedFilter.code != 'select') {
      const fromDate = this.FromDate.toISOString().split('T')[0];
      const toDate = this.ToDate.toISOString().split('T')[0];
      this.getFpContractMainDetails(fromDate, toDate);
    }
  }
}
