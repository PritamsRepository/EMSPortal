import { AfterContentInit, Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';

@Component({
  selector: 'app-fp-workflow',
  templateUrl: './fp-workflow.component.html',
  styleUrls: ['./fp-workflow.component.css'],
  providers: [DynamicDialogRef],
})
export class FpWorkflowComponent implements AfterContentInit {
  constructor(
    private readonly _ref: DynamicDialogRef,
    private readonly _config: DynamicDialogConfig,
    private readonly _fpUpload: FpUploadService,
    private readonly ROBService: ResourceOnboardingService
  ) {}
  Poscols!: any[];
  cols!: any[];
  fpWfDetails!: any[];
  fpposDetails!: any[];
  showPosDetails: boolean = false;
  ngAfterContentInit() {
    console.log('data for dialog : ', this._config.data);
    console.log('data for dialog : ', this._config.data.cmid);
  
    this._fpUpload.getFPContractWorkFlow(this._config.data.fbcid, 
      this._config.data.billingTypeName, this._config.data.contractTypeName).subscribe({
      next: (result) => {
        console.log('RESULT : ', result);
        this.fpWfDetails = result;
        this.cols = [
          { field: 'role', header: 'Role' },
          { field: 'actionByName', header: 'Action By' },
          { field: 'action', header: 'Action' },
          { field: 'actionDate', header: 'Action Date', type: 'date' },
          { field: 'remarks', header: 'Remarks' },
          { field: 'nextWfrole', header: 'Redirected To' },
        ];
        if (this.fpWfDetails.length == 0) {
          // alert('No Work Flow.');
        }else {
          //Reusing TM method. The SP returning the data for FP also.
          this.ROBService.GetTMmultiRcrsByPsCode(
            this._config.data.etwid
          ).subscribe((fpposDetailsresult) => {
            console.log(fpposDetailsresult);
            this.fpposDetails = fpposDetailsresult.map(
              (item: { firstName: any; lastName: any }) => {
                // Concatenate firstName and lastName to create Fullname
                const fullname = `${item.firstName} ${item.lastName}`;

                // Add Fullname property to the item
                return {
                  ...item,
                  Fullname: fullname,
                };
              }
            );


            if (this.fpposDetails.length != 0) {
              this.showPosDetails = true;
            }
            this.Poscols = [
              { field: 'positionCode', header: 'PositionCode' },
              { field: 'Fullname', header: 'Name' },
              { field: 'viatrisMID', header: 'MID' },
              // { field: 'firstName', header: 'First Name' },
              // { field: 'lastName', header: 'last Name' },
              { field: 'mappedBy', header: 'Mapped By' },
              { field: 'mappedDate', header: 'Mapped Date', type: 'date' },
              {
                field: 'isMappingActive',
                header: 'Is Mapping Active',
                type: 'boolean',
              },
              { field: 'status', header: 'Resource Status' },
              { field: 'vendorName', header: 'Vendor Name' },
            ];
          });
        }
      },

      error: (error) => {
        console.error('Error fetching workflow details:', error);
        // Handle error as needed
      },
    });
  }
}
