import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpWorkflowComponent } from './fp-workflow.component';

describe('FpWorkflowComponent', () => {
  let component: FpWorkflowComponent;
  let fixture: ComponentFixture<FpWorkflowComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpWorkflowComponent]
    });
    fixture = TestBed.createComponent(FpWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
