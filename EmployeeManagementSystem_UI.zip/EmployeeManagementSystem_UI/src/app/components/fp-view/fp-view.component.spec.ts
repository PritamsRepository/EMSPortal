import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpViewComponent } from './fp-view.component';

describe('FpViewComponent', () => {
  let component: FpViewComponent;
  let fixture: ComponentFixture<FpViewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpViewComponent]
    });
    fixture = TestBed.createComponent(FpViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
