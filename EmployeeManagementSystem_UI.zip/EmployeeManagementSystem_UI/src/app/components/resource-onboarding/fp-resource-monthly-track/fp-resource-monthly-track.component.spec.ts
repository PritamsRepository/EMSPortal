import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpResourceMonthlyTrackComponent } from './fp-resource-monthly-track.component';

describe('FpResourceMonthlyTrackComponent', () => {
  let component: FpResourceMonthlyTrackComponent;
  let fixture: ComponentFixture<FpResourceMonthlyTrackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpResourceMonthlyTrackComponent]
    });
    fixture = TestBed.createComponent(FpResourceMonthlyTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
