import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-fp-onboarding-track-menu',
  templateUrl: './fp-onboarding-track-menu.component.html',
  styleUrls: ['./fp-onboarding-track-menu.component.css'],
})
export class FpOnboardingTrackMenuComponent {
  activeItem!: MenuItem;

  items!: MenuItem[];
  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {
    this.createtab();
  }
  ngOnInit() {}
  createtab() {
    this.items = [
      {
        label: 'Track FP Milestone Contracts',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['../fpRsrcMlstneTrk'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Track FP Monthly Contracts',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['../fpRsrcMonthlyTrk'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
  }

  onTabChange(event: MenuItem) {
    this.activeItem = event;
  }
}
