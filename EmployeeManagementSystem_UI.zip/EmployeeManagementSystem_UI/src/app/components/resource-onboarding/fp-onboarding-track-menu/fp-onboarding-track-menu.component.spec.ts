import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpOnboardingTrackMenuComponent } from './fp-onboarding-track-menu.component';

describe('FpOnboardingTrackMenuComponent', () => {
  let component: FpOnboardingTrackMenuComponent;
  let fixture: ComponentFixture<FpOnboardingTrackMenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpOnboardingTrackMenuComponent]
    });
    fixture = TestBed.createComponent(FpOnboardingTrackMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
