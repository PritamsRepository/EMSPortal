import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-fp-resource-mid-menu',
  templateUrl: './fp-resource-mid-menu.component.html',
  styleUrls: ['./fp-resource-mid-menu.component.css'],
})
export class FpResourceMidMenuComponent {
  activeItem!: MenuItem;

  items!: MenuItem[];
  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {
    this.createtab();
  }
  ngOnInit() {
    //console.log('test1');
    //console.log(this.items);
    //console.log(this.activeItem);
  }
  createtab() {
    this.items = [
      {
        label: 'Pending FP Milestone MID Update',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['../fpMilestoneMid'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Pending FP Monthly MID Update',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['../fpMonthlyMid'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
  }

  onTabChange(event: MenuItem) {
    this.activeItem = event;
  }
}
