import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpResourceMidMenuComponent } from './fp-resource-mid-menu.component';

describe('FpResourceMidMenuComponent', () => {
  let component: FpResourceMidMenuComponent;
  let fixture: ComponentFixture<FpResourceMidMenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpResourceMidMenuComponent]
    });
    fixture = TestBed.createComponent(FpResourceMidMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
