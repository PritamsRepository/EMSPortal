import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyDetailsDlgComponent } from './monthly-details-dlg.component';

describe('MonthlyDetailsDlgComponent', () => {
  let component: MonthlyDetailsDlgComponent;
  let fixture: ComponentFixture<MonthlyDetailsDlgComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MonthlyDetailsDlgComponent]
    });
    fixture = TestBed.createComponent(MonthlyDetailsDlgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
