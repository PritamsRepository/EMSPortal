import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MonthlyDetails } from 'src/app/core/interfaces/monthly-details';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';

@Component({
  selector: 'app-monthly-details-dlg',
  templateUrl: './monthly-details-dlg.component.html',
  styleUrls: ['./monthly-details-dlg.component.css'],
  providers: [DynamicDialogRef],
})
export class MonthlyDetailsDlgComponent implements OnInit {
  MonthlyDetails!: MonthlyDetails[];
  constructor(
    private readonly _ref: DynamicDialogRef,
    private readonly _config: DynamicDialogConfig,
    private readonly ResourceOnboardingService: ResourceOnboardingService
  ) {}
  ngOnInit() {
    // console.log('data for dialog : ', this._config.data);
    //console.log('data for dialog : ', this._config.data);
    this.ResourceOnboardingService.GetMonthlyDetailsBySowNum(
      this._config.data
    ).subscribe((result) => {
      //console.log(result);
      this.MonthlyDetails = result;
    });
  }
}
