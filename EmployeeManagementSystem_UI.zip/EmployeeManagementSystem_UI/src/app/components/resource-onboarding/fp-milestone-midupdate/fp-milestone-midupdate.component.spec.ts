import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpMilestoneMIDUpdateComponent } from './fp-milestone-midupdate.component';

describe('FpMilestoneMIDUpdateComponent', () => {
  let component: FpMilestoneMIDUpdateComponent;
  let fixture: ComponentFixture<FpMilestoneMIDUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpMilestoneMIDUpdateComponent]
    });
    fixture = TestBed.createComponent(FpMilestoneMIDUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
