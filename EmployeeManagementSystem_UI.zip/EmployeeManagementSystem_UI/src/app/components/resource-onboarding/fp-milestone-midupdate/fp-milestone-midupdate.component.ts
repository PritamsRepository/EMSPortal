import { Component, OnInit } from '@angular/core';
import { MilestoneDetails } from 'src/app/core/interfaces/milestone-details';
import { ResourceBasicDts } from 'src/app/core/interfaces/resource-basic-dts';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FpWorkflowComponent } from '../../fp-view/fp-workflow/fp-workflow.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MilestoneDetailsDlgComponent } from '../milestone-details-dlg/milestone-details-dlg.component';

@Component({
  selector: 'app-fp-milestone-midupdate',
  templateUrl: './fp-milestone-midupdate.component.html',
  styleUrls: ['./fp-milestone-midupdate.component.css'],
  providers: [DialogService],
})
export class FpMilestoneMIDUpdateComponent implements OnInit {
  pageTitle: string = 'Fixed Price Milestone - MID Update Pending Requests';
  contractlistTrack!: ResourceTrack[];
  contractWorkFlow!: ResourceWorkflow[];
  resources!: ResourceTrack[];
  data: any[] = [];
  Workflowdialog: boolean = false;
  MilestoneDialog: boolean = false;
  MIDdialog: boolean = false;
  AssetsRequired!: boolean;
  Email!: string;
  MID!: string;
  visible: boolean = false;
  wfheadertext: string = 'Work Flow History';
  // Error:boolean=true;
  midemailError: boolean = true;
  MilestoneDetails!: MilestoneDetails[];
  validationMessage!: string;
  Assets!: string;
  RMID!: number;
  CMID!: number;
  fbcIntID!: number;
  positionTrack!: ResourceTrack[];
  ref: DynamicDialogRef | undefined;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    public StorageService: StorageService,
    private DialogService: DialogService
  ) {}
  ngOnInit() {
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    this.GetResourceMIDcreationPendingList(MID, Number(locationID));
  }
  GetResourceMIDcreationPendingList(UserName: string, LocationID: number) {
    this.ResourceOnboardingService.GetMilestoneMIDcreationPendingList(
      UserName,
      LocationID
    ).subscribe((result) => {
      //console.log(result);
      this.contractlistTrack = result;
    });
  }
  // GetFPWorkFlowData(fbcIntID: number, etwid: string) {
  //   this.showDialog();
  //   (this.wfheadertext = 'Work Flow History - (ETWID:- ' + etwid + ')'),
  //     // this.wfheadertext="Work Flow History-" + etwid;
  //     this.ResourceOnboardingService.GetFPmilestoneResourceWorkFlow(
  //       fbcIntID
  //     ).subscribe((result) => {
  //       //console.log(result);
  //       this.contractWorkFlow = result;
  //     });
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(etwid).subscribe(
  //     (result) => {
  //       this.positionTrack = result;
  //     }
  //   );
  // }
  GetMIDData(rmid: number, fbcIntID: number) {
    debugger;
    this.resources = this.contractlistTrack.filter(
      (x) => x.fbcIntID == fbcIntID
    );
    this.RMID = rmid;
    this.fbcIntID = fbcIntID;
    this.showMIDDialog();
  }
  showDialog() {
    this.Workflowdialog = true;
  }
  showMIDDialog() {
    this.MIDdialog = true;
    this.MID = null;
    this.Email = null;
    // this.Error=true;
    this.midemailError = true;
  }
  // GetMilestoneDetails(SowNumber: string) {
  //   this.MilestoneDialog = true;
  //   this.ResourceOnboardingService.GetMilestoneDetailsBySowNum(
  //     SowNumber
  //   ).subscribe((result) => {
  //     //console.log(result);
  //     this.MilestoneDetails = result;
  //   });
  // }
  IsAssetClicked(event: Event) {
    this.visible = this.AssetsRequired;
  }
  SearchDataAD() {
    debugger;
    if (this.MID != null) {
      this.ResourceOnboardingService.SearchDataFromAd(this.MID).subscribe(
        (valiedata: string) => {
          if (valiedata != null) {
            this.Email = valiedata;
            this.midemailError = true;
          } else {
            this.validationMessage = '';
            this.validationMessage =
              "Note : MID does't exist, you can still save the data.";
            this.midemailError = false;
          }
        }
      );
    }
  }
  SaveData() {
    // if (this.MID== null||this.Email==null||(this.AssetsRequired==true && this.Assets==null))
    if (this.MID == null || this.Email == null) {
      this.validationMessage = '';
      this.validationMessage = 'Note : Please fill all required fields.';
      this.midemailError = false;
    } else {
      this.midemailError = true;
      const rtype = {} as ResourceBasicDts;
      rtype.mid = this.MID;
      rtype.email = this.Email;
      rtype.rmid = this.RMID;
      rtype.cmid = this.fbcIntID;
      var MID = this.StorageService.getCurrentUserMID();
      var locationID = this.StorageService.getCurrentUserLocationID();
      this.ResourceOnboardingService.SaveMilestoneResourceAssetDetails(
        rtype
      ).subscribe((valiedata: string) => {
        if (valiedata == null) {
          this.midemailError = true;
          this.GetResourceMIDcreationPendingList(MID, Number(locationID));
          this.MIDdialog = false;
        } else {
          this.validationMessage = '';
          this.validationMessage = valiedata;
          // this.validationMessage="Note : MID/Email ID already exist, Please provide correct MID/Email ID.";
          this.midemailError = false;
        }
      });
    }
  }


  GetFPWorkFlowData(data: ResourceTrack) {
    debugger;
    //console.log('Data : ', data);
    var fpDatatofetch = {
      fbcid: data.fbcIntID,
      billingTypeName: data.billingType,
      contractTypeName: data.contractType,
      positionCode: data.etwid,
      etwid:data.etwid,
    };
    this.ref = this.DialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      // header: 'Work Flow History-'+data.etwid,
      data: fpDatatofetch,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
  GetMilestoneDetails(SowNumber: string,etwid:string) {
    this.ref = this.DialogService.open(MilestoneDetailsDlgComponent, {
      header: 'Milestone Details - (ETWID:- ' + etwid + ')',
      data: SowNumber,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      maximizable: true,
    });
  }
}
