import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpResourceMilestoneTrackComponent } from './fp-resource-milestone-track.component';

describe('FpResourceMilestoneTrackComponent', () => {
  let component: FpResourceMilestoneTrackComponent;
  let fixture: ComponentFixture<FpResourceMilestoneTrackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpResourceMilestoneTrackComponent]
    });
    fixture = TestBed.createComponent(FpResourceMilestoneTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
