import { MilestoneDetails } from 'src/app/core/interfaces/milestone-details';
import { Component, OnInit } from '@angular/core';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { FpWorkflowComponent } from '../../fp-view/fp-workflow/fp-workflow.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MilestoneDetailsDlgComponent } from '../milestone-details-dlg/milestone-details-dlg.component';


@Component({
  selector: 'app-fp-resource-milestone-track',
  templateUrl: './fp-resource-milestone-track.component.html',
  styleUrls: ['./fp-resource-milestone-track.component.css'],
  providers: [DialogService],
  
})
export class FpResourceMilestoneTrackComponent implements OnInit {
  pageTitle: string = 'Fixed Price - Track Milestone Positions';
  contractlistTrack!: ResourceTrack[];
  contractWorkFlow!: ResourceWorkflow[];
  resources!: ResourceTrack;
  wfheadertext: string = 'Work Flow History';
  data: any[] = [];
  ddFilter: any[] = [];
  ddActiveFilter: any[] = [];
  selectedFilter?: any = { name: 'ALL', code: 'ALL' };
  selectedActiveFilter?:any = { name: 'Active', code: 'Active' };
  FromDate!: Date;
  ToDate!: Date;
  dialogVisible: boolean = false;
  MilestoneDialog: boolean = false;
  MilestoneDetails!: MilestoneDetails[];
  positionTrack!: ResourceTrack[];
  ref: DynamicDialogRef | undefined;

  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    public StorageService: StorageService,
    private DialogService: DialogService,
  ) {}
  ngOnInit() {
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    const today = new Date();
    // this.FromDate = new Date(today.setDate(1));
    this.FromDate = new Date(today.getFullYear() - 4, today.getMonth(), today.getDate());


    this.ToDate = new Date();
    const formattedFromDate = this.FromDate.toISOString().split('T')[0];
    const formattedToDate = new Date().toISOString().split('T')[0];
    this.ddFilter = [
      { name: '-- Select Filter --', code: 'select' },
      { name: 'Mapped Resource Without Credentials', code: 'Approved' },
      { name: 'Mapped Resource With Credentials', code: 'MidUpdated' },
      { name: 'Pending Resource Mapping List', code: 'Pending' },
      { name: 'ALL', code: 'ALL' },
    ];
    this.ddActiveFilter=[
      { name: 'Active', code: 'Active' },
      { name: 'In Active', code: 'InActive' },
      { name: 'Both', code: 'Both' },
    ];
    this.GetResourceMappingPendingList(
      MID,
      2,
      Number(locationID),
      this.selectedFilter.code,
      this.selectedActiveFilter.code,
      formattedFromDate,
      formattedToDate
    );
  }

  SearchData() {
    if (this.selectedFilter.code != 'select') {
      const fromDate = this.FromDate.toISOString().split('T')[0];
      const toDate = this.ToDate.toISOString().split('T')[0];
      this.GetResourceMappingPendingList(
        this.StorageService.getCurrentUserMID(),
        2,
        Number(this.StorageService.getCurrentUserLocationID()),
        this.selectedFilter.code,
        this.selectedActiveFilter.code,
        fromDate,
        toDate
      );
    }
  }
  GetResourceMappingPendingList(
    UserName: string,
    workflowOrder: number,
    LocationID: number,
    Filter: string,
   ActiveFilter:string,
    FromDate: string,
    ToDate: string
  ) {
    if (this.selectedFilter.code != 'select') {
      this.ResourceOnboardingService.GetResourceFPmilestoneTrackList(
        UserName,
        workflowOrder,
        LocationID,
        Filter,
        ActiveFilter,
        FromDate,
        ToDate
      ).subscribe((result) => {
        //console.log(result);
        this.contractlistTrack = result;
      });
    }
  }
  // GetFPWorkFlowData(fbcIntID: number, etwid: string) {
  //   this.showDialog();
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   (this.wfheadertext = 'Work Flow History - (ETWID:- ' + etwid + ')'),
  //     this.ResourceOnboardingService.GetFPmilestoneResourceWorkFlow(
  //       fbcIntID
  //     ).subscribe((result) => {
  //       //console.log(result);
  //       this.contractWorkFlow = result;
  //     });
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(etwid).subscribe(
  //     (result) => {
  //       this.positionTrack = result;
  //     }
  //   );
  // }

  showDialog() {
    this.dialogVisible = true;
  }
  // GetMilestoneDetails(SowNumber: string) {
  //   this.MilestoneDialog = true;
  //   this.ResourceOnboardingService.GetMilestoneDetailsBySowNum(
  //     SowNumber
  //   ).subscribe((result) => {
  //     //console.log(result);
  //     this.MilestoneDetails = result;
  //   });
  // }
  ExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    const filteredContractList = this.contractlistTrack.map((contract) => {
      const clonedContract = { ...contract };
      delete clonedContract.remarks;
      delete clonedContract.validationRemarks;
      delete clonedContract.vendorEmails;
      delete clonedContract.managerMid;
      delete clonedContract.isSelectedApproval;
      delete clonedContract.positionLocationId;
      delete clonedContract.tmvcmid;
      delete clonedContract.fbcIntID;
      delete clonedContract.vendorID;
      delete clonedContract.positionLocationId;
      delete clonedContract.cmid;
      delete clonedContract.amortizationStartMonth;
      delete clonedContract.amortizationEndMonth;
      delete clonedContract.rmid;
      delete clonedContract.billingRateYear1;
      delete clonedContract.billingRateYear2;
      delete clonedContract.billingRateYear3;
      delete clonedContract.billingRateYear4;
      delete clonedContract.billingRateYear5;
      return clonedContract;
    });

    // Convert the filteredContractList to a worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'FP Milestone Resource Track List.xlsx');
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  // }

  getSeverity(data: string) {
    switch (data) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }
  GetFPWorkFlowData(data: ResourceTrack) {
    debugger;
    //console.log('Data : ', data);
    var fpDatatofetch = {
      fbcid: data.fbcIntID,
      billingTypeName: data.billingType,
      contractTypeName: data.contractType,
      positionCode: data.etwid,
      etwid:data.etwid,
    };
    this.ref = this.DialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      // header: 'Work Flow History-'+data.etwid,
      data: fpDatatofetch,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
  GetMilestoneDetails(SowNumber: string,etwid:string) {
    this.ref = this.DialogService.open(MilestoneDetailsDlgComponent, {
      header: 'Milestone Details - (ETWID:- ' + etwid + ')',
      data: SowNumber,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      maximizable: true,
    });
  }
}
