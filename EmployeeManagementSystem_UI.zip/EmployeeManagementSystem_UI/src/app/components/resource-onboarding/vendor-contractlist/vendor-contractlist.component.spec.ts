import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorContractlistComponent } from './vendor-contractlist.component';

describe('VendorContractlistComponent', () => {
  let component: VendorContractlistComponent;
  let fixture: ComponentFixture<VendorContractlistComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VendorContractlistComponent]
    });
    fixture = TestBed.createComponent(VendorContractlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
