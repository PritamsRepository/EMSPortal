import { ResourceOnboardingService } from './../../../core/services/resource-onboarding/resource-onboarding.service';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import * as XLSX from 'xlsx';
import { ResourceMapping } from 'src/app/core/interfaces/resource-mapping';
import { FileSelectEvent } from 'primeng/fileupload';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import { environment } from 'src/environments/environment';
import { Roletypemapping } from 'src/app/core/interfaces/roletypemapping';
import { DatePipe, JsonPipe, formatDate } from '@angular/common';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Table } from 'primeng/table';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TmWorkflowComponent } from '../../tm-view/tm-workflow/tm-workflow.component';

@Component({
  selector: 'app-vendor-contractlist',
  templateUrl: './vendor-contractlist.component.html',
  styleUrls: ['./vendor-contractlist.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class VendorContractlistComponent implements OnInit {
  @ViewChild('ResourceMapping') RMVisibleRows!: Table;
  pageTitle: string = 'TIME & MATERIAL - Open Positions';
  contractlist!: ResourceMapping[];
  resources!: ResourceMapping;
  contractWorkFlow!: ResourceWorkflow[];
  data: any[] = [];
  isapprovechecked: boolean = false;
  isrejectchecked: boolean = false;
  totalApproved: number = 0;
  totalRejected: number = 0;
  inValidrecord!: ResourceMapping | null;
  errorMessage!: string | null;
  showError: boolean = false;
  dialogVisible: boolean = false;
  showUploadButton: boolean = false;
  fileValidation: string = '';
  positionTrack!: ResourceTrack[];
  wfheadertext: string = 'Work Flow History';
  ref!: DynamicDialogRef;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    private excelFileValidationService: excelFileValidation,
    private ConfirmationService: ConfirmationService,
    private MessageService: MessageService,
    public StorageService: StorageService,
    private cdr: ChangeDetectorRef,
    public dialogService: DialogService
  ) {}
  @ViewChild('fileUpload') fileUpload!: OverlayPanel;
  ngOnInit() {
    this.showError = false;

    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    this.GetResourceMappingPendingList(MID, Number(locationID));
  }
  isAnySendBackButtonEnabled(): boolean {
    if (this.contractlist && this.contractlist.length > 0) {
      var data = this.contractlist.some((contract) => contract.tmrmid != null);
      return data;
    } else {
      return false;
    }
  }
  ShowVendorMailBtm(): boolean {
    var data;
    if (this.contractlist && this.contractlist.length > 0) {
      if (
        this.contractlist.some(
          (contract) => contract.tmrmid == null
          //  contract.firstName == null ||
          //   contract.lastName == null ||
          //   contract.gender == null ||
          //   contract.managerName == null
        )
      ) {
        data = false;
      } else {
        data = true;
      }
    } else {
      data = true;
    }
    return data;
  }
  ShowUploadDownload(): boolean {
    if (this.contractlist && this.contractlist.length > 0) {
      return false;
    }
    return true;
  }
  showSaveButton(): boolean {
    if (this.totalApproved > 0 || this.totalRejected > 0) {
      return false;
    }
    return true;
  }
  async GetResourceMappingPendingList(UserName: string, LocationID: number) {
    try {
      const result =
        await this.ResourceOnboardingService.GetResourceMappingPendingList(
          UserName,
          LocationID
        ).toPromise();
      //console.log('contractlit', result);
      this.contractlist = result;
      this.sortByValidationRemarks();
    } catch (error) {
      console.error('API Error:', error);
    }
  }

  sortByValidationRemarks() {
    this.contractlist.sort((a, b) => {
      // Check if a or b has validation remarks, first name, or remappedmid
      const hasRemarksOrNameOrRemappedMidA =
        !!a.validationRemarks || !!a.firstName || !!a.remappedMID;
      const hasRemarksOrNameOrRemappedMidB =
        !!b.validationRemarks || !!b.firstName || !!b.remappedMID;

      if (hasRemarksOrNameOrRemappedMidA && !hasRemarksOrNameOrRemappedMidB) {
        return -1; // a comes before b
      } else if (
        !hasRemarksOrNameOrRemappedMidA &&
        hasRemarksOrNameOrRemappedMidB
      ) {
        return 1; // b comes before a
      } else {
        return 0; // no change in order
      }
    });
  }

  //   GetResourceMappingPendingList(UserName: string,LocationID:number) {
  //   this.ResourceOnboardingService.GetResourceMappingPendingList(UserName,LocationID)
  //     .subscribe((result) => {
  //       //console.log(result);
  //       this.contractlist = result;
  //     });
  // }
  exportToExcel(): void {
    const datePipe = new DatePipe('en-US');

    var visiblerows = this.RMVisibleRows.filteredValue
      ? this.RMVisibleRows.filteredValue
      : this.contractlist;

    if (visiblerows.length > 0) {
      // const filteredContractList = this.contractlist.map((contract) => {
      const filteredContractList = visiblerows.map((contract) => {
        // Create a new object to hold the properties in the desired order
        return {
          ETWID: contract.etwid,
          PositionCode: contract.positionCode,
          VendorName: contract.vendorName,
          SOWNumber: contract.sowNumber,
          SOWName: contract.sowName,
          SOWStartDate: contract.sowStartDate
            ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
            : null,
          SOWEndDate: contract.sowEndDate
            ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
            : null,
          PONumber: contract.poNumber,
          POStartDate: contract.poStartDate
            ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
            : null,
          POEndDate: contract.poEndDate
            ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
            : null,
          ContractType: contract.contractType,
          PPMProjectID: contract.ppmProjectID,
          ProjectName: contract.ppmProjectName,
          Tower: contract.tower,
          DomainSkillName: contract.domainName,
          Skillset: contract.skillSet,
          DomainSkillStartDate: contract.domainSkillStartDate
            ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
            : null,
          DomainSkillEndDate: contract.domainSkillEndDate
            ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
            : null,
          BillingType: contract.billingType,
          RemappedMID: contract.remappedMID,
          // CostCenter: contract.costCenter,
          FirstName: contract.firstName,
          LastName: contract.lastName,
          Gender: contract.gender,
          DOB: contract.dob
            ? datePipe.transform(contract.dob, 'dd-MMM-yyyy')
            : null,
          DOJViatris: contract.dojViatris
            ? datePipe.transform(contract.dojViatris, 'dd-MMM-yyyy')
            : null,
          ManagerName: contract.managerName,
          ManagerEmail: contract.managerEmail,
          MobileNumber: contract.mobileNumber,
        };
      });

      // Convert the filteredContractList to a worksheet
      const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

      // Create a workbook and append the worksheet
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      // Save the workbook as an Excel file
      XLSX.writeFile(wb, 'Resource List.xlsx');
      this.ShowVendorMailBtm();
    }
  }

  OnUpload(event: FileSelectEvent) {
    const file = event.currentFiles[0];
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const fileContent = e.target.result;
      const result =
        this.excelFileValidationService.readExcelFileUpload(fileContent);
      var validate = this.excelFileValidationService.hasDuplicateRecordsTmPMO(
        result,
        this.contractlist
      );
      //console.log('validationmessage', validate.message);
      if (validate.message == null || validate.message == '') {
        const result1 = result as ResourceMapping[];
        // //console.log(result1);
        this.ResourceOnboardingService.SaveOnboardingResourceMapping(
          result1
        ).subscribe((data) => {
          this.cdr.detectChanges();

          //console.log(data);
          // }
          this.totalApproved = 0;
          this.totalRejected = 0;
          this.showSaveButton();
          this.showError = false;
          this.fileUpload.hide();
          var MID = this.StorageService.getCurrentUserMID();
          var locationID = this.StorageService.getCurrentUserLocationID();
          this.GetResourceMappingPendingList(MID, Number(locationID));
        });
      } else {
        this.fileValidation = validate.message;
        //console.log('syftuyrft', validate.message);
      }
    };

    reader.readAsBinaryString(file);
  }
  selectApproveAll() {
    this.contractlist.forEach((x) => {
      if (!x.validationRemarks && (x.firstName || x.remappedMID)) {
        x.isSelectedApproval = true;
        this.isapprovechecked = true;
        this.isrejectchecked = false;
        this.totalApproved = this.contractlist.filter(
          (x) => !x.validationRemarks && (x.firstName || x.remappedMID)
        ).length;
      }
    });
    // this.totalApproved = [...this.contractlist].length;
    this.totalRejected = 0;
    this.showSaveButton();
  }
  selectApprove(resources: ResourceMapping) {
    const aIndex = this.contractlist.findIndex((item) => item === resources);
    if (aIndex !== -1) {
      this.totalApproved = this.totalApproved + 1;
      if (this.contractlist[aIndex].isSelectedApproval != null) {
        this.totalRejected =
          this.totalRejected == 0 ? 0 : this.totalRejected - 1;
      }
      this.contractlist[aIndex].isSelectedApproval = true; // Remove 1 element starting from the index
    }
    this.isapprovechecked = false;
    this.isrejectchecked = false;
    this.showSaveButton();
  }
  selectRejectAll() {
    debugger;
    this.contractlist.forEach((x) => {
      if (x.tmrmid !== null) {
        x.isSelectedApproval = false;
      }
    });
    //this.contractlist.forEach((x) => (x.isSelectedApproval = false && x.firstName));
    this.totalApproved = 0;
    this.totalRejected = [...this.contractlist].filter(
      (x) => x.isSelectedApproval == false
    ).length;
    this.isapprovechecked = false;
    this.isrejectchecked = true;
    this.showSaveButton();
  }
  //Click on SendBack
  selectReject(resources: ResourceMapping) {
    const aIndex = this.contractlist.findIndex((item) => item === resources);
    if (aIndex !== -1) {
      if (this.contractlist[aIndex].isSelectedApproval != null) {
        this.totalApproved =
          this.totalApproved == 0 ? 0 : this.totalApproved - 1;
      }
      this.totalRejected = this.totalRejected + 1;
      this.contractlist[aIndex].isSelectedApproval = false;
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;
    this.showSaveButton();
  }

  submitResourceData() {
    // Check for invalid records without remarks
    const invalidRecord = this.contractlist.find(
      (item) =>
        item.isSelectedApproval === false &&
        (item.remarks === '' || item.remarks === null)
    );

    if (invalidRecord) {
      this.inValidrecord = invalidRecord as ResourceMapping;
      this.showError = true;
      return;
    } else {
      this.showError = false;
    }

    // Filter data for submission
    const filteredData = this.contractlist.filter(
      (x) =>
        x.tmrmid != null &&
        (x.isSelectedApproval === true || x.isSelectedApproval === false)
    );

    if (filteredData.length > 0) {
      // Submit approval data
      this.ResourceOnboardingService.submitApprovaldata(filteredData).subscribe(
        (result) => {
          //console.log(result);
          var MID = this.StorageService.getCurrentUserMID();
          var locationID = this.StorageService.getCurrentUserLocationID();
          this.cdr.detectChanges();
          this.totalApproved = 0;
          this.totalRejected = 0;
          this.showSaveButton();
          this.showError = false;
          this.fileUpload.hide();
          this.GetResourceMappingPendingList(MID, Number(locationID));
        }
      );
    } else {
      //console.log('No mail sent. Filtered data count is not greater than 0.');
    }
  }

  SendMailToVendor() {
    // const filteredData = this.contractlist.filter(
    //   (x) =>
    //     x.firstName == null ||
    //     x.firstName == '' ||
    //     x.lastName == '' ||
    //     x.lastName == null ||
    //     x.validationRemarks != null
    // );

    var visiblerows = this.RMVisibleRows.filteredValue
      ? this.RMVisibleRows.filteredValue
      : this.contractlist;

    const filteredData = visiblerows.filter((x) => x.tmrmid == null);

    if (filteredData.length > 0) {
      this.ResourceOnboardingService.sendOpenPositionsToVendor(
        filteredData
      ).subscribe((result) => {
        //console.log(result);

        // Call GetResourceMappingPendingList inside the subscribe callback
        var MID = this.StorageService.getCurrentUserMID();
        var locationID = this.StorageService.getCurrentUserLocationID();
        this.GetResourceMappingPendingList(MID, Number(locationID));

        // if (result.message === 'success') {
        //   this.MessageService.add({
        //     severity: 'info',
        //     summary: 'Mail sent to vendor Successfully!',
        //   });
        // }
      });
    } else {
      //console.log('No mail sent. Filtered data count is not greater than 0.');
    }
  }

  // GetTMWorkFlowData(cmid: number, positionCode: string, etwid: number) {
  //   this.showDialog();
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   (this.wfheadertext = 'Work Flow History - (ETWID:- ' + etwid + ')'),
  //     this.ResourceOnboardingService.GetTMResourceWorkFlow(cmid).subscribe(
  //       (result) => {
  //         //console.log(result);
  //         this.contractWorkFlow = result;
  //       }
  //     );
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(
  //     positionCode
  //   ).subscribe((result) => {
  //     this.positionTrack = result;
  //   });
  // }

  viewTmWorkFlow(data: any) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History  - (ETWID : ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  showDialog() {
    this.dialogVisible = true;
  }
  deleteTMFromIntr(tmrmid: number) {
    this.ResourceOnboardingService.DeleteIntrResourceTMdata(tmrmid).subscribe(
      (data) => {
        this.cdr.detectChanges();
        this.totalApproved = 0;
        this.totalRejected = 0;
        this.showSaveButton();
        this.showError = false;
        this.fileUpload.hide();
        var MID = this.StorageService.getCurrentUserMID();
        var locationID = this.StorageService.getCurrentUserLocationID();
        this.GetResourceMappingPendingList(MID, Number(locationID));
      }
    );
  }
}
