import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-fp-onboarding-approval-menuitems',
  templateUrl: './fp-onboarding-approval-menuitems.component.html',
  styleUrls: ['./fp-onboarding-approval-menuitems.component.css'],
})
export class FpOnboardingApprovalMenuitemsComponent {
  activeItem!: MenuItem;

  items!: MenuItem[];
  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {
    this.createtab();
  }
  ngOnInit() {
    //console.log('test1');
    //console.log(this.items);
    //console.log(this.activeItem);
  }
  createtab() {
    this.items = [
      {
        label: 'Pending FP Milestone Open Positions',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['../fpOnboardMilestoneApproval'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Pending FP Monthly Open Positions',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['../fpOnboardMonthlyApproval'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
  }

  onTabChange(event: MenuItem) {
    this.activeItem = event;
  }
}
