import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpOnboardingApprovalMenuitemsComponent } from './fp-onboarding-approval-menuitems.component';

describe('FpOnboardingApprovalMenuitemsComponent', () => {
  let component: FpOnboardingApprovalMenuitemsComponent;
  let fixture: ComponentFixture<FpOnboardingApprovalMenuitemsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpOnboardingApprovalMenuitemsComponent]
    });
    fixture = TestBed.createComponent(FpOnboardingApprovalMenuitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
