import { DatePipe } from '@angular/common';
import { ResourceOnboardingService } from './../../../core/services/resource-onboarding/resource-onboarding.service';
import { Component, OnInit } from '@angular/core';
import { ResourceMapping } from 'src/app/core/interfaces/resource-mapping';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { TmPositionTrack } from 'src/app/core/interfaces/tm-position-track';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import * as XLSX from 'xlsx';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TmWorkflowComponent } from '../../tm-view/tm-workflow/tm-workflow.component';
import { iBillingTypeMaster, iContractTypeMaster, iLocationMaster, iObsMaster, iProjectOrRunMaster, iSkillSetMaster, iSowTypeMaster, iTowerNameMaster, iVendorMaster, iVerticalMaster } from 'src/app/core/interfaces/imasterDetails';
import { itmUpload } from 'src/app/core/interfaces/itmupload';
import { ConfirmationService, MessageService } from 'primeng/api';
import { itmDetails } from 'src/app/core/interfaces/itmDetails';

@Component({
  selector: 'app-tm-onboarding-track',
  templateUrl: './tm-onboarding-track.component.html',
  styleUrls: ['./tm-onboarding-track.component.css'],
  providers: [MessageService, DialogService, ConfirmationService],

})
export class TmOnboardingTrackComponent implements OnInit {
  pageTitle: string = 'TRACK TIME & MATERIAL CONTRACTS';
  contractlistTrack!: ResourceTrack[];
  contractWorkFlow!: ResourceWorkflow[];
  resources!: ResourceTrack;



  data: any[] = [];
  ddFilter: any[] = [];
  ddActiveFilter:any[]=[];
  selectedFilter?: any = { name: 'ALL', code: 'ALL' };
  selectedActiveFilter?:any = { name: 'Active', code: 'Active' };
  FromDate!: Date;
  ToDate!: Date;
  dialogVisible: boolean = false;
  positionTrack!: TmPositionTrack[];
  wfheadertext: string = 'Work Flow History';
  ref!: DynamicDialogRef;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    public StorageService: StorageService,
    public dialogService: DialogService,

    private messageService: MessageService,

  ) {}

  ngOnInit() {
    this.LoadTMTrackscreen();
  }

  LoadTMTrackscreen(){
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    const today = new Date();
    // this.FromDate = new Date(today.setDate(1));
    this.FromDate = new Date(today.getFullYear() - 4, today.getMonth(), today.getDate());

    this.ToDate = new Date();
    const formattedFromDate = this.FromDate.toISOString().split('T')[0];
    const formattedToDate = new Date().toISOString().split('T')[0];

    this.ddFilter = [
      { name: '-- Select Filter --', code: 'select' },
      { name: 'Mapped Resource Without Credentials', code: 'Approved' },
      { name: 'Mapped Resource With Credentials', code: 'MidUpdated' },
      { name: 'Pending Resource Mapping List', code: 'Pending' },
      { name: 'ALL', code: 'ALL' },
    ];
    this.ddActiveFilter=[
      { name: 'Active', code: 'Active' },
      { name: 'In Active', code: 'InActive' },
      { name: 'Both', code: 'Both' },
    ];
    this.GetResourceMappingPendingList(
      MID,
      2,
      Number(locationID),
      this.selectedFilter.code,
      this.selectedActiveFilter.code,
      formattedFromDate,
      formattedToDate
    );
  }

  SearchData() {
    if (this.selectedFilter.code != 'select') {
      const fromDate = this.FromDate.toISOString().split('T')[0];
      const toDate = this.ToDate.toISOString().split('T')[0];
      this.GetResourceMappingPendingList(
        this.StorageService.getCurrentUserMID(),
        2,
        Number(this.StorageService.getCurrentUserLocationID()),
        this.selectedFilter.code,
        this.selectedActiveFilter.code,
        fromDate,
        toDate
      );
    }
  }
  GetResourceMappingPendingList(
    UserName: string,
    workflowOrder: number,
    LocationID: number,
    Filter: string,
   ActiveFilter:string,
    FromDate: string,
    ToDate: string
  ) {
    if (this.selectedFilter.code != 'select') {
      this.ResourceOnboardingService.GetResourceMappingTrackList(
        UserName,
        workflowOrder,
        LocationID,
        Filter,
        ActiveFilter,
        FromDate,
        ToDate
      ).subscribe((result) => {
        //console.log(result);
        this.contractlistTrack = result;
      });
    }
  }
  // GetTMWorkFlowData(tmvcmid: number, positionCode: string, etwid: number) {
  //   this.showDialog();
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   (this.wfheadertext = 'Work Flow History - (ETWID:- ' + etwid + ')'),
  //     this.ResourceOnboardingService.GetTMResourceWorkFlow(tmvcmid).subscribe(
  //       (result) => {
  //         //console.log(result);
  //         this.contractWorkFlow = result;
  //       }
  //     );
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(
  //     positionCode
  //   ).subscribe((result) => {
  //     this.positionTrack = result;
  //   });
  // }

  viewTmWorkFlow(data: any) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History  - (ETWID : ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  showDialog() {
    this.dialogVisible = true;
  }
  ExportToExcel(): void {
    const filteredContractList = this.contractlistTrack.map((contract) => {
   
      const clonedContract = { ...contract };
      delete clonedContract.remarks;
      delete clonedContract.validationRemarks;
      delete clonedContract.vendorEmails;
      delete clonedContract.managerMid;
      delete clonedContract.isSelectedApproval;
      delete clonedContract.positionLocationId;
      delete clonedContract.tmvcmid;
      delete clonedContract.fbcIntID;
      delete clonedContract.vendorID;
      delete clonedContract.positionLocationId;
      delete clonedContract.cmid;
      delete clonedContract.amortizationStartMonth;
      delete clonedContract.amortizationEndMonth;
      delete clonedContract.rmid;

      return clonedContract;
    });
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'T&M Resource Track List.xlsx');
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  // }

  getSeverity(data: string) {
    switch (data) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }
  




}
