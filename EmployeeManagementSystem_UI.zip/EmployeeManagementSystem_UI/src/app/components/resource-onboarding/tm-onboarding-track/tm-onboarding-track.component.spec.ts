import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmOnboardingTrackComponent } from './tm-onboarding-track.component';

describe('TmOnboardingTrackComponent', () => {
  let component: TmOnboardingTrackComponent;
  let fixture: ComponentFixture<TmOnboardingTrackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmOnboardingTrackComponent]
    });
    fixture = TestBed.createComponent(TmOnboardingTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
