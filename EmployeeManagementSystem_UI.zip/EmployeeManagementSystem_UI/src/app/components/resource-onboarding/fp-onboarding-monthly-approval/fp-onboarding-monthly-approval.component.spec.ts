import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpOnboardingMonthlyApprovalComponent } from './fp-onboarding-monthly-approval.component';

describe('FpOnboardingMonthlyApprovalComponent', () => {
  let component: FpOnboardingMonthlyApprovalComponent;
  let fixture: ComponentFixture<FpOnboardingMonthlyApprovalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpOnboardingMonthlyApprovalComponent]
    });
    fixture = TestBed.createComponent(FpOnboardingMonthlyApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
