import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FileSelectEvent } from 'primeng/fileupload';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Table } from 'primeng/table';
import { FpResourceMapping } from 'src/app/core/interfaces/fp-resource-mapping';
import { MonthlyDetails } from 'src/app/core/interfaces/monthly-details';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import * as XLSX from 'xlsx';
import { MonthlyDetailsDlgComponent } from '../monthly-details-dlg/monthly-details-dlg.component';
import { FpWorkflowComponent } from '../../fp-view/fp-workflow/fp-workflow.component';

@Component({
  selector: 'app-fp-onboarding-monthly-approval',
  templateUrl: './fp-onboarding-monthly-approval.component.html',
  styleUrls: ['./fp-onboarding-monthly-approval.component.css'],
  providers: [DialogService],
})
export class FpOnboardingMonthlyApprovalComponent implements OnInit {
  @ViewChild('ResourceMapping') RMVisibleRows!: Table;
  pageTitle: string = 'Fixed Price - Monthly Open Positions';
  fpapprovaldetail!: FpResourceMapping[];
  resources!: FpResourceMapping;
  contractWorkFlow!: ResourceWorkflow[];
  data: any[] = [];
  isapprovechecked: boolean = false;
  isrejectchecked: boolean = false;
  totalApproved: number = 0;
  totalRejected: number = 0;
  inValidrecord!: FpResourceMapping | null;
  errorMessage!: string | null;
  showError: boolean = false;
  dialogVisible: boolean = false;
  MonthlyDialog:boolean=false;
  fileValidation: string = '';
  wfheadertext:string="Work Flow History";
  positionTrack!:ResourceTrack[];
  ref: DynamicDialogRef | undefined;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    private excelFileValidationService: excelFileValidation,
    // private MessageService: MessageService,
    public StorageService: StorageService,
    private DialogService: DialogService,
    private cdr: ChangeDetectorRef
  ) {}
  @ViewChild('fileUpload') fileUpload!: OverlayPanel;
  ngOnInit() {
    this.showError = false;
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    this.GetResourceMappingPendingList(MID, Number(locationID));
  }
  isAnySendBackButtonEnabled(): boolean {
    if (this.fpapprovaldetail && this.fpapprovaldetail.length > 0) {
      var data = this.fpapprovaldetail.some(
        (contract) => contract.fpintid != null
      );
      return data;
    } else {
      // If this.contractlist is not defined or empty, consider the button as disabled
      return false;
    }
  }
  ShowVendorMailBtm(): boolean {
    var data;
    if (this.fpapprovaldetail && this.fpapprovaldetail.length > 0) {
      if (
        this.fpapprovaldetail.some(
          (contract) =>
            contract.fpintid==null
        )
      ) {
        data = false;
      } else {
        data = true;
      }
    } else {
      data = true;
    }
    return data;
  }
  ShowUploadDownload(): boolean {
    if (this.fpapprovaldetail && this.fpapprovaldetail.length > 0) {
      return false;
    }
    return true;
  }
  showSaveButton(): boolean {
    if (this.totalApproved > 0 || this.totalRejected > 0) {
      return false;
    }
    return true;
  }

  async GetResourceMappingPendingList(UserName: string, LocationID: number) {
    try {
      const result =
        await this.ResourceOnboardingService.GetResourceMappingMonthlyPendingList(
          UserName,
          LocationID
        ).toPromise();
      //console.log(result);
      this.fpapprovaldetail = result;
      this.sortByValidationRemarks();
    } catch (error) {
      console.error('API Error:', error);
    }
  }

  sortByValidationRemarks() {
    this.fpapprovaldetail.sort((a, b) => {
      // Check if a or b has validation remarks, first name, or remappedmid
      const hasRemarksOrNameOrRemappedMidA = !!a.validationRemarks || !!a.firstName || !!a.remappedMID;
      const hasRemarksOrNameOrRemappedMidB = !!b.validationRemarks || !!b.firstName || !!b.remappedMID;

      if (hasRemarksOrNameOrRemappedMidA && !hasRemarksOrNameOrRemappedMidB) {
        return -1; // a comes before b
      } else if (!hasRemarksOrNameOrRemappedMidA && hasRemarksOrNameOrRemappedMidB) {
        return 1; // b comes before a
      } else {
        return 0; // no change in order
      }
    });
  }

    exportToExcel(): void {

      const datePipe = new DatePipe('en-US');
      var visiblerows = this.RMVisibleRows.filteredValue
      ? this.RMVisibleRows.filteredValue
      : this.fpapprovaldetail;
      if(visiblerows.length>0) 
      {
         // const filteredContractList = this.contractlist.map((contract) => {
       const filteredContractList = visiblerows.map((contract) => {
        // Create a new object to hold the properties in the desired order
        return {
          ETWID: contract.etwid,
          VendorName: contract.vendorName,
          SOWNumber: contract.sowNumber,
          SOWName: contract.sowName,
          SOWStartDate: contract.sowStartDate
            ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
            : null,
          SOWEndDate: contract.sowEndDate
            ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
            : null,
         
          PONumber: contract.poNumber,
          POStartDate: contract.poStartDate
            ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
            : null,
          POEndDate: contract.poEndDate
            ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
            : null,
            DomainSkillName: contract.domainSkillName,
            Skillset: contract.skillSet,
            DomainSkillStartDate: contract.domainSkillStartDate
              ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
              : null,
            DomainSkillEndDate: contract.domainSkillEndDate
              ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
              : null,   
          ContractType:contract.contractType,
          PPMProjectID: contract.ppmProjectID,
          ProjectName: contract.ppmProjectName,
          Tower: contract.tower,
          BillingType:contract.billingType,
          RemappedMID: contract.remappedMID,
          FirstName: contract.firstName,
          LastName: contract.lastName,
          Gender: contract.gender,
          DOB: contract.dob
            ? datePipe.transform(contract.dob, 'dd-MMM-yyyy')
            : null,
          DOJViatris: contract.dojViatris
            ? datePipe.transform(contract.dojViatris, 'dd-MMM-yyyy')
            : null,
          ManagerName: contract.managerName,
          ManagerEmail: contract.managerEmail,
          MobileNumber: contract.mobileNumber,
        };
      
      });
      // Convert the filteredContractList to a worksheet
      const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);
      // Create a workbook and append the worksheet
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      // Save the workbook as an Excel file
      XLSX.writeFile(wb, 'Monthly Resource List.xlsx');
      this.ShowVendorMailBtm();
    }
    }
    OnUpload(event: FileSelectEvent) {
      debugger;
      const file = event.currentFiles[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const fileContent = e.target.result;
        const result =
        this.excelFileValidationService.readExcelFileUploadfpMonthly(fileContent);
      var validate = this.excelFileValidationService.hasDuplicateRecordsFpPMO(
        result,
        this.fpapprovaldetail
      );
      if (validate.message == null || validate.message == '') {
        this.fileValidation="";
        const result1 = result as FpResourceMapping[];
        this.ResourceOnboardingService.SaveOnboardingMonthlyResourceMapping(
          result1
        ).subscribe((data) => {
          this.cdr.detectChanges();
          //console.log(data);
          this.totalApproved = 0;
          this.totalRejected = 0;
          this.showSaveButton();
          this.showError = false;
          this.fileUpload.hide();
          var MID = this.StorageService.getCurrentUserMID();
          var locationID = this.StorageService.getCurrentUserLocationID();
          this.GetResourceMappingPendingList(MID, Number(locationID));
        });
      } else {
        this.fileValidation = validate.message;
      }
    };
    reader.readAsBinaryString(file);
  }
  selectApproveAll() {
    this.fpapprovaldetail.forEach((x) => {
      if (!x.validationRemarks &&  (x.firstName||x.remappedMID)) {
        x.isSelectedApproval = true;
        this.isapprovechecked = true;
        this.isrejectchecked = false;
        this.totalApproved = this.fpapprovaldetail.filter(
          (x) => !x.validationRemarks &&  (x.firstName||x.remappedMID)
        ).length;
      }
    });
    // this.totalApproved = [...this.fpapprovaldetail].length;
    this.totalRejected = 0;
    this.showSaveButton();
  }
  selectApprove(resources: FpResourceMapping) {
    const aIndex = this.fpapprovaldetail.findIndex(
      (item) => item === resources
    );
    if (aIndex !== -1) {
      this.totalApproved = this.totalApproved + 1;
      if (this.fpapprovaldetail[aIndex].isSelectedApproval != null) {
        this.totalRejected =
          this.totalRejected == 0 ? 0 : this.totalRejected - 1;
      }
      this.fpapprovaldetail[aIndex].isSelectedApproval = true; // Remove 1 element starting from the index
    }
    this.isapprovechecked = false;
    this.isrejectchecked = false;
    this.showSaveButton();
  }
  selectRejectAll() {

    this.fpapprovaldetail.forEach((x) => {
      if (x.fpintid !== null) {
        x.isSelectedApproval = false;
      }
    });
    this.totalApproved = 0;
    this.totalRejected = [...this.fpapprovaldetail].filter(
      (x) => x.isSelectedApproval == false
    ).length;

    this.isapprovechecked = false;
    this.isrejectchecked = true;
    this.showSaveButton();

  }
  //Click on SendBack
  selectReject(resources: FpResourceMapping) {
    const aIndex = this.fpapprovaldetail.findIndex(
      (item) => item === resources
    );
    if (aIndex !== -1) {
      if (this.fpapprovaldetail[aIndex].isSelectedApproval != null) {
        this.totalApproved =
          this.totalApproved == 0 ? 0 : this.totalApproved - 1;
      }
      this.totalRejected = this.totalRejected + 1;
      this.fpapprovaldetail[aIndex].isSelectedApproval = false;
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;
    this.showSaveButton();
  }

  submitResourceData() {
    // Check for invalid records without remarks
    const invalidRecord = this.fpapprovaldetail.find(
      (item) =>
        item.isSelectedApproval === false &&
        (item.remarks === '' || item.remarks === null)
    );

    if (invalidRecord) {
      this.inValidrecord = invalidRecord as FpResourceMapping;
      this.showError = true;
      return;
    } else {
      this.showError = false;
    }

    // Filter data for submission
    const filteredData = this.fpapprovaldetail.filter(
      (x) =>
        (x.fpintid !=null )&&
        (x.isSelectedApproval === true || x.isSelectedApproval === false)
    );

    if (filteredData.length > 0) {
      // Submit approval data
      this.ResourceOnboardingService.submitMonthlyApprovaldata(
        filteredData
      ).subscribe((result) => {
        //console.log(result);
        var MID = this.StorageService.getCurrentUserMID();
        var locationID = this.StorageService.getCurrentUserLocationID();
        this.cdr.detectChanges();
        this.totalApproved = 0;
        this.totalRejected = 0;
        this.showSaveButton();
        this.showError = false;
        this.fileUpload.hide();
        this.GetResourceMappingPendingList(MID, Number(locationID));
      });
    } else {
      //console.log('No mail sent. Filtered data count is not greater than 0.');
    }
  }

  SendMailToVendor() {
    var visiblerows = this.RMVisibleRows.filteredValue
      ? this.RMVisibleRows.filteredValue
      : this.fpapprovaldetail;

    const filteredData = visiblerows.filter(
      (x) => x.fpintid==null
    );

    if (filteredData.length > 0) {
      this.ResourceOnboardingService.sendFPOpenPositionsToVendor(
        filteredData
      ).subscribe((result) => {
        // Call GetResourceMappingPendingList inside the subscribe callback
        var MID = this.StorageService.getCurrentUserMID();
        var locationID = this.StorageService.getCurrentUserLocationID();
        this.GetResourceMappingPendingList(MID, Number(locationID));

      });
    } else {
      //console.log('No mail sent. Filtered data count is not greater than 0.');
    }
  }

  // GetFPWorkFlowData(fbcIntID: number,etwid:string) {
  //   debugger;
  //   this.showDialog();
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   this.wfheadertext= "Work Flow History - (ETWID:- "+ etwid+")",
  //   this.ResourceOnboardingService.GetFPmonthlyResourceWorkFlow(
  //     fbcIntID
  //   ).subscribe((result) => {
  //     //console.log(result);
  //     this.contractWorkFlow = result;
  //   });
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(etwid).subscribe((result) => {
  //     this.positionTrack = result;
  //   });
  // }

  showDialog() {
    this.dialogVisible = true;
  }
  deleteFpFromIntr(fpintid: number) {
    this.ResourceOnboardingService.DeleteIntrResourceFPmyldataById(
      fpintid
    ).subscribe((data) => {
      //console.log(data);
      this.cdr.detectChanges();
      this.totalApproved = 0;
      this.totalRejected = 0;
      this.showSaveButton();
      this.showError = false;
      this.fileUpload.hide();
      var MID = this.StorageService.getCurrentUserMID();
      var locationID = this.StorageService.getCurrentUserLocationID();
      this.GetResourceMappingPendingList(MID, Number(locationID));
    });
  }
 
  viewMonthlyDetails(etwid:number,SowNumber:string) {
    this.ref = this.DialogService.open(MonthlyDetailsDlgComponent, {
      header: 'Monthly Details -' + etwid,
      data: SowNumber,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      maximizable: true,
    });
  }
  GetFPWorkFlowData(data: FpResourceMapping) {
    debugger;
    //console.log('Data : ', data);
    var fpDatatofetch = {
      fbcid: data.fbcIntID,
      billingTypeName: data.billingType,
      contractTypeName: data.contractType,
      positionCode: data.etwid,
      etwid:data.etwid,
    };
    this.ref = this.DialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      // header: 'Work Flow History-'+data.etwid,
      data: fpDatatofetch,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
}
