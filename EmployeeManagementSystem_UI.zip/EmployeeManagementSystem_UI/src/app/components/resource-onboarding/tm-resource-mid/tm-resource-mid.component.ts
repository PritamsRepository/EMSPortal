import { Component, OnInit } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ResourceBasicDts } from 'src/app/core/interfaces/resource-basic-dts';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { TmWorkflowComponent } from '../../tm-view/tm-workflow/tm-workflow.component';

@Component({
  selector: 'app-tm-resource-mid',
  templateUrl: './tm-resource-mid.component.html',
  styleUrls: ['./tm-resource-mid.component.css'],
  providers: [DialogService],
})
export class TmResourceMidComponent implements OnInit {
  pageTitle: string = 'T&M - MID Pending Requests';
  contractlistTrack!: ResourceTrack[];
  contractWorkFlow!: ResourceWorkflow[];
  resources!: ResourceTrack[];
  data: any[] = [];
  Workflowdialog: boolean = false;
  MIDdialog: boolean = false;
  AssetsRequired!: boolean;
  Email!: string;
  MID!: string;
  visible: boolean = false;
  // Error: boolean = true;
  midemailError: boolean = true;
  validationMessage!: string;
  Assets!: string;
  RMID!: number;
  TMVCMID!: number;
  positionTrack!: ResourceTrack[];
  wfheadertext: string = 'Work Flow History';
  ref!: DynamicDialogRef;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    public StorageService: StorageService,
    public dialogService: DialogService
  ) {}
  ngOnInit() {
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    this.GetResourceMIDcreationPendingList(MID, Number(locationID));
  }
  GetResourceMIDcreationPendingList(UserName: string, LocationID: number) {
    this.ResourceOnboardingService.GetResourceMIDcreationPendingList(
      UserName,
      LocationID
    ).subscribe((result) => {
      //console.log(result);
      this.contractlistTrack = result;
    });
  }
  // GetTMWorkFlowData(tmvcmid: number, positionCode: string,etwid: number) {
  //   this.showDialog();
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   this.wfheadertext= "Work Flow History - (ETWID:- "+ etwid+")",
  //   this.ResourceOnboardingService.GetTMResourceWorkFlow(tmvcmid).subscribe(
  //     (result) => {
  //       this.contractWorkFlow = result;
  //     }
  //   );
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(positionCode).subscribe((result) => {
  //     this.positionTrack = result;
  //   });

  // }

  viewTmWorkFlow(data: any) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History  - (ETWID : ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  GetMIDData(rmid: number, tmvcmid: number) {
    this.resources = this.contractlistTrack.filter((x) => x.tmvcmid == tmvcmid);
    this.RMID = rmid;
    this.TMVCMID = tmvcmid;
    this.showMIDDialog();
  }
  showDialog() {
    this.Workflowdialog = true;
  }
  showMIDDialog() {
    this.MIDdialog = true;
    this.MID = null;
    this.Email = null;
    // this.Error = true;
    this.midemailError = true;
  }
  IsAssetClicked(event: Event) {
    this.visible = this.AssetsRequired;
  }
  SearchDataAD() {
    if (this.MID != null) {
      this.ResourceOnboardingService.SearchDataFromAd(this.MID).subscribe(
        (valiedata: string) => {
          if (valiedata != null) {
            this.Email = valiedata;
            this.midemailError = true;
          } else {
            this.validationMessage = '';
            this.validationMessage =
              "Note : MID does't exist, you can still save the data.";
            this.midemailError = false;
          }
        }
      );
    }
  }
  SaveData() {
    if (this.MID == null || this.Email == null) {
      this.validationMessage = '';
      this.validationMessage = 'Note : Please fill all required fields.';
      this.midemailError = false;
    } else {
      this.midemailError = true;
      const rtype = {} as ResourceBasicDts;
      rtype.mid = this.MID;
      rtype.email = this.Email;
      rtype.rmid = this.RMID;
      rtype.cmid = this.TMVCMID;
      var MID = this.StorageService.getCurrentUserMID();
      var locationID = this.StorageService.getCurrentUserLocationID();
      this.ResourceOnboardingService.SaveResourceAssetDetails(rtype).subscribe(
        (valiedata: string) => {
          if (valiedata == null) {
            this.midemailError = true;
            this.GetResourceMIDcreationPendingList(MID, Number(locationID));
            this.MIDdialog = false;
          } else {
            this.validationMessage = '';
            this.validationMessage = valiedata;
            // this.validationMessage="Note : MID/Email ID already exist, Please provide correct MID/Email ID.";
            this.midemailError = false;
          }
        }
      );
    }
  }
}
