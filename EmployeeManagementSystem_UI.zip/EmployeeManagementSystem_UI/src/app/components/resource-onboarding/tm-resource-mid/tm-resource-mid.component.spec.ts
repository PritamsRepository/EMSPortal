import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmResourceMidComponent } from './tm-resource-mid.component';

describe('TmResourceMidComponent', () => {
  let component: TmResourceMidComponent;
  let fixture: ComponentFixture<TmResourceMidComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmResourceMidComponent]
    });
    fixture = TestBed.createComponent(TmResourceMidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
