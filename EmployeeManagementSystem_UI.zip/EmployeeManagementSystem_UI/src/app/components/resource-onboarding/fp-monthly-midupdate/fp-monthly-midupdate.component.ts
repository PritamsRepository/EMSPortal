import { Component, OnInit } from '@angular/core';
import { ResourceBasicDts } from 'src/app/core/interfaces/resource-basic-dts';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MonthlyDetailsDlgComponent } from '../monthly-details-dlg/monthly-details-dlg.component';
import { FpWorkflowComponent } from '../../fp-view/fp-workflow/fp-workflow.component';
@Component({
  selector: 'app-fp-monthly-midupdate',
  templateUrl: './fp-monthly-midupdate.component.html',
  styleUrls: ['./fp-monthly-midupdate.component.css'],
  providers: [DialogService],
})
export class FpMonthlyMIDUpdateComponent implements OnInit {
  pageTitle: string = 'Fixed price Monthly - MID Update Pending Requests';
  contractlistTrack!: ResourceTrack[];
  contractWorkFlow!: ResourceWorkflow[];
  resources!: ResourceTrack[];
  data: any[] = [];
  Workflowdialog: boolean = false;
  MIDdialog: boolean = false;
  AssetsRequired!: boolean;
  Email!: string;
  MID!: string;
  visible: boolean = false;
  // Error: boolean = true;
  midemailError: boolean = true;
  validationMessage!:string;
  Assets!: string;
  RMID!: number;
  CMID!: number;
  fbcIntID!:number;
  positionTrack!:ResourceTrack[];
  wfheadertext:string="Work Flow History";
  ref: DynamicDialogRef | undefined;
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    public StorageService: StorageService,
    private DialogService: DialogService,
  ) {}
  ngOnInit() {
    var MID = this.StorageService.getCurrentUserMID();
    var locationID = this.StorageService.getCurrentUserLocationID();
    this.GetResourceMIDcreationPendingList(MID, Number(locationID));
  }
  GetResourceMIDcreationPendingList(UserName: string, LocationID: number) {
    this.ResourceOnboardingService.GetMonthlyMIDcreationPendingList(
      UserName,
      LocationID
    ).subscribe((result) => {
      //console.log(result);
      this.contractlistTrack = result;
    });
  }
  // GetFPWorkFlowData(cmid: number,etwid:string) {
  //   this.showDialog();
  //   this.wfheadertext= "Work Flow History - (ETWID:- "+ etwid+")",
  //   // this.wfheadertext="Work Flow History-" + etwid;
  //   this.ResourceOnboardingService.GetFPmonthlyResourceWorkFlow(cmid).subscribe(
  //     (result) => {
  //       //console.log(result);
  //       this.contractWorkFlow = result;
  //     }
  //   );
  //   this.ResourceOnboardingService.GetTMmultiRcrsByPsCode(etwid).subscribe((result) => {
  //     this.positionTrack = result;
  //   });
  // }
  GetMIDData(rmid: number, fbcIntID: number) {
    this.resources = this.contractlistTrack.filter((x) => x.fbcIntID == fbcIntID);
    this.RMID = rmid;
    this.fbcIntID = fbcIntID;
    this.showMIDDialog();
  }
  showDialog() {
    this.Workflowdialog = true;
  }
  showMIDDialog() {
    this.MIDdialog = true;
    this.MID = null;
    this.Email = null;
    // this.Error = true;
    this.midemailError = true;
  }
  IsAssetClicked(event: Event) {
    this.visible = this.AssetsRequired;
  }
  SearchDataAD()
  {
    debugger;
    if(this.MID!=null)
    {
    this.ResourceOnboardingService.SearchDataFromAd(this.MID).subscribe(
      (valiedata: string) => {
        if (valiedata!=null) {
          this.Email=valiedata;
          this.midemailError = true;
        } else {
          this.validationMessage="";
          this.validationMessage="Note : MID does't exist, you can still save the data.";
          this.midemailError = false;
        }
      }
    );
    }
  }
  SaveData() {
    if (this.MID == null || this.Email == null) {
      this.validationMessage="";
      this.validationMessage="Note : Please fill all required fields.";
      this.midemailError=false;
    } else {
      this.midemailError=true;
      const rtype = {} as ResourceBasicDts;
      rtype.mid = this.MID;
      rtype.email = this.Email;
      rtype.rmid = this.RMID;
      rtype.cmid = this.fbcIntID;
      var MID = this.StorageService.getCurrentUserMID();
      var locationID = this.StorageService.getCurrentUserLocationID();
      this.ResourceOnboardingService.SaveMonthlyResourceAssetDetails(
        rtype
      ).subscribe((valiedata: string) => {
        if (valiedata==null) {
          this.midemailError = true;
          this.GetResourceMIDcreationPendingList(MID, Number(locationID));
          this.MIDdialog = false;
        } else {
          this.validationMessage="";
          this.validationMessage=valiedata;
          // this.validationMessage="Note : MID/Email ID already exist, Please provide correct MID/Email ID.";
          this.midemailError = false;
        }
      });
    }
  }
  viewMonthlyDetails(etwid:number,SowNumber:string) {
    this.ref = this.DialogService.open(MonthlyDetailsDlgComponent, {
      header: 'Monthly Details -' + etwid,
      data: SowNumber,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      maximizable: true,
    });
  }
  GetFPWorkFlowData(data: ResourceTrack) {
    debugger;
    //console.log('Data : ', data);
    var fpDatatofetch = {
      fbcid: data.fbcIntID,
      billingTypeName: data.billingType,
      contractTypeName: data.contractType,
      positionCode: data.etwid,
      etwid:data.etwid,
    };
    this.ref = this.DialogService.open(FpWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      // header: 'Work Flow History-'+data.etwid,
      data: fpDatatofetch,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }
}
