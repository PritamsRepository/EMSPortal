import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpMonthlyMIDUpdateComponent } from './fp-monthly-midupdate.component';

describe('FpMonthlyMIDUpdateComponent', () => {
  let component: FpMonthlyMIDUpdateComponent;
  let fixture: ComponentFixture<FpMonthlyMIDUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpMonthlyMIDUpdateComponent]
    });
    fixture = TestBed.createComponent(FpMonthlyMIDUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
