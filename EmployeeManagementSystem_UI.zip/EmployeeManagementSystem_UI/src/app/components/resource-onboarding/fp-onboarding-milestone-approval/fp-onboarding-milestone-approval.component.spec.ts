import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpOnboardingMilestoneApprovalComponent } from './fp-onboarding-milestone-approval.component';

describe('FpOnboardingMilestoneApprovalComponent', () => {
  let component: FpOnboardingMilestoneApprovalComponent;
  let fixture: ComponentFixture<FpOnboardingMilestoneApprovalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpOnboardingMilestoneApprovalComponent]
    });
    fixture = TestBed.createComponent(FpOnboardingMilestoneApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
