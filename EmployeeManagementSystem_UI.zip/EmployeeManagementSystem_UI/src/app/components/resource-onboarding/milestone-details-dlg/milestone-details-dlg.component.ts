import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MilestoneDetails } from 'src/app/core/interfaces/milestone-details';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';

@Component({
  selector: 'app-milestone-details-dlg',
  templateUrl: './milestone-details-dlg.component.html',
  styleUrls: ['./milestone-details-dlg.component.css'],
  providers: [DynamicDialogRef],
})
export class MilestoneDetailsDlgComponent implements OnInit {
  MilestoneDetails!: MilestoneDetails[];
  constructor(
    private readonly _ref: DynamicDialogRef,
    private readonly _config: DynamicDialogConfig,
    private readonly ResourceOnboardingService: ResourceOnboardingService
  ) {}
  ngOnInit() {
    debugger;
    this.ResourceOnboardingService.GetMilestoneDetailsBySowNum(

      this._config.data
    ).subscribe((result) => {
      //console.log(result);
      this.MilestoneDetails = result;
    });
  }
}


