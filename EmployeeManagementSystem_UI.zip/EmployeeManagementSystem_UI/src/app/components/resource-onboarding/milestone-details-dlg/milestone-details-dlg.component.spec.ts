import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneDetailsDlgComponent } from './milestone-details-dlg.component';

describe('MilestoneDetailsDlgComponent', () => {
  let component: MilestoneDetailsDlgComponent;
  let fixture: ComponentFixture<MilestoneDetailsDlgComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MilestoneDetailsDlgComponent]
    });
    fixture = TestBed.createComponent(MilestoneDetailsDlgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
