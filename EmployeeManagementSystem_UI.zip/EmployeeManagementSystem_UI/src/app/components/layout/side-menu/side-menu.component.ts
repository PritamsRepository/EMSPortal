import { Component, OnInit } from '@angular/core';
import { Data } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';
import { SharedService } from 'src/app/core/services/shared.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { DefinedRoles } from 'src/app/core/utiltz/DefinedRolesList';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css'],
})
export class SideMenuComponent implements OnInit {
  constructor(
    private AuthService: AuthenticationService,
    private sharedService: SharedService,
    private storageService: StorageService
  ) {
    this.sideMenuItems = this.buildMenu();
  }
  sideMenuItems: MenuItem[] | undefined;
  sidebarVisible: boolean = false;
  collapsed: boolean = false;

  ngOnInit() {}

  buildMenu(): any[] {
    const MenuItems: any[] = [
      {
        label: 'Procurement',
        icon: '',
        expanded: true,
        visible: this.AuthService.hasRoles([
          DefinedRoles.Super_Admin,
          DefinedRoles.PMO_Contract_Mgm,
        ]),
        items: [
          {
            label:
              '<b class="customeMenuItemText">Time & Material Contracts</b>',
            escape: false,
            expanded: true,
            icon: '',
            items: [
              {
                label: 'T&M Contract Upload',
                icon: 'fa-solid fa-arrow-up-from-bracket',
                routerLink: ['/main/tmupload'],
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Track T&M Contract',
                icon: 'fa-regular fa-rectangle-list',
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),

                routerLink: ['/main/tmContractDetails'],

                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Pending for Action',
                icon: 'fa-solid fa-rotate-left',
                routerLink: ['/main/tmSendbackDetails'],
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),
                command: () => {
                  this.hideSidebar();
                },
              },
            ],
          },
          { separator: true },
          {
            label: '<b class="customeMenuItemText">Fixed Price Contracts</b>',
            escape: false,
            icon: '',
            expanded: true,
            items: [
              {
                label: 'FP Contract Upload',
                icon: 'fa-solid fa-arrow-up-from-bracket',
                routerLink: ['/main/fpmenu'],
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Track FP Contract',
                icon: 'fa-regular fa-rectangle-list',
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),
                routerLink: ['/main/fpContractDetails'],
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Pending for Action',
                icon: 'fa-solid fa-rotate-left',
                routerLink: ['/main/fpSendbackDetails'],
                visible: this.AuthService.hasRoles([
                  DefinedRoles.PMO_Contract_Mgm,
                ]),
                command: () => {
                  this.hideSidebar();
                },
              },
            ],
          },
        ],
      },

      {
        label: 'Masters',
        icon: '',
        expanded: true,
        visible: this.AuthService.hasRoles([
          DefinedRoles.Super_Admin,
          DefinedRoles.Admin,
        ]),
        items: [
          {
            label: 'Role Mapping',
            icon: 'fa-solid fa-id-badge',
            routerLink: ['main/rolemapping'],
            command: () => {
              this.hideSidebar();
            },
          },
          // {
          //   label: 'AMS Masters',
          //   icon: '',
          //   expanded: true,
          //   items: [
          //     {
          //       label: 'Vendor Master',
          //       icon: 'fa-solid fa-users-gear',
          //       routerLink: [
          //         'main/amsmaster',
          //         `${environment.AMS_URL}?RedirectPage=` +
          //           btoa('VendorMaster.aspx') +
          //           `&EMS_MID=` +
          //           this.storageService.getCurrentUserMID(),
          //       ],
          //       // skipLocationChange:true,
          //       command: () => {
          //         this.hideSidebar();
          //       },
          //     },
          //     {
          //       label: 'Tower Lead Master',
          //       icon: 'fa-solid fa-tower-cell',
          //       // routerLink: [
          //       //   'main/amsmaster',
          //       //   `${environment.AMS_URL}?RedirectPage=`+btoa('towerleadmaster.aspx')+`&EMS_MID=` +
          //       //     this.storageService.getCurrentUserMID(),
          //       // ],
          //       routerLink: [
          //         'main/amsmaster',
          //         `${environment.AMS_URL}?RedirectPage=` +
          //           btoa('towerleadmaster.aspx'),
          //       ],
          //       // skipLocationChange:true,
          //       command: () => {
          //         this.hideSidebar();
          //       },
          //     },
          //     {
          //       label: 'Tower Master',
          //       icon: 'fa-solid fa-gopuram',
          //       routerLink: [
          //         'main/amsmaster',
          //         `${environment.AMS_URL}?RedirectPage=` +
          //           btoa('FunctionsMaster.aspx'),
          //       ],
          //       // skipLocationChange:true,
          //       command: () => {
          //         this.hideSidebar();
          //       },
          //     },
          //     {
          //       label: 'Role Master',
          //       icon: 'fa-solid fa-ranking-star',
          //       routerLink: [
          //         'main/amsmaster',
          //         `${environment.AMS_URL}?RedirectPage=` +
          //           btoa('RoleMaster.aspx'),
          //       ],
          //       // skipLocationChange:true,
          //       command: () => {
          //         this.hideSidebar();
          //       },
          //     },
          //     {
          //       label: 'Mapping Master',
          //       icon: 'fa-solid fa-sitemap',
          //       routerLink: [
          //         'main/amsmaster',
          //         `${environment.AMS_URL}?RedirectPage=` +
          //           btoa('MappingMaster.aspx'),
          //       ],
          //       // skipLocationChange:true,
          //       command: () => {
          //         this.hideSidebar();
          //       },
          //     },
          //   ],
          // },
        ],
      },
      {
        label: 'IT Finance Manager',
        icon: '',
        expanded: true,
        visible: this.AuthService.hasRoles([
          DefinedRoles.Super_Admin,
          DefinedRoles.IT_Finance_Manager,
        ]),
        items: [
          {
            label: 'Bulk Update Contracts',
            icon: 'fa-solid fa-list-check',
            routerLink: ['/main/tmBulkUpdate'],
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label:
              '<b class="customeMenuItemText">Time & Material Contracts<b/>',
            escape: false,
            icon: '',
            expanded: true,
            items: [
              {
                label: 'T&M Contract Approval',
                icon: 'fa-solid fa-file-signature',
                routerLink: ['/main/tmApproval'],
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Track T&M Contract',
                icon: 'fa-regular fa-rectangle-list',
                routerLink: ['/main/tmTrack'],
                command: () => {
                  this.hideSidebar();
                },
              },
              
            ],
          },
          { separator: true },
          {
            label: '<b class="customeMenuItemText">Fixed Price Contracts</b>',
            escape: false,
            icon: '',
            expanded: true,
            items: [
              {
                label: 'FP Contract Approval',
                icon: 'fa-solid fa-file-signature',
                routerLink: ['/main/fpapprovalmilestone'],
                command: () => {
                  this.hideSidebar();
                },
                //url:'fpapprovalmenu'
              },
              {
                label: 'Track FP Contract',
                icon: 'fa-regular fa-rectangle-list',
                routerLink: ['/main/fptrackmilestone'],
                command: () => {
                  this.hideSidebar();
                },
                //url:'fpapprovalmenu'
              },
            ],
          },
        ],
      },

      {
        label: 'Resource Management',
        icon: '',
        expanded: true,
        visible: this.AuthService.hasRoles([
          DefinedRoles.Super_Admin,
          DefinedRoles.PMO_Admin,
        ]),
        items: [
          {
            label:
              '<b class="customeMenuItemText">Time & Material Contracts</b>',
            escape: false,
            icon: '',
            expanded: true,
            items: [
              {
                label: 'T&M Resource Mapping',
                icon: 'fa-solid fa-circle-nodes',
                routerLink: ['/main/vendorContractList'],
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'T&M Resource MID/Email Update',
                icon: 'fa-solid fa-user-pen',
                routerLink: ['/main/tmResourceMid'],
                command: () => {
                  this.hideSidebar();
                },

                //url:'fpapprovalmenu'
              },
              {
                label: 'Track T&M Contract',
                icon: 'fa-regular fa-rectangle-list',
                routerLink: ['/main/tmonboardingtrack'],
                command: () => {
                  this.hideSidebar();
                },
              },
            ],
          },
          { separator: true },
          {
            label: '<b class="customeMenuItemText">Fixed Price Contracts<b/>',
            escape: false,
            icon: '',
            expanded: true,
            items: [
              {
                label: 'FP Resource Mapping',
                icon: 'fa-solid fa-circle-nodes',
                routerLink: ['/main/fpOnboardMilestoneApproval'],
                command: () => {
                  this.hideSidebar();
                },
                //url:'fpapprovalmenu'
              },
              {
                label: 'FP Resource MID/Email Update',
                icon: 'fa-solid fa-user-pen',
                routerLink: ['/main/fpMilestoneMid'],
                command: () => {
                  this.hideSidebar();
                },
              },
              {
                label: 'Track FP Contract',
                icon: 'fa-regular fa-rectangle-list',
                routerLink: ['/main/fpRsrcMlstneTrk'],
                command: () => {
                  this.hideSidebar();
                },
                //url:'fpapprovalmenu'
              },
            ],
          },
        ],
      },

      {
        label: 'Reports',
        icon: '',
        expanded: true,
        // visible: this.AuthService.hasRoles([
        //   DefinedRoles.Report_Access,
        //   DefinedRoles.PMO_Contract_Mgm,
        // ]),
        items: [
          {
            label: 'Renewal dashboard ',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/renewalDashboard'],
            visible: this.AuthService.hasRoles([
              DefinedRoles.PMO_Contract_Mgm,
              DefinedRoles.IT_Finance_Manager,
              DefinedRoles.Report_Access,
            ]),
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Create Open-Position Report Domain-wise',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/contractSummaryReportTowerHeadAndDomain'],
            visible: this.AuthService.hasRoles([
              DefinedRoles.PMO_Admin,
            ]),
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Open-Position Report Domain-wise',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/PublishedcontractSummaryReportTowerHeadAndDomain'],
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Open-Position Report Tower-wise',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/contractSummaryReportTowerHead'],
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Open-Position Report SOWName-Wise',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/contractSummaryReportProject'],
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Open-Position Report Vendor-wise',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/contractDetailReport'],
            command: () => {
              this.hideSidebar();
            },
          },
          {
            label: 'Employee Master',
            icon: 'fa-solid fa-chart-pie',
            routerLink: ['/main/employeeMasterDetailReport'],
            command: () => {
              this.hideSidebar();
            },
            
          },
        ],
      },

      {
        label: 'Applications',
        icon: '',
        expanded: true,
        items: [
          {
            label: 'AMS',
            icon: 'fa-solid fa-person-walking-dashed-line-arrow-right',
            // routerLink: ['main/amsmaster', `${environment.AMS_URL}`],
            // command: () => {
            //   this.hideSidebar();
            // },
            command: () => {
              window.open(`${environment.AMS_URL}`, '_blank');
              this.hideSidebar();
            },
          },
          {
            label: 'eSeparation',
            icon: 'fa-solid fa-people-arrows',
            // routerLink: ['main/amsmaster', `${environment.ESep_URL}`],
            // command: () => {
            //   this.hideSidebar();
            // },
            command: () => {
              window.open(`${environment.ESep_URL}`, '_blank');
              this.hideSidebar();
            },
          },
        ],
      },
    ];

    return MenuItems;
  }

  // Call this method when you want to hide the sidebar
  hideSidebar(): void {
    this.sharedService.setSidebarVisible(false);
  }
}
