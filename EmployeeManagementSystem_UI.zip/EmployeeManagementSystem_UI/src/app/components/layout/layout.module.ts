import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { HeaderComponent } from './header/header.component';
import { MainComponent } from './main/main.component';
import { RouterModule } from '@angular/router';
import { HttpClientJsonpModule, HttpClientModule } from '@angular/common/http';
import { PrimengModule } from 'src/app/primeng.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [SideMenuComponent, MainComponent, HeaderComponent],
  exports: [SideMenuComponent, MainComponent, HeaderComponent],
  imports: [
    CommonModule,
    RouterModule,
    HttpClientModule,
    HttpClientJsonpModule,
    PrimengModule,
    ReactiveFormsModule,
  ],
})
export class LayoutModule {}
