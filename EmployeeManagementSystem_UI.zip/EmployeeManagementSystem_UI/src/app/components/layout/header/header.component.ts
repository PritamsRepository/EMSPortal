import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivationStart, NavigationEnd, Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { SharedService } from 'src/app/core/services/shared.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { filter, startWith } from 'rxjs/operators';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from '@angular/forms';
import {
  ILocation,
  IRole,
  IUpdatePreference,
} from 'src/app/core/interfaces/irole-location-preferences';
import { Dialog } from 'primeng/dialog';
import { Time } from '@angular/common';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';
// interface location {
//   locationId: number;
//   locationName: string;
// }

// interface roles {
//   roleMasterId: string;
//   roleType: string;
// }

// interface UpdatePreference {
//   LocationId: number;
//   RoleMasterId: Number;
// }

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [MessageService],
})
export class HeaderComponent implements OnInit {
  @ViewChild('locationChanger') locationChanger!: Dialog;
  visible: boolean = false;
  sidebarVisible: boolean = false;
  userItems: MenuItem[] | undefined;
  userName!: string;
  locationsData!: ILocation[];
  rolesData!: any[];
  selectedLocation: any;
  selectedRole: any;
  locationFormGroup!: FormGroup<any>;
  roles!: IRole[];
  userID: string;

  AssignedRoles: string = 'AssignedRoles';
  loading: boolean = false;
  expiryTime: Date;

  constructor(
    private readonly _router: Router,
    private messageService: MessageService,
    private storageService: StorageService,
    private sharedService: SharedService,
    private locoForm: FormBuilder,
    private readonly _authentication: AuthenticationService
  ) {
    this.sharedService.sidebarVisible$.subscribe((visible) => {
      this.sidebarVisible = visible;
    });
    this._router.events.subscribe((data) => {
      if (data instanceof ActivationStart) {
        //this.componentTitle = data.snapshot.data['title']
      }
    });
    this._router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      startWith(this._router)
    );

    this.locationFormGroup = this.locoForm.group({
      selectedLocation: [
        { value: null, disabled: false },
        [Validators.required],
      ],
      selectedRole: [{ value: null, disabled: true }, [Validators.required]],
    });
  }

  ngOnInit() {
    this.userName = this.storageService.getUser().displayName;

    // this.locationFormGroup = this.locoForm.group({
    //   selectedLocation: new FormControl({
    //     value: null,
    //     disabled: false,
    //   }),
    //   selectedRole: new FormControl({
    //     value: null,
    //     disabled: true,
    //   }), // Disable initially
    // });

    // Listen for changes in the "selectedLocation" control
    this.locationFormGroup
      .get('selectedLocation')
      .valueChanges.subscribe((selectedLocation) => {
        // Enable/disable the "selectedRole" control based on the selectedLocation
        const roleControl = this.locationFormGroup.get('selectedRole');
        if (selectedLocation) {
          this.updateRoles(
            parseInt(this.storageService.getCurrentUserLocationID())
          );
          roleControl.enable();
        } else {
          roleControl.disable();
        }
      });

    this.userName = this.storageService.getUser().displayName;
    this.userID = this.storageService.getCurrentUserMID();
    //console.log(this.userID);

    this.sharedService.setupLocationAndRoles(this.userID).subscribe({
      next: (result) => {
        //console.log('LocationWithRoles : ', result);

        this.locationsData = result.userLocation;
        this.rolesData = result.userRoles;
        this.roles = this.rolesData.map((role: any) => {
          const { locationId, roleMasterId, roleType } = role;
          return { locationId, roleMasterId, roleType };
        });
        //console.log('Location : ', this.locationsData);
        //console.log('Roles : ', this.roles);

        window.sessionStorage.removeItem(this.AssignedRoles);
        window.sessionStorage.setItem(
          this.AssignedRoles,
          JSON.stringify(this.roles)
        );

        this.assignLocationAndRoles(this.locationsData, this.roles);
        this.storageService.navigateBasedOnRole();
      },
      error: (err) => {
        //console.log(err);
      },
    });

    this.expiryTime = new Date(this.storageService.getExpirtTime());
  }

  downloadUserManual() {
    this.messageService.add({
      severity: 'success',
      summary: 'Download Started',
      detail: 'User manual successfully downloaded.',
    });
  }

  logout() {
    this._authentication.logout().subscribe();
    this._router.navigate(['/main/logout']);
    this.messageService.add({
      severity: 'error',
      summary: 'Bye!',
      detail: 'You have been successfully logged out.',
    });
  }

  showDialog() {
    this.visible = true;
    //alert(this.storageService.getCurrentUserLocationID());

    this.locationFormGroup.patchValue({
      selectedLocation: parseInt(
        this.storageService.getCurrentUserLocationID()
      ),
      selectedRole: parseInt(this.storageService.getCurrentUserRoleMasterID()),
    });
    //this.updateRoles(parseInt(this.storageService.getCurrentUserLocationID()));
  }
  checkForlocation(event: boolean) {
    //console.log('EVENT : ', event);
    const locId = this.storageService.getCurrentUserLocationID();
    const rolId = this.storageService.getCurrentUserRoleMasterID();

    if (event == false && locId === '0' && rolId === '0') {
      // Open the dialog box
      this.visible = true;
      //console.log('Opening dialog box');
    }
  }

  assignLocationAndRoles(locs: ILocation[], roles: IRole[]) {
    const locId = this.storageService.getCurrentUserLocationID();
    const rolId = this.storageService.getCurrentUserRoleMasterID();

    //console.log('locId : ', locId);
    //console.log('rolId : ', rolId);
    if (locId === '0' && rolId === '0') {
      // Open the dialog box
      this.visible = true;
      //console.log('Opening dialog box');
    } else {
      // Find the selected location and role based on the IDs
      const selectedLocation = locs.find(
        (item) => item.locationId.toString() === locId
      );
      const selectedRole = roles.find(
        (item) => item.roleMasterId.toString() === rolId
      );

      // If a location and role are found, update the properties
      if (selectedLocation) {
        this.selectedLocation = selectedLocation.locationName.replace(',', '');

        // this.locationFormGroup
        //   .get('selectedLocation')
        //   .setValue(this.selectedLocation);
      }

      if (selectedRole) {
        this.selectedRole = selectedRole.roleType.replace(',', '');
        // this.locationFormGroup.get('selectedRole').setValue(this.selectedRole);
      }
    }
  }

  updateRoles(locId: any) {
    this.roles = this.rolesData
      .filter((role: any) => role.locationId === locId)
      .map((role: any) => {
        const { locationId, roleMasterId, roleType } = role;

        return { locationId, roleMasterId, roleType };
      });

    // //console.log('Avail Roles : ', this.rolesData);
    // //console.log('Updated Roles : ', this.roles);
    return this.roles;
  }

  // assignRoleValue(locId: any) {
  //   this.selectedRole = parseInt(
  //     this.storageService.getCurrentUserRoleMasterID()
  //   );
  // }

  onPreferenceSubmit() {
    this.loading = true;
    // Open the dialog box
    //this.visible = false;
    //console.log('Closing dialog box');

    //console.log(this.locationFormGroup.valid);
    //console.log(this.locationFormGroup.value);

    const Data = this.locationFormGroup.value;
    const selectedLocation = Data.selectedLocation;
    const selectedRole = Data.selectedRole;

    const prefData = {} as IUpdatePreference;

    prefData.locationId = selectedLocation;
    prefData.roleMasterId = selectedRole;
    prefData.userId = this.userID;

    //console.log('pref : ', prefData);

    if (this.locationFormGroup.valid) {
      this.sharedService.UpdatePreferenceAndReload(prefData).subscribe({
        next: (data) => {
          //console.log('Preference : ', data);
          const l = data.locationId;
          const r = data.roleMasterId;
          this.storageService.updateLocationandRole(l, r);
        },
        error: (err) => {
          this.loading = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: '',
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });
    } else {
    }
  }

  goToHome() {
    this.storageService.navigateBasedOnRole();
  }
}
