import { Component, OnInit } from '@angular/core';
import { AutoLogoutService } from 'src/app/core/services/auto-logout/auto-logout.service';
import { SharedService } from 'src/app/core/services/shared.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
  providers: [AutoLogoutService],
})
export class MainComponent implements OnInit {
  constructor(
    private readonly _sharedService: SharedService,
    private readonly _storageService: StorageService,
    private readonly _autoLogoutService: AutoLogoutService
  ) {}
  ngOnInit() {
    // const userID = this._storageService.getCurrentUserMID();
    // //console.log(userID);
    // this._sharedService.setupLocationAndRoles(userID).subscribe();
  }
}
