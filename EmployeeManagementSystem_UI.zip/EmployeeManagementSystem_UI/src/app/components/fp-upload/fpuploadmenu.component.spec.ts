import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpuploadmenuComponent } from './fpuploadmenu.component';

describe('FpuploadmenuComponent', () => {
  let component: FpuploadmenuComponent;
  let fixture: ComponentFixture<FpuploadmenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpuploadmenuComponent]
    });
    fixture = TestBed.createComponent(FpuploadmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
