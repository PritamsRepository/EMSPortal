import { ApplicationRef, Component, OnInit, ViewChild } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ifpUpload } from 'src/app/core/interfaces/ifpupload';
import {
  FileSelectEvent,
  FileSendEvent,
  FileUploadErrorEvent,
  UploadEvent,
} from 'primeng/fileupload';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import * as XLSX from 'xlsx';
import { fileDownload } from 'src/app/core/services/fileDownload.service';
import { DatePipe } from '@angular/common';
import * as FileSaver from 'file-saver';
import { OverlayPanel } from 'primeng/overlaypanel';

@Component({
  selector: 'app-fpuploadcontract',
  templateUrl: './fpuploadcontract.component.html',
  styleUrls: ['./fpuploadcontract.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class FpuploadcontractComponent {
  selectedRows: any[] = [];
  constructor(
    private fpUploadService: FpUploadService,
    private messageService: MessageService,
    private excelFileValidationService: excelFileValidation,
    private tempDownloadService: fileDownload,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    private router: Router,
    private appRef: ApplicationRef
  ) {}
  @ViewChild('fileUpload') fileUpload!: OverlayPanel;

  sortField = 'ValidationRemarks';
  sortOrder = -1;
  uploadUrl: string = `${environment.API_URL}/Contracts/FPContractUpload`;
  gridTitle: string = 'Fixed Price Contracts Upload';
  fileValidation: string = '';
  fpUploads!: ifpUpload[];
  invalidDetails!: ifpUpload[] | null;
  showUploadButton: boolean = false;
  fpUpload!: ifpUpload;
  selectedItems: any[] = [];
  cols!: any[];
  selectedDetails!: ifpUpload[];
  deleteFpUploadDetailDialog: boolean = false;
  ref: DynamicDialogRef | undefined;
  selectedFiles: any;
  expectedColumns: string[] = [
    'fbcIntID',
    'etwid',
    'vendorName',
    'positionLocation',
    'oldSowNumber',
    'sowNumber',
    'sowName',
    'sowStartDate',
    'sowEndDate',
    'amortizationStartMonth',
    'amortizationEndMonth',
    'poNumber',
    'poStartDate',
    'poEndDate',
    'ppmProjectID',
    'ppmProjectName',
    'wbsDetail',
    'vertical',
    'tower',
    'domainLeadEmail',
    'costCenter',
    'obs',
    'domainSkillName',
    'skillSet',
    'domainSkillStartDate',
    'domainSkillEndDate',
    'projectOrRun',
    'contractType',
    'billingType',
    'remappedMID',
    // 'validationRemarks'
  ];

  ngOnInit() {
    this.getFpContractIntermediateDetails();

    this.cols = [
      { field: 'fbcIntID', header: 'fbcIntID' },
      { field: 'etwid', header: 'ETW ID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'positionLocation', header: 'Managing Team' },
      { field: 'billingType', header: 'Billing Type' },
      { field: 'oldSowNumber', header: 'Old Sow Number' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      {
        field: 'sowStartDate',
        header: 'SOW Start Date',
        format: 'dd-MMM-yyyy',
      },
      { field: 'sowEndDate', header: 'SOW End Date', format: 'dd-MMM-yyyy' },
      {
        field: 'amortizationStartMonth',
        header: 'Amortization Starting From',
        format: 'dd-MMM-yyyy',
      },
      {
        field: 'amortizationEndMonth',
        header: 'Amortization Ending On',
        format: 'dd-MMM-yyyy',
      },
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date', format: 'dd-MMM-yyyy' },
      { field: 'poEndDate', header: 'PO End Date', format: 'dd-MMM-yyyy' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'wbsDetail', header: 'SAP Code' },
      { field: 'vertical', header: 'Vertical' },
      { field: 'tower', header: 'Tower' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'costCenter', header: 'Cost Center' },
      { field: 'obs', header: 'OBS' },
      { field: 'domainSkillName', header: 'Domain Skill Name' },
      { field: 'skillSet', header: 'Skill Set' },
      {
        field: 'domainSkillStartDate',
        header: 'DomainSkill Start Date',
        format: 'dd-MMM-yyyy',
      },
      {
        field: 'domainSkillEndDate',
        header: 'DomainSkill End Date',
        format: 'dd-MMM-yyyy',
      },
      { field: 'projectOrRun', header: 'Project Or Run' },
      { field: 'contractType', header: 'Contract Type' },

      { field: 'remappedMID', header: 'Existing MID' },
      { field: 'validationRemarks', header: 'Validation Remarks' },
    ];
  }

  downloadFPTemplate() {
    this.tempDownloadService
      .downloadFile('assets/contract-data-template/FP_Template.xlsx') //add the path of the file as a parameter
      .subscribe((data: Blob) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = 'FP_Template.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      });
  }
  // saveFpdata() {
  //   this.fpUploadService.saveSelectedFpRows(this.selectedRows).subscribe({
  //     next: (data) => {
  //       this.messageService.add({
  //         severity: 'success',
  //         summary: 'Successfull',
  //         detail: 'FP Detail Deleted',
  //         life: 3000,
  //       });

  //       this.router.navigate(['/fpUpload']);
  //     },
  //     error: (err) => {
  //       this.messageService.add({
  //         severity: 'error',
  //         summary: 'Save function Failed!',
  //         detail: 'Something went wrong while saving records',
  //       });
  //     },
  //   });
  // }

  getFpContractIntermediateDetails() {

    //Function to initialise grid
    console.log('getFpContractIntermediateDetails() test CICD pipline');
    this.fpUploadService.getFPContractIntermediateDetails().subscribe({
      next: (result) => {
        this.fpUploads = result;
        this.fpUploads = this.fpUploads.filter((upload) => {
          return !(this.selectedDetails ?? []).some(
            (detail) => detail.fbcIntID === upload.fbcIntID
          );
        });
        this.selectedDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);

        // if(this.fpUploads.length==0)
        // {
        //   this.invalidDetails = [];
        // }
        // else
        // {
        //   this.invalidDetails = result;
        // }
        // .filter(
        //   (item: any) =>
        //     item.validationRemarks != null || item.validationRemarks != ''
        // )
        // .map((item: any) => item);
        this.invalidDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks != null && item.validationRemarks != ''
          )
          .map((item: any) => item);
      },
      error: (err) => {
        //console.log('error log');
        //console.log(err);
        this.messageService.add({
          severity: 'error',
          summary: 'Records fetching failed',
          detail: 'Something went wrong while retrieving records',
        });
      },
    });
  }

  deleteFpUploadDetail(detail: ifpUpload) {
    this.deleteFpUploadDetailDialog = true;

    this.fpUpload = { ...detail };
  }

  confirmDelete(selectedETWID: string) {
    this.deleteFpUploadDetailDialog = false;

    this.fpUploadService.deleteFPAllOrByID(selectedETWID).subscribe({
      next: (data) => {
        if (data) {
          // this.messageService.add({
          //   severity: 'success',
          //   summary: 'Successfull',
          //   detail: 'Deleted Successfully',
          //   life: 3000,
          // });
          if (typeof selectedETWID === 'string') {
            this.fpUploads = [];
            this.invalidDetails = [];
            this.selectedDetails = [];
          } else {
            this.fpUploads = this.fpUploads.filter(
              (val) => val.fbcIntID !== parseInt(selectedETWID)
            );
            this.selectedDetails = this.fpUploads
              .filter(
                (item: any) =>
                  item.validationRemarks == null || item.validationRemarks == ''
              )
              .map((item: any) => item);
            this.invalidDetails = this.fpUploads
              .filter(
                (item: any) =>
                  item.validationRemarks != null && item.validationRemarks != ''
              )
              .map((item: any) => item);
          }

          // this.fpUploads = this.fpUploads.filter(upload => {
          //   return !this.selectedDetails.some(detail => detail.fbcIntID === upload.fbcIntID);
          // });
        } else {
          this.messageService.add({
            severity: 'error',
            summary: 'Deletion Failed!',
            detail: 'Something went wrong while deleting',
          });
        }

        this.router.navigate(['/main/fpcontract']);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Deletion Failed!',
          detail: 'Something went wrong while deleting',
        });
      },
    });
  }

  confirm(event: Event, rowData: any) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Are you sure that you want to proceed?',
      icon: 'fa-solid fa-exclamation-triangle',
      accept: () => {
        if (typeof rowData === 'string') {
          this.confirmDelete('All');
        } else {
          this.confirmDelete(rowData.fbcIntID);
        }

        this.messageService.add({
          severity: 'success',
          summary: 'Deleted!',
          detail: 'Deleted Successfully',
        });
      },
      reject: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Canceled!',
          detail: 'No Record Deleted',
        });
      },
    });
  }

  isValidationAvailable(data: ifpUpload) {
    return data.validationRemarks === ''
      ? false
      : data.validationRemarks == null
      ? false
      : true;
  }
  isRowSelectable(event: any) {
    return !(event.data.validationRemarks === ''
      ? false
      : event.data.validationRemarks == null
      ? false
      : true);
  }

  onCheckboxChange(event: any, rowData: ifpUpload): void {
    if (
      event.target.ariaChecked == null ||
      event.target.ariaChecked == 'false'
    ) {
      this.selectedRows = this.selectedRows.filter(
        (row) => row.etwid !== rowData.etwid
      );
    } else {
      this.selectedRows.push(rowData);
    }
  }

  onUpload(event: UploadEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Success',
      detail: 'File Uploaded with Basic Mode',
    });

    this.fileUpload.hide();
  }

  onCancel(event: any) {}

  FpFileUploader(event: any, fpfileUpload: any) {
    if (event.files.length > 0) {
      debugger;
      const file = event.files[0];

      this.fpUploadService.UploadFpFiles(file).subscribe({
        next: (data) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Successfull',
            detail: 'FP Contract Detail Saved successfully',
            life: 3000,
          });
          this.showUploadButton = false;
          this.fileValidation = '';
          fpfileUpload.clear();
          this.fileUpload.hide();
          this.getFpContractIntermediateDetails();
        },
        error: (err) => {
          //console.log('err');
          //console.log(err);
          this.messageService.add({
            severity: 'error',
            summary: 'FP Contracts file upload',
            detail:
              'Please validate excel columns / data in your excel sheet. Also date columns should have valid dates.',
            life: 10000,
          });

          this.fileUpload.hide();
        },
      });
    }

    this.messageService.add({
      severity: 'info',
      summary: 'File Uploaded',
      detail: '',
    });
  }

  onFPUplaod(event: UploadEvent) {
    this.selectedFiles = event.originalEvent;
    this.messageService.add({
      severity: 'success',
      summary: 'Imported',
      detail: 'Fetching FP Contract Details.',
    });

    this.getFpContractIntermediateDetails();
  }

  onFPError(event: FileUploadErrorEvent) {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Failed to Upload a file.',
    });
  }

  onFPSend(event: FileSendEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Sent',
      detail: 'Your file has been sent to upload.',
    });
  }

  isRowSelected(rowData: any): boolean {
    return this.selectedRows.includes(rowData);
  }

  onHeaderCheckboxChange(event: any): void {
    if (event.checked) {
      this.selectedItems = this.fpUploads.filter(
        (row) => row.validationRemarks == '' || row.validationRemarks == null
      );
    } else {
      this.selectedItems = [];
    }
  }
  sendDetailsForAction(selectedDetails: ifpUpload[], action: string) {
    // const tmcidArray = selectedDetails.map((item: any) => item.etwid);
    if (action == 'save') {
      this.fpUploadService
        .saveFPContractIntermediateDetails(selectedDetails)
        // .subscribe(
        //   (Response: any) => {
        //     this.selectedDetails = this.fpUploads
        //     .filter(
        //       (item: any) =>
        //         item.validationRemarks == null || item.validationRemarks == ''
        //     )
        //     .map((item: any) => item);
        //   },
        //   (error: any) => {
        //     console.error('API Error:', error);
        //   })
        .subscribe({
          next: (value) => {
            this.selectedDetails = this.fpUploads
              .filter(
                (item: any) =>
                  item.validationRemarks == null || item.validationRemarks == ''
              )
              .map((item: any) => item);
          },
          error: (error) => {
            console.error('API Error:', error);
          },
          complete: () => {
            // complete callback
          },
        });

      this.messageService.add({
        severity: 'success',
        summary: 'Successfull',
        detail: 'FP Detail saved',
        life: 3000,
      });
    } else {
      // let FBCIntIDvalues = selectedDetails.map(obj => obj.fbcIntID);

      this.fpUploadService
        .removeFPContractIntermediateDetails(selectedDetails)
        .subscribe(
          (Response: any) => {},
          (error: any) => {
            console.error('API Error:', error);
          }
        );
      this.messageService.add({
        severity: 'success',
        summary: 'Successfull',
        detail: 'FP Detail Deleted',
        life: 3000,
      });
    }
    this.getFpContractIntermediateDetails();
  }

  checkAndUploadFpDetails(event: FileSelectEvent) {
    const file = event.currentFiles[0];
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const fileContent = e.target.result;
      // const result =
      //   this.excelFileValidationService.validateForDuplicatRecordsFpMo(fileContent);
      const result =
        this.excelFileValidationService.validateForDuplicateRecordsInSpecifiCol(
          fileContent,
          'ETWID'
        );
      const inValidFile =
        this.excelFileValidationService.checkforValidTmTemplateFile(
          fileContent,
          'Fp'
        );

      if (inValidFile.isInvalidTemplate) {
        this.showUploadButton = !inValidFile.isInvalidTemplate;
        this.fileValidation = inValidFile.message;
      } else if (result) {
        this.showUploadButton = false;
        this.fileValidation =
          'Check if ETWID columns exists and has unique values.';
      } else {
        this.showUploadButton = true;
        this.fileValidation = '';
      }
    };

    reader.readAsBinaryString(file);
  }

  handleFileSelect(event: any): void {
    //let expectedColumns = getColumnNamesFromInterface(this.fpUpload);
    const files: File[] = event.files;
    this.readAndValidateExcelFile(files[0]);
  }
  exportExcel() {
    import('xlsx').then((xlsx) => {
      // Clone the original data to avoid modifying the original array
      const data = JSON.parse(JSON.stringify(this.invalidDetails));
      //console.log('DAAATA : ', data);
      const datePipe = new DatePipe('en-US');
      // Define the columns to be removed (replace with your actual column names)
      const columnsToRemove = [
        'fbcIntID',
        'isSelectedApproval',
        'remarks',
        'vendoreMail',
        'wfOrder',
        'status',
        'updatedBy',
        'updatedOn',
        'milestones',
        'pendingwithwhom',
        'cmid',
      ];

      // Remove specified columns from the data
      data.forEach((row: { [x: string]: any }) => {
        columnsToRemove.forEach((col) => {
          delete row[col];
        });
      });

      data.forEach((row: { [x: string]: any }) => {
        Object.keys(row).forEach((col) => {
          if (
            [
              'sowStartDate',
              'sowEndDate',
              'poStartDate',
              'poEndDate',
              'domainSkillEndDate',
              'domainSkillStartDate',
            ].includes(col)
          ) {
            // Check if the column value is a valid date string
            const existingDate = new Date(row[col]);
            if (!isNaN(existingDate.getTime())) {
              // Format the date using DatePipe
              const formattedDate = datePipe.transform(
                existingDate,
                'dd-MMM-yyyy'
              );
              // Update the row with the formatted date
              row[col] = formattedDate;
            }
          }
        });
      });

      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      // console.log(workbook);
      // console.log('--------------------------------------------------');
      // console.log(excelBuffer);
      this.saveAsExcelFile(excelBuffer, 'FP CONTRACT UPLOAD(Invalid Records)');
    });
  }
  readAndValidateExcelFile(file: File): void {
    const reader: FileReader = new FileReader();

    reader.onload = (e: any) => {
      const data: ArrayBuffer = e.target.result;
      const workbook = XLSX.read(data, { type: 'array' });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      const actualColumns: unknown = jsonData[0];
      const isValidColumns = this.validateColumns(actualColumns as string[]);

      if (isValidColumns) {
      } else {
      }
    };

    reader.readAsArrayBuffer(file);
  }

  validateColumns(actualColumns: string[]): boolean {
    return this.expectedColumns.every((column) =>
      actualColumns.includes(column)
    );
  }
  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
      data,
      fileName + '_' + new Date().getTime() + EXCEL_EXTENSION
    );
  }
}
