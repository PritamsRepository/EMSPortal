import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpuploadcontractComponent } from './fpuploadcontract.component';

describe('FpuploadcontractComponent', () => {
  let component: FpuploadcontractComponent;
  let fixture: ComponentFixture<FpuploadcontractComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpuploadcontractComponent]
    });
    fixture = TestBed.createComponent(FpuploadcontractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
