import { Component, OnInit, ViewChild } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ifpmlUpload } from 'src/app/core/interfaces/ifpmlupload';

import {
  FileSelectEvent,
  FileSendEvent,
  FileUploadErrorEvent,
  UploadEvent,
} from 'primeng/fileupload';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import * as XLSX from 'xlsx';
import { fileDownload } from 'src/app/core/services/fileDownload.service';
import { OverlayPanel } from 'primeng/overlaypanel';

@Component({
  selector: 'app-fpuploadmilestone',
  templateUrl: './fpuploadmilestone.component.html',
  styleUrls: ['./fpuploadmilestone.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class FpuploadmilestoneComponent {
  selectedRows: any[] = [];

  constructor(
    private fpUploadService: FpUploadService,
    private messageService: MessageService,
    private excelFileValidationService: excelFileValidation,
    private tempDownloadService: fileDownload,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    private router: Router
  ) {}

  @ViewChild('fileUpload') fileUpload!: OverlayPanel;

  sortField = 'validationRemarks';
  sortOrder = -1;
  uploadUrl: string = `${environment.API_URL}/Contracts/FPContractUploadMl`;
  gridTitle: string = 'Fixed Price Contract Milestone Upload';
  fileValidation: string = '';
  fpUploads!: ifpmlUpload[];
  showUploadButton: boolean = false;
  fpUpload!: ifpmlUpload;
  selectedItems: any[] = [];
  cols!: any[];
  selectedDetails!: ifpmlUpload[] | null;
  deleteFpUploadDetailDialog: boolean = false;
  ref: DynamicDialogRef | undefined;
  selectedFiles: any;
  expectedColumns: string[] = [
    'fbcMilestoneIntID',
    'sowNumber',
    'milestone',
    'MilestoneDescription',
    'milestoneAmount',
    'currency',
    'validationRemarks',
  ];

  ngOnInit() {
    this.getFpContractIntermediateDetails();

    this.cols = [
      { field: 'fbcMilestoneIntID', header: 'fbcMilestoneIntID' },
      { field: 'sowNumber', header: 'SOW Number', align: 'center' },
      { field: 'milestone', header: 'Milestone', align: 'center' },
      {
        field: 'milstoneDescription',
        header: 'Milestone Description',
        align: 'center',
      },
      { field: 'milestoneAmount', header: 'Milestone Amount', align: 'center' },
      { field: 'currency', header: 'Currency', align: 'center' },
      { field: 'validationRemarks', header: 'Validation Remarks' },
    ];
  }

  downloadFPTemplate() {
    this.tempDownloadService
      .downloadFile('assets/contract-data-template/FPMilestone_Template.xlsx')
      .subscribe((data: Blob) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = 'FPMilestone_Template.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      });
  }
  // saveFpdata() {
  //   this.fpUploadService.saveSelectedFpMlRows(this.selectedRows).subscribe({
  //     next: (data) => {
  //       this.messageService.add({
  //         severity: 'success',
  //         summary: 'Successfull',
  //         detail: 'FP Detail Deleted',
  //         life: 3000,
  //       });
  //       this.router.navigate(['/fpmlUpload']);
  //     },
  //     error: (err) => {
  //       this.messageService.add({
  //         severity: 'error',
  //         summary: 'Save function Failed!',
  //         detail: 'Something went wrong while saving records',
  //       });
  //     },
  //   });
  // }

  getFpContractIntermediateDetails() {
    this.fpUploadService.getFPMlContractIntermediateDetails().subscribe({
      next: (result) => {
        this.fpUploads = result;
        this.fpUploads = this.fpUploads.filter((upload) => {
          return !(this.selectedDetails ?? []).some(
            (detail) => detail.fbcMilestoneIntID === upload.fbcMilestoneIntID
          );
        });
        this.selectedDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Records fetching failed',
          detail: 'Something went wrong while retrieving records',
        });
      },
    });
  }
  deleteFpUploadDetail(detail: ifpmlUpload) {}

  confirmDelete(selectedETWID: string) {
    this.deleteFpUploadDetailDialog = false;
    this.fpUploadService.deleteFPMlAllOrByID(selectedETWID).subscribe({
      next: (data) => {
        if (data) {
          // this.fpUploads = this.fpUploads.filter(
          //   (val) => val.etwid !== selectedETWID
          // );
        } else {
          this.messageService.add({
            severity: 'error',
            summary: 'Deletion Failed!',
            detail: 'Something went wrong while deleting',
          });
        }
        this.router.navigate(['/main/fpmilestone']);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Deletion Failed!',
          detail: 'Something went wrong while deleting',
        });
      },
    });
  }

  confirm(event: Event, rowData: any) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Are you sure that you want to proceed?',
      icon: 'fa-solid fa-exclamation-triangle',
      accept: () => {
        if (typeof rowData === 'string') {
          this.confirmDelete('All');
          this.fpUploads = [];
        } else {
          this.confirmDelete(rowData.fbcMilestoneIntID);
          this.fpUploads = this.fpUploads.filter(
            (val) => val.fbcMilestoneIntID !== rowData.fbcMilestoneIntID
          );
        }

        this.selectedDetails = this.fpUploads
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);

        this.messageService.add({
          severity: 'success',
          summary: 'Deleted!',
          detail: 'Deleted Successfully',
        });
      },
      reject: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Canceled!',
          detail: 'No Record Deleted',
        });
      },
    });
  }

  isValidationAvailable(data: ifpmlUpload) {
    return data.validationRemarks === ''
      ? false
      : data.validationRemarks == null
      ? false
      : true;
  }
  isRowSelectable(event: any) {
    return !(event.data.validationRemarks === ''
      ? false
      : event.data.validationRemarks == null
      ? false
      : true);
  }

  onCheckboxChange(event: any, rowData: ifpmlUpload): void {
    if (
      event.target.ariaChecked == null ||
      event.target.ariaChecked == 'false'
    ) {
      this.selectedRows = this.selectedRows.filter(
        (row) => row.fbcMilestoneIntID !== rowData.fbcMilestoneIntID
      );
    } else {
      this.selectedRows.push(rowData);
    }
  }

  onUpload(event: UploadEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Success',
      detail: 'File Uploaded with Basic Mode',
    });
    this.fileUpload.hide();
  }

  onCancel(event: any) {}

  onFPUplaod(event: UploadEvent) {
    this.selectedFiles = event.originalEvent;

    this.messageService.add({
      severity: 'success',
      summary: 'Imported',
      detail: 'Fetching FP Contract Details.',
    });

    this.fileUpload.hide();
    this.getFpContractIntermediateDetails();
  }

  onFPError(event: FileUploadErrorEvent) {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Failed to Upload a file.',
    });

    this.fileUpload.hide();
  }

  onFPSend(event: FileSendEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Sent',
      detail: 'Your file has been sent to upload.',
    });

    this.fileUpload.hide();
  }

  isRowSelected(rowData: any): boolean {
    return this.selectedRows.includes(rowData);
  }

  onHeaderCheckboxChange(event: any): void {
    if (event.checked) {
      this.selectedItems = this.fpUploads.filter(
        (row) => row.validationRemarks == '' || row.validationRemarks == null
      );
    } else {
      this.selectedItems = [];
    }
  }

  sendDetailsForAction(selectedDetails: any, action: string) {
    // const tmcidArray = selectedDetails.map((item: any) => item.fbcMilestoneIntID);

    if (action == 'save') {
      this.fpUploadService
        .saveFPMLContractIntermediateDetails(selectedDetails)
        // .subscribe(
        //   (Response: any) => {
        //     this.selectedDetails = this.fpUploads
        //     .filter(
        //       (item: any) =>
        //         item.validationRemarks == null || item.validationRemarks == ''
        //     )
        //     .map((item: any) => item);
        //   },
        //   (error: any) => {
        //     console.error('API Error:', error);
        //   }
        // )
        .subscribe({
          next: (value) => {
            this.selectedDetails = this.fpUploads
              .filter(
                (item: any) =>
                  item.validationRemarks == null || item.validationRemarks == ''
              )
              .map((item: any) => item);
          },
          error: (error) => {
            console.error('API Error:', error);
          },
          complete: () => {
            // complete callback
          },
        });
      this.getFpContractIntermediateDetails();
    }
    // else {
    //   this.fpUploadService
    //     .removeFPMLContractIntermediateDetails(selectedDetails)
    //     .subscribe(
    //       (Response: any) => {},
    //       (error: any) => {
    //         console.error('API Error:', error);
    //       }
    //     );
    // }
    this.getFpContractIntermediateDetails();
  }

  checkAndUploadMlDetails(event: FileSelectEvent) {
    const file = event.currentFiles[0];
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const fileContent = e.target.result;
      // const result =
      //   this.excelFileValidationService.validateForDuplicateRecordsInSpecifiCol(
      //     fileContent,
      //     'SOW Number'
      //   );
      const inValidFile =
        this.excelFileValidationService.checkforValidTmTemplateFile(
          fileContent,
          'FpMl'
        );
      if (inValidFile.isInvalidTemplate) {
        this.showUploadButton = !inValidFile.isInvalidTemplate;
        this.fileValidation = inValidFile.message;
      } 
      
      // else if (result) {
      //   this.showUploadButton = false;
      //   this.fileValidation =
      //     'Check if SOW number columns exists and has unique values.';
      // } 
      
      else {
        this.showUploadButton = true;
        this.fileValidation = '';
      }
    };

    reader.readAsBinaryString(file);
  }

  handleFileSelect(event: any): void {
    //let expectedColumns = getColumnNamesFromInterface(this.fpUpload);
    const files: File[] = event.files;
    this.readAndValidateExcelFile(files[0]);
    // files.forEach((file: File) => {
    //   alert('te');
    //   this.readAndValidateExcelFile(file);
    // });
  }

  readAndValidateExcelFile(file: File): void {
    const reader: FileReader = new FileReader();

    reader.onload = (e: any) => {
      const data: ArrayBuffer = e.target.result;
      const workbook = XLSX.read(data, { type: 'array' });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      const actualColumns: unknown = jsonData[0];
      const isValidColumns = this.validateColumns(actualColumns as string[]);

      if (isValidColumns) {
      } else {
      }
    };

    reader.readAsArrayBuffer(file);
  }

  validateColumns(actualColumns: string[]): boolean {
    return this.expectedColumns.every((column) =>
      actualColumns.includes(column)
    );
  }

  FpMlFileUploader(event: any, fpmlfileUpload: any) {
    if (event.files.length > 0) {
      const file = event.files[0];

      this.fpUploadService.UploadFpMlFiles(file).subscribe({
        next: (data) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Successfull',
            detail: 'FP Contract Detail Saved successfully',
            life: 3000,
          });
          this.showUploadButton = false;
          this.fileValidation = '';
          fpmlfileUpload.clear();

          this.fileUpload.hide();
          this.getFpContractIntermediateDetails();
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'FP Contracts file upload',
            detail:
              'FP Contract Detail Failed. Make sure amount is valid number.',
            life: 5000,
          });

          this.fileUpload.hide();
        },
      });
    }

    this.messageService.add({
      severity: 'info',
      summary: 'File Uploaded',
      detail: '',
    });
  }
}
