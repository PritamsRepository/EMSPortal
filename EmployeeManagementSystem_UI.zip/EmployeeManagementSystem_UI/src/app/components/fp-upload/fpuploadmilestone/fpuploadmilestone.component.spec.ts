import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpuploadmilestoneComponent } from './fpuploadmilestone.component';

describe('FpuploadmilestoneComponent', () => {
  let component: FpuploadmilestoneComponent;
  let fixture: ComponentFixture<FpuploadmilestoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpuploadmilestoneComponent]
    });
    fixture = TestBed.createComponent(FpuploadmilestoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
