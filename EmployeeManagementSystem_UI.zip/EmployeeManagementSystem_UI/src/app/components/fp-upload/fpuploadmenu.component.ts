import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
@Component({
  selector: 'app-fpuploadmenu',
  templateUrl: './fpuploadmenu.component.html',
  styleUrls: ['./fpuploadmenu.component.css'],
  //   template: `
  //   <p-tabMenu [model]="items" (onChange)="onTabChange($event)"></p-tabMenu>
  // `,
})
export class FpuploadmenuComponent {
  activeItem!: MenuItem;
  sortField = 'validationRemarks';
  sortOrder = -1;
  items!: MenuItem[];

  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {}
  ngOnInit() {
    this.items = [
      {
        label: 'Upload FP Contracts',
        icon: 'pi pi-fw pi-home',
        // routerLink: ['Fpcontractdetail']
        routerLink: ['/main/fpcontract'],
        // command: () => this.router.navigate(['/fpcontract']),
        //  url:"/fpcontract"
        // command: () => this.selectTab('fpcontract'),
      },
      {
        label: 'Upload FP Milestone Commercial',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['/main/fpmilestone'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Upload FP Monthly Commercial',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['/main/fpmonthly'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
    const currentPath = this.router.url;
    if (currentPath == '/main/fpmenu') {
      this.router.navigate(['/main/fpcontract']);
    }
  }
  onTabChange(event: any): void {}
  //   onActiveItemChange(event: MenuItem) {
  //     this.activeItem = event;
  // }
}
