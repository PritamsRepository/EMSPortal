import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpuploadmonthlyComponent } from './fpuploadmonthly.component';

describe('FpuploadmonthlyComponent', () => {
  let component: FpuploadmonthlyComponent;
  let fixture: ComponentFixture<FpuploadmonthlyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpuploadmonthlyComponent]
    });
    fixture = TestBed.createComponent(FpuploadmonthlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
