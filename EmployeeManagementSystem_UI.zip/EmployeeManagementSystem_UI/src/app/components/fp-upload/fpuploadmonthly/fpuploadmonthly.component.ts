import { Component, OnInit, ViewChild } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ifpmoUpload } from 'src/app/core/interfaces/ifpmoupload';
import {
  FileSelectEvent,
  FileSendEvent,
  FileUploadErrorEvent,
  UploadEvent,
} from 'primeng/fileupload';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { FpUploadService } from 'src/app/core/services/fp-upload/fp-upload.service';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import * as XLSX from 'xlsx';
import { fileDownload } from 'src/app/core/services/fileDownload.service';
import { OverlayPanel } from 'primeng/overlaypanel';

@Component({
  selector: 'app-fpuploadmonthly',
  templateUrl: './fpuploadmonthly.component.html',
  styleUrls: ['./fpuploadmonthly.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class FpuploadmonthlyComponent {
  selectedRows: any[] = [];

  constructor(
    private fpUploadService: FpUploadService,
    private messageService: MessageService,
    private excelFileValidationService: excelFileValidation,
    private tempDownloadService: fileDownload,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    private router: Router
  ) {}
  @ViewChild('fileUpload') fileUpload!: OverlayPanel;

  sortField = 'validationRemarks';
  sortOrder = -1;
  uploadUrl: string = `${environment.API_URL}/Contracts/FPContractUploadMo`;
  gridTitle: string = 'Fixed Price Contract Monthly Upload';
  fileValidation: string = '';
  fpUploads!: ifpmoUpload[];
  showUploadButton: boolean = false;
  fpUpload!: ifpmoUpload;
  selectedItems: any[] = [];
  cols!: any[];
  selectedDetails!: ifpmoUpload[] | null;
  deleteFpUploadDetailDialog: boolean = false;
  ref: DynamicDialogRef | undefined;
  selectedFiles: any;
  expectedColumns: string[] = [
    'fbMonthlyIntID',
    'sowNumber',
    'amortizationStartDate',
    'amortizationEndDate',
    'milestoneAmount',
    'durationOfMonth',
    'currency',
    'validationRemarks',
  ];

  ngOnInit() {
    this.getFpMoContractIntermediateDetails();

    this.cols = [
      { field: 'fbMonthlyIntID', header: 'fbMonthlyIntID', align: 'center' },
      { field: 'sowNumber', header: 'SOW Number', align: 'center' },
      {
        field: 'amortizationStartDate',
        header: 'Amortization Starting From',
        format: 'dd-MMM-yyyy',
        align: 'center',
      },
      {
        field: 'amortizationEndDate',
        header: 'Amortization Ending On',
        format: 'dd-MMM-yyyy',
        align: 'center',
      },
      { field: 'milestoneAmount', header: 'Milestone Amount', align: 'center' },
      {
        field: 'durationOfMonth',
        header: 'Duration Of Month',
        align: 'center',
      },
      { field: 'currency', header: 'Currency', align: 'center' },
      { field: 'validationRemarks', header: 'Validation Remarks' },
    ];
  }

  downloadFPTemplate() {
    this.tempDownloadService
      .downloadFile('assets/contract-data-template/FPMonhly_Template.xlsx')
      .subscribe((data: Blob) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'FPMonthly_Template.xlsx'; //rename it to ur file name.
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      });
  }
  saveFpModata() {
    this.fpUploadService.saveSelectedFpMoRows(this.selectedRows).subscribe({
      next: (data) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Successfull',
          detail: 'FP Monthly Detail Deleted',
          life: 3000,
        });
        this.fileUpload.hide();
        this.router.navigate(['/main/fpmonthly']);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Save function Failed!',
          detail: 'Something went wrong while saving records',
        });
        this.fileUpload.hide();
      },
    });
  }

  getFpMoContractIntermediateDetails() {
    this.fpUploadService.getFPMOContractIntermediateDetails().subscribe({
      next: (result) => {
        this.fpUploads = result;

        this.fpUploads = this.fpUploads.filter((upload) => {
          return !(this.selectedDetails ?? []).some(
            (detail) => detail.fbMonthlyIntID === upload.fbMonthlyIntID
          );
        });
        this.selectedDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Records fetching failed',
          detail: 'Something went wrong while retrieving records',
        });
      },
    });
  }

  deleteFpUploadDetail(detail: ifpmoUpload) {
    this.deleteFpUploadDetailDialog = true;

    this.fpUpload = { ...detail };
  }

  confirmDelete(selectedETWID: any) {
    this.deleteFpUploadDetailDialog = false;

    this.fpUploadService.deleteFPMOByID(selectedETWID).subscribe({
      next: (data) => {
        if (data) {
          // this.messageService.add({
          //   severity: 'success',
          //   summary: 'Successfull',
          //   detail: 'FP Detail Deleted',
          //   life: 3000,
          // });
          if (typeof selectedETWID === 'string') {
            this.fpUploads = [];
          } else {
            this.fpUploads = this.fpUploads.filter(
              (val) => val.fbMonthlyIntID !== selectedETWID
            );
          }
          this.selectedDetails = this.fpUploads
            .filter(
              (item: any) =>
                item.validationRemarks == null || item.validationRemarks == ''
            )
            .map((item: any) => item);
        } else {
          this.messageService.add({
            severity: 'error',
            summary: 'Deletion Failed!',
            detail: 'Something went wrong while deleting',
          });
        }

        this.router.navigate(['/main/fpmonthly']);
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Deletion Failed!',
          detail: 'Something went wrong while deleting',
        });
      },
    });
  }

  confirm(event: Event, rowData: any) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Are you sure that you want to proceed?',
      icon: 'fa-solid fa-exclamation-triangle',
      accept: () => {
        if (typeof rowData === 'string') {
          this.confirmDelete('All');
        } else {
          this.confirmDelete(rowData.fbMonthlyIntID);
        }

        this.messageService.add({
          severity: 'success',
          summary: 'Deleted!',
          detail: 'Record Deleted Successfully',
        });
        this.selectedDetails = this.fpUploads
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);
      },
      reject: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Canceled!',
          detail: 'No Record Deleted',
        });
      },
    });
  }

  isValidationAvailable(data: ifpmoUpload) {
    return data.validationRemarks === ''
      ? false
      : data.validationRemarks == null
      ? false
      : true;
  }
  isRowSelectable(event: any) {
    return !(event.data.validationRemarks === ''
      ? false
      : event.data.validationRemarks == null
      ? false
      : true);
  }

  onCheckboxChange(event: any, rowData: ifpmoUpload): void {
    if (
      event.target.ariaChecked == null ||
      event.target.ariaChecked == 'false'
    ) {
      this.selectedRows = this.selectedRows.filter(
        (row) => row.etwid !== rowData.fbMonthlyIntID
      );
    } else {
      this.selectedRows.push(rowData);
    }
  }

  onUpload(event: UploadEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Success',
      detail: 'File Uploaded with Basic Mode',
    });
    this.fileUpload.hide();
  }

  onCancel(event: any) {}

  onFPMOUplaod(event: UploadEvent) {
    this.selectedFiles = event.originalEvent;

    this.messageService.add({
      severity: 'success',
      summary: 'Imported',
      detail: 'Fetching FP Monthly Contract Details.',
    });
    this.fileUpload.hide();
    this.getFpMoContractIntermediateDetails();
  }

  onFPMOError(event: FileUploadErrorEvent) {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Failed to Upload a file.',
    });
    this.fileUpload.hide();
  }

  onFPMOSend(event: FileSendEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Sent',
      detail: 'Your file has been sent to upload.',
    });
    this.fileUpload.hide();
  }

  isRowSelected(rowData: any): boolean {
    return this.selectedRows.includes(rowData);
  }

  onHeaderCheckboxChange(event: any): void {
    if (event.checked) {
      this.selectedItems = this.fpUploads.filter(
        (row) => row.validationRemarks == '' || row.validationRemarks == null
      );
    } else {
      this.selectedItems = [];
    }
  }
  sendDetailsForAction(selectedDetails: any, action: string) {
    // const tmcidArray = selectedDetails.map((item: any) => item.etwid);
    if (action == 'save') {
      this.fpUploadService
        .saveFPMOContractIntermediateDetails(selectedDetails)
        // .subscribe(
        //   (Response: any) => {
        //     this.selectedDetails = this.fpUploads
        //     .filter(
        //       (item: any) =>
        //         item.validationRemarks == null || item.validationRemarks == ''
        //     )
        //     .map((item: any) => item);
        //   },
        //   (error: any) => {
        //     console.error('API Error:', error);
        //   }
        // )
        .subscribe({
          next: (value) => {
            this.selectedDetails = this.fpUploads
              .filter(
                (item: any) =>
                  item.validationRemarks == null || item.validationRemarks == ''
              )
              .map((item: any) => item);
          },
          error: (error) => {
            console.error('API Error:', error);
          },
          complete: () => {
            // complete callback
          },
        });
      this.getFpMoContractIntermediateDetails();
    } else {
      this.fpUploadService
        .removeFPMOContractIntermediateDetails(selectedDetails)
        .subscribe(
          (Response: any) => {},
          (error: any) => {
            console.error('API Error:', error);
          }
        );
      this.getFpMoContractIntermediateDetails();
    }
  }

  checkAndUploadFpDetails(event: FileSelectEvent) {
    const file = event.currentFiles[0];
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const fileContent = e.target.result;
      // const result =
      //   this.excelFileValidationService.validateForDuplicateRecordsInSpecifiCol(
      //     fileContent,
      //     'SOW Number'
      //   );
      const inValidFile =
        this.excelFileValidationService.checkforValidTmTemplateFile(
          fileContent,
          'FpMo'
        );
      if (inValidFile.isInvalidTemplate) {
        this.showUploadButton = !inValidFile.isInvalidTemplate;
        this.fileValidation = inValidFile.message;
      } 
      // else if (result) {
      //   this.showUploadButton = false;
      //   this.fileValidation =
      //     'Check if SOW number columns exists and has unique values.';
      // } 
      else {
        this.showUploadButton = true;
        this.fileValidation = '';
        // if (result.hasDuplicateRecords) {
        //   this.showUploadButton = !result.hasDuplicateRecords;
        //   this.fileValidation = result.message;
        // } else {
        //   this.showUploadButton = !result.hasDuplicateRecords;
        //   this.fileValidation = result.message;
        // }
      }
    };

    reader.readAsBinaryString(file);
  }

  handleFileSelect(event: any): void {
    const files: File[] = event.files;
    this.readAndValidateExcelFile(files[0]);
  }

  readAndValidateExcelFile(file: File): void {
    const reader: FileReader = new FileReader();

    reader.onload = (e: any) => {
      const data: ArrayBuffer = e.target.result;
      const workbook = XLSX.read(data, { type: 'array' });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      const actualColumns: unknown = jsonData[0];
      const isValidColumns = this.validateColumns(actualColumns as string[]);

      if (isValidColumns) {
      } else {
      }
    };

    reader.readAsArrayBuffer(file);
  }

  validateColumns(actualColumns: string[]): boolean {
    return this.expectedColumns.every((column) =>
      actualColumns.includes(column)
    );
  }
  FpMoFileUploader(event: any, fpmlfileUpload: any) {
    if (event.files.length > 0) {
      const file = event.files[0];

      this.fpUploadService.UploadFpMoFiles(file).subscribe({
        next: (data) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Successfull',
            detail: 'FP Contract Detail Saved successfully',
            life: 3000,
          });

          this.showUploadButton = false;
          this.fileValidation = '';
          fpmlfileUpload.clear();
          this.fileUpload.hide();
          this.getFpMoContractIntermediateDetails();
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'FP Contracts file upload',
            detail:
              'FP Contract Detail Failed. Make sure number and date fields have valid value.',
            life: 5000,
          });
          this.fileUpload.hide();
        },
      });
    }

    this.messageService.add({
      severity: 'info',
      summary: 'File Uploaded',
      detail: '',
    });
  }
}
