import { Component, OnInit } from '@angular/core';
import { MessageService, Message } from 'primeng/api';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css'],
  providers: [MessageService]
})
export class ErrorComponent implements OnInit {

  errorMessageDetails: Message[] | undefined;

  ngOnInit() {
    var errorMessage=sessionStorage.getItem('ErrorMessage');
    this.errorMessageDetails = [
      { severity: 'error', summary: 'Error', detail: errorMessage }];

  }
}
