import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmTrackComponent } from './tm-track.component';

describe('TmTrackComponent', () => {
  let component: TmTrackComponent;
  let fixture: ComponentFixture<TmTrackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmTrackComponent]
    });
    fixture = TestBed.createComponent(TmTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
