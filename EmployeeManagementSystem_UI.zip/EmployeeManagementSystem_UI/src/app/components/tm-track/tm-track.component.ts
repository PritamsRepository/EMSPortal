import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { TmApprovalService } from 'src/app/core/services/contract-approval/tm-approval.service';
import { tmApproval } from 'src/app/core/interfaces/Itm-approval';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { Table } from 'primeng/table';
import { itmUpload } from 'src/app/core/interfaces/itmupload';
import { TmWorkflowComponent } from '../tm-view/tm-workflow/tm-workflow.component';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { SharedService } from 'src/app/core/services/shared.service';
import { iBillingTypeMaster, iContractTypeMaster, iLocationMaster, iObsMaster, iProjectOrRunMaster, iSkillSetMaster, iSowTypeMaster, iTowerNameMaster, iVendorMaster, iVerticalMaster } from 'src/app/core/interfaces/imasterDetails';
import { TmContractEditComponent } from '../tm-sendback/tm-contract-edit/tm-contract-edit.component';
import { itmDetails } from 'src/app/core/interfaces/itmDetails';

@Component({
  selector: 'app-tm-edit-track',
  templateUrl: './tm-track.component.html',
  styleUrls: ['./tm-track.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class TmTrackComponent implements OnInit {
  constructor(
    private tmApprovalService: TmApprovalService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public sharedService: SharedService,
    public dialogService: DialogService
  ) {}

  tmapprovaldetails!: tmApproval[];

  cols: any[] = [];
  ddFilter: any[] = [];
  selectedFilter?: any = { name: 'Approved List', code: 'AL' };
  vendorDetails!: iVendorMaster[];
  sowTypeDetails!: iSowTypeMaster[];
  contractTypeDetails!: iContractTypeMaster[];
  billingTypeDetails!: iBillingTypeMaster[];
  verticalDetails!: iVerticalMaster[];
  towerNameDetails!: iTowerNameMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  obsDetails!: iObsMaster[];
  skillSetDetails!: iSkillSetMaster[];
  locationDetails!: iLocationMaster[];

  ddActiveFilter: any[] = [];
  selectedActiveFilter?: any = { name: 'Active Records', code: 'Active' };
  isvalid: boolean = false;

  ref: DynamicDialogRef | undefined;

  pageTitle: string = 'TRACK TIME & MATERIAL CONTRACTS';

  ngOnInit() {
    this.getTMContractTrackdata(this.selectedFilter, this.selectedActiveFilter);
    this.ddFilter = [
      { name: 'All', code: 'ALL' },
      { name: 'Approved List', code: 'AL' },
      { name: 'Sentback List', code: 'SL' },
    ];

    this.ddActiveFilter = [
      { name: 'Both', code: 'Both' },
      { name: 'Active Records', code: 'Active' },
      { name: 'InActive Records', code: 'InActive' },
    ];

    /* this.cols = [
      { field: 'tmcmid', header: 'TMVCMID' },
      { field: 'tmvcmid', header: 'TMVCMID' },
      { field: 'etwid', header: 'ETWID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'sowNumber', header: 'SOW Number' },

      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowType', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date' },
      { field: 'sowEndDate', header: 'SOW End Date' },
      { field: 'poNumber', header: 'PO Number' },

      { field: 'poStartDate', header: 'PO Start Date' },
      { field: 'poEndDate', header: 'PO End Date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'tower', header: 'Tower' },

      { field: 'domainName', header: 'Domain Name' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'domainSkillStartDate', header: 'Domain Skill Start Date' },
      { field: 'domainSkillEndDate', header: 'Domain Skill End Date' },
      { field: 'contractType', header: 'Contract Type' },

      { field: 'billingType', header: 'Billing Type' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },

      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'noticePeriod', header: 'Notice Period' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'positionLocation', header: 'Managing Team' },
      { field: 'oldSowNumber', header: 'Old SOW Number' },

      { field: 'remappedMID', header: 'Existing MID' },
    ];*/
  }
  clear(table: Table) {
    table.clear();
  }
  getTMContractTrackdata(selectedFilter: any, selectedActiveFilter: any) {
    this.tmApprovalService
      .getTMContractTrackdata(selectedFilter.code, selectedActiveFilter.code)
      .subscribe((result) => {
        //console.log(result);
        this.tmapprovaldetails = result;
      });
  }

  viewTmWorkFlow(data: itmUpload) {
    const jsonString = JSON.stringify(data, null, 2); // Convert object to JSON string with pretty printing (2 spaces indent)
    // console.log('console');
    // console.log(jsonString);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  // }

  getSeverity(data: string) {
    switch (data) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }
  ExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    const filteredContractList = this.tmapprovaldetails.map((contract) => {
      // Create a new object to hold the properties in the desired order
      return {
        etwid: contract.etwid,

        PositionCode: contract.positionCode,
        vendorName: contract.vendorName,
        positionLocation: contract.positionLocation,
        RemappedMID: contract.remappedMID,
        oldSowNumber: contract.oldSowNumber,
        sowNumber: contract.sowNumber,
        sowName: contract.sowName,
        sowType: contract.sowType,
        sowStartDate: contract.sowStartDate
          ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
          : '',
        sowEndDate: contract.sowEndDate
          ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
          : '',
        skillSet: contract.skillSet,
        domainName: contract.domainName,
        domainSkillStartDate: contract.domainSkillStartDate
          ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
          : '',
        domainSkillEndDate: contract.domainSkillEndDate
          ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
          : '',
        domainLeadEmail: contract.domainLeadEmail,
        poNumber: contract.poNumber,
        poStartDate: contract.poStartDate
          ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
          : '',
        poEndDate: contract.poEndDate
          ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
          : '',
        projectOrRun: contract.ppmProjectID,
        ppmProjectName: contract.ppmProjectName,

        tower: contract.tower,
        costCenter: contract.costCenter,
        vertical: contract.vertical,
        obs: contract.obs,
        wbsDetail: contract.wbsDetail,
        // domainLeadEmail: contract.domainLeadEmail,
        contractType: contract.contractType,
        BillingType: contract.billingType,
        currency: contract.currency,

        billingRateYear1: contract.billingRateYear1,
        billingRateYear2: contract.billingRateYear2,
        billingRateYear3: contract.billingRateYear3,
        billingRateYear4: contract.billingRateYear4,
        billingRateYear5: contract.billingRateYear5,
        sapCode: contract.sapCode,
        noticePeriod: contract.noticePeriod,
        isActive: contract.isActive,
        uploadedby: contract.uploadedBy,
        uploadedDate: contract.uploadDate
          ? datePipe.transform(contract.uploadDate, 'dd-MMM-yyyy')
          : '',
      };
    });

    // Convert the filteredContractList to a worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'T&M Contract Track List.xlsx');
  }
  tmDetails!: itmDetails;

  isEditAllowed(data: tmApproval): boolean {
    // console.log(data.isActive);
    // console.log('test');
    // console.log(data.wfOrder);
    //return this.selectedFilter?.code === 'AL' && this.selectedActiveFilter?.code === 'Active';

    return  (data.isActive==true && (data.wfOrder == null || data.wfOrder>1));

    // return data.status;
    //isActive
    //return true;
    //console.log(data);
    //return true;
  }

  EditTmDetails(data: tmApproval) {
    // this.tmDetails = data;
    this.tmDetails = this.convertResourceToItm(data);
  
    this.sharedService.GetAllMasterDetails().subscribe({
      next: (result) => {
        this.vendorDetails = result.vendorMastersDetails.map((item: any) => {
          const { vendorId, vendorName } = item;
          return { vendorId, vendorName };
        });

        this.sowTypeDetails = result.sowTypeMastersDetails.map((item: any) => {
          const { sowTypeId, sowTypeName } = item;
          return { sowTypeId, sowTypeName };
        });
        this.contractTypeDetails = result.contractTypeMastersDetails.map(
          (item: any) => {
            const { contractTypeId, contractTypeName } = item;
            return { contractTypeId, contractTypeName };
          }
        );
        this.billingTypeDetails = result.billingTypeMastersDetails.map(
          (item: any) => {
            const { billingTypeId, billingTypeName } = item;
            return { billingTypeId, billingTypeName };
          }
        );
        this.verticalDetails = result.verticalMastersDetails.map(
          (item: any) => {
            const { verticalId, verticalName } = item;
            return { verticalId, verticalName };
          }
        );
        this.towerNameDetails = result.towerMastersDetails.map((item: any) => {
          const { towerNameId, towerName } = item;
          return { towerNameId, towerName };
        });
        this.projectOrRunDetails = result.projOrRunMastersDetails.map(
          (item: any) => {
            const { projectOrRunId, projectOrRun } = item;
            return { projectOrRunId, projectOrRun };
          }
        );
        this.obsDetails = result.obsMastersDetails.map((item: any) => {
          const { obsmasterId, obsmasterName } = item;
          return { obsmasterId, obsmasterName };
        });
        this.skillSetDetails = result.skillSetMastersDetails.map(
          (item: any) => {
            const { skillId, skillSet } = item;
            return { skillId, skillSet };
          }
        );
        this.locationDetails = result.locationMastersDetails.map(
          (item: any) => {
            const { locationId, locationName } = item;
            return { locationId, locationName };
          }
        );
       
        this.ref = this.dialogService.open(TmContractEditComponent, {
          header: 'T&M Details',
          data: {
            tmdetails: this.tmDetails,
            vendor: this.vendorDetails,
            sowTypes: this.sowTypeDetails,
            contractTypes: this.contractTypeDetails,
            billingTypes: this.billingTypeDetails,
            verticals: this.verticalDetails,
            towerNames: this.towerNameDetails,
            projectOrRuns: this.projectOrRunDetails,
            obs: this.obsDetails,
            skillSets: this.skillSetDetails,
            locations: this.locationDetails,
            EditFromTmTrackScreen: true
          },
          width: '80%',
          contentStyle: { overflow: 'auto' },
          baseZIndex: 2204,
          maximizable: true,
        });

        this.ref.onClose.subscribe((result: string) => {
          if (result) {
            //this.LoadTMTrackscreen();
            this.getTMContractTrackdata(this.selectedFilter, this.selectedActiveFilter);
            this.messageService.add({
              severity: 'success',
              summary: 'Saved!',
              detail: result,
            });
          }
        });

      },
      complete() {},
      error: (error) => {
        console.error('Error fetching master details:', error);
        // Handle error as needed
      },
    });
  }
  
  convertResourceToItm(resource: tmApproval): itmDetails {
    const tmdts: itmDetails = {
        tmvcmid: resource.tmvcmid ?? 0,
        tmcmid: resource.tmcmid ?? 0,
        etwid: resource.etwid ?? "",
        vendorName: resource.vendorName ?? "",
        sowTypeName: resource.sowType ?? "",
        contractTypeName: resource.contractType ?? "",
        billingTypeName: resource.billingType ?? "",
        verticalName: resource.vertical ?? "",
        towerName: resource.tower ?? "",
        projectOrRun: resource.projectOrRun ?? "",
        skillSet: resource.skillSet ?? "",
        sowNumber: resource.sowNumber ?? "",
        sowName: resource.sowName ?? "",
        sowStartDate: resource.sowStartDate ?? new Date(),
        sowEndDate: resource.sowEndDate ?? new Date(),
        poNumber: resource.poNumber ?? "",
        poStartDate: resource.poStartDate ?? new Date(),
        poEndDate: resource.poEndDate ?? new Date(),
        ppmProjectID: resource.ppmProjectID ?? "",
        ppmProjectName: resource.ppmProjectName ?? "",
        wbsDetail: resource.wbsDetail ?? "",
        domainLeadEmail: resource.domainLeadEmail ?? "",
        domainName: resource.domainName ?? "",
        domainSkillStartDate: resource.domainSkillStartDate ?? new Date(),
        domainSkillEndDate: resource.domainSkillEndDate ?? new Date(),
        currency: resource.currency ?? "",
        billingRateYear1: resource.billingRateYear1 ?? 0,
        billingRateYear2: resource.billingRateYear2 ?? 0,
        billingRateYear3: resource.billingRateYear3 ?? 0,
        billingRateYear4: resource.billingRateYear4 ?? 0,
        billingRateYear5: resource.billingRateYear5 ?? 0,
        locationName: resource.positionLocation ?? "",
        noticePeriod: resource.noticePeriod ?? 0,
        positionCode: resource.positionCode ?? "",
        oldSOWNumber: resource.oldSowNumber ?? "",
        remappedMID: resource.remappedMID ?? "",
        sapCode: resource.sapCode ?? "",
        costCenter: resource.costCenter ?? "",
        obs: resource.obs ?? "",
        status: resource.status ?? "",
        pendingWithWhom: resource.Pendingwithwhom ?? "",

        // wfOrder: resource.fbcIntID ?? 0,
        wfOrder: resource.wfOrder ?? 0,

        isActive: resource.isActive,// === "Active",
        // contract: resource.contractStatus ?? "",
        uploadedBy: resource.uploadedBy ?? "",
        uploadedDate: resource.uploadDate ?? new Date(),
        customDomainName: resource.customDomainName ?? ""
    };
    return tmdts;
}

  isSowEndDateBeforeToday(sowEndDate: Date): boolean {
    const today = new Date();
    if (sowEndDate === null) {
      return false;
    }
    const endDate = new Date(sowEndDate);
    today.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);
    return endDate < today;
  }
}
