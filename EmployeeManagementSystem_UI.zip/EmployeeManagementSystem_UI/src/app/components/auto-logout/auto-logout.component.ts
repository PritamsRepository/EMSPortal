import { Component,  OnInit } from '@angular/core'
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';
import { AutoLogoutService } from 'src/app/core/services/auto-logout/auto-logout.service'
import { StorageService } from 'src/app/core/services/storage/storage.service';
@Component({
  selector: 'app-auto-logout',
  templateUrl: './auto-logout.component.html',
  providers: [AutoLogoutService]
})

export class AutoLogoutComponent implements OnInit {
  constructor (private readonly autoLogoutService: AutoLogoutService, private readonly _authentication:AuthenticationService, private readonly _storageService:StorageService, private readonly _router:Router) { 
    this._authentication.logout().subscribe({
      next: (res) => {
        this._storageService.clean();
        this._router.navigate(['/login']);
        window.location.reload();
      },
      error(err) {
        //window.location.reload();
        //console.log(err);
      },
    });
  }

  ngOnInit () {
   
  }
}
