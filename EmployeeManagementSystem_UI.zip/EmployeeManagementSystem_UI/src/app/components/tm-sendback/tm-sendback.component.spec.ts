import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmSendbackComponent } from './tm-sendback.component';

describe('TmSendbackComponent', () => {
  let component: TmSendbackComponent;
  let fixture: ComponentFixture<TmSendbackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmSendbackComponent]
    });
    fixture = TestBed.createComponent(TmSendbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
