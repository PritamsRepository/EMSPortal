import {
  AfterContentInit,
  AfterViewInit,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { itmUpload } from 'src/app/core/interfaces/itmupload';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TmContractEditComponent } from './tm-contract-edit/tm-contract-edit.component';
import { ConfirmationService, MessageService } from 'primeng/api';
import {
  iBillingTypeMaster,
  iContractTypeMaster,
  iLocationMaster,
  iObsMaster,
  iProjectOrRunMaster,
  iSkillSetMaster,
  iSowTypeMaster,
  iTowerNameMaster,
  iVendorMaster,
  iVerticalMaster,
} from 'src/app/core/interfaces/imasterDetails';
import { SharedService } from 'src/app/core/services/shared.service';
import { itmEditedDetails } from 'src/app/core/interfaces/itmDetails';
import { TmWorkflowComponent } from '../tm-view/tm-workflow/tm-workflow.component';
import { DatePipe } from '@angular/common';
import * as FileSaver from 'file-saver';
import { FormGroup, FormControl, NgModel } from '@angular/forms';

@Component({
  selector: 'app-tm-sendback',
  templateUrl: './tm-sendback.component.html',
  styleUrls: ['./tm-sendback.component.css'],
  providers: [MessageService, DialogService, ConfirmationService],
})
export class TmSendbackComponent implements AfterContentInit {
  @ViewChild('inputField') inputField: NgModel;
  gridTitle: string = 'Time & Material Contract Sendback List';
  ref: DynamicDialogRef | undefined;
  tableCols: any[];
  tmSendbackLists!: itmUpload[];
  tmSendback!: itmUpload;

  vendorDetails!: iVendorMaster[];
  sowTypeDetails!: iSowTypeMaster[];
  contractTypeDetails!: iContractTypeMaster[];
  billingTypeDetails!: iBillingTypeMaster[];
  verticalDetails!: iVerticalMaster[];
  towerNameDetails!: iTowerNameMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  obsDetails!: iObsMaster[];
  skillSetDetails!: iSkillSetMaster[];
  locationDetails!: iLocationMaster[];
  datePipe = new DatePipe('en-US');
  selectedDetails!: itmUpload[] | null;
  delRemarks: string;
  constructor(
    private tmUploadService: TmUploadService,
    private messageService: MessageService,
    public dialogService: DialogService,
    public sharedService: SharedService,
    private confirmationService: ConfirmationService
  ) {}

  tmSendbackListsbackup!: itmUpload[];
  FilterMyData(data: any, typo: string) {
    //console.log(data.value);
    //console.log(typo);
    this.tmSendbackLists = data.value.map((item: any) => {
      item.domainSkillStartDate = this.datePipe.transform(
        item.domainSkillStartDate,
        'dd-MMM-yyyy'
      );

      item.domainSkillEndDate = this.datePipe.transform(
        item.domainSkillEndDate,
        'dd-MMM-yyyy'
      );
      item.poStartDate = this.datePipe.transform(
        item.poStartDate,
        'dd-MMM-yyyy'
      );
      item.poEndDate = this.datePipe.transform(item.poEndDate, 'dd-MMM-yyyy');
      item.sowStartDate = this.datePipe.transform(
        item.sowStartDate,
        'dd-MMM-yyyy'
      );
      item.sowEndDate = this.datePipe.transform(item.sowEndDate, 'dd-MMM-yyyy');
      item.uploadedDate = this.datePipe.transform(
        item.uploadedDate,
        'dd-MMM-yyyy'
      );

      return item;
    });
    // Example entered text for search
    //alert(typo.length);
    if (typo != '') {
      const searchText = typo;

      // Filter the array based on the entered text
      const searchResults = data.value.filter(
        (item: { [x: string]: string }) => {
          // Convert all property values to lowercase for case-insensitive search
          for (const key in item) {
            if (
              typeof item[key] === 'string' &&
              item[key].toLowerCase().includes(searchText.toLowerCase())
            ) {
              return true; // Match found, include in results
            }
          }
          return false; // No match found
        }
      );
      this.tmSendbackLists = searchResults;
      //console.log('Search-Results : ', searchResults);
    } else {
      this.tmSendbackLists = this.tmSendbackListsbackup;
    }
    return this.tmSendbackLists;
  }

  ngAfterContentInit() {
    this.getTmContractSendbackDetails();
    this.tableCols = [
      //{ field: 'sendBackReason', header: 'Send back Reason' },
      { field: 'pendingWithWhom', header: 'Pending With Whom' },
      { field: 'etwid', header: 'ETWID' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'vendorName', header: 'Vendor Name' },

      { field: 'locationName', header: 'Managing Team' },
      { field: 'oldSOWNumber', header: 'Old SOW Number' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowTypeName', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date', type: 'date' },
      { field: 'sowEndDate', header: 'SOW End Date', type: 'date' },
      { field: 'customDomainName', header: 'Domain Name' },
      { field: 'domainName', header: 'Domain Skill Name' },
      { field: 'skillSet', header: 'Skill Set' },
      {
        field: 'domainSkillStartDate',
        header: 'Domain Skill Start Date',
        type: 'date',
      },
      {
        field: 'domainSkillEndDate',
        header: 'Domain Skill End Date',
        type: 'date',
      },
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date', type: 'date' },
      { field: 'poEndDate', header: 'PO End Date', type: 'date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'wbsDetail', header: 'WBS Detail' },
      { field: 'verticalName', header: 'Vertical' },
      { field: 'towerName', header: 'Tower' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'costCenter', header: 'Cost Center Code' },
      { field: 'obs', header: 'OBS' },

      { field: 'projectOrRun', header: 'Project Or Run' },
      { field: 'contractTypeName', header: 'Contract Type' },
      { field: 'billingTypeName', header: 'Billing Type' },
      { field: 'currency', header: 'Currency' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },
      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'remappedMID', header: 'Existing MID' },
      { field: 'sapCode', header: 'SAP Code' },
      { field: 'noticePeriod', header: 'Notice Period' },
      { field: 'locationName', header: 'Location Name' },

      { field: 'isActive', header: 'Is Active', type: 'bool' },
      { field: 'uploadedBy', header: 'Uploaded By' },
      { field: 'uploadedDate', header: 'Uploaded Date', type: 'date' },
    ];
  }
  getTmContractSendbackDetails() {
    this.tmUploadService.getTMContractSendbackDetails().subscribe({
      next: (result: itmUpload[]) => {
        this.tmSendbackLists = result;
        this.tmSendbackListsbackup = this.tmSendbackLists;
        //console.log('Details : ', this.tmSendbackLists);
        if (this.tmSendbackLists.length > 0) {
          this.messageService.add({
            severity: 'info',
            summary: 'Fetched',
            detail: 'T&M contract sendback details fetched successfully.',
          });
        } else {
          this.messageService.add({
            severity: 'warn',
            summary: 'No Records',
            detail: 'No t&m contract sendback details found.',
          });
        }
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch t&m contract sendback details.',
        });
      },
    });
  }

  editTmSendBackDetails(data: itmUpload) {
    this.sharedService.GetAllMasterDetails().subscribe({
      next: (result) => {
        //console.log('Master Details : ', result);
        this.vendorDetails = result.vendorMastersDetails.map((item: any) => {
          const { vendorId, vendorName } = item;
          return { vendorId, vendorName };
        });

        this.sowTypeDetails = result.sowTypeMastersDetails.map((item: any) => {
          const { sowTypeId, sowTypeName } = item;
          return { sowTypeId, sowTypeName };
        });
        this.contractTypeDetails = result.contractTypeMastersDetails.map(
          (item: any) => {
            const { contractTypeId, contractTypeName } = item;
            return { contractTypeId, contractTypeName };
          }
        );
        this.billingTypeDetails = result.billingTypeMastersDetails.map(
          (item: any) => {
            const { billingTypeId, billingTypeName } = item;
            return { billingTypeId, billingTypeName };
          }
        );
        this.verticalDetails = result.verticalMastersDetails.map(
          (item: any) => {
            const { verticalId, verticalName } = item;
            return { verticalId, verticalName };
          }
        );
        this.towerNameDetails = result.towerMastersDetails.map((item: any) => {
          const { towerNameId, towerName } = item;
          return { towerNameId, towerName };
        });
        this.projectOrRunDetails = result.projOrRunMastersDetails.map(
          (item: any) => {
            const { projectOrRunId, projectOrRun } = item;
            return { projectOrRunId, projectOrRun };
          }
        );
        this.obsDetails = result.obsMastersDetails.map((item: any) => {
          const { obsmasterId, obsmasterName } = item;
          return { obsmasterId, obsmasterName };
        });
        this.skillSetDetails = result.skillSetMastersDetails.map(
          (item: any) => {
            const { skillId, skillSet } = item;
            return { skillId, skillSet };
          }
        );
        this.locationDetails = result.locationMastersDetails.map(
          (item: any) => {
            const { locationId, locationName } = item;
            return { locationId, locationName };
          }
        );

        this.ref = this.dialogService.open(TmContractEditComponent, {
          header: 'T&M Sendback Details',
          data: {
            tmdetails: data,
            vendor: this.vendorDetails,
            sowTypes: this.sowTypeDetails,
            contractTypes: this.contractTypeDetails,
            billingTypes: this.billingTypeDetails,
            verticals: this.verticalDetails,
            towerNames: this.towerNameDetails,
            projectOrRuns: this.projectOrRunDetails,
            obs: this.obsDetails,
            skillSets: this.skillSetDetails,
            locations: this.locationDetails,
          },
          width: '80%',
          contentStyle: { overflow: 'auto' },
          baseZIndex: 2204,
          maximizable: true,
        });

        this.ref.onClose.subscribe((result: string) => {
          if (result) {
            this.getTmContractSendbackDetails();
            this.messageService.add({
              severity: 'success',
              summary: 'Saved!',
              detail: result,
            });
          }
        });

        // this.ref.onDestroy.subscribe((blah: any) => {
        //   //console.log('blah : ', blah);
        //   this.getTmContractSendbackDetails();
        //   this.messageService.add({
        //     severity: 'success',
        //     summary: 'Saved!',
        //   });
        // });
      },
      complete() {},
      error: (error) => {
        console.error('Error fetching master details:', error);
        // Handle error as needed
      },
    });
  }

  viewTmWorkFlow(data: itmUpload) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History - (ETWID:- ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }

  exportExcel() {
    import('xlsx').then((xlsx) => {
      // Clone the original data to avoid modifying the original array
      const data = JSON.parse(JSON.stringify(this.tmSendbackLists));
      //console.log('DAAATA : ', data);
      const datePipe = new DatePipe('en-US');
      ////Define the columns to be removed (replace with your actual column names)
      const columnsToRemove = [
        'tmcmid',
        'tmvcmid',
        'tmcid',
        'isSelectedApproval',
        'remarks',
        'vendoreMail',
        'wfOrder',
        'status',
        'pendingwithwhom',
      ];

      ////Remove specified columns from the data
      data.forEach((row: { [x: string]: any }) => {
        columnsToRemove.forEach((col) => {
          delete row[col];
        });
      });

      data.forEach((row: { [x: string]: any }) => {
        Object.keys(row).forEach((col) => {
          if (
            [
              'sowStartDate',
              'sowEndDate',
              'poStartDate',
              'poEndDate',
              'domainSkillEndDate',
              'domainSkillStartDate',
            ].includes(col)
          ) {
            // Check if the column value is a valid date string
            const existingDate = new Date(row[col]);
            if (!isNaN(existingDate.getTime())) {
              // Format the date using DatePipe
              const formattedDate = datePipe.transform(
                existingDate,
                'dd-MMM-yyyy'
              );
              // Update the row with the formatted date
              row[col] = formattedDate;
            }
          }
        });
      });

      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      // //console.log(workbook);
      // //console.log('--------------------------------------------------');
      // //console.log(excelBuffer);
      this.saveAsExcelFile(
        excelBuffer,
        'TIME & MATERIAL CONTRACT SENDBACK DETAILS'
      );
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
      data,
      fileName + '_' + new Date().getTime() + EXCEL_EXTENSION
    );
  }

  removeTMContractSendBackDetails(selectedDetails: any) {
    var tmcidArray: number;
    var remarks: string;

    try {
      tmcidArray = selectedDetails.map((item: any) => item.tmvcmid);
      remarks = selectedDetails.map((item: any) => item.delRemarks);
    } catch {
      tmcidArray = selectedDetails.tmvcmid;
      remarks = selectedDetails.delRemarks;
    }

    if (remarks != null && remarks != '' && typeof remarks != 'undefined') {
      this.tmUploadService
        .removeTMContractSendBackDetails(tmcidArray, remarks)
        .subscribe({
          next: (res) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Deleted',
              detail: 'T&M contract details deleted successfully.',
            });
          },
          complete: () => {
            this.getTmContractSendbackDetails();
          },
          error: (err) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: 'Failed to delete t&m contract details.',
            });
          },
        });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Required !',
        detail: 'Please enter delete remarks.',
      });
    }
  }

  confirm(event: Event, data: itmUpload[]) {
    // console.log(data.length);
    // console.log(data);

    if (data) {
      this.confirmationService.confirm({
        target: event.target as EventTarget,
        message: 'Are you sure that you want to proceed?',
        icon: 'fa-solid fa-exclamation-triangle',
        accept: () => {
          this.removeTMContractSendBackDetails(data);
        },
        reject: () => {
          // this.messageService.add({
          //   severity: 'error',
          //   summary: 'Canceled!',
          //   detail: 'No Record Deleted',
          // });
        },
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'No Invalid Records Found!',
        detail: 'There are no invalid records to delete.',
      });
    }
  }
}
