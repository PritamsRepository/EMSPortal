import {
  AfterContentChecked,
  AfterViewInit,
  Component,
  OnInit,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/dynamicdialog';
import {
  iVendorMaster,
  iSowTypeMaster,
  iContractTypeMaster,
  iBillingTypeMaster,
  iVerticalMaster,
  iTowerNameMaster,
  iProjectOrRunMaster,
  iObsMaster,
  iSkillSetMaster,
  iLocationMaster,
} from 'src/app/core/interfaces/imasterDetails';
import {
  itmDetails,
  itmEditedDetails,
} from 'src/app/core/interfaces/itmDetails';
import { itmUpload } from 'src/app/core/interfaces/itmupload';
import { ResourceTrack } from 'src/app/core/interfaces/resource-track';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';

@Component({
  selector: 'app-tm-contract-edit',
  templateUrl: './tm-contract-edit.component.html',
  styleUrls: ['./tm-contract-edit.component.css'],
  providers: [MessageService],
})
export class TmContractEditComponent implements OnInit, AfterViewInit {
  tmDetailsform: FormGroup<any>;
  constructor(
    private fb: FormBuilder,
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public tmUpload: TmUploadService,
    public messageService: MessageService
  ) 
  {
    // Build your form controls using FormBuilder
    this.tmDetailsform = this.fb.group({
      etwid: ['', [Validators.required]],
      positionCode: ['', [Validators.required]],
      vendorId: ['', [Validators.required]], // Use this to bind to your dropdown value
      positionLocationId: ['', [Validators.required]], // Use this to bind to your dropdown value
      oldSOWNumber: ['', []],
      sowNumber: ['', [Validators.required]],
      sowName: ['', [Validators.required]],
      sowtypeId: ['', [Validators.required]], // Use this to bind to your dropdown value
      sowstartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      sowEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      customDomainName: ['', [Validators.required]],
      domainName: ['', [Validators.required]],
      skillSetId: ['', [Validators.required]], // Use this to bind to your dropdown value
      domainSkillStartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      domainSkillEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      poNumber: ['', [Validators.required]],
      poStartDate: ['', [Validators.required]], // Use this to bind to your calendar value
      poEndDate: ['', [Validators.required]], // Use this to bind to your calendar value
      ppmProjectID: ['', [Validators.required]],
      ppmProjectName: ['', [Validators.required]],
      wbsDetail: ['', [Validators.required]],
      verticalId: ['', [Validators.required]], // Use this to bind to your dropdown value
      towerId: ['', [Validators.required]], // Use this to bind to your dropdown value
      domainLeadEmail: ['', [Validators.required]],
      costCenter: ['', [Validators.required]],
      obs: ['', [Validators.required]], // Use this to bind to your dropdown value
      projectOrRunId: ['', [Validators.required]], // Use this to bind to your dropdown value
      contractTypeId: [{ value: '', disabled: true }, [Validators.required]], // Use this to bind to your dropdown value
      billingTypeId: ['', [Validators.required]], // Use this to bind to your dropdown value
      currency: ['', [Validators.required]],
      billingRateYear1: ['', [Validators.required]],
      billingRateYear2: ['', [Validators.required]],
      billingRateYear3: ['', [Validators.required]],
      billingRateYear4: ['', [Validators.required]],
      billingRateYear5: ['', [Validators.required]],
      remappedMID: ['', []],
      sapCode: ['', [Validators.required]],
      noticePeriod: ['', [Validators.required]],
      pendingWithWhom: ['', [Validators.required]],
      remarks: ['', [Validators.required]],
    });
  }

  tmDetails!: itmDetails;
  vendorDetails!: iVendorMaster[];
  sowTypeDetails!: iSowTypeMaster[];
  contractTypeDetails!: iContractTypeMaster[];
  billingTypeDetails!: iBillingTypeMaster[];
  verticalDetails!: iVerticalMaster[];
  towerNameDetails!: iTowerNameMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  obsDetails!: iObsMaster[];
  skillSetDetails!: iSkillSetMaster[];
  locationDetails!: iLocationMaster[];
  validationRemarks!: string;
  ShowSbHeader: boolean=true;
  EditFromTmTrackScreen: boolean=false;
  EditSowDtsTmTrackScreen: boolean=false;
  ngOnInit(): void {
    //console.log('data for dialog : ', this.config.data);

    // Retrieve details from the config object {value:'Y'}
    this.tmDetails = this.config.data.tmdetails;
    this.vendorDetails = this.config.data.vendor;
    this.sowTypeDetails = this.config.data.sowTypes;
    this.contractTypeDetails = this.config.data.contractTypes;
    this.billingTypeDetails = this.config.data.billingTypes;
    this.verticalDetails = this.config.data.verticals;
    this.towerNameDetails = this.config.data.towerNames;
    this.projectOrRunDetails = this.config.data.projectOrRuns;
    this.obsDetails = this.config.data.obs;
    this.skillSetDetails = this.config.data.skillSets;
    this.locationDetails = this.config.data.locations;

    if(this.config.data.EditFromTmTrackScreen || this.config.data.EditSowDtsTmTrackScreen)
    {
      this.EditFromTmTrackScreen = this.config.data.EditFromTmTrackScreen;
      this.EditSowDtsTmTrackScreen = this.config.data.EditSowDtsTmTrackScreen;
      this.ShowSbHeader=false;
      this.DisableFieldsForTmTrackScreen();
      const formControls = this.tmDetailsform.controls;
      formControls['remarks'].enable();
    }

    // this.ShowSbHeader = this.config.data.ShowSbHeader;
  }

  ngAfterViewInit() {
    // Patch the form with data from this.tmDetails
    this.tmDetailsform.patchValue({
      etwid: this.tmDetails.etwid,
      positionCode: this.tmDetails.positionCode,

      vendorId: this.vendorDetails.find(
        (item) => item.vendorName === this.tmDetails.vendorName
      )?.vendorId,

      positionLocationId: this.locationDetails.find(
        (item) => item.locationName === this.tmDetails.locationName
      )?.locationId,

      oldSOWNumber: this.tmDetails.oldSOWNumber,
      sowNumber: this.tmDetails.sowNumber,
      sowName: this.tmDetails.sowName,

      sowtypeId: this.sowTypeDetails.find(
        (item) => item.sowTypeName === this.tmDetails.sowTypeName
      )?.sowTypeId,

      sowstartDate: new Date(this.tmDetails.sowStartDate), // Assuming sowStartDate is a string
      sowEndDate: new Date(this.tmDetails.sowEndDate), // Assuming sowEndDate is a string
      domainName: this.tmDetails.domainName,
      customDomainName: this.tmDetails.customDomainName,
      skillSetId: this.skillSetDetails.find(
        (item) => item.skillSet === this.tmDetails.skillSet
      )?.skillId,

      domainSkillStartDate: new Date(this.tmDetails.domainSkillStartDate), // Assuming domainSkillStartDate is a string
      domainSkillEndDate: new Date(this.tmDetails.domainSkillEndDate), // Assuming domainSkillEndDate is a string
      poNumber: this.tmDetails.poNumber,
      poStartDate: new Date(this.tmDetails.poStartDate), // Assuming poStartDate is a string
      poEndDate: new Date(this.tmDetails.poEndDate), // Assuming poEndDate is a string
      ppmProjectID: this.tmDetails.ppmProjectID,
      ppmProjectName: this.tmDetails.ppmProjectName,
      wbsDetail: this.tmDetails.wbsDetail,

      verticalId: this.verticalDetails.find(
        (item) => item.verticalName === this.tmDetails.verticalName
      )?.verticalId,

      towerId: this.towerNameDetails.find(
        (item) => item.towerName === this.tmDetails.towerName
      )?.towerNameId,

      domainLeadEmail: this.tmDetails.domainLeadEmail,
      costCenter: this.tmDetails.costCenter,

      obs: this.obsDetails.find(
        (item) => item.obsmasterName === this.tmDetails.obs
      )?.obsmasterId,

      projectOrRunId: this.projectOrRunDetails.find(
        (item) => item.projectOrRun === this.tmDetails.projectOrRun
      )?.projectOrRunId,

      contractTypeId: this.contractTypeDetails.find(
        (item) => item.contractTypeName === this.tmDetails.contractTypeName
      )?.contractTypeId,

      billingTypeId: this.billingTypeDetails.find(
        (item) => item.billingTypeName === this.tmDetails.billingTypeName
      )?.billingTypeId,

      currency: this.tmDetails.currency,
      billingRateYear1: this.tmDetails.billingRateYear1,
      billingRateYear2: this.tmDetails.billingRateYear2,
      billingRateYear3: this.tmDetails.billingRateYear3,
      billingRateYear4: this.tmDetails.billingRateYear4,
      billingRateYear5: this.tmDetails.billingRateYear5,
      remappedMID: this.tmDetails.remappedMID,
      sapCode: this.tmDetails.sapCode,
      noticePeriod: this.tmDetails.noticePeriod,
      pendingWithWhom: this.tmDetails.pendingWithWhom,
    });
  }

  onTmDetailsSubmit() {
    this.tmDetailsform.get('contractTypeId').enable();

    const Data = this.tmDetailsform.value;
    const tmData = {} as itmEditedDetails;

    tmData.updatedBy = '';
    tmData.updatedDate = new Date();
    tmData.remarks = Data.remarks;
    // if(Data.remarks.toString().trim().length==0)
    // {
    //   tmData.remarks=null;
    // }

    if(this.EditSowDtsTmTrackScreen)
    {
      tmData.sowname = Data.sowName;
      //  tmData.sowname = this.tmDetails.sowName;
      tmData.sowstartDate = new Date(Data.sowstartDate);
      tmData.sowendDate = new Date(Data.sowEndDate);
      //  tmData.sowstartDate = new Date(this.tmDetails.sowStartDate);
      //  tmData.sowendDate = new Date(this.tmDetails.sowEndDate);

      tmData.ponumber = Data.poNumber;
      //  tmData.ponumber = this.tmDetails.poNumber;

      tmData.postartDate = Data.poStartDate;
      tmData.poendDate = Data.poEndDate;
      //  tmData.postartDate = this.tmDetails.poStartDate;
      //  tmData.poendDate = this.tmDetails.poEndDate;

      tmData.ppmProjectID = Data.ppmProjectID;
      //  tmData.ppmProjectID = this.tmDetails.ppmProjectID;

      tmData.ppmprojectName = Data.ppmProjectName;
      //  tmData.ppmprojectName = this.tmDetails.ppmProjectName;

      tmData.wbsdetail = Data.wbsDetail;
      //  tmData.wbsdetail = this.tmDetails.wbsDetail;

      tmData.costCenter = Data.costCenter;
      //  tmData.costCenter = this.tmDetails.costCenter;

      tmData.obs = this.obsDetails.find(
      (item) => item.obsmasterId === Data.obs
      )?.obsmasterName;
      //  tmData.obs =  this.tmDetails.obs;

      tmData.projectOrRunId = Data.projectOrRunId;  
      //  const projectOrRunId = this.projectOrRunDetails.find(
      //    (item) => item.projectOrRun === this.tmDetails.projectOrRun
      //  )?.projectOrRunId;

      //  if (projectOrRunId !== undefined) {
      //      tmData.projectOrRunId= Number(projectOrRunId);
      //  } else {
      //    tmData.projectOrRunId = 0;
      //  }

      tmData.billingTypeId = Data.billingTypeId;
      //  const btypeid = this.billingTypeDetails.find(
      //    (item) => item.billingTypeName === this.tmDetails.billingTypeName
      //  )?.billingTypeId;

      //  if (btypeid !== undefined) {
      //    tmData.billingTypeId = Number(btypeid);
      //  } else {
      //    tmData.billingTypeId = 0;
      //  }

      tmData.sapcode = Data.sapCode;
      //  tmData.sapcode = this.tmDetails.sapCode;

      tmData.noticePeriod = Data.noticePeriod;
      //  tmData.noticePeriod = this.tmDetails.noticePeriod;

      //Below fields 
      tmData.tmvcmid = this.tmDetails.tmvcmid;
      tmData.tmcmid = this.tmDetails.tmcmid;
      tmData.etwid = this.tmDetails.etwid;
      // tmData.vendorId = 0;
      const vendorId = this.vendorDetails.find(
      (item) => item.vendorName === this.tmDetails.vendorName
      )?.vendorId;

      if (vendorId !== undefined) {
      tmData.vendorId= Number(vendorId);
      } else {
      tmData.vendorId = 0;
      }

      // tmData.sowtypeId = 0;
      const sowtypeId = this.sowTypeDetails.find(
      (item) => item.sowTypeName === this.tmDetails.sowTypeName
      )?.sowTypeId;

      if (sowtypeId !== undefined) {
      tmData.sowtypeId= Number(sowtypeId);
      } else {
      tmData.sowtypeId = 0;
      }

      // tmData.contractTypeId = 0;
      const contractTypeId = this.contractTypeDetails.find(
      (item) => item.contractTypeName === this.tmDetails.contractTypeName
      )?.contractTypeId;

      if (contractTypeId !== undefined) {
      tmData.contractTypeId= Number(contractTypeId);
      } else {
      tmData.contractTypeId = 0;
      }

      //  tmData.verticalId = 0;
      //  tmData.verticalId = Data.verticalId;
      const vendorId_ = this.vendorDetails.find(
      (item) => item.vendorName === this.tmDetails.vendorName
      )?.vendorId;

      if (vendorId_ !== undefined) {
      tmData.vendorId= Number(vendorId_);
      } else {
      tmData.vendorId = 0;
      }

      //  tmData.towerId = 0;
      //  tmData.towerId = Data.towerId;
      const towerId_ = this.towerNameDetails.find(
      (item) => item.towerName === this.tmDetails.towerName
      )?.towerNameId;

      if (towerId_ !== undefined) {
      tmData.towerId= Number(towerId_);
      } else {
      tmData.towerId = 0;
      }


      //  tmData.skillSetId = 0;
      //  tmData.skillSetId = Data.skillSetId;
      const skillSetId_ = this.skillSetDetails.find(
      (item) => item.skillSet === this.tmDetails.skillSet
      )?.skillId;

      if (skillSetId_ !== undefined) {
      tmData.skillSetId= Number(skillSetId_);
      } else {
      tmData.skillSetId = 0;
      }

      //  tmData.positionLocationId = 0;
      const positionLocationId = this.locationDetails.find(
      (item) => item.locationName === this.tmDetails.locationName
      )?.locationId;

      if (positionLocationId !== undefined) {
      tmData.positionLocationId= Number(positionLocationId);
      } else {
      tmData.positionLocationId = 0;
      }

      tmData.sownumber = this.tmDetails.sowNumber;
      tmData.oldSownumber = this.tmDetails.oldSOWNumber;
      tmData.domainLeadEmail = this.tmDetails.domainLeadEmail;
      tmData.customDomainName = this.tmDetails.customDomainName;
      tmData.domainName = this.tmDetails.domainName;
      tmData.domainSkillStartDate = this.tmDetails.domainSkillStartDate;
      tmData.domainSkillEndDate = this.tmDetails.domainSkillEndDate;
      tmData.currency = this.tmDetails.currency;
      tmData.billingRateYear1 = this.tmDetails.billingRateYear1;
      tmData.billingRateYear2 = this.tmDetails.billingRateYear2;
      tmData.billingRateYear3 = this.tmDetails.billingRateYear3;
      tmData.billingRateYear4 = this.tmDetails.billingRateYear4;
      tmData.billingRateYear5 = this.tmDetails.billingRateYear5;

      tmData.positionCode = this.tmDetails.positionCode;

      tmData.remappedMid = this.tmDetails.remappedMID;
      tmData.status = this.tmDetails.status;
      tmData.pendingWithWhom = this.tmDetails.pendingWithWhom;
      tmData.wforder = this.tmDetails.wfOrder;
      tmData.isActive = this.tmDetails.isActive;
      tmData.uploadedBy = this.tmDetails.uploadedBy;
      tmData.uploadedDate = this.tmDetails.uploadedDate;
    }
    else if(this.EditFromTmTrackScreen)
    {
        // tmData.sowname = Data.sowName;
        tmData.sowname = this.tmDetails.sowName;
        // tmData.sowstartDate = new Date(Data.sowstartDate);
        // tmData.sowendDate = new Date(Data.sowEndDate);
        tmData.sowstartDate = new Date(this.tmDetails.sowStartDate);
        tmData.sowendDate = new Date(this.tmDetails.sowEndDate);

        // tmData.ponumber = Data.poNumber;
        tmData.ponumber = this.tmDetails.poNumber;

        // tmData.postartDate = Data.poStartDate;
        // tmData.poendDate = Data.poEndDate;
        tmData.postartDate = this.tmDetails.poStartDate;
        tmData.poendDate = this.tmDetails.poEndDate;

        // tmData.ppmProjectID = Data.ppmProjectID;
        tmData.ppmProjectID = this.tmDetails.ppmProjectID;

        // tmData.ppmprojectName = Data.ppmProjectName;
        tmData.ppmprojectName = this.tmDetails.ppmProjectName;

        // tmData.wbsdetail = Data.wbsDetail;
        tmData.wbsdetail = this.tmDetails.wbsDetail;

        //tmData.costCenter = Data.costCenter;
        tmData.costCenter = this.tmDetails.costCenter;

        // tmData.obs = this.obsDetails.find(
        // (item) => item.obsmasterId === Data.obs
        // )?.obsmasterName;
        tmData.obs =  this.tmDetails.obs;

        // tmData.projectOrRunId = Data.projectOrRunId;  
        const projectOrRunId = this.projectOrRunDetails.find(
          (item) => item.projectOrRun === this.tmDetails.projectOrRun
        )?.projectOrRunId;
        
        if (projectOrRunId !== undefined) {
            tmData.projectOrRunId= Number(projectOrRunId);
        } else {
          tmData.projectOrRunId = 0;
        }

        // tmData.billingTypeId = Data.billingTypeId;
        const btypeid = this.billingTypeDetails.find(
          (item) => item.billingTypeName === this.tmDetails.billingTypeName
        )?.billingTypeId;
  
        if (btypeid !== undefined) {
          tmData.billingTypeId = Number(btypeid);
        } else {
          tmData.billingTypeId = 0;
        }

        // tmData.sapcode = Data.sapCode;
        tmData.sapcode = this.tmDetails.sapCode;
        // tmData.noticePeriod = Data.noticePeriod;
        tmData.noticePeriod = this.tmDetails.noticePeriod;
        //Below fields 
        tmData.tmvcmid = this.tmDetails.tmvcmid;
        tmData.tmcmid = this.tmDetails.tmcmid;
        tmData.etwid = this.tmDetails.etwid;
        // tmData.vendorId = 0;
        const vendorId = this.vendorDetails.find(
          (item) => item.vendorName === this.tmDetails.vendorName
        )?.vendorId;
        
        if (vendorId !== undefined) {
            tmData.vendorId= Number(vendorId);
        } else {
          tmData.vendorId = 0;
        }

        // tmData.sowtypeId = 0;
        const sowtypeId = this.sowTypeDetails.find(
          (item) => item.sowTypeName === this.tmDetails.sowTypeName
        )?.sowTypeId;
        
        if (sowtypeId !== undefined) {
            tmData.sowtypeId= Number(sowtypeId);
        } else {
          tmData.sowtypeId = 0;
        }

        // tmData.contractTypeId = 0;
        const contractTypeId = this.contractTypeDetails.find(
          (item) => item.contractTypeName === this.tmDetails.contractTypeName
        )?.contractTypeId;
        
        if (contractTypeId !== undefined) {
            tmData.contractTypeId= Number(contractTypeId);
        } else {
          tmData.contractTypeId = 0;
        }

        // tmData.verticalId = 0;
        tmData.verticalId = Data.verticalId;

        // tmData.towerId = 0;
        tmData.towerId = Data.towerId;

        // tmData.skillSetId = 0;
        tmData.skillSetId = Data.skillSetId;

        // tmData.positionLocationId = 0;
        const positionLocationId = this.locationDetails.find(
          (item) => item.locationName === this.tmDetails.locationName
        )?.locationId;
        
        if (positionLocationId !== undefined) {
            tmData.positionLocationId= Number(positionLocationId);
        } else {
          tmData.positionLocationId = 0;
        }

        tmData.sownumber = this.tmDetails.sowNumber;
        tmData.oldSownumber = Data.oldSOWNumber;
        tmData.domainLeadEmail = Data.domainLeadEmail;
        tmData.customDomainName = Data.customDomainName;
        tmData.domainName = Data.domainName;
        tmData.domainSkillStartDate = Data.domainSkillStartDate;
        tmData.domainSkillEndDate = Data.domainSkillEndDate;
        tmData.currency = Data.currency;
        tmData.billingRateYear1 = Data.billingRateYear1;
        tmData.billingRateYear2 = Data.billingRateYear2;
        tmData.billingRateYear3 = Data.billingRateYear3;
        tmData.billingRateYear4 = Data.billingRateYear4;
        tmData.billingRateYear5 = Data.billingRateYear5;

        tmData.positionCode = this.tmDetails.positionCode;
        
        tmData.remappedMid = this.tmDetails.remappedMID;
        tmData.status = this.tmDetails.status;
        tmData.pendingWithWhom = this.tmDetails.pendingWithWhom;
        tmData.wforder = this.tmDetails.wfOrder;
        tmData.isActive = this.tmDetails.isActive;
        tmData.uploadedBy = this.tmDetails.uploadedBy;
        tmData.uploadedDate = this.tmDetails.uploadedDate;
    }
    else
    {
      
      tmData.tmvcmid = this.tmDetails.tmvcmid;
      tmData.tmcmid = this.tmDetails.tmcmid;
      tmData.etwid = Data.etwid;
      tmData.vendorId = Data.vendorId;
      tmData.sowtypeId = Data.sowtypeId;
      tmData.contractTypeId = Data.contractTypeId;
      tmData.verticalId = Data.verticalId;
      tmData.towerId = Data.towerId;
      
      tmData.skillSetId = Data.skillSetId;


      tmData.domainLeadEmail = Data.domainLeadEmail;
      tmData.customDomainName = Data.customDomainName;
      tmData.domainName = Data.domainName;
      tmData.domainSkillStartDate = Data.domainSkillStartDate;
      tmData.domainSkillEndDate = Data.domainSkillEndDate;
      tmData.currency = Data.currency;
      tmData.billingRateYear1 = Data.billingRateYear1;
      tmData.billingRateYear2 = Data.billingRateYear2;
      tmData.billingRateYear3 = Data.billingRateYear3;
      tmData.billingRateYear4 = Data.billingRateYear4;
      tmData.billingRateYear5 = Data.billingRateYear5;
      tmData.positionLocationId = Data.positionLocationId;
      tmData.positionCode = Data.positionCode;
      tmData.oldSownumber = Data.oldSOWNumber;
      tmData.remappedMid = Data.remappedMID;
      tmData.status = this.tmDetails.status;
      tmData.pendingWithWhom = this.tmDetails.pendingWithWhom;
      tmData.wforder = this.tmDetails.wfOrder;
      tmData.isActive = this.tmDetails.isActive;
      tmData.uploadedBy = this.tmDetails.uploadedBy;
      tmData.uploadedDate = this.tmDetails.uploadedDate;
      //Below fields are editable in TM track screen
      tmData.sownumber = Data.sowNumber;
      tmData.sowname = this.tmDetails.sowName;
      tmData.sowstartDate = new Date(this.tmDetails.sowStartDate);
      tmData.sowendDate = new Date(this.tmDetails.sowEndDate);
      tmData.ponumber = this.tmDetails.poNumber;
      tmData.postartDate = this.tmDetails.poStartDate;
      tmData.poendDate = this.tmDetails.poEndDate;
      tmData.ppmProjectID = this.tmDetails.ppmProjectID;
      tmData.ppmprojectName = this.tmDetails.ppmProjectName;
      tmData.wbsdetail = this.tmDetails.wbsDetail;
      tmData.costCenter = this.tmDetails.costCenter;
      tmData.obs =  this.tmDetails.obs;

      const projectOrRunId = this.projectOrRunDetails.find(
        (item) => item.projectOrRun === this.tmDetails.projectOrRun
      )?.projectOrRunId;
      
      if (projectOrRunId !== undefined) {
          tmData.projectOrRunId= Number(projectOrRunId);
      } else {
        tmData.projectOrRunId = 0;
      }

      const btypeid = this.billingTypeDetails.find(
        (item) => item.billingTypeName === this.tmDetails.billingTypeName
      )?.billingTypeId;

      if (btypeid !== undefined) {
        tmData.billingTypeId = Number(btypeid);
      } else {
        tmData.billingTypeId = 0;
      }

      tmData.sapcode = this.tmDetails.sapCode;
      tmData.noticePeriod = this.tmDetails.noticePeriod;
    }

    this.tmDetailsform.get('contractTypeId').disable();

    if(this.EditSowDtsTmTrackScreen && this.tmDetailsform.valid)
    {
      this.tmUpload.updateTMApprovedSowDtsContractDetails(tmData).subscribe({
        next: (response) => {
          if (response != '' && response != 'Contract saved successfully') {
            this.validationRemarks = response;
          } else {
            this.ref.close(response);
          }
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to save T&M Details.',
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });
    }
    else if(this.EditFromTmTrackScreen && this.tmDetailsform.valid)
    {
      this.tmUpload.updateTMApprovedContractDetails(tmData).subscribe({
        next: (response) => {
          if (response != '' && response != 'Contract saved successfully') {
            this.validationRemarks = response;
          } else {
            this.ref.close(response);
          }
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to save T&M Details.',
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });
    }
    else if (this.tmDetailsform.valid) {
       this.tmUpload.updateTMContractDetails(tmData).subscribe({
        next: (response) => {
          if (response != '' && response != 'Contract saved successfully') {
            this.validationRemarks = response;
          } else {
            this.ref.close(response);
          }
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to save T&M Details.',
          });
          setTimeout(() => {
            this.messageService.clear();
          }, 3000);
        },
      });
    }
    else {
      const invalid = [];
      const controls = this.tmDetailsform.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
      this.validationRemarks = ' Invalid/Empty ' + invalid.toString() + ' Fields.';
    }
  }

  DisableFieldsForTmTrackScreen(): void {
    const formControls = this.tmDetailsform.controls;

    // formControls['contractTypeId'].disable();
    // formControls['contractTypeId'].enable();

    formControls['etwid'].disable();
    formControls['positionCode'].disable();
    formControls['vendorId'].disable();
    formControls['positionLocationId'].disable();
    formControls['sowNumber'].disable();
    formControls['sowtypeId'].disable();
    formControls['remappedMID'].disable();
    formControls['pendingWithWhom'].disable();
    // formControls['remarks'].disable();

    if(this.EditSowDtsTmTrackScreen)
    {
      //orange columns
      formControls['oldSOWNumber'].disable();
      formControls['customDomainName'].disable();
      formControls['domainName'].disable();
      formControls['skillSetId'].disable();
      formControls['domainSkillStartDate'].disable();
      formControls['domainSkillEndDate'].disable();
      formControls['currency'].disable();
      formControls['billingRateYear1'].disable();
      formControls['billingRateYear2'].disable();
      formControls['billingRateYear3'].disable();
      formControls['billingRateYear4'].disable();
      formControls['billingRateYear5'].disable();
      formControls['verticalId'].disable();
      formControls['towerId'].disable();
      formControls['domainLeadEmail'].disable();
      //green columns
      // formControls['sowName'].disable();
      // formControls['sowstartDate'].disable();
      // formControls['sowEndDate'].disable();
      // formControls['poNumber'].disable();
      // formControls['poStartDate'].disable();
      // formControls['poEndDate'].disable();
      // formControls['ppmProjectID'].disable();
      // formControls['ppmProjectName'].disable();
      // formControls['wbsDetail'].disable();
      // formControls['costCenter'].disable();
      // formControls['obs'].disable();
      // formControls['projectOrRunId'].disable();    
      // formControls['billingTypeId'].disable();
      // formControls['sapCode'].disable();
      // formControls['noticePeriod'].disable();
    }
    else
    {
      //orange columns
      // formControls['oldSOWNumber'].disable();
      // formControls['customDomainName'].disable();
      // formControls['domainName'].disable();
      // formControls['skillSetId'].disable();
      // formControls['domainSkillStartDate'].disable();
      // formControls['domainSkillEndDate'].disable();
      // formControls['currency'].disable();
      // formControls['billingRateYear1'].disable();
      // formControls['billingRateYear2'].disable();
      // formControls['billingRateYear3'].disable();
      // formControls['billingRateYear4'].disable();
      // formControls['billingRateYear5'].disable();
      // formControls['verticalId'].disable();
      // formControls['towerId'].disable();
      // formControls['domainLeadEmail'].disable();
      //green columns
      formControls['sowName'].disable();
      formControls['sowstartDate'].disable();
      formControls['sowEndDate'].disable();
      formControls['poNumber'].disable();
      formControls['poStartDate'].disable();
      formControls['poEndDate'].disable();
      formControls['ppmProjectID'].disable();
      formControls['ppmProjectName'].disable();
      formControls['wbsDetail'].disable();
      formControls['costCenter'].disable();
      formControls['obs'].disable();
      formControls['projectOrRunId'].disable();    
      formControls['billingTypeId'].disable();
      formControls['sapCode'].disable();
      formControls['noticePeriod'].disable();
    }

    
  }
  getButtonLabel(): string {
    return this.ShowSbHeader ? 'Resubmit' : 'Submit';
  }

}
