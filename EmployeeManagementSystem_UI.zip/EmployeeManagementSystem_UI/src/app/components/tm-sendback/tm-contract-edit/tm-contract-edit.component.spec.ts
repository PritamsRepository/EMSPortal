import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmContractEditComponent } from './tm-contract-edit.component';

describe('TmContractEditComponent', () => {
  let component: TmContractEditComponent;
  let fixture: ComponentFixture<TmContractEditComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmContractEditComponent]
    });
    fixture = TestBed.createComponent(TmContractEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
