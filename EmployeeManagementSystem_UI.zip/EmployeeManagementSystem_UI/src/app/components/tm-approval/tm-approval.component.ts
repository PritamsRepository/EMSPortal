import { Component, OnInit } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { TmApprovalService } from 'src/app/core/services/contract-approval/tm-approval.service';
import { tmApproval } from 'src/app/core/interfaces/Itm-approval';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule, Routes } from '@angular/router';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-tm-approval',
  templateUrl: './tm-approval.component.html',
  styleUrls: ['./tm-approval.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class TmApprovalComponent implements OnInit {
  constructor(
    private tmApprovalService: TmApprovalService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    private router: Router
  ) {
    /* this.isRowSelectable = this.isRowSelectable.bind(this); */
  }

  tmapprovaldetails!: tmApproval[];
  tmapprovaldetail!: tmApproval;
  cols: any[] = [];
  selectedDetails!: any[] | null;
  isvalid: boolean = false;
  inValidrecord!: tmApproval | null;
  errorMessage!: string | null;

  ref: DynamicDialogRef | undefined;

  isapprovechecked: boolean = false;
  isrejectchecked: boolean = false;
  totalApproved: number = 0;
  totalRejected: number = 0;
  pageTitle: string = 'Time & Material Pending List';

  ngOnInit() {
    this.getTmContractDetails();
    //console.log('test');
    this.cols = [
      { field: 'isSelectedApproval', header: 'Approve' },
      { field: 'selectedRejectedlist', header: 'Reject' },
      { field: 'tmcmid', header: 'TMVCMID' },
      { field: 'tmvcmid', header: 'TMVCMID' },
      { field: 'etwid', header: 'ETWID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowType', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date' },
      { field: 'sowEndDate', header: 'SOW End Date' },
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date' },
      { field: 'poEndDate', header: 'PO End Date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'tower', header: 'Tower' },
      { field: 'customDomainName', header: 'Domain Name' },
      { field: 'domainName', header: 'Domain Skill Name' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'domainSkillStartDate', header: 'Domain Skill Start Date' },
      { field: 'domainSkillEndDate', header: 'Domain Skill End Date' },
      { field: 'contractType', header: 'Contract Type' },
      { field: 'billingType', header: 'Billing Type' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },
      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'noticePeriod', header: 'Notice Period' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'positionLocation', header: 'Managing Team' },

      { field: 'oldSowNumber', header: 'Old SOW Number' },
      { field: 'remappedMID', header: 'Existing MID' },
    ];
  }
  getTmContractDetails() {
    this.tmApprovalService.getapprovaldata().subscribe((result) => {
      //console.log(result);
      this.tmapprovaldetails = result;
    });
    //console.log('check');
  }
  // Reject --> SendBack
  selectApproveAll() {
    this.tmapprovaldetails.forEach((x) => (x.isSelectedApproval = true));
    this.isapprovechecked = true;
    this.isrejectchecked = false;
    this.totalApproved = [...this.tmapprovaldetails].length;
    this.totalRejected = 0;

    this.messageService.add({
      severity: 'info',
      summary: 'All contracts sellected for Approval',
    });
  }
  selectApprove(tmapprovaldetail: tmApproval) {
    const aIndex = this.tmapprovaldetails.findIndex(
      (item) => item === tmapprovaldetail
    );
    if (aIndex !== -1) {
      this.totalApproved = this.totalApproved + 1;
      if (this.tmapprovaldetails[aIndex].isSelectedApproval != null) {
        this.totalRejected =
          this.totalRejected == 0 ? 0 : this.totalRejected - 1;
      }
      this.tmapprovaldetails[aIndex].isSelectedApproval = true; // Remove 1 element starting from the index
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;

    this.messageService.add({
      severity: 'info',
      summary: tmapprovaldetail.sowNumber + ' contract selected for Approval',
    });
  }
  selectRejectAll() {
    this.tmapprovaldetails.forEach((x) => (x.isSelectedApproval = false));

    this.totalApproved = 0;
    this.totalRejected = [...this.tmapprovaldetails].length;

    this.isapprovechecked = false;
    this.isrejectchecked = true;

    this.messageService.add({
      severity: 'info',
      summary: 'All contracts selected for SendBack',
    });
  }
  //Click on SendBack
  selectReject(tmapprovaldetail: tmApproval) {
    const aIndex = this.tmapprovaldetails.findIndex(
      (item) => item === tmapprovaldetail
    );
    if (aIndex !== -1) {
      if (this.tmapprovaldetails[aIndex].isSelectedApproval != null) {
        this.totalApproved =
          this.totalApproved == 0 ? 0 : this.totalApproved - 1;
      }
      this.totalRejected = this.totalRejected + 1;
      this.tmapprovaldetails[aIndex].isSelectedApproval = false;
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;

    this.messageService.add({
      severity: 'info',
      summary: tmapprovaldetail.sowNumber + ' contract selected for SendBack',
    });
  }
  // Click on Submit Button
  submitAction() {
    //If action not taken
    const aIndex = this.tmapprovaldetails.find(
      (item) => item.isSelectedApproval === null
    );
    if (aIndex !== null && aIndex != undefined) {
      this.inValidrecord = aIndex as tmApproval;
      this.errorMessage = 'Please take action on contract (ETWID):';
      this.confirmationService.confirm({
        accept: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
        reject: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
      });
      return;
    }
    //If Reject not having remarks
    const remarks = this.tmapprovaldetails.find(
      (item) =>
        item.isSelectedApproval === false &&
        (item.remarks === '' || item.remarks === null)
    );
    if (remarks !== null && remarks != undefined) {
      this.inValidrecord = remarks as tmApproval;
      this.errorMessage =
        'Please provide remarks for Sendback contract (ETWID):';
      this.confirmationService.confirm({
        reject: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
      });
      return;
    }
    this.tmApprovalService
      .postApproval(this.tmapprovaldetails)
      .subscribe((result) => {
        //console.log(result);
        this.getTmContractDetails();
        if (result.message === 'success')
          this.messageService.add({
            severity: 'info',
            summary: 'Contracts Approved/Sentback Successfully!',
          });
        // this.router.navigate(['/main/tmApproval']);
        this.getTmContractDetails;
        this.totalApproved = 0;
        this.totalRejected = 0;
      });
  }
  ExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    const filteredContractList = this.tmapprovaldetails.map((contract) => {
      // Create a new object to hold the properties in the desired order
      return {
        etwid: contract.etwid,
        PositionCode: contract.positionCode,
        vendorName: contract.vendorName,
        sowNumber: contract.sowNumber,
        sowName: contract.sowName,
        sowType: contract.sowType,
        sowStartDate: contract.sowStartDate
          ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
          : '',
        sowEndDate: contract.sowEndDate
          ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
          : '',
        poNumber: contract.poNumber,
        poStartDate: contract.poStartDate
          ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
          : '',
        poEndDate: contract.poEndDate
          ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
          : '',
        contractType: contract.contractType,
        projectOrRun: contract.projectOrRun,
        ppmProjectID:contract.ppmProjectID,
        ppmProjectName: contract.ppmProjectName,
        tower: contract.tower,
        vertical: contract.vertical,
        wbsDetail: contract.wbsDetail,
        domainLeadEmail: contract.domainLeadEmail,
        domainName: contract.domainName,
        currency: contract.currency,
        positionLocation: contract.positionLocation,
        oldSowNumber: contract.oldSowNumber,
        sapCode: contract.sapCode,
        obs: contract.obs,
        noticePeriod: contract.noticePeriod,
        status: contract.status,
        Pendingwithwhom: contract.Pendingwithwhom,
        DomainSkillName: contract.domainName,
        skillSet: contract.skillSet,
        domainSkillStartDate: contract.domainSkillStartDate
          ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
          : '',
        domainSkillEndDate: contract.domainSkillEndDate
          ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
          : '',
        BillingType: contract.billingType,
        RemappedMID: contract.remappedMID,
        billingRateYear1: contract.billingRateYear1,
        billingRateYear2: contract.billingRateYear2,
        billingRateYear3: contract.billingRateYear3,
        billingRateYear4: contract.billingRateYear4,
        billingRateYear5: contract.billingRateYear5,
      };
    });

    // Convert the filteredContractList to a worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'T&M Contract Pending List.xlsx');
  }
}
