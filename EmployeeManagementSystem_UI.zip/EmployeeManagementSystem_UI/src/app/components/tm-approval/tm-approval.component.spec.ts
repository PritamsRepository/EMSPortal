import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmApprovalComponent } from './tm-approval.component';

describe('TmApprovalComponent', () => {
  let component: TmApprovalComponent;
  let fixture: ComponentFixture<TmApprovalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmApprovalComponent]
    });
    fixture = TestBed.createComponent(TmApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
