import { Component, OnInit } from '@angular/core';
import { Roletypemapping } from 'src/app/core/interfaces/roletypemapping';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { LocationAndRoleMaster } from 'src/app/core/interfaces/location-and-role-master';
import { IDropDownKeyValue } from 'src/app/core/interfaces/idropdown-key-value';
import { RoleTypeMappingService } from 'src/app/core/services/role-type-mapping/role-type-mapping.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

interface City {
  name: string;
  code: string;
}
interface roletype {
  name: string;
  code: string;
}
@Component({
  selector: 'app-employeerolemapping',
  templateUrl: './employeerolemapping.component.html',
  styleUrls: ['./employeerolemapping.component.css'],
  providers: [ConfirmationService, MessageService],
})
export class EmployeerolemappingComponent implements OnInit {
  pageTitle: string = 'Employee Role Mapping';
  myForm!: FormGroup;
  employeedata!: Roletypemapping[];
  public searchInput: string = '';
  roletypemaster!: IDropDownKeyValue[];
  locationmaster!: IDropDownKeyValue[];
  selectedRoleType!: any;
  selectedLocation!: [];
  EmpSearchData!: LocationAndRoleMaster[];
  loading: boolean = true;
  Error: Boolean = true;
  searchMID: any;
  searchName: any;
  searchMail: any;
  IsPrimary: boolean = false;
  IsPrimaryResponsible!: boolean;
  UserName!: string;
  LocationId!: number;

  constructor(
    private RoleTypeMappingService: RoleTypeMappingService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private readonly _storageService: StorageService
  ) {}
  ngOnInit() {
    this.UserName = this._storageService.getCurrentUserMID();
    this.LocationId = Number(this._storageService.getCurrentUserLocationID());
    this.GetEmpRoleMappingData(this.UserName, this.LocationId);
  }
  GetEmpRoleMappingData(UserName: string, LocationID: number) {
    this.RoleTypeMappingService.GetEmpRoleMappingData(
      UserName,
      LocationID
    ).subscribe((result) => {
      // //console.log('mapping res : ', result);
      this.employeedata = this.sortEmployeeData(result);
      this.loading = false;
    });
  }

  // Function to sort employee data
  sortEmployeeData(data: any[]): any[] {
    // Use the Array.sort method to sort based on Location, RoleType, and Name
    return data.sort((a, b) => {
      // Compare by Location
      const locationComparison = a.locationName.localeCompare(b.locationName);
      if (locationComparison !== 0) {
        return locationComparison;
      }

      // Compare by RoleType
      const roleTypeComparison = a.roleTypeName.localeCompare(b.roleTypeName);
      if (roleTypeComparison !== 0) {
        return roleTypeComparison;
      }

      // Compare by Name
      return a.name.localeCompare(b.name);
    });
  }

  visible: boolean = false;
  showDialog() {
    this.visible = true;
    this.selectedLocation = null;
    this.selectedRoleType = null;
    this.searchInput = null;
    this.searchName = null;
    this.searchMID = null;
    this.searchMail = null;
    this.IsPrimaryResponsible = null;
    this.getLocAndRoleDetails();
  }
  getLocAndRoleDetails() {
    this.RoleTypeMappingService.getLocAndRoleDetails(
      this._storageService.getCurrentUserMID()
    ).subscribe({
      next: (data) => {
        this.roletypemaster = data.roleType;
        this.locationmaster = data.locationMaster;
      },
    });
  }
  hideDialog() {
    this.visible = false;
  }
  validateData(): boolean {
    const txtmidValue = (document.getElementById('txtmid') as HTMLInputElement)
      .value;
    const txtnameValue = (
      document.getElementById('txtname') as HTMLInputElement
    ).value;
    const txtemailValue = (
      document.getElementById('txtemail') as HTMLInputElement
    ).value;
    const selectedrole = this.selectedRoleType;
    var data = false;
    if (
      txtmidValue.trim() === '' ||
      txtnameValue.trim() === '' ||
      txtemailValue.trim() === '' ||
      this.selectedRoleType == null ||
      this.selectedLocation == null
    ) {
      this.Error = false;
      data = false;
    } else {
      this.Error = true;
      data = true;
    }

    return data;
  }
  closeModal() {
    window.location.reload();
  }
  SearchEmpDetails(UserName: string) {
    this.RoleTypeMappingService.getEmployeeSearchdetails(UserName).subscribe(
      (result) => {
        this.searchMID = result.mid;
        this.searchName = result.displayName;
        this.searchMail = result.email;
      }
    );
  }
  SaveData() {
    const rtype = {} as Roletypemapping;
    if (this.validateData()) {
      rtype.roleTypeName = this.selectedRoleType;
      rtype.selectedLocation = this.selectedLocation;
      //console.log(rtype.selectedLocation);
      rtype.mid = this.searchMID;
      rtype.emailId = this.searchMail;
      rtype.name = this.searchName;
      rtype.isActive = true;
      rtype.isPrimary = this.IsPrimaryResponsible;
      this.RoleTypeMappingService.SaveRoleMappingDetails(rtype).subscribe(
        (result) => {
          //console.log(result);
          this.GetEmpRoleMappingData(this.UserName, this.LocationId);
          this.visible = false;
        }
      );
    }
  }

  DeactivateRecord(event: Event, roleTypeID: number, isPrimary: boolean) {
    if (isPrimary) {
      this.GetEmpRoleMappingData(this.UserName, this.LocationId);
      this.messageService.add({
        severity: 'warn',
        detail: 'Record with Prime responsible cannot be deactivated.',
      });
    } else {
      this.confirmationService.confirm({
        target: event.target as EventTarget,
        message: 'Are you sure that you want to deactivate this record?',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.RoleTypeMappingService.DeactivateRoleMappingDetailsByID(
            roleTypeID
          ).subscribe((validatedata: boolean) => {
            if (validatedata) {
              this.GetEmpRoleMappingData(this.UserName, this.LocationId);
            } else {
              this.GetEmpRoleMappingData(this.UserName, this.LocationId);
              this.messageService.add({
                severity: 'warn',
                detail: 'Record Deactivated.',
              });
            }
          });
        },
        reject: () => {},
      });
    }
  }
  ActivateRecord(event: Event, roleTypeID: number) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Are you sure that you want to activate this record?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.RoleTypeMappingService.DeactivateRoleMappingDetailsByID(
          roleTypeID
        ).subscribe((validatedata: boolean) => {
          if (validatedata) {
            this.GetEmpRoleMappingData(this.UserName, this.LocationId);
          } else {
            this.GetEmpRoleMappingData(this.UserName, this.LocationId);
            this.messageService.add({
              severity: 'success',
              detail: 'Record Activated.',
            });
          }
        });
      },
      reject: () => {},
    });
  }

  Primary(
    event: Event,
    roleTypeID: number,
    IsPrimary: boolean,
    IsActive: boolean
  ) {
    if (!IsActive && !IsPrimary) {
      this.GetEmpRoleMappingData(this.UserName, this.LocationId);
      this.messageService.add({
        severity: 'warn',
        detail:
          'Deactivated record cannot be assigned with primary responsibility.',
      });
    } else {
      this.RoleTypeMappingService.PrimaryRoleMappingDetailsByID(
        roleTypeID
      ).subscribe((validatedata: boolean) => {
        if (validatedata) {
          this.GetEmpRoleMappingData(this.UserName, this.LocationId);
        } else {
          this.GetEmpRoleMappingData(this.UserName, this.LocationId);
          this.messageService.add({
            severity: 'warn',
            summary: 'Warning',
            detail: 'One record should be primary.',
          });
        }
      });
    }
  }
}
