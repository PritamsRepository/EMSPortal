import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeerolemappingComponent } from './employeerolemapping.component';

describe('EmployeerolemappingComponent', () => {
  let component: EmployeerolemappingComponent;
  let fixture: ComponentFixture<EmployeerolemappingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeerolemappingComponent]
    });
    fixture = TestBed.createComponent(EmployeerolemappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
