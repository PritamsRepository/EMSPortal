import { Component } from '@angular/core';

@Component({
  selector: 'app-roletype',
  templateUrl: './roletype.component.html',
  styleUrls: ['./roletype.component.css']
})
export class RoletypeComponent {

}
