import { Component , OnInit} from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-amsmaster',
  templateUrl: './amsmaster.component.html',
  styleUrls: ['./amsmaster.component.css']
})
export class AmsmasterComponent implements OnInit  {
  url: string;
  urlSafe: SafeResourceUrl;
  routeReuseStrategy: any;
  // url: string = 'http://localhost:54230/LogOn.aspx';
 
  constructor(public sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private router: Router) { 
      this.routeReuseStrategy = this.router.routeReuseStrategy.shouldReuseRoute;
      this.router.routeReuseStrategy.shouldReuseRoute = () => false; 
 
    }

  ngOnInit() {
 
 
    this.url = this.route.snapshot.paramMap.get('urlParameter'); 
    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);


  }

}
