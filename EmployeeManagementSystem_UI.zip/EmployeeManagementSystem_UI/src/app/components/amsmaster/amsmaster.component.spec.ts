import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmsmasterComponent } from './amsmaster.component';

describe('AmsmasterComponent', () => {
  let component: AmsmasterComponent;
  let fixture: ComponentFixture<AmsmasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AmsmasterComponent]
    });
    fixture = TestBed.createComponent(AmsmasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
