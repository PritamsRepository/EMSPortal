import { AfterViewInit, Component } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements AfterViewInit {
  constructor(private readonly _storageService: StorageService) {}
  ngAfterViewInit(): void {
    //this._storageService.navigateBasedOnRole();
  }
}
