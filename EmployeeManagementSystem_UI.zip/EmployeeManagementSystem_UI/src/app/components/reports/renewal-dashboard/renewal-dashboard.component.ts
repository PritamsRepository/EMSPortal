import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as FileSaver from 'file-saver';
import { ConfirmationService, MessageService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { IDropDownKeyValue } from 'src/app/core/interfaces/idropdown-key-value';
import { VendorContractDataByDate } from 'src/app/core/interfaces/vendor-contract-data-by-date';
import { ReportsService } from 'src/app/core/services/reports/reports.service';
import { SharedService } from 'src/app/core/services/shared.service';
import { ContractTypeConstant } from 'src/app/core/utiltz/ContractTypeConstant';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-renewal-dashboard',
  templateUrl: './renewal-dashboard.component.html',
  styleUrls: ['./renewal-dashboard.component.css'],
  providers: [MessageService, ConfirmationService, DialogService, DatePipe],
})

export class RenewalDashboardComponent implements OnInit {

  pageTitle: string = 'Renewal Dashboard';
  allVendorContractsByDate: VendorContractDataByDate[] = [];
  allVendorContractsByDateBackup: VendorContractDataByDate[] = [];
  selectedDetails: VendorContractDataByDate[] = [];
  contractType: { id: string, name: string }[] = [];
  selectedContract: { Id: string } = { Id: ContractTypeConstant.TM };
  cols: any[] = [];
  datePipe = new DatePipe('en-US');
  fieldNames = [
    { fieldName: 'ETWID', displayName: 'ETW ID', column: 'etwid' },
    { fieldName: 'PositionCode', displayName: 'Position Code', column: 'positionCode' },
    { fieldName: 'SOWNumber', displayName: 'SOW Number', column: 'sowNumber' },
    { fieldName: 'SOWName', displayName: 'SOW Name', column: 'sowName' },
    { fieldName: 'SOWStartDate', displayName: 'SOW Start Date', column: 'sowStartDate', type: 'date' },
    { fieldName: 'SOWEndDate', displayName: 'SOW End Date', column: 'sowEndDate', type: 'date' },
    { fieldName: 'VendorName', displayName: 'Vendor Name', column: 'vendorName' },
    { fieldName: 'VerticalName', displayName: 'Vertical Name', column: 'verticalName' },
    { fieldName: 'TowerName', displayName: 'Tower Name', column: 'towerName' },
    { fieldName: 'ContractTypeName', displayName: 'Contract Type', column: 'contractTypeName' },
    { fieldName: 'SkillSet', displayName: 'Skill Set', column: 'skillSet' },
    { fieldName: 'PONumber', displayName: 'PO Number', column: 'poNumber' },
    { fieldName: 'POStartDate', displayName: 'PO Start Date', column: 'poStartDate', type: 'date' },
    { fieldName: 'POEndDate', displayName: 'PO End Date', column: 'poEndDate', type: 'date' },
    { fieldName: 'ProjectOrRunID', displayName: 'Project or Run', column: 'projectOrRunID' },
    { fieldName: 'PPMProjectID', displayName: 'PPM Project ID', column: 'ppmProjectID' },
    { fieldName: 'PPMProjectName', displayName: 'PPM Project Name', column: 'ppmProjectName' },
    { fieldName: 'SowTypeName', displayName: 'Sow Type', column: 'sowTypeName' },
    { fieldName: 'DomainLeadEmail', displayName: 'Domain Lead Email', column: 'domainLeadEmail' },
    { fieldName: 'DomainName', displayName: 'Domain Name', column: 'domainName' },
    { fieldName: 'DomainSkillStartDate', displayName: 'Domain Skill Start Date', column: 'domainSkillStartDate', type: 'date' },
    { fieldName: 'DomainSkillEndDate', displayName: 'Domain Skill End Date', column: 'domainSkillEndDate', type: 'date' },
    { fieldName: 'NoticePeriod', displayName: 'Notice Period Days', column: 'noticePeriod' },
    { fieldName: 'OldSowNumber', displayName: 'Old SOW Number', column: 'oldSowNumber' },
    { fieldName: 'SAPCode', displayName: 'SAP Code', column: 'sapCode' },
    { fieldName: 'CostCenter', displayName: 'Cost Center', column: 'costCenter' },
    { fieldName: 'OBS', displayName: 'OBS', column: 'obs' },
    { fieldName: 'BillingTypeName', displayName: 'Billing Type', column: 'billingTypeName' },
    { fieldName: 'CustomDomainName', displayName: 'Custom Domain Name', column: 'customDomainName' }
  ];

  constructor(
    private messageService: MessageService,
    public sharedService: SharedService,
    public dialogService: DialogService,
    public reportService: ReportsService,
  ) { }

  ngOnInit(): void {
    this.initializeDropdownOptions();
    this.GetAllVendorContractsByDate(ContractTypeConstant.TM);
  }

  GetAllVendorContractsByDate(contractType: string) {
    this.reportService.getAllVendorContractsByDate(contractType).subscribe({
      next: (result: VendorContractDataByDate[]) => {
        if (result.length === 0) {
          this.allVendorContractsByDate = [];
          this.messageService.add({
            severity: 'info',
            summary: 'No Data',
            detail: 'No Contract data found.',
          });
        }
        else {
          this.allVendorContractsByDate = this.formatDataForDates(result);
          this.allVendorContractsByDateBackup = this.formatDataForDates(result);
        }
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch vendor contract data.',
        });
      },
    });
  }

  formatDataForDates(data: VendorContractDataByDate[]): any[] {
    return data.map(item => {
      return {
        ...item,
        sowStartDate: this.formatDate(item.sowStartDate),
        sowEndDate: this.formatDate(item.sowEndDate),
        poStartDate: this.formatDate(item.poStartDate),
        poEndDate: this.formatDate(item.poEndDate),
        domainSkillStartDate: this.formatDate(item.domainSkillStartDate),
        domainSkillEndDate: this.formatDate(item.domainSkillEndDate),
      };
    });
  }

  formatDate(date: Date | string): string {
    if (!date) return 'N/A';
    const dateObj = new Date(date);
    const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    return dateObj.toLocaleDateString('en-GB', options);
  }

  getRowClass(sowEndDate: string): string {
    const now = new Date();
    const endDate = new Date(sowEndDate);
    const timeDiff = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

    if (diffDays <= 30) {
      return 'due-in-30';
    } else if (diffDays <= 60) {
      return 'due-in-60';
    } else if (diffDays <= 90) {
      return 'due-in-90';
    }
    return '';
  }

  ExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    const filteredContractList = this.allVendorContractsByDate.map((contract) => {
      return {
        ETWID: contract.etwid,
        PositionCode: contract.positionCode,
        SOWNumber: contract.sowNumber,
        SOWName: contract.sowName,
        SOWStartDate: contract.sowStartDate
          ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
          : '',
        SOWEndDate: contract.sowEndDate
          ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
          : '',
        VendorName: contract.vendorName,
        VerticalName: contract.verticalName ? contract.verticalName : 'NA',
        TowerName: contract.towerName ? contract.towerName : 'NA',


        ContractType: contract.contractTypeName,
        SkillSet: contract.skillSet,
        PONumber: contract.poNumber,
        POStartDate: contract.poStartDate
          ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
          : '',
        poEndDate: contract.poEndDate
          ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
          : '',
        projectOrRun: contract.projectOrRunID,
        PPMProjectID: contract.ppmProjectID,
        PPMProjectName: contract.ppmProjectName,
        SowTypeName: contract.sowTypeName,
        DomainLeadEmail: contract.domainLeadEmail,
        DomainName: contract.domainName,
        DomainSkillStartDate: contract.domainSkillStartDate
          ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
          : '',
        DomainSkillEndDate: contract.domainSkillEndDate
          ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
          : '',
        NoticePeriod: contract.noticePeriod ? contract.noticePeriod : 'NA',
        OldSowNumber: contract.oldSOWNumber ? contract.oldSOWNumber : 'NA',
        SAPCode: contract.sapCode ? contract.sapCode : 'NA',
        CostCenter: contract.costCenter ? contract.costCenter : 'NA',
        OBS: contract.obs ? contract.obs : 'NA',
        BillingType: contract.billingTypeName,
        CustomDomainName: contract.customDomainName ? contract.customDomainName : 'NA'
      };
    });
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const now = new Date();
    const formattedDate = now.toISOString().replace(/:/g, '.').slice(0, 19);
    const filename = `UpcomingRenewals_${formattedDate}.xlsx`;
    XLSX.writeFile(wb, filename);
  }

  FilterMyData(data: any, typo: string) {
    this.allVendorContractsByDate = data.value.map((item: any) => {
      item.domainSkillStartDate = this.datePipe.transform(item.domainSkillStartDate, 'dd-MMM-yyyy');
      item.domainSkillEndDate = this.datePipe.transform(item.domainSkillEndDate, 'dd-MMM-yyyy');
      item.poStartDate = this.datePipe.transform(item.poStartDate, 'dd-MMM-yyyy');
      item.poEndDate = this.datePipe.transform(item.poEndDate, 'dd-MMM-yyyy');
      item.sowStartDate = this.datePipe.transform(item.sowStartDate, 'dd-MMM-yyyy');
      item.sowEndDate = this.datePipe.transform(item.sowEndDate, 'dd-MMM-yyyy');
      item.uploadedDate = this.datePipe.transform(item.uploadedDate, 'dd-MMM-yyyy');
      return item;
    });

    if (typo != '') {
      const searchText = typo;
      const searchResults = data.value.filter(
        (item: { [x: string]: string }) => {
          // Convert all property values to lowercase for case-insensitive search
          for (const key in item) {
            if (
              typeof item[key] === 'string' &&
              item[key].toLowerCase().includes(searchText.trim().toLowerCase())
            ) {
              return true; // Match found, include in results
            }
          }
          return false; // No match found
        }
      );
      this.allVendorContractsByDate = searchResults;
    } else {
      this.allVendorContractsByDate = this.allVendorContractsByDateBackup;
    }
    return this.allVendorContractsByDate;
  }

  initializeDropdownOptions(): void {
    this.contractType = [
      { id: 'All', name: 'All' },
      { id: ContractTypeConstant.TM, name: ContractTypeConstant.TM },
      { id: ContractTypeConstant.FIXED_MILESTONE, name: ContractTypeConstant.FIXED_MILESTONE },
      { id: ContractTypeConstant.FIXED_MONTHLY, name: ContractTypeConstant.FIXED_MONTHLY }
    ];
  }

  OnChange(event: any): void {
    this.GetAllVendorContractsByDate(event.value);
  }
}