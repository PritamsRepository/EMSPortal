import { AfterContentInit, Component, OnInit, ViewChild } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AutoComplete, AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { Table } from 'primeng/table';
import { IEmployeeMasterReport } from 'src/app/core/interfaces/iemployee-master-report';
import { ReportsService } from 'src/app/core/services/reports/reports.service';
// import { DefinedRoles } from 'src/app/core/utiltz/DefinedRolesList';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-employee-master',
  templateUrl: './employee-master.component.html',
  styleUrls: ['./employee-master.component.css'],
  providers: [MessageService],
})

export class EmployeeMasterComponent implements OnInit {
  constructor(
    private readonly _reportsService: ReportsService,
    private readonly _messageService: MessageService,
    private messageService: MessageService,
  ) {}
  months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  currentDate = new Date();
  day = this.currentDate.getDate().toString().padStart(2, '0');
  month = (this.currentDate.toLocaleString('default', { month: 'short' })).toString();
  year = this.currentDate.getFullYear().toString();
  csvfilename:string = 'Employee_Master_' + `${this.day}-${this.month}-${this.year}`;

 

  @ViewChild('towerAC') towerAutoComplete: AutoComplete;
  @ViewChild('pr') pr: AutoComplete;
  @ViewChild('ctname') ctname: AutoComplete;
  @ViewChild('obs_') obs_: AutoComplete;
  @ViewChild('vname') vname: AutoComplete;
  @ViewChild('sowname') sowname: AutoComplete;
  @ViewChild('pname') pname: AutoComplete;
  @ViewChild('cst') cst: AutoComplete;
  @ViewChild('employeeMasterDetails') EmpTable: Table;
  
  gridTitle: string = 'Employee Master Report';
  gridCols!: any[];
  employeeMasterReport: IEmployeeMasterReport[];

  ngOnInit(): void {
    this.GetEmployeeMasterDetailReport();
    this.gridCols = [
      { field: 'viatrisMid', header: 'MID' },
      { field: 'empName', header: 'Employee Name' },
      { field: 'viatrisEmailId', header: 'Email ID' },
      { field: 'managerMid', header: 'Manager MID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'dojviatris', header: 'DOJ'},
      { field: 'mobileNo', header: 'Mobile No' },
      { field: 'dob', header: 'DOB' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'locationName', header: 'Location Name' },
      { field: 'contractTypeName', header: 'Contract Type Name' },
      { field: 'sowTypeName', header: 'SOW Type Name' },
      { field: 'sowname', header: 'SOW Name' },
      { field: 'sownumber', header: 'SOW Number' },
      { field: 'sowstartDate', header: 'SOW Start Date' },
      { field: 'sowendDate', header: 'SOW End Date' },
      { field: 'ponumber', header: 'Po Number' },
      { field: 'postartDate', header: 'Po Start Date' },
      { field: 'poendDate', header: 'Po End Date' },
      { field: 'billingTypeName', header: 'Billing Type Name' },
      { field: 'verticalName', header: 'Vertical Name' },
      { field: 'projectOrRun', header: 'Project Or Run' },
      { field: 'domainName', header: 'Domain Skill Name' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'domainSkillStartDate', header: 'Domain Skill Start Date' },
      { field: 'domainSkillEndDate', header: 'Domain Skill End Date' },
      { field: 'Sapcode', header: 'Sap Code' },
      { field: 'costCenter', header: 'Cost Center' },
      { field: 'ppmprojectId', header: 'PPM Project ID' },
      { field: 'ppmprojectName', header: 'PPM Project Name' },
      { field: 'towerName', header: 'Tower Name' },
      { field: 'resourceStatus', header: 'Resource Status' },

      { field: 'etwid', header: 'ETWID' },
      { field: 'customDomainName', header: 'Custom Domain Name' },
      { field: 'managerName', header: 'Manager Name' },
      { field: 'managerEmail', header: 'Manager Email' },
      { field: 'contractStatus', header: 'Contract Status' },
      { field: 'amortizationStartMonth', header: 'Amortization Start Month' },
      { field: 'amortizationEndMonth', header: 'Amortization End Month' },
      { field: 'wbsdetail', header: 'WBS' },
      { field: 'obs', header: 'OBS' },
      { field: 'lwd', header: 'LWD' },
      { field: 'noticePeriod', header: 'Notice Period' },
      { field: 'oldSownumber', header: 'Old Sow Number' },
      { field: 'currency', header: 'Currency' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },
      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'milestones', header: 'Milestone' },
      { field: 'milestoneDescription', header: 'Milestone Description' },
      { field: 'milestonesAmount', header: 'Milestone Amount' },
      { field: 'monthlyContractAmount', header: 'Monthly Contract Amount' },
      { field: 'durationOfMonths', header: 'Duration Of Months' } 
    ];

    const storedRoles: any[] = JSON.parse(
      sessionStorage.getItem('AssignedRoles')
    );
 
    const rolesToCheck = ['Local IT', 'Report Access', 'HR'];  
    const foundRoles = storedRoles.filter(role => rolesToCheck.includes(role.roleType));
 
    if ((storedRoles.length == 1 && foundRoles.length > 0) || foundRoles.length == 3) {
      console.log('only report access');
      this.hideColumns();
    } else {
      console.log('more than report access');
    }
    this.defaultValForFilters();
  }
  defaultValForFilters(){
    this.filters.towerName = "ALL";
    this.filters.projectOrRun = "ALL";
    this.filters.contractTypeName = "ALL";
    this.filters.obs = "ALL";
    this.filters.vendorName = "ALL";
    this.filters.sowname = "ALL";
    this.filters.ppmprojectName = "ALL";
    this.filters.resourceStatus = [{"name": "Active", "code": "Active"}];
  }
  //exportCSVWithModifiedData
  exportCSVWithModifiedData() {

    const dataToExport = [...this.EmpTable.filteredValue || this.EmpTable.value];
    const dateColumns = [
      'postartDate',
      'poendDate',
      'domainSkillStartDate',
      'domainSkillEndDate',
      'amortizationStartMonth',
      'amortizationEndMonth',
      'sowstartDate',
      'sowendDate',
      'dojviatris',
      'dob',
      'lwd',
    ];

    // row.field === 'Po Start Date' ||   postartDate
    // row.header === 'Po End Date' ||   poendDate
    // row.header === 'Domain Skill Start Date' ||  domainSkillStartDate
    // row.header === 'Domain Skill End Date' ||  domainSkillEndDate
    // row.header === 'Amortization Start Month' ||   amortizationStartMonth
    // row.header === 'Amortization End Month' ||  amortizationEndMonth
    // row.header === 'SOW Start Date' ||   sowstartDate
    // row.header === 'SOW End Date' || sowendDate
    // row.header === 'DOJ' ||   dojviatris
    // row.header === 'DOB' ||   dob
    // row.header === 'LWD'  lwd

    dataToExport.forEach(row => {
      dateColumns.reduce((row, column) => {
        if (row[column] !== '') {
          row[column] = this.formatDate(row[column]);
        }
        return row;
      }, row);
  
      if (row.resourceStatus === 'Left') {
        row.resourceStatus = 'InActive';
      }
    });
 
    // Export the modified data
    this.EmpTable.exportCSV();
  }

  GetEmployeeMasterDetailReport() {
    this._reportsService.GetEmployeeMasterDetailReport().subscribe({
      next: (result: IEmployeeMasterReport[]) => {
        this.employeeMasterReport = result;

        this.employeeMasterReport = result.map(report => {
          // Check if the resourcestatus is 'Left', if yes, change it to 'InActive'
          if (report.resourceStatus === 'Left') {
            report.resourceStatus = 'InActive';
          }
          return report;
        });
        this.searchEmployeeData();

        //console.log('Details : ', this.employeeMasterReport);
        if (this.employeeMasterReport.length > 0) {
          this._messageService.add({
            severity: 'info',
            summary: 'Fetched',
            detail: 'Employee Master Details report fetched successfully.',
          });
        } else {
          this._messageService.add({
            severity: 'warn',
            summary: 'No Records',
            detail: 'No data found.',
          });
        }
      },
      error: (err) => {
        this._messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch the reports.',
        });
      },
    });
  }

  TowerNameSuggestions: any[] | undefined;  
  searchTowerName(event: AutoCompleteCompleteEvent) {
      const query = event.query;
      const TNames = [...new Set(this.employeeMasterReport.map(item => item.towerName))]
      let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
      filtered.unshift("ALL");     
      this.TowerNameSuggestions = filtered;
  }

  PorRunSuggestions: any[] | undefined;  
  searchPorRun(event: AutoCompleteCompleteEvent) {
      const query = event.query;
      const TNames = [...new Set(this.employeeMasterReport.map(item => item.projectOrRun))]
      let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
      filtered.unshift("ALL");
      this.PorRunSuggestions = filtered;
  }

  CTypeSuggestions: any[] | undefined;  
  searchCType(event: AutoCompleteCompleteEvent) {

      const query = event.query;
      const TNames = [...new Set(this.employeeMasterReport.map(item => item.contractTypeName))]
      let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
      filtered.unshift("ALL");
      this.CTypeSuggestions = filtered;
  }

  OBSSuggestions: any[] | undefined;  
  searchOBS(event: AutoCompleteCompleteEvent) {
      const query = event.query;
      const TNames = [...new Set(this.employeeMasterReport.map(item => item.obs))]
      let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
      filtered.unshift("ALL");
      this.OBSSuggestions = filtered;
  }

  VNameSuggestions: any[] | undefined;  
  searchVName(event: AutoCompleteCompleteEvent) {
    const query = event.query;
    const TNames = [...new Set(this.employeeMasterReport.map(item => item.vendorName))]
    let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
    filtered.unshift("ALL");
    this.VNameSuggestions = filtered;
  }

  SOWNameSuggestions: any[] | undefined;  
  searchSOWName(event: AutoCompleteCompleteEvent) {
    const query = event.query;
    const TNames = [...new Set(this.employeeMasterReport.map(item => item.sowname))]
    let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
    filtered.unshift("ALL");
    this.SOWNameSuggestions = filtered;
  }

  PNameSuggestions: any[] | undefined;  
  searchPName(event: AutoCompleteCompleteEvent) {
    const query = event.query;
    const TNames = [...new Set(this.employeeMasterReport.map(item => item.ppmprojectName))]
    let filtered = TNames.filter(item => item.toLowerCase().indexOf(query) === 0);
    filtered.unshift("ALL");
    this.PNameSuggestions = filtered;
  }

  CStatusSuggestions: any[] | undefined;  
  searchCStatus(event: AutoCompleteCompleteEvent) {
    const selectedStatuses = this.filters.resourceStatus.map((status: any) => status.name.toLowerCase()); 
    const query = event.query;
    const TNames: any[] = [
      {"name": "ALL", "code": "ALL"},
      {"name": "Active", "code": "Active"},
      {"name": "InActive", "code": "InActive"},
      {"name": "Resigned", "code": "Resigned"},
    ];

    const allSelected = selectedStatuses.includes("all");

     let message: string | undefined;
     if(allSelected==false && selectedStatuses.length === 3)
      {
        this.messageService.add({
          severity: 'info',
          summary: "You have selected all available options. Clear any one option to proceed further.",
        });
        return ;
      }
 
     if (message) {
         this.CStatusSuggestions = [{ name: message, code: "" }];
         return ;
     }
  
    let filtered = TNames
        .filter(item => !selectedStatuses.includes(item.name.toLowerCase())) 
        .map(item => ({ name: item.name.replace("Left", "InActive"), code: item.code.replace("Left", "InActive") }))
        .filter(item => item.name.toLowerCase().indexOf(query) === 0);  

    this.CStatusSuggestions = filtered;
 
  }

  onRSSelected(event: any){
    console.log( event );

    const indexToRemove = this.filters.resourceStatus.findIndex((status: any) => status.name.toLowerCase() === 'all');
    if (indexToRemove !== -1 && event.value.name.toLowerCase() != 'all') {
        this.filters.resourceStatus.splice(indexToRemove, 1);
    }
    if(event.value.name.toLowerCase() == 'all')
    {
      this.filters.resourceStatus = [{"name": "ALL", "code": "ALL"}];
    }
  }

  filteredEmployeeMasterReport: any[];  
  filters: any = {
    towerName: null,
    projectOrRun: null,
    contractTypeName: null,
    obs: null,
    vendorName: null,
    sowname: null,
    ppmprojectName: null,
    resourceStatus: []
  };

  getCurrentDate(): string {
    let cdate = new Date().toISOString();
    return this.formatDate(cdate);
  }

  searchEmployeeData(){
    if (this.filters.projectOrRun.trim() === '') {
        this.filters.projectOrRun = "ALL";
    }
    
    if (this.filters.contractTypeName.trim() === '') {
        this.filters.contractTypeName = "ALL";
    }
    
    if (this.filters.obs.trim() === '') {
        this.filters.obs = "ALL";
    }
    
    if (this.filters.vendorName.trim() === '') {
        this.filters.vendorName = "ALL";
    }
    
    if (this.filters.sowname.trim() === '') {
        this.filters.sowname = "ALL";
    }
    
    if (this.filters.ppmprojectName.trim() === '') {
        this.filters.ppmprojectName = "ALL";
    }
    
    if (this.filters.resourceStatus.length==0) {
      this.filters.resourceStatus = [{"name": "ALL", "code": "ALL"}];
    }
   
    let filteredResourceStatus: any[];
    if (Array.isArray(this.filters.resourceStatus)) {
      filteredResourceStatus = this.filters.resourceStatus.map((status: any) => status.name);
    } 
    else {
      filteredResourceStatus = this.filters.resourceStatus.map((status: any) => status.name);
    }
 
    this.filteredEmployeeMasterReport = this.employeeMasterReport.filter(item => {
      return (
              (this.filters.towerName === 'ALL' || item.towerName === this.filters.towerName) &&
              (this.filters.projectOrRun === 'ALL' || item.projectOrRun === this.filters.projectOrRun) &&
              (this.filters.contractTypeName === 'ALL' || item.contractTypeName === this.filters.contractTypeName) &&
              (this.filters.obs === 'ALL' || item.obs === this.filters.obs) &&
              (this.filters.vendorName === 'ALL' || item.vendorName === this.filters.vendorName) &&
              (this.filters.sowname === 'ALL' || item.sowname === this.filters.sowname) &&
              (this.filters.ppmprojectName === 'ALL' || item.ppmprojectName === this.filters.ppmprojectName) &&
              (
                filteredResourceStatus.includes('ALL') ||
                (Array.isArray(filteredResourceStatus) && filteredResourceStatus.includes(item.resourceStatus)) ||
                (Array.isArray(filteredResourceStatus) && filteredResourceStatus.indexOf(item.resourceStatus) !== -1) ||
                filteredResourceStatus.includes(item.resourceStatus)
              )
      );
    });
  }
  ClearFilters(){
    // this.towerAutoComplete.clear();
    // this.pr.clear();
    // this.ctname.clear(); 
    // this.obs_.clear(); 
    // this.vname.clear(); 
    // this.sowname.clear(); 
    // this.pname.clear(); 
    // this.cst.clear(); 
    this.defaultValForFilters();
    this.filteredEmployeeMasterReport=this.employeeMasterReport;
  }

  hideColumns() {
    this.gridCols = this.gridCols
    .filter(col => col.field !== 'currency' && 
            col.field !== 'billingRateYear1' &&
            col.field !== 'billingRateYear2' &&
            col.field !== 'billingRateYear3' &&
            col.field !== 'billingRateYear4' &&
            col.field !== 'billingRateYear5' &&
            col.field !== 'milestones' &&
            col.field !== 'milestoneDescription' &&
            col.field !== 'milestonesAmount' &&
            col.field !== 'monthlyContractAmount' &&
            col.field !== 'durationOfMonths' 
          );
  }

  formatDate(date: string): string {

    if (date === null || date === '' || date === undefined) 
      return ''; 
    
  const monthSubstring = this.months.join('|');
  const monthRegex = new RegExp(`-${monthSubstring}-`);

    if (monthRegex.test(date)) {
      return date;
    }

    if(date.includes('T'))
    {
      const datePart = date.split('T')[0];
      const dateParts = datePart.split('-');
      const day = dateParts[2];
      const month = this.getMonthName(dateParts[1]);
      const year = dateParts[0];
      return `${day}-${month}-${year}`;
    }

    const parts = date.split('-');
    const day = parts[0];
    const month = this.getMonthName(parts[1]);
    const year = parts[2];
    return `${day}-${month}-${year}`;
  } 
  getMonthName(month: string): string {
    // const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthIndex = parseInt(month, 10) - 1; 
    return this.months[monthIndex];
  } 
}
