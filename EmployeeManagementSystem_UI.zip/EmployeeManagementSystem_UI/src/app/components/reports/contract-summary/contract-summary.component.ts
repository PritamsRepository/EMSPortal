import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { MessageService } from 'primeng/api';
import { IContractSummaryReport } from 'src/app/core/interfaces/icontract-summary-report';
import { IDropDownKeyValue } from 'src/app/core/interfaces/idropdown-key-value';
import { ReportsService } from 'src/app/core/services/reports/reports.service';
import { ReportType } from 'src/app/core/utiltz/ReportType';

@Component({
  selector: 'app-contract-summary',
  templateUrl: './contract-summary.component.html',
  styleUrls: ['./contract-summary.component.css'],
  providers: [MessageService],
})
export class ContractSummaryComponent {
  constructor(
    private readonly _reportsService: ReportsService,
    private readonly _messageService: MessageService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}

  gridTitle: string;
  gridCols!: any[];
  contractSummaryReportTowerHead: IContractSummaryReport[];
  contractSummaryReportPPMProject: IContractSummaryReport[];
  reportType: string;
  reportTypeHeader: string;
  projectOrRunMaster!: IDropDownKeyValue[];
  // selectedProjectOrRunValue: number=0;
  selectedProjectOrRunValue: any = { Name: 'Run', Id: '1' };
  // tmDetails!: itmUpload[];
  // ref!: DynamicDialogRef;

  SumtotalL1Position?: number;
  SumtotalL2Position?: number;
  SumtotalL3Position?: number;
  SumtotalPosition?: number;
  Suml1ClosedPosition?: number;
  Suml2ClosedPosition?: number;
  Suml3ClosedPosition?: number;
  SumtotalClosedPositions?: number;
  SumopenL1Position?: number;
  SumopenL2Position?: number;
  SumopenL3Position?: number;
  SumtotalOpenPosition?: number;
  Suml1Unfulfilled?: number;
  Suml2Unfulfilled?: number;
  Suml3Unfulfilled?: number;
  SumoverallUnfullfilled?: number;
  Suml1Selected?: number;
  Suml2Selected?: number;
  Suml3Selected?: number;
  SumtotalSelected?: number;

  

  ngAfterContentInit() {
    this.reportType = this.route.snapshot.data['reportType'];
    switch (this.reportType) {
      case 'TowerHead':
        this.gridCols = [
          { field: 'summaryName', header: this.reportTypeHeader },
          { field: 'totalL1Position', header: 'Total L1 Position' },
          { field: 'totalL2Position', header: 'Total L2 Position' },
          { field: 'totalL3Position', header: 'Total L3 Position' },
          { field: 'totalPosition', header: '  Total Position' },
          { field: 'l1ClosedPosition', header: 'L1 Onboarded Position' },
          { field: 'l2ClosedPosition', header: 'L2 Onboarded Position' },
          { field: 'l3ClosedPosition', header: 'L3 Onboarded Position' },
          { field: 'totalClosedPositions', header: 'Total Onboarded Position' },
          { field: 'openL1Position', header: 'L1 Open Position' },
          { field: 'openL2Position', header: 'L2 Open Position' },
          { field: 'openL3Position', header: 'L3 Open Position' },
          { field: 'totalOpenPosition', header: 'Total Open Position' },
    
          { field: 'l1Selected', header: 'L1 Selected' },
          { field: 'l2Selected', header: 'L2 Selected' },
          { field: 'l3Selected', header: 'L3 Selected' },
          { field: 'totalSelected', header: 'Total Selected' },

          { field: 'l1Unfulfilled', header: 'L1 Unfulfilled' },
          { field: 'l2Unfulfilled', header: 'L2 Unfulfilled' },
          { field: 'l3Unfulfilled', header: 'L3 Unfulfilled' },
          { field: 'overallUnfullfilled', header: 'Overall Unfullfilled' },
         
          // { field: 'l1Backup', header: 'L1 Backup' },
          // { field: 'l2Backup', header: 'L2 Backup' },
          // { field: 'l3Backup', header: 'L3 Backup' },
          // { field: 'totalBackup', header: 'Total Backup' },
        ];
        break;
      case 'PPMProjectName':
        this.gridCols = [
          { field: 'summaryName', header: this.reportTypeHeader },
          { field: 'totalL1Position', header: 'Total L1 Position' },
          { field: 'totalL2Position', header: 'Total L2 Position' },
          { field: 'totalL3Position', header: 'Total L3 Position' },
          { field: 'totalPosition', header: '  Total Position' },
          { field: 'l1ClosedPosition', header: 'L1 Onboarded Position' },
          { field: 'l2ClosedPosition', header: 'L2 Onboarded Position' },
          { field: 'l3ClosedPosition', header: 'L3 Onboarded Position' },
          { field: 'totalClosedPositions', header: 'Total Onboarded Position' },
          { field: 'openL1Position', header: 'L1 Open Position' },
          { field: 'openL2Position', header: 'L2 Open Position' },
          { field: 'openL3Position', header: 'L3 Open Position' },
          { field: 'totalOpenPosition', header: 'Total Open Position' },
    
          // { field: 'l1Unfulfilled', header: 'L1 Unfulfilled' },
          // { field: 'l2Unfulfilled', header: 'L2 Unfulfilled' },
          // { field: 'l3Unfulfilled', header: 'L3 Unfulfilled' },
          // { field: 'overallUnfullfilled', header: 'Overall Unfullfilled' },
          // { field: 'l1Selected', header: 'L1 Selected' },
          // { field: 'l2Selected', header: 'L2 Selected' },
          // { field: 'l3Selected', header: 'L3 Selected' },
          // { field: 'totalSelected', header: 'Total Selected' },
          // { field: 'l1Backup', header: 'L1 Backup' },
          // { field: 'l2Backup', header: 'L2 Backup' },
          // { field: 'l3Backup', header: 'L3 Backup' },
          // { field: 'totalBackup', header: 'Total Backup' },
        ];
        break;
    }

    
  }

  ngOnInit(): void {
    //console.log(this.route.snapshot.data['reportType']);
    this.reportType = this.route.snapshot.data['reportType'];
    switch (this.reportType) {
      case 'TowerHead':
        this.gridTitle = 'Open-Position Report Tower-wise';
        this.reportTypeHeader = 'Tower Head';
        break;
      case 'PPMProjectName':
        this.gridTitle = 'Open-Position Report SOWName-Wise';
        this.reportTypeHeader = 'SOW Name';
        break;
    }
    this.getProjectOrRunMaster();
    this.getContractSummaryReport(
      this.reportType,
      this.selectedProjectOrRunValue.Id
    );
  }
  getProjectOrRunMaster() {
    this._reportsService.GetProjectOrRunMaster().subscribe({
      next: (data) => {
        this.projectOrRunMaster = data;
      },
    });
  }
  OnChange(e: any) {
    //console.log('ProjectOr Run Value', e.value);
    //console.log('ProjectOr Run Value',this.selectedProjectOrRunValue);
    this.getContractSummaryReport(this.reportType, e.value);
  }
  getContractSummaryReport(reportType: string, prid: number) {
    this._reportsService
      .GetContractSummaryReport(reportType, prid)
      .pipe()
      .subscribe({
        next: (result: IContractSummaryReport[]) => {
          this.contractSummaryReportPPMProject = result;
          this.CalculateSum();

          if (this.contractSummaryReportPPMProject.length > 0) {
            this._messageService.add({
              severity: 'info',
              summary: 'Fetched',
              detail: 'Contract Details report fetched successfully.',
            });
          } else {
            this._messageService.add({
              severity: 'warn',
              summary: 'No Records',
              detail: 'No data found.',
            });
          }
        },
        error: (err) => {
          this._messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to fetch the reports.',
          });
        },
      });
  }
  CalculateSum(){
    this.reportType = this.route.snapshot.data['reportType'];
    switch (this.reportType) {
    case 'TowerHead':
      this.SumtotalL1Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL1Position , 0);
      this.SumtotalL2Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL2Position , 0);
      this.SumtotalL3Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL3Position , 0);
      this.SumtotalPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalPosition , 0);
      this.Suml1ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l1ClosedPosition , 0);
      this.Suml2ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l2ClosedPosition , 0);
      this.Suml3ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l3ClosedPosition , 0);
      this.SumtotalClosedPositions = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalClosedPositions , 0);
      this.SumopenL1Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL1Position , 0);
      this.SumopenL2Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL2Position , 0);
      this.SumopenL3Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL3Position , 0);
      this.SumtotalOpenPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalOpenPosition , 0);
      this.Suml1Unfulfilled = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l1Unfulfilled , 0);
      this.Suml2Unfulfilled = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l2Unfulfilled , 0);
      this.Suml3Unfulfilled = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l3Unfulfilled , 0);
      this.SumoverallUnfullfilled = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.overallUnfullfilled , 0);
      this.Suml1Selected = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l1Selected , 0);
      this.Suml2Selected = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l2Selected , 0);
      this.Suml3Selected = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l3Selected , 0);
      this.SumtotalSelected = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalSelected , 0);

    break;
    case 'PPMProjectName':
      this.SumtotalL1Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL1Position , 0);
      this.SumtotalL2Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL2Position , 0);
      this.SumtotalL3Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalL3Position , 0);
      this.SumtotalPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalPosition , 0);
      this.Suml1ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l1ClosedPosition , 0);
      this.Suml2ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l2ClosedPosition , 0);
      this.Suml3ClosedPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.l3ClosedPosition , 0);
      this.SumtotalClosedPositions = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalClosedPositions , 0);
      this.SumopenL1Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL1Position , 0);
      this.SumopenL2Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL2Position , 0);
      this.SumopenL3Position = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.openL3Position , 0);
      this.SumtotalOpenPosition = this.contractSummaryReportPPMProject.reduce((total, item) => total + item.totalOpenPosition , 0);
  
      break;
    }
  }
}
