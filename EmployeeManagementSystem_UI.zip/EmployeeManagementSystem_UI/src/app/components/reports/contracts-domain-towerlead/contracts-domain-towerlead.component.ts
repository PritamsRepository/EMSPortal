
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, convertToParamMap } from '@angular/router';
import { ContractTowerDomainReport } from 'src/app/core/interfaces/contract-tower-domain-report';
import { ReportsService } from 'src/app/core/services/reports/reports.service';

@Component({
  selector: 'app-contracts-domain-towerlead',
  templateUrl: './contracts-domain-towerlead.component.html',
  styleUrls: ['./contracts-domain-towerlead.component.css']
})
export class ContractsDomainTowerleadComponent implements OnInit {
  constructor(
    private readonly _reportsService: ReportsService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}

  gridTitle: string;
  gridCols!: any[];
  ContractTowerDomainReport: ContractTowerDomainReport[];
  reportType: string;
  reportTypeHeader: string;
  rowData: any[] = [];
  editedValue: any;
  data:any;
  ddFilter: { name: string, code: string }[] = [];
  selectedItem: any = { name: 'ALL', code: 'ALL' };
  ddlfilterProject: any[] = [];
  selectedItemproject?: any = { name: 'Run', code: 'Run' };

  SumRequiredPositions?:number;
  suml1?:number;
  Suml1onboarded?:number;
  Suml1openPostions?:number;
  Suml1selected?:number;
  Suml1backUp?:number;
  suml2?:number;
  Suml2onboarded?:number;
  Suml2openPostions?:number;
  Suml2selected?:number;
  Suml2backUp?:number;
  suml3?:number;
  Suml3onboarded?:number;
  Suml3openPostions?:number;
  Suml3selected?:number;
  Suml3backUp?:number;
  SumoverallOnboarded?:number;
  SumoverallOpenPostion?:number;
  Sumoverallselected?:number;
  Sumunfullfilled?:number;

  ngOnInit() {

    this.gridTitle = 'Open-Position Report Domain-wise';
    this.getContractReport();
    this.gridCols = [
      { field: 'towerHead', header: 'Tower Lead', editable: false },
      { field: 'customDomainName', header: 'Domain Name',editable: false },
      // { field: 'domainName', header: 'Domain Skill Name',editable: false },
      { field: 'totalRequiredPositions', header: 'Total Required Positions' ,editable: false},
      { field: 'l1Position', header: 'L1' ,editable: false},
      { field: 'l1OnBoarder', header: 'L1 Onboarded',editable: false },
      { field: 'l1Openposition', header: 'L1 Open	Postions',editable: false },
      { field: 'l1AgingDays', header: 'Ageing Days',editable: false },
      { field: 'l1PositionOpenDate', header: 'Opened Date',editable: false },
      { field: 'l1Selected', header: 'L1 Selected',editable: true   },
      { field: 'l1BackUp', header: 'L1 Backup' ,editable: true },
      { field: 'l1ResourceDOJ', header: 'Resource DOJ',editable: true  },
      { field: 'l2Position', header: 'L2' , editable: false},
      { field: 'l2OnBoarder', header: 'L2 Onboarded', editable: false },
      { field: 'l2Openposition', header: 'L2 Open	Postions' , editable: false},
      { field: 'l2AgingDays', header: 'Ageing Days', editable: false },
      { field: 'l2PositionOpenDate', header: 'Opened Date' , editable: false},
      { field: 'l2Selected', header: 'L2 Selected' , editable: true},
      { field: 'l2BackUp', header: 'L2 Backup', editable: true },
      { field: 'l2ResourceDOJ', header: 'Resource DOJ', editable: true },
      { field: 'l3Position', header: 'L3' , editable: false},
      { field: 'l3OnBoarder', header: 'L3 Onboarded', editable: false },
      { field: 'l3Openposition', header: 'L3 Open	Postions', editable: false },
      { field: 'l3AgingDays', header: 'Ageing Days' , editable: false},
      { field: 'l3PositionOpenDate', header: 'Opened Date', editable: false },
      { field: 'l3Selected', header: 'L3 Selected' , editable: true},
      { field: 'l3BackUp', header: 'L3 Backup', editable: true },
      { field: 'l3ResourceDOJ', header: 'Resource DOJ', editable: true },
      { field: 'overallOnboarded', header: 'Overall Onboarded', editable: false },
      { field: 'overallOpenPostion', header: 'Overall Open Postion', editable: false },
      { field: 'overallselected', header: 'Overall selected' , editable: false},
      { field: 'unfullfilled', header: 'Overall Unfullfilled' , editable: false},
    ];

    this.getTowerHeadMasterData();
    this.ddlfilterProject = [
      { name: 'ALL', code: 'ALL' },
      { name: 'Project', code: 'Project' },
      { name: 'Run', code: 'Run' },
    ];


  }
  getContractReport() {
    this._reportsService.GetContractReportByToweHeadAndDomain(this.selectedItem.code,this.selectedItemproject.code).subscribe((result: any[]) => {
    debugger;
      this.ContractTowerDomainReport=result;

    //  if( this.ContractTowerDomainReport!=null &&this.ContractTowerDomainReport.length>0)
    //  {
      this.SumRequiredPositions=this.ContractTowerDomainReport.reduce((total, item) => total + item.totalRequiredPositions, 0);
      this.suml1 = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1Position, 0);
      this.Suml1onboarded = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1OnBoarder, 0);
      this.Suml1openPostions = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1Openposition, 0);
      this.Suml1selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1Selected, 0);
      this.Suml1backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1BackUp, 0);
      this.suml2 = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2Position, 0);
      this.Suml2onboarded = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2OnBoarder, 0);
      this.Suml2openPostions = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2Openposition, 0);
      this.Suml2selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2Selected, 0);
      this.Suml2backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2BackUp, 0);
      this.suml3 = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3Position, 0);
      this.Suml3onboarded = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3OnBoarder, 0);
      this.Suml3openPostions = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3Openposition, 0);
      this.Suml3selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3Selected, 0);
      this.Suml3backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3BackUp, 0);
      this.SumoverallOnboarded = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallOnboarded, 0);
      this.SumoverallOpenPostion = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallOpenPostion, 0);
      this.Sumoverallselected = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallselected, 0);
      this.Sumunfullfilled = this.ContractTowerDomainReport.reduce((total, item) => total + item.unfullfilled, 0);
     
    // }
    });
        
  }
  
  calculatevalues(col: any, data: any) {
  debugger;
  data['l1Selected']!=null?(data['l1Selected']>data['l1Openposition'] ||data['l1Selected'].length >data['l1Openposition'].length )? data['l1Selected']=null:null:null
  data['l2Selected']!=null?(data['l2Selected']>data['l2Openposition'] ||data['l2Selected'].length >data['l2Openposition'].length )? data['l2Selected']=null:null:null   
  data['l3Selected']!=null?(data['l3Selected']>data['l3Openposition'] ||data['l3Selected'].length >data['l3Openposition'].length )? data['l3Selected']=null:null:null

      data['overallselected'] = (data['l1Selected'] || 0) + (data['l2Selected'] || 0) + (data['l3Selected'] || 0);
      data['unfullfilled'] = (data['overallOpenPostion'] || 0) - (data['overallselected']||0);

      if (col.field === 'l1Selected')
      {
        this.Suml1selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1Selected, 0);
        this.Sumoverallselected = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallselected, 0);
        this.Sumunfullfilled = this.ContractTowerDomainReport.reduce((total, item) => total + item.unfullfilled, 0);
      }
      else if (col.field === 'l2Selected')
      {
        this.Suml2selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2Selected, 0);
        this.Sumoverallselected = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallselected, 0);
        this.Sumunfullfilled = this.ContractTowerDomainReport.reduce((total, item) => total + item.unfullfilled, 0);
      }
      else if (col.field === 'l3Selected')
      {
        this.Suml3selected = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3Selected, 0);
        this.Sumoverallselected = this.ContractTowerDomainReport.reduce((total, item) => total + item.overallselected, 0);
        this.Sumunfullfilled = this.ContractTowerDomainReport.reduce((total, item) => total + item.unfullfilled, 0);
      }
      else if(col.field === 'l1BackUp')
      {
        this.Suml1backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l1BackUp, 0);
      }
      else if(col.field === 'l2BackUp')
      {
        this.Suml2backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l2BackUp, 0);
      }
      else if(col.field === 'l3BackUp')
      {
        this.Suml3backUp = this.ContractTowerDomainReport.reduce((total, item) => total + item.l3BackUp, 0);
      }
     
  
  }
  ValidateNUmerics(data: any)
  {
    
   
  }
  submitReportData()
  {
    var data=this.ContractTowerDomainReport;

    if (this.ContractTowerDomainReport.length > 0) {
    
      this._reportsService.SaveContractPublishedData(this.ContractTowerDomainReport).subscribe((result) => {
       
      this.getContractReport();
      });
    } else {

    }
  }
  shouldDisableInput(col: any, rowData: any): boolean {

    if (col.field === 'l1Selected' || col.field === 'l1BackUp' || col.field === 'l1ResourceDOJ') {
        return rowData.l1Openposition === 0;
    } else if (col.field === 'l2Selected' || col.field === 'l2BackUp' || col.field === 'l2ResourceDOJ') {
        return rowData.l2Openposition === 0;
    } else if (col.field === 'l3Selected' || col.field === 'l3BackUp' || col.field === 'l3ResourceDOJ') {
        return rowData.l3Openposition === 0;
    }
    return false; // default: input enabled
}

submitReportDataWithMail()
  {
    var data=this.ContractTowerDomainReport;

    if (this.ContractTowerDomainReport.length > 0) {
    
      this._reportsService.SaveContractPublishedDataWithMail(this.ContractTowerDomainReport).subscribe((result) => {
       
      this.getContractReport();
      });
    } else {

    }
  }
  getTowerHeadMasterData()
  {
      this._reportsService.getTowerHeadMasterData().subscribe((result) => {
        // Assuming `result` is an array
      this.ddFilter = result.map((item: any) => ({ name: item, code: item }));
      // Adding a new object at the beginning of `this.ddFilter`
      this.ddFilter.unshift({ name: 'ALL', code: 'ALL' });
      });
   
  }
  SearchData()
  {
      this.getContractReport();
  }
  
}