import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractsDomainTowerleadComponent } from './contracts-domain-towerlead.component';

describe('ContractsDomainTowerleadComponent', () => {
  let component: ContractsDomainTowerleadComponent;
  let fixture: ComponentFixture<ContractsDomainTowerleadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContractsDomainTowerleadComponent]
    });
    fixture = TestBed.createComponent(ContractsDomainTowerleadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
