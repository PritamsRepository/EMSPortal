import { Component } from '@angular/core';

@Component({
  selector: 'app-open-position',
  templateUrl: './open-position.component.html',
  styleUrls: ['./open-position.component.css']
})
export class OpenPositionComponent {

}
