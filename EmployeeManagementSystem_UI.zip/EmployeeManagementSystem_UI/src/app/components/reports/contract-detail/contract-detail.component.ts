import { AfterContentInit, Component, OnInit, OnChanges } from '@angular/core';
import { MessageService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { IContractDetailReport } from 'src/app/core/interfaces/icontract-detail-reports';
import { IDropDownKeyValue } from 'src/app/core/interfaces/idropdown-key-value';
import { ReportsService } from 'src/app/core/services/reports/reports.service';
import { ReportType } from 'src/app/core/utiltz/ReportType';

@Component({
  selector: 'app-contract-detail',
  templateUrl: './contract-detail.component.html',
  styleUrls: ['./contract-detail.component.css'],
  providers: [MessageService, DialogService],
})
export class ContractDetailComponent implements AfterContentInit, OnInit {
  constructor(
    private readonly _reportsService: ReportsService,
    private readonly _messageService: MessageService
  ) {}

  gridTitle: string = 'Open Position Report Vendor Wise';
  gridCols!: any[];
  contractDetailsReport: IContractDetailReport[];
  projectOrRunMaster!: IDropDownKeyValue[];
  // selectedProjectOrRunValue: number=0;
  selectedProjectOrRunValue: any = { Name: 'Run', Id: '1' };
  // tmDetails!: itmUpload[];
  // ref!: DynamicDialogRef;

  Suml1totalposition?:number;
  Suml2totalposition?:number;
  Suml3totalposition?:number;
  SumtotalPosition?:number;
  Suml1HMposition?:number;
  Suml2HMposition?:number;
  Suml3HMposition?:number;
  SumtotalHMPosition?:number;
  Suml1NTTposition?:number;
  Suml2NTTposition?:number;
  Suml3NTTposition?:number;
  SumtotalNTTPosition?:number;
  Suml1TruSpeQposition?:number;
  Suml2TruSpeQposition?:number;
  Suml3TruSpeQposition?:number;
  SumtotalTruSpeQPosition?:number;
  Suml1CTSposition?:number;
  Suml2CTSposition?:number;
  Suml3CTSposition?:number;
  SumtotalCTSPosition?:number;
  Suml1Othersposition?:number;
  Suml2Othersposition?:number;
  Suml3Othersposition?:number;
  SumtotalOtherPosition?:number;
  Suml1ClosedPosition?:number;
  Suml2ClosedPosition?:number;
  Suml3ClosedPosition?:number;
  SumtotalClosedPositions?:number;
  SumopenL1Position?:number;
  SumopenL2Position?:number;
  SumopenL3Position?:number;
  SumtotalOpenPosition?:number;

  

  ngAfterContentInit() {
    this.gridCols = [
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'ppmProjectName', header: 'SOW Name' },
      { field: 'domainName', header: 'Domain Skill Name' },
      { field: 'customDomainName', header: 'Domain Name' },
      { field: 'towerHead', header: 'Tower Head' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },      

      { field: 'l1totalposition', header: 'L1 Total Position' },
      { field: 'l2totalposition', header: 'L2 Total Position' },
      { field: 'l3totalposition', header: 'L3 Total Position' },
      { field: 'totalPosition', header: 'Total Position' },
      { field: 'l1HMposition', header: 'L1 HM position' },
      { field: 'l2HMposition', header: 'L2 HM Position' },
      { field: 'l3HMposition', header: 'L3 HM Position' },
      { field: 'totalHMPosition', header: 'Total HM Position' },
      { field: 'l1NTTposition', header: 'L1 NTT Position' },
      { field: 'l2NTTposition', header: 'L2 NTT Position' },
      { field: 'l3NTTposition', header: 'L3 NTT Position' },
      { field: 'totalNTTPosition', header: 'Total NTT Position' },
      { field: 'l1TruSpeQposition', header: 'L1 TruSpeQ Position' },
      { field: 'l2TruSpeQposition', header: 'L2 TruSpeQ position' },
      { field: 'l3TruSpeQposition', header: 'L3 TruSpeQ Position' },
      { field: 'totalTruSpeQPosition', header: 'Total TruSpeQ Position' },
      { field: 'l1CTSposition', header: 'L1 CTS Position' },
      { field: 'l2CTSposition', header: 'L2 CTS Position' },
      { field: 'l3CTSposition', header: 'L3 CTS position' },
      { field: 'totalCTSPosition', header: 'Total CTS Position' },
      { field: 'l1Othersposition', header: 'L1 Others Position' },
      { field: 'l2Othersposition', header: 'L2 Others Position' },
      { field: 'l3Othersposition', header: 'L3 Others Position' },
      { field: 'totalOtherPosition', header: 'Total Other Position' },
      { field: 'l1ClosedPosition', header: 'L1 Onboarded Position' },
      { field: 'l2ClosedPosition', header: 'L2 Onboarded Position' },
      { field: 'l3ClosedPosition', header: 'L3 Onboarded Position' },
      { field: 'totalClosedPositions', header: 'Total Onboarded Position' },
      { field: 'openL1Position', header: 'Open L1 Position' },
      { field: 'openL2Position', header: 'Open L2 Position' },
      { field: 'openL3Position', header: 'Open L3 Position' },
      { field: 'totalOpenPosition', header: 'Total Open Position' },

      
      

    ];
  }
  ngOnInit() {
    this.getProjectOrRunMaster();  
    this.getContractDetailsReport(this.selectedProjectOrRunValue.Id);
    debugger;

   

  }

  getProjectOrRunMaster() {
    this._reportsService.GetProjectOrRunMaster().subscribe({
      next: (data) => {
        this.projectOrRunMaster = data;
      },
    });
  }
  OnChange(e: any) {
    //console.log('ProjectOr Run Value', e.value);
    //console.log('ProjectOr Run Value',this.selectedProjectOrRunValue);
    this.getContractDetailsReport(e.value);
  }
  getContractDetailsReport(prId: number) {
    this._reportsService
      .GetContractDetailReport(ReportType.Detail, prId)
      .subscribe({
        next: (result: IContractDetailReport[]) => {
          this.contractDetailsReport = result;
          this.CalculateSum();
          //console.log('Details : ', this.contractDetailsReport);
          if (this.contractDetailsReport.length > 0) {
            this._messageService.add({
              severity: 'info',
              summary: 'Fetched',
              detail: 'Contract Details report fetched successfully.',
            });
          } else {
            this._messageService.add({
              severity: 'warn',
              summary: 'No Records',
              detail: 'No data found.',
            });
          }
        },
        error: (err) => {
          this._messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to fetch the reports.',
          });
        },
      });
  }

  CalculateSum(){
    this.Suml1totalposition = this.contractDetailsReport.reduce((total, item) => total + item.l1totalposition , 0);
    this.Suml2totalposition = this.contractDetailsReport.reduce((total, item) => total + item.l2totalposition , 0);
    this.Suml3totalposition = this.contractDetailsReport.reduce((total, item) => total + item.l3totalposition , 0);
    this.SumtotalPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalPosition , 0);
    this.Suml1HMposition = this.contractDetailsReport.reduce((total, item) => total + item.l1HMposition , 0);
    this.Suml2HMposition = this.contractDetailsReport.reduce((total, item) => total + item.l2HMposition , 0);
    this.Suml3HMposition = this.contractDetailsReport.reduce((total, item) => total + item.l3HMposition , 0);
    this.SumtotalHMPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalHMPosition , 0);
    this.Suml1NTTposition = this.contractDetailsReport.reduce((total, item) => total + item.l1NTTposition , 0);
    this.Suml2NTTposition = this.contractDetailsReport.reduce((total, item) => total + item.l2NTTposition , 0);
    this.Suml3NTTposition = this.contractDetailsReport.reduce((total, item) => total + item.l3NTTposition , 0);
    this.SumtotalNTTPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalNTTPosition , 0);
    this.Suml1TruSpeQposition = this.contractDetailsReport.reduce((total, item) => total + item.l1TruSpeQposition , 0);
    this.Suml2TruSpeQposition = this.contractDetailsReport.reduce((total, item) => total + item.l2TruSpeQposition , 0);
    this.Suml3TruSpeQposition = this.contractDetailsReport.reduce((total, item) => total + item.l3TruSpeQposition , 0);
    this.SumtotalTruSpeQPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalTruSpeQPosition , 0);
    this.Suml1CTSposition = this.contractDetailsReport.reduce((total, item) => total + item.l1CTSposition , 0);
    this.Suml2CTSposition = this.contractDetailsReport.reduce((total, item) => total + item.l2CTSposition , 0);
    this.Suml3CTSposition = this.contractDetailsReport.reduce((total, item) => total + item.l3CTSposition , 0);
    this.SumtotalCTSPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalCTSPosition , 0);
    this.Suml1Othersposition = this.contractDetailsReport.reduce((total, item) => total + item.l1Othersposition , 0);
    this.Suml2Othersposition = this.contractDetailsReport.reduce((total, item) => total + item.l2Othersposition , 0);
    this.Suml3Othersposition = this.contractDetailsReport.reduce((total, item) => total + item.l3Othersposition , 0);
    this.SumtotalOtherPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalOtherPosition , 0);
    this.Suml1ClosedPosition = this.contractDetailsReport.reduce((total, item) => total + item.l1ClosedPosition , 0);
    this.Suml2ClosedPosition = this.contractDetailsReport.reduce((total, item) => total + item.l2ClosedPosition , 0);
    this.Suml3ClosedPosition = this.contractDetailsReport.reduce((total, item) => total + item.l3ClosedPosition , 0);
    this.SumtotalClosedPositions = this.contractDetailsReport.reduce((total, item) => total + item.totalClosedPositions , 0);
    this.SumopenL1Position = this.contractDetailsReport.reduce((total, item) => total + item.openL1Position , 0);
    this.SumopenL2Position = this.contractDetailsReport.reduce((total, item) => total + item.openL2Position , 0);
    this.SumopenL3Position = this.contractDetailsReport.reduce((total, item) => total + item.openL3Position , 0);
    this.SumtotalOpenPosition = this.contractDetailsReport.reduce((total, item) => total + item.totalOpenPosition , 0);
  }
}
