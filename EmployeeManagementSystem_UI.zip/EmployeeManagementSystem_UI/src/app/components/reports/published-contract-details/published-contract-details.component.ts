import { PublishedContractReport } from './../../../core/interfaces/published-contract-report';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Table } from 'primeng/table';
import { ReportsService } from 'src/app/core/services/reports/reports.service';

@Component({
  selector: 'app-published-contract-details',
  templateUrl: './published-contract-details.component.html',
  styleUrls: ['./published-contract-details.component.css']
})
export class PublishedContractDetailsComponent  implements OnInit {

  constructor(
    private readonly _reportsService: ReportsService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {}
  @ViewChild('tmMasterDetails') RMVisibleRows!: Table;
  gridTitle: string;
  gridCols!: any[];
  PublishedContractReport: PublishedContractReport[];
  reportType: string;
  reportTypeHeader: string;
  rowData: any[] = [];
  editedValue: any;
  data:any;
  publishedDate:any;
  ddFilter: { name: string, code: string }[] = [];
  selectedItem: any = { name: 'ALL', code: 'ALL' };
  ddlfilterProject: any[] = [];
  selectedItemproject?: any = { name: 'Run', code: 'Run' };
  SumRequiredPositions?:number;
  suml1?:number;
  Suml1onboarded?:number;
  Suml1openPostions?:number;
  Suml1selected?:number;
  Suml1backUp?:number;
  suml2?:number;
  Suml2onboarded?:number;
  Suml2openPostions?:number;
  Suml2selected?:number;
  Suml2backUp?:number;
  suml3?:number;
  Suml3onboarded?:number;
  Suml3openPostions?:number;
  Suml3selected?:number;
  Suml3backUp?:number;
  SumoverallOnboarded?:number;
  SumoverallOpenPostion?:number;
  Sumoverallselected?:number;
  Sumunfullfilled?:number;
  ngOnInit() {

    this.gridTitle = 'Open-Position Report Domain-wise';
    this.getContractReport();
    this.gridCols = [
      { field: 'towerlead', header: 'Tower Lead'},
      { field: 'customDomainName', header: 'Domain Name'},
      // { field: 'domain', header: 'Domain Skill Name'},
      { field: 'totalRequiredPositions', header: 'Total Required Positions'},
      { field: 'l1', header: 'L1'},
      { field: 'l1onboarded', header: 'L1 Onboarded'},
      { field: 'l1openPostions', header: 'L1 Open	Postions'},
      { field: 'l1ageingDays', header: 'Ageing Days'},
      { field: 'l1openedDate', header: 'Opened Date'},      
      { field: 'l1selected', header: 'L1 Selected'},
      { field: 'l1backup', header: 'L1 Backup'},
      { field: 'l1resourceDoj', header: 'Resource DOJ'},
      { field: 'l2', header: 'L2' },
      { field: 'l2onboarded', header: 'L2 Onboarded'},
      { field: 'l2openPositions', header: 'L2 Open	Postions' },
      { field: 'l2ageingDays', header: 'Ageing Days'},
      { field: 'l2openDate', header: 'Opened Date' },
      { field: 'l2selected', header: 'L2 Selected' },
      { field: 'l2backup', header: 'L2 Backup'},
      { field: 'l2resourceDoj', header: 'Resource DOJ'},
      { field: 'l3', header: 'L3' },
      { field: 'l3onboarded', header: 'L3 Onboarded'},
      { field: 'l3openPostions', header: 'L3 Open	Postions'},
      { field: 'l3ageingDays', header: 'Ageing Days' },
      { field: 'l3openDate', header: 'Opened Date'},
      { field: 'l3selected', header: 'L3 Selected' },
      { field: 'l3backup', header: 'L3 Backup'},
      { field: 'l3resourceDoj', header: 'Resource DOJ'},
      { field: 'overallOnboarded', header: 'Overall Onboarded'},
      { field: 'overallOpenPostion', header: 'Overall Open Postion'},
      { field: 'overallselected', header: 'Overall selected' },
      { field: 'unfullfilled', header: 'Unfullfilled' },
      // { field: 'publishedBy', header: 'Published By' },
       //{ field: 'publishedDate', header: 'Published On' },
    ];
    this.getTowerHeadMasterData();
    this.ddlfilterProject = [
      { name: 'ALL', code: 'ALL' },
      { name: 'Project', code: 'Project' },
      { name: 'Run', code: 'Run' },
    ];

  }
  getContractReport() {
    debugger;
    this._reportsService.GetpublishedContractDetails(this.selectedItem.code,this.selectedItemproject.code).subscribe((result: any[]) => {
     this.PublishedContractReport=result;
     if( this.PublishedContractReport!=null &&this.PublishedContractReport.length>0)
     {
      this.publishedDate=this.PublishedContractReport[0].publishedDate;
     }
      // this.publishedDate=this.PublishedContractReport[0].publishedDate;
      this.SumRequiredPositions=this.PublishedContractReport.reduce((total, item) => total + item.totalRequiredPositions, 0);
      this.suml1 = this.PublishedContractReport.reduce((total, item) => total + item.l1, 0);
      this.Suml1onboarded = this.PublishedContractReport.reduce((total, item) => total + item.l1onboarded, 0);
      this.Suml1openPostions = this.PublishedContractReport.reduce((total, item) => total + item.l1openPostions, 0);
      this.Suml1selected = this.PublishedContractReport.reduce((total, item) => total + item.l1selected, 0);
      this.Suml1backUp = this.PublishedContractReport.reduce((total, item) => total + item.l1backup, 0);
      this.suml2 = this.PublishedContractReport.reduce((total, item) => total + item.l2, 0);
      this.Suml2onboarded = this.PublishedContractReport.reduce((total, item) => total + item.l2onboarded, 0);
      this.Suml2openPostions = this.PublishedContractReport.reduce((total, item) => total + item.l2openPositions, 0);
      this.Suml2selected = this.PublishedContractReport.reduce((total, item) => total + item.l2selected, 0);
      this.Suml2backUp = this.PublishedContractReport.reduce((total, item) => total + item.l2backup, 0);
      this.suml3 = this.PublishedContractReport.reduce((total, item) => total + item.l3, 0);
      this.Suml3onboarded = this.PublishedContractReport.reduce((total, item) => total + item.l3onboarded, 0);
      this.Suml3openPostions = this.PublishedContractReport.reduce((total, item) => total + item.l3openPostions, 0);
      this.Suml3selected = this.PublishedContractReport.reduce((total, item) => total + item.l3selected, 0);
      this.Suml3backUp = this.PublishedContractReport.reduce((total, item) => total + item.l3backup, 0);
      this.SumoverallOnboarded = this.PublishedContractReport.reduce((total, item) => total + item.overallOnboarded, 0);
      this.SumoverallOpenPostion = this.PublishedContractReport.reduce((total, item) => total + item.overallOpenPostion, 0);
      this.Sumoverallselected = this.PublishedContractReport.reduce((total, item) => total + item.overallselected, 0);
      this.Sumunfullfilled = this.PublishedContractReport.reduce((total, item) => total + item.unfullfilled, 0);
    //  }
    });
        
  }
  getTowerHeadMasterData()
  {
      this._reportsService.getTowerHeadMasterData().subscribe((result) => {
        // Assuming `result` is an array
      this.ddFilter = result.map((item: any) => ({ name: item, code: item }));
      // Adding a new object at the beginning of `this.ddFilter`
      this.ddFilter.unshift({ name: 'ALL', code: 'ALL' });
      });
   
  }
  SearchData()
  {
      this.getContractReport();
  }
  // changeCalculation()
  // {
  //   debugger;
  //   var visiblerows = this.RMVisibleRows.filteredValue
  //   ? this.RMVisibleRows.filteredValue
  //   : this.PublishedContractReport;

  //   // if (visiblerows.length > 0) {
  //   //   const finalSum = visiblerows.reduce((acc, item) => {
  //   //     acc.suml1 += item.l1 || 0;
  //   //     acc.suml2 += item.l2 || 0;
  //   //     acc.suml3 += item.l3 || 0;
  //   //     acc.Suml1onboarded += item.Suml1onboarded || 0;
  //   //     acc.Suml2onboarded += item.Suml2onboarded || 0;
  //   //     acc.Suml3onboarded += item.Suml3onboarded || 0;
  //   //     acc.overallOnboarded += item.overallOnboarded || 0;
  //   //     acc.overallOpenPosition += item.overallOpenPosition || 0;
  //   //     acc.overallSelected += item.overallSelected || 0;
  //   //     acc.unfulfilled += item.unfulfilled || 0;
  //   //     return acc;
  //   //   });
    
  //   //   // Assign final sums to class properties
  //   //   this.suml1 = finalSum.suml1;
  //   //   this.suml2 = finalSum.suml2;
  //   //   this.suml3 = finalSum.suml3;
  //   //   this.SumoverallOnboarded = finalSum.overallOnboarded;
  //   //   this.SumoverallOpenPostion = finalSum.overallOpenPosition;
  //   //   this.Sumoverallselected = finalSum.overallSelected;
  //   //   this.Sumunfullfilled = finalSum.unfulfilled;
  //   // }
    



  // // if (visiblerows.length > 0) {
  
  // // this.suml1 =  this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l1, 0);
  // // this.Suml1onboarded =  this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l1onboarded, 0);
  // // this.Suml1openPostions = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l1openPostions, 0);
  // // this.Suml1selected = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l1selected, 0);
  // // this.Suml1backUp = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l1backup, 0);
  // // this.suml2 = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2, 0);
  // // this.Suml2onboarded = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2onboarded, 0);
  // // this.Suml2openPostions = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2openPositions, 0);
  // // this.Suml2selected = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2selected, 0);
  // // this.Suml2backUp = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2backup, 0);
  // // this.suml3 = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l2, 0);
  // // this.Suml3onboarded = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l3onboarded, 0);
  // // this.Suml3openPostions = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l3openPostions, 0);
  // // this.Suml3selected = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l3selected, 0);
  // // this.Suml3backUp = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.l3backup, 0);
  // // this.SumoverallOnboarded = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.overallOnboarded, 0);
  // // this.SumoverallOpenPostion = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.overallOpenPostion, 0);
  // // this.Sumoverallselected = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.overallselected, 0);
  // // this.Sumunfullfilled = this.RMVisibleRows.filteredValue.reduce((total, item) => total + item.unfullfilled, 0);
  // // }
  //  }
}

