import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublishedContractDetailsComponent } from './published-contract-details.component';

describe('PublishedContractDetailsComponent', () => {
  let component: PublishedContractDetailsComponent;
  let fixture: ComponentFixture<PublishedContractDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PublishedContractDetailsComponent]
    });
    fixture = TestBed.createComponent(PublishedContractDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
