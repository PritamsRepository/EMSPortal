import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmUploadComponent } from './tm-upload.component';

describe('TmUploadComponent', () => {
  let component: TmUploadComponent;
  let fixture: ComponentFixture<TmUploadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmUploadComponent]
    });
    fixture = TestBed.createComponent(TmUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
