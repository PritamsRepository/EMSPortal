import {
  AfterContentInit,
  AfterViewInit,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MessageService, ConfirmationService, MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { iTmContractModal, itmUpload } from 'src/app/core/interfaces/itmupload';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';
import {
  FileSelectEvent,
  FileSendEvent,
  FileUploadErrorEvent,
  FileUploadHandlerEvent,
  UploadEvent,
} from 'primeng/fileupload';
import { environment } from 'src/environments/environment';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { excelFileValidation } from 'src/app/core/services/excelFilevalidation.service';
import { fileDownload } from 'src/app/core/services/fileDownload.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { OverlayPanel } from 'primeng/overlaypanel';

@Component({
  selector: 'app-tm-upload',
  templateUrl: './tm-upload.component.html',
  styleUrls: ['./tm-upload.component.css'],
  providers: [MessageService, ConfirmationService, DialogService],
})
export class TmUploadComponent implements AfterContentInit {
  constructor(
    private tmUploadService: TmUploadService,
    private excelFileValidationService: excelFileValidation,
    private tempDownloadService: fileDownload,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    private readonly _storageService: StorageService
  ) {}

  @ViewChild('fileUpload') fileUpload!: OverlayPanel;

  isChecked: boolean = true;
  gridTitle: string = 'Time & Material Contract Upload';
  tmUploads!: itmUpload[];
  tmUpload!: itmUpload;
  cols!: any[];
  selectedDetails!: itmUpload[] | null;
  ref: DynamicDialogRef | undefined;
  uploadUrl: string = `${environment.API_URL}/Contracts/TMContractUpload`;
  invalidDetails!: itmUpload[] | null;
  uploadedFiles: any[] = [];
  fileValidation: string = '';
  showUploadButton: boolean = false;
  loading: boolean = false;
  uploadedFile!: File;
  iTmContractModal: iTmContractModal[];

  ngAfterContentInit() {
    this.getTmContractIntermediateDetails();
    this.cols = [
      { field: 'validationRemarks', header: 'Validation Remarks' },
      { field: 'etwid', header: 'ETWID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'positionLocation', header: 'Managing Team' },
      { field: 'oldSowNumber', header: 'Old SOW Number' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowType', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date', type: 'date' },
      { field: 'sowEndDate', header: 'SOW End Date', type: 'date' },
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date', type: 'date' },
      { field: 'poEndDate', header: 'PO End Date', type: 'date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'wbsDetail', header: 'WBS Detail' },
      { field: 'vertical', header: 'Vertical' },
      { field: 'tower', header: 'Tower' },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },
      { field: 'costCenter', header: 'Cost Center Code' },
      { field: 'obs', header: 'OBS' },
      { field: 'domainSkillName', header: 'Domain Skill Name' },
      { field: 'skillSet', header: 'Skill Set' },
      {
        field: 'domainSkillStartDate',
        header: 'Domain Skill Start Date',
        type: 'date',
      },
      {
        field: 'domainSkillEndDate',
        header: 'Domain Skill End Date',
        type: 'date',
      },
      { field: 'projectOrRun', header: 'Project Or Run' },
      { field: 'contractType', header: 'Contract Type' },
      { field: 'billingType', header: 'Billing Type' },
      { field: 'currency', header: 'Currency' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },
      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'remappedMID', header: 'Existing MID' },
      { field: 'sapCode', header: 'SAP Code' },
      { field: 'noticePeriod', header: 'Notice Period' },
      { field: 'customDomainName', header: 'Domain Name' },
    ];
  }

  downloadTmTemplateFile() {
    this.tempDownloadService
      .downloadFile('assets/contract-data-template/TmContract_Template.xlsx') //add the path of the file as a parameter
      .subscribe((data: Blob) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = window.URL.createObjectURL(blob);

        // Create a link element and click it to trigger the download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'TmContract_Template.xlsx'; //rename it to ur file name.
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      });
  }

  getTmContractIntermediateDetails() {
    this.loading = true;

    this.tmUploadService.getTMContractIntermediateDetails().subscribe({
      next: (result: itmUpload[]) => {
        this.tmUploads = result;

        //console.log(result);
        this.selectedDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks == null || item.validationRemarks == ''
          )
          .map((item: any) => item);

        this.invalidDetails = result
          .filter(
            (item: any) =>
              item.validationRemarks != null && item.validationRemarks != ''
          )
          .map((item: any) => item);

        //console.log('IN-Valid : ', this.invalidDetails);
        //console.log('Valid : ', this.selectedDetails);

        if (this.selectedDetails.length > 0 || this.invalidDetails.length > 0) {
          this.messageService.add({
            severity: 'info',
            summary: 'Fetched',
            detail: 'T&M contract details fetched successfully.',
          });
        } else {
          this.messageService.add({
            severity: 'warn',
            summary: 'No Records',
            detail: 'No t&m contract details found.',
          });
        }
        this.loading = false;
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch t&m contract details.',
        });
      },
    });
  }

  sendDetailsForAction(selectedDetails: any, action: string) {
    var tmcidArray: number[] = [];

    try {
      tmcidArray = selectedDetails.map((item: any) => item.tmcid);
    } catch {
      tmcidArray.push(selectedDetails.tmcid);
    }

    if (action == 'save') {
      this.tmUploadService
        .saveTMContractIntermediateDetails(tmcidArray)
        .subscribe({
          next: (res) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Saved',
              detail: 'T&M contract details saved successfully.',
            });
          },
          complete: () => {
            this.getTmContractIntermediateDetails();
          },
          error: (err) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: 'Failed to save t&m contract details.',
            });
          },
        });
    } 
    else {
      this.tmUploadService
        .removeTMContractIntermediateDetails(tmcidArray)
        .subscribe({
          next: (res) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Deleted',
              detail: 'T&M contract details deleted successfully.',
            });
          },
          complete: () => {
            this.getTmContractIntermediateDetails();
          },
          error: (err) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: 'Failed to delete t&m contract details.',
            });
          },
        });
    }
  }

  confirm(event: Event, data: itmUpload[]) {
    //console.log(data.length);
    if (data) {
      this.confirmationService.confirm({
        target: event.target as EventTarget,
        message: 'Are you sure that you want to proceed?',
        icon: 'fa-solid fa-exclamation-triangle',
        accept: () => {
          this.sendDetailsForAction(data, 'remove');
        },
        reject: () => {
          // this.messageService.add({
          //   severity: 'error',
          //   summary: 'Canceled!',
          //   detail: 'No Record Deleted',
          // });
        },
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'No Invalid Records Found!',
        detail: 'There are no invalid records to delete.',
      });
    }
  }

  isRowSelectable(event: any) {
    return !(event.data.validationRemarks === ''
      ? false
      : event.data.validationRemarks == null
      ? false
      : true);
  }

  isValidationAvailable(data: itmUpload) {
    this.isChecked =
      data.validationRemarks === ''
        ? false
        : data.validationRemarks == null
        ? false
        : true;
    return this.isChecked;
  }

  onTMUplaod(event: UploadEvent) {
    this.messageService.add({
      severity: 'success',
      summary: 'Imported',
      detail: 'Fetching T&M Contract Details.',
    });

    this.getTmContractIntermediateDetails();
    this.fileUpload.hide();
  }

  onTMError(event: FileUploadErrorEvent) {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Failed to Upload a file.',
    });
  }

  onTMSend(event: FileSendEvent) {
    this.messageService.add({
      severity: 'info',
      summary: 'Sent',
      detail: 'Your file has been sent to upload.',
    });
  }

  checkAndValidateTmDetails(event: FileSelectEvent) {
    const file = event.currentFiles[0];
    const reader = new FileReader();

    reader.onload = (e: any) => {
      const fileContent = e.target.result;
      // //console.log('fileContent : ', fileContent);
      const result =
        this.excelFileValidationService.validateForDuplicatRecords(fileContent);
      const inValidFile =
        this.excelFileValidationService.checkforValidTmTemplateFile(
          fileContent,
          'tm'
        );

      if (inValidFile.isInvalidTemplate) {
        this.showUploadButton = !inValidFile.isInvalidTemplate;
        this.fileValidation = inValidFile.message;
      } else {
        if (result.hasDuplicateRecords) {
          this.showUploadButton = !result.hasDuplicateRecords;
          this.fileValidation = result.message;
        } else {
          this.showUploadButton = !result.hasDuplicateRecords;
          this.fileValidation = result.message;
        }
      }
    };

    reader.readAsBinaryString(file);
  }

  sendTMDetailsToUplaod(event: FileUploadHandlerEvent) {
    //console.log('Custom event', event);
    //console.log('Custom event Files : ', event.files);
    if (event && event.files) {
      const file = event.files[0];
      const reader = new FileReader();

      reader.onload = (e: any) => {
        const fileContent = e.target.result;
        const result = fileContent;
        this.iTmContractModal =
          this.excelFileValidationService.convertExcelFileToModal(result, 'tm');

        //console.log('Data to Upload : ', this.iTmContractModal);

        this.tmUploadService.UploadTMDetails(this.iTmContractModal).subscribe({
          next: (res) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Imported',
              detail: 'Fetching T&M Contract Details.',
            });
            this.fileUpload.hide();
          },
          complete: () => {
            this.getTmContractIntermediateDetails();
          },
          error: (err) => {
            //console.log('Upload error :', err.errorMessage);
            this.messageService.add({
              severity: 'error',
              summary: 'Failed',
              detail: 'Failed to uplaod T&M Contract Details.',
            });
            this.fileUpload.hide();
          },
        });
      };

      reader.readAsBinaryString(file);
    }
  }

  exportExcel() {
    import('xlsx').then((xlsx) => {
      // Clone the original data to avoid modifying the original array
      const data = JSON.parse(JSON.stringify(this.invalidDetails));
      //console.log('DAAATA : ', data);
      const datePipe = new DatePipe('en-US');
      // Define the columns to be removed (replace with your actual column names)
      const columnsToRemove = [
        'tmcmid',
        'tmvcmid',
        'tmcid',
        'isSelectedApproval',
        'remarks',
        'vendoreMail',
        'wfOrder',
        'status',
        'pendingwithwhom',
      ];

      // Remove specified columns from the data
      data.forEach((row: { [x: string]: any }) => {
        columnsToRemove.forEach((col) => {
          delete row[col];
        });
      });

      data.forEach((row: { [x: string]: any }) => {
        Object.keys(row).forEach((col) => {
          if (
            [
              'sowStartDate',
              'sowEndDate',
              'poStartDate',
              'poEndDate',
              'domainSkillEndDate',
              'domainSkillStartDate',
            ].includes(col)
          ) {
            // Check if the column value is a valid date string
            const existingDate = new Date(row[col]);
            if (!isNaN(existingDate.getTime())) {
              // Format the date using DatePipe
              const formattedDate = datePipe.transform(
                existingDate,
                'dd-MMM-yyyy'
              );
              // Update the row with the formatted date
              row[col] = formattedDate;
            }
          }
        });
      });

      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      // //console.log(workbook);
      // //console.log('--------------------------------------------------');
      // //console.log(excelBuffer);
      this.saveAsExcelFile(
        excelBuffer,
        'TIME & MATERIAL CONTRACT UPLOAD(Invalid Records)'
      );
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
      data,
      fileName + '_' + new Date().getTime() + EXCEL_EXTENSION
    );
  }
}
