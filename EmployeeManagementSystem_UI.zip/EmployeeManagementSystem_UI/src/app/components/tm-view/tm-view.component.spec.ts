import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmViewComponent } from './tm-view.component';

describe('TmViewComponent', () => {
  let component: TmViewComponent;
  let fixture: ComponentFixture<TmViewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmViewComponent]
    });
    fixture = TestBed.createComponent(TmViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
