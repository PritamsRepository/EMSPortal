import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmWorkflowComponent } from './tm-workflow.component';

describe('TmWorkflowComponent', () => {
  let component: TmWorkflowComponent;
  let fixture: ComponentFixture<TmWorkflowComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmWorkflowComponent]
    });
    fixture = TestBed.createComponent(TmWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
