import { AfterContentInit, Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';

@Component({
  selector: 'app-tm-workflow',
  templateUrl: './tm-workflow.component.html',
  styleUrls: ['./tm-workflow.component.css'],
  providers: [DynamicDialogRef],
})
export class TmWorkflowComponent implements AfterContentInit {
  constructor(
    private readonly _ref: DynamicDialogRef,
    private readonly _config: DynamicDialogConfig,
    private readonly _tmUpload: TmUploadService,
    private readonly ROBService: ResourceOnboardingService
  ) {}
  cols!: any[];
  Poscols!: any[];
  tmWfDetails!: any[];
  tmposDetails!: any[];
  showPosDetails: boolean = false;
  ngAfterContentInit() {
    //console.log('data for dialog : ', this._config.data);
    //console.log('data for dialog : ', this._config.data.tmcmid);
    this._tmUpload.getTMContractWorkFlow(this._config.data.tmvcmid).subscribe({
      next: (result) => {
        //console.log('RESULT : ', result);
        this.tmWfDetails = result.map((item) => {
          item.actionByName = item.actionByName;
          return item;
        });
        this.cols = [
          { field: 'role', header: 'Role' },
          { field: 'actionByName', header: 'Action By' },
          { field: 'action', header: 'Action' },
          { field: 'actionDate', header: 'Action Date', type: 'date' },
          { field: 'remarks', header: 'Remarks' },
          { field: 'nextWfrole', header: 'Redirected To' },
        ];
        if (this.tmWfDetails.length == 0) {
          alert('No Work Flow.');
        } else {
          this.ROBService.GetTMmultiRcrsByPsCode(
            this._config.data.positionCode
          ).subscribe((tmposDetailsresult) => {
            //console.log(tmposDetailsresult);
            this.tmposDetails = tmposDetailsresult.map(
              (item: { firstName: any; lastName: any }) => {
                // console.log(item.firstName);
                // console.log(item.lastName);
                // Concatenate firstName and lastName to create Fullname
                const fullname = `${item.firstName} ${item.lastName}`;

                // Add Fullname property to the item
                return {
                  ...item,
                  Fullname: fullname,
                };
              }
            );

            if (this.tmposDetails.length != 0) {
              this.showPosDetails = true;
            }
            this.Poscols = [
              { field: 'positionCode', header: 'Position Code' },
              { field: 'Fullname', header: 'Name' },
              { field: 'viatrisMID', header: 'MID' },

              // { field: 'firstName', header: 'First Name' },
              // { field: 'lastName', header: 'last Name' },
              { field: 'mappedBy', header: 'Mapped By' },
              { field: 'mappedDate', header: 'Mapped Date', type: 'date' },
              {
                field: 'isMappingActive',
                header: 'Is Mapping Active',
                type: 'boolean',
              },
              { field: 'status', header: 'Resource Status' },
              { field: 'vendorName', header: 'Vendor Name' },
            ];
          });
        }
      },
      error: (error) => {
        console.error('Error fetching workflow details:', error);
        // Handle error as needed
      },
    });
  }
}
