import {
  AfterContentInit,
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { MessageService } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { itmUpload } from 'src/app/core/interfaces/itmupload';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';
import { TmWorkflowComponent } from './tm-workflow/tm-workflow.component';
import * as FileSaver from 'file-saver';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-tm-view',
  templateUrl: './tm-view.component.html',
  styleUrls: ['./tm-view.component.css'],
  providers: [MessageService, DialogService],
})
export class TmViewComponent implements AfterContentInit {
  constructor(
    private tmUploadService: TmUploadService,
    private messageService: MessageService,
    public dialogService: DialogService
  ) {}

  gridTitle: string = 'Time & Material Contract Details';
  cols!: any[];
  tmDetails!: itmUpload[];
  ddFilter: any[] = [];
  selectedFilter?: any = { name: 'Active Records', code: 'Active' };
  ref!: DynamicDialogRef;
  datePipe = new DatePipe('en-US');

  tmDetailsbackup!: itmUpload[];
  FilterMyData(data: any, typo: string) {
    //console.log(data.value);
    //console.log(typo);
    this.tmDetails = data.value.map((item: any) => {
      item.domainSkillStartDate = this.datePipe.transform(
        item.domainSkillStartDate,
        'dd-MMM-yyyy'
      );

      item.domainSkillEndDate = this.datePipe.transform(
        item.domainSkillEndDate,
        'dd-MMM-yyyy'
      );
      item.poStartDate = this.datePipe.transform(
        item.poStartDate,
        'dd-MMM-yyyy'
      );
      item.poEndDate = this.datePipe.transform(item.poEndDate, 'dd-MMM-yyyy');
      item.sowStartDate = this.datePipe.transform(
        item.sowStartDate,
        'dd-MMM-yyyy'
      );
      item.sowEndDate = this.datePipe.transform(item.sowEndDate, 'dd-MMM-yyyy');
      item.uploadedDate = this.datePipe.transform(
        item.uploadedDate,
        'dd-MMM-yyyy'
      );

      return item;
    });
    // Example entered text for search
    //alert(typo.length);
    if (typo != '') {
      const searchText = typo;

      // Filter the array based on the entered text
      const searchResults = data.value.filter(
        (item: { [x: string]: string }) => {
          // Convert all property values to lowercase for case-insensitive search
          for (const key in item) {
            if (
              typeof item[key] === 'string' &&
              item[key].toLowerCase().includes(searchText.toLowerCase())
            ) {
              return true; // Match found, include in results
            }
          }
          return false; // No match found
        }
      );
      this.tmDetails = searchResults;
      //console.log('Search-Results : ', searchResults);
    } else {
      this.tmDetails = this.tmDetailsbackup;
    }
    return this.tmDetails;
  }
  ngAfterContentInit() {
    this.ddFilter = [
      { name: 'All', code: 'All' },
      { name: 'Active Records', code: 'Active' },
      { name: 'InActive Records', code: 'InActive' },
    ];

    this.getTmContractMainDetails(this.selectedFilter);
    this.cols = [
      { field: 'status', header: 'Status' },
      { field: 'pendingWithWhom', header: 'Pending With Whom' },

      { field: 'etwid', header: 'ETWID' },
      { field: 'positionCode', header: 'Position Code' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'locationName', header: 'Managing Team' },
      { field: 'remappedMID', header: 'Existing MID' },

      { field: 'oldSOWNumber', header: 'Old SOW Number' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowTypeName', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date', type: 'date' },
      { field: 'sowEndDate', header: 'SOW End Date', type: 'date' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'customDomainName', header: 'Domain Name' },
      { field: 'domainName', header: 'Domain Skill Name' },

      {
        field: 'domainSkillStartDate',
        header: 'Domain Skill Start Date',
        type: 'date',
      },
      {
        field: 'domainSkillEndDate',
        header: 'Domain Skill End Date',
        type: 'date',
      },
      { field: 'domainLeadEmail', header: 'Domain Lead Email' },

      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date', type: 'date' },
      { field: 'poEndDate', header: 'PO End Date', type: 'date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'towerName', header: 'Tower' },
      { field: 'costCenter', header: 'Cost Center Code' },

      { field: 'verticalName', header: 'Vertical' },
      { field: 'obs', header: 'OBS' },

      { field: 'wbsDetail', header: 'WBS Detail' },

      { field: 'projectOrRun', header: 'Project Or Run' },
      { field: 'contractTypeName', header: 'Contract Type' },
      { field: 'billingTypeName', header: 'Billing Type' },
      { field: 'currency', header: 'Currency' },
      { field: 'billingRateYear1', header: 'Billing Rate Year 1' },
      { field: 'billingRateYear2', header: 'Billing Rate Year 2' },
      { field: 'billingRateYear3', header: 'Billing Rate Year 3' },
      { field: 'billingRateYear4', header: 'Billing Rate Year 4' },
      { field: 'billingRateYear5', header: 'Billing Rate Year 5' },
      { field: 'sapCode', header: 'SAP Code' },
      { field: 'noticePeriod', header: 'Notice Period' },

      { field: 'isActive', header: 'Is Active', type: 'bool' },
      { field: 'uploadedBy', header: 'Uploaded By' },
      { field: 'uploadedDate', header: 'Upload Date', type: 'date' },
    ];
  }

  getTmContractMainDetails(selectedFilter: any) {
    this.tmUploadService
      .getTMContractMainDetails(selectedFilter['code'])
      .subscribe({
        next: (result: itmUpload[]) => {
          this.tmDetails = result;
          this.tmDetailsbackup = this.tmDetails;
          // this.tmDetails = this.tmDetails.map((item) => {
          //   if (item.uploadDate != null) {
          //     item.uploadDate = this.datePipe.transform(
          //       item.uploadDate,
          //       'dd-MMM-yyyy'
          //     );
          //   }
          //   return item;
          // });
          //console.log('Details : ', this.tmDetails);
          if (this.tmDetails.length > 0) {
            this.messageService.add({
              severity: 'info',
              summary: 'Fetched',
              detail: 'T&M contract details fetched successfully.',
            });
          } else {
            this.messageService.add({
              severity: 'warn',
              summary: 'No Records',
              detail: 'No t&m contract details found.',
            });
          }
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to fetch t&m contract details.',
          });
        },
      });
  }

  // updateValue(rowData: any, rowItem: string) {
  //   let newValue = rowItem;
  //   if (rowItem === 'Position Onboarded' && rowData['isActive'] === false) {
  //     newValue = 'Contract InActive';
  //   }
  //   return newValue;
  // }

  getSeverity(data: itmUpload) {
    switch (data.status) {
      case 'Position Open':
        return 'danger';
      case 'Pending':
        return 'warning';
      case 'Position Onboarded':
        return 'success';
      case 'Filled By Other':
        return 'default';
      case 'Revoked':
        return 'info';
      case 'Contract InActive':
        return 'info';
      default:
        return 'default';
    }
  }

  viewTmWorkFlow(data: itmUpload) {
    //console.log('Data : ', data);
    this.ref = this.dialogService.open(TmWorkflowComponent, {
      header: 'Work Flow History  - (ETWID : ' + data.etwid + ')',
      data: data,
      width: '70%',
      contentStyle: { overflow: 'auto' },
      baseZIndex: 2204,
      maximizable: true,
    });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }

  exportExcel() {
    import('xlsx').then((xlsx) => {
      // Clone the original data to avoid modifying the original array
      const data = JSON.parse(JSON.stringify(this.tmDetails));
      //console.log('DAAATA : ', data);

      // Define the columns to be removed (replace with your actual column names)
      const columnsToRemove = [
        'tmcmid',
        'tmvcmid',
        'tmcid',
        'isSelectedApproval',
        'remarks',
        'vendoreMail',
        'wfOrder',
        'status',
        'pendingwithwhom',
      ];

      //// Remove specified columns from the data
      data.forEach((row: { [x: string]: any }) => {
        columnsToRemove.forEach((col) => {
          delete row[col];
        });
      });

      data.forEach((row: { [x: string]: any }) => {
        Object.keys(row).forEach((col) => {
          if (
            [
              'sowStartDate',
              'sowEndDate',
              'poStartDate',
              'poEndDate',
              'domainSkillEndDate',
              'domainSkillStartDate',
              'uploadedDate',
            ].includes(col)
          ) {
            // Check if the column value is a valid date string
            const existingDate = new Date(row[col]);
            if (!isNaN(existingDate.getTime())) {
              // Format the date using DatePipe
              const formattedDate = this.datePipe.transform(
                existingDate,
                'dd-MMM-yyyy'
              );
              // Update the row with the formatted date
              row[col] = formattedDate;
            }
          }
        });
      });

      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      // //console.log(workbook);
      // //console.log('--------------------------------------------------');
      // //console.log(excelBuffer);
      this.saveAsExcelFile(excelBuffer, 'TIME & MATERIAL CONTRACT');
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
      data,
      fileName + '_' + new Date().getTime() + EXCEL_EXTENSION
    );
  }
}
