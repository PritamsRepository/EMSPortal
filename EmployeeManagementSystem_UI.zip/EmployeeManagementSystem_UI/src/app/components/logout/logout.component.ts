import { AfterContentInit, AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css'],
})
export class LogoutComponent implements OnInit {
  /**
   *
   */
  constructor(
    private readonly router: Router,
    private readonly _authentication: AuthenticationService,
    private readonly _storageService: StorageService
  ) { }

  ngOnInit(): void {
    this._authentication.logout().subscribe({
      next: (res) => {
        this._storageService.clean();
        this.router.navigate(['/login']);
       window.location.reload();
      },
      error(err) {
        //window.location.reload();
        //console.log(err);
      },
    });
  }
  
}

