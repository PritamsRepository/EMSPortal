import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmBulkUpdateComponent } from './tm-bulk-update.component';

describe('TmBulkUpdateComponent', () => {
  let component: TmBulkUpdateComponent;
  let fixture: ComponentFixture<TmBulkUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmBulkUpdateComponent]
    });
    fixture = TestBed.createComponent(TmBulkUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
