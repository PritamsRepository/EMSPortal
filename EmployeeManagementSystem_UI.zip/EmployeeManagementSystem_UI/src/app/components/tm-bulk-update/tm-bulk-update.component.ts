import { DatePipe, formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MessageService, ConfirmationService } from 'primeng/api';
import { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { DialogService } from 'primeng/dynamicdialog';
import { BulkUpdateFilterType } from 'src/app/core/interfaces/bulk-update-filter-type';
import { EmsFetchContactListBySowNo } from 'src/app/core/interfaces/ems-fetch-contact-list-by-sow-no';
import { BulkUpdateValidation, FieldType } from 'src/app/core/interfaces/field-type';
import { iBillingTypeMaster, iProjectOrRunMaster } from 'src/app/core/interfaces/imasterDetails';
import { SowList } from 'src/app/core/interfaces/sow-list';
import { SharedService } from 'src/app/core/services/shared.service';
import { TmUploadService } from 'src/app/core/services/tm-upload/tm-upload.service';
import { ContractTypeConstant, CT_NAMES } from 'src/app/core/utiltz/ContractTypeConstant';

@Component({
  selector: 'app-tm-bulk-update',
  templateUrl: './tm-bulk-update.component.html',
  styleUrls: ['./tm-bulk-update.component.css'],
  providers: [MessageService, ConfirmationService, DialogService, DatePipe],
})

export class TmBulkUpdateComponent implements OnInit {
  constructor(
    private messageService: MessageService,
    public sharedService: SharedService,
    public dialogService: DialogService,
    public tmUploadService: TmUploadService,
    private fb: FormBuilder,
    private datePipe: DatePipe
  ) { }

  pageTitle: string = 'BULK UPDATE CONTRACTS';
  contractTypeSuggestions: any[] | undefined;
  defaultContractType: string = ContractTypeConstant.TM;
  bulkUpdateForm: FormGroup;
  sowNumberSuggestions: any[] | undefined;
  defaultSowType: any[];
  fieldSuggestions: any[] | undefined;
  isContractValid: boolean = true;
  isSowNumberValid: boolean = false;
  isFieldValid: boolean = false;
  billingTypeDetails!: iBillingTypeMaster[];
  projectOrRunDetails!: iProjectOrRunMaster[];
  isDateField: boolean = false;
  contractListBySowNo: EmsFetchContactListBySowNo[] = [];
  selectedDetails: EmsFetchContactListBySowNo[] = [];
  cols: any[] = []; 

  originalSearchFieldNames = [
    { fieldName: 'SOWNumber', displayName: 'SOW Number', dataType: 'string', column: 'sowNumber' },
    { fieldName: 'SOWName', displayName: 'SOW Name', dataType: 'string', column: 'sowName' },
    { fieldName: 'SOWStartDate', displayName: 'SOW Start Date', dataType: 'date', column: 'sowStartDate' },
    { fieldName: 'SOWEndDate', displayName: 'SOW End Date', dataType: 'date', column: 'sowEndDate' },
    { fieldName: 'PONumber', displayName: 'PO Number', dataType: 'string', column: 'poNumber' },
    { fieldName: 'POStartDate', displayName: 'PO Start Date', dataType: 'date', column: 'poStartDate' },
    { fieldName: 'POEndDate', displayName: 'PO End Date', dataType: 'date', column: 'poEndDate' },
    { fieldName: 'PPMProjectID', displayName: 'PPM Project ID', dataType: 'string', column: 'ppmProjectID' },
    { fieldName: 'PPMProjectName', displayName: 'PPM Project Name', dataType: 'string', column: 'ppmProjectName' },
    { fieldName: 'WBSDetail', displayName: 'WBS Detail', dataType: 'string', column: 'wbsDetail' },
    { fieldName: 'CostCenter', displayName: 'Cost Center', dataType: 'string', column: 'costCenter' },
    { fieldName: 'OBS', displayName: 'OBS', dataType: 'string', column: 'obs' },
    { fieldName: 'ProjectOrRunID', displayName: 'Project or Run', dataType: 'string', column: 'projectOrRunID' },
    { fieldName: 'BillingTypeID', displayName: 'Billing Type', dataType: 'string', column: 'billingTypeID' },
    { fieldName: 'SAPCode', displayName: 'SAP Code', dataType: 'string', column: 'sapCode' },
    { fieldName: 'NoticePeriod', displayName: 'Notice Period Days', dataType: 'number', column: 'noticePeriod' }
  ];
  searchfieldNames = [...this.originalSearchFieldNames];

  ngOnInit() {
    this.contractTypeSuggestions = CT_NAMES;
    this.getActiveProjectAndBillType();
    this.bulkUpdateForm = this.fb.group({
      contractType: [this.defaultContractType],
      sowNumber: [this.defaultSowType],
      field: [''],
      oldValue: [''],
      newValue: ['']
    });
  }

  searchcontractType(event: AutoCompleteCompleteEvent) {
    const query = event.query ? event.query.toLowerCase() : '';
    let filtered = CT_NAMES.filter(item => item.toLowerCase().includes(query));
    this.contractTypeSuggestions = filtered;
    if (filtered.length === 0) {
      this.isContractValid = false;
      this.messageService.add({
        severity: 'info',
        summary: 'No Data',
        detail: 'Not a valid contract type.',
      });
    }
  }

  onContractTypeSelect(event: any) {
    this.isContractValid = this.contractTypeSuggestions.includes(event?.value);
    if (this.isContractValid && event?.value !== ContractTypeConstant.TM) {
      this.searchfieldNames = this.originalSearchFieldNames.filter(field =>
        !['OBS', 'SAPCode', 'NoticePeriod'].includes(field.fieldName)
      );
    } else {
      this.searchfieldNames = [...this.originalSearchFieldNames];
    }
    this.bulkUpdateForm.patchValue({
      sowNumber: [''],
      field: [''],
      oldValue: '',
      newValue: ''
    });
    this.contractListBySowNo =[];
    this.setValidationToFalse();
  }

  searchsowNumber(event: AutoCompleteCompleteEvent) {
    const query = event.query;
    this.contractListBySowNo = [];
    if (query && query.length >= 3) {
      const selectedContractType = this.bulkUpdateForm.get('contractType')?.value;
      if (selectedContractType) {
        this.isSowNumberValid = false;
        this.GetSowListByContractType(selectedContractType, query);
      }
    }
  }

  onSowNumberSelect(event: any) {
    this.isSowNumberValid = this.sowNumberSuggestions.includes(event?.value);
    this.bulkUpdateForm.patchValue({
      newValue: '',
    }, { emitEvent: false });
    this.loadOldValue();
    const contractType = this.bulkUpdateForm.get('contractType').value;
    if (this.isContractValid && this.isSowNumberValid) {
      this.GetAllSowListByContractType(contractType, event?.value);
    }
  }

  searchfield(event: AutoCompleteCompleteEvent) {
    const query = event.query ? event.query.toLowerCase() : '';
    if (query.length >= 3) {
      this.bulkUpdateForm.patchValue({
        oldValue: '',
        newValue: '',
      }, { emitEvent: false });

      const searchfieldNames = this.searchfieldNames.map(field => field.displayName);
      const filtered = searchfieldNames
        .filter(displayName => displayName.toLowerCase().includes(query))
        .map(displayName => displayName);

      if (filtered.length === 0) {
        this.isFieldValid = false;
        this.messageService.add({
          severity: 'info',
          summary: 'No Data',
          detail: 'Not a valid field type.',
        });
      } else {
        this.fieldSuggestions = filtered;
      }
    } else {
      this.bulkUpdateForm.patchValue({
        oldValue: '',
        newValue: '',
      }, { emitEvent: false });
      this.fieldSuggestions = this.searchfieldNames.map(field => field.displayName).map(displayName => displayName); // Clear suggestions if query length is less than 3
    }
  }

  onFieldSelect(event: any) {
    this.isFieldValid = this.fieldSuggestions.includes(event?.value);
    if (this.isFieldValid) {
      const selectedField = this.searchfieldNames.find(f => f.displayName === event?.value);
      this.isDateField = selectedField?.dataType === 'date';
      this.loadOldValue();
    }
  }

  loadOldValue() {
    if (this.isContractValid && this.isSowNumberValid && this.isFieldValid) {
      const displayName = this.bulkUpdateForm.get('field').value;
      const contractType = this.bulkUpdateForm.get('contractType').value;
      const SOWNumber = this.bulkUpdateForm.get('sowNumber').value;
      this.GetOldValueByContractSowType(
        contractType,
        SOWNumber,
        displayName
      );
    }
  }

  onSubmit() {
    if (this.bulkUpdateForm.valid && this.isSowNumberValid && this.isFieldValid) {
      const displayName = this.bulkUpdateForm.get('field').value;
      const fType = this.getFieldNameByDisplayName(displayName);
      const dataType = this.getFieldDataType(displayName);
      let oldValue = this.bulkUpdateForm.get('oldValue').value;
      let newValue = this.bulkUpdateForm.get('newValue').value;
      if (newValue === '' || newValue === undefined || newValue === null) {
        this.handleInputFieldError('New value is required.');
        return;
      }
      if (dataType === 'date') {
        newValue = this.getFormattedDate(newValue);
      }
      if (!this.validateNewValue(newValue, dataType)) {
        return;
      }

      let exists = false;
      if (displayName === 'Billing Type') {
        exists = this.billingTypeDetails.some(item => item.billingTypeName == newValue);
        if (exists) {
          const patchOldValue = this.billingTypeDetails.find(item => item.billingTypeName === oldValue);
          const patchNewValue = this.billingTypeDetails.find(item => item.billingTypeName == newValue);

          var formOldValue: string = oldValue;
          const billingTypeNames = formOldValue.split(',').map(name => name.trim());
          const billingTypeIds = billingTypeNames
            .map(name => {
              const billingType = this.billingTypeDetails.find(item => item.billingTypeName === name);
              return billingType ? billingType.billingTypeId.toString() : null;
            })
            .filter(id => id !== null);

          if (billingTypeIds.length === billingTypeNames.length) {
            oldValue = billingTypeIds.join(', ');
          } else {
            oldValue = formOldValue;
          }
          //oldValue = patchOldValue.billingTypeId.toString();
          newValue = patchNewValue.billingTypeId.toString();
        } else {
          this.handleInputFieldError('Invalid Billing type.');
          return;
        }
      } else if (displayName === 'Project or Run') {
        exists = this.projectOrRunDetails.some(item => item.projectOrRun == newValue);
        if (exists) {
          //const patchOldValue = this.projectOrRunDetails.find(item => item.projectOrRun === oldValue);
          const patchNewValue = this.projectOrRunDetails.find(item => item.projectOrRun == newValue);

          var formOldValue: string = oldValue;
          const projectOrRunNames = formOldValue.split(',').map(name => name.trim());
          const projectOrRunIds = projectOrRunNames
            .map(name => {
              const projectOrRun = this.projectOrRunDetails.find(item => item.projectOrRun === name);
              return projectOrRun ? projectOrRun.projectOrRunId.toString() : null;
            })
            .filter(id => id !== null);
          if (projectOrRunIds.length === projectOrRunNames.length) {
            oldValue = projectOrRunIds.join(', ');
          } else {
            oldValue = formOldValue;
          }
          //oldValue = patchOldValue.projectOrRunId.toString();
          newValue = patchNewValue.projectOrRunId.toString();
        } else {
          this.handleInputFieldError('Invalid Project or Run type.');
          return;
        }
      }
      else if (displayName === 'Notice Period Days') {
        const numericValue = typeof newValue === 'string' ? parseFloat(newValue) : newValue;
        if (isNaN(numericValue) || numericValue < 0 || numericValue > 90) {
          this.handleInputFieldError('Invalid Notice Period days. Must be between 0 and 90 days.');
          return;
        }
      }

      const bulkFilter: BulkUpdateFilterType = {
        ContractType: this.bulkUpdateForm.get('contractType').value,
        SearchSowText: '',
        SOWNumber: this.bulkUpdateForm.get('sowNumber').value,
        FieldType: fType,
        oldValue: oldValue,
        newValue: newValue,
        dataType: dataType
      };

      const validContractTypes: string[] = CT_NAMES;
      if (!bulkFilter.ContractType || !validContractTypes.includes(bulkFilter.ContractType)) {
        this.handleInputFieldError('Invalid contract type.');
        return;
      }

      // Perform validation check and update the contract data
      this.CheckValidations(bulkFilter.ContractType, bulkFilter.SOWNumber, bulkFilter.FieldType, bulkFilter.newValue)
        .then(isValid => {
          if (isValid) {
            this.tmUploadService.UpdateContractColumnBySowNumber(bulkFilter).subscribe({
              next: (response) => {
                this.handleSuccessResponse(response);
                this.resetForm();
              },
              error: () => {
                this.handleErrorResponse();
              },
            });
          }
        })
        .catch(() => {
          this.handleErrorResponse();
        });
    } else {
      if (!this.isContractValid) {
        this.handleInputFieldError('Please select a valid Contract type.');
      }
      if (!this.isSowNumberValid) {
        this.handleInputFieldError('Please select a valid SOW Number.');
      }
      if (!this.isFieldValid) {
        this.handleInputFieldError('Please select a valid Field type.');
      }
      else {
        this.handleInvalidForm();
      }
    }
  }

  resetForm() {
    this.bulkUpdateForm.patchValue({
      contractType: this.defaultContractType,
      sowNumber: [''],
      field: [],
      oldValue: '',
      newValue: ''
    });
    this.isFieldValid = false;
    this.isSowNumberValid = false;
    this.bulkUpdateForm.markAsPristine();
    this.bulkUpdateForm.markAsUntouched();
    this.bulkUpdateForm.updateValueAndValidity();
    this.contractListBySowNo = [];
  }

  setValidationToFalse() {
    this.isFieldValid = false;
    this.isSowNumberValid = false;
  }

  getFormattedDate(dateValue: string): string {
    return this.datePipe.transform(dateValue, 'dd-MMM-yyyy') || '';
  }

  private validateNewValue(newValue: string, dataType: string): boolean {
    if (dataType === 'date') {
      const dateFormatPattern = /^\d{2}-[A-Za-z]{3}-\d{4}$/;
      if (!dateFormatPattern.test(newValue)) {
        this.bulkUpdateForm.get('newValue').setErrors({ invalidDateFormat: true });
        this.messageService.add({
          severity: 'error',
          summary: 'Validation Error!',
          detail: 'Date must be in the format "DD-MMM-YYYY".',
        });
        return false;
      }
    } else
      if (dataType === 'number') {
        const numberPattern = /^[0-9]*$/;
        if (!numberPattern.test(newValue)) {
          this.bulkUpdateForm.get('newValue').setErrors({ invalidNumberFormat: true });
          this.messageService.add({
            severity: 'error',
            summary: 'Validation Error!',
            detail: 'New Value must be a valid number.',
          });
          return false;
        }
      } else {
        this.bulkUpdateForm.get('newValue').setErrors(null);
      }
    return true;
  }

  private handleSuccessResponse(response: any) {
    if (response && response.affectedRows >= 1) {
      this.messageService.add({
        severity: 'success',
        summary: 'Success!',
        detail: 'Contracts updated successfully.',
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning!',
        detail: 'No contract found to update.',
      });
    }
    setTimeout(() => {
      this.messageService.clear();
    }, 3000);
  }

  private handleErrorResponse() {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Failed to update contracts.',
    });
    setTimeout(() => {
      this.messageService.clear();
    }, 3000);
  }

  private handleInputFieldError(message: string) {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: message,
    });
    setTimeout(() => {
      this.messageService.clear();
    }, 3000);
  }

  private handleInvalidForm() {
    this.messageService.add({
      severity: 'error',
      summary: 'Failed!',
      detail: 'Please select valid values',
    });
  }

  //Calling API for SOW Number List
  GetSowListByContractType(contractType: string, searchedText: string) {
    this.tmUploadService.GetSowListByContractType(contractType, searchedText).subscribe({
      next: (result: SowList[]) => {
        this.sowNumberSuggestions = result.map(item => item.sownumber);
        if (this.sowNumberSuggestions.length === 0) {
          this.messageService.add({
            severity: 'info',
            summary: 'No Data',
            detail: 'No SOWs found for the specified contract type.',
          });
        }
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch SOW list.',
        });
      },
    });
  }

  //Calling API for SOW Number List
  GetAllSowListByContractType(contractType: string, sowNo: string) {
    this.tmUploadService.GetAllSowListByContractType(contractType, sowNo).subscribe({
      next: (result: EmsFetchContactListBySowNo[]) => {
        if (this.sowNumberSuggestions.length === 0) {
          this.contractListBySowNo = [];
          this.messageService.add({
            severity: 'info',
            summary: 'No Data',
            detail: 'No SOWs list found for the specified contract type and SOW No.',
          });
        }
        else {
          this.contractListBySowNo = result;
        }
      },
      error: (err) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Failed!',
          detail: 'Failed to fetch all SOW list.',
        });
      },
    });
  }

  //Calling API to fetch old value
  GetOldValueByContractSowType(contractType: string, sowNumber: string, fieldType: string) {
    if (this.isFieldValid && this.isSowNumberValid) {
      this.tmUploadService.GetOldValueByContractSowType(contractType, sowNumber, this.getFieldNameByDisplayName(fieldType)).subscribe({
        next: (result: FieldType[]) => {
          if (result.length >= 1) {
            const dataType = this.getFieldDataType(fieldType);
            const formattedValues = result.map(item => this.formatFieldValue(item.fieldValue, dataType));
            let exists = false;
            let patchValue: any = null;

            if (fieldType === 'Billing Type') {
              // exists = this.billingTypeDetails.some(item => item.billingTypeId == formattedValues[0]);
              // if (exists) {
              //   patchValue = this.billingTypeDetails.find(item => item.billingTypeId == formattedValues[0]);
              //   this.bulkUpdateForm.patchValue({
              //     oldValue: patchValue.billingTypeName
              //   });
              // }
              const exists = this.billingTypeDetails.some(item => formattedValues.includes(item.billingTypeId.toString()));
              if (exists) {
                const billingTypeNames = this.billingTypeDetails
                  .filter(item => formattedValues.includes(item.billingTypeId.toString()))
                  .map(item => item.billingTypeName)
                  .join(', ');

                this.bulkUpdateForm.patchValue({
                  oldValue: billingTypeNames
                });
              } else {
                this.bulkUpdateForm.patchValue({
                  oldValue: ''
                });
              }
            } else if (fieldType === 'Project or Run') {
              // exists = this.projectOrRunDetails.some(item => item.projectOrRunId == formattedValues[0]);
              // if (exists) {
              //   patchValue = this.projectOrRunDetails.find(item => item.projectOrRunId == formattedValues[0]);
              //   this.bulkUpdateForm.patchValue({
              //     oldValue: patchValue.projectOrRun
              //   });
              // }
              const exists = this.projectOrRunDetails.some(item => formattedValues.includes(item.projectOrRunId.toString()));

              if (exists) {
                const projectOrRunValues = this.projectOrRunDetails
                  .filter(item => formattedValues.includes(item.projectOrRunId.toString()))
                  .map(item => item.projectOrRun)
                  .join(', ');

                this.bulkUpdateForm.patchValue({
                  oldValue: projectOrRunValues
                });
              } else {
                this.bulkUpdateForm.patchValue({
                  oldValue: ''
                });
              }
            } else {
              this.bulkUpdateForm.patchValue({
                oldValue: formattedValues.join(', ') // Join array values into a comma-separated string
              });
            }
          } else {
            this.bulkUpdateForm.patchValue({
              oldValue: '',
              newValue: '',
            });
            this.messageService.add({
              severity: 'error',
              summary: 'Failed!',
              detail: fieldType + ' does not contain any value.',
            });
          }
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to fetch existing value.',
          });
        },
      });
    }
  }

  //Calling API to check data validation
  CheckValidations(contractType: string, sowNumber: string, fieldType: string, newValue: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.tmUploadService.getValidationStatusForColumn(contractType, sowNumber, fieldType, newValue).subscribe({
        next: (result: BulkUpdateValidation[]) => {
          if (result.length > 0) {
            const validationResult = result[0];
            if (validationResult.message !== 'success') {
              this.messageService.add({
                severity: 'error',
                summary: 'Validation Error',
                detail: validationResult.message,
              });
              resolve(false);
            } else {
              resolve(true);
            }
          }
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed!',
            detail: 'Failed to check validation.',
          });
          resolve(false);
        },
      });
    });
  }

  //Calling API to fetch BillType and ProjectRunType
  getActiveProjectAndBillType() {
    this.sharedService.GetAllMasterDetails().subscribe({
      next: (result) => {
        this.billingTypeDetails = result.billingTypeMastersDetails.map(
          (item: any) => {
            const { billingTypeId, billingTypeName } = item;
            return { billingTypeId, billingTypeName };
          }
        );
        this.projectOrRunDetails = result.projOrRunMastersDetails.map(
          (item: any) => {
            const { projectOrRunId, projectOrRun } = item;
            return { projectOrRunId, projectOrRun };
          }
        );
      },
      complete() { },
      error: (error) => {
        console.error('Error fetching master details:', error);
      },
    });
  }

  getFieldDetailsByDisplayName(displayName: string) {
    return this.searchfieldNames.find(item => item.displayName === displayName);
  }

  getFieldDataType(fieldType: string): string {
    const fieldDetail = this.getFieldDetailsByDisplayName(fieldType);
    return fieldDetail ? fieldDetail.dataType : 'string';
  }

  getFieldNameByDisplayName(displayName: string): string {
    const fieldDetail = this.getFieldDetailsByDisplayName(displayName);
    return fieldDetail ? fieldDetail.fieldName : '';
  }

  formatFieldValue(value: any, dataType: string): any {
    if (dataType === 'date') {
      let date = new Date(value);
      if (isNaN(date.getTime())) {
        value = value.replace(/\s+/g, ' ');
        const dateParts = value.split(' ');
        if (dateParts.length >= 3) {
          const [monthStr, dayStr, yearStr] = dateParts;
          const month = new Date(Date.parse(monthStr + " 1, 2022")).getMonth();
          const day = parseInt(dayStr, 10);
          const year = parseInt(yearStr, 10);
          date = new Date(year, month, day);
        } else {
          console.error('Invalid date string format:', value);
          return value;
        }
      }

      // Convert to date format (dd-MMM-yyyy)
      const options: Intl.DateTimeFormatOptions = {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      };

      // Get the month abbreviation and convert to capitalized format
      const dateString = date.toLocaleDateString('en-GB', options);
      const [day, month, year] = dateString.split(' ');

      // Capitalize the first letter of the month and keep the rest lowercase
      const formattedMonth = month.charAt(0).toUpperCase() + month.slice(1).toLowerCase();
      return `${day}-${formattedMonth}-${year}`;
    }

    if (Array.isArray(value)) {
      return value.join(', ');
    }
    return value;
  }

  transform(value: any, format: string = 'dd-MMM-yyyy'): string {
    if (value) {
      return formatDate(value, format, 'en-US');
    }
    return value;
  }

  getProjectOrRunName(id: number): string {
    const found = this.projectOrRunDetails.find(detail => detail.projectOrRunId === id);
    return found ? found.projectOrRun : '';
  }

  getBillingTypeName(id: number): string {
    const found = this.billingTypeDetails.find(detail => detail.billingTypeId === id);
    return found ? found.billingTypeName : '';
  }

}