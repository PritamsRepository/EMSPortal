import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpApprovalmenuComponent } from './fp-approvalmenu.component';

describe('FpApprovalmenuComponent', () => {
  let component: FpApprovalmenuComponent;
  let fixture: ComponentFixture<FpApprovalmenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpApprovalmenuComponent]
    });
    fixture = TestBed.createComponent(FpApprovalmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
