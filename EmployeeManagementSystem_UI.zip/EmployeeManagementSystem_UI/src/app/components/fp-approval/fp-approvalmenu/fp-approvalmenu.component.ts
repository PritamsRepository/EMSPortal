import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Menu } from 'primeng/menu';

@Component({
  selector: 'app-fp-approvalmenu',
  templateUrl: './fp-approvalmenu.component.html',
  styleUrls: ['./fp-approvalmenu.component.css'],
})
export class FpApprovalmenuComponent {
  activeItem!: MenuItem;

  items!: MenuItem[];
  selectedTab: string = '';
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  constructor(private readonly router: Router) {
    this.createtab();
  }
  ngOnInit() {
    /*  this.items = [
       
        { label: 'Pending Milestone Details', icon: 'pi pi-fw pi-calendar', 
        routerLink: ['/fpapprovalmilestone']
        // command: () => this.selectTab('/fpuploadmilestone'), 
        },
        { label: 'Pending Monthly Payment Details', icon: 'pi pi-fw pi-pencil', 
          routerLink: ['/fpapprovalmonthly'] 
          // command: () => this.selectTab('/fpuploadmonthly'),
        }
      ];
      this.activeItem = this.items[0]; */
    //console.log('test1');
    //console.log(this.items);
    //console.log(this.activeItem);
  }
  createtab() {
    this.items = [
      {
        label: 'Pending FP Milestones Contracts',
        icon: 'pi pi-fw pi-calendar',
        routerLink: ['../fpapprovalmilestone'],
        // command: () => this.selectTab('/fpuploadmilestone'),
      },
      {
        label: 'Pending FP Monthly Contracts',
        icon: 'pi pi-fw pi-pencil',
        routerLink: ['../fpapprovalmonthly'],
        // command: () => this.selectTab('/fpuploadmonthly'),
      },
    ];
    this.activeItem = this.items[0];
  }

  onTabChange(event: MenuItem) {
    this.activeItem = event;
  }
}
