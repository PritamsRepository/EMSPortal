import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpApprovalmonthlyComponent } from './fp-approvalmonthly.component';

describe('FpApprovalmonthlyComponent', () => {
  let component: FpApprovalmonthlyComponent;
  let fixture: ComponentFixture<FpApprovalmonthlyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpApprovalmonthlyComponent]
    });
    fixture = TestBed.createComponent(FpApprovalmonthlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
