import { Component, OnInit } from '@angular/core';
import { FPApprovalService } from 'src/app/core/services/contract-approval/fp-approval.service';
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { ifpapproval } from 'src/app/core/interfaces/ifpapproval';
import { ifpmonapproval } from 'src/app/core/interfaces/ifpmonapproval';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { ResourceWorkflow } from 'src/app/core/interfaces/resource-workflow';
import { ResourceOnboardingService } from 'src/app/core/services/resource-onboarding/resource-onboarding.service';

@Component({
  selector: 'app-fp-approvalmonthly',
  templateUrl: './fp-approvalmonthly.component.html',
  styleUrls: ['./fp-approvalmonthly.component.css'],
  providers: [
    MessageService,
    DialogService,
    FPApprovalService,
    ConfirmationService,
  ],
})
export class FpApprovalmonthlyComponent implements OnInit {
  constructor(
    private ResourceOnboardingService: ResourceOnboardingService,
    private fpApprovalService: FPApprovalService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService
  ) {}

  fpapprovaldetails!: ifpapproval[];
  fpapprovaldetail!: ifpapproval;
  fpmapprovaldetails!: ifpmonapproval[];
  cols: any[] = [];
  isapprovechecked: boolean = false;
  isrejectchecked: boolean = false;
  totalApproved: number = 0;
  totalRejected: number = 0;
  pageTitle: string = 'Fixed Price Monthly Contracts Pending Lists';
  selectedDetails!: any[] | null;
  isvalid: boolean = false;
  inValidrecord!: ifpapproval | null;
  errorMessage!: string | null;
  expanded: any;
  Workflowdialog: boolean = false;
  contractWorkFlow!: ResourceWorkflow[];
  wfheadertext: string = 'Work Flow History';

  ngOnInit() {
    this.getfpContractDetails();
    //console.log('test');
    this.cols = [
      { field: 'isSelectedApproval', header: 'Approve' },
      { field: 'selectedRejectedlist', header: 'Reject' },
      { field: 'CMID', header: 'CMID' },
      { field: 'etwid', header: 'ETWID' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'sowNumber', header: 'SOW Number' },
      { field: 'sowName', header: 'SOW Name' },
      { field: 'sowType', header: 'SOW Type' },
      { field: 'sowStartDate', header: 'SOW Start Date' },
      { field: 'sowEndDate', header: 'SOW End Date' },
      
      { field: 'poNumber', header: 'PO Number' },
      { field: 'poStartDate', header: 'PO Start Date' },
      { field: 'poEndDate', header: 'PO End Date' },
      { field: 'ppmProjectID', header: 'PPM Project ID' },
      { field: 'ppmProjectName', header: 'PPM Project Name' },
      { field: 'tower', header: 'Tower' },
      { field: 'domainName', header: 'Domain Name' },
      { field: 'skillSet', header: 'Skill Set' },
      { field: 'domainSkillStartDate', header: 'Domain Skill Start Date' },
      { field: 'domainSkillEndDate', header: 'Domain Skill End Date' },
      { field: 'contractType', header: 'Contract Type' },
      { field: 'billingType', header: 'Billing Type' },
      { field: 'amortizationStartMonth', header: 'Amortization Starting From' },
      { field: 'amortizationEndMonth', header: 'Amortization Ending On' },
      { field: 'positionLocation', header: 'Managing Team' },

      { field: 'oldSowNumber', header: 'Old SOW Number' },
      { field: 'remappedMID', header: 'Existing MID' },
    ];
  }
  getfpContractDetails() {
    this.fpApprovalService.getmonapprovaldata().subscribe((result) => {
      //console.log(result);
      this.fpapprovaldetails = result;
    });
    //console.log('check');
  }
  // Reject --> SendBack
  selectApproveAll() {
    this.fpapprovaldetails.forEach((x) => (x.isSelectedApproval = true));
    this.isapprovechecked = true;
    this.isrejectchecked = false;
    this.totalApproved = [...this.fpapprovaldetails].length;
    this.totalRejected = 0;

    this.messageService.add({
      severity: 'info',
      summary: 'All contracts sellected for Approval',
    });
  }
  selectApprove(fpapprovaldetail: ifpapproval) {
    const aIndex = this.fpapprovaldetails.findIndex(
      (item) => item === fpapprovaldetail
    );
    if (aIndex !== -1) {
      this.totalApproved = this.totalApproved + 1;
      if (this.fpapprovaldetails[aIndex].isSelectedApproval != null) {
        this.totalRejected =
          this.totalRejected == 0 ? 0 : this.totalRejected - 1;
      }
      this.fpapprovaldetails[aIndex].isSelectedApproval = true; // Remove 1 element starting from the index
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;

    this.messageService.add({
      severity: 'info',
      summary: fpapprovaldetail.sowNumber + ' contract selected for Approval',
    });
  }
  selectRejectAll() {
    this.fpapprovaldetails.forEach((x) => (x.isSelectedApproval = false));

    this.totalApproved = 0;
    this.totalRejected = [...this.fpapprovaldetails].length;

    this.isapprovechecked = false;
    this.isrejectchecked = true;

    this.messageService.add({
      severity: 'info',
      summary: 'All contracts selected for SendBack',
    });
  }
  //Click on SendBack
  selectReject(fpapprovaldetail: ifpapproval) {
    const aIndex = this.fpapprovaldetails.findIndex(
      (item) => item === fpapprovaldetail
    );
    if (aIndex !== -1) {
      if (this.fpapprovaldetails[aIndex].isSelectedApproval != null) {
        this.totalApproved =
          this.totalApproved == 0 ? 0 : this.totalApproved - 1;
      }
      this.totalRejected = this.totalRejected + 1;
      this.fpapprovaldetails[aIndex].isSelectedApproval = false;
    }

    this.isapprovechecked = false;
    this.isrejectchecked = false;

    this.messageService.add({
      severity: 'info',
      summary: fpapprovaldetail.sowNumber + ' contract selected for SendBack',
    });
  }
  expandClick(fpapprovaldetail: ifpapproval, isexpanded: boolean) {
    if (isexpanded == false && fpapprovaldetail.milestones == null) {
      this.fpApprovalService
        .getmonthlyData(fpapprovaldetail.sowNumber)
        .subscribe((result) => {
          this.fpmapprovaldetails = result;
          this.fpapprovaldetails.map((x) =>
            x.sowNumber === fpapprovaldetail.sowNumber
              ? (x.monthly = this.fpmapprovaldetails)
              : x
          );
        });
    }
  }
  // Click on Submit Button
  submitAction() {
    //If action not taken
    const aIndex = this.fpapprovaldetails.find(
      (item) => item.isSelectedApproval === null
    );
    if (aIndex !== null && aIndex != undefined) {
      this.inValidrecord = aIndex as ifpapproval;
      this.errorMessage = 'Please take action on contract (ETWID):';
      this.confirmationService.confirm({
        accept: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
        reject: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
      });
      return;
    }
    //If Reject not having remarks
    const remarks = this.fpapprovaldetails.find(
      (item) =>
        item.isSelectedApproval === false &&
        (item.remarks === '' || item.remarks === null)
    );
    if (remarks !== null && remarks != undefined) {
      this.inValidrecord = remarks as ifpapproval;
      this.errorMessage =
        'Please provide remarks for Sendback contract (ETWID):';
      this.confirmationService.confirm({
        reject: () => {
          this.errorMessage === '';
          this.inValidrecord === null;
        },
      });
      return;
    }
    this.fpApprovalService
      .postmonApproval(this.fpapprovaldetails)
      .subscribe((result) => {
        //console.log(result);
        if (result.message === 'success')
          this.messageService.add({
            severity: 'info',
            summary: 'Contracts Approved/Sentback Successfully!',
          });
        this.fpapprovaldetails = [];
        this.totalApproved = 0;
        this.totalRejected = 0;
      });
  }
  GetFPWorkFlowData(cmid: number, etwid: number) {
    this.Workflowdialog = true;
    (this.wfheadertext = 'Work Flow History - (ETWID:- ' + etwid + ')'),
      this.ResourceOnboardingService.GetFPmonthlyResourceWorkFlow(
        cmid
      ).subscribe((result) => {
        //console.log(result);
        this.contractWorkFlow = result;
      });
  }
  ExportToExcel(): void {
    const datePipe = new DatePipe('en-US');
    const filteredContractList = this.fpapprovaldetails.map((contract) => {
      // Create a new object to hold the properties in the desired order
      return {
        etwid: contract.etwid,

        vendorName: contract.vendorName,
        sowNumber: contract.sowNumber,
        sowName: contract.sowName,
        // sowType :contract.sowType,
        sowStartDate: contract.sowStartDate
          ? datePipe.transform(contract.sowStartDate, 'dd-MMM-yyyy')
          : '',
        sowEndDate: contract.sowEndDate
          ? datePipe.transform(contract.sowEndDate, 'dd-MMM-yyyy')
          : '',
        poNumber: contract.poNumber,
        poStartDate: contract.poStartDate
          ? datePipe.transform(contract.poStartDate, 'dd-MMM-yyyy')
          : '',
        poEndDate: contract.poEndDate
          ? datePipe.transform(contract.poEndDate, 'dd-MMM-yyyy')
          : '',
        contractType: contract.contractType,
        ppmProjectID: contract.ppmProjectID,
        ppmProjectName: contract.ppmProjectName,
        tower: contract.tower,
        vertical: contract.vertical,
        wbsDetail: contract.wbsDetail,
        domainLeadEmail: contract.domainLeadEmail,
        domainSkillName: contract.domainSkillName,
        // currency:contract.currency,
        positionLocation: contract.positionLocation,
        oldSowNumber: contract.oldSowNumber,
        //sapCode :contract.sapCode,
        // obs :contract.obs,
        // noticePeriod:contract.noticePeriod,
        amortizationStartDate: contract.amortizationStartMonth
          ? datePipe.transform(contract.amortizationStartMonth, 'dd-MMM-yyyy')
          : '',
        amortizationEndDate: contract.amortizationEndMonth
          ? datePipe.transform(contract.amortizationEndMonth, 'dd-MMM-yyyy')
          : '',

        skillSet: contract.skillSet,
        domainSkillStartDate: contract.domainSkillStartDate
          ? datePipe.transform(contract.domainSkillStartDate, 'dd-MMM-yyyy')
          : '',
        domainSkillEndDate: contract.domainSkillEndDate
          ? datePipe.transform(contract.domainSkillEndDate, 'dd-MMM-yyyy')
          : '',
        BillingType: contract.billingType,
        RemappedMID: contract.remappedMID,
      };
    });

    // Convert the filteredContractList to a worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredContractList);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'FP Monthly Contract Pending List.xlsx');
  }
}
