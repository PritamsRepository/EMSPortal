import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpApprovalmilestoneComponent } from './fp-approvalmilestone.component';

describe('FpApprovalmilestoneComponent', () => {
  let component: FpApprovalmilestoneComponent;
  let fixture: ComponentFixture<FpApprovalmilestoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FpApprovalmilestoneComponent]
    });
    fixture = TestBed.createComponent(FpApprovalmilestoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
