// role.guard.ts
import { Injectable } from '@angular/core';
import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  CanActivate,
  CanActivateFn,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from 'src/app/core/services/auth/authentication.service';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard {
  constructor(
    private readonly authService: AuthenticationService,
    private readonly router: Router
  ) {}

  //   canActivate(
  //     route: ActivatedRouteSnapshot,
  //     state: RouterStateSnapshot
  //   ):
  //     | Observable<boolean | UrlTree>
  //     | Promise<boolean | UrlTree>
  //     | boolean
  //     | UrlTree {
  //     //console.log('role Security call');
  //     // const user = this.storageService.getUser()
  //     // if (user != null) {
  //     //   // logged in so return true
  //     //   //console.log('test user');
  //     // //  //console.log(user);
  //     //   return true
  //     // }
  //     // not logged in so redirect to login page with the return url
  //     this.router.navigate(['login'], { queryParams: { returnUrl: state.url } });
  //     return false;
  //   }

  canActivate: (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ) =>
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
    //console.log('role security  guard call');
    var expectedRoles = route.data['expectedRoles'];
    var routData = route.data;

    // Check if the route has the skipRoleCheck property
    if (route.data['skipRoleCheck']) {
      return true; // Allow access without role check
    } else if (
      //!this.authService.isAuthenticated() ||
      this.authService.hasRoles(expectedRoles) == false
    ) {
      //console.log('route data :', routData);
      //console.log('ex-role :', expectedRoles);
      //console.log('result :', this.authService.hasRoles(expectedRoles));

      this.router.navigate(['/error']);
      return false;
    }

    return true;
  };
}
